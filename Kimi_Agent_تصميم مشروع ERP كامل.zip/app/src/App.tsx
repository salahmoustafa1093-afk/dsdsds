import { HashRouter, Routes, Route } from 'react-router-dom';
import { DarkModeProvider } from '@/hooks/useDarkMode';
import { SidebarProvider } from '@/hooks/useSidebar';
import Layout from '@/components/Layout';

// Dashboard & Executive
import Dashboard from '@/pages/Dashboard';
import ExecutiveDashboard from '@/pages/ExecutiveDashboard';
import AIDashboard from '@/pages/AIDashboard';

// Inventory
import InventoryPage from '@/pages/InventoryPage';
import ProductsPage from '@/pages/ProductsPage';
import MovementsPage from '@/pages/MovementsPage';
import AuditPage from '@/pages/AuditPage';
import InventoryWarehousePage from '@/pages/InventoryWarehousePage';

// Sales
import SalesPage from '@/pages/SalesPage';
import SalesReturnsPage from '@/pages/SalesReturnsPage';
import QuotesPage from '@/pages/QuotesPage';
import SalesChannelPage from '@/pages/SalesChannelPage';

// Purchases
import PurchasesPage from '@/pages/PurchasesPage';

// Customers
import CustomersPage from '@/pages/CustomersPage';
import CustomerDebtsPage from '@/pages/CustomerDebtsPage';
import CustomerCategoriesPage from '@/pages/CustomerCategoriesPage';
import B2BPortalPage from '@/pages/B2BPortalPage';
import DriverAppPage from '@/pages/DriverAppPage';
import WarehouseAppPage from '@/pages/WarehouseAppPage';
import AICopilotPage from '@/pages/AICopilotPage';

// Suppliers
import SuppliersPage from '@/pages/SuppliersPage';
import SupplierRatingPage from '@/pages/SupplierRatingPage';

// Accounting
import AccountingPage from '@/pages/AccountingPage';
import AccountingTreasuryPage from '@/pages/AccountingTreasuryPage';
import AccountingBanksPage from '@/pages/AccountingBanksPage';
import AccountingEntriesPage from '@/pages/AccountingEntriesPage';
import AccountingChartPage from '@/pages/AccountingChartPage';

// Production
import ProductionPage from '@/pages/ProductionPage';
import ProductionLinesPage from '@/pages/ProductionLinesPage';
import ProductionOrdersPage from '@/pages/ProductionOrdersPage';
import ProductionReportsPage from '@/pages/ProductionReportsPage';

// Feed
import FeedPage from '@/pages/FeedPage';
import FeedFormulasPage from '@/pages/FeedFormulasPage';
import FeedMaterialsPage from '@/pages/FeedMaterialsPage';
import FeedCostsPage from '@/pages/FeedCostsPage';

// Pulses
import PulsesPage from '@/pages/PulsesPage';
import PulsesReceivingPage from '@/pages/PulsesReceivingPage';
import PulsesSortingPage from '@/pages/PulsesSortingPage';
import PulsesPackagingPage from '@/pages/PulsesPackagingPage';

// Packaging
import PackagingPage from '@/pages/PackagingPage';
import PackagingLinesPage from '@/pages/PackagingLinesPage';
import PackagingOrdersPage from '@/pages/PackagingOrdersPage';
import PackagingDesignsPage from '@/pages/PackagingDesignsPage';

// Poultry & Eggs
import PoultryPage from '@/pages/PoultryPage';
import EggsPage from '@/pages/EggsPage';

// Livestock
import LivestockPage from '@/pages/LivestockPage';
import LivestockHerdPage from '@/pages/LivestockHerdPage';
import LivestockFeedingPage from '@/pages/LivestockFeedingPage';
import LivestockVaccinesPage from '@/pages/LivestockVaccinesPage';

// Fleet & Delivery
import FleetPage from '@/pages/FleetPage';
import DeliveryPage from '@/pages/DeliveryPage';

// HR
import HRPage from '@/pages/HRPage';
import HREmployeesPage from '@/pages/HREmployeesPage';
import HRAttendancePage from '@/pages/HRAttendancePage';
import HRPayrollPage from '@/pages/HRPayrollPage';
import HRCommissionsPage from '@/pages/HRCommissionsPage';

// Branches
import BranchesPage from '@/pages/BranchesPage';
import BranchesListPage from '@/pages/BranchesListPage';
import BranchesTransfersPage from '@/pages/BranchesTransfersPage';
import BranchesSalesPage from '@/pages/BranchesSalesPage';

// Reports
import ReportsPage from '@/pages/ReportsPage';
import ReportsFinancialPage from '@/pages/ReportsFinancialPage';
import ReportsInventoryPage from '@/pages/ReportsInventoryPage';
import ReportsSalesPage from '@/pages/ReportsSalesPage';
import ReportsProductionPage from '@/pages/ReportsProductionPage';

// Settings
import SettingsPage from '@/pages/SettingsPage';
import SettingsGeneralPage from '@/pages/SettingsGeneralPage';
import SettingsUsersPage from '@/pages/SettingsUsersPage';
import SettingsFinancialPage from '@/pages/SettingsFinancialPage';
import SettingsBackupPage from '@/pages/SettingsBackupPage';

function App() {
  return (
    <DarkModeProvider>
      <SidebarProvider>
        <HashRouter>
          <Layout>
            <Routes>
              {/* Dashboard & Executive */}
              <Route path="/" element={<Dashboard />} />
              <Route path="/executive" element={<ExecutiveDashboard />} />
              <Route path="/ai" element={<AIDashboard />} />

              {/* Inventory */}
              <Route path="/inventory" element={<InventoryPage />} />
              <Route path="/inventory/products" element={<ProductsPage />} />
              <Route path="/inventory/movements" element={<MovementsPage />} />
              <Route path="/inventory/audit" element={<AuditPage />} />
              <Route path="/inventory/warehouses" element={<InventoryWarehousePage />} />

              {/* Sales */}
              <Route path="/sales" element={<SalesPage />} />
              <Route path="/sales/returns" element={<SalesReturnsPage />} />
              <Route path="/sales/quotes" element={<QuotesPage />} />
              <Route path="/sales/channels" element={<SalesChannelPage />} />

              {/* Purchases */}
              <Route path="/purchases" element={<PurchasesPage />} />
              <Route path="/purchases/returns" element={<PurchasesPage />} />
              <Route path="/purchases/requests" element={<PurchasesPage />} />

              {/* Customers & Suppliers */}
              <Route path="/customers" element={<CustomersPage />} />
              <Route path="/customers/debts" element={<CustomerDebtsPage />} />
              <Route path="/customers/categories" element={<CustomerCategoriesPage />} />
              <Route path="/suppliers" element={<SuppliersPage />} />
              <Route path="/suppliers/rating" element={<SupplierRatingPage />} />
              <Route path="/b2b" element={<B2BPortalPage />} />

              {/* Accounting */}
              <Route path="/accounting" element={<AccountingPage />} />
              <Route path="/accounting/treasury" element={<AccountingTreasuryPage />} />
              <Route path="/accounting/banks" element={<AccountingBanksPage />} />
              <Route path="/accounting/entries" element={<AccountingEntriesPage />} />
              <Route path="/accounting/chart" element={<AccountingChartPage />} />

              {/* Production */}
              <Route path="/production" element={<ProductionPage />} />
              <Route path="/production/lines" element={<ProductionLinesPage />} />
              <Route path="/production/orders" element={<ProductionOrdersPage />} />
              <Route path="/production/reports" element={<ProductionReportsPage />} />

              {/* Feed */}
              <Route path="/feed" element={<FeedPage />} />
              <Route path="/feed/formulas" element={<FeedFormulasPage />} />
              <Route path="/feed/materials" element={<FeedMaterialsPage />} />
              <Route path="/feed/costs" element={<FeedCostsPage />} />

              {/* Pulses */}
              <Route path="/pulses" element={<PulsesPage />} />
              <Route path="/pulses/receiving" element={<PulsesReceivingPage />} />
              <Route path="/pulses/sorting" element={<PulsesSortingPage />} />
              <Route path="/pulses/packaging" element={<PulsesPackagingPage />} />

              {/* Packaging */}
              <Route path="/packaging" element={<PackagingPage />} />
              <Route path="/packaging/lines" element={<PackagingLinesPage />} />
              <Route path="/packaging/orders" element={<PackagingOrdersPage />} />
              <Route path="/packaging/designs" element={<PackagingDesignsPage />} />

              {/* Poultry & Eggs */}
              <Route path="/poultry" element={<PoultryPage />} />
              <Route path="/eggs" element={<EggsPage />} />

              {/* Livestock */}
              <Route path="/livestock" element={<LivestockPage />} />
              <Route path="/livestock/herd" element={<LivestockHerdPage />} />
              <Route path="/livestock/feeding" element={<LivestockFeedingPage />} />
              <Route path="/livestock/vaccines" element={<LivestockVaccinesPage />} />

              {/* Fleet & Delivery */}
              <Route path="/fleet" element={<FleetPage />} />
              <Route path="/delivery" element={<DeliveryPage />} />
              <Route path="/driver-app" element={<DriverAppPage />} />
              <Route path="/warehouse-app" element={<WarehouseAppPage />} />
              <Route path="/ai-copilot" element={<AICopilotPage />} />

              {/* HR */}
              <Route path="/hr" element={<HRPage />} />
              <Route path="/hr/employees" element={<HREmployeesPage />} />
              <Route path="/hr/attendance" element={<HRAttendancePage />} />
              <Route path="/hr/payroll" element={<HRPayrollPage />} />
              <Route path="/hr/commissions" element={<HRCommissionsPage />} />

              {/* Branches */}
              <Route path="/branches" element={<BranchesPage />} />
              <Route path="/branches/list" element={<BranchesListPage />} />
              <Route path="/branches/transfers" element={<BranchesTransfersPage />} />
              <Route path="/branches/sales" element={<BranchesSalesPage />} />

              {/* Reports */}
              <Route path="/reports" element={<ReportsPage />} />
              <Route path="/reports/financial" element={<ReportsFinancialPage />} />
              <Route path="/reports/inventory" element={<ReportsInventoryPage />} />
              <Route path="/reports/sales" element={<ReportsSalesPage />} />
              <Route path="/reports/production" element={<ReportsProductionPage />} />

              {/* Settings */}
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/settings/general" element={<SettingsGeneralPage />} />
              <Route path="/settings/users" element={<SettingsUsersPage />} />
              <Route path="/settings/financial" element={<SettingsFinancialPage />} />
              <Route path="/settings/backup" element={<SettingsBackupPage />} />
            </Routes>
          </Layout>
        </HashRouter>
      </SidebarProvider>
    </DarkModeProvider>
  );
}

export default App;
