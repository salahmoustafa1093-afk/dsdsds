import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface KPICardProps {
  title: string;
  value: string;
  change?: number;
  changeLabel?: string;
  icon: React.ElementType;
  iconBg: string;
  iconColor: string;
  delay?: number;
}

export default function KPICard({
  title,
  value,
  change,
  changeLabel = 'عن الفترة السابقة',
  icon: Icon,
  iconBg,
  iconColor,
  delay = 0,
}: KPICardProps) {
  const isPositive = change && change > 0;
  const isNegative = change && change < 0;
  const isNeutral = change === 0 || change === undefined;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: [0, 0, 0.2, 1] as [number, number, number, number] }}
      className={cn(
        'bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-kpi p-5 hover:shadow-md transition-shadow duration-200'
      )}
    >
      <div className="flex items-start justify-between mb-3">
        <div
          className={cn(
            'w-11 h-11 rounded-full flex items-center justify-center',
            iconBg
          )}
        >
          <Icon size={22} className={iconColor} />
        </div>
        {change !== undefined && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.3, delay: delay + 0.3 }}
            className={cn(
              'flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold',
              isPositive && 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400',
              isNegative && 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400',
              isNeutral && 'bg-slate-50 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
            )}
          >
            {isPositive && <TrendingUp size={12} />}
            {isNegative && <TrendingDown size={12} />}
            {isNeutral && <Minus size={12} />}
            <span>
              {isPositive ? '+' : ''}
              {change}%
            </span>
          </motion.div>
        )}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: delay + 0.1 }}
      >
        <h3 className="text-[28px] font-bold text-textPrimary dark:text-darkText leading-tight mb-1">
          {value}
        </h3>
        <p className="text-xs text-textSecondary dark:text-darkTextSec font-medium">
          {title}
        </p>
        {change !== undefined && (
          <p className="text-[11px] text-textMuted mt-1">{changeLabel}</p>
        )}
      </motion.div>
    </motion.div>
  );
}
