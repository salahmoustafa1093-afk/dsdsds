import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  breadcrumb?: { label: string; path?: string }[];
  children?: React.ReactNode;
}

export default function PageHeader({
  title,
  subtitle,
  breadcrumb,
  children,
}: PageHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0, 0, 0.2, 1] as [number, number, number, number] }}
      className="mb-6"
    >
      {breadcrumb && breadcrumb.length > 0 && (
        <nav className="flex items-center gap-1 mb-2 text-xs text-textMuted">
          {breadcrumb.map((item, index) => (
            <span key={item.label} className="flex items-center gap-1">
              {index > 0 && <ChevronLeft size={12} className="text-textMuted" />}
              {item.path ? (
                <Link
                  to={item.path}
                  className="hover:text-green-700 dark:hover:text-green-400 transition-colors"
                >
                  {item.label}
                </Link>
              ) : (
                <span className="text-textSecondary dark:text-darkTextSec">
                  {item.label}
                </span>
              )}
            </span>
          ))}
        </nav>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-[28px] font-bold text-textPrimary dark:text-darkText leading-tight">
            {title}
          </h1>
          {subtitle && (
            <p className="text-sm text-textSecondary dark:text-darkTextSec mt-1">
              {subtitle}
            </p>
          )}
        </div>
        {children && (
          <div className="flex items-center gap-2 flex-wrap">{children}</div>
        )}
      </div>
    </motion.div>
  );
}
