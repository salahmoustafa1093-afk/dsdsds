import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useSidebar } from '@/hooks/useSidebar';
import Sidebar from './Sidebar';
import Navbar from './Navbar';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { collapsed } = useSidebar();
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="min-h-[100dvh] dir-rtl">
      <Sidebar />

      <div
        className={cn(
          'sidebar-transition flex flex-col min-h-[100dvh]',
          collapsed
            ? 'mr-[72px] lg:mr-[72px]'
            : 'mr-0 lg:mr-[260px]'
        )}
      >
        <Navbar />
        <main className="flex-1 p-4 lg:p-6 bg-surface dark:bg-darkBg gff-page-transition">
          {children}
        </main>
      </div>
    </div>
  );
}
