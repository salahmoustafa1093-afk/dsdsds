import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Warehouse,
  ShoppingCart,
  Truck,
  Users,
  Handshake,
  Landmark,
  Factory,
  Wheat,
  Bean,
  Package,
  Beef,
  UsersRound,
  MapPin,
  BarChart3,
  Settings,
  ChevronDown,
  ChevronLeft,
  Menu,
  X,
  Crown,
  Brain,
  Car,
  Navigation,
  Bird,
  Egg,
  Globe,
  Smartphone,
  PackageCheck,
  Bot,
} from 'lucide-react';
import { useSidebar } from '@/hooks/useSidebar';
import { cn } from '@/lib/utils';

interface MenuItem {
  label: string;
  icon: React.ElementType;
  path?: string;
  children?: { label: string; path: string }[];
}

const menuItems: MenuItem[] = [
  { label: 'لوحة التحكم', icon: LayoutDashboard, path: '/' },
  { label: 'لوحة القيادة التنفيذية', icon: Crown, path: '/executive' },
  { label: 'تحليلات الذكاء الاصطناعي', icon: Brain, path: '/ai' },
  {
    label: 'إدارة المخازن',
    icon: Warehouse,
    children: [
      { label: 'المستودعات', path: '/inventory' },
      { label: 'المنتجات', path: '/inventory/products' },
      { label: 'حركات المخزون', path: '/inventory/movements' },
      { label: 'الجرد', path: '/inventory/audit' },
    ],
  },
  {
    label: 'المبيعات',
    icon: ShoppingCart,
    children: [
      { label: 'فواتير', path: '/sales' },
      { label: 'مرتجعات', path: '/sales/returns' },
      { label: 'عروض أسعار', path: '/sales/quotes' },
    ],
  },
  {
    label: 'المشتريات',
    icon: Truck,
    children: [
      { label: 'أوامر شراء', path: '/purchases' },
      { label: 'مرتجعات', path: '/purchases/returns' },
      { label: 'طلبات', path: '/purchases/requests' },
    ],
  },
  {
    label: 'العملاء',
    icon: Users,
    children: [
      { label: 'سجل', path: '/customers' },
      { label: 'مديونيات', path: '/customers/debts' },
      { label: 'تصنيفات', path: '/customers/categories' },
    ],
  },
  { label: 'بوابة العملاء B2B', icon: Globe, path: '/b2b' },
  {
    label: 'الموردين',
    icon: Handshake,
    children: [
      { label: 'سجل', path: '/suppliers' },
      { label: 'تقييم', path: '/suppliers/rating' },
    ],
  },
  {
    label: 'الحسابات',
    icon: Landmark,
    children: [
      { label: 'خزينة', path: '/accounting/treasury' },
      { label: 'بنوك', path: '/accounting/banks' },
      { label: 'قيود', path: '/accounting/entries' },
      { label: 'شجرة حسابات', path: '/accounting/chart' },
    ],
  },
  {
    label: 'الإنتاج',
    icon: Factory,
    children: [
      { label: 'خطوط', path: '/production/lines' },
      { label: 'أوامر', path: '/production/orders' },
      { label: 'تقارير', path: '/production/reports' },
    ],
  },
  {
    label: 'الأعلاف',
    icon: Wheat,
    children: [
      { label: 'تركيبات', path: '/feed/formulas' },
      { label: 'مواد خام', path: '/feed/materials' },
      { label: 'تكاليف', path: '/feed/costs' },
    ],
  },
  {
    label: 'البقوليات',
    icon: Bean,
    children: [
      { label: 'استلام', path: '/pulses/receiving' },
      { label: 'فرز', path: '/pulses/sorting' },
      { label: 'تعبئة', path: '/pulses/packaging' },
    ],
  },
  {
    label: 'التعبئة',
    icon: Package,
    children: [
      { label: 'خطوط', path: '/packaging/lines' },
      { label: 'أوامر', path: '/packaging/orders' },
      { label: 'تصاميم', path: '/packaging/designs' },
    ],
  },
  { label: 'الدواجن', icon: Bird, path: '/poultry' },
  { label: 'بيض المائدة', icon: Egg, path: '/eggs' },
  {
    label: 'المواشي',
    icon: Beef,
    children: [
      { label: 'قطيع', path: '/livestock/herd' },
      { label: 'تغذية', path: '/livestock/feeding' },
      { label: 'تحصينات', path: '/livestock/vaccines' },
    ],
  },
  { label: 'الأسطول', icon: Car, path: '/fleet' },
  { label: 'التوصيل', icon: Navigation, path: '/delivery' },
  { label: 'تطبيق السائق', icon: Smartphone, path: '/driver-app' },
  { label: 'تطبيق المخزن', icon: PackageCheck, path: '/warehouse-app' },
  { label: 'AI Copilot', icon: Bot, path: '/ai-copilot' },
  {
    label: 'الموارد البشرية',
    icon: UsersRound,
    children: [
      { label: 'موظفين', path: '/hr/employees' },
      { label: 'حضور', path: '/hr/attendance' },
      { label: 'رواتب', path: '/hr/payroll' },
      { label: 'عمولات', path: '/hr/commissions' },
    ],
  },
  {
    label: 'الفروع',
    icon: MapPin,
    children: [
      { label: 'الفروع', path: '/branches' },
      { label: 'تحويلات', path: '/branches/transfers' },
      { label: 'مبيعات', path: '/branches/sales' },
    ],
  },
  {
    label: 'التقارير',
    icon: BarChart3,
    children: [
      { label: 'مالية', path: '/reports/financial' },
      { label: 'مخزون', path: '/reports/inventory' },
      { label: 'مبيعات', path: '/reports/sales' },
      { label: 'إنتاج', path: '/reports/production' },
    ],
  },
  {
    label: 'الإعدادات',
    icon: Settings,
    children: [
      { label: 'عام', path: '/settings/general' },
      { label: 'مستخدمين', path: '/settings/users' },
      { label: 'مالية', path: '/settings/financial' },
      { label: 'نسخ احتياطي', path: '/settings/backup' },
    ],
  },
];

const menuPathMap: Record<string, string> = {};
menuItems.forEach((item) => {
  if (item.path) menuPathMap[item.path] = item.label;
  if (item.children) {
    item.children.forEach((child) => {
      menuPathMap[child.path] = `${item.label} / ${child.label}`;
    });
  }
});

export { menuPathMap };

function MenuGroup({ item, collapsed }: { item: MenuItem; collapsed: boolean }) {
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const hasActiveChild = item.children?.some(
    (c) => location.pathname === c.path || location.pathname.startsWith(c.path)
  );
  const isOpen = open || hasActiveChild;

  if (collapsed) {
    return (
      <div className="group relative">
        <button
          onClick={() => setOpen(!open)}
          className={cn(
            'w-[56px] h-11 mx-auto rounded-lg flex items-center justify-center transition-all duration-200',
            hasActiveChild
              ? 'bg-green-800 text-gold-400'
              : 'text-green-200/80 hover:bg-green-900 hover:text-white'
          )}
        >
          <item.icon size={20} />
        </button>
        {hasActiveChild && (
          <div className="absolute right-full mr-2 top-1/2 -translate-y-1/2 w-1 h-6 bg-gold-500 rounded-l" />
        )}
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-darkBg text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap transition-opacity z-50">
          {item.label}
        </div>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          'w-full h-11 px-3 rounded-lg flex items-center justify-between transition-all duration-200',
          hasActiveChild
            ? 'bg-green-800 text-white'
            : 'text-green-200/80 hover:bg-green-900 hover:text-white'
        )}
      >
        <div className="flex items-center gap-3">
          <item.icon size={20} />
          <span className="text-sm font-medium">{item.label}</span>
        </div>
        <motion.div
          animate={{ rotate: isOpen ? -180 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <ChevronDown size={16} />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="mr-7 mt-1 space-y-0.5 border-r border-green-800/50 pr-3">
              {item.children?.map((child) => {
                const isActive = location.pathname === child.path;
                return (
                  <Link
                    key={child.path}
                    to={child.path}
                    className={cn(
                      'block px-3 py-2 rounded-lg text-sm transition-all duration-200',
                      isActive
                        ? 'bg-green-800/60 text-gold-400 font-medium'
                        : 'text-green-200/60 hover:text-white hover:bg-green-900/50'
                    )}
                  >
                    {child.label}
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function Sidebar() {
  const { collapsed, toggle, mobileOpen, setMobileOpen } = useSidebar();
  const location = useLocation();

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="fixed top-4 right-4 z-50 lg:hidden w-10 h-10 rounded-lg bg-green-950 text-white flex items-center justify-center shadow-lg"
      >
        {mobileOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      <aside
        className={cn(
          'fixed top-0 right-0 h-full bg-green-950 z-40 sidebar-transition flex flex-col',
          collapsed ? 'w-[72px]' : 'w-[260px]',
          mobileOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        )}
      >
        <div
          className={cn(
            'h-16 flex items-center border-b border-green-900/50 shrink-0',
            collapsed ? 'justify-center px-2' : 'px-4 gap-3'
          )}
        >
          <div className="w-9 h-9 rounded-lg bg-gold-500 flex items-center justify-center shrink-0">
            <span className="text-green-950 font-bold text-sm">GFF</span>
          </div>
          {!collapsed && (
            <div className="flex items-center justify-between flex-1 min-w-0">
              <div className="min-w-0">
                <h1 className="text-white font-bold text-sm truncate leading-tight">
                  Golden Farmonia
                </h1>
                <p className="text-green-400 text-[10px] truncate leading-tight">
                  Fidex ERP
                </p>
              </div>
              <button
                onClick={toggle}
                className="text-green-400 hover:text-white transition-colors p-1 rounded-md hover:bg-green-800 shrink-0"
              >
                <ChevronLeft
                  size={18}
                  className={cn(
                    'transition-transform duration-200',
                    collapsed ? 'rotate-180' : ''
                  )}
                />
              </button>
            </div>
          )}
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
          {menuItems.map((item) => {
            if (item.children) {
              return (
                <MenuGroup
                  key={item.label}
                  item={item}
                  collapsed={collapsed}
                />
              );
            }

            const isActive =
              location.pathname === item.path ||
              (item.path === '/'
                ? location.pathname === '/'
                : location.pathname.startsWith(item.path!));

            if (collapsed) {
              return (
                <div key={item.path} className="group relative">
                  <Link
                    to={item.path!}
                    className={cn(
                      'w-[56px] h-11 mx-auto rounded-lg flex items-center justify-center transition-all duration-200',
                      isActive
                        ? 'bg-green-800 text-gold-400'
                        : 'text-green-200/80 hover:bg-green-900 hover:text-white'
                    )}
                  >
                    <item.icon size={20} />
                  </Link>
                  {isActive && (
                    <div className="absolute right-full mr-2 top-1/2 -translate-y-1/2 w-1 h-6 bg-gold-500 rounded-l" />
                  )}
                  <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-darkBg text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap transition-opacity z-50">
                    {item.label}
                  </div>
                </div>
              );
            }

            return (
              <Link
                key={item.path}
                to={item.path!}
                className={cn(
                  'h-11 px-3 rounded-lg flex items-center gap-3 transition-all duration-200',
                  isActive
                    ? 'bg-green-800 text-gold-400'
                    : 'text-green-200/80 hover:bg-green-900 hover:text-white'
                )}
              >
                <item.icon size={20} />
                <span className="text-sm font-medium">{item.label}</span>
                {isActive && (
                  <div className="mr-auto w-1 h-5 bg-gold-500 rounded-r" />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="shrink-0 border-t border-green-900/50 p-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gold-500/20 border border-gold-500/50 flex items-center justify-center shrink-0">
              <span className="text-gold-400 text-xs font-bold">م</span>
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <p className="text-white text-xs font-medium truncate">
                  محمد أحمد
                </p>
                <p className="text-green-400 text-[10px] truncate">
                  مدير النظام
                </p>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}
