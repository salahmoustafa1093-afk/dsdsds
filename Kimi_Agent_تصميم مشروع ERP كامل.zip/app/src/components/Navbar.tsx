import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Bell,
  Search,
  Sun,
  Moon,
  LogOut,
  Settings,
  User,
  ChevronDown,
  RefreshCw,
  Menu,
} from 'lucide-react';
import { useDarkMode } from '@/hooks/useDarkMode';
import { useSidebar } from '@/hooks/useSidebar';
import { cn } from '@/lib/utils';

export default function Navbar() {
  const { isDark, toggle: toggleDark } = useDarkMode();
  const { toggle: toggleSidebar } = useSidebar();
  const [userOpen, setUserOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const userRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (userRef.current && !userRef.current.contains(e.target as Node)) {
        setUserOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const notifications = [
    {
      id: 1,
      text: 'مخزون منخفض: علف دواجن ٢٥ كجم',
      time: 'منذ ١٥ دقيقة',
      type: 'danger' as const,
    },
    {
      id: 2,
      text: 'فاتورة جديدة: #INV-0015',
      time: 'منذ ٣٠ دقيقة',
      type: 'info' as const,
    },
    {
      id: 3,
      text: 'عميل جديد مسجل: مزارع السلام',
      time: 'منذ ساعة',
      type: 'success' as const,
    },
    {
      id: 4,
      text: 'تنبيه: استحقاق دفعة مورد',
      time: 'منذ ساعتين',
      type: 'warning' as const,
    },
  ];

  const notifColor = {
    danger: 'bg-red-500',
    warning: 'bg-amber-500',
    success: 'bg-green-500',
    info: 'bg-blue-500',
  };

  return (
    <header className="h-16 bg-white dark:bg-darkSurface border-b border-uiBorder dark:border-darkBorder shadow-topbar flex items-center px-4 lg:px-6 sticky top-0 z-30">
      {/* Right side: Menu toggle + Search */}
      <div className="flex items-center gap-3 flex-1">
        <button
          onClick={toggleSidebar}
          className="hidden lg:flex w-9 h-9 rounded-lg items-center justify-center text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors"
        >
          <Menu size={20} />
        </button>

        <div className="relative w-full max-w-[320px]">
          <Search
            size={16}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted"
          />
          <input
            type="text"
            placeholder="بحث سريع..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
          />
        </div>
      </div>

      {/* Left side: Actions */}
      <div className="flex items-center gap-1">
        {/* Dark mode toggle */}
        <button
          onClick={toggleDark}
          className="w-9 h-9 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard transition-colors"
          title={isDark ? 'الوضع الفاتح' : 'الوضع الداكن'}
        >
          {isDark ? <Sun size={18} /> : <Moon size={18} />}
        </button>

        {/* Refresh */}
        <button
          className="w-9 h-9 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard transition-colors"
          title="تحديث البيانات"
        >
          <RefreshCw size={18} />
        </button>

        {/* Notifications */}
        <div ref={notifRef} className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="relative w-9 h-9 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard transition-colors"
          >
            <Bell size={18} />
            <span className="absolute top-1 left-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
              4
            </span>
          </button>

          {notifOpen && (
            <div className="absolute left-0 top-full mt-2 w-80 bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal z-50 overflow-hidden">
              <div className="px-4 py-3 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="font-semibold text-sm text-textPrimary dark:text-darkText">
                  الإشعارات
                </h3>
                <span className="text-xs text-green-600 dark:text-green-400 cursor-pointer hover:underline">
                  تحديد الكل كمقروء
                </span>
              </div>
              <div className="max-h-72 overflow-y-auto">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    className="px-4 py-3 border-b border-uiBorder/50 dark:border-darkBorder/50 hover:bg-surface dark:hover:bg-darkCard transition-colors cursor-pointer"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={cn(
                          'w-2 h-2 rounded-full mt-1.5 shrink-0',
                          notifColor[n.type]
                        )}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-textPrimary dark:text-darkText leading-relaxed">
                          {n.text}
                        </p>
                        <p className="text-xs text-textMuted mt-1">{n.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="px-4 py-2 border-t border-uiBorder dark:border-darkBorder text-center">
                <Link
                  to="/notifications"
                  className="text-xs text-green-600 dark:text-green-400 hover:underline"
                >
                  عرض كل الإشعارات
                </Link>
              </div>
            </div>
          )}
        </div>

        {/* User dropdown */}
        <div ref={userRef} className="relative">
          <button
            onClick={() => setUserOpen(!userOpen)}
            className="flex items-center gap-2 mr-1 pr-2 pl-1 py-1 rounded-lg hover:bg-surface dark:hover:bg-darkCard transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-green-800 text-white flex items-center justify-center text-xs font-bold">
              م
            </div>
            <div className="hidden md:block text-right">
              <p className="text-sm font-medium text-textPrimary dark:text-darkText leading-tight">
                محمد أحمد
              </p>
              <p className="text-[10px] text-textMuted leading-tight">
                مدير النظام
              </p>
            </div>
            <ChevronDown
              size={14}
              className="text-textMuted hidden md:block"
            />
          </button>

          {userOpen && (
            <div className="absolute left-0 top-full mt-2 w-52 bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal z-50 overflow-hidden">
              <div className="px-4 py-3 border-b border-uiBorder dark:border-darkBorder">
                <p className="font-semibold text-sm text-textPrimary dark:text-darkText">
                  محمد أحمد
                </p>
                <p className="text-xs text-textMuted">admin@gff.com</p>
              </div>
              <div className="py-1">
                <Link
                  to="/profile"
                  className="flex items-center gap-2 px-4 py-2 text-sm text-textSecondary dark:text-darkTextSec hover:bg-surface dark:hover:bg-darkCard transition-colors"
                >
                  <User size={16} />
                  الملف الشخصي
                </Link>
                <Link
                  to="/settings"
                  className="flex items-center gap-2 px-4 py-2 text-sm text-textSecondary dark:text-darkTextSec hover:bg-surface dark:hover:bg-darkCard transition-colors"
                >
                  <Settings size={16} />
                  الإعدادات
                </Link>
                <div className="border-t border-uiBorder dark:border-darkBorder my-1" />
                <button className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors">
                  <LogOut size={16} />
                  تسجيل الخروج
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
