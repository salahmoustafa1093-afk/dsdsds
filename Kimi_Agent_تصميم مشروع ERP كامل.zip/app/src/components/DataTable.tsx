import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Search,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Eye,
  Edit3,
  Trash2,
  PackageX,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Column<T> {
  key: string;
  header: string;
  sortable?: boolean;
  width?: string;
  render?: (row: T) => React.ReactNode;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  searchable?: boolean;
  searchKeys?: string[];
  pageSize?: number;
  rowActions?: {
    onView?: (row: T) => void;
    onEdit?: (row: T) => void;
    onDelete?: (row: T) => void;
  };
  emptyMessage?: string;
  loading?: boolean;
  title?: string;
}

export default function DataTable<T extends Record<string, unknown>>({
  columns,
  data,
  searchable = true,
  searchKeys,
  pageSize = 10,
  rowActions,
  emptyMessage = 'لا توجد بيانات',
  loading = false,
  title,
}: DataTableProps<T>) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);

  const filteredData = useMemo(() => {
    let result = [...data];

    if (searchable && searchQuery) {
      const query = searchQuery.toLowerCase();
      const keys = searchKeys || columns.map((c) => c.key);
      result = result.filter((row) =>
        keys.some((key) => {
          const val = row[key];
          return val !== undefined && val !== null
            ? String(val).toLowerCase().includes(query)
            : false;
        })
      );
    }

    if (sortColumn) {
      result.sort((a, b) => {
        const aVal = a[sortColumn];
        const bVal = b[sortColumn];
        if (aVal === undefined || aVal === null) return 1;
        if (bVal === undefined || bVal === null) return -1;
        const comparison = String(aVal).localeCompare(String(bVal), 'ar');
        return sortDirection === 'asc' ? comparison : -comparison;
      });
    }

    return result;
  }, [data, searchQuery, sortColumn, sortDirection, searchable, searchKeys, columns]);

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const paginatedData = filteredData.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleSort = (key: string) => {
    if (sortColumn === key) {
      setSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortColumn(key);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (key: string) => {
    if (sortColumn !== key) return <ArrowUpDown size={14} />;
    return sortDirection === 'asc' ? (
      <ArrowUp size={14} />
    ) : (
      <ArrowDown size={14} />
    );
  };

  if (loading) {
    return (
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
        {title && (
          <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
            <div className="gff-skeleton h-5 w-32 rounded" />
          </div>
        )}
        <div className="p-5 space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="gff-skeleton h-12 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
      {/* Toolbar */}
      {(searchable || title) && (
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {title && (
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">
              {title}
            </h3>
          )}
          {searchable && (
            <div className="relative w-full sm:w-64">
              <Search
                size={16}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted"
              />
              <input
                type="text"
                placeholder="بحث..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
              />
            </div>
          )}
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={cn(
                    'px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec uppercase tracking-wider',
                    col.sortable && 'cursor-pointer hover:text-textPrimary transition-colors select-none'
                  )}
                  style={{ width: col.width }}
                  onClick={() => col.sortable && handleSort(col.key)}
                >
                  <div className="flex items-center gap-1">
                    {col.header}
                    {col.sortable && (
                      <span className="text-textMuted">
                        {getSortIcon(col.key)}
                      </span>
                    )}
                  </div>
                </th>
              ))}
              {rowActions && (
                <th className="px-4 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec">
                  إجراءات
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {paginatedData.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + (rowActions ? 1 : 0)}
                  className="px-4 py-16 text-center"
                >
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-16 h-16 rounded-full bg-surface dark:bg-darkCard flex items-center justify-center">
                      <PackageX
                        size={32}
                        className="text-textMuted"
                      />
                    </div>
                    <p className="text-textSecondary dark:text-darkTextSec text-sm">
                      {emptyMessage}
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              paginatedData.map((row, index) => (
                <motion.tr
                  key={String(row.id ?? index)}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.3,
                    delay: index * 0.05,
                    ease: [0, 0, 0.2, 1] as [number, number, number, number],
                  }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  {columns.map((col) => (
                    <td
                      key={col.key}
                      className="px-4 py-3 text-sm text-textPrimary dark:text-darkText"
                    >
                      {col.render
                        ? col.render(row)
                        : String(row[col.key] ?? '-')}
                    </td>
                  ))}
                  {rowActions && (
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        {rowActions.onView && (
                          <button
                            onClick={() => rowActions.onView?.(row)}
                            className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors"
                            title="عرض"
                          >
                            <Eye size={16} />
                          </button>
                        )}
                        {rowActions.onEdit && (
                          <button
                            onClick={() => rowActions.onEdit?.(row)}
                            className="w-8 h-8 rounded-lg flex items-center justify-center text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/30 transition-colors"
                            title="تعديل"
                          >
                            <Edit3 size={16} />
                          </button>
                        )}
                        {rowActions.onDelete && (
                          <button
                            onClick={() => rowActions.onDelete?.(row)}
                            className="w-8 h-8 rounded-lg flex items-center justify-center text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                            title="حذف"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  )}
                </motion.tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {filteredData.length > pageSize && (
        <div className="px-5 py-3 border-t border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-textMuted">
            عرض {(currentPage - 1) * pageSize + 1} إلى{' '}
            {Math.min(currentPage * pageSize, filteredData.length)} من{' '}
            {filteredData.length} عنصر
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard disabled:opacity-30 transition-colors"
            >
              <ChevronsRight size={16} />
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard disabled:opacity-30 transition-colors"
            >
              <ChevronRight size={16} />
            </button>
            <span className="text-xs text-textSecondary dark:text-darkTextSec px-2">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard disabled:opacity-30 transition-colors"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard disabled:opacity-30 transition-colors"
            >
              <ChevronsLeft size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
