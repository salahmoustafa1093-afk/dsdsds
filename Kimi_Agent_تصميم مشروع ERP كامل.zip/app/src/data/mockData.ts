// ─── KPI Data ───────────────────────────────────────────
export const kpiData = {
  dailySales: 345678,
  monthlyRevenue: 8945000,
  lowStock: 23,
  activeCustomers: 456,
  activeProductionLines: 8,
  pendingPayables: 2145000,
  branchCount: 4,
  dailyOrders: 47,
  monthlyProfit: 2150000,
};

// ─── Sales Chart Data (30 days) ─────────────────────────
export const salesChartData = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  actual: Math.floor(80000 + Math.random() * 120000),
  target: 100000,
}));

// ─── Low Stock Items ────────────────────────────────────
export const lowStockItems = [
  { name: 'علف دواجن ٢٥ كجم', warehouse: 'المستودع الرئيسي', current: 45, min: 100, percent: 45 },
  { name: 'ذرة صفراء مجروشة', warehouse: 'مستودع الإسكندرية', current: 200, min: 500, percent: 40 },
  { name: 'ردة خشنة', warehouse: 'المستودع الرئيسي', current: 80, min: 200, percent: 40 },
  { name: 'صويا مبشورة', warehouse: 'مستودع طنطا', current: 120, min: 300, percent: 40 },
  { name: 'أرز مصري', warehouse: 'المستودع الرئيسي', current: 50, min: 150, percent: 33 },
  { name: 'كسب قطن', warehouse: 'مستودع المنصورة', current: 30, min: 100, percent: 30 },
];

// ─── Sales Distribution ─────────────────────────────────
export const salesDistribution = [
  { name: 'القطاعي', value: 45, color: '#14a86a' },
  { name: 'الجملة', value: 30, color: '#daa520' },
  { name: 'الموزعين', value: 20, color: '#3b82f6' },
  { name: 'التصدير', value: 5, color: '#8b5cf6' },
];

// ─── Branch Performance ─────────────────────────────────
export const branchPerformance = [
  { name: 'القاهرة', sales: 3200000, target: 3000000 },
  { name: 'الإسكندرية', sales: 2100000, target: 2200000 },
  { name: 'طنطا', sales: 1800000, target: 1700000 },
  { name: 'المنصورة', sales: 1450000, target: 1500000 },
];

// ─── Recent Transactions ────────────────────────────────
export const recentTransactions = [
  {
    id: 1,
    type: 'فاتورة مبيعات',
    code: 'INV-2025-0015',
    date: '١٥/٠١/٢٠٢٥',
    party: 'مزارع النور',
    amount: '٤٥٬٠٠٠ ج.م',
    status: 'مدفوعة',
    statusType: 'success' as const,
  },
  {
    id: 2,
    type: 'أمر شراء',
    code: 'PO-2025-0042',
    date: '١٥/٠١/٢٠٢٥',
    party: 'شركة الأعلاف الكبرى',
    amount: '١٢٥٬٠٠٠ ج.م',
    status: 'قيد التنفيذ',
    statusType: 'warning' as const,
  },
  {
    id: 3,
    type: 'قيد محاسبي',
    code: 'JV-2025-0091',
    date: '١٤/٠١/٢٠٢٥',
    party: '—',
    amount: '٨٧٬٥٠٠ ج.م',
    status: 'معتمد',
    statusType: 'success' as const,
  },
  {
    id: 4,
    type: 'مرتجع مبيعات',
    code: 'SR-2025-0003',
    date: '١٤/٠١/٢٠٢٥',
    party: 'مؤسسة الريف',
    amount: '١٢٬٥٠٠ ج.م',
    status: 'قيد المراجعة',
    statusType: 'warning' as const,
  },
  {
    id: 5,
    type: 'حركة مخزون',
    code: 'ST-2025-0234',
    date: '١٣/٠١/٢٠٢٥',
    party: 'مستودع رئيسي',
    amount: '—',
    status: 'مكتملة',
    statusType: 'success' as const,
  },
  {
    id: 6,
    type: 'فاتورة مبيعات',
    code: 'INV-2025-0014',
    date: '١٣/٠١/٢٠٢٥',
    party: 'مزرعة الذهبية',
    amount: '٧٨٬٠٠٠ ج.م',
    status: 'مدفوعة',
    statusType: 'success' as const,
  },
];

// ─── Notifications ──────────────────────────────────────
export const notifications = [
  {
    id: 1,
    text: 'مخزون منخفض: علف دواجن ٢٥ كجم',
    time: 'منذ ١٥ دقيقة',
    type: 'danger' as const,
  },
  {
    id: 2,
    text: 'فاتورة جديدة: #INV-0015',
    time: 'منذ ٣٠ دقيقة',
    type: 'info' as const,
  },
  {
    id: 3,
    text: 'عميل جديد مسجل: مزارع السلام',
    time: 'منذ ساعة',
    type: 'success' as const,
  },
  {
    id: 4,
    text: 'تنبيه: استحقاق دفعة مورد',
    time: 'منذ ساعتين',
    type: 'warning' as const,
  },
  {
    id: 5,
    text: 'تم إكمال أمر الإنتاج #PR-0089',
    time: 'منذ ٣ ساعات',
    type: 'success' as const,
  },
];

// ─── Products ───────────────────────────────────────────
export const products = [
  { id: 1, name: 'علف دواجن بادئ ٢٥ كجم', category: 'أعلاف دواجن', price: 1850, stock: 450, minStock: 100, unit: 'شيكارة' },
  { id: 2, name: 'علف دواجن نامي ٢٥ كجم', category: 'أعلاف دواجن', price: 1720, stock: 320, minStock: 100, unit: 'شيكارة' },
  { id: 3, name: 'علف أبقار حلاب ٤٠ كجم', category: 'أعلاف مواشي', price: 2100, stock: 180, minStock: 50, unit: 'شيكارة' },
  { id: 4, name: 'ذرة صفراء مجروشة', category: 'مواد خام', price: 14500, stock: 2000, minStock: 500, unit: 'طن' },
  { id: 5, name: 'ردة خشنة', category: 'مواد خام', price: 8200, stock: 800, minStock: 200, unit: 'طن' },
  { id: 6, name: 'صويا مبشورة ٤٨%', category: 'مواد خام', price: 18500, stock: 1200, minStock: 300, unit: 'طن' },
  { id: 7, name: 'كسب قطن', category: 'مواد خام', price: 6200, stock: 350, minStock: 100, unit: 'طن' },
  { id: 8, name: 'فول سوداني مكشوف', category: 'بقوليات', price: 28500, stock: 85, minStock: 20, unit: 'طن' },
];

// ─── Customers ──────────────────────────────────────────
export const customers = [
  { id: 1, name: 'مزارع النور', type: 'مزرعة دواجن', phone: '٠١٠٠١٢٣٤٥٦٧٨', balance: 125000, status: 'نشط' },
  { id: 2, name: 'مؤسسة الريف الزراعية', type: 'موزع', phone: '٠١١١٢٢٣٣٤٤٥٥', balance: 450000, status: 'نشط' },
  { id: 3, name: 'مزرعة الذهبية', type: 'مزرعة مواشي', phone: '٠١٢٢٣٣٤٤٥٥٦٦', balance: 78000, status: 'نشط' },
  { id: 4, name: 'شركة الدلتا للأعلاف', type: 'تاجر جملة', phone: '٠١٥٥٤٤٣٣٢٢١١', balance: 920000, status: 'نشط' },
  { id: 5, name: 'مزرعة السلام', type: 'مزرعة دواجن', phone: '٠١٠٩٩٨٨٧٧٦٦', balance: 0, status: 'جديد' },
  { id: 6, name: 'مؤسسة النيل للتسويق', type: 'موزع', phone: '٠١١٥٥٦٦٧٧٨٨', balance: 340000, status: 'نشط' },
];

// ─── Suppliers ──────────────────────────────────────────
export const suppliers = [
  { id: 1, name: 'شركة الأعلاف الكبرى', type: 'مورد أعلاف', phone: '٠٢٣٤٥٦٧٨٩٠', balance: 1250000, rating: 4.5 },
  { id: 2, name: 'مطاحن مصر الوسطى', type: 'مورد مواد خام', phone: '٠٨٥٤٣٢١٠٩٨', balance: 890000, rating: 4.2 },
  { id: 3, name: 'شركة النيل للحبوب', type: 'مورد مواد خام', phone: '٠٩٨٧٦٥٤٣٢١', balance: 2100000, rating: 4.8 },
  { id: 4, name: 'مزارع الصعيد', type: 'مورد بقوليات', phone: '٠١٢٣٤٥٦٧٨٩', balance: 450000, rating: 3.9 },
];

// ─── Employees ──────────────────────────────────────────
export const employees = [
  { id: 1, name: 'محمد أحمد', role: 'مدير النظام', department: 'إدارة', phone: '٠١٠٠٠٠٠٠٠٠١', joinDate: '٠١/٠٣/٢٠٢٣' },
  { id: 2, name: 'أحمد علي', role: 'محاسب', department: 'الحسابات', phone: '٠١٠٠٠٠٠٠٠٠٢', joinDate: '١٥/٠٦/٢٠٢٣' },
  { id: 3, name: 'محمود سالم', role: 'مندوب مبيعات', department: 'المبيعات', phone: '٠١٠٠٠٠٠٠٠٠٣', joinDate: '٠١/٠٩/٢٠٢٣' },
  { id: 4, name: 'خالد عمر', role: 'مشرف إنتاج', department: 'الإنتاج', phone: '٠١٠٠٠٠٠٠٠٠٤', joinDate: '١٠/١١/٢٠٢٣' },
  { id: 5, name: 'يوسف إبراهيم', role: 'مشرف مخازن', department: 'المخازن', phone: '٠١٠٠٠٠٠٠٠٠٥', joinDate: '٠١/٠١/٢٠٢٤' },
];

// ─── Branches ───────────────────────────────────────────
export const branches = [
  { id: 1, name: 'الفرع الرئيسي - القاهرة', manager: 'محمد أحمد', employees: 25, sales: 3200000, status: 'نشط' },
  { id: 2, name: 'فرع الإسكندرية', manager: 'أحمد علي', employees: 18, sales: 2100000, status: 'نشط' },
  { id: 3, name: 'فرع طنطا', manager: 'محمود سالم', employees: 12, sales: 1800000, status: 'نشط' },
  { id: 4, name: 'فرع المنصورة', manager: 'خالد عمر', employees: 10, sales: 1450000, status: 'نشط' },
];

// ─── Helper: Format currency ────────────────────────────
export function formatCurrency(value: number): string {
  return value.toLocaleString('ar-EG') + ' ج.م';
}

// ─── Helper: Format number ──────────────────────────────
export function formatNumber(value: number): string {
  return value.toLocaleString('ar-EG');
}
