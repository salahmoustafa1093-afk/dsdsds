export const demandForecast = Array.from({ length: 90 }, (_, i) => ({
  day: i + 1,
  predicted: 180 + Math.sin(i / 10) * 40 + i * 0.5 + Math.random() * 20,
  lower: 160 + Math.sin(i / 10) * 35 + i * 0.4,
  upper: 200 + Math.sin(i / 10) * 45 + i * 0.6,
}));

export const commodityPrices = [
  { month: "يناير", corn: 5800, soy: 7200, wheat: 5200 },
  { month: "فبراير", corn: 5950, soy: 7350, wheat: 5350 },
  { month: "مارس", corn: 6100, soy: 7100, wheat: 5500 },
  { month: "أبريل", corn: 5900, soy: 6900, wheat: 5400 },
  { month: "مايو", corn: 6200, soy: 7500, wheat: 5600 },
  { month: "يونيو", corn: 6350, soy: 7800, wheat: 5800 },
  { month: "يوليو", corn: 6500, soy: 8000, wheat: 5900 },
];

export const branchForecast = [
  { branch: "القاهرة", forecast: 18.8, actual: 18.5 },
  { branch: "الإسكندرية", forecast: 12.5, actual: 12.2 },
  { branch: "المنصورة", forecast: 9.5, actual: 9.8 },
  { branch: "طنطا", forecast: 7.8, actual: 7.5 },
  { branch: "الزقازيق", forecast: 6.0, actual: 6.3 },
  { branch: "بنها", forecast: 5.3, actual: 5.1 },
];

export const churnRiskData = [
  { name: "شركة النيل", risk: 0.15, value: 4200, segment: "منخفض" },
  { name: "الصفوة", risk: 0.35, value: 3100, segment: "متوسط" },
  { name: "الخليج", risk: 0.72, value: 2900, segment: "عالي" },
  { name: "الهرم", risk: 0.22, value: 3800, segment: "منخفض" },
  { name: "مصر للصناعات", risk: 0.55, value: 3500, segment: "عالي" },
  { name: "سوبر وان", risk: 0.42, value: 2700, segment: "متوسط" },
  { name: "كارفور", risk: 0.08, value: 2500, segment: "منخفض" },
  { name: "بن داود", risk: 0.63, value: 2100, segment: "عالي" },
];

export const creditRisk = [
  { customer: "شركة النيل", limit: 5000, used: 3200, score: 85, status: "جيد" },
  { customer: "الصفوة", limit: 3000, used: 2800, score: 62, status: "متوسط" },
  { customer: "الخليج", limit: 4000, used: 3900, score: 45, status: "ضعيف" },
  { customer: "الهرم", limit: 2500, used: 1200, score: 91, status: "ممتاز" },
  { customer: "مصر للصناعات", limit: 6000, used: 5100, score: 58, status: "متوسط" },
  { customer: "كارفور", limit: 8000, used: 2100, score: 96, status: "ممتاز" },
];

export const abcAnalysis = [
  { name: "A - دواجن نخالة", value: 45 },
  { name: "B - بياض أعلاف", value: 30 },
  { name: "C - ماشية أعلاف", value: 15 },
  { name: "C - مستلزمات", value: 10 },
];

export const seasonalHeatmap = [
  { product: "أعلاف دواجن", jan: 85, feb: 80, mar: 78, apr: 75, may: 82, jun: 90, jul: 95, aug: 88, sep: 85, oct: 92, nov: 96, dec: 98 },
  { product: "أعلاف ماشية", jan: 70, feb: 72, mar: 75, apr: 80, may: 85, jun: 82, jul: 78, aug: 75, sep: 80, oct: 85, nov: 88, dec: 82 },
  { product: "كتاكيت", jan: 90, feb: 85, mar: 88, apr: 92, may: 95, jun: 90, jul: 85, aug: 82, sep: 88, oct: 95, nov: 98, dec: 92 },
  { product: "بيض مائدة", jan: 75, feb: 78, mar: 82, apr: 88, may: 90, jun: 85, jul: 80, aug: 82, sep: 88, oct: 92, nov: 90, dec: 85 },
];

export const reorderSuggestions = [
  { item: "ذرة صفراء", current: 120, suggested: 450, reorderPoint: 200, supplier: "شركة النيل للحبوب", leadTime: "5 أيام" },
  { item: "فول صويا", current: 85, suggested: 320, reorderPoint: 150, supplier: "الدولية للبذور", leadTime: "7 أيام" },
  { item: "نخالة قمح", current: 200, suggested: 500, reorderPoint: 250, supplier: "مطاحن الدلتا", leadTime: "3 أيام" },
  { item: "رجيع أرز", current: 45, suggested: 180, reorderPoint: 80, supplier: "شعير النيل", leadTime: "4 أيام" },
];

export const pricingOptimization = [
  { product: "علف دواجن 25كجم", currentPrice: 420, suggested: 445, elasticity: -1.2, confidence: 88 },
  { product: "علف بياض 25كجم", currentPrice: 480, suggested: 495, elasticity: -0.8, confidence: 82 },
  { product: "علف ماشية 50كجم", currentPrice: 650, suggested: 625, elasticity: -2.1, confidence: 75 },
];

export const upsellOpportunities = [
  { customer: "شركة النيل", current: "دواجن أعلاف", opportunity: "مستلزمات + كتاكيت", value: 450 },
  { customer: "الصفوة", current: "بياض أعلاف", opportunity: "نخالة إضافية", value: 280 },
  { customer: "كارفور", current: "دواجن أعلاف", opportunity: "بيض مائدة", value: 620 },
  { customer: "الهرم", current: "ماشية أعلاف", opportunity: "دواجن أعلاف", value: 350 },
];

export const expansionRecommendations = [
  { city: "أسيوط", marketSize: 12.5, competition: "متوسط", estimatedROI: 28, breakeven: "14 شهر" },
  { city: "الأقصر", marketSize: 6.8, competition: "منخفض", estimatedROI: 22, breakeven: "18 شهر" },
  { city: "بني سويف", marketSize: 9.2, competition: "عالي", estimatedROI: 19, breakeven: "20 شهر" },
];

export const modelMetrics = [
  { model: "تنبؤ المبيعات", mae: 2.3, rmse: 3.1, accuracy: 94.2 },
  { model: "تنبؤ الطلب", mae: 3.8, rmse: 4.9, accuracy: 89.7 },
  { model: "مخاطر الائتمان", mae: 5.2, rmse: 6.8, accuracy: 87.3 },
  { model: "نفوق الدواجن", mae: 0.4, rmse: 0.6, accuracy: 92.1 },
  { model: "أسعار السلع", mae: 180, rmse: 250, accuracy: 85.6 },
];
