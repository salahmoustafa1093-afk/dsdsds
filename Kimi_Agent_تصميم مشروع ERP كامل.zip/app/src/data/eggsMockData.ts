export const eggsInventory = [
  { grade: "A (Extra Large)", count: 125000, trays: 4167, cartons: 521, price: 145, location: "مخزن القاهرة", expiry: "2024-07-15" },
  { grade: "B (Large)", count: 98000, trays: 3267, cartons: 408, price: 135, location: "مخزن القاهرة", expiry: "2024-07-14" },
  { grade: "C (Medium)", count: 76000, trays: 2533, cartons: 317, price: 125, location: "مخزن الإسكندرية", expiry: "2024-07-13" },
  { grade: "D (Small)", count: 45000, trays: 1500, cartons: 188, price: 110, location: "مخزن المنصورة", expiry: "2024-07-12" },
];

export const eggsProduction = [
  { date: "2024-06-15", farm: "مزرعة الدلتا", gradeA: 42000, gradeB: 35000, gradeC: 18000, gradeD: 8000, broken: 450 },
  { date: "2024-06-14", farm: "مزرعة الصعيد", gradeA: 38000, gradeB: 32000, gradeC: 21000, gradeD: 9500, broken: 520 },
  { date: "2024-06-13", farm: "مزرعة البركة", gradeA: 45000, gradeB: 28000, gradeC: 15000, gradeD: 7000, broken: 380 },
  { date: "2024-06-12", farm: "مزرعة الدلتا", gradeA: 41000, gradeB: 36000, gradeC: 19500, gradeD: 8200, broken: 410 },
  { date: "2024-06-11", farm: "مجموعة الصفوة", gradeA: 39000, gradeB: 31000, gradeC: 16500, gradeD: 9000, broken: 480 },
];

export const distributionOrders = [
  { id: "DIST-001", customer: "هايبر وان", grade: "A", quantity: 500, price: 145, total: 72500, status: "تم التوصيل", date: "2024-06-15" },
  { id: "DIST-002", customer: "كارفور مصر", grade: "A+B", quantity: 800, price: 140, total: 112000, status: "قيد التوصيل", date: "2024-06-15" },
  { id: "DIST-003", customer: "شركة النيل", grade: "B", quantity: 300, price: 135, total: 40500, status: "تم التحضير", date: "2024-06-16" },
  { id: "DIST-004", customer: "بن داود", grade: "A", quantity: 450, price: 145, total: 65250, status: "مجدول", date: "2024-06-17" },
  { id: "DIST-005", customer: "الصفوة", grade: "C+D", quantity: 600, price: 115, total: 69000, status: "تم التوصيل", date: "2024-06-14" },
];

export const eggsPricing = [
  { grade: "A", currentPrice: 145, cost: 95, margin: 34.5, lastWeek: 142, lastMonth: 138, trend: "up" },
  { grade: "B", currentPrice: 135, cost: 88, margin: 34.8, lastWeek: 133, lastMonth: 130, trend: "up" },
  { grade: "C", currentPrice: 125, cost: 82, margin: 34.4, lastWeek: 126, lastMonth: 125, trend: "stable" },
  { grade: "D", currentPrice: 110, cost: 75, margin: 31.8, lastWeek: 112, lastMonth: 115, trend: "down" },
];

export const priceHistory = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  gradeA: 138 + Math.sin(i / 5) * 5 + Math.random() * 3,
  gradeB: 128 + Math.sin(i / 5) * 5 + Math.random() * 3,
  gradeC: 120 + Math.sin(i / 5) * 4 + Math.random() * 2,
}));
