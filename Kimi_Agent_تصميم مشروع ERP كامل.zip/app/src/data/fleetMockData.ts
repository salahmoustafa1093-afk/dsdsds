export const vehicles = [
  { id: 1, plate: "م ع أ 4521", type: "ثلاجة", model: " Mercedes Sprinter 2021", status: "active", mileage: 125400, driver: "محمد علي", lastService: "2024-05-15", nextService: "2024-08-15" },
  { id: 2, plate: "م ع أ 4522", type: "فان", model: "Toyota Hiace 2022", status: "active", mileage: 87400, driver: "أحمد سمير", lastService: "2024-04-20", nextService: "2024-07-20" },
  { id: 3, plate: "م ع أ 4523", type: "شاحنة", model: "Isuzu NPR 2020", status: "maintenance", mileage: 198200, driver: "خالد محمود", lastService: "2024-06-01", nextService: "2024-06-30" },
  { id: 4, plate: "م ع أ 4524", type: "ثلاجة", model: "Mercedes Sprinter 2022", status: "active", mileage: 67300, driver: "سيد حسن", lastService: "2024-05-10", nextService: "2024-08-10" },
  { id: 5, plate: "م ع أ 4525", type: "فان", model: "Hyundai H1 2021", status: "active", mileage: 92300, driver: "عبدالله فؤاد", lastService: "2024-03-15", nextService: "2024-06-15" },
  { id: 6, plate: "م ع أ 4526", type: "شاحنة", model: "Isuzu FVR 2019", status: "active", mileage: 234500, driver: "إبراهيم نصر", lastService: "2024-06-10", nextService: "2024-09-10" },
  { id: 7, plate: "م ع أ 4527", type: "ثلاجة", model: "Volkswagen Crafter 2022", status: "inactive", mileage: 45600, driver: "غير معين", lastService: "2024-02-20", nextService: "2024-05-20" },
  { id: 8, plate: "م ع أ 4528", type: "فان", model: "Toyota Hiace 2020", status: "active", mileage: 134200, driver: "طارق محيي", lastService: "2024-05-25", nextService: "2024-08-25" },
  { id: 9, plate: "م ع أ 4529", type: "شاحنة", model: "Isuzu NPR 2021", status: "active", mileage: 87600, driver: "حسن محمد", lastService: "2024-04-10", nextService: "2024-07-10" },
  { id: 10, plate: "م ع أ 4530", type: "ثلاجة", model: "Mercedes Sprinter 2020", status: "active", mileage: 156700, driver: "عادل رشاد", lastService: "2024-06-05", nextService: "2024-09-05" },
  { id: 11, plate: "م ع أ 4531", type: "فان", model: "Hyundai H350 2022", status: "active", mileage: 34200, driver: "ياسر عاطف", lastService: "2024-05-01", nextService: "2024-08-01" },
  { id: 12, plate: "م ع أ 4532", type: "شاحنة", model: "Isuzu FVR 2020", status: "maintenance", mileage: 178900, driver: "كريم فathy", lastService: "2024-06-12", nextService: "2024-06-26" },
  { id: 13, plate: "م ع أ 4533", type: "ثلاجة", model: "Volkswagen Crafter 2021", status: "active", mileage: 78900, driver: "وليد صلاح", lastService: "2024-04-25", nextService: "2024-07-25" },
  { id: 14, plate: "م ع أ 4534", type: "فان", model: "Toyota Hiace 2023", status: "active", mileage: 23400, driver: "مصطفى جمال", lastService: "2024-06-01", nextService: "2024-09-01" },
  { id: 15, plate: "م ع أ 4535", type: "شاحنة", model: "Isuzu NPR 2022", status: "active", mileage: 56700, driver: "عمر عبدالعزيز", lastService: "2024-05-18", nextService: "2024-08-18" },
];

export const drivers = [
  { id: 1, name: "محمد علي", phone: "0100-1234567", license: "رخصة درجة أولى", rating: 4.8, experience: "8 سنوات", status: "نشط", violations: 0 },
  { id: 2, name: "أحمد سمير", phone: "0101-2345678", license: "رخصة درجة ثانية", rating: 4.5, experience: "5 سنوات", status: "نشط", violations: 1 },
  { id: 3, name: "خالد محمود", phone: "0102-3456789", license: "رخصة درجة أولى", rating: 4.9, experience: "12 سنة", status: "إجازة", violations: 0 },
  { id: 4, name: "سيد حسن", phone: "0103-4567890", license: "رخصة درجة ثانية", rating: 4.3, experience: "6 سنوات", status: "نشط", violations: 2 },
  { id: 5, name: "عبدالله فؤاد", phone: "0104-5678901", license: "رخصة درجة أولى", rating: 4.7, experience: "9 سنوات", status: "نشط", violations: 0 },
  { id: 6, name: "إبراهيم نصر", phone: "0105-6789012", license: "رخصة درجة أولى", rating: 4.6, experience: "10 سنوات", status: "نشط", violations: 1 },
  { id: 7, name: "طارق محيي", phone: "0106-7890123", license: "رخصة درجة ثالثة", rating: 4.1, experience: "3 سنوات", status: "نشط", violations: 3 },
  { id: 8, name: "حسن محمد", phone: "0107-8901234", license: "رخصة درجة أولى", rating: 4.8, experience: "7 سنوات", status: "إيقاف", violations: 2 },
  { id: 9, name: "عادل رشاد", phone: "0108-9012345", license: "رخصة درجة ثانية", rating: 4.4, experience: "4 سنوات", status: "نشط", violations: 1 },
  { id: 10, name: "ياسر عاطف", phone: "0109-0123456", license: "رخصة درجة أولى", rating: 4.9, experience: "11 سنة", status: "نشط", violations: 0 },
  { id: 11, name: "وليد صلاح", phone: "0110-1234567", license: "رخصة درجة ثانية", rating: 4.2, experience: "5 سنوات", status: "نشط", violations: 1 },
  { id: 12, name: "مصطفى جمال", phone: "0111-2345678", license: "رخصة درجة ثالثة", rating: 4.0, experience: "2 سنة", status: "نشط", violations: 2 },
  { id: 13, name: "عمر عبدالعزيز", phone: "0112-3456789", license: "رخصة درجة أولى", rating: 4.7, experience: "8 سنوات", status: "نشط", violations: 0 },
];

export const fuelLogs = [
  { id: 1, vehicleId: 1, date: "2024-06-15", liters: 42, cost: 966, km: 480, efficiency: 11.4 },
  { id: 2, vehicleId: 2, date: "2024-06-15", liters: 38, cost: 874, km: 420, efficiency: 11.1 },
  { id: 3, vehicleId: 4, date: "2024-06-15", liters: 45, cost: 1035, km: 510, efficiency: 11.3 },
  { id: 4, vehicleId: 6, date: "2024-06-14", liters: 62, cost: 1426, km: 580, efficiency: 9.4 },
  { id: 5, vehicleId: 8, date: "2024-06-14", liters: 35, cost: 805, km: 390, efficiency: 11.1 },
  { id: 6, vehicleId: 9, date: "2024-06-14", liters: 58, cost: 1334, km: 550, efficiency: 9.5 },
  { id: 7, vehicleId: 10, date: "2024-06-13", liters: 48, cost: 1104, km: 500, efficiency: 10.4 },
  { id: 8, vehicleId: 11, date: "2024-06-13", liters: 32, cost: 736, km: 380, efficiency: 11.9 },
  { id: 9, vehicleId: 13, date: "2024-06-12", liters: 44, cost: 1012, km: 495, efficiency: 11.3 },
  { id: 10, vehicleId: 14, date: "2024-06-12", liters: 28, cost: 644, km: 350, efficiency: 12.5 },
];

export const maintenanceRecords = [
  { id: 1, vehicleId: 3, type: "صيانة دورية", date: "2024-06-01", cost: 3500, status: "قيد التنفيذ", nextDue: "2024-06-30", daysLeft: 5 },
  { id: 2, vehicleId: 12, type: "إصلاح فرامل", date: "2024-06-12", cost: 2200, status: "مجدولة", nextDue: "2024-06-26", daysLeft: 1 },
  { id: 3, vehicleId: 7, type: "تغيير زيت", date: "2024-06-05", cost: 800, status: "متأخرة", nextDue: "2024-05-20", daysLeft: -20 },
  { id: 4, vehicleId: 1, type: "صيانة دورية", date: "2024-05-15", cost: 2800, status: "مكتملة", nextDue: "2024-08-15", daysLeft: 80 },
  { id: 5, vehicleId: 6, type: "تغيير إطارات", date: "2024-06-10", cost: 8500, status: "مكتملة", nextDue: "2024-09-10", daysLeft: 75 },
  { id: 6, vehicleId: 4, type: "فحص تكييف", date: "2024-06-08", cost: 1200, status: "مكتملة", nextDue: "2024-08-10", daysLeft: 70 },
];

export const trips = [
  { id: 1, vehicle: "م ع أ 4521", driver: "محمد علي", route: "القاهرة → الإسكندرية", status: "قيد التنفيذ", startTime: "06:00", eta: "09:30", deliveries: 8 },
  { id: 2, vehicle: "م ع أ 4522", driver: "أحمد سمير", route: "القاهرة → المنصورة", status: "مكتملة", startTime: "05:30", eta: "08:00", deliveries: 6 },
  { id: 3, vehicle: "م ع أ 4524", driver: "سيد حسن", route: "القاهرة → طنطا", status: "قيد التنفيذ", startTime: "07:00", eta: "10:00", deliveries: 5 },
  { id: 4, vehicle: "م ع أ 4525", driver: "عبدالله فؤاد", route: "القاهرة → الزقازيق", status: "مجدولة", startTime: "09:00", eta: "11:30", deliveries: 4 },
  { id: 5, vehicle: "م ع أ 4526", driver: "إبراهيم نصر", route: "القاهرة → بنها", status: "مكتملة", startTime: "04:30", eta: "06:00", deliveries: 10 },
  { id: 6, vehicle: "م ع أ 4528", driver: "طارق محيي", route: "القاهرة → كفر الشيخ", status: "قيد التنفيذ", startTime: "06:30", eta: "10:30", deliveries: 7 },
  { id: 7, vehicle: "م ع أ 4529", driver: "حسن محمد", route: "القاهرة → السويس", status: "مجدولة", startTime: "10:00", eta: "12:00", deliveries: 9 },
  { id: 8, vehicle: "م ع أ 4530", driver: "عادل رشاد", route: "القاهرة → بورسعيد", status: "قيد التنفيذ", startTime: "05:00", eta: "08:30", deliveries: 6 },
];
