export const poultrySuppliers = [
  { id: 1, name: "مزرعة الدلتا للدواجن", location: "المنصورة", rating: 4.8, lastDelivery: "2024-06-14", debt: 125000, status: "نشط" },
  { id: 2, name: "شركة النيل للكتاكيت", location: "القاهرة", rating: 4.5, lastDelivery: "2024-06-15", debt: 89000, status: "نشط" },
  { id: 3, name: "مزرعة الصعيد", location: "أسيوط", rating: 4.2, lastDelivery: "2024-06-13", debt: 156000, status: "معلق" },
  { id: 4, name: "مجموعة الصفوة", location: "طنطا", rating: 4.9, lastDelivery: "2024-06-15", debt: 45000, status: "نشط" },
  { id: 5, name: "مزرعة البركة", location: "كفر الشيخ", rating: 4.0, lastDelivery: "2024-06-12", debt: 210000, status: "نشط" },
];

export const breeds = [
  { id: 1, name: "Cobb 500", type: "لاحم", origin: "أمريكي", ageDays: 35, avgWeight: 2.4, fcr: 1.65, mortality: 3.2, population: 45000, supplier: "Cobb" },
  { id: 2, name: "Ross 308", type: "لاحم", origin: "بريطاني", ageDays: 33, avgWeight: 2.2, fcr: 1.62, mortality: 2.8, population: 38000, supplier: "Aviagen" },
  { id: 3, name: "Ross 708", type: "لاحم", origin: "بريطاني", ageDays: 40, avgWeight: 2.8, fcr: 1.72, mortality: 3.5, population: 22000, supplier: "Aviagen" },
  { id: 4, name: "Hy-Line Brown", type: "بياض", origin: "أمريكي", ageDays: 180, avgWeight: 1.8, fcr: 2.1, mortality: 5.2, population: 32000, supplier: "Hy-Line" },
  { id: 5, name: "Lohmann Brown", type: "بياض", origin: "ألماني", ageDays: 175, avgWeight: 1.75, fcr: 2.05, mortality: 4.8, population: 28000, supplier: "Lohmann" },
];

export const reservations = [
  { id: "RES-001", customer: "شركة النيل", breed: "Cobb 500", quantity: 10000, deliveryDate: "2024-07-01", status: "مؤكد", deposit: 50000, unitPrice: 12 },
  { id: "RES-002", customer: "هايبر الهرم", breed: "Ross 308", quantity: 5000, deliveryDate: "2024-07-05", status: "قيد التأكيد", deposit: 25000, unitPrice: 12.5 },
  { id: "RES-003", customer: "الصفوة", breed: "Hy-Line Brown", quantity: 8000, deliveryDate: "2024-07-10", status: "مؤكد", deposit: 40000, unitPrice: 18 },
  { id: "RES-004", customer: "شركة الخليج", breed: "Cobb 500", quantity: 15000, deliveryDate: "2024-07-15", status: "قيد المراجعة", deposit: 0, unitPrice: 11.8 },
  { id: "RES-005", customer: "كارفور", breed: "Ross 308", quantity: 12000, deliveryDate: "2024-07-20", status: "مؤكد", deposit: 60000, unitPrice: 12 },
];

export const mortalityRecords = [
  { id: 1, farm: "مزرعة الدلتا", breed: "Cobb 500", batch: "B-2401", date: "2024-06-15", count: 24, rate: 2.1, cause: "حرارة مرتفعة", action: "تعديل تبريد" },
  { id: 2, farm: "مزرعة الصعيد", breed: "Ross 308", batch: "B-2402", date: "2024-06-14", count: 45, rate: 3.8, cause: "عدوى تنفسية", action: "علاج بالمضادات" },
  { id: 3, farm: "مزرعة البركة", breed: "Cobb 500", batch: "B-2403", date: "2024-06-13", count: 18, rate: 1.5, cause: "سقوط من الأقفاص", action: "إصلاح أقفاص" },
  { id: 4, farm: "مزرعة الدلتا", breed: "Hy-Line Brown", batch: "B-2404", date: "2024-06-12", count: 32, rate: 2.4, cause: "إجهاد حراري", action: "تحسين تهوية" },
  { id: 5, farm: "مجموعة الصفوة", breed: "Ross 308", batch: "B-2405", date: "2024-06-11", count: 12, rate: 1.8, cause: "طبيعي", action: "مراقبة" },
];

export const vaccinations = [
  { id: 1, farm: "مزرعة الدلتا", batch: "B-2401", vaccine: "Gumboro", scheduledDate: "2024-06-16", status: "مجدول", type: "شرب" },
  { id: 2, farm: "مزرعة الصعيد", batch: "B-2402", vaccine: "Newcastle", scheduledDate: "2024-06-15", status: "اليوم", type: "رذاذ" },
  { id: 3, farm: "مزرعة البركة", batch: "B-2403", vaccine: "IBD", scheduledDate: "2024-06-14", status: "مكتمل", type: "حقن" },
  { id: 4, farm: "مجموعة الصفوة", batch: "B-2405", vaccine: "AI H5N1", scheduledDate: "2024-06-17", status: "مجدول", type: "حقن" },
  { id: 5, farm: "مزرعة الدلتا", batch: "B-2404", vaccine: "Newcastle", scheduledDate: "2024-06-18", status: "مجدول", type: "شرب" },
];
