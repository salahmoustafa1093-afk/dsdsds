export const b2bCustomer = {
  id: "C-4521",
  name: "شركة النيل للتجارة",
  contact: "أحمد محمود",
  phone: "0100-9876543",
  email: "ahmed@niletrading.com",
  address: "15 شارع النيل، مدينة نصر، القاهرة",
  creditLimit: 500000,
  creditUsed: 320000,
  creditAvailable: 180000,
  paymentTerms: "Net 30",
  discountTier: "ذهبي",
  memberSince: "2019-03-15",
};

export const b2bOrders = [
  { id: "BO-4521", date: "2024-06-15", items: 12, total: 145000, status: "قيد التنفيذ", delivery: "2024-06-18" },
  { id: "BO-4518", date: "2024-06-12", items: 8, total: 89000, status: "تم التسليم", delivery: "2024-06-15" },
  { id: "BO-4515", date: "2024-06-10", items: 15, total: 210000, status: "تم التسليم", delivery: "2024-06-13" },
  { id: "BO-4510", date: "2024-06-05", items: 6, total: 72000, status: "ملغي", delivery: "---" },
  { id: "BO-4505", date: "2024-06-01", items: 20, total: 285000, status: "تم التسليم", delivery: "2024-06-04" },
];

export const b2bInvoices = [
  { id: "INV-4521", date: "2024-06-15", amount: 145000, paid: 0, due: 145000, dueDate: "2024-07-15", status: "مستحق" },
  { id: "INV-4518", date: "2024-06-12", amount: 89000, paid: 89000, due: 0, dueDate: "2024-07-12", status: "مدفوع" },
  { id: "INV-4515", date: "2024-06-10", amount: 210000, paid: 150000, due: 60000, dueDate: "2024-07-10", status: "جزئي" },
  { id: "INV-4510", date: "2024-06-05", amount: 72000, paid: 0, due: 0, dueDate: "2024-07-05", status: "ملغي" },
  { id: "INV-4505", date: "2024-06-01", amount: 285000, paid: 285000, due: 0, dueDate: "2024-07-01", status: "مدفوع" },
  { id: "INV-4500", date: "2024-05-28", amount: 175000, paid: 0, due: 175000, dueDate: "2024-06-28", status: "متأخر" },
];

export const b2bStatements = [
  { id: "ST-2024-06", period: "يونيو 2024", opening: 320000, debit: 711000, credit: 524000, closing: 507000, transactions: 18 },
  { id: "ST-2024-05", period: "مايو 2024", opening: 145000, debit: 680000, credit: 505000, closing: 320000, transactions: 22 },
  { id: "ST-2024-04", period: "أبريل 2024", opening: 80000, debit: 520000, credit: 455000, closing: 145000, transactions: 15 },
  { id: "ST-2024-03", period: "مارس 2024", opening: 120000, debit: 610000, credit: 650000, closing: 80000, transactions: 20 },
];

export const b2bPayments = [
  { id: "PMT-001", date: "2024-06-12", amount: 89000, method: "تحويل بنكي", reference: "TRX-789456", invoices: ["INV-4518"] },
  { id: "PMT-002", date: "2024-06-10", amount: 150000, method: "شيك", reference: "CHQ-123456", invoices: ["INV-4515"] },
  { id: "PMT-003", date: "2024-06-01", amount: 285000, method: "تحويل بنكي", reference: "TRX-789123", invoices: ["INV-4505"] },
  { id: "PMT-004", date: "2024-05-25", amount: 175000, method: "كاش", reference: "CASH-001", invoices: ["INV-4495"] },
];

export const b2bPriceList = [
  { product: "علف دواجن نخالة 25كجم", unitPrice: 420, volume1: 400, volume2: 385, volume3: 370, minQty: 50 },
  { product: "علف بياض 25كجم", unitPrice: 480, volume1: 460, volume2: 445, volume3: 430, minQty: 50 },
  { product: "علف ماشية 50كجم", unitPrice: 650, volume1: 620, volume2: 600, volume3: 580, minQty: 25 },
  { product: "كتكوت Cobb 500", unitPrice: 12, volume1: 11.5, volume2: 11, volume3: 10.5, minQty: 1000 },
  { product: "كتكوت Ross 308", unitPrice: 12.5, volume1: 12, volume2: 11.5, volume3: 11, minQty: 1000 },
  { product: "بيض مائدة درجة A", unitPrice: 145, volume1: 140, volume2: 135, volume3: 130, minQty: 100 },
  { product: "بيض مائدة درجة B", unitPrice: 135, volume1: 130, volume2: 125, volume3: 120, minQty: 100 },
];

export const b2bTickets = [
  { id: "TK-001", subject: "طلب تعديل سعر", status: "مفتوح", priority: "عالية", created: "2024-06-15", lastUpdate: "2024-06-15", assignee: "محمد علي" },
  { id: "TK-002", subject: "تأخر في تسليم", status: "قيد المعالجة", priority: "عالية", created: "2024-06-14", lastUpdate: "2024-06-15", assignee: "أحمد سمير" },
  { id: "TK-003", subject: "استفسار عن فاتورة", status: "مغلق", priority: "منخفضة", created: "2024-06-10", lastUpdate: "2024-06-12", assignee: "خالد محمود" },
  { id: "TK-004", subject: "طلب زيادة حد الائتمان", status: "قيد المراجعة", priority: "متوسطة", created: "2024-06-13", lastUpdate: "2024-06-15", assignee: "سيد حسن" },
  { id: "TK-005", subject: "شكوى جودة منتج", status: "مفتوح", priority: "عالية", created: "2024-06-15", lastUpdate: "2024-06-15", assignee: "عبدالله فؤاد" },
];
