export const deliveryOrders = [
  { id: "ORD-2841", customer: "شركة النيل", branch: "القاهرة", items: 12, weight: "2.4 طن", driver: "محمد علي", vehicle: "م ع أ 4521", status: "قيد التوصيل", time: "08:30", zone: "مدينة نصر" },
  { id: "ORD-2842", customer: "هايبر الهرم", branch: "الجيزة", items: 8, weight: "1.2 طن", driver: "أحمد سمير", vehicle: "م ع أ 4522", status: "تم التسليم", time: "07:15", zone: "الهرم" },
  { id: "ORD-2843", customer: "مجموعة الصفوة", branch: "الإسكندرية", items: 20, weight: "4.5 طن", driver: "سيد حسن", vehicle: "م ع أ 4524", status: "قيد التحضير", time: "09:00", zone: "سموحة" },
  { id: "ORD-2844", customer: "شركة الخليج", branch: "المنصورة", items: 6, weight: "1.1 طن", driver: "عبدالله فؤاد", vehicle: "م ع أ 4525", status: "معلق", time: "10:30", zone: "جمال عبد الناصر" },
  { id: "ORD-2845", customer: "سوبر وان", branch: "طنطا", items: 15, weight: "3.0 طن", driver: "إبراهيم نصر", vehicle: "م ع أ 4526", status: "تم التحميل", time: "08:00", zone: "شارع الجيش" },
  { id: "ORD-2846", customer: "كارفور مصر", branch: "القاهرة", items: 25, weight: "5.2 طن", driver: "طارق محيي", vehicle: "م ع أ 4528", status: "قيد التوصيل", time: "06:30", zone: "التجمع" },
  { id: "ORD-2847", customer: "شركة النيل", branch: "الزقازيق", items: 10, weight: "1.8 طن", driver: "حسن محمد", vehicle: "م ع أ 4529", status: "متأخر", time: "07:00", zone: "وسط البلد" },
  { id: "ORD-2848", customer: "بن داود", branch: "القاهرة", items: 18, weight: "3.6 طن", driver: "عادل رشاد", vehicle: "م ع أ 4530", status: "قيد التحضير", time: "09:30", zone: "مصر الجديدة" },
  { id: "ORD-2849", customer: "مؤسسة مصر", branch: "بنها", items: 7, weight: "1.4 طن", driver: "ياسر عاطف", vehicle: "م ع أ 4531", status: "تم التسليم", time: "06:00", zone: "شبرا" },
  { id: "ORD-2850", customer: "LuLu هايبر", branch: "الإسكندرية", items: 22, weight: "4.8 طن", driver: "وليد صلاح", vehicle: "م ع أ 4533", status: "قيد التوصيل", time: "07:45", zone: "المنتزه" },
  { id: "ORD-2851", customer: "الدولية", branch: "كفر الشيخ", items: 5, weight: "0.9 طن", driver: "مصطفى جمال", vehicle: "م ع أ 4534", status: "معلق", time: "11:00", zone: "الحامول" },
  { id: "ORD-2852", customer: "شركة النيل", branch: "السويس", items: 14, weight: "2.8 طن", driver: "عمر عبدالعزيز", vehicle: "م ع أ 4535", status: "تم التحميل", time: "08:15", zone: "الأربعين" },
  { id: "ORD-2853", customer: "هايبر وان", branch: "دمياط", items: 9, weight: "1.7 طن", driver: "محمد علي", vehicle: "م ع أ 4521", status: "قيد التحضير", time: "10:00", zone: "رأس البر" },
  { id: "ORD-2854", customer: "مجموعة الصفوة", branch: "المنصورة", items: 11, weight: "2.2 طن", driver: "أحمد سمير", vehicle: "م ع أ 4522", status: "قيد التوصيل", time: "09:15", zone: "المحطة" },
  { id: "ORD-2855", customer: "شركة الخليج", branch: "طنطا", items: 16, weight: "3.3 طن", driver: "سيد حسن", vehicle: "م ع أ 4524", status: "تم التسليم", time: "05:45", zone: "سبرباي" },
  { id: "ORD-2856", customer: "كارفور مصر", branch: "بورسعيد", items: 19, weight: "3.9 طن", driver: "عبدالله فؤاد", vehicle: "م ع أ 4525", status: "قيد التحميل", time: "08:45", zone: "المناخ" },
  { id: "ORD-2857", customer: "سوبر ماركت", branch: "الزقازيق", items: 4, weight: "0.8 طن", driver: "إبراهيم نصر", vehicle: "م ع أ 4526", status: "معلق", time: "11:30", zone: "أولاد صقر" },
  { id: "ORD-2858", customer: "بن داود", branch: "القاهرة", items: 13, weight: "2.6 طن", driver: "طارق محيي", vehicle: "م ع أ 4528", status: "قيد التوصيل", time: "07:30", zone: "المعادي" },
  { id: "ORD-2859", customer: "مؤسسة مصر", branch: "الإسكندرية", items: 8, weight: "1.5 طن", driver: "حسن محمد", vehicle: "م ع أ 4529", status: "تم التسليم", time: "06:15", zone: "جليم" },
  { id: "ORD-2860", customer: "الدولية", branch: "القاهرة", items: 17, weight: "3.4 طن", driver: "عادل رشاد", vehicle: "م ع أ 4530", status: "قيد التحضير", time: "09:45", zone: "مدينتي" },
  { id: "ORD-2861", customer: "هايبر الهرم", branch: "الجيزة", items: 6, weight: "1.0 طن", driver: "ياسر عاطف", vehicle: "م ع أ 4531", status: "تم التحميل", time: "08:30", zone: "فيصل" },
  { id: "ORD-2862", customer: "شركة النيل", branch: "طنطا", items: 21, weight: "4.2 طن", driver: "وليد صلاح", vehicle: "م ع أ 4533", status: "قيد التوصيل", time: "07:00", zone: "المحلة" },
];

export const loadingManifests = [
  { id: "MAN-001", orderId: "ORD-2845", steps: [{ name: "الاستلام", status: "done" }, { name: "تأكيد المستودع", status: "done" }, { name: "التحميل", status: "done" }, { name: "استلام السائق", status: "done" }], items: 15 },
  { id: "MAN-002", orderId: "ORD-2846", steps: [{ name: "الاستلام", status: "done" }, { name: "تأكيد المستودع", status: "done" }, { name: "التحميل", status: "done" }, { name: "استلام السائق", status: "current" }], items: 25 },
  { id: "MAN-003", orderId: "ORD-2848", steps: [{ name: "الاستلام", status: "done" }, { name: "تأكيد المستودع", status: "current" }, { name: "التحميل", status: "pending" }, { name: "استلام السائق", status: "pending" }], items: 18 },
  { id: "MAN-004", orderId: "ORD-2852", steps: [{ name: "الاستلام", status: "done" }, { name: "تأكيد المستودع", status: "done" }, { name: "التحميل", status: "current" }, { name: "استلام السائق", status: "pending" }], items: 14 },
  { id: "MAN-005", orderId: "ORD-2856", steps: [{ name: "الاستلام", status: "current" }, { name: "تأكيد المستودع", status: "pending" }, { name: "التحميل", status: "pending" }, { name: "استلام السائق", status: "pending" }], items: 19 },
];

export const routes = [
  { id: 1, driver: "محمد علي", zone: "مدينة نصر - التجمع", orders: 4, distance: "35 كم", estimatedTime: "2.5 ساعة", stops: [{ loc: "مدينة نصر", time: "08:30" }, { loc: "مصر الجديدة", time: "09:15" }, { loc: "التجمع", time: "10:00" }] },
  { id: 2, driver: "أحمد سمير", zone: "الهرم - فيصل", orders: 3, distance: "22 كم", estimatedTime: "1.8 ساعة", stops: [{ loc: "الهرم", time: "09:00" }, { loc: "فيصل", time: "09:45" }, { loc: "الجيزة", time: "10:30" }] },
  { id: 3, driver: "سيد حسن", zone: "الإسكندرية", orders: 5, distance: "210 كم", estimatedTime: "3.5 ساعة", stops: [{ loc: "سموحة", time: "07:00" }, { loc: "المنتزه", time: "08:30" }, { loc: "جليم", time: "09:45" }] },
  { id: 4, driver: "طارق محيي", zone: "المعادي - حلوان", orders: 3, distance: "28 كم", estimatedTime: "2 ساعة", stops: [{ loc: "المعادي", time: "10:00" }, { loc: "حلوان", time: "10:45" }, { loc: "15 مايو", time: "11:30" }] },
  { id: 5, driver: "عادل رشاد", zone: "شبرا - بنها", orders: 4, distance: "45 كم", estimatedTime: "2.2 ساعة", stops: [{ loc: "شبرا", time: "08:00" }, { loc: "الخلفاوي", time: "08:40" }, { loc: "بنها", time: "09:30" }] },
  { id: 6, driver: "وليد صلاح", zone: "طنطا - المحلة", orders: 3, distance: "30 كم", estimatedTime: "1.5 ساعة", stops: [{ loc: "طنطا", time: "11:00" }, { loc: "المحلة", time: "11:45" }, { loc: "كفر الزيات", time: "12:30" }] },
];

export const podRecords = [
  { id: 1, orderId: "ORD-2842", customer: "هايبر الهرم", signed: true, photo: true, notes: "تم الاستلام بشكل جيد", time: "08:45" },
  { id: 2, orderId: "ORD-2849", customer: "مؤسسة مصر", signed: true, photo: true, notes: "", time: "07:30" },
  { id: 3, orderId: "ORD-2855", customer: "شركة الخليج", signed: true, photo: false, notes: "تأخر 15 دقيقة", time: "06:45" },
  { id: 4, orderId: "ORD-2859", customer: "مؤسسة مصر", signed: false, photo: false, notes: "العميل غير متواجد", time: "", status: "فشل" },
  { id: 5, orderId: "ORD-2841", customer: "شركة النيل", signed: false, photo: false, notes: "قيد التوصيل", time: "", status: "قيد التنفيذ" },
];

export const returns = [
  { id: "RET-001", orderId: "ORD-2835", customer: "هايبر الهرم", reason: "منتج تالف", quantity: 5, status: "مستلم", refund: 2100, date: "2024-06-14" },
  { id: "RET-002", orderId: "ORD-2838", customer: "شركة الخليج", reason: "طلب خاطئ", quantity: 2, status: "قيد المراجعة", refund: 960, date: "2024-06-15" },
  { id: "RET-003", orderId: "ORD-2840", customer: "سوبر وان", reason: "انتهاء صلاحية", quantity: 8, status: "مستلم", refund: 3840, date: "2024-06-13" },
  { id: "RET-004", orderId: "ORD-2843", customer: "مجموعة الصفوة", reason: "جودة منخفضة", quantity: 3, status: "معلق", refund: 1450, date: "2024-06-15" },
];
