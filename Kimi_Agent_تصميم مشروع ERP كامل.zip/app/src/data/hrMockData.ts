// ═══════════════════════════════════════════════════════════
// GFF ERP — HR Module Mock Data ( comprehesive )
// ═══════════════════════════════════════════════════════════

export interface Employee {
  id: number;
  code: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  position: string;
  branch: string;
  joinDate: string;
  status: 'active' | 'on_leave' | 'terminated' | 'new';
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  foodAllowance: number;
  insuranceDeduction: number;
  taxDeduction: number;
  socialInsuranceId: string;
  birthDate: string;
  nationality: string;
  maritalStatus: string;
  address: string;
  emergencyName: string;
  emergencyRelation: string;
  emergencyPhone: string;
  contractType: string;
  probationMonths: number;
}

export interface AttendanceRecord {
  id: number;
  employeeId: number;
  employeeName: string;
  department: string;
  date: string;
  checkIn: string | null;
  checkOut: string | null;
  status: 'present' | 'absent' | 'late' | 'leave' | 'vacation';
  workHours: number;
  overtimeHours: number;
  notes: string;
}

export interface PayrollRecord {
  id: number;
  employeeId: number;
  employeeName: string;
  department: string;
  month: string;
  year: number;
  basicSalary: number;
  housingAllowance: number;
  transportAllowance: number;
  foodAllowance: number;
  overtimePay: number;
  bonuses: number;
  commission: number;
  totalEarnings: number;
  insuranceDeduction: number;
  taxDeduction: number;
  loanDeduction: number;
  absenceDeduction: number;
  otherDeductions: number;
  totalDeductions: number;
  netSalary: number;
  status: 'pending' | 'paid' | 'hold';
  paymentDate: string | null;
}

export interface CommissionRule {
  id: number;
  role: string;
  salesTarget: number;
  commissionRate: number;
  bonusThreshold: number;
  bonusRate: number;
}

export interface CommissionRecord {
  id: number;
  employeeId: number;
  employeeName: string;
  role: string;
  month: string;
  year: number;
  salesTarget: number;
  actualSales: number;
  achievementRate: number;
  commissionAmount: number;
  bonusAmount: number;
  totalCommission: number;
  status: 'pending' | 'approved' | 'paid';
}

export interface LeaveRequest {
  id: number;
  employeeId: number;
  employeeName: string;
  department: string;
  type: 'annual' | 'sick' | 'emergency' | 'unpaid' | 'hajj' | 'maternity';
  fromDate: string;
  toDate: string;
  days: number;
  reason: string;
  replacement: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
}

export interface LeaveBalance {
  employeeId: number;
  employeeName: string;
  annualTotal: number;
  annualUsed: number;
  sickTotal: number;
  sickUsed: number;
  emergencyTotal: number;
  emergencyUsed: number;
  unpaidUsed: number;
}

export interface OrgDepartment {
  id: number;
  name: string;
  managerId: number;
  managerName: string;
  parentId: number | null;
  employeeCount: number;
  color: string;
}

export interface OrgNode {
  id: number;
  name: string;
  position: string;
  department: string;
  level: number;
  parentId: number | null;
  avatar: string;
}

// ─── Egyptian Employee Names ────────────────────────────
const EGYPTIAN_NAMES = [
  'أحمد محمد', 'محمود سعيد', 'فاطمة علي', 'هالة أحمد', 'خالد حسن',
  'سامي رضا', 'ياسر فؤاد', 'علي عبدالله', 'كريم سعيد', 'نادر إبراهيم',
  'طارق محمود', 'سيد فاروق', 'منى محمود', ' Naglaa سمير', 'وجدي عاطف',
  'أمل رشاد', 'محمد علي', 'إبراهيم كمال', 'نادية فهمي', 'حسن عبدالعظيم',
  'عبير صلاح', 'وليد مصطفى', 'دعاء رأفت', 'شريف محمد', 'ليلى إبراهيم',
];

const DEPARTMENTS = ['المبيعات', 'الإنتاج', 'المخازن', 'الحسابات', 'الموارد البشرية', 'الصيانة', 'الجودة', 'اللوجستيات', 'المشتريات', 'الإدارة'];
const POSITIONS = ['مدير', 'مشرف', 'أخصائي', 'مندوب', 'محاسب', 'فني', 'أمين مخزن', 'كاشير', 'سائق', 'مساعد إداري'];
const BRANCHES = ['القاهرة', 'الإسكندرية', 'طنطا', 'المنصورة'];
// Employee status is assigned inline during generation

// ─── Employees ──────────────────────────────────────────
export const hrEmployees: Employee[] = Array.from({ length: 24 }, (_, i) => {
  const dept = DEPARTMENTS[i % DEPARTMENTS.length];
  const status = i < 18 ? 'active' : i < 20 ? 'on_leave' : i < 22 ? 'new' : 'terminated';
  const basicSalary = 5000 + Math.floor(Math.random() * 15000);
  return {
    id: i + 1,
    code: `EMP-${String(i + 1).padStart(4, '0')}`,
    name: EGYPTIAN_NAMES[i % EGYPTIAN_NAMES.length],
    email: `emp${i + 1}@gff.com`,
    phone: `01${[0, 1, 2, 5][i % 4]}${String(Math.floor(Math.random() * 10000000)).padStart(7, '0')}`,
    department: dept,
    position: `${POSITIONS[i % POSITIONS.length]} ${dept}`,
    branch: BRANCHES[i % BRANCHES.length],
    joinDate: `${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}/${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}/202${Math.floor(Math.random() * 3)}`,
    status,
    basicSalary,
    housingAllowance: Math.floor(basicSalary * 0.2),
    transportAllowance: Math.floor(basicSalary * 0.1),
    foodAllowance: Math.floor(basicSalary * 0.08),
    insuranceDeduction: Math.floor(basicSalary * 0.11),
    taxDeduction: Math.floor(basicSalary * 0.05),
    socialInsuranceId: `${Math.floor(Math.random() * 1000000000000)}`,
    birthDate: `${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}/${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}/${1980 + Math.floor(Math.random() * 25)}`,
    nationality: i % 10 === 0 ? 'سوداني' : 'مصري',
    maritalStatus: i % 3 === 0 ? 'أعزب' : 'متزوج',
    address: `${['شارع النصر', 'شارع الجمهورية', 'شارع التحرير', 'شارع المعز'][i % 4]} - ${BRANCHES[i % BRANCHES.length]}`,
    emergencyName: `جهة طوارئ ${i + 1}`,
    emergencyRelation: ['زوج/زوجة', 'أب', 'أم', 'أخ'][i % 4],
    emergencyPhone: `01${[0, 1, 2, 5][(i + 1) % 4]}${String(Math.floor(Math.random() * 10000000)).padStart(7, '0')}`,
    contractType: ['دائم', 'مؤقت', 'جزئي'][i % 3],
    probationMonths: [3, 6, 1][i % 3],
  };
});

// ─── Attendance (current month, days 1-30) ──────────────
// Attendance statuses are assigned inline during generation
export const hrAttendance: AttendanceRecord[] = [];
let attId = 1;
for (let empIdx = 0; empIdx < 20; empIdx++) {
  const emp = hrEmployees[empIdx];
  for (let day = 1; day <= 30; day++) {
    const r = Math.random();
    let status: AttendanceRecord['status'] = 'present';
    if (r > 0.95) status = 'absent';
    else if (r > 0.88) status = 'late';
    else if (r > 0.85) status = 'leave';
    else if (r > 0.82) status = 'vacation';

    const checkIn = status === 'absent' || status === 'vacation' ? null :
      `${status === 'late' ? String(9 + Math.floor(Math.random() * 2)).padStart(2, '0') : '0${8 + Math.floor(Math.random() * 1)}'}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`;
    const checkOut = checkIn ? `${15 + Math.floor(Math.random() * 3)}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}` : null;
    const workHours = checkIn && checkOut ? 8 + Math.floor(Math.random() * 3) : 0;

    hrAttendance.push({
      id: attId++,
      employeeId: emp.id,
      employeeName: emp.name,
      department: emp.department,
      date: `${String(day).padStart(2, '0')}/01/2025`,
      checkIn,
      checkOut,
      status,
      workHours,
      overtimeHours: workHours > 8 ? workHours - 8 : 0,
      notes: status === 'late' ? 'تأخر بسبب الزحام' : status === 'absent' ? 'غياب غير مبرر' : '',
    });
  }
}

// ─── Payroll (January 2025) ─────────────────────────────
export const hrPayroll: PayrollRecord[] = hrEmployees
  .filter((e) => e.status !== 'terminated')
  .map((emp, i) => {
    const overtimePay = Math.floor(Math.random() * 2000);
    const bonuses = Math.floor(Math.random() * 1500);
    const commission = emp.department === 'المبيعات' ? Math.floor(Math.random() * 5000) : 0;
    const totalEarnings = emp.basicSalary + emp.housingAllowance + emp.transportAllowance + emp.foodAllowance + overtimePay + bonuses + commission;
    const loanDeduction = Math.floor(Math.random() * 500);
    const absenceDeduction = Math.floor(Math.random() * 300);
    const otherDeductions = Math.floor(Math.random() * 200);
    const totalDeductions = emp.insuranceDeduction + emp.taxDeduction + loanDeduction + absenceDeduction + otherDeductions;
    const statuses: PayrollRecord['status'][] = ['pending', 'paid', 'hold'];
    return {
      id: i + 1,
      employeeId: emp.id,
      employeeName: emp.name,
      department: emp.department,
      month: 'يناير',
      year: 2025,
      basicSalary: emp.basicSalary,
      housingAllowance: emp.housingAllowance,
      transportAllowance: emp.transportAllowance,
      foodAllowance: emp.foodAllowance,
      overtimePay,
      bonuses,
      commission,
      totalEarnings,
      insuranceDeduction: emp.insuranceDeduction,
      taxDeduction: emp.taxDeduction,
      loanDeduction,
      absenceDeduction,
      otherDeductions,
      totalDeductions,
      netSalary: totalEarnings - totalDeductions,
      status: statuses[i % 3],
      paymentDate: statuses[i % 3] === 'paid' ? '28/01/2025' : null,
    };
  });

// ─── Commission Rules ───────────────────────────────────
export const hrCommissionRules: CommissionRule[] = [
  { id: 1, role: 'مندوب مبيعات', salesTarget: 500000, commissionRate: 0.03, bonusThreshold: 700000, bonusRate: 0.02 },
  { id: 2, role: 'مشرف مبيعات', salesTarget: 800000, commissionRate: 0.025, bonusThreshold: 1000000, bonusRate: 0.015 },
  { id: 3, role: 'مدير مبيعات', salesTarget: 1200000, commissionRate: 0.02, bonusThreshold: 1500000, bonusRate: 0.01 },
  { id: 4, role: 'مندوب توزيع', salesTarget: 400000, commissionRate: 0.035, bonusThreshold: 600000, bonusRate: 0.025 },
  { id: 5, role: 'مبيعات أونلاين', salesTarget: 300000, commissionRate: 0.04, bonusThreshold: 500000, bonusRate: 0.03 },
];

// ─── Commission Records ─────────────────────────────────
export const hrCommissions: CommissionRecord[] = hrEmployees
  .filter((e) => e.department === 'المبيعات')
  .map((emp, i) => {
    const rule = hrCommissionRules[i % hrCommissionRules.length];
    const achievement = 0.5 + Math.random() * 1.2;
    const actualSales = Math.floor(rule.salesTarget * achievement);
    const achievementRate = (actualSales / rule.salesTarget) * 100;
    const commissionAmount = Math.floor(actualSales * rule.commissionRate);
    const bonusAmount = actualSales >= rule.bonusThreshold ? Math.floor((actualSales - rule.bonusThreshold) * rule.bonusRate) : 0;
    const statuses: CommissionRecord['status'][] = ['pending', 'approved', 'paid'];
    return {
      id: i + 1,
      employeeId: emp.id,
      employeeName: emp.name,
      role: rule.role,
      month: 'يناير',
      year: 2025,
      salesTarget: rule.salesTarget,
      actualSales,
      achievementRate: Math.round(achievementRate * 10) / 10,
      commissionAmount,
      bonusAmount,
      totalCommission: commissionAmount + bonusAmount,
      status: statuses[i % 3],
    };
  });

// ─── Leave Requests ─────────────────────────────────────
export const hrLeaveRequests: LeaveRequest[] = [
  { id: 1, employeeId: 1, employeeName: 'أحمد محمد', department: 'المبيعات', type: 'annual', fromDate: '15/01/2025', toDate: '20/01/2025', days: 6, reason: 'إجازة سنوية مع العائلة', replacement: 'محمود سعيد', status: 'approved', requestedAt: '01/01/2025' },
  { id: 2, employeeId: 3, employeeName: 'محمود سعيد', department: 'الإنتاج', type: 'sick', fromDate: '10/01/2025', toDate: '12/01/2025', days: 3, reason: 'مراجعة طبية', replacement: 'خالد حسن', status: 'approved', requestedAt: '09/01/2025' },
  { id: 3, employeeId: 5, employeeName: 'خالد حسن', department: 'المخازن', type: 'emergency', fromDate: '18/01/2025', toDate: '18/01/2025', days: 1, reason: 'ظرف طارئ عائلي', replacement: 'سامي رضا', status: 'pending', requestedAt: '17/01/2025' },
  { id: 4, employeeId: 7, employeeName: 'ياسر فؤاد', department: 'الحسابات', type: 'unpaid', fromDate: '01/02/2025', toDate: '07/02/2025', days: 7, reason: 'سفر للخارج', replacement: 'علي عبدالله', status: 'pending', requestedAt: '15/01/2025' },
  { id: 5, employeeId: 9, employeeName: 'كريم سعيد', department: 'الموارد البشرية', type: 'annual', fromDate: '05/02/2025', toDate: '10/02/2025', days: 6, reason: 'راحة وت recover', replacement: 'نادر إبراهيم', status: 'pending', requestedAt: '20/01/2025' },
  { id: 6, employeeId: 2, employeeName: 'محمد علي', department: 'الصيانة', type: 'sick', fromDate: '22/01/2025', toDate: '24/01/2025', days: 3, reason: 'نزلة برد', replacement: 'طارق محمود', status: 'approved', requestedAt: '21/01/2025' },
  { id: 7, employeeId: 11, employeeName: 'طارق محمود', department: 'الجودة', type: 'hajj', fromDate: '01/03/2025', toDate: '15/03/2025', days: 15, reason: 'أداء العمرة', replacement: 'سيد فاروق', status: 'pending', requestedAt: '10/01/2025' },
  { id: 8, employeeId: 4, employeeName: 'سامي رضا', department: 'اللوجستيات', type: 'annual', fromDate: '20/02/2025', toDate: '25/02/2025', days: 6, reason: 'إجازة سنوية', replacement: 'منى محمود', status: 'rejected', requestedAt: '05/01/2025' },
];

// ─── Leave Balances ─────────────────────────────────────
export const hrLeaveBalances: LeaveBalance[] = hrEmployees.slice(0, 15).map((emp, i) => ({
  employeeId: emp.id,
  employeeName: emp.name,
  annualTotal: 21,
  annualUsed: [6, 0, 3, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0][i] || 0,
  sickTotal: 10,
  sickUsed: [0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0][i] || 0,
  emergencyTotal: 5,
  emergencyUsed: [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0][i] || 0,
  unpaidUsed: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0][i] || 0,
}));

// ─── Organization Departments ───────────────────────────
export const hrOrgDepartments: OrgDepartment[] = [
  { id: 1, name: 'الإدارة العامة', managerId: 1, managerName: 'أحمد محمد', parentId: null, employeeCount: 3, color: '#0d6b43' },
  { id: 2, name: 'المبيعات', managerId: 2, managerName: 'محمود سعيد', parentId: 1, employeeCount: 6, color: '#14a86a' },
  { id: 3, name: 'الإنتاج', managerId: 3, managerName: 'فاطمة علي', parentId: 1, employeeCount: 5, color: '#daa520' },
  { id: 4, name: 'المخازن', managerId: 4, managerName: 'هالة أحمد', parentId: 1, employeeCount: 4, color: '#3b82f6' },
  { id: 5, name: 'الحسابات', managerId: 5, managerName: 'خالد حسن', parentId: 1, employeeCount: 3, color: '#8b5cf6' },
  { id: 6, name: 'الموارد البشرية', managerId: 6, managerName: 'سامي رضا', parentId: 1, employeeCount: 3, color: '#f59e0b' },
  { id: 7, name: 'الصيانة', managerId: 7, managerName: 'ياسر فؤاد', parentId: 3, employeeCount: 3, color: '#ef4444' },
  { id: 8, name: 'الجودة', managerId: 8, managerName: 'علي عبدالله', parentId: 3, employeeCount: 2, color: '#10b981' },
  { id: 9, name: 'اللوجستيات', managerId: 9, managerName: 'كريم سعيد', parentId: 2, employeeCount: 3, color: '#06b6d4' },
  { id: 10, name: 'المشتريات', managerId: 10, managerName: 'نادر إبراهيم', parentId: 4, employeeCount: 2, color: '#6366f1' },
];

// ─── Organization Chart Nodes ───────────────────────────
export const hrOrgNodes: OrgNode[] = [
  { id: 1, name: 'أحمد محمد', position: 'المدير العام', department: 'الإدارة العامة', level: 0, parentId: null, avatar: 'أم' },
  { id: 2, name: 'محمود سعيد', position: 'مدير المبيعات', department: 'المبيعات', level: 1, parentId: 1, avatar: 'مس' },
  { id: 3, name: 'فاطمة علي', position: 'مدير الإنتاج', department: 'الإنتاج', level: 1, parentId: 1, avatar: 'فع' },
  { id: 4, name: 'هالة أحمد', position: 'مدير المخازن', department: 'المخازن', level: 1, parentId: 1, avatar: 'هأ' },
  { id: 5, name: 'خالد حسن', position: 'مدير الحسابات', department: 'الحسابات', level: 1, parentId: 1, avatar: 'خح' },
  { id: 6, name: 'سامي رضا', position: 'مدير الموارد البشرية', department: 'الموارد البشرية', level: 1, parentId: 1, avatar: 'سر' },
  { id: 7, name: 'ياسر فؤاد', position: 'مشرف الصيانة', department: 'الصيانة', level: 2, parentId: 3, avatar: 'يف' },
  { id: 8, name: 'علي عبدالله', position: 'مشرف الجودة', department: 'الجودة', level: 2, parentId: 3, avatar: 'عأ' },
  { id: 9, name: 'كريم سعيد', position: 'مشرف اللوجستيات', department: 'اللوجستيات', level: 2, parentId: 2, avatar: 'كس' },
  { id: 10, name: 'نادر إبراهيم', position: 'مشرف المشتريات', department: 'المشتريات', level: 2, parentId: 4, avatar: 'نإ' },
  { id: 11, name: 'طارق محمود', position: 'مندوب مبيعات', department: 'المبيعات', level: 3, parentId: 2, avatar: 'طم' },
  { id: 12, name: 'سيد فاروق', position: 'فني إنتاج', department: 'الإنتاج', level: 3, parentId: 3, avatar: 'سف' },
  { id: 13, name: 'منى محمود', position: 'أمين مخزن', department: 'المخازن', level: 3, parentId: 4, avatar: 'مم' },
  { id: 14, name: ' Naglaa سمير', position: 'محاسب', department: 'الحسابات', level: 3, parentId: 5, avatar: 'نس' },
  { id: 15, name: 'وجدي عاطف', position: 'أخصائي موارد بشرية', department: 'الموارد البشرية', level: 3, parentId: 6, avatar: 'وع' },
];

// ─── Status Badge Helpers ───────────────────────────────
export function getStatusBadgeClass(status: string) {
  switch (status) {
    case 'active':
    case 'present':
    case 'approved':
    case 'paid':
      return 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400';
    case 'on_leave':
    case 'pending':
    case 'hold':
    case 'late':
      return 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400';
    case 'terminated':
    case 'absent':
    case 'rejected':
      return 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400';
    case 'new':
    case 'vacation':
    case 'leave':
    case 'draft':
      return 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400';
    default:
      return 'bg-slate-50 text-slate-600 dark:bg-slate-800 dark:text-slate-400';
  }
}

export function getStatusLabel(status: string) {
  const map: Record<string, string> = {
    active: 'نشط', on_leave: 'في إجازة', terminated: 'مقطوع', new: 'مستجد',
    present: 'حاضر', absent: 'غائب', late: 'متأخر', vacation: 'إجازة', leave: 'إذن',
    pending: 'معلق', approved: 'معتمد', rejected: 'مرفوض',
    paid: 'مدفوع', hold: 'معلق',
    annual: 'سنوية', sick: 'مرضية', emergency: 'عارضة', unpaid: 'بدون راتب', hajj: 'حج/عمرة', maternity: 'أمومة',
  };
  return map[status] || status;
}

// ─── KPI Summary Helpers ────────────────────────────────
export function getEmployeeStats() {
  const total = hrEmployees.length;
  const active = hrEmployees.filter((e) => e.status === 'active').length;
  const onLeave = hrEmployees.filter((e) => e.status === 'on_leave').length;
  const terminated = hrEmployees.filter((e) => e.status === 'terminated').length;
  const newThisMonth = hrEmployees.filter((e) => e.status === 'new').length;
  return { total, active, onLeave, terminated, newThisMonth };
}

export function getAttendanceStats() {
  const todayRecords = hrAttendance.filter((a) => a.date === '15/01/2025');
  const present = todayRecords.filter((a) => a.status === 'present').length;
  const absent = todayRecords.filter((a) => a.status === 'absent').length;
  const late = todayRecords.filter((a) => a.status === 'late').length;
  const onVacation = todayRecords.filter((a) => a.status === 'vacation').length;
  const early = todayRecords.filter((a) => a.status === 'present' && a.checkIn && a.checkIn < '09:00').length;
  return { present, absent, late, onVacation, early };
}

export function getPayrollSummary() {
  const totalSalaries = hrPayroll.reduce((s, p) => s + p.totalEarnings, 0);
  const totalDeductions = hrPayroll.reduce((s, p) => s + p.totalDeductions, 0);
  const totalNet = hrPayroll.reduce((s, p) => s + p.netSalary, 0);
  const paidCount = hrPayroll.filter((p) => p.status === 'paid').length;
  const pendingCount = hrPayroll.filter((p) => p.status === 'pending').length;
  return { totalSalaries, totalDeductions, totalNet, paidCount, pendingCount };
}

export function getCommissionSummary() {
  const totalCommission = hrCommissions.reduce((s, c) => s + c.totalCommission, 0);
  const totalSales = hrCommissions.reduce((s, c) => s + c.actualSales, 0);
  const totalTarget = hrCommissions.reduce((s, c) => s + c.salesTarget, 0);
  const avgAchievement = hrCommissions.length > 0 ? hrCommissions.reduce((s, c) => s + c.achievementRate, 0) / hrCommissions.length : 0;
  return { totalCommission, totalSales, totalTarget, avgAchievement: Math.round(avgAchievement * 10) / 10 };
}
