export const execKPIs = [
  { label: "المبيعات اليومية", value: "EGP 2.4M", change: "+8.2%", trend: "up" as const },
  { label: "المبيعات الشهرية", value: "EGP 68M", change: "+12.5%", trend: "up" as const },
  { label: "صافي الربح", value: "EGP 12.4M", change: "+6.3%", trend: "up" as const },
  { label: "قيمة المخزون", value: "EGP 45M", change: "-2.1%", trend: "down" as const },
  { label: "الموقف النقدي", value: "EGP 8.2M", change: "+4.7%", trend: "up" as const },
  { label: "المستحقات", value: "EGP 18M", change: "-1.5%", trend: "down" as const },
  { label: "المدفوعات", value: "EGP 9M", change: "+3.2%", trend: "up" as const },
  { label: "التسليمات المعلقة", value: "142", change: "-5.8%", trend: "down" as const },
];

export const salesTrend = [
  { month: "يناير", sales: 45, profit: 8 },
  { month: "فبراير", sales: 52, profit: 9.5 },
  { month: "مارس", sales: 48, profit: 8.8 },
  { month: "أبريل", sales: 61, profit: 11.2 },
  { month: "مايو", sales: 58, profit: 10.5 },
  { month: "يونيو", sales: 68, profit: 12.4 },
  { month: "يوليو", sales: 55, profit: 9.8 },
  { month: "أغسطس", sales: 63, profit: 11.5 },
  { month: "سبتمبر", sales: 59, profit: 10.2 },
  { month: "أكتوبر", sales: 72, profit: 13.1 },
  { month: "نوفمبر", sales: 65, profit: 11.8 },
  { month: "ديسمبر", sales: 70, profit: 12.9 },
];

export const salesByBranch = [
  { name: "القاهرة", sales: 18.5 },
  { name: "الإسكندرية", sales: 12.2 },
  { name: "المنصورة", sales: 9.8 },
  { name: "طنطا", sales: 7.5 },
  { name: "الزقازيق", sales: 6.3 },
  { name: "بنها", sales: 5.1 },
  { name: "كفر الشيخ", sales: 4.2 },
];

export const topCustomers = [
  { name: "شركة النيل للتجارة", sales: 4.2 },
  { name: "سوبر ماركت الهرم", sales: 3.8 },
  { name: "مجموعة مصر للصناعات", sales: 3.5 },
  { name: "مؤسسة الصفوة", sales: 3.1 },
  { name: "شركة الخليج للتوزيع", sales: 2.9 },
  { name: "هايبر وان", sales: 2.7 },
  { name: "كارفور مصر", sales: 2.5 },
  { name: "سعودي ماركت", sales: 2.3 },
  { name: "بن داود", sales: 2.1 },
  { name: " LuLu هايبر", sales: 1.9 },
];

export const salesByCategory = [
  { name: "أعلاف دواجن", value: 35 },
  { name: "أعلاف ماشية", value: 25 },
  { name: "كتاكيت", value: 20 },
  { name: "بيض مائدة", value: 12 },
  { name: "مستلزمات", value: 8 },
];

export const branches = Array.from({ length: 16 }, (_, i) => ({
  id: i + 1,
  name: ["القاهرة", "الإسكندرية", "المنصورة", "طنطا", "الزقازيق", "بنها", "كفر الشيخ", "السويس", "بورسعيد", "دمياط", "أسيوط", "سوهاج", "الأقصر", "أسوان", "الفيوم", "بني سويف"][i],
  status: Math.random() > 0.3 ? "active" : Math.random() > 0.5 ? "warning" : "danger",
  todaySales: Math.floor(Math.random() * 500000) + 50000,
  monthlyTarget: Math.random() > 0.5 ? "achieved" : "pending",
  staff: Math.floor(Math.random() * 30) + 5,
}));

export const fleetSummary = {
  totalVehicles: 45,
  activeTrips: 23,
  avgFuelConsumption: 8.2,
  maintenanceAlerts: 4,
  utilizationRate: 78,
};

export const productionSummary = {
  linesRunning: 12,
  totalLines: 14,
  todayOutput: 2850,
  yieldRate: 94.2,
  oee: 87.5,
  downtimeHours: 1.2,
};

export const alerts = [
  { id: 1, type: "warning", message: "مخزون أعلاف دواجن منخفض - فرع القاهرة", time: "5 دقائق" },
  { id: 2, type: "danger", message: "تأخر تسليم طلب #2847 - عميل النيل", time: "12 دقيقة" },
  { id: 3, type: "info", message: "فاتورة مستحقة #1892 - شركة الصفوة", time: "30 دقيقة" },
  { id: 4, type: "warning", message: "صيانة دورية م due - مركبة رقم 12", time: "1 ساعة" },
  { id: 5, type: "danger", message: "نفوق مرتفع في مزرعة الدلتا - 2.1%", time: "2 ساعة" },
  { id: 6, type: "info", message: "تحصين مجدول غداً - 3 مزارع", time: "3 ساعات" },
  { id: 7, type: "warning", message: "طلب إرجاع معلق #3921 - بيض تالف", time: "4 ساعات" },
  { id: 8, type: "danger", message: "تجاوز حد الائتمان - العميل الخليج", time: "5 ساعات" },
];

export const aiRecommendations = [
  { id: 1, title: "زيادة طلبية الذرة الصفراء", desc: "ارتفاع متوقع في الطلب 18% الشهر القادم", confidence: 92, impact: "EGP +2.1M" },
  { id: 2, title: "فتح فرع جديد - أسيوط", desc: "كثافة عملاء مرتفعة بدون تغطية كافية", confidence: 87, impact: "EGP +5.8M/سنة" },
  { id: 3, title: "تعديل سعر أعلاف البياض", desc: "السوق يسمح برفع 3% بدون تأثير على الطلب", confidence: 85, impact: "EGP +890K" },
  { id: 4, title: "تسريع دورة التحصيل", desc: "5 عملاء يتجاوزون 60 يوم مستحقات", confidence: 91, impact: "EGP +3.2M سيولة" },
  { id: 5, title: "صيانة وقائية لخط التعبئة 3", desc: "توقع عطل بنسبة 78% خلال 14 يوم", confidence: 78, impact: "تجنب خسارة EGP 450K" },
];

export const branchRanking = [
  { name: "القاهرة", sales: 18.5, profit: 3.2, turnover: 12.4 },
  { name: "الإسكندرية", sales: 12.2, profit: 2.1, turnover: 9.8 },
  { name: "المنصورة", sales: 9.8, profit: 1.6, turnover: 8.2 },
  { name: "طنطا", sales: 7.5, profit: 1.2, turnover: 7.1 },
  { name: "الزقازيق", sales: 6.3, profit: 0.9, turnover: 6.5 },
  { name: "بنها", sales: 5.1, profit: 0.8, turnover: 5.3 },
  { name: "كفر الشيخ", sales: 4.2, profit: 0.6, turnover: 4.8 },
];

export const cashFlowWeekly = [
  { day: "السبت", in: 420, out: 380 },
  { day: "الأحد", in: 550, out: 410 },
  { day: "الإثنين", in: 480, out: 520 },
  { day: "الثلاثاء", in: 610, out: 390 },
  { day: "الأربعاء", in: 530, out: 450 },
  { day: "الخميس", in: 720, out: 380 },
  { day: "الجمعة", in: 290, out: 210 },
];
