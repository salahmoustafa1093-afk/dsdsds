import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2, TrendingUp, ArrowDownLeft, ArrowUpRight,
  Plus, X, CreditCard, CheckCircle2, Clock, AlertCircle
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

/* ─── Mock Data ─── */
const banks = [
  { id: 1, name: 'CIB بنك مصر', accountNumber: '1234-5678-9012', balance: 850000, lastTransaction: '2025-01-15', branch: 'فرع القاهرة' },
  { id: 2, name: 'QNB الأهلي', accountNumber: '9876-5432-1098', balance: 420000, lastTransaction: '2025-01-14', branch: 'فرع الجيزة' },
  { id: 3, name: 'AlexBank', accountNumber: '4567-8901-2345', balance: 180000, lastTransaction: '2025-01-13', branch: 'فرع الإسكندرية' },
  { id: 4, name: 'Cairo Bank', accountNumber: '7890-1234-5678', balance: 320000, lastTransaction: '2025-01-12', branch: 'فرع طنطا' },
];

const bankTransactions = [
  { id: 1, date: '2025-01-15', bank: 'CIB بنك مصر', type: 'إيداع', amount: 150000, description: 'تحصيل شيكات عملاء', reference: 'DEP-001', balance: 850000 },
  { id: 2, date: '2025-01-14', bank: 'QNB الأهلي', type: 'سحب', amount: 75000, description: 'سداد موردين', reference: 'WTH-002', balance: 420000 },
  { id: 3, date: '2025-01-14', bank: 'AlexBank', type: 'تحويل', amount: 50000, description: 'تحويل إلى CIB', reference: 'TRF-003', balance: 180000 },
  { id: 4, date: '2025-01-13', bank: 'CIB بنك مصر', type: 'إيداع', amount: 220000, description: 'إيرادات مبيعات', reference: 'DEP-002', balance: 850000 },
  { id: 5, date: '2025-01-12', bank: 'Cairo Bank', type: 'سحب', amount: 45000, description: 'مصروفات تشغيل', reference: 'WTH-004', balance: 320000 },
  { id: 6, date: '2025-01-11', bank: 'QNB الأهلي', type: 'إيداع', amount: 180000, description: 'تحصيل دفعات', reference: 'DEP-003', balance: 420000 },
];

const checks = [
  { id: 1, checkNumber: 'CHK-2025-001', bank: 'CIB بنك مصر', amount: 50000, payee: 'شركة الأعلاف الكبرى', issueDate: '2025-01-10', dueDate: '2025-02-10', status: 'نشط' },
  { id: 2, checkNumber: 'CHK-2025-002', bank: 'QNB الأهلي', amount: 75000, payee: 'مطاحن مصر الوسطى', issueDate: '2025-01-08', dueDate: '2025-02-08', status: 'مقبوض' },
  { id: 3, checkNumber: 'CHK-2025-003', bank: 'AlexBank', amount: 30000, payee: 'مزارع الصعيد', issueDate: '2025-01-05', dueDate: '2025-01-20', status: 'نشط' },
  { id: 4, checkNumber: 'CHK-2025-004', bank: 'Cairo Bank', amount: 120000, payee: 'شركة النيل للحبوب', issueDate: '2024-12-28', dueDate: '2025-01-28', status: 'مُرجع' },
  { id: 5, checkNumber: 'CHK-2025-005', bank: 'CIB بنك مصر', amount: 45000, payee: 'مؤسسة النيل للتسويق', issueDate: '2025-01-12', dueDate: '2025-03-12', status: 'نشط' },
];

const kpi = {
  totalBanks: 4,
  totalBalance: 1770000,
  dailyMovements: 6,
  upcomingChecks: 3,
};

export default function AccountingBanksPage() {
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'transactions' | 'checks'>('transactions');

  const [formBank, setFormBank] = useState(banks[0].name);
  const [formType, setFormType] = useState('إيداع');
  const [formAmount, setFormAmount] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formReference, setFormReference] = useState('');

  const checkStatusBadge = (status: string) => {
    const classes: Record<string, string> = {
      'نشط': 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400',
      'مقبوض': 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400',
      'مُرجع': 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400',
    };
    const icons: Record<string, React.ReactNode> = {
      'نشط': <Clock size={12} />,
      'مقبوض': <CheckCircle2 size={12} />,
      'مُرجع': <AlertCircle size={12} />,
    };
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${classes[status] || classes['نشط']}`}>
        {icons[status]}
        {status}
      </span>
    );
  };

  const transTypeBadge = (type: string) => (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
      type === 'إيداع'
        ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400'
        : type === 'سحب'
        ? 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
        : 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400'
    }`}>
      {type === 'إيداع' ? <ArrowDownLeft size={12} /> : type === 'سحب' ? <ArrowUpRight size={12} /> : <CreditCard size={12} />}
      {type}
    </span>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="الحسابات البنكية"
        subtitle="إدارة الحسابات البنكية والشيكات والتحويلات"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الحسابات', path: '/accounting' },
          { label: 'البنوك' },
        ]}
      >
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>إضافة حركة</span>
        </button>
      </PageHeader>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="إجمالي البنوك" value={String(kpi.totalBanks)} icon={Building2} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="الرصيد الإجمالي" value={formatCurrency(kpi.totalBalance)} icon={TrendingUp} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.1} />
        <KPICard title="حركات اليوم" value={String(kpi.dailyMovements)} icon={CreditCard} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="شيكات قادمة" value={String(kpi.upcomingChecks)} icon={Clock} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-700 dark:text-purple-400" delay={0.3} />
      </div>

      {/* Bank Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {banks.map((bank, i) => (
          <motion.div
            key={bank.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 * i }}
            className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <Building2 size={20} className="text-green-700 dark:text-green-400" />
              </div>
              <span className="text-[10px] text-textMuted">{bank.branch}</span>
            </div>
            <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-1">{bank.name}</h4>
            <p className="text-xs text-textMuted mb-3">{bank.accountNumber}</p>
            <div className="flex items-end justify-between">
              <div>
                <p className="text-xs text-textSecondary">الرصيد الحالي</p>
                <p className="text-lg font-bold text-green-700 dark:text-green-400">{formatCurrency(bank.balance)}</p>
              </div>
              <p className="text-[10px] text-textMuted">آخر حركة: {bank.lastTransaction}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
        <div className="flex border-b border-uiBorder dark:border-darkBorder">
          {[
            { key: 'transactions' as const, label: 'حركات البنوك' },
            { key: 'checks' as const, label: 'الشيكات' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-5 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.key
                  ? 'border-green-600 text-green-700 dark:text-green-400'
                  : 'border-transparent text-textSecondary hover:text-textPrimary dark:text-darkTextSec dark:hover:text-darkText'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-4">
          {activeTab === 'transactions' ? (
            <DataTable
              columns={[
                { key: 'date', header: 'التاريخ', sortable: true },
                { key: 'bank', header: 'البنك', sortable: true },
                { key: 'type', header: 'النوع', render: (row) => transTypeBadge(row.type as string) },
                { key: 'amount', header: 'المبلغ', render: (row) => <span className="font-medium">{formatCurrency(row.amount as number)}</span> },
                { key: 'description', header: 'الوصف', sortable: true },
                { key: 'reference', header: 'المرجع', sortable: true },
                { key: 'balance', header: 'الرصيد بعد', render: (row) => <span className="text-textSecondary">{formatCurrency(row.balance as number)}</span> },
              ]}
              data={bankTransactions as unknown as Record<string, unknown>[]}
              pageSize={6}
            />
          ) : (
            <DataTable
              columns={[
                { key: 'checkNumber', header: 'رقم الشيك', sortable: true },
                { key: 'bank', header: 'البنك', sortable: true },
                { key: 'amount', header: 'المبلغ', render: (row) => <span className="font-medium">{formatCurrency(row.amount as number)}</span> },
                { key: 'payee', header: 'المستفيد', sortable: true },
                { key: 'issueDate', header: 'تاريخ الإصدار', sortable: true },
                { key: 'dueDate', header: 'تاريخ الاستحقاق', sortable: true },
                { key: 'status', header: 'الحالة', render: (row) => checkStatusBadge(row.status as string) },
              ]}
              data={checks as unknown as Record<string, unknown>[]}
              pageSize={6}
            />
          )}
        </div>
      </div>

      {/* Add Transaction Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إضافة حركة بنكية</h3>
                <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">البنك</label>
                  <select value={formBank} onChange={(e) => setFormBank(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    {banks.map((b) => <option key={b.id} value={b.name}>{b.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">نوع الحركة</label>
                  <div className="flex gap-2">
                    {['إيداع', 'سحب', 'تحويل'].map((t) => (
                      <button
                        key={t}
                        onClick={() => setFormType(t)}
                        className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${
                          formType === t ? 'bg-green-700 text-white border-green-700' : 'border-uiBorder dark:border-darkBorder text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">المبلغ</label>
                  <input type="number" value={formAmount} onChange={(e) => setFormAmount(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="0.00" />
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">الوصف</label>
                  <textarea value={formDescription} onChange={(e) => setFormDescription(e.target.value)} rows={2} className="w-full px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm resize-none" />
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">المرجع</label>
                  <input type="text" value={formReference} onChange={(e) => setFormReference(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إلغاء</button>
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">حفظ الحركة</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
