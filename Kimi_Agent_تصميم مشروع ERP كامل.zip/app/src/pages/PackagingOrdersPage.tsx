// @ts-nocheck
import { useState, useMemo } from 'react';
import {
  ClipboardList, CheckCircle2, Clock, XCircle, Plus, Package, ArrowUpDown, Filter,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

/* ─── Types ─────────────────────────────────────────── */
interface PackagingOrder {
  id: number;
  orderNumber: string;
  product: string;
  packageType: string;
  qty: number;
  status: 'scheduled' | 'running' | 'completed' | 'cancelled';
  line: string;
  date: string;
  priority: 'urgent' | 'normal' | 'low';
  notes: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const ordersData: PackagingOrder[] = [
  { id: 1, orderNumber: 'PKO-2025-001', product: 'أرز مصري', packageType: '٥ كجم كيس', qty: 5000, status: 'completed', line: 'خط تعبئة أرز ١', date: '١٥/٠١/٢٠٢٥', priority: 'normal', notes: '' },
  { id: 2, orderNumber: 'PKO-2025-002', product: 'عدس أصفر', packageType: '٢٥ كجم شكاية', qty: 3000, status: 'running', line: 'خط تعبئة عدس ١', date: '١٥/٠١/٢٠٢٥', priority: 'urgent', notes: 'طلب عاجل للتصدير' },
  { id: 3, orderNumber: 'PKO-2025-003', product: 'فول مدمس', packageType: '٥٠ كجم جوال', qty: 2000, status: 'scheduled', line: 'خط تعبئة فول ١', date: '١٦/٠١/٢٠٢٥', priority: 'normal', notes: '' },
  { id: 4, orderNumber: 'PKO-2025-004', product: 'حمص مجروش', packageType: '١ كجم سائب', qty: 8000, status: 'running', line: 'خط تعبئة حمص ١', date: '١٥/٠١/٢٠٢٥', priority: 'normal', notes: '' },
  { id: 5, orderNumber: 'PKO-2025-005', product: 'لوبيا أبيض', packageType: '٥ كجم كيس', qty: 2500, status: 'completed', line: 'خط تعبئة لوبيا ١', date: '١٤/٠١/٢٠٢٥', priority: 'normal', notes: '' },
  { id: 6, orderNumber: 'PKO-2025-006', product: 'أرز مصري', packageType: '٢٥ كجم شكاية', qty: 4000, status: 'scheduled', line: 'خط تعبئة أرز ١', date: '١٧/٠١/٢٠٢٥', priority: 'low', notes: '' },
  { id: 7, orderNumber: 'PKO-2025-007', product: 'عدس أخضر', packageType: '٥٠ كجم جوال', qty: 1800, status: 'cancelled', line: '—', date: '١٣/٠١/٢٠٢٥', priority: 'normal', notes: 'إلغاء لنقص خام' },
  { id: 8, orderNumber: 'PKO-2025-008', product: 'فول مدمس', packageType: '٥ كجم كيس', qty: 3500, status: 'completed', line: 'خط تعبئة فول ١', date: '١٤/٠١/٢٠٢٥', priority: 'urgent', notes: '' },
];

const statusConfig: Record<string, { label: string; color: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  scheduled: { label: 'مجدول', color: 'bg-gray-100 text-gray-700', variant: 'secondary' },
  running: { label: 'قيد التشغيل', color: 'bg-amber-100 text-amber-700', variant: 'secondary' },
  completed: { label: 'مكتمل', color: 'bg-green-100 text-green-700', variant: 'default' },
  cancelled: { label: 'ملغي', color: 'bg-red-100 text-red-700', variant: 'destructive' },
};

const priorityConfig: Record<string, { label: string; badge: string }> = {
  urgent: { label: 'عاجل', badge: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' },
  normal: { label: 'عادي', badge: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' },
  low: { label: 'منخفض', badge: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300' },
};

/* ─── Page ──────────────────────────────────────────── */
export default function PackagingOrdersPage() {
  const [filterStatus, setFilterStatus] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState({ product: '', packageType: '٥ كجم كيس', quantity: '', priority: 'normal', line: '', notes: '' });

  const todayOrders = ordersData.filter(o => o.date === '١٥/٠١/٢٠٢٥');
  const runningOrders = ordersData.filter(o => o.status === 'running');
  const completedOrders = ordersData.filter(o => o.status === 'completed');
  const urgentOrders = ordersData.filter(o => o.priority === 'urgent' && o.status !== 'completed' && o.status !== 'cancelled');

  const filteredData = useMemo(() => {
    if (filterStatus === 'all') return ordersData;
    return ordersData.filter(o => o.status === filterStatus);
  }, [filterStatus]);

  const columns = [
    { key: 'orderNumber', header: 'رقم الأمر', sortable: true, width: '120px' },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'packageType', header: 'نوع التعبئة', sortable: true },
    { key: 'qty', header: 'الكمية', sortable: true, width: '80px' },
    {
      key: 'priority',
      header: 'الأولوية',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => {
        const cfg = priorityConfig[row.priority as string];
        return <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${cfg.badge}`}>{cfg.label}</span>;
      },
    },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: Record<string, unknown>) => {
        const cfg = statusConfig[row.status as string];
        return <Badge variant={cfg.variant} className={cfg.color}>{cfg.label}</Badge>;
      },
    },
    { key: 'line', header: 'الخط' },
    { key: 'date', header: 'التاريخ', sortable: true },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="أوامر التعبئة" subtitle="إدارة أوامر تعبئة المنتجات النهائية" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'التعبئة' }, { label: 'أوامر التعبئة' }]}>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild><Button className="bg-green-700 hover:bg-green-800 text-white gap-1"><Plus size={16} /> أمر جديد</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>إنشاء أمر تعبئة</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>المنتج</Label>
                  <select value={formData.product} onChange={e => setFormData({ ...formData, product: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option value="">اختر</option><option>أرز مصري</option><option>عدس أصفر</option><option>عدس أخضر</option><option>فول مدمس</option><option>حمص مجروش</option><option>حمص كامل</option><option>لوبيا أبيض</option><option>لوبيا أحمر</option>
                  </select>
                </div>
                <div className="space-y-1.5"><Label>نوع التعبئة</Label>
                  <select value={formData.packageType} onChange={e => setFormData({ ...formData, packageType: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option>١ كجم سائب</option><option>٥ كجم كيس</option><option>٢٥ كجم شكاية</option><option>٥٠ كجم جوال</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>الكمية</Label><Input type="number" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} placeholder="عدد الأكياس" /></div>
                <div className="space-y-1.5"><Label>الأولوية</Label>
                  <select value={formData.priority} onChange={e => setFormData({ ...formData, priority: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option value="urgent">عاجل</option><option value="normal">عادي</option><option value="low">منخفض</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1.5"><Label>الخط</Label>
                <select value={formData.line} onChange={e => setFormData({ ...formData, line: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                  <option value="">اختر</option><option>خط تعبئة أرز ١</option><option>خط تعبئة عدس ١</option><option>خط تعبئة فول ١</option><option>خط تعبئة حمص ١</option><option>خط تعبئة لوبيا ١</option><option>خط تعبئة مختلط ١</option>
                </select>
              </div>
              <div className="space-y-1.5"><Label>ملاحظات</Label><textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} className="w-full h-16 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-green-500/30" placeholder="ملاحظات..." /></div>
              <div className="flex justify-end gap-2 pt-2"><Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button><Button className="bg-green-700 hover:bg-green-800 text-white">إنشاء الأمر</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="أوامر اليوم" value={String(todayOrders.length)} icon={ClipboardList} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="قيد التشغيل" value={String(runningOrders.length)} change={+1} icon={Clock} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.1} />
        <KPICard title="مكتملة" value={String(completedOrders.length)} change={+5} icon={CheckCircle2} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.2} />
        <KPICard title="عاجلة" value={String(urgentOrders.length)} icon={ArrowUpDown} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4">
        <Tabs value={filterStatus} onValueChange={setFilterStatus}>
          <TabsList className="h-9"><TabsTrigger value="all" className="text-xs">الكل</TabsTrigger><TabsTrigger value="scheduled" className="text-xs">مجدول</TabsTrigger><TabsTrigger value="running" className="text-xs">قيد التشغيل</TabsTrigger><TabsTrigger value="completed" className="text-xs">مكتمل</TabsTrigger><TabsTrigger value="cancelled" className="text-xs">ملغي</TabsTrigger></TabsList>
        </Tabs>
      </div>

      {/* Table */}
      <DataTable columns={columns} data={filteredData as unknown as Record<string, unknown>[] as Record<string, unknown>[]} title="أوامر التعبئة" rowActions={{ onView: () => {}, onEdit: () => {}, onDelete: () => {} }} />
    </div>
  );
}
