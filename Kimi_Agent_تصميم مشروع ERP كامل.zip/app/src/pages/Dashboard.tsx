import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ShoppingCart,
  TrendingUp,
  AlertTriangle,
  Users,
  Factory,
  Wallet,
  Building2,
  Plus,
  Truck,
  UserPlus,
  PackagePlus,
  CircleDot,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from 'recharts';
import KPICard from '@/components/KPICard';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import {
  kpiData,
  salesChartData,
  lowStockItems,
  salesDistribution,
  branchPerformance,
  recentTransactions,
  notifications,
  formatNumber,
} from '@/data/mockData';
import { cn } from '@/lib/utils';

// ─── Quick Action Button ─────────────────────────────────
function QuickAction({
  icon: Icon,
  label,
  color,
  path,
}: {
  icon: React.ElementType;
  label: string;
  color: string;
  path: string;
}) {
  const colorMap: Record<string, { bg: string; text: string; hover: string }> = {
    green: { bg: 'bg-green-50 dark:bg-green-950/30', text: 'text-green-700 dark:text-green-400', hover: 'hover:bg-green-100 dark:hover:bg-green-950/50' },
    gold: { bg: 'bg-gold-50 dark:bg-gold-950/30', text: 'text-gold-700 dark:text-gold-400', hover: 'hover:bg-gold-100 dark:hover:bg-gold-950/50' },
    blue: { bg: 'bg-blue-50 dark:bg-blue-950/30', text: 'text-blue-700 dark:text-blue-400', hover: 'hover:bg-blue-100 dark:hover:bg-blue-950/50' },
    purple: { bg: 'bg-purple-50 dark:bg-purple-950/30', text: 'text-purple-700 dark:text-purple-400', hover: 'hover:bg-purple-100 dark:hover:bg-purple-950/50' },
  };
  const c = colorMap[color] || colorMap.green;

  return (
    <Link
      to={path}
      className={cn(
        'flex flex-col items-center justify-center gap-2 h-20 rounded-xl border border-uiBorder dark:border-darkBorder transition-all duration-200',
        c.bg,
        c.hover
      )}
    >
      <Icon size={24} className={c.text} />
      <span className={cn('text-xs font-semibold', c.text)}>{label}</span>
    </Link>
  );
}

// ─── Status Badge ────────────────────────────────────────
function StatusBadge({ status, type }: { status: string; type: string }) {
  const styles: Record<string, string> = {
    success: 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400',
    warning: 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400',
    danger: 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400',
    info: 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400',
  };
  return (
    <span
      className={cn(
        'inline-flex px-2 py-0.5 rounded-full text-[11px] font-semibold',
        styles[type] || styles.info
      )}
    >
      {status}
    </span>
  );
}

// ─── Custom Recharts Tooltip ─────────────────────────────
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white dark:bg-darkSurface border border-uiBorder dark:border-darkBorder rounded-lg shadow-lg p-3 text-sm">
      <p className="text-textSecondary dark:text-darkTextSec mb-1">اليوم {label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="font-semibold" style={{ color: p.color }}>
          {p.name}: {formatNumber(p.value)} ج.م
        </p>
      ))}
    </div>
  );
}

// ─── Custom Pie Label ────────────────────────────────────
const RADIAN = Math.PI / 180;
function renderCustomLabel({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={12} fontWeight={700}>
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
}

// ─── Main Dashboard Page ─────────────────────────────────
export default function Dashboard() {
  const tableColumns = [
    { key: 'type', header: 'نوع العملية', sortable: true },
    { key: 'code', header: 'الرقم', sortable: true },
    { key: 'date', header: 'التاريخ', sortable: true },
    { key: 'party', header: 'العميل/مورد', sortable: true },
    { key: 'amount', header: 'المبلغ', sortable: true },
    {
      key: 'status',
      header: 'الحالة',
      sortable: true,
      render: (row: any) => <StatusBadge status={row.status} type={row.statusType} />,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <PageHeader
        title="لوحة التحكم"
        subtitle="نظرة شاملة على أداء الشركة"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'لوحة التحكم' },
        ]}
      >
        <span className="text-xs text-textMuted">
          الخميس، ١٥ يناير ٢٠٢٥
        </span>
      </PageHeader>

      {/* KPI Cards Row 1 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard
          title="إجمالي المبيعات اليوم"
          value={`${formatNumber(kpiData.dailySales)} ج.م`}
          change={12}
          changeLabel="عن الأمس"
          icon={ShoppingCart}
          iconBg="bg-green-100 dark:bg-green-900/30"
          iconColor="text-green-600 dark:text-green-400"
          delay={0}
        />
        <KPICard
          title="إيرادات الشهر الحالي"
          value={`${formatNumber(kpiData.monthlyRevenue)} ج.م`}
          change={8.5}
          icon={TrendingUp}
          iconBg="bg-gold-100 dark:bg-gold-900/30"
          iconColor="text-gold-600 dark:text-gold-400"
          delay={0.1}
        />
        <KPICard
          title="منتجات تحت الحد الأدنى"
          value={String(kpiData.lowStock)}
          icon={AlertTriangle}
          iconBg="bg-red-100 dark:bg-red-900/30"
          iconColor="text-red-600 dark:text-red-400"
          delay={0.2}
        />
        <KPICard
          title="عميل نشط هذا الشهر"
          value={String(kpiData.activeCustomers)}
          change={5.2}
          icon={Users}
          iconBg="bg-blue-100 dark:bg-blue-900/30"
          iconColor="text-blue-600 dark:text-blue-400"
          delay={0.3}
        />
      </div>

      {/* KPI Cards Row 2 */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard
          title="خطوط إنتاج نشطة"
          value={`${kpiData.activeProductionLines} قيد التشغيل`}
          icon={Factory}
          iconBg="bg-purple-100 dark:bg-purple-900/30"
          iconColor="text-purple-600 dark:text-purple-400"
          delay={0.4}
        />
        <KPICard
          title="مستحقات مستحقة"
          value={`${formatNumber(kpiData.pendingPayables)} ج.م`}
          change={-2.4}
          icon={Wallet}
          iconBg="bg-gold-100 dark:bg-gold-900/30"
          iconColor="text-gold-600 dark:text-gold-400"
          delay={0.5}
        />
        <KPICard
          title="عدد الفروع"
          value={String(kpiData.branchCount)}
          change={33.3}
          changeLabel="١ فرع جديد"
          icon={Building2}
          iconBg="bg-green-100 dark:bg-green-900/30"
          iconColor="text-green-600 dark:text-green-400"
          delay={0.6}
        />
      </div>

      {/* Charts Row 1: Area Chart + Low Stock */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Area Chart */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="lg:col-span-2 bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">
              تحليل المبيعات
            </h3>
            <div className="flex items-center gap-1 bg-surface dark:bg-darkCard rounded-lg p-0.5">
              {['يوم', 'أسبوع', 'شهر', 'سنة'].map((period, i) => (
                <button
                  key={period}
                  className={cn(
                    'px-3 py-1 rounded-md text-xs font-medium transition-all',
                    i === 2
                      ? 'bg-green-700 text-white'
                      : 'text-textSecondary dark:text-darkTextSec hover:text-textPrimary'
                  )}
                >
                  {period}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={350}>
            <AreaChart data={salesChartData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
              <defs>
                <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1bc47a" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#1bc47a" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis
                dataKey="day"
                tick={{ fontSize: 12, fill: '#64748b' }}
                axisLine={{ stroke: '#e2e8f0' }}
              />
              <YAxis
                tick={{ fontSize: 12, fill: '#64748b' }}
                axisLine={{ stroke: '#e2e8f0' }}
                tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="actual"
                name="المبيعات الفعلية"
                stroke="#1bc47a"
                strokeWidth={2}
                fill="url(#colorActual)"
              />
              <Area
                type="monotone"
                dataKey="target"
                name="المستهدف"
                stroke="#daa520"
                strokeWidth={2}
                strokeDasharray="5 5"
                fill="none"
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Low Stock Alerts */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">
              تنبيهات المخزون
            </h3>
            <Link
              to="/inventory"
              className="text-xs text-green-600 dark:text-green-400 hover:underline"
            >
              عرض الكل
            </Link>
          </div>
          <div className="space-y-3">
            {lowStockItems.map((item, index) => (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.7 + index * 0.08 }}
              >
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">
                      {item.name}
                    </p>
                    <p className="text-[11px] text-textMuted">{item.warehouse}</p>
                  </div>
                  <span
                    className={cn(
                      'text-sm font-bold',
                      item.percent < 35
                        ? 'text-red-600 dark:text-red-400'
                        : item.percent < 50
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-green-600 dark:text-green-400'
                    )}
                  >
                    {item.current}
                  </span>
                </div>
                <div className="h-2 bg-surface dark:bg-darkCard rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${item.percent}%` }}
                    transition={{ duration: 0.6, delay: 0.8 + index * 0.08 }}
                    className={cn(
                      'h-full rounded-full',
                      item.percent < 35
                        ? 'bg-red-500'
                        : item.percent < 50
                        ? 'bg-amber-500'
                        : 'bg-green-500'
                    )}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Charts Row 2: Doughnut + Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Doughnut Chart */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">
            توزيع المبيعات حسب القطاع
          </h3>
          <div className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={salesDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={renderCustomLabel}
                  outerRadius={110}
                  innerRadius={60}
                  dataKey="value"
                  animationBegin={800}
                  animationDuration={800}
                >
                  {salesDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: any) => [`${value}%`, '']}
                  contentStyle={{
                    background: 'var(--darkSurface, #1e293b)',
                    border: '1px solid var(--darkBorder, #475569)',
                    borderRadius: '8px',
                    color: '#f1f5f9',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap justify-center gap-4 mt-2">
            {salesDistribution.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-xs text-textSecondary dark:text-darkTextSec">
                  {item.name}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">
              أداء الفروع
            </h3>
            <select className="text-xs border border-uiBorder dark:border-darkBorder rounded-lg px-2 py-1 bg-surface dark:bg-darkCard text-textSecondary dark:text-darkTextSec focus:outline-none focus:ring-2 focus:ring-green-500/30">
              <option>هذا الشهر</option>
              <option>الشهر الماضي</option>
              <option>هذا الربع</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart
              data={branchPerformance}
              layout="vertical"
              margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
              <XAxis
                type="number"
                tick={{ fontSize: 12, fill: '#64748b' }}
                tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`}
              />
              <YAxis
                type="category"
                dataKey="name"
                tick={{ fontSize: 12, fill: '#64748b' }}
                width={70}
              />
              <Tooltip
                formatter={(value: any) => [formatNumber(value) + ' ج.م', 'المبيعات']}
                contentStyle={{
                  background: 'var(--darkSurface, #1e293b)',
                  border: '1px solid var(--darkBorder, #475569)',
                  borderRadius: '8px',
                  color: '#f1f5f9',
                }}
              />
              <Bar dataKey="sales" fill="#1bc47a" radius={[4, 4, 4, 4]} />
              <Bar dataKey="target" fill="#daa520" radius={[4, 4, 4, 4]} barSize={6} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Recent Transactions Table */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.9 }}
      >
        <DataTable
          columns={tableColumns}
          data={recentTransactions}
          title="آخر العمليات"
          pageSize={5}
          rowActions={{
            onView: (row) => console.log('View', row),
            onEdit: (row) => console.log('Edit', row),
          }}
        />
      </motion.div>

      {/* Quick Actions + Notifications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 1.0 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">
            إجراءات سريعة
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <QuickAction
              icon={Plus}
              label="فاتورة مبيعات جديدة"
              color="green"
              path="/sales"
            />
            <QuickAction
              icon={Truck}
              label="أمر شراء جديد"
              color="gold"
              path="/purchases"
            />
            <QuickAction
              icon={UserPlus}
              label="إضافة عميل"
              color="blue"
              path="/customers"
            />
            <QuickAction
              icon={PackagePlus}
              label="إضافة منتج"
              color="purple"
              path="/inventory/products"
            />
          </div>
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 1.1 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">
              الإشعارات
            </h3>
            <span className="px-2 py-0.5 bg-red-100 dark:bg-red-950/40 text-red-700 dark:text-red-400 text-[11px] font-semibold rounded-full">
              {notifications.length} جديد
            </span>
          </div>
          <div className="space-y-3">
            {notifications.map((n, i) => (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 1.2 + i * 0.06 }}
                className="flex items-start gap-3"
              >
                <CircleDot
                  size={10}
                  className={cn(
                    'mt-1.5 shrink-0',
                    n.type === 'danger' && 'text-red-500',
                    n.type === 'warning' && 'text-amber-500',
                    n.type === 'success' && 'text-green-500',
                    n.type === 'info' && 'text-blue-500'
                  )}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-textPrimary dark:text-darkText leading-relaxed">
                    {n.text}
                  </p>
                  <p className="text-[11px] text-textMuted mt-0.5">{n.time}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
