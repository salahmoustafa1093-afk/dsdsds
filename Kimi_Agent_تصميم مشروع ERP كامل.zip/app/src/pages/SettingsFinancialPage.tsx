import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Receipt, Percent, Hash, CreditCard, Building2,
  Save, Check, Plus, Trash2
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';

const paymentTerms = [
  { id: 1, name: 'نقدي', days: 0, isDefault: true },
  { id: 2, name: 'آجل 15 يوم', days: 15, isDefault: false },
  { id: 3, name: 'آجل 30 يوم', days: 30, isDefault: false },
  { id: 4, name: 'آجل 60 يوم', days: 60, isDefault: false },
  { id: 5, name: 'آجل 90 يوم', days: 90, isDefault: false },
];

const bankAccounts = [
  { id: 1, bank: 'CIB بنك مصر', accountName: 'Golden Farmonia Fidex', accountNumber: '1234-5678-9012', iban: 'EG85 1234 5678 9012 3456 7890 1234', currency: 'EGP', isDefault: true },
  { id: 2, bank: 'QNB الأهلي', accountName: 'Golden Farmonia Fidex', accountNumber: '9876-5432-1098', iban: 'EG85 9876 5432 1098 7654 3210 9876', currency: 'EGP', isDefault: false },
];

export default function SettingsFinancialPage() {
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<'tax' | 'payment' | 'invoice' | 'currency' | 'banks'>('tax');

  /* Tax settings */
  const [vatRate, setVatRate] = useState(14);
  const [taxRegNumber, setTaxRegNumber] = useState('123-456-789');
  const [taxAuthority, setTaxAuthority] = useState('مصلحة الضرائب المصرية - القاهرة');

  /* Invoice numbering */
  const [invoicePrefix, setInvoicePrefix] = useState('INV');
  const [invoiceStart, setInvoiceStart] = useState(1000);
  const [autoIncrement, setAutoIncrement] = useState(true);

  /* Currency settings */
  const [baseCurrency, setBaseCurrency] = useState('EGP');
  const [decimalPlaces, setDecimalPlaces] = useState(2);
  const [rounding, setRounding] = useState('أقرب');

  /* Bank accounts list */
  const [banks, setBanks] = useState(bankAccounts);
  const [showBankForm, setShowBankForm] = useState(false);
  const [newBankName, setNewBankName] = useState('');
  const [newAccountNumber, setNewAccountNumber] = useState('');
  const [newIban, setNewIban] = useState('');

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const addBank = () => {
    if (!newBankName || !newAccountNumber) return;
    setBanks([...banks, {
      id: Date.now(),
      bank: newBankName,
      accountName: 'Golden Farmonia Fidex',
      accountNumber: newAccountNumber,
      iban: newIban || '—',
      currency: 'EGP',
      isDefault: false,
    }]);
    setNewBankName('');
    setNewAccountNumber('');
    setNewIban('');
    setShowBankForm(false);
  };

  const removeBank = (id: number) => {
    setBanks(banks.filter((b) => b.id !== id));
  };

  const tabs = [
    { key: 'tax' as const, label: 'الإعدادات الضريبية', icon: Percent },
    { key: 'payment' as const, label: 'شروط الدفع', icon: Receipt },
    { key: 'invoice' as const, label: 'ترقيم الفواتير', icon: Hash },
    { key: 'currency' as const, label: 'إعدادات العملة', icon: CreditCard },
    { key: 'banks' as const, label: 'الحسابات البنكية', icon: Building2 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="الإعدادات المالية"
        subtitle="الضرائب وشروط الدفع وترقيم الفواتير"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الإعدادات', path: '/settings' },
          { label: 'مالية' },
        ]}
      >
        <button onClick={handleSave} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">
          {saved ? <Check size={16} /> : <Save size={16} />}
          <span>{saved ? 'تم الحفظ' : 'حفظ'}</span>
        </button>
      </PageHeader>

      {/* Tabs */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-1 flex gap-1 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              activeTab === tab.key
                ? 'bg-green-700 text-white'
                : 'text-textSecondary hover:text-textPrimary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard'
            }`}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tax Settings */}
      {activeTab === 'tax' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-2">الإعدادات الضريبية</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-textSecondary mb-1 block">نسبة ضريبة القيمة المضافة (%)</label>
              <input type="number" value={vatRate} onChange={(e) => setVatRate(Number(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">الرقم الضريبي</label>
              <input value={taxRegNumber} onChange={(e) => setTaxRegNumber(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">السلطة الضريبية</label>
              <input value={taxAuthority} onChange={(e) => setTaxAuthority(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
          </div>
        </motion.div>
      )}

      {/* Payment Terms */}
      {activeTab === 'payment' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-2">شروط الدفع</h3>
          <div className="space-y-2">
            {paymentTerms.map((term) => (
              <div key={term.id} className="flex items-center justify-between p-3 rounded-lg bg-surface dark:bg-darkCard">
                <div className="flex items-center gap-3">
                  <span className={`w-4 h-4 rounded-full border-2 ${term.isDefault ? 'border-green-600 bg-green-600' : 'border-uiBorder dark:border-darkBorder'}`} />
                  <span className="text-sm font-medium text-textPrimary dark:text-darkText">{term.name}</span>
                  <span className="text-xs text-textMuted">{term.days} يوم</span>
                </div>
                {term.isDefault && <span className="text-xs bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400 px-2 py-0.5 rounded-full">افتراضي</span>}
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Invoice Numbering */}
      {activeTab === 'invoice' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-2">ترقيم الفواتير</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-textSecondary mb-1 block">البادئة</label>
              <input value={invoicePrefix} onChange={(e) => setInvoicePrefix(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">رقم البداية</label>
              <input type="number" value={invoiceStart} onChange={(e) => setInvoiceStart(Number(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div className="flex items-end">
              <div className="flex items-center justify-between w-full p-3 rounded-lg bg-surface dark:bg-darkCard">
                <span className="text-sm text-textSecondary">ترقيم تلقائي</span>
                <button
                  onClick={() => setAutoIncrement(!autoIncrement)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${autoIncrement ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'}`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${autoIncrement ? 'right-0.5' : 'left-0.5'}`} />
                </button>
              </div>
            </div>
          </div>
          <div className="p-3 rounded-lg bg-surface dark:bg-darkCard">
            <p className="text-sm text-textSecondary">معاينة: <span className="font-medium text-textPrimary dark:text-darkText">{invoicePrefix}-2025-{invoiceStart}</span></p>
          </div>
        </motion.div>
      )}

      {/* Currency Settings */}
      {activeTab === 'currency' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-2">إعدادات العملة</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-textSecondary mb-1 block">العملة الأساسية</label>
              <select value={baseCurrency} onChange={(e) => setBaseCurrency(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                <option value="EGP">جنيه مصري (EGP)</option>
                <option value="USD">دولار أمريكي (USD)</option>
                <option value="SAR">ريال سعودي (SAR)</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">المنازل العشرية</label>
              <select value={decimalPlaces} onChange={(e) => setDecimalPlaces(Number(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                <option value={0}>0</option>
                <option value={2}>2</option>
                <option value={3}>3</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">طريقة التقريب</label>
              <select value={rounding} onChange={(e) => setRounding(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                <option>أقرب</option>
                <option>للأعلى</option>
                <option>للأسفل</option>
              </select>
            </div>
          </div>
        </motion.div>
      )}

      {/* Bank Accounts */}
      {activeTab === 'banks' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">الحسابات البنكية</h3>
            <button onClick={() => setShowBankForm(!showBankForm)} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-700 hover:bg-green-800 text-white text-xs font-medium transition-colors">
              <Plus size={14} />
              إضافة
            </button>
          </div>

          {showBankForm && (
            <div className="p-4 rounded-lg bg-surface dark:bg-darkCard border border-uiBorder dark:border-darkBorder space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input value={newBankName} onChange={(e) => setNewBankName(e.target.value)} placeholder="اسم البنك" className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkSurface text-textPrimary dark:text-darkText text-sm" />
                <input value={newAccountNumber} onChange={(e) => setNewAccountNumber(e.target.value)} placeholder="رقم الحساب" className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkSurface text-textPrimary dark:text-darkText text-sm" />
                <input value={newIban} onChange={(e) => setNewIban(e.target.value)} placeholder="IBAN" className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkSurface text-textPrimary dark:text-darkText text-sm" />
              </div>
              <div className="flex justify-end gap-2">
                <button onClick={() => setShowBankForm(false)} className="px-3 py-1.5 rounded-lg border border-uiBorder dark:border-darkBorder text-xs text-textSecondary">إلغاء</button>
                <button onClick={addBank} className="px-3 py-1.5 rounded-lg bg-green-700 hover:bg-green-800 text-white text-xs font-medium">إضافة</button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {banks.map((bank) => (
              <div key={bank.id} className="flex items-center justify-between p-4 rounded-lg bg-surface dark:bg-darkCard">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <Building2 size={18} className="text-green-700 dark:text-green-400" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-textPrimary dark:text-darkText">{bank.bank}</p>
                      {bank.isDefault && <span className="text-[10px] bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400 px-1.5 py-0.5 rounded-full">افتراضي</span>}
                    </div>
                    <p className="text-xs text-textSecondary">{bank.accountNumber}</p>
                    <p className="text-[10px] text-textMuted">{bank.iban}</p>
                  </div>
                </div>
                <button onClick={() => removeBank(bank.id)} className="w-8 h-8 rounded-lg flex items-center justify-center text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
