// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import {
  RotateCcw,
  TrendingDown,
  Clock,
  DollarSign,
  Search,
  Plus,
  Eye,
  Edit3,
  Trash2,
  XCircle,
  AlertTriangle,
  PackageX,
  FileText,
  ChevronDown,
  Filter,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

/* ──────────────────────────── mock data ──────────────────────────── */

interface ReturnItem {
  id: string;
  number: string;
  originalInvoice: string;
  date: string;
  customer: string;
  product: string;
  qty: number;
  unit: string;
  reason: 'damaged' | 'wrong' | 'mismatch' | 'other';
  reasonNote: string;
  value: number;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  branch: string;
}

const RETURNS: ReturnItem[] = [
  { id: '1', number: 'RET-001', originalInvoice: 'INV-006', date: '2025-06-20', customer: 'مزارع السلام', product: 'ردة قمح', qty: 20, unit: 'شيكارة', reason: 'damaged', reasonNote: 'منتج تالف بسبب الرطوبة', value: 5000, status: 'pending', branch: 'المنصورة' },
  { id: '2', number: 'RET-002', originalInvoice: 'INV-003', date: '2025-06-19', customer: 'مزرعة الفيوم', product: 'أعلاف دواجن ناهي', qty: 5, unit: 'شيكارة', reason: 'wrong', reasonNote: 'خطأ في التسليم - صنف خاطئ', value: 3750, status: 'approved', branch: 'القاهرة' },
  { id: '3', number: 'RET-003', originalInvoice: 'INV-011', date: '2025-06-18', customer: 'مزارع التوفيق', product: 'أعلاف دواجن بادئ', qty: 10, unit: 'شيكارة', reason: 'mismatch', reasonNote: 'المنتج لا يطابق المواصفات المطلوبة', value: 4500, status: 'completed', branch: 'القاهرة' },
  { id: '4', number: 'RET-004', originalInvoice: 'INV-015', date: '2025-06-18', customer: 'شركة الفلاح للمواشي', product: 'كسب فول صويا', qty: 15, unit: 'طن', reason: 'damaged', reasonNote: 'تلف أثناء النقل', value: 21000, status: 'pending', branch: 'المنصورة' },
  { id: '5', number: 'RET-005', originalInvoice: 'INV-002', date: '2025-06-17', customer: 'شركة النور للتسويق', product: 'ردة قمح', qty: 8, unit: 'طن', reason: 'other', reasonNote: 'تغيير في الطلب - لم نعد بحاجة الكمية', value: 3200, status: 'approved', branch: 'الإسكندرية' },
  { id: '6', number: 'RET-006', originalInvoice: 'INV-008', date: '2025-06-17', customer: 'مزرعة الجزيرة', product: 'أعلاف دواجن نامي', qty: 12, unit: 'شيكارة', reason: 'wrong', reasonNote: 'خطأ في الفاتورة الأصلية', value: 8160, status: 'rejected', branch: 'القاهرة' },
  { id: '7', number: 'RET-007', originalInvoice: 'INV-004', date: '2025-06-16', customer: 'مطاحن الأمل', product: 'ذرة صفراء', qty: 25, unit: 'طن', reason: 'mismatch', reasonNote: 'جودة أقل من المتفق عليها', value: 20000, status: 'pending', branch: 'طنطا' },
  { id: '8', number: 'RET-008', originalInvoice: 'INV-013', date: '2025-06-16', customer: 'مزرعة الهنا', product: 'أعلاف دواجن نامي', qty: 8, unit: 'شيكارة', reason: 'damaged', reasonNote: 'عبوات مكسورة', value: 4800, status: 'completed', branch: 'القاهرة' },
  { id: '9', number: 'RET-009', originalInvoice: 'INV-014', date: '2025-06-15', customer: 'مطاحن البركة', product: 'ردة قمح', qty: 30, unit: 'شيكارة', reason: 'other', reasonNote: 'إرجاع فائض عن الطلب', value: 7500, status: 'approved', branch: 'طنطا' },
  { id: '10', number: 'RET-010', originalInvoice: 'INV-012', date: '2025-06-14', customer: 'شركة الأمانة للتجارة', product: 'كسب فول صويا', qty: 20, unit: 'طن', reason: 'mismatch', reasonNote: 'نسبة بروتين أقل من 44%', value: 28000, status: 'pending', branch: 'الإسكندرية' },
];

const REASON_MAP: Record<string, { label: string; color: string; bg: string; icon: any }> = {
  damaged: { label: 'تالف', color: 'text-red-700', bg: 'bg-red-100 dark:bg-red-900/30', icon: PackageX },
  wrong: { label: 'خطأ', color: 'text-blue-700', bg: 'bg-blue-100 dark:bg-blue-900/30', icon: XCircle },
  mismatch: { label: 'غير مطابق', color: 'text-amber-700', bg: 'bg-amber-100 dark:bg-amber-900/30', icon: AlertTriangle },
  other: { label: 'أخرى', color: 'text-gray-700', bg: 'bg-gray-100 dark:bg-gray-900/30', icon: FileText },
};

const STATUS_MAP: Record<string, { label: string; color: string; bg: string }> = {
  pending: { label: 'معلق', color: 'text-amber-700', bg: 'bg-amber-100 dark:bg-amber-900/30' },
  approved: { label: 'معتمد', color: 'text-blue-700', bg: 'bg-blue-100 dark:bg-blue-900/30' },
  rejected: { label: 'مرفوض', color: 'text-red-700', bg: 'bg-red-100 dark:bg-red-900/30' },
  completed: { label: 'مكتمل', color: 'text-green-700', bg: 'bg-green-100 dark:bg-green-900/30' },
};

const INVOICES = [
  { id: 'INV-001', customer: 'مزارع الصفا للدواجن', products: ['أعلاف دواجن بادئ', 'ذرة صفراء'] },
  { id: 'INV-002', customer: 'شركة النور للتسويق', products: ['كسب فول صويا', 'ردة قمح'] },
  { id: 'INV-003', customer: 'مزرعة الفيوم', products: ['أعلاف دواجن ناهي'] },
  { id: 'INV-004', customer: 'مطاحن الأمل', products: ['ذرة صفراء'] },
  { id: 'INV-005', customer: 'شركة البديع للدواجن', products: ['أعلاف دواجن بادئ', 'أعلاف دواجن نامي', 'كسب فول صويا'] },
  { id: 'INV-006', customer: 'مزارع السلام', products: ['ردة قمح'] },
  { id: 'INV-007', customer: 'شركة البركة للتجارة', products: ['كسب فول صويا'] },
  { id: 'INV-008', customer: 'مزرعة الجزيرة', products: ['أعلاف دواجن نامي'] },
  { id: 'INV-009', customer: 'مطاحن النصر', products: ['ذرة صفراء'] },
  { id: 'INV-010', customer: 'شركة الرحمة للتسويق', products: ['أعلاف دواجن ناهي', 'ردة قمح'] },
  { id: 'INV-011', customer: 'مزارع التوفيق', products: ['أعلاف دواجن بادئ'] },
  { id: 'INV-012', customer: 'شركة الأمانة للتجارة', products: ['كسب فول صويا', 'ذرة صفراء'] },
  { id: 'INV-013', customer: 'مزرعة الهنا', products: ['أعلاف دواجن نامي'] },
  { id: 'INV-014', customer: 'مطاحن البركة', products: ['ردة قمح'] },
  { id: 'INV-015', customer: 'شركة الفلاح للمواشي', products: ['أعلاف دواجن بادئ', 'كسب فول صويا', 'ذرة صفراء'] },
];

/* ──────────────────────────── component ──────────────────────────── */

export default function SalesReturnsPage() {
  const [returns, setReturns] = useState<ReturnItem[]>(RETURNS);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [reasonFilter, setReasonFilter] = useState('all');
  const [page, setPage] = useState(1);

  const pageSize = 8;

  const filtered = useMemo(() => {
    return returns.filter((r) => {
      const q = search.trim();
      const matchSearch = q === '' || r.number.includes(q) || r.customer.includes(q) || r.product.includes(q) || r.originalInvoice.includes(q);
      const matchStatus = statusFilter === 'all' || r.status === statusFilter;
      const matchReason = reasonFilter === 'all' || r.reason === reasonFilter;
      return matchSearch && matchStatus && matchReason;
    });
  }, [returns, search, statusFilter, reasonFilter]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const totalReturns = returns.length;
  const todayReturns = returns.filter((r) => r.date === '2025-06-20').length;
  const returnsValue = returns.reduce((s, r) => s + r.value, 0);

  const resetFilters = () => {
    setSearch('');
    setStatusFilter('all');
    setReasonFilter('all');
    setPage(1);
  };

  const deleteReturn = (id: string) => {
    setReturns((prev) => prev.filter((r) => r.id !== id));
  };

  const handleCreate = (newR: ReturnItem) => {
    setReturns((prev) => [newR, ...prev]);
  };

  const formatEGP = (n: number) => n.toLocaleString('ar-EG') + ' ج.م';

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="مرتجعات المبيعات"
        subtitle="إدارة مرتجعات العملاء"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'المبيعات', path: '/sales' }, { label: 'مرتجعات' }]}
      >
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-[#0a4a30] hover:bg-[#0d6b43] text-white gap-2">
              <Plus size={16} />
              مرتجع جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-right text-lg">تسجيل مرتجع جديد</DialogTitle>
            </DialogHeader>
            <ReturnForm onSave={handleCreate} />
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="إجمالي المرتجعات" value={totalReturns.toString()} icon={RotateCcw} iconBg="bg-red-100" iconColor="text-red-600" change={-5} delay={0} />
        <KPICard title="مرتجعات اليوم" value={todayReturns.toString()} icon={Clock} iconBg="bg-amber-100" iconColor="text-amber-600" change={2} delay={0.1} />
        <KPICard title="قيمة المرتجعات" value={formatEGP(returnsValue)} icon={DollarSign} iconBg="bg-red-100" iconColor="text-red-600" change={12} delay={0.2} />
      </div>

      {/* Filters */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <Input
                placeholder="بحث برقم المرتجع أو الفاتورة أو العميل..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                className="pr-9 text-right"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 text-right text-xs"><SelectValue placeholder="الحالة" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الحالات</SelectItem>
                <SelectItem value="pending">معلق</SelectItem>
                <SelectItem value="approved">معتمد</SelectItem>
                <SelectItem value="rejected">مرفوض</SelectItem>
                <SelectItem value="completed">مكتمل</SelectItem>
              </SelectContent>
            </Select>
            <Select value={reasonFilter} onValueChange={setReasonFilter}>
              <SelectTrigger className="w-36 text-right text-xs"><SelectValue placeholder="السبب" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الأسباب</SelectItem>
                <SelectItem value="damaged">تالف</SelectItem>
                <SelectItem value="wrong">خطأ</SelectItem>
                <SelectItem value="mismatch">غير مطابق</SelectItem>
                <SelectItem value="other">أخرى</SelectItem>
              </SelectContent>
            </Select>
            {(statusFilter !== 'all' || reasonFilter !== 'all' || search) && (
              <Button variant="ghost" size="sm" className="text-red-500 text-xs" onClick={resetFilters}>
                <X size={12} />
                إلغاء
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border border-gray-200 dark:border-gray-700 overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                  <TableHead className="text-right font-semibold text-xs">رقم المرتجع</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الفاتورة الأصلية</TableHead>
                  <TableHead className="text-right font-semibold text-xs">التاريخ</TableHead>
                  <TableHead className="text-right font-semibold text-xs">العميل</TableHead>
                  <TableHead className="text-right font-semibold text-xs">المنتج</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الكمية</TableHead>
                  <TableHead className="text-right font-semibold text-xs">السبب</TableHead>
                  <TableHead className="text-right font-semibold text-xs">القيمة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الحالة</TableHead>
                  <TableHead className="text-center font-semibold text-xs">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.map((r) => {
                  const rm = REASON_MAP[r.reason];
                  const sm = STATUS_MAP[r.status];
                  return (
                    <TableRow key={r.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                      <TableCell className="font-mono text-xs font-medium">{r.number}</TableCell>
                      <TableCell className="text-xs text-gray-500">{r.originalInvoice}</TableCell>
                      <TableCell className="text-xs text-gray-500">{r.date}</TableCell>
                      <TableCell className="text-sm font-medium">{r.customer}</TableCell>
                      <TableCell className="text-sm">{r.product}</TableCell>
                      <TableCell className="text-sm">{r.qty} {r.unit}</TableCell>
                      <TableCell>
                        <Badge className={cn('text-[10px] border-0 gap-1', rm.bg, rm.color)}>
                          {rm.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm font-semibold text-red-600">{formatEGP(r.value)}</TableCell>
                      <TableCell>
                        <Badge className={cn('text-[10px] border-0', sm.bg, sm.color)}>
                          {sm.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600">
                            <Eye size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600">
                            <Edit3 size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => deleteReturn(r.id)}>
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {paged.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-12 text-gray-400">
                      لا توجد مرتجعات مطابقة
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {/* Pagination */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 dark:border-gray-700">
            <span className="text-xs text-gray-500">
              عرض {filtered.length > 0 ? (page - 1) * pageSize + 1 : 0} - {Math.min(page * pageSize, filtered.length)} من {filtered.length}
            </span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(1)}>الأولى</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(page - 1)}>السابق</Button>
              <span className="text-xs px-2">{page} / {totalPages}</span>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(page + 1)}>التالي</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(totalPages)}>الأخيرة</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ──────────────────────────── Return Form ──────────────────────────── */

function ReturnForm({ onSave }: { onSave: (r: ReturnItem) => void }) {
  const [invoice, setInvoice] = useState('');
  const [product, setProduct] = useState('');
  const [qty, setQty] = useState(1);
  const [reason, setReason] = useState<'damaged' | 'wrong' | 'mismatch' | 'other'>('damaged');
  const [reasonNote, setReasonNote] = useState('');
  const [value, setValue] = useState(0);

  const selectedInv = INVOICES.find((i) => i.id === invoice);

  const handleSubmit = () => {
    onSave({
      id: Date.now().toString(),
      number: `RET-${String(RETURNS.length + 1).padStart(3, '0')}`,
      originalInvoice: invoice || '-',
      date: new Date().toISOString().split('T')[0],
      customer: selectedInv?.customer || 'عميل جديد',
      product: product || 'منتج',
      qty,
      unit: 'شيكارة',
      reason,
      reasonNote,
      value: Number(value),
      status: 'pending',
      branch: 'القاهرة',
    });
  };

  return (
    <div className="space-y-3" dir="rtl">
      <div>
        <Label className="text-xs">الفاتورة الأصلية</Label>
        <Select value={invoice} onValueChange={(v) => { setInvoice(v); setProduct(''); }}>
          <SelectTrigger className="text-right"><SelectValue placeholder="اختر الفاتورة" /></SelectTrigger>
          <SelectContent>
            {INVOICES.map((i) => <SelectItem key={i.id} value={i.id}>{i.id} — {i.customer}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {selectedInv && (
        <div className="bg-gray-50 p-2 rounded text-xs text-gray-600">
          العميل: <strong>{selectedInv.customer}</strong>
        </div>
      )}
      <div>
        <Label className="text-xs">المنتج</Label>
        <Select value={product} onValueChange={setProduct}>
          <SelectTrigger className="text-right"><SelectValue placeholder="اختر المنتج" /></SelectTrigger>
          <SelectContent>
            {(selectedInv?.products || []).map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">الكمية</Label>
          <Input type="number" value={qty} onChange={(e) => setQty(parseInt(e.target.value) || 0)} className="text-center" />
        </div>
        <div>
          <Label className="text-xs">القيمة</Label>
          <Input type="number" value={value} onChange={(e) => setValue(parseFloat(e.target.value) || 0)} className="text-center" />
        </div>
      </div>
      <div>
        <Label className="text-xs">سبب المرتجع</Label>
        <Select value={reason} onValueChange={(v) => setReason(v as any)}>
          <SelectTrigger className="text-right"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="damaged">تالف</SelectItem>
            <SelectItem value="wrong">خطأ في التسليم</SelectItem>
            <SelectItem value="mismatch">غير مطابق للمواصفات</SelectItem>
            <SelectItem value="other">أخرى</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-xs">ملاحظات إضافية</Label>
        <textarea value={reasonNote} onChange={(e) => setReasonNote(e.target.value)} className="w-full border rounded-md p-2 text-xs text-right min-h-[60px]" placeholder="تفاصيل إضافية عن سبب المرتجع..." />
      </div>
      <Button onClick={handleSubmit} className="w-full bg-[#0a4a30] hover:bg-[#0d6b43] text-white">
        تسجيل المرتجع
      </Button>
    </div>
  );
}
