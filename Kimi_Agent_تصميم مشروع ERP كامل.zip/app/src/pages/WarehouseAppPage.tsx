import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Warehouse,
  User,
  ScanBarcode,
  Package,
  CheckCircle2,
  Truck,
  ClipboardList,
  ArrowLeftRight,
  Home,
  Inbox,
  ListChecks,
  UploadCloud,
  Camera,
  PenTool,
  Printer,
  ChevronRight,
  Check,
  AlertTriangle,
  Search,
  Plus,
  Minus,
  QrCode,
  Box,
  MapPin,
  Weight,
  FileText,
  BadgeCheck,
  Barcode,
  X,
  Save,
  RotateCcw,
  Send,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface ReceivingItem {
  id: string;
  product: string;
  qtyExpected: number;
  qtyReceived: number;
  condition: 'جيد' | 'تالف' | 'ناقص';
  notes: string;
  photo?: string;
}

interface PickingItem {
  id: string;
  product: string;
  qty: number;
  picked: number;
  location: string;
  done: boolean;
}

interface TransferReq {
  id: string;
  from: string;
  to: string;
  product: string;
  qty: number;
  status: 'معلقة' | 'قيد التنفيذ' | 'مكتملة';
}

interface CountItem {
  id: string;
  product: string;
  location: string;
  expected: number;
  actual: number;
  variance: number;
}

/* ------------------------------------------------------------------ */
/*  Mock Data                                                          */
/* ------------------------------------------------------------------ */
const initialReceiving: ReceivingItem[] = [
  { id: 'R-001', product: 'علف دواجن بادئ 25كجم', qtyExpected: 200, qtyReceived: 200, condition: 'جيد', notes: '' },
  { id: 'R-002', product: 'ذرة صفراء مكسرة', qtyExpected: 500, qtyReceived: 495, condition: 'ناقص', notes: 'نقص 5 كجم' },
  { id: 'R-003', product: 'كسب صويا 48%', qtyExpected: 300, qtyReceived: 300, condition: 'جيد', notes: '' },
];

const initialPicking: PickingItem[] = [
  { id: 'P-001', product: 'علف دواجن بادئ 25كجم', qty: 20, picked: 20, location: 'A-12-3-5', done: true },
  { id: 'P-002', product: 'علف ناهي 25كجم', qty: 15, picked: 15, location: 'A-12-3-6', done: true },
  { id: 'P-003', product: 'ذرة صفراء', qty: 50, picked: 30, location: 'B-05-1-2', done: false },
  { id: 'P-004', product: 'كسب صويا', qty: 25, picked: 0, location: 'B-05-1-3', done: false },
  { id: 'P-005', product: 'ردة ناعمة', qty: 40, picked: 0, location: 'C-08-2-1', done: false },
];

const loadingList = [
  { id: 'L-001', product: 'علف دواجن بادئ 25كجم', qty: 50, weight: 1250 },
  { id: 'L-002', product: 'علف ناهي 25كجم', qty: 30, weight: 750 },
  { id: 'L-003', product: 'ذرة صفراء مكسرة', qty: 100, weight: 1000 },
  { id: 'L-004', product: 'كسب صويا', qty: 75, weight: 750 },
  { id: 'L-005', product: 'ردة ناعمة', qty: 50, weight: 500 },
];

const initialCounts: CountItem[] = [
  { id: 'C-001', product: 'علف دواجن بادئ 25كجم', location: 'A-12-3-5', expected: 200, actual: 198, variance: -2 },
  { id: 'C-002', product: 'ذرة صفراء مكسرة', location: 'B-05-1-2', expected: 500, actual: 502, variance: 2 },
  { id: 'C-003', product: 'كسب صويا 48%', location: 'B-05-1-3', expected: 300, actual: 300, variance: 0 },
];

const transferRequests: TransferReq[] = [
  { id: 'TR-001', from: 'مستودع القاهرة الرئيسي', to: 'مستودع الجيزة', product: 'علف بادئ 25كجم', qty: 100, status: 'معلقة' },
  { id: 'TR-002', from: 'مستودع الإسكندرية', to: 'مستودع كفر الشيخ', product: 'ذرة صفراء', qty: 250, status: 'قيد التنفيذ' },
  { id: 'TR-003', from: 'مستودع طنطا', to: 'مستودع القاهرة', product: 'كسب صويا', qty: 150, status: 'مكتملة' },
  { id: 'TR-004', from: 'مستودع القاهرة', to: 'مستودع المنصورة', product: 'علف ناهي 25كجم', qty: 80, status: 'معلقة' },
];

/* ------------------------------------------------------------------ */
/*  Helper Components                                                  */
/* ------------------------------------------------------------------ */
function ConditionBadge({ condition }: { condition: ReceivingItem['condition'] }) {
  const map: Record<string, string> = {
    'جيد': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'تالف': 'bg-red-50 text-red-700 border-red-200',
    'ناقص': 'bg-amber-50 text-amber-700 border-amber-200',
  };
  return (
    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${map[condition]}`}>
      {condition}
    </span>
  );
}

function TransferStatusBadge({ status }: { status: TransferReq['status'] }) {
  const map: Record<string, string> = {
    'معلقة': 'bg-amber-50 text-amber-700 border-amber-200',
    'قيد التنفيذ': 'bg-blue-50 text-blue-700 border-blue-200',
    'مكتملة': 'bg-emerald-50 text-emerald-700 border-emerald-200',
  };
  return (
    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${map[status]}`}>
      {status}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Page Component                                                */
/* ------------------------------------------------------------------ */
export default function WarehouseAppPage() {
  const [activeTab, setActiveTab] = useState<'home' | 'receive' | 'pick' | 'load' | 'count'>('home');

  /* receiving state */
  const [receiving, setReceiving] = useState<ReceivingItem[]>(initialReceiving);
  const [recvForm, setRecvForm] = useState({ supplier: '', poRef: '', product: '', qtyExpected: '', qtyReceived: '', condition: 'جيد' as ReceivingItem['condition'], notes: '' });
  const [scanMode, setScanMode] = useState(false);

  /* picking state */
  const [picking, setPicking] = useState<PickingItem[]>(initialPicking);

  /* counting state */
  const [counts, setCounts] = useState<CountItem[]>(initialCounts);
  const [countForm, setCountForm] = useState({ barcode: '', product: '', location: '', expected: '', actual: '' });

  /* loading state */
  const [driverSigned, setDriverSigned] = useState(false);
  const [loaded, setLoaded] = useState(false);

  /* derived */
  const pickedCount = picking.filter((p) => p.done).length;
  const pickProgress = (pickedCount / picking.length) * 100;
  const totalLoadingWeight = loadingList.reduce((s, i) => s + i.weight, 0);

  /* -- actions -- */
  const addReceivingItem = () => {
    if (!recvForm.product || !recvForm.qtyReceived) return;
    const newItem: ReceivingItem = {
      id: `R-${String(receiving.length + 1).padStart(3, '0')}`,
      product: recvForm.product,
      qtyExpected: Number(recvForm.qtyExpected) || 0,
      qtyReceived: Number(recvForm.qtyReceived),
      condition: recvForm.condition,
      notes: recvForm.notes,
    };
    setReceiving((p) => [newItem, ...p]);
    setRecvForm({ supplier: '', poRef: '', product: '', qtyExpected: '', qtyReceived: '', condition: 'جيد', notes: '' });
  };

  const togglePick = (id: string) => {
    setPicking((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const newDone = !p.done;
          return { ...p, done: newDone, picked: newDone ? p.qty : 0 };
        }
        return p;
      })
    );
  };

  const submitCount = () => {
    if (!countForm.product || !countForm.actual) return;
    const exp = Number(countForm.expected) || 0;
    const act = Number(countForm.actual);
    const newCount: CountItem = {
      id: `C-${String(counts.length + 1).padStart(3, '0')}`,
      product: countForm.product,
      location: countForm.location || '-',
      expected: exp,
      actual: act,
      variance: act - exp,
    };
    setCounts((p) => [newCount, ...p]);
    setCountForm({ barcode: '', product: '', location: '', expected: '', actual: '' });
  };

  /* ================================================================== */
  /*  RENDER                                                            */
  /* ================================================================== */
  return (
    <div className="min-h-screen bg-[#f0f2f5] flex justify-center p-0 md:p-4">
      <div className="w-full max-w-[480px] bg-[#f8f9fa] min-h-[100dvh] md:min-h-0 md:rounded-3xl shadow-2xl overflow-hidden relative flex flex-col">
        <AnimatePresence mode="wait">
          {/* ====================== HOME TAB ======================*/}
          {activeTab === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col overflow-auto pb-4"
            >
              {/* Header */}
              <div className="bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] text-white px-5 pt-6 pb-10 rounded-b-[28px] shadow-lg relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-full opacity-5">
                  <div className="absolute top-6 left-6 w-20 h-20 rounded-full border-[2px] border-white" />
                  <div className="absolute bottom-4 right-10 w-14 h-14 rounded-full border-[2px] border-white" />
                </div>
                <div className="relative flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center border border-white/30">
                    <User size={22} className="text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">أحمد سمير</p>
                    <p className="text-[10px] text-white/70">مستودع القاهرة الرئيسي</p>
                    <p className="text-[10px] text-white/60 flex items-center gap-1">
                      <Warehouse size={10} /> عامل مستودع
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="px-4 -mt-6 relative z-10 grid grid-cols-3 gap-2">
                <div className="bg-white rounded-xl p-3 shadow-md text-center">
                  <p className="text-xl font-bold text-[#0d6b43]">12</p>
                  <p className="text-[10px] text-gray-500 mt-0.5">عمليات استلام</p>
                </div>
                <div className="bg-white rounded-xl p-3 shadow-md text-center">
                  <p className="text-xl font-bold text-[#daa520]">{pickedCount}/{picking.length}</p>
                  <p className="text-[10px] text-gray-500 mt-0.5">عمليات تجميع</p>
                </div>
                <div className="bg-white rounded-xl p-3 shadow-md text-center">
                  <p className="text-xl font-bold text-blue-600">8</p>
                  <p className="text-[10px] text-gray-500 mt-0.5">عمليات تحميل</p>
                </div>
              </div>

              {/* Menu Grid */}
              <div className="px-4 mt-5">
                <h3 className="text-sm font-bold text-gray-800 mb-3">العمليات السريعة</h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: 'receive', label: 'الاستلام', sub: 'استلام البضائع', icon: Inbox, color: 'bg-emerald-50 text-emerald-600', border: 'border-emerald-200' },
                    { key: 'pick', label: 'التجميع', sub: 'تجميع الطلبات', icon: ListChecks, color: 'bg-amber-50 text-amber-600', border: 'border-amber-200' },
                    { key: 'load', label: 'التحميل', sub: 'تحميل المركبات', icon: Truck, color: 'bg-blue-50 text-blue-600', border: 'border-blue-200' },
                    { key: 'count', label: 'الجرد', sub: 'جرد المخزون', icon: ClipboardList, color: 'bg-purple-50 text-purple-600', border: 'border-purple-200' },
                  ].map((item) => (
                    <motion.button
                      key={item.key}
                      whileTap={{ scale: 0.96 }}
                      onClick={() => setActiveTab(item.key as typeof activeTab)}
                      className={`bg-white rounded-xl p-4 border ${item.border} shadow-sm flex flex-col items-center gap-2 active:scale-[0.98] transition-transform`}
                    >
                      <div className={`w-12 h-12 rounded-xl ${item.color} flex items-center justify-center`}>
                        <item.icon size={24} />
                      </div>
                      <p className="text-xs font-bold text-gray-800">{item.label}</p>
                      <p className="text-[10px] text-gray-400">{item.sub}</p>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Transfer Requests Preview */}
              <div className="px-4 mt-5">
                <h3 className="text-sm font-bold text-gray-800 mb-3">طلبات التحويل</h3>
                <div className="space-y-2">
                  {transferRequests.slice(0, 2).map((tr) => (
                    <div key={tr.id} className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                        <ArrowLeftRight size={16} className="text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-gray-800">{tr.id}</p>
                        <p className="text-[10px] text-gray-500 truncate">{tr.from} → {tr.to}</p>
                      </div>
                      <TransferStatusBadge status={tr.status} />
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* ====================== RECEIVING TAB ======================*/}
          {activeTab === 'receive' && (
            <motion.div
              key="receive"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] text-white px-4 pt-5 pb-5 rounded-b-[24px]">
                <button
                  onClick={() => setActiveTab('home')}
                  className="flex items-center gap-1 text-white/80 text-xs mb-2 hover:text-white transition-colors"
                >
                  <ChevronRight size={16} /> رجوع
                </button>
                <h2 className="text-base font-bold">استلام البضائع</h2>
                <p className="text-[10px] text-white/60">مسح الباركود واستلام الشحنات</p>
              </div>

              <div className="flex-1 overflow-auto px-4 pb-4 -mt-2 pt-3">
                {/* Barcode Scanner Big Button */}
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={() => setScanMode(!scanMode)}
                  className="w-full h-24 bg-gradient-to-br from-[#0d6b43]/10 to-[#0d6b43]/5 rounded-2xl border-2 border-dashed border-[#0d6b43]/30 flex flex-col items-center justify-center gap-2 mb-4 active:scale-[0.98] transition-transform"
                >
                  <div className="w-12 h-12 rounded-full bg-[#0d6b43]/10 flex items-center justify-center">
                    {scanMode ? <QrCode size={24} className="text-[#0d6b43]" /> : <ScanBarcode size={24} className="text-[#0d6b43]" />}
                  </div>
                  <p className="text-xs font-bold text-[#0d6b43]">
                    {scanMode ? 'وضع المسح النشط' : 'مسح الباركود'}
                  </p>
                </motion.button>

                {/* Receiving Form */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">إضافة صنف جديد</h4>
                  <div className="space-y-2.5">
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">المورد</label>
                      <Input
                        placeholder="اسم المورد"
                        value={recvForm.supplier}
                        onChange={(e) => setRecvForm((f) => ({ ...f, supplier: e.target.value }))}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">رقم أمر الشراء</label>
                      <Input
                        placeholder="PO-####"
                        value={recvForm.poRef}
                        onChange={(e) => setRecvForm((f) => ({ ...f, poRef: e.target.value }))}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">المنتج</label>
                      <Input
                        placeholder="اسم المنتج"
                        value={recvForm.product}
                        onChange={(e) => setRecvForm((f) => ({ ...f, product: e.target.value }))}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[11px] text-gray-500 mb-1 block">الكمية المتوقعة</label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={recvForm.qtyExpected}
                          onChange={(e) => setRecvForm((f) => ({ ...f, qtyExpected: e.target.value }))}
                          className="h-9 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-gray-500 mb-1 block">الكمية المستلمة</label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={recvForm.qtyReceived}
                          onChange={(e) => setRecvForm((f) => ({ ...f, qtyReceived: e.target.value }))}
                          className="h-9 text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">الحالة</label>
                      <div className="flex gap-2">
                        {(['جيد', 'تالف', 'ناقص'] as const).map((c) => (
                          <button
                            key={c}
                            onClick={() => setRecvForm((f) => ({ ...f, condition: c }))}
                            className={`flex-1 h-8 rounded-lg text-[11px] font-medium border transition-all ${
                              recvForm.condition === c
                                ? c === 'جيد' ? 'bg-emerald-500 text-white border-emerald-500' : c === 'تالف' ? 'bg-red-500 text-white border-red-500' : 'bg-amber-500 text-white border-amber-500'
                                : 'bg-white text-gray-600 border-gray-200'
                            }`}
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">ملاحظات</label>
                      <Textarea
                        placeholder="أي ملاحظات..."
                        value={recvForm.notes}
                        onChange={(e) => setRecvForm((f) => ({ ...f, notes: e.target.value }))}
                        className="min-h-[50px] text-xs"
                      />
                    </div>
                    <Button size="sm" className="w-full h-8 text-[11px] bg-[#0d6b43]" onClick={addReceivingItem}>
                      <Plus size={12} /> إضافة صنف
                    </Button>
                  </div>
                </div>

                {/* Photo Upload for Damage */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">صورة التلف (اختياري)</h4>
                  <div className="h-24 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-2 bg-gray-50">
                    <Camera size={22} className="text-gray-300" />
                    <p className="text-[10px] text-gray-400">اضغط لالتقاط صورة</p>
                  </div>
                </div>

                {/* Received Items List */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold text-gray-800">الأصناف المستلمة</h4>
                    <Badge variant="success" className="text-[10px]">{receiving.length} صنف</Badge>
                  </div>
                  <div className="space-y-2">
                    {receiving.map((item) => (
                      <div key={item.id} className="p-3 rounded-lg border border-gray-100 bg-gray-50/50">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-xs font-bold text-gray-800">{item.product}</p>
                          <ConditionBadge condition={item.condition} />
                        </div>
                        <div className="flex items-center gap-3 text-[10px] text-gray-500">
                          <span>متوقع: <b>{item.qtyExpected}</b></span>
                          <span>مستلم: <b className={item.qtyReceived < item.qtyExpected ? 'text-red-500' : 'text-emerald-600'}>{item.qtyReceived}</b></span>
                          {item.qtyReceived < item.qtyExpected && (
                            <span className="text-red-500 font-bold">فرق: {item.qtyExpected - item.qtyReceived}</span>
                          )}
                        </div>
                        {item.notes && <p className="text-[10px] text-gray-400 mt-1">{item.notes}</p>}
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full h-10 text-sm font-bold bg-[#0a4a30] hover:bg-[#083d28] mb-4">
                  <BadgeCheck size={16} /> تأكيد الاستلام
                </Button>
              </div>
            </motion.div>
          )}

          {/* ====================== PICKING TAB ======================*/}
          {activeTab === 'pick' && (
            <motion.div
              key="pick"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="bg-gradient-to-br from-amber-600 to-amber-700 text-white px-4 pt-5 pb-5 rounded-b-[24px]">
                <button
                  onClick={() => setActiveTab('home')}
                  className="flex items-center gap-1 text-white/80 text-xs mb-2 hover:text-white transition-colors"
                >
                  <ChevronRight size={16} /> رجوع
                </button>
                <h2 className="text-base font-bold">التجميع</h2>
                <p className="text-[10px] text-white/60">تجميع منتجات الطلبات</p>
              </div>

              <div className="flex-1 overflow-auto px-4 pb-4 -mt-2 pt-3">
                {/* Progress */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold text-gray-800">تقدم التجميع</p>
                    <p className="text-xs font-bold text-amber-600">{pickedCount} / {picking.length}</p>
                  </div>
                  <Progress value={pickProgress} className="h-2.5" />
                  <p className="text-[10px] text-gray-400 mt-1.5 text-left">{Math.round(pickProgress)}% مكتمل</p>
                </div>

                {/* Barcode Scan */}
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  className="w-full h-16 bg-gradient-to-br from-amber-50 to-amber-50/50 rounded-2xl border-2 border-dashed border-amber-300 flex items-center justify-center gap-2 mb-4 active:scale-[0.98] transition-transform"
                >
                  <ScanBarcode size={22} className="text-amber-600" />
                  <span className="text-xs font-bold text-amber-700">مسح الباركود لتأكيد التجميع</span>
                </motion.button>

                {/* Picking List */}
                <h3 className="text-xs font-bold text-gray-800 mb-3">قائمة التجميع</h3>
                <div className="space-y-3">
                  {picking.map((item, i) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className={`bg-white rounded-xl p-4 shadow-sm border transition-all ${item.done ? 'border-emerald-200 bg-emerald-50/30' : 'border-gray-100'}`}
                    >
                      <div className="flex items-start gap-3">
                        <button
                          onClick={() => togglePick(item.id)}
                          className={`w-7 h-7 rounded-lg flex items-center justify-center border-2 shrink-0 mt-0.5 transition-all ${
                            item.done
                              ? 'bg-emerald-500 border-emerald-500 text-white'
                              : 'border-gray-300 hover:border-emerald-400'
                          }`}
                        >
                          {item.done && <Check size={14} />}
                        </button>
                        <div className="flex-1">
                          <p className={`text-xs font-bold ${item.done ? 'text-emerald-700 line-through' : 'text-gray-800'}`}>
                            {item.product}
                          </p>
                          <div className="flex items-center gap-3 mt-1.5">
                            <span className="text-[10px] text-gray-500 flex items-center gap-1">
                              <MapPin size={10} className="text-amber-600" />
                              {item.location}
                            </span>
                            <span className="text-[10px] text-gray-500 flex items-center gap-1">
                              <Box size={10} className="text-blue-500" />
                              {item.qty} وحدة
                            </span>
                          </div>
                          {/* Mini progress per item */}
                          {!item.done && (
                            <div className="mt-2">
                              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${(item.picked / item.qty) * 100}%` }} />
                              </div>
                              <p className="text-[9px] text-gray-400 mt-0.5">تم: {item.picked} / {item.qty}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {pickedCount === picking.length && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mt-4 bg-emerald-50 rounded-xl p-4 text-center border border-emerald-200"
                  >
                    <CheckCircle2 size={32} className="text-emerald-500 mx-auto mb-2" />
                    <p className="text-sm font-bold text-emerald-700">تم التجميع بنجاح!</p>
                    <p className="text-[11px] text-emerald-600 mt-1">جميع الأصناف تم تجميعها</p>
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}

          {/* ====================== LOADING TAB ======================*/}
          {activeTab === 'load' && (
            <motion.div
              key="load"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white px-4 pt-5 pb-5 rounded-b-[24px]">
                <button
                  onClick={() => setActiveTab('home')}
                  className="flex items-center gap-1 text-white/80 text-xs mb-2 hover:text-white transition-colors"
                >
                  <ChevronRight size={16} /> رجوع
                </button>
                <h2 className="text-base font-bold">التحميل</h2>
                <p className="text-[10px] text-white/60">تحميل البضائع على المركبات</p>
              </div>

              <div className="flex-1 overflow-auto px-4 pb-4 -mt-2 pt-3">
                {/* Vehicle Info */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">معلومات المركبة</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500 flex items-center gap-1"><Truck size={12} /> رقم اللوحة</span>
                      <span className="font-bold text-gray-800">م ع أ 4521</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500 flex items-center gap-1"><User size={12} /> السائق</span>
                      <span className="font-bold text-gray-800">محمد علي أحمد</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500 flex items-center gap-1"><Weight size={12} /> الوزن الكلي</span>
                      <span className="font-bold text-gray-800">{totalLoadingWeight.toLocaleString()} كجم</span>
                    </div>
                  </div>
                </div>

                {/* Loading List */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">قائمة التحميل</h4>
                  <div className="space-y-2">
                    {loadingList.map((item, i) => (
                      <div key={item.id} className={`flex items-center gap-3 py-2.5 border-b border-gray-50 last:border-0 ${loaded ? 'opacity-60' : ''}`}>
                        <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center shrink-0">
                          <Package size={14} className="text-blue-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-gray-800 truncate">{item.product}</p>
                          <p className="text-[10px] text-gray-400">{item.weight} كجم</p>
                        </div>
                        <div className="text-left">
                          <p className="text-xs font-bold text-blue-600">x{item.qty}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Driver Signature */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">توقيع السائق</h4>
                  <button
                    onClick={() => setDriverSigned(!driverSigned)}
                    className={`w-full h-24 rounded-xl border-2 border-dashed transition-all flex flex-col items-center justify-center gap-2 ${
                      driverSigned
                        ? 'bg-emerald-50 border-emerald-300'
                        : 'bg-gray-50 border-gray-300'
                    }`}
                  >
                    {driverSigned ? (
                      <>
                        <CheckCircle2 size={28} className="text-emerald-500" />
                        <p className="text-[11px] font-bold text-emerald-600">تم التوقيع</p>
                      </>
                    ) : (
                      <>
                        <PenTool size={24} className="text-gray-300" />
                        <p className="text-[11px] text-gray-400">اضغط للتوقيع</p>
                      </>
                    )}
                  </button>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2 mb-4">
                  <Button
                    className={`w-full h-10 text-sm font-bold ${
                      loaded
                        ? 'bg-emerald-500 hover:bg-emerald-600'
                        : 'bg-[#0a4a30] hover:bg-[#083d28]'
                    }`}
                    onClick={() => setLoaded(!loaded)}
                  >
                    {loaded ? (
                      <><CheckCircle2 size={16} /> تم التحميل</>
                    ) : (
                      <><Truck size={16} /> تأكيد التحميل</>
                    )}
                  </Button>
                  <Button variant="outline" className="w-full h-9 text-xs border-gray-200">
                    <Printer size={14} /> طباعة بوليصة الشحن
                  </Button>
                </div>
              </div>
            </motion.div>
          )}

          {/* ====================== COUNT TAB ======================*/}
          {activeTab === 'count' && (
            <motion.div
              key="count"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="bg-gradient-to-br from-purple-600 to-purple-700 text-white px-4 pt-5 pb-5 rounded-b-[24px]">
                <button
                  onClick={() => setActiveTab('home')}
                  className="flex items-center gap-1 text-white/80 text-xs mb-2 hover:text-white transition-colors"
                >
                  <ChevronRight size={16} /> رجوع
                </button>
                <h2 className="text-base font-bold">جرد المخزون</h2>
                <p className="text-[10px] text-white/60">جرد وإحصاء المنتجات</p>
              </div>

              <div className="flex-1 overflow-auto px-4 pb-4 -mt-2 pt-3">
                {/* Count Form */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">إضافة جرد جديد</h4>
                  <div className="space-y-2.5">
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">مسح الباركود</label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="ادخل الباركود"
                          value={countForm.barcode}
                          onChange={(e) => setCountForm((f) => ({ ...f, barcode: e.target.value }))}
                          className="h-9 text-xs flex-1"
                        />
                        <Button size="icon" className="h-9 w-9 bg-purple-600">
                          <ScanBarcode size={16} />
                        </Button>
                      </div>
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">المنتج</label>
                      <Input
                        placeholder="اسم المنتج"
                        value={countForm.product}
                        onChange={(e) => setCountForm((f) => ({ ...f, product: e.target.value }))}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">الموقع</label>
                      <Input
                        placeholder="Zone-Aisle-Rack-Shelf"
                        value={countForm.location}
                        onChange={(e) => setCountForm((f) => ({ ...f, location: e.target.value }))}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[11px] text-gray-500 mb-1 block">الكمية المتوقعة</label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={countForm.expected}
                          onChange={(e) => setCountForm((f) => ({ ...f, expected: e.target.value }))}
                          className="h-9 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-gray-500 mb-1 block">الكمية الفعلية</label>
                        <Input
                          type="number"
                          placeholder="0"
                          value={countForm.actual}
                          onChange={(e) => setCountForm((f) => ({ ...f, actual: e.target.value }))}
                          className="h-9 text-xs"
                        />
                      </div>
                    </div>
                    {countForm.expected && countForm.actual && (
                      <div className="bg-gray-50 rounded-lg p-2 text-center">
                        <p className="text-[11px] text-gray-500">الفرق (التباين)</p>
                        <p className={`text-sm font-bold ${Number(countForm.actual) - Number(countForm.expected) === 0 ? 'text-emerald-600' : Number(countForm.actual) - Number(countForm.expected) > 0 ? 'text-blue-600' : 'text-red-500'}`}>
                          {Number(countForm.actual) - Number(countForm.expected) > 0 ? '+' : ''}
                          {Number(countForm.actual) - Number(countForm.expected)}
                        </p>
                      </div>
                    )}
                    <Button size="sm" className="w-full h-8 text-[11px] bg-purple-600 hover:bg-purple-700" onClick={submitCount}>
                      <Save size={12} /> حفظ الجرد
                    </Button>
                  </div>
                </div>

                {/* Count History */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold text-gray-800">سجل الجرد</h4>
                    <Badge variant="outline" className="text-[10px]">{counts.length} عملية</Badge>
                  </div>
                  <div className="space-y-2">
                    {counts.map((c) => (
                      <div key={c.id} className="p-3 rounded-lg border border-gray-100 bg-gray-50/50">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-xs font-bold text-gray-800">{c.product}</p>
                          {c.variance === 0 ? (
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">متطابق</span>
                          ) : c.variance > 0 ? (
                            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">+{c.variance} زيادة</span>
                          ) : (
                            <span className="text-[10px] font-bold text-red-500 bg-red-50 px-2 py-0.5 rounded-full">{c.variance} عجز</span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-[10px] text-gray-500">
                          <span className="flex items-center gap-1"><MapPin size={9} /> {c.location}</span>
                          <span>متوقع: <b>{c.expected}</b></span>
                          <span>فعلي: <b>{c.actual}</b></span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Transfers Section */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">طلبات التحويل</h4>
                  <div className="space-y-2">
                    {transferRequests.map((tr) => (
                      <div key={tr.id} className="p-3 rounded-lg border border-gray-100">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-xs font-bold text-gray-800">{tr.id}</p>
                          <TransferStatusBadge status={tr.status} />
                        </div>
                        <p className="text-[10px] text-gray-600 mb-1">{tr.product} - {tr.qty} وحدة</p>
                        <div className="flex items-center gap-1 text-[10px] text-gray-400">
                          <span className="truncate">{tr.from}</span>
                          <ArrowLeftRight size={9} />
                          <span className="truncate">{tr.to}</span>
                        </div>
                        {tr.status === 'معلقة' && (
                          <Button size="sm" className="w-full mt-2 h-7 text-[11px] bg-[#0d6b43]">
                            <Check size={12} /> تأكيد التحويل
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ====================== BOTTOM NAV ======================*/}
        <div className="shrink-0 bg-white border-t border-gray-100 px-1 py-1 flex items-center justify-around z-20">
          {[
            { key: 'home', label: 'الرئيسية', icon: Home },
            { key: 'receive', label: 'استلام', icon: Inbox },
            { key: 'pick', label: 'تجميع', icon: ListChecks },
            { key: 'load', label: 'تحميل', icon: Truck },
            { key: 'count', label: 'جرد', icon: ClipboardList },
          ].map((item) => {
            const isActive = activeTab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setActiveTab(item.key as typeof activeTab)}
                className={`flex flex-col items-center gap-0.5 py-2 px-2 rounded-xl transition-all ${
                  isActive ? 'text-[#0d6b43]' : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                <item.icon size={19} strokeWidth={isActive ? 2.5 : 1.5} />
                <span className={`text-[10px] font-medium ${isActive ? 'font-bold' : ''}`}>{item.label}</span>
                {isActive && <div className="w-1 h-1 rounded-full bg-[#0d6b43]" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
