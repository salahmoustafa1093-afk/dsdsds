// @ts-nocheck
import { useState } from 'react';
import {
  Package, CheckCircle2, Clock, AlertTriangle, Plus, Printer, Barcode,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

/* ─── Types ─────────────────────────────────────────── */
interface PackagingOrder {
  id: number;
  orderNumber: string;
  product: string;
  grade: string;
  packageType: string;
  qtyOrdered: number;
  qtyPacked: number;
  status: 'scheduled' | 'running' | 'completed';
  batch: string;
  expiryDate: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const packagingOrders: PackagingOrder[] = [
  { id: 1, orderNumber: 'PKG-001', product: 'فول مدمس', grade: 'ممتاز', packageType: '٥٠ كجم جوال', qtyOrdered: 2000, qtyPacked: 2000, status: 'completed', batch: 'FB-001', expiryDate: '١٥/٠٧/٢٠٢٥' },
  { id: 2, orderNumber: 'PKG-002', product: 'عدس أصفر', grade: 'أولى', packageType: '٢٥ كجم شكاية', qtyOrdered: 3000, qtyPacked: 2400, status: 'running', batch: 'FB-002', expiryDate: '٢٠/٠٧/٢٠٢٥' },
  { id: 3, orderNumber: 'PKG-003', product: 'حمص', grade: 'ممتاز', packageType: '١ كجم سائب', qtyOrdered: 5000, qtyPacked: 0, status: 'scheduled', batch: 'FB-003', expiryDate: '٢٢/٠٧/٢٠٢٥' },
  { id: 4, orderNumber: 'PKG-004', product: 'لوبيا', grade: 'ممتاز', packageType: '٥ كجم كيس', qtyOrdered: 1500, qtyPacked: 1500, status: 'completed', batch: 'FB-004', expiryDate: '١٨/٠٧/٢٠٢٥' },
  { id: 5, orderNumber: 'PKG-005', product: 'فول مدمس', grade: 'أولى', packageType: '٢٥ كجم شكاية', qtyOrdered: 2500, qtyPacked: 800, status: 'running', batch: 'FB-005', expiryDate: '٢٥/٠٧/٢٠٢٥' },
  { id: 6, orderNumber: 'PKG-006', product: 'عدس أخضر', grade: 'ممتاز', packageType: '٥٠ كجم جوال', qtyOrdered: 1800, qtyPacked: 0, status: 'scheduled', batch: 'FB-006', expiryDate: '٣٠/٠٧/٢٠٢٥' },
  { id: 7, orderNumber: 'PKG-007', product: 'حمص', grade: 'أولى', packageType: '٥ كجم كيس', qtyOrdered: 2000, qtyPacked: 2000, status: 'completed', batch: 'FB-007', expiryDate: '٢٨/٠٧/٢٠٢٥' },
  { id: 8, orderNumber: 'PKG-008', product: 'فول مدمس', grade: 'ممتاز', packageType: '١ كجم سائب', qtyOrdered: 8000, qtyPacked: 0, status: 'scheduled', batch: 'FB-008', expiryDate: '٠١/٠٨/٢٠٢٥' },
];

const statusConfig: Record<string, { label: string; color: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  scheduled: { label: 'مجدول', color: 'bg-gray-100 text-gray-700', variant: 'secondary' },
  running: { label: 'قيد التشغيل', color: 'bg-amber-100 text-amber-700', variant: 'secondary' },
  completed: { label: 'مكتمل', color: 'bg-green-100 text-green-700', variant: 'default' },
};

const packageSizes = ['١ كجم سائب', '٥ كجم كيس', '٢٥ كجم شكاية', '٥٠ كجم جوال'];

/* ─── Page ──────────────────────────────────────────── */
export default function PulsesPackagingPage() {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isLabelOpen, setIsLabelOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<PackagingOrder | null>(null);
  const [formData, setFormData] = useState({ product: '', grade: 'ممتاز', packageType: '٥٠ كجم جوال', quantity: '', batch: '' });

  const todayOrders = packagingOrders.length;
  const packedQty = packagingOrders.reduce((s, o) => s + o.qtyPacked, 0);
  const remainingQty = packagingOrders.reduce((s, o) => s + (o.qtyOrdered - o.qtyPacked), 0);
  const wasteQty = Math.round(packedQty * 0.015);

  const columns = [
    { key: 'orderNumber', header: 'رقم الأمر', sortable: true, width: '100px' },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'grade', header: 'الدرجة', sortable: true },
    { key: 'packageType', header: 'نوع التعبئة', sortable: true },
    {
      key: 'qtyOrdered',
      header: 'المطلوب',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => <span>{row.qtyOrdered as number}</span>,
    },
    {
      key: 'qtyPacked',
      header: 'المعبأ',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => {
        const pct = ((row.qtyPacked as number) / (row.qtyOrdered as number)) * 100;
        return (
          <div className="space-y-1">
            <span className="text-sm">{row.qtyPacked as number}</span>
            <div className="w-12 h-1.5 bg-gray-200 rounded-full overflow-hidden"><div className="h-full bg-green-500 rounded-full" style={{ width: `${pct}%` }} /></div>
          </div>
        );
      },
    },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: Record<string, unknown>) => {
        const cfg = statusConfig[row.status as string];
        return <Badge variant={cfg.variant} className={cfg.color}>{cfg.label}</Badge>;
      },
    },
    { key: 'batch', header: 'الدفعة', sortable: true },
  ];

  const printLabel = (order: PackagingOrder) => {
    setSelectedOrder(order);
    setIsLabelOpen(true);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="تعبئة البقوليات" subtitle="تعبئة وتغليف البقوليات حسب أوامر التعبئة" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'البقوليات' }, { label: 'التعبئة' }]}>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild><Button className="bg-green-700 hover:bg-green-800 text-white gap-1"><Plus size={16} /> أمر تعبئة</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>إنشاء أمر تعبئة</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>المنتج</Label>
                  <select value={formData.product} onChange={e => setFormData({ ...formData, product: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option value="">اختر</option><option>فول مدمس</option><option>عدس أصفر</option><option>عدس أخضر</option><option>حمص</option><option>لوبيا</option>
                  </select>
                </div>
                <div className="space-y-1.5"><Label>الدرجة</Label>
                  <select value={formData.grade} onChange={e => setFormData({ ...formData, grade: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option>ممتاز</option><option>أولى</option><option>ثانية</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>نوع التعبئة</Label>
                  <select value={formData.packageType} onChange={e => setFormData({ ...formData, packageType: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    {packageSizes.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5"><Label>الكمية</Label><Input type="number" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} placeholder="عدد الأكياس" /></div>
              </div>
              <div className="space-y-1.5"><Label>رقم الدفعة</Label><Input value={formData.batch} onChange={e => setFormData({ ...formData, batch: e.target.value })} placeholder="FB-XXX" /></div>
              <div className="flex justify-end gap-2 pt-2"><Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button><Button className="bg-green-700 hover:bg-green-800 text-white">حفظ الأمر</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="أوامر اليوم" value={String(todayOrders)} icon={Package} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="معبأ" value={`${packedQty}`} icon={CheckCircle2} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.1} />
        <KPICard title="متبقي" value={`${remainingQty}`} icon={Clock} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="هالك" value={`${wasteQty}`} icon={AlertTriangle} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Package Sizes */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {packageSizes.map((size, i) => (
          <div key={size} className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4 text-center hover:shadow-md transition-shadow cursor-pointer">
            <Package size={24} className="mx-auto mb-2 text-green-600" />
            <span className="text-sm font-medium">{size}</span>
          </div>
        ))}
      </div>

      {/* Table */}
      <DataTable
        columns={columns}
        data={packagingOrders as unknown as Record<string, unknown>[]}
        title="أوامر التعبئة"
        rowActions={{
          onView: (row) => printLabel(row as unknown as PackagingOrder),
          onEdit: () => {},
          onDelete: () => {},
        }}
      />

      {/* Label Preview Dialog */}
      <Dialog open={isLabelOpen} onOpenChange={setIsLabelOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle className="flex items-center gap-1"><Printer size={16} /> معاينة البطاقة</DialogTitle></DialogHeader>
          {selectedOrder && (
            <div className="mt-4 p-4 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 space-y-3">
              <div className="flex items-center justify-between border-b pb-2">
                <span className="text-lg font-bold text-green-700">GFF</span>
                <Barcode size={40} className="text-gray-600" />
              </div>
              <div className="space-y-1">
                <p className="text-xs text-gray-500">المنتج</p>
                <p className="text-base font-bold">{selectedOrder.product} - {selectedOrder.grade}</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-xs text-gray-500">الوزن</p><p className="font-semibold">{selectedOrder.packageType}</p></div>
                <div><p className="text-xs text-gray-500">الدفعة</p><p className="font-semibold">{selectedOrder.batch}</p></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-xs text-gray-500">تاريخ الإنتاج</p><p className="font-semibold">١٥/٠١/٢٠٢٥</p></div>
                <div><p className="text-xs text-gray-500">تاريخ الانتهاء</p><p className="font-semibold text-red-600">{selectedOrder.expiryDate}</p></div>
              </div>
              <div className="text-center text-[10px] text-gray-400 pt-2 border-t">شركة الجودة للأغذية والأعلاف</div>
            </div>
          )}
          <Button className="w-full gap-1"><Printer size={16} /> طباعة</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
