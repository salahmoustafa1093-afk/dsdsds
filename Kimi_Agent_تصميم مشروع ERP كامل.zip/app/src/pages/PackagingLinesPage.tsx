// @ts-nocheck
import { useState } from 'react';
import {
  Cog, Gauge, Zap, Activity, Plus, CheckCircle2, AlertTriangle, XCircle,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

/* ─── Types ─────────────────────────────────────────── */
interface PackagingLine {
  id: number;
  name: string;
  type: string;
  speed: string;
  status: 'active' | 'maintenance' | 'offline';
  efficiency: number;
  currentProduct: string;
  currentBatch: string;
  outputCount: number;
  rejects: number;
  runtime: string;
  products: string[];
}

/* ─── Mock Data ─────────────────────────────────────── */
const linesData: PackagingLine[] = [
  { id: 1, name: 'خط تعبئة أرز ١', type: 'أرز', speed: '٦٠ كيس/دقيقة', status: 'active', efficiency: 94, currentProduct: 'أرز مصري أروما', currentBatch: 'RB-2025-001', outputCount: 14200, rejects: 45, runtime: '١٦:٣٠', products: ['أرز مصري', 'أرز عريض'] },
  { id: 2, name: 'خط تعبئة عدس ١', type: 'عدس', speed: '٥٥ كيس/دقيقة', status: 'active', efficiency: 91, currentProduct: 'عدس أصفر مجروش', currentBatch: 'LB-2025-002', outputCount: 11800, rejects: 62, runtime: '١٤:٠٠', products: ['عدس أصفر', 'عدس أخضر'] },
  { id: 3, name: 'خط تعبئة فول ١', type: 'فول', speed: '٥٠ كيس/دقيقة', status: 'active', efficiency: 88, currentProduct: 'فول مدمس كبير', currentBatch: 'FB-2025-003', outputCount: 9600, rejects: 38, runtime: '١٢:٤٥', products: ['فول مدمس', 'فول صغير'] },
  { id: 4, name: 'خط تعبئة حمص ١', type: 'حمص', speed: '٥٥ كيس/دقيقة', status: 'maintenance', efficiency: 0, currentProduct: '—', currentBatch: '—', outputCount: 0, rejects: 0, runtime: '—', products: ['حمص مجروش', 'حمص كامل'] },
  { id: 5, name: 'خط تعبئة لوبيا ١', type: 'لوبيا', speed: '٤٥ كيس/دقيقة', status: 'active', efficiency: 93, currentProduct: 'لوبيا أبيض', currentBatch: 'WB-2025-005', outputCount: 7200, rejects: 28, runtime: '١٠:١٥', products: ['لوبيا أبيض', 'لوبيا أحمر'] },
  { id: 6, name: 'خط تعبئة أرز ٢', type: 'أرز', speed: '٦٥ كيس/دقيقة', status: 'offline', efficiency: 0, currentProduct: '—', currentBatch: '—', outputCount: 0, rejects: 0, runtime: '—', products: ['أرز مصري'] },
  { id: 7, name: 'خط تعبئة مختلط ١', type: 'مختلط', speed: '٤٠ كيس/دقيقة', status: 'active', efficiency: 86, currentProduct: 'خلطة بقوليات', currentBatch: 'MB-2025-001', outputCount: 5800, rejects: 52, runtime: '٠٩:٣٠', products: ['فول', 'عدس', 'حمص', 'لوبيا'] },
];

const statusConfig = {
  active: { label: 'نشط', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', icon: CheckCircle2 },
  maintenance: { label: 'صيانة', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400', icon: AlertTriangle },
  offline: { label: 'خارج الخدمة', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', icon: XCircle },
};

/* ─── Page ──────────────────────────────────────────── */
export default function PackagingLinesPage() {
  const [filter, setFilter] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [detailLine, setDetailLine] = useState<PackagingLine | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', type: '', speed: '' });

  const activeCount = linesData.filter(l => l.status === 'active').length;
  const dailyCapacity = '٣٨٠٠٠ كيس';
  const avgEfficiency = Math.round(linesData.filter(l => l.status === 'active').reduce((s, l) => s + l.efficiency, 0) / activeCount);

  const filteredData = filter === 'all' ? linesData : linesData.filter(l => l.status === filter);

  const columns = [
    { key: 'name', header: 'اسم الخط', sortable: true },
    { key: 'type', header: 'النوع', sortable: true },
    { key: 'speed', header: 'السرعة', sortable: true, width: '130px' },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: Record<string, unknown>) => {
        const cfg = statusConfig[row.status as keyof typeof statusConfig];
        const Icon = cfg.icon;
        return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}><Icon size={12} /> {cfg.label}</span>;
      },
    },
    {
      key: 'efficiency',
      header: 'الكفاءة %',
      sortable: true,
      width: '90px',
      render: (row: Record<string, unknown>) => (
        <div className="flex items-center gap-2">
          <div className="w-14 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div className={`h-full rounded-full ${(row.efficiency as number) >= 90 ? 'bg-green-500' : (row.efficiency as number) >= 75 ? 'bg-amber-500' : 'bg-red-500'}`} style={{ width: `${row.efficiency as number}%` }} />
          </div>
          <span className="text-xs">{row.efficiency as number}%</span>
        </div>
      ),
    },
    { key: 'products', header: 'المنتجات', render: (row: Record<string, unknown>) => <span className="text-xs">{(row.products as string[]).join('، ')}</span> },
  ];

  const openDetail = (line: PackagingLine) => { setDetailLine(line); setIsDetailOpen(true); };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="خطوط التعبئة" subtitle="متابعة وإدارة خطوط التعبئة والتغليف" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'التعبئة' }, { label: 'خطوط التعبئة' }]}>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild><Button className="bg-green-700 hover:bg-green-800 text-white gap-1"><Plus size={16} /> إضافة خط</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>إضافة خط تعبئة جديد</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-1.5"><Label>اسم الخط</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="مثال: خط تعبئة أرز ٣" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>النوع</Label>
                  <select value={formData.type} onChange={e => setFormData({ ...formData, type: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option value="">اختر</option><option>أرز</option><option>عدس</option><option>فول</option><option>حمص</option><option>لوبيا</option><option>مختلط</option>
                  </select>
                </div>
                <div className="space-y-1.5"><Label>السرعة</Label><Input value={formData.speed} onChange={e => setFormData({ ...formData, speed: e.target.value })} placeholder="كيس/دقيقة" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2"><Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button><Button className="bg-green-700 hover:bg-green-800 text-white">حفظ الخط</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="عدد الخطوط" value={String(linesData.length)} icon={Cog} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="نشطة" value={String(activeCount)} change={+2} icon={Activity} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.1} />
        <KPICard title="طاقة يومية" value={dailyCapacity} icon={Zap} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="كفاءة متوسطة" value={`${avgEfficiency}%`} change={+1.5} icon={Gauge} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.3} />
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4">
        <Tabs value={filter} onValueChange={setFilter}>
          <TabsList className="h-9"><TabsTrigger value="all" className="text-xs">الكل</TabsTrigger><TabsTrigger value="active" className="text-xs">نشط</TabsTrigger><TabsTrigger value="maintenance" className="text-xs">صيانة</TabsTrigger><TabsTrigger value="offline" className="text-xs">خارج الخدمة</TabsTrigger></TabsList>
        </Tabs>
      </div>

      {/* Table */}
      <DataTable columns={columns} data={filteredData as unknown as Record<string, unknown>[]} title="خطوط التعبئة" rowActions={{ onView: (row) => openDetail(row as unknown as PackagingLine), onEdit: () => {}, onDelete: () => {} }} />

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>تفاصيل خط التعبئة: {detailLine?.name}</DialogTitle></DialogHeader>
          {detailLine && detailLine.status === 'active' && (
            <div className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block">المنتج الحالي</span><span className="font-semibold">{detailLine.currentProduct}</span></div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block">الدفعة</span><span className="font-semibold">{detailLine.currentBatch}</span></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center"><span className="text-xs text-green-600 block">إنتاج</span><span className="font-bold text-lg">{detailLine.outputCount.toLocaleString()}</span></div>
                <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg text-center"><span className="text-xs text-red-600 block">مستبعدين</span><span className="font-bold text-lg">{detailLine.rejects}</span></div>
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center"><span className="text-xs text-blue-600 block">وقت التشغيل</span><span className="font-bold text-lg">{detailLine.runtime}</span></div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <span className="text-xs text-gray-500 block mb-1">نسبة المستبعدين</span>
                <div className="w-full h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div className="h-full bg-red-500 rounded-full" style={{ width: `${Math.min(100, (detailLine.rejects / detailLine.outputCount) * 100 * 20)}%` }} />
                </div>
                <span className="text-xs mt-1 block">{((detailLine.rejects / detailLine.outputCount) * 100).toFixed(2)}%</span>
              </div>
            </div>
          )}
          {detailLine && detailLine.status !== 'active' && (
            <div className="mt-4 p-8 text-center text-gray-500">
              <AlertTriangle size={32} className="mx-auto mb-2" />
              <p>الخط غير نشط حالياً</p>
              <p className="text-sm">الحالة: {statusConfig[detailLine.status].label}</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
