// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bird, Syringe, HeartPulse, TrendingUp, TrendingDown, Users, Truck,
  Calendar, AlertTriangle, CheckCircle2, XCircle, Plus, Search, Eye,
  Edit3, Trash2, DollarSign, BarChart3, Package, ClipboardList,
  ThermometerSun, Droplets, Weight, Activity, Factory, MapPin,
  Phone, Star, Filter, Download, ChevronDown, Egg
} from 'lucide-react';
import { cn } from '@/lib/utils';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

/* ─────────────────────── mock data ─────────────────────── */

const SUPPLIERS = [
  { id: 1, name: 'Cobb Arabia', country: 'السعودية', rating: 4.9, chicksSupplied: 25000, lastDelivery: '2025-01-10', contact: 'Faisal@cobbarabia.com', phone: '0555123456', breeds: ['Cobb 500', 'Cobb 700'] },
  { id: 2, name: 'Ross Middle East', country: 'الإمارات', rating: 4.7, chicksSupplied: 18000, lastDelivery: '2025-01-08', contact: 'info@ross-me.com', phone: '0555234567', breeds: ['Ross 308', 'Ross 508'] },
  { id: 3, name: 'Arbor Acres Gulf', country: 'البحرين', rating: 4.6, chicksSupplied: 12000, lastDelivery: '2025-01-05', contact: 'sales@aagulf.com', phone: '0555345678', breeds: ['Arbor Acres Plus'] },
  { id: 4, name: 'Hubbard Saudi', country: 'السعودية', rating: 4.5, chicksSupplied: 8000, lastDelivery: '2024-12-28', contact: 'contact@hubbard.sa', phone: '0555456789', breeds: ['Hubbard Classic'] },
];

const BREEDS = [
  { id: 1, name: 'Cobb 500', supplier: 'Cobb Arabia', growthRate: 95, fcr: 1.62, mortality: 3.8, weight42: 2.85, eggProduction: 170, color: '#0a4a30' },
  { id: 2, name: 'Ross 308', supplier: 'Ross Middle East', growthRate: 93, fcr: 1.65, mortality: 4.2, weight42: 2.78, eggProduction: 165, color: '#0d6b43' },
  { id: 3, name: 'Cobb 700', supplier: 'Cobb Arabia', growthRate: 92, fcr: 1.68, mortality: 4.0, weight42: 3.15, eggProduction: 160, color: '#daa520' },
  { id: 4, name: 'Ross 508', supplier: 'Ross Middle East', growthRate: 90, fcr: 1.70, mortality: 4.5, weight42: 2.92, eggProduction: 162, color: '#2563eb' },
  { id: 5, name: 'Arbor Acres Plus', supplier: 'Arbor Acres Gulf', growthRate: 91, fcr: 1.66, mortality: 4.1, weight42: 2.80, eggProduction: 168, color: '#7c3aed' },
];

const RESERVATIONS = [
  { id: 'RES-001', customer: 'مؤسسة الدواجن الذهبية', breed: 'Cobb 500', quantity: 10000, date: '2025-02-01', status: 'مؤكد', deposit: 25000 },
  { id: 'RES-002', customer: 'شركة النور للدواجن', breed: 'Ross 308', quantity: 8000, date: '2025-02-10', status: 'قيد المراجعة', deposit: 15000 },
  { id: 'RES-003', customer: 'مزرعة السعادة', breed: 'Cobb 700', quantity: 5000, date: '2025-02-15', status: 'مؤكد', deposit: 18000 },
  { id: 'RES-004', customer: 'مؤسسة الرفاهية', breed: 'Arbor Acres Plus', quantity: 12000, date: '2025-03-01', status: 'قيد المراجعة', deposit: 28000 },
  { id: 'RES-005', customer: 'شركة الوادي الأخضر', breed: 'Cobb 500', quantity: 15000, date: '2025-03-10', status: 'مؤكد', deposit: 35000 },
  { id: 'RES-006', customer: 'مزرعة الفيصلية', breed: 'Ross 508', quantity: 6000, date: '2025-03-15', status: 'ملغي', deposit: 0 },
];

const SALES = [
  { id: 1, date: '2025-01-15', breed: 'Cobb 500', quantity: 5000, price: 2.5, total: 12500, customer: 'مؤسسة الدواجن الذهبية' },
  { id: 2, date: '2025-01-15', breed: 'Ross 308', quantity: 3200, price: 2.4, total: 7680, customer: 'شركة النور للدواجن' },
  { id: 3, date: '2025-01-14', breed: 'Cobb 500', quantity: 4500, price: 2.5, total: 11250, customer: 'مزرعة السعادة' },
  { id: 4, date: '2025-01-14', breed: 'Arbor Acres Plus', quantity: 2800, price: 2.6, total: 7280, customer: 'مؤسسة الرفاهية' },
  { id: 5, date: '2025-01-13', breed: 'Cobb 700', quantity: 2000, price: 2.8, total: 5600, customer: 'شركة الوادي الأخضر' },
  { id: 6, date: '2025-01-13', breed: 'Ross 308', quantity: 3800, price: 2.4, total: 9120, customer: 'مزرعة الفيصلية' },
  { id: 7, date: '2025-01-12', breed: 'Cobb 500', quantity: 6000, price: 2.5, total: 15000, customer: 'مؤسسة الدواجن الذهبية' },
  { id: 8, date: '2025-01-12', breed: 'Ross 508', quantity: 1500, price: 2.3, total: 3450, customer: 'شركة النور للدواجن' },
];

const MORTALITY = [
  { id: 1, date: '2025-01-15', batch: 'BT-2025-001', breed: 'Cobb 500', age: 14, dead: 18, total: 5000, rate: 0.36, cause: 'ارتفاع حرارة', action: 'تعديل تبريد' },
  { id: 2, date: '2025-01-15', batch: 'BT-2025-002', breed: 'Ross 308', age: 21, dead: 12, total: 8000, rate: 0.15, cause: 'طبيعي', action: 'مراقبة' },
  { id: 3, date: '2025-01-14', batch: 'BT-2025-001', breed: 'Cobb 500', age: 13, dead: 22, total: 5000, rate: 0.44, cause: 'تسلخ جلدي', action: 'علاج' },
  { id: 4, date: '2025-01-14', batch: 'BT-2025-003', breed: 'Cobb 700', age: 7, dead: 8, total: 3000, rate: 0.27, cause: 'طبيعي', action: 'مراقبة' },
  { id: 5, date: '2025-01-13', batch: 'BT-2025-002', breed: 'Ross 308', age: 20, dead: 15, total: 8000, rate: 0.19, cause: 'كوكسيديا', action: 'تطعيم' },
];

const VACCINATIONS = [
  { id: 1, batch: 'BT-2025-001', vaccine: '新城疫 (ND)', date: '2025-01-10', nextDose: '2025-01-24', status: 'تم', method: 'رش' },
  { id: 2, batch: 'BT-2025-001', vaccine: 'إنفلونزا (AI)', date: '2025-01-12', nextDose: '2025-01-26', status: 'تم', method: 'حقن' },
  { id: 3, batch: 'BT-2025-002', vaccine: 'كوكسيديا', date: '2025-01-15', nextDose: '2025-01-22', status: 'قادم', method: 'فم' },
  { id: 4, batch: 'BT-2025-003', vaccine: 'الغامبورو (IBD)', date: '2025-01-08', nextDose: '2025-01-18', status: 'تم', method: 'رش' },
  { id: 5, batch: 'BT-2025-003', vaccine: '新城疫 (ND)', date: '2025-01-18', nextDose: '2025-02-01', status: 'قادم', method: 'رش' },
  { id: 6, batch: 'BT-2025-001', vaccine: 'Gumboro Booster', date: '2025-01-20', nextDose: '-', status: 'قادم', method: 'حقن' },
];

const TABS = [
  { key: 'suppliers', label: 'الموردين', icon: Truck },
  { key: 'breeds', label: 'السلالات', icon: Bird },
  { key: 'reservations', label: 'الحجوزات', icon: ClipboardList },
  { key: 'sales', label: 'المبيعات', icon: DollarSign },
  { key: 'mortality', label: 'النفوق', icon: HeartPulse },
  { key: 'vaccinations', label: 'التطعيمات', icon: Syringe },
  { key: 'analytics', label: 'التحليلات', icon: BarChart3 },
];

const statusBadge = (s: string) => {
  const map: Record<string, string> = {
    'مؤكد': 'bg-green-100 text-green-700', 'قيد المراجعة': 'bg-amber-100 text-amber-700',
    'ملغي': 'bg-red-100 text-red-700', 'تم': 'bg-green-100 text-green-700',
    'قادم': 'bg-blue-100 text-blue-700', 'طبيعي': 'bg-green-100 text-green-700',
    'مراقبة': 'bg-blue-100 text-blue-700', 'علاج': 'bg-amber-100 text-amber-700',
    'تطعيم': 'bg-purple-100 text-purple-700',
  };
  return map[s] || 'bg-slate-100 text-slate-600';
};

/* ─────────────────────── mini charts ─────────────────────── */

function MiniBarChart({ data, labels, color }: { data: number[]; labels: string[]; color: string }) {
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-2 h-28">
      {data.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <span className="text-[10px] text-textMuted">{v}</span>
          <div className="w-full rounded-t-sm" style={{ height: `${(v / max) * 100}px`, backgroundColor: color, opacity: 0.5 + (i / data.length) * 0.5 }} />
          <span className="text-[10px] text-textMuted">{labels[i]}</span>
        </div>
      ))}
    </div>
  );
}

function MiniPieChart({ data, colors }: { data: number[]; colors: string[] }) {
  const total = data.reduce((a, b) => a + b, 0);
  let offset = 0;
  return (
    <svg viewBox="0 0 100 100" className="w-24 h-24">
      {data.map((v, i) => {
        const pct = (v / total) * 360;
        const el = (
          <circle key={i} cx="50" cy="50" r="40" fill="none" stroke={colors[i]} strokeWidth="20" strokeDasharray={`${pct} ${360 - pct}`} transform={`rotate(${offset - 90} 50 50)`} />
        );
        offset += pct;
        return el;
      })}
    </svg>
  );
}

/* ─────────────────────── main page ─────────────────────── */

export default function PoultryPage() {
  const [activeTab, setActiveTab] = useState('suppliers');
  const [searchQ, setSearchQ] = useState('');

  const totalChicks = 45000;
  const todaySales = SALES.filter(s => s.date === '2025-01-15').reduce((a, s) => a + s.total, 0);
  const avgMortality = (MORTALITY.reduce((a, m) => a + m.rate, 0) / MORTALITY.length).toFixed(2);
  const profit = todaySales * 0.22;

  return (
    <div className="p-4 md:p-6">
      <PageHeader title="تجارة الكتاكيت" subtitle="إدارة الموردين والسلالات والحجوزات والمبيعات">
        <button className="flex items-center gap-2 px-4 py-2 bg-[#0a4a30] hover:bg-[#0d6b43] text-white rounded-lg text-sm font-medium transition-colors">
          <Plus size={16} /> حجز جديد
        </button>
      </PageHeader>

      {/* ─── KPIs ─── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        <KPICard title="إجمالي الكتاكيت" value={totalChicks.toLocaleString()} icon={Bird} iconBg="bg-amber-50" iconColor="text-amber-600" delay={0} />
        <KPICard title="مبيعات اليوم" value={`${todaySales.toLocaleString()} ر.س`} change={8} icon={DollarSign} iconBg="bg-green-50" iconColor="text-green-600" delay={0.05} />
        <KPICard title="نسبة النفوق" value={`${avgMortality}%`} change={-12} icon={HeartPulse} iconBg="bg-red-50" iconColor="text-red-600" delay={0.1} />
        <KPICard title="الموردين" value={SUPPLIERS.length.toString()} icon={Truck} iconBg="bg-blue-50" iconColor="text-blue-600" delay={0.15} />
        <KPICard title="العملاء" value="24" change={5} icon={Users} iconBg="bg-purple-50" iconColor="text-purple-600" delay={0.2} />
        <KPICard title="الربح المتوقع" value={`${Math.round(profit).toLocaleString()} ر.س`} change={15} icon={TrendingUp} iconBg="bg-emerald-50" iconColor="text-emerald-600" delay={0.25} />
      </div>

      {/* ─── Tabs ─── */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card">
        <div className="flex overflow-x-auto border-b border-uiBorder dark:border-darkBorder scrollbar-hide">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className={cn('flex items-center gap-2 px-5 py-3.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
                activeTab === t.key ? 'border-[#0a4a30] text-[#0a4a30] dark:text-green-400' : 'border-transparent text-textSecondary hover:text-textPrimary dark:text-darkTextSec')}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>

        <div className="p-4 md:p-5">
          <AnimatePresence mode="wait">

            {/* ─── Suppliers ─── */}
            {activeTab === 'suppliers' && (
              <motion.div key="suppliers" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">موردي الكتاكيت</h3>
                  <div className="relative w-56">
                    <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                    <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                      className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {SUPPLIERS.filter(s => !searchQ || s.name.includes(searchQ)).map((s, i) => (
                    <motion.div key={s.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                      className="bg-surface dark:bg-darkBg rounded-xl border border-uiBorder dark:border-darkBorder p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-[#0a4a30] flex items-center justify-center text-white font-bold text-lg">
                            {s.name.charAt(0)}
                          </div>
                          <div>
                            <h4 className="font-bold text-textPrimary dark:text-darkText">{s.name}</h4>
                            <p className="text-xs text-textMuted flex items-center gap-1"><MapPin size={10} /> {s.country}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 px-2 py-1 bg-amber-50 rounded-full">
                          <Star size={12} className="text-amber-500 fill-amber-500" />
                          <span className="text-xs font-semibold text-amber-700">{s.rating}</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        <div className="bg-white dark:bg-darkSurface rounded-lg p-2 text-center">
                          <p className="text-lg font-bold text-[#0a4a30]">{s.chicksSupplied.toLocaleString()}</p>
                          <p className="text-[11px] text-textMuted">كتاكيت مسلمة</p>
                        </div>
                        <div className="bg-white dark:bg-darkSurface rounded-lg p-2 text-center">
                          <p className="text-lg font-bold text-[#daa520]">{s.breeds.length}</p>
                          <p className="text-[11px] text-textMuted">سلالات</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-xs border-t border-uiBorder dark:border-darkBorder pt-2">
                        <span className="text-textSecondary dark:text-darkTextSec">آخر توريد: {s.lastDelivery}</span>
                        <div className="flex gap-1">
                          <button className="w-7 h-7 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors"><Phone size={13} /></button>
                          <button className="w-7 h-7 rounded-lg flex items-center justify-center text-amber-500 hover:bg-amber-50 transition-colors"><Eye size={13} /></button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ─── Breeds ─── */}
            {activeTab === 'breeds' && (
              <motion.div key="breeds" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">السلالات المتاحة</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  {BREEDS.map((b, i) => (
                    <motion.div key={b.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                      className="bg-surface dark:bg-darkBg rounded-xl border border-uiBorder dark:border-darkBorder p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-bold text-textPrimary dark:text-darkText" style={{ color: b.color }}>{b.name}</h4>
                        <span className="text-[11px] text-textMuted bg-white dark:bg-darkSurface px-2 py-0.5 rounded-full">{b.supplier}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 mb-3">
                        <div className="bg-white dark:bg-darkSurface rounded-lg p-2 text-center">
                          <p className="text-sm font-bold text-textPrimary dark:text-darkText">{b.fcr}</p>
                          <p className="text-[10px] text-textMuted">FCR</p>
                        </div>
                        <div className="bg-white dark:bg-darkSurface rounded-lg p-2 text-center">
                          <p className="text-sm font-bold text-textPrimary dark:text-darkText">{b.weight42}كغ</p>
                          <p className="text-[10px] text-textMuted">وزن 42يوم</p>
                        </div>
                        <div className="bg-white dark:bg-darkSurface rounded-lg p-2 text-center">
                          <p className="text-sm font-bold text-textPrimary dark:text-darkText">{b.mortality}%</p>
                          <p className="text-[10px] text-textMuted">نفوق</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-[11px] mb-0.5">
                            <span className="text-textMuted">معدل النمو</span>
                            <span className="font-semibold">{b.growthRate}%</span>
                          </div>
                          <div className="h-1.5 bg-white dark:bg-darkSurface rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${b.growthRate}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className="h-full rounded-full" style={{ backgroundColor: b.color }} />
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between text-[11px] mb-0.5">
                            <span className="text-textMuted">إنتاج البيض</span>
                            <span className="font-semibold">{b.eggProduction} بيضة</span>
                          </div>
                          <div className="h-1.5 bg-white dark:bg-darkSurface rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(b.eggProduction / 200) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className="h-full rounded-full" style={{ backgroundColor: b.color, opacity: 0.7 }} />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* ─── Reservations ─── */}
            {activeTab === 'reservations' && (
              <motion.div key="reservations" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">الحجوزات</h3>
                  <div className="relative w-56">
                    <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                    <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                      className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                    <thead>
                      <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                        {['رقم الحجز', 'العميل', 'السلالة', 'الكمية', 'التاريخ', 'العربون', 'الحالة', ''].map(h => (
                          <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {RESERVATIONS.filter(r => !searchQ || r.customer.includes(searchQ)).map((r, i) => (
                        <motion.tr key={r.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                          className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                        >
                          <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{r.id}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{r.customer}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{r.breed}</td>
                          <td className="px-3 py-2.5 text-sm font-semibold text-textPrimary dark:text-darkText">{r.quantity.toLocaleString()}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{r.date}</td>
                          <td className="px-3 py-2.5 text-sm font-semibold text-green-600">{r.deposit.toLocaleString()} ر.س</td>
                          <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(r.status))}>{r.status}</span></td>
                          <td className="px-3 py-2.5">
                            <div className="flex items-center gap-1 justify-center">
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors"><Eye size={15} /></button>
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-amber-500 hover:bg-amber-50 transition-colors"><Edit3 size={15} /></button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* ─── Sales ─── */}
            {activeTab === 'sales' && (
              <motion.div key="sales" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">المبيعات اليومية</h3>
                  <button className="flex items-center gap-1.5 px-3 py-1.5 border border-uiBorder rounded-lg text-xs text-textSecondary hover:bg-surface transition-colors">
                    <Download size={14} /> تصدير
                  </button>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['التاريخ', 'السلالة', 'العميل', 'الكمية', 'السعر', 'الإجمالي'].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {SALES.map((s, i) => (
                            <motion.tr key={s.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{s.date}</td>
                              <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{s.breed}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{s.customer}</td>
                              <td className="px-3 py-2.5 text-sm font-semibold text-textPrimary dark:text-darkText">{s.quantity.toLocaleString()}</td>
                              <td className="px-3 py-2.5 text-sm text-green-600 font-semibold">{s.price} ر.س</td>
                              <td className="px-3 py-2.5 text-sm font-bold text-green-600">{s.total.toLocaleString()} ر.س</td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">إجمالي المبيعات حسب السلالة</h4>
                      {[
                        { breed: 'Cobb 500', amount: 38750, qty: 15500 },
                        { breed: 'Ross 308', amount: 16800, qty: 7000 },
                        { breed: 'Cobb 700', amount: 5600, qty: 2000 },
                        { breed: 'Arbor Acres Plus', amount: 7280, qty: 2800 },
                        { breed: 'Ross 508', amount: 3450, qty: 1500 },
                      ].map((item, i) => (
                        <div key={item.breed} className="mb-3">
                          <div className="flex justify-between text-xs mb-0.5">
                            <span className="text-textSecondary dark:text-darkTextSec">{item.breed}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{item.amount.toLocaleString()} ر.س</span>
                          </div>
                          <div className="h-2 bg-surface dark:bg-darkBg rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(item.amount / 38750) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className="h-full rounded-full bg-[#0a4a30]" />
                          </div>
                          <p className="text-[10px] text-textMuted mt-0.5">{item.qty.toLocaleString()} كتكوت</p>
                        </div>
                      ))}
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">ملخص المبيعات</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'إجمالي المبيعات', value: `${SALES.reduce((a, s) => a + s.total, 0).toLocaleString()} ر.س` },
                          { label: 'إجمالي الكمية', value: `${SALES.reduce((a, s) => a + s.quantity, 0).toLocaleString()} كتكوت` },
                          { label: 'متوسط السعر', value: `${(SALES.reduce((a, s) => a + s.price, 0) / SALES.length).toFixed(2)} ر.س` },
                          { label: 'عدد العملاء', value: '8' },
                        ].map(s => (
                          <div key={s.label} className="flex items-center justify-between text-xs">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{s.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Mortality ─── */}
            {activeTab === 'mortality' && (
              <motion.div key="mortality" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">سجل النفوق</h3>
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['التاريخ', 'الدفعة', 'السلالة', 'العمر', 'النفوق', 'إجمالي', 'النسبة', 'السبب', 'الإجراء'].map(h => (
                              <th key={h} className="px-2 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {MORTALITY.map((m, i) => (
                            <motion.tr key={m.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.date}</td>
                              <td className="px-2 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{m.batch}</td>
                              <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.breed}</td>
                              <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.age} يوم</td>
                              <td className="px-2 py-2.5 text-sm font-semibold text-red-600">{m.dead}</td>
                              <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.total.toLocaleString()}</td>
                              <td className="px-2 py-2.5"><span className={cn('text-xs font-semibold', m.rate > 0.4 ? 'text-red-600' : m.rate > 0.2 ? 'text-amber-600' : 'text-green-600')}>{m.rate}%</span></td>
                              <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.cause}</td>
                              <td className="px-2 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(m.action))}>{m.action}</span></td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">أسباب النفوق</h4>
                      {[
                        { cause: 'طبيعي', count: 35, pct: 40 },
                        { cause: 'ارتفاع حرارة', count: 22, pct: 25 },
                        { cause: 'كوكسيديا', count: 15, pct: 17 },
                        { cause: 'تسلخ جلدي', count: 10, pct: 11 },
                        { cause: 'أخرى', count: 6, pct: 7 },
                      ].map((item, i) => (
                        <div key={item.cause} className="mb-2.5">
                          <div className="flex justify-between text-xs mb-0.5">
                            <span className="text-textSecondary dark:text-darkTextSec">{item.cause}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{item.count} ({item.pct}%)</span>
                          </div>
                          <div className="h-2 bg-surface dark:bg-darkBg rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${item.pct}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className={cn('h-full rounded-full', i === 0 ? 'bg-green-500' : i === 1 ? 'bg-red-500' : i === 2 ? 'bg-amber-500' : 'bg-slate-400')} />
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">مؤشرات النفوق</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'متوسط النفوق اليومي', value: '0.28%' },
                          { label: 'نفوق الأسبوع', value: '1.95%' },
                          { label: 'نفوق الشهر', value: '3.82%' },
                          { label: 'الهدف', value: '< 4.0%' },
                        ].map(s => (
                          <div key={s.label} className="flex items-center justify-between text-xs">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                            <span className={cn('font-semibold', s.label === 'الهدف' ? 'text-green-600' : 'text-textPrimary dark:text-darkText')}>{s.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Vaccinations ─── */}
            {activeTab === 'vaccinations' && (
              <motion.div key="vaccinations" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">جدول التطعيمات</h3>
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['الدفعة', 'التطعيم', 'التاريخ', 'التطعيم القادم', 'الحالة', 'الطريقة'].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {VACCINATIONS.map((v, i) => (
                            <motion.tr key={v.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{v.batch}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{v.vaccine}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{v.date}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{v.nextDose}</td>
                              <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(v.status))}>{v.status}</span></td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{v.method}</td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">تطعيمات قادمة</h4>
                      {VACCINATIONS.filter(v => v.status === 'قادم').map(v => (
                        <div key={v.id} className="flex items-start gap-2 mb-2 p-2 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                          <Calendar size={14} className="text-blue-500 mt-0.5 shrink-0" />
                          <div>
                            <p className="text-xs font-medium text-textPrimary dark:text-darkText">{v.vaccine}</p>
                            <p className="text-[11px] text-textMuted">{v.batch} | {v.nextDose} | {v.method}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">ملخص التطعيمات</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'التطعيمات المكتملة', value: VACCINATIONS.filter(v => v.status === 'تم').length.toString() },
                          { label: 'التطعيمات القادمة', value: VACCINATIONS.filter(v => v.status === 'قادم').length.toString() },
                          { label: 'إجمالي الدفعات', value: '3' },
                          { label: 'التغطية', value: '100%' },
                        ].map(s => (
                          <div key={s.label} className="flex items-center justify-between text-xs">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{s.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Analytics ─── */}
            {activeTab === 'analytics' && (
              <motion.div key="analytics" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">اتجاه المبيعات (آخر 7 أيام)</h4>
                    <MiniBarChart data={[18500, 22000, 16800, 24500, 19200, 21000, 20180]} labels={['9', '10', '11', '12', '13', '14', '15']} color="#0a4a30" />
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">مقارنة النفوق حسب السلالة</h4>
                    <MiniBarChart data={[3.8, 4.2, 4.0, 4.5, 4.1]} labels={['Cobb500', 'Ross308', 'Cobb700', 'Ross508', 'AA+']} color="#ef4444" />
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">توزيع المبيعات حسب السلالة</h4>
                    <div className="flex items-center justify-center mb-4">
                      <MiniPieChart data={[15500, 7000, 2000, 2800, 1500]} colors={['#0a4a30', '#0d6b43', '#daa520', '#7c3aed', '#2563eb']} />
                    </div>
                    <div className="space-y-1.5">
                      {BREEDS.map((b, i) => (
                        <div key={b.id} className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ['#0a4a30', '#0d6b43', '#daa520', '#7c3aed', '#2563eb'][i] }} />
                          <span className="text-xs text-textSecondary dark:text-darkTextSec flex-1">{b.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">أداء الموردين</h4>
                    <div className="space-y-3">
                      {SUPPLIERS.map((s, i) => (
                        <div key={s.id}>
                          <div className="flex justify-between text-xs mb-0.5">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.name}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{s.chicksSupplied.toLocaleString()} كتكوت</span>
                          </div>
                          <div className="h-2 bg-surface dark:bg-darkBg rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(s.chicksSupplied / 25000) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className="h-full rounded-full bg-[#daa520]" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
