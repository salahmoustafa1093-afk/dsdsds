// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import {
  Warehouse,
  DollarSign,
  ArrowLeftRight,
  Clock,
  Search,
  Plus,
  Eye,
  Edit3,
  Trash2,
  MapPin,
  Package,
  Users,
  ChevronLeft,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

/* ──────────────────────────── mock data ──────────────────────────── */

interface WarehouseData {
  id: string;
  name: string;
  location: string;
  type: 'main' | 'branch';
  capacity: number;
  used: number;
  manager: string;
  phone: string;
  status: 'active' | 'full' | 'maintenance';
  products: { name: string; qty: number; unit: string }[];
  movements: { date: string; type: string; product: string; qty: number; user: string }[];
}

const WAREHOUSES: WarehouseData[] = [
  {
    id: '1', name: 'مستودع القاهرة الرئيسي', location: 'المنطقة الصناعية، مدينة السلام، القاهرة', type: 'main', capacity: 5000, used: 3800, manager: 'أحمد محمود', phone: '0100-123-4567', status: 'active',
    products: [
      { name: 'أعلاف دواجن بادئ', qty: 1200, unit: 'شيكارة' },
      { name: 'ذرة صفراء', qty: 850, unit: 'طن' },
      { name: 'كسب فول صويا', qty: 620, unit: 'طن' },
      { name: 'ردة قمح', qty: 430, unit: 'طن' },
      { name: 'أعلاف دواجن نامي', qty: 700, unit: 'شيكارة' },
    ],
    movements: [
      { date: '2025-06-20 08:30', type: 'وارد', product: 'ذرة صفراء', qty: 120, user: 'محمد علي' },
      { date: '2025-06-20 10:15', type: 'صادر', product: 'أعلاف بادئ', qty: 50, user: 'خالد حسن' },
      { date: '2025-06-19 14:00', type: 'تحويل', product: 'كسب فول صويا', qty: 80, user: 'أحمد محمود' },
      { date: '2025-06-19 09:30', type: 'وارد', product: 'ردة قمح', qty: 200, user: 'محمد علي' },
    ],
  },
  {
    id: '2', name: 'مستودع الإسكندرية', location: 'منطقة البرج، طريق مصر-إسكندرية الصحراوي', type: 'branch', capacity: 3000, used: 2400, manager: 'سعيد فؤاد', phone: '0100-987-6543', status: 'active',
    products: [
      { name: 'أعلاف دواجن ناهي', qty: 450, unit: 'شيكارة' },
      { name: 'كسب فول صويا', qty: 380, unit: 'طن' },
      { name: 'نخالة قمح', qty: 520, unit: 'طن' },
      { name: 'شعير', qty: 290, unit: 'طن' },
    ],
    movements: [
      { date: '2025-06-20 07:00', type: 'وارد', product: 'أعلاف ناهي', qty: 80, user: 'سعيد فؤاد' },
      { date: '2025-06-19 16:00', type: 'صادر', product: 'كسب فول صويا', qty: 40, user: 'محمد رضا' },
      { date: '2025-06-19 11:00', type: 'تحويل', product: 'نخالة قمح', qty: 100, user: 'سعيد فؤاد' },
    ],
  },
  {
    id: '3', name: 'مستودع طنطا', location: 'المنطقة الصناعية الثالثة، طنطا، الغربية', type: 'branch', capacity: 2500, used: 2100, manager: 'محمد رضا', phone: '0101-234-5678', status: 'full',
    products: [
      { name: 'ذرة صفراء', qty: 600, unit: 'طن' },
      { name: 'ردة قمح', qty: 350, unit: 'طن' },
      { name: 'أعلاف دواجن بادئ', qty: 480, unit: 'شيكارة' },
      { name: 'خلطة فيتامينات', qty: 120, unit: 'علبة' },
    ],
    movements: [
      { date: '2025-06-20 09:00', type: 'وارد', product: 'ذرة صفراء', qty: 200, user: 'محمد رضا' },
      { date: '2025-06-19 13:00', type: 'صادر', product: 'ردة قمح', qty: 150, user: 'علي سالم' },
    ],
  },
  {
    id: '4', name: 'مستودع المنصورة', location: 'طريق جمصة، المنصورة، الدقهلية', type: 'branch', capacity: 2000, used: 1200, manager: 'علي سالم', phone: '0102-345-6789', status: 'active',
    products: [
      { name: 'أعلاف دواجن نامي', qty: 380, unit: 'شيكارة' },
      { name: 'فول صويا كامل', qty: 220, unit: 'طن' },
      { name: 'مسحوق عظام', qty: 90, unit: 'كجم' },
      { name: 'حجر جيري', qty: 200, unit: 'كجم' },
    ],
    movements: [
      { date: '2025-06-20 06:30', type: 'وارد', product: 'فول صويا كامل', qty: 100, user: 'علي سالم' },
      { date: '2025-06-19 15:00', type: 'صادر', product: 'أعلاف نامي', qty: 60, user: 'محمد رضا' },
      { date: '2025-06-18 10:00', type: 'وارد', product: 'مسحوق عظام', qty: 50, user: 'علي سالم' },
    ],
  },
];

const TYPE_MAP: Record<string, { label: string; color: string }> = {
  main: { label: 'رئيسي', color: 'text-purple-700 bg-purple-100 dark:bg-purple-900/30' },
  branch: { label: 'فرعي', color: 'text-blue-700 bg-blue-100 dark:bg-blue-900/30' },
};

const STATUS_MAP: Record<string, { label: string; color: string }> = {
  active: { label: 'نشط', color: 'text-green-700 bg-green-100 dark:bg-green-900/30' },
  full: { label: 'ممتلئ', color: 'text-amber-700 bg-amber-100 dark:bg-amber-900/30' },
  maintenance: { label: 'صيانة', color: 'text-red-700 bg-red-100 dark:bg-red-900/30' },
};

/* ──────────────────────────── component ──────────────────────────── */

export default function InventoryPage() {
  const [warehouses, setWarehouses] = useState<WarehouseData[]>(WAREHOUSES);
  const [selectedWarehouse, setSelectedWarehouse] = useState<WarehouseData | null>(null);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const filtered = useMemo(() => {
    return warehouses.filter((w) => {
      const q = search.trim();
      const matchSearch = q === '' || w.name.includes(q) || w.location.includes(q) || w.manager.includes(q);
      const matchType = typeFilter === 'all' || w.type === typeFilter;
      const matchStatus = statusFilter === 'all' || w.status === statusFilter;
      return matchSearch && matchType && matchStatus;
    });
  }, [warehouses, search, typeFilter, statusFilter]);

  const totalWarehouses = warehouses.length;
  const totalValue = warehouses.reduce((s, w) => s + w.products.reduce((ps, p) => ps + p.qty * 100, 0), 0);
  const todayMovements = warehouses.reduce((s, w) => s + w.movements.filter((m) => m.date.startsWith('2025-06-20')).length, 0);
  const pendingTransfers = warehouses.reduce((s, w) => s + w.movements.filter((m) => m.type === 'تحويل').length, 0);

  const deleteWarehouse = (id: string) => {
    setWarehouses((prev) => prev.filter((w) => w.id !== id));
  };

  const formatEGP = (n: number) => n.toLocaleString('ar-EG') + ' ج.م';

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="إدارة المخازن"
        subtitle="المستودعات والمخزون وحركات التخزين"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'إدارة المخازن' }]}
      >
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-[#0a4a30] hover:bg-[#0d6b43] text-white gap-2">
              <Plus size={16} />
              مستودع جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-right text-lg">إضافة مستودع جديد</DialogTitle>
            </DialogHeader>
            <WarehouseForm onSave={(w) => setWarehouses((prev) => [w, ...prev])} />
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="عدد المستودعات" value={totalWarehouses.toString()} icon={Warehouse} iconBg="bg-green-100" iconColor="text-green-600" change={1} delay={0} />
        <KPICard title="قيمة المخزون" value={formatEGP(totalValue)} icon={DollarSign} iconBg="bg-amber-100" iconColor="text-amber-600" change={12} delay={0.1} />
        <KPICard title="حركات اليوم" value={todayMovements.toString()} icon={ArrowLeftRight} iconBg="bg-blue-100" iconColor="text-blue-600" change={5} delay={0.2} />
        <KPICard title="تحويلات معلقة" value={pendingTransfers.toString()} icon={Clock} iconBg="bg-red-100" iconColor="text-red-600" change={-2} delay={0.3} />
      </div>

      {/* Warehouse Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((w) => {
          const usedPct = Math.round((w.used / w.capacity) * 100);
          const isFull = usedPct >= 90;
          const barColor = isFull ? 'bg-amber-500' : usedPct >= 70 ? 'bg-amber-400' : 'bg-green-500';
          return (
            <motion.div
              key={w.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setSelectedWarehouse(w)}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', w.type === 'main' ? 'bg-purple-100' : 'bg-blue-100')}>
                        <Warehouse size={20} className={w.type === 'main' ? 'text-purple-600' : 'text-blue-600'} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm">{w.name}</h3>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <MapPin size={10} />
                          {w.location.slice(0, 40)}...
                        </div>
                      </div>
                    </div>
                    <Badge className={cn('text-[10px] border-0', TYPE_MAP[w.type].color)}>
                      {TYPE_MAP[w.type].label}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    <div className="bg-gray-50 dark:bg-gray-800 p-2 rounded text-center">
                      <Package size={14} className="mx-auto mb-1 text-gray-400" />
                      <span className="text-xs text-gray-500 block">منتجات</span>
                      <span className="text-sm font-bold">{w.products.length}</span>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 p-2 rounded text-center">
                      <Users size={14} className="mx-auto mb-1 text-gray-400" />
                      <span className="text-xs text-gray-500 block">المدير</span>
                      <span className="text-xs font-semibold truncate">{w.manager}</span>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800 p-2 rounded text-center">
                      <Badge className={cn('text-[10px] border-0', STATUS_MAP[w.status].color)}>
                        {STATUS_MAP[w.status].label}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-gray-500">السعة ({usedPct}%)</span>
                      <span className="text-gray-500">{w.used.toLocaleString('ar-EG')} / {w.capacity.toLocaleString('ar-EG')}</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className={cn('h-full rounded-full transition-all', barColor)} style={{ width: `${usedPct}%` }} />
                    </div>
                  </div>
                  <div className="flex items-center justify-end gap-1 mt-3 pt-2 border-t border-gray-100">
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600" onClick={(e) => { e.stopPropagation(); setSelectedWarehouse(w); }}>
                      <Eye size={14} />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600">
                      <Edit3 size={14} />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={(e) => { e.stopPropagation(); deleteWarehouse(w.id); }}>
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Table */}
      <Card className="border border-gray-200 dark:border-gray-700 overflow-hidden">
        <CardContent className="p-0">
          <div className="p-4 flex flex-wrap items-center gap-3 border-b border-gray-100">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <Input
                placeholder="بحث باسم المستودع أو الموقع..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-9 text-right"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-32 text-right text-xs"><SelectValue placeholder="النوع" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                <SelectItem value="main">رئيسي</SelectItem>
                <SelectItem value="branch">فرعي</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32 text-right text-xs"><SelectValue placeholder="الحالة" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                <SelectItem value="active">نشط</SelectItem>
                <SelectItem value="full">ممتلئ</SelectItem>
                <SelectItem value="maintenance">صيانة</SelectItem>
              </SelectContent>
            </Select>
            {(search || typeFilter !== 'all' || statusFilter !== 'all') && (
              <Button variant="ghost" size="sm" className="text-red-500 text-xs" onClick={() => { setSearch(''); setTypeFilter('all'); setStatusFilter('all'); }}>
                <X size={12} />
                إلغاء
              </Button>
            )}
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                  <TableHead className="text-right font-semibold text-xs">المستودع</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الموقع</TableHead>
                  <TableHead className="text-right font-semibold text-xs">النوع</TableHead>
                  <TableHead className="text-right font-semibold text-xs">السعة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">المنتجات</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الحالة</TableHead>
                  <TableHead className="text-center font-semibold text-xs">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((w) => (
                  <TableRow key={w.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                    <TableCell className="text-sm font-medium">{w.name}</TableCell>
                    <TableCell className="text-xs text-gray-500 max-w-[200px] truncate">{w.location}</TableCell>
                    <TableCell>
                      <Badge className={cn('text-[10px] border-0', TYPE_MAP[w.type].color)}>{TYPE_MAP[w.type].label}</Badge>
                    </TableCell>
                    <TableCell className="text-xs">
                      <div className="flex items-center gap-2 min-w-[100px]">
                        <span>{Math.round((w.used / w.capacity) * 100)}%</span>
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div className={cn('h-full rounded-full', (w.used / w.capacity) * 100 >= 90 ? 'bg-amber-500' : 'bg-green-500')} style={{ width: `${(w.used / w.capacity) * 100}%` }} />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{w.products.length}</TableCell>
                    <TableCell>
                      <Badge className={cn('text-[10px] border-0', STATUS_MAP[w.status].color)}>{STATUS_MAP[w.status].label}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1">
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600" onClick={() => setSelectedWarehouse(w)}>
                          <Eye size={14} />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => deleteWarehouse(w.id)}>
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-12 text-gray-400">لا توجد مستودعات مطابقة</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Detail Sidebar */}
      <Dialog open={!!selectedWarehouse} onOpenChange={() => setSelectedWarehouse(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-right text-lg flex items-center gap-2">
              <Warehouse size={20} className="text-[#0a4a30]" />
              {selectedWarehouse?.name}
            </DialogTitle>
          </DialogHeader>
          {selectedWarehouse && <WarehouseDetail warehouse={selectedWarehouse} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ──────────────────────────── Warehouse Detail ──────────────────────────── */

function WarehouseDetail({ warehouse }: { warehouse: WarehouseData }) {
  const [tab, setTab] = useState<'products' | 'movements'>('products');
  const usedPct = Math.round((warehouse.used / warehouse.capacity) * 100);

  return (
    <div className="space-y-4" dir="rtl">
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div className="bg-gray-50 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">المدير</span>
          <span className="font-semibold">{warehouse.manager}</span>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">الهاتف</span>
          <span className="font-semibold">{warehouse.phone}</span>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">الموقع</span>
          <span className="font-semibold text-xs">{warehouse.location}</span>
        </div>
        <div className="bg-gray-50 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">الحالة</span>
          <Badge className={cn('text-[10px] border-0 mt-1', STATUS_MAP[warehouse.status].color)}>
            {STATUS_MAP[warehouse.status].label}
          </Badge>
        </div>
      </div>
      <div className="bg-gray-50 p-3 rounded-lg">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="text-gray-500">السعة المستخدمة ({usedPct}%)</span>
          <span className="font-semibold">{warehouse.used.toLocaleString('ar-EG')} / {warehouse.capacity.toLocaleString('ar-EG')}</span>
        </div>
        <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
          <div className={cn('h-full rounded-full transition-all', usedPct >= 90 ? 'bg-amber-500' : 'bg-green-500')} style={{ width: `${usedPct}%` }} />
        </div>
      </div>
      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
        <button
          onClick={() => setTab('products')}
          className={cn('flex-1 text-xs py-2 px-3 rounded-md transition-colors', tab === 'products' ? 'bg-white shadow text-[#0a4a30] font-semibold' : 'text-gray-500')}
        >
          <Package size={12} className="inline ml-1" />
          المنتجات ({warehouse.products.length})
        </button>
        <button
          onClick={() => setTab('movements')}
          className={cn('flex-1 text-xs py-2 px-3 rounded-md transition-colors', tab === 'movements' ? 'bg-white shadow text-[#0a4a30] font-semibold' : 'text-gray-500')}
        >
          <ArrowLeftRight size={12} className="inline ml-1" />
          الحركات ({warehouse.movements.length})
        </button>
      </div>
      {tab === 'products' ? (
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead className="text-right text-xs">المنتج</TableHead>
              <TableHead className="text-right text-xs">الكمية</TableHead>
              <TableHead className="text-right text-xs">الوحدة</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {warehouse.products.map((p, i) => (
              <TableRow key={i}>
                <TableCell className="text-sm">{p.name}</TableCell>
                <TableCell className="text-sm font-semibold">{p.qty.toLocaleString('ar-EG')}</TableCell>
                <TableCell className="text-xs text-gray-500">{p.unit}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead className="text-right text-xs">التاريخ</TableHead>
              <TableHead className="text-right text-xs">النوع</TableHead>
              <TableHead className="text-right text-xs">المنتج</TableHead>
              <TableHead className="text-right text-xs">الكمية</TableHead>
              <TableHead className="text-right text-xs">المستخدم</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {warehouse.movements.map((m, i) => (
              <TableRow key={i}>
                <TableCell className="text-xs text-gray-500">{m.date}</TableCell>
                <TableCell>
                  <Badge className={cn('text-[10px] border-0',
                    m.type === 'وارد' ? 'bg-green-100 text-green-700' :
                    m.type === 'صادر' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                  )}>{m.type}</Badge>
                </TableCell>
                <TableCell className="text-sm">{m.product}</TableCell>
                <TableCell className="text-sm">{m.qty}</TableCell>
                <TableCell className="text-xs">{m.user}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}

/* ──────────────────────────── Warehouse Form ──────────────────────────── */

function WarehouseForm({ onSave }: { onSave: (w: WarehouseData) => void }) {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [type, setType] = useState<'main' | 'branch'>('branch');
  const [capacity, setCapacity] = useState(1000);
  const [manager, setManager] = useState('');

  const handleSubmit = () => {
    onSave({
      id: Date.now().toString(),
      name: name || 'مستودع جديد',
      location: location || '',
      type,
      capacity: Number(capacity),
      used: 0,
      manager: manager || '',
      phone: '',
      status: 'active',
      products: [],
      movements: [],
    });
  };

  return (
    <div className="space-y-3" dir="rtl">
      <div>
        <Label className="text-xs">اسم المستودع *</Label>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="اسم المستودع" className="text-right" />
      </div>
      <div>
        <Label className="text-xs">الموقع</Label>
        <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="عنوان المستودع" className="text-right" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">النوع</Label>
          <Select value={type} onValueChange={(v) => setType(v as 'main' | 'branch')}>
            <SelectTrigger className="text-right"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="main">رئيسي</SelectItem>
              <SelectItem value="branch">فرعي</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">السعة (م²)</Label>
          <Input type="number" value={capacity} onChange={(e) => setCapacity(parseFloat(e.target.value) || 0)} className="text-center" />
        </div>
      </div>
      <div>
        <Label className="text-xs">مدير المستودع</Label>
        <Input value={manager} onChange={(e) => setManager(e.target.value)} placeholder="اسم المدير" className="text-right" />
      </div>
      <Button onClick={handleSubmit} className="w-full bg-[#0a4a30] hover:bg-[#0d6b43] text-white">
        حفظ المستودع
      </Button>
    </div>
  );
}
