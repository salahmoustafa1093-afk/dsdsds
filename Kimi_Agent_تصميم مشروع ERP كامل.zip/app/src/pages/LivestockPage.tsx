// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Beef, Plus, Search, X, CheckCircle2, Clock, CalendarDays,
  TrendingUp, Syringe, Wheat, Weight, HeartPulse, Filter,
  Pencil, Trash2, Eye, Stethoscope, ChevronRight, ChevronDown,
  Activity, AlertCircle, Edit3,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

/* ─── mock data ─── */
const animals = [
  { id: 1, tagNo: 'CA-2024-001', type: 'عجل', breed: 'بلدي مصري', gender: 'ذكر', age: '8 شهور', weight: 220, pen: 'عنبر أ', status: 'نشط', health: 'جيدة', entryDate: '2024-04-15' },
  { id: 2, tagNo: 'CA-2024-002', type: 'عجل', breed: 'هولشتاين', gender: 'ذكر', age: '6 شهور', weight: 180, pen: 'عنبر أ', status: 'نشط', health: 'جيدة', entryDate: '2024-06-10' },
  { id: 3, tagNo: 'CA-2024-003', type: 'عجل', breed: 'سيمينتال', gender: 'أنثى', age: '10 شهور', weight: 260, pen: 'عنبر ب', status: 'نشط', health: 'جيدة', entryDate: '2024-02-20' },
  { id: 4, tagNo: 'CA-2024-004', type: 'عجل', breed: 'بلدي مصري', gender: 'ذكر', age: '4 شهور', weight: 120, pen: 'عنبر أ', status: 'نشط', health: 'متوسطة', entryDate: '2024-08-05' },
  { id: 5, tagNo: 'CA-2024-005', type: 'عجل', breed: 'أنغس', gender: 'ذكر', age: '12 شهر', weight: 310, pen: 'عنبر ب', status: 'نشط', health: 'جيدة', entryDate: '2023-12-12' },
  { id: 6, tagNo: 'SH-2024-001', type: 'غنم', breed: 'عواسي', gender: 'ذكر', age: '5 شهور', weight: 45, pen: 'عنبر ج', status: 'نشط', health: 'جيدة', entryDate: '2024-07-18' },
  { id: 7, tagNo: 'SH-2024-002', type: 'غنم', breed: 'رحماني', gender: 'أنثى', age: '7 شهور', weight: 52, pen: 'عنبر ج', status: 'نشط', health: 'جيدة', entryDate: '2024-05-22' },
  { id: 8, tagNo: 'SH-2024-003', type: 'غنم', breed: 'عواسي', gender: 'ذكر', age: '3 شهور', weight: 28, pen: 'عنبر ج', status: 'نشط', health: 'جيدة', entryDate: '2024-09-10' },
  { id: 9, tagNo: 'SH-2024-004', type: 'غنم', breed: 'برقي', gender: 'أنثى', age: '9 شهور', weight: 58, pen: 'عنبر ج', status: 'نشط', health: 'متوسطة', entryDate: '2024-03-25' },
  { id: 10, tagNo: 'SH-2024-005', type: 'غنم', breed: 'عواسي', gender: 'ذكر', age: '11 شهر', weight: 65, pen: 'عنبر ج', status: 'نشط', health: 'جيدة', entryDate: '2024-01-14' },
  { id: 11, tagNo: 'BF-2024-001', type: 'جاموس', breed: 'مصري', gender: 'ذكر', age: '14 شهر', weight: 380, pen: 'عنبر د', status: 'نشط', health: 'جيدة', entryDate: '2023-10-20' },
  { id: 12, tagNo: 'BF-2024-002', type: 'جاموس', breed: 'مصري', gender: 'أنثى', age: '18 شهر', weight: 420, pen: 'عنبر د', status: 'نشط', health: 'جيدة', entryDate: '2023-06-15' },
  { id: 13, tagNo: 'BF-2024-003', type: 'جاموس', breed: 'متقاطع', gender: 'ذكر', age: '8 شهور', weight: 240, pen: 'عنبر د', status: 'نشط', health: 'جيدة', entryDate: '2024-04-08' },
  { id: 14, tagNo: 'CA-2024-006', type: 'عجل', breed: 'بلدي مصري', gender: 'أنثى', age: '2 شهر', weight: 75, pen: 'عنبر أ', status: 'جديد', health: 'جيدة', entryDate: '2024-10-20' },
  { id: 15, tagNo: 'SH-2024-006', type: 'غنم', breed: 'رحماني', gender: 'ذكر', age: '1 شهر', weight: 15, pen: 'عنبر ج', status: 'جديد', health: 'جيدة', entryDate: '2024-11-18' },
  { id: 16, tagNo: 'CA-2024-007', type: 'عجل', breed: 'هولشتاين', gender: 'ذكر', age: '7 شهور', weight: 195, pen: 'عنبر أ', status: 'نشط', health: 'جيدة', entryDate: '2024-05-10' },
  { id: 17, tagNo: 'BF-2024-004', type: 'جاموس', breed: 'مصري', gender: 'ذكر', age: '20 شهر', weight: 450, pen: 'عنبر د', status: 'نشط', health: 'جيدة', entryDate: '2023-04-22' },
  { id: 18, tagNo: 'SH-2024-007', type: 'غنم', breed: 'عواسي', gender: 'أنثى', age: '4 شهور', weight: 35, pen: 'عنبر ج', status: 'نشط', health: 'جيدة', entryDate: '2024-08-12' },
  { id: 19, tagNo: 'CA-2024-008', type: 'عجل', breed: 'سيمينتال', gender: 'أنثى', age: '9 شهور', weight: 250, pen: 'عنبر ب', status: 'نشط', health: 'جيدة', entryDate: '2024-03-15' },
  { id: 20, tagNo: 'BF-2024-005', type: 'جاموس', breed: 'متقاطع', gender: 'أنثى', age: '16 شهر', weight: 400, pen: 'عنبر د', status: 'نشط', health: 'متوسطة', entryDate: '2023-08-20' },
];

const vaccinations = [
  { id: 1, animalTag: 'CA-2024-001', vaccine: 'الحمة القلاعية', date: '2024-12-15', nextDate: '2025-01-15', status: 'منجزة', vet: 'د. أحمد سمير' },
  { id: 2, animalTag: 'SH-2024-001', vaccine: 'الجدري', date: '2024-12-18', nextDate: '2025-02-18', status: 'منجزة', vet: 'د. أحمد سمير' },
  { id: 3, animalTag: 'BF-2024-001', vaccine: 'الحمة القلاعية', date: '2024-12-10', nextDate: '2025-01-10', status: 'منجزة', vet: 'د. محمد كمال' },
  { id: 4, animalTag: 'CA-2024-002', vaccine: 'الحمة القلاعية', date: '2024-11-20', nextDate: '2024-12-20', status: 'متأخرة', vet: 'د. أحمد سمير' },
  { id: 5, animalTag: 'SH-2024-002', vaccine: 'التوكسويد', date: '2025-01-05', nextDate: '2025-04-05', status: 'مجدولة', vet: 'د. محمد كمال' },
  { id: 6, animalTag: 'CA-2024-003', vaccine: 'الحمة القلاعية', date: '2025-01-10', nextDate: '2025-02-10', status: 'مجدولة', vet: 'د. أحمد سمير' },
  { id: 7, animalTag: 'BF-2024-002', vaccine: 'الدرن', date: '2024-12-01', nextDate: '2025-12-01', status: 'منجزة', vet: 'د. محمد كمال' },
  { id: 8, animalTag: 'SH-2024-004', vaccine: 'التوكسويد', date: '2024-12-22', nextDate: '2025-03-22', status: 'منجزة', vet: 'د. أحمد سمير' },
];

const growthRecords = [
  { month: 'شهر 1', calves: 85, sheep: 18, buffalo: 140 },
  { month: 'شهر 2', calves: 120, sheep: 25, buffalo: 190 },
  { month: 'شهر 3', calves: 160, sheep: 32, buffalo: 230 },
  { month: 'شهر 4', calves: 195, sheep: 38, buffalo: 280 },
  { month: 'شهر 5', calves: 225, sheep: 45, buffalo: 320 },
  { month: 'شهر 6', calves: 260, sheep: 52, buffalo: 360 },
  { month: 'شهر 7', calves: 290, sheep: 58, buffalo: 400 },
  { month: 'شهر 8', calves: 320, sheep: 65, buffalo: 440 },
  { month: 'شهر 9', calves: 350, sheep: 72, buffalo: 470 },
  { month: 'شهر 10', calves: 380, sheep: 78, buffalo: 500 },
  { month: 'شهر 11', calves: 410, sheep: 85, buffalo: 530 },
  { month: 'شهر 12', calves: 440, sheep: 92, buffalo: 560 },
];

const feedRations = {
  'عجل': { dailyFeed: 0.025, protein: 16, roughage: 60 },
  'غنم': { dailyFeed: 0.03, protein: 14, roughage: 70 },
  'جاموس': { dailyFeed: 0.022, protein: 14, roughage: 65 },
};

const statusStyles: Record<string, string> = {
  'نشط': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'جديد': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'معالج': 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
  'مباع': 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
};

const healthStyles: Record<string, string> = {
  'جيدة': 'text-green-600',
  'متوسطة': 'text-amber-600',
  'ضعيفة': 'text-red-600',
};

const vacStatusStyles: Record<string, string> = {
  'منجزة': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'مجدولة': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'متأخرة': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

/* ─── helper components ─── */
function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${statusStyles[status] || 'bg-gray-100 text-gray-700'}`}>
      {status === 'نشط' && <CheckCircle2 size={12} />}
      {status === 'جديد' && <AlertCircle size={12} />}
      {status}
    </span>
  );
}

function RationCalculator() {
  const [animalType, setAnimalType] = useState('عجل');
  const [weight, setWeight] = useState('200');
  const ration = feedRations[animalType as keyof typeof feedRations];
  const daily = ration ? Math.round(Number(weight) * ration.dailyFeed * 100) / 100 : 0;
  const protein = ration ? ration.protein : 0;
  const roughage = ration ? Math.round(daily * (ration.roughage / 100)) : 0;
  const concentrate = ration ? Math.round(daily - roughage) : 0;

  return (
    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5">
      <h4 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
        <Wheat size={18} className="text-[#daa520]" /> حاسبة العليقة اليومية
      </h4>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <label className="block text-sm font-medium text-textSecondary mb-1.5">نوع الحيوان</label>
          <select
            value={animalType}
            onChange={(e) => setAnimalType(e.target.value)}
            className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
          >
            <option value="عجل">عجل</option>
            <option value="غنم">غنم</option>
            <option value="جاموس">جاموس</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-textSecondary mb-1.5">الوزن (كجم)</label>
          <input
            type="number"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-center">
          <p className="text-[11px] text-textSecondary">العليقة اليومية</p>
          <p className="text-lg font-bold text-[#0d6b43]">{daily} كجم</p>
        </div>
        <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 text-center">
          <p className="text-[11px] text-textSecondary">العلف المركز</p>
          <p className="text-lg font-bold text-blue-600">{concentrate} كجم</p>
        </div>
        <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 text-center">
          <p className="text-[11px] text-textSecondary">الأعلاف الخشنة</p>
          <p className="text-lg font-bold text-amber-600">{roughage} كجم</p>
        </div>
        <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 text-center">
          <p className="text-[11px] text-textSecondary">بروتين %</p>
          <p className="text-lg font-bold text-purple-600">{protein}%</p>
        </div>
      </div>
    </div>
  );
}

/* ─── main page ─── */
export default function LivestockPage() {
  const [animalList, setAnimalList] = useState(animals);
  const [vaccineList, setVaccineList] = useState(vaccinations);
  const [activeTab, setActiveTab] = useState('herd');
  const [showAnimalModal, setShowAnimalModal] = useState(false);
  const [showWeightModal, setShowWeightModal] = useState(false);
  const [showVaccineModal, setShowVaccineModal] = useState(false);
  const [showDetailAnimal, setShowDetailAnimal] = useState<any | null>(null);
  const [showEditAnimal, setShowEditAnimal] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [animalForm, setAnimalForm] = useState({
    tagNo: '', type: 'عجل', breed: '', gender: 'ذكر', age: '', weight: '', pen: '', health: 'جيدة',
  });

  const [weightForm, setWeightForm] = useState({ animalTag: '', weight: '', date: new Date().toISOString().split('T')[0] });

  const [vaccineForm, setVaccineForm] = useState({
    animalTag: '', vaccine: '', date: '', nextDate: '', vet: '',
  });

  const calfCount = animalList.filter(a => a.type === 'عجل').length;
  const sheepCount = animalList.filter(a => a.type === 'غنم').length;
  const buffaloCount = animalList.filter(a => a.type === 'جاموس').length;
  const growthRate = 12.5;

  const filteredAnimals = animalList.filter(a =>
    a.tagNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.breed.includes(searchQuery) ||
    a.pen.includes(searchQuery)
  );

  const filteredVaccines = vaccineList.filter(v =>
    v.animalTag.toLowerCase().includes(searchQuery.toLowerCase()) ||
    v.vaccine.includes(searchQuery)
  );

  const handleAddAnimal = () => {
    if (!animalForm.tagNo || !animalForm.weight) return;
    const newAnimal = {
      id: animalList.length + 1,
      tagNo: animalForm.tagNo,
      type: animalForm.type,
      breed: animalForm.breed || 'غير محدد',
      gender: animalForm.gender,
      age: animalForm.age || 'غير محدد',
      weight: Number(animalForm.weight),
      pen: animalForm.pen || 'غير محدد',
      status: 'جديد',
      health: animalForm.health,
      entryDate: new Date().toISOString().split('T')[0],
    };
    setAnimalList([newAnimal, ...animalList]);
    setAnimalForm({ tagNo: '', type: 'عجل', breed: '', gender: 'ذكر', age: '', weight: '', pen: '', health: 'جيدة' });
    setShowAnimalModal(false);
  };

  const handleAddWeight = () => {
    if (!weightForm.animalTag || !weightForm.weight) return;
    setAnimalList(animalList.map(a =>
      a.tagNo === weightForm.animalTag ? { ...a, weight: Number(weightForm.weight) } : a
    ));
    setWeightForm({ animalTag: '', weight: '', date: new Date().toISOString().split('T')[0] });
    setShowWeightModal(false);
  };

  const handleAddVaccine = () => {
    if (!vaccineForm.animalTag || !vaccineForm.vaccine || !vaccineForm.date) return;
    const newVaccine = {
      id: vaccineList.length + 1,
      animalTag: vaccineForm.animalTag,
      vaccine: vaccineForm.vaccine,
      date: vaccineForm.date,
      nextDate: vaccineForm.nextDate || '-',
      status: 'منجزة',
      vet: vaccineForm.vet || '-',
    };
    setVaccineList([newVaccine, ...vaccineList]);
    setVaccineForm({ animalTag: '', vaccine: '', date: '', nextDate: '', vet: '' });
    setShowVaccineModal(false);
  };

  const handleDeleteAnimal = (id: number) => {
    if (confirm('هل أنت متأكد من حذف الحيوان؟')) {
      setAnimalList(animalList.filter(a => a.id !== id));
    }
  };

  const animalColumns = [
    { key: 'tagNo', header: 'رقم التعريف', sortable: true },
    { key: 'type', header: 'النوع', sortable: true },
    { key: 'breed', header: 'السلالة', sortable: true },
    { key: 'gender', header: 'الجنس', sortable: true },
    { key: 'age', header: 'العمر', sortable: true },
    { key: 'weight', header: 'الوزن (كجم)', sortable: true, render: (row: any) => <span className="font-semibold text-[#0d6b43]">{row.weight}</span> },
    { key: 'pen', header: 'العنبر', sortable: true },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <StatusBadge status={row.status} /> },
    { key: 'health', header: 'الصحة', sortable: true, render: (row: any) => <span className={healthStyles[row.health] || ''}>{row.health}</span> },
  ];

  const vaccineColumns = [
    { key: 'animalTag', header: 'رقم الحيوان', sortable: true },
    { key: 'vaccine', header: 'التطعيم', sortable: true },
    { key: 'date', header: 'التاريخ', sortable: true },
    { key: 'nextDate', header: 'التالي', sortable: true, render: (row: any) => (
      <span className={row.status === 'متأخرة' ? 'text-red-600 font-semibold' : ''}>{row.nextDate}</span>
    )},
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => (
      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${vacStatusStyles[row.status] || ''}`}>{row.status}</span>
    )},
    { key: 'vet', header: 'البيطري', sortable: true },
  ];

  const tabs = [
    { key: 'herd', label: 'سجل القطيع', icon: Beef },
    { key: 'feed', label: 'التغذية', icon: Wheat },
    { key: 'vaccines', label: 'التحصينات', icon: Syringe },
    { key: 'growth', label: 'النمو', icon: TrendingUp },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="المواشي"
        subtitle="إدارة القطيع والتغذية والتحصينات"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'المواشي' }]}
      >
        {activeTab === 'herd' && (
          <button onClick={() => setShowAnimalModal(true)} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all">
            <Plus size={18} /> إضافة حيوان
          </button>
        )}
        {activeTab === 'growth' && (
          <button onClick={() => setShowWeightModal(true)} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all">
            <Weight size={18} /> تسجيل وزن
          </button>
        )}
        {activeTab === 'vaccines' && (
          <button onClick={() => setShowVaccineModal(true)} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all">
            <Syringe size={18} /> تسجيل تطعيم
          </button>
        )}
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="إجمالي القطيع" value={String(animalList.length)} icon={Beef} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-600" change={3} delay={0} />
        <KPICard title="عجول" value={String(calfCount)} icon={Beef} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-600" change={2} delay={0.05} />
        <KPICard title="أغنام" value={String(sheepCount)} icon={Beef} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-600" change={1} delay={0.1} />
        <KPICard title="جاموس" value={String(buffaloCount)} icon={Beef} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-600" change={0} delay={0.15} />
        <KPICard title="نسبة النمو" value={`${growthRate}%`} icon={TrendingUp} iconBg="bg-teal-100 dark:bg-teal-900/30" iconColor="text-teal-600" change={4.2} delay={0.2} />
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-3 border-b border-uiBorder dark:border-darkBorder flex items-center gap-1 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab.key
                    ? 'bg-[#0a4a30] text-white'
                    : 'text-textSecondary hover:bg-surface dark:hover:bg-darkCard'
                }`}
              >
                <Icon size={16} /> {tab.label}
              </button>
            );
          })}
        </div>

        {/* Herd Tab */}
        {activeTab === 'herd' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Beef size={18} className="text-[#0d6b43]" /> سجل القطيع
              </h3>
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                <input
                  type="text" placeholder="بحث في القطيع..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-56 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                />
              </div>
            </div>
            <DataTable
              columns={animalColumns}
              data={filteredAnimals}
              pageSize={10}
              searchable={false}
              rowActions={{
                onView: (row) => setShowDetailAnimal(row),
                onEdit: (row) => { setShowEditAnimal({ ...row }); },
                onDelete: (row) => handleDeleteAnimal(row.id),
              }}
              emptyMessage="لا يوجد حيوانات"
            />
          </div>
        )}

        {/* Feed Tab */}
        {activeTab === 'feed' && (
          <div className="p-5">
            <RationCalculator />
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
              className="mt-6"
            >
              <h4 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
                <Wheat size={18} className="text-[#daa520]" /> جدول العلائق المقترحة
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-sm border border-uiBorder dark:border-darkBorder rounded-xl">
                  <thead>
                    <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                      <th className="px-4 py-3 text-right font-semibold text-textSecondary">الحيوان</th>
                      <th className="px-4 py-3 text-right font-semibold text-textSecondary">وزن كجم</th>
                      <th className="px-4 py-3 text-right font-semibold text-textSecondary">عليقة يومية كجم</th>
                      <th className="px-4 py-3 text-right font-semibold text-textSecondary">مركز كجم</th>
                      <th className="px-4 py-3 text-right font-semibold text-textSecondary">خشن كجم</th>
                      <th className="px-4 py-3 text-right font-semibold text-textSecondary">بروتين %</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { animal: 'عجل 100-200 كجم', feed: 3.5, concentrate: 1.4, roughage: 2.1, protein: 16 },
                      { animal: 'عجل 200-350 كجم', feed: 6.5, concentrate: 2.6, roughage: 3.9, protein: 15 },
                      { animal: 'عجل {'>'}350 كجم', feed: 8.5, concentrate: 3.4, roughage: 5.1, protein: 14 },
                      { animal: 'غنم 20-40 كجم', feed: 1.0, concentrate: 0.3, roughage: 0.7, protein: 14 },
                      { animal: 'غنم 40-60 كجم', feed: 1.5, concentrate: 0.45, roughage: 1.05, protein: 13 },
                      { animal: 'جاموس 300-450 كجم', feed: 8.0, concentrate: 2.8, roughage: 5.2, protein: 14 },
                    ].map((row, i) => (
                      <tr key={i} className="border-b border-uiBorder/30 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors">
                        <td className="px-4 py-3 font-medium text-textPrimary">{row.animal}</td>
                        <td className="px-4 py-3 text-textPrimary">{row.feed} كجم</td>
                        <td className="px-4 py-3 font-semibold text-[#0d6b43]">{row.feed} كجم</td>
                        <td className="px-4 py-3 text-blue-600">{row.concentrate} كجم</td>
                        <td className="px-4 py-3 text-amber-600">{row.roughage} كجم</td>
                        <td className="px-4 py-3 text-purple-600">{row.protein}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </div>
        )}

        {/* Vaccines Tab */}
        {activeTab === 'vaccines' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Syringe size={18} className="text-[#0d6b43]" /> سجل التحصينات
              </h3>
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                <input
                  type="text" placeholder="بحث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-48 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                />
              </div>
            </div>
            {/* Upcoming Vaccines Alert */}
            <div className="px-5 py-3 bg-amber-50 dark:bg-amber-900/20 border-b border-amber-200 dark:border-amber-800">
              <div className="flex items-center gap-2">
                <AlertCircle size={16} className="text-amber-600" />
                <span className="text-sm font-medium text-amber-800 dark:text-amber-300">
                  تحذير: {vaccineList.filter(v => v.status === 'متأخرة').length} تطعيم متأخر، {vaccineList.filter(v => v.status === 'مجدولة').length} مجدول
                </span>
              </div>
            </div>
            <DataTable
              columns={vaccineColumns}
              data={filteredVaccines}
              pageSize={8}
              searchable={false}
              rowActions={{
                onDelete: (row) => { if (confirm('حذف التسجيل؟')) setVaccineList(vaccineList.filter(v => v.id !== row.id)); },
              }}
              emptyMessage="لا توجد تسجيلات تحصين"
            />
          </div>
        )}

        {/* Growth Tab */}
        {activeTab === 'growth' && (
          <div className="p-5 space-y-6">
            {/* Growth Chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <h4 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
                <Activity size={18} className="text-[#0d6b43]" /> منحنى النمو المتوقع
              </h4>
              <div className="bg-surface dark:bg-darkCard rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                <ResponsiveContainer width="100%" height={320}>
                  <LineChart data={growthRecords}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="calves" name="العجول" stroke="#0d6b43" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="sheep" name="الأغنام" stroke="#daa520" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="buffalo" name="الجاموس" stroke="#2563eb" strokeWidth={2} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Weight Entry Form Inline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
            >
              <h4 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
                <Weight size={18} className="text-[#daa520]" /> تسجيل وزن جديد
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">رقم الحيوان</label>
                  <select
                    value={weightForm.animalTag}
                    onChange={(e) => setWeightForm({ ...weightForm, animalTag: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  >
                    <option value="">اختر حيوان</option>
                    {animalList.map(a => (
                      <option key={a.id} value={a.tagNo}>{a.tagNo} - {a.type} ({a.weight} كجم)</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الوزن الجديد (كجم)</label>
                  <input
                    type="number" placeholder="0"
                    value={weightForm.weight}
                    onChange={(e) => setWeightForm({ ...weightForm, weight: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">التاريخ</label>
                  <input
                    type="date"
                    value={weightForm.date}
                    onChange={(e) => setWeightForm({ ...weightForm, date: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
              </div>
              <button
                onClick={handleAddWeight}
                className="mt-3 px-6 h-10 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all"
              >
                حفظ الوزن
              </button>
            </motion.div>
          </div>
        )}
      </div>

      {/* Add Animal Modal */}
      <AnimatePresence>
        {showAnimalModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowAnimalModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إضافة حيوان جديد</h3>
                <button onClick={() => setShowAnimalModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">رقم التعريف</label>
                    <input
                      type="text" placeholder="XX-2024-XXX"
                      value={animalForm.tagNo}
                      onChange={(e) => setAnimalForm({ ...animalForm, tagNo: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">النوع</label>
                    <select
                      value={animalForm.type}
                      onChange={(e) => setAnimalForm({ ...animalForm, type: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="عجل">عجل</option>
                      <option value="غنم">غنم</option>
                      <option value="جاموس">جاموس</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">السلالة</label>
                    <input
                      type="text" placeholder="اسم السلالة"
                      value={animalForm.breed}
                      onChange={(e) => setAnimalForm({ ...animalForm, breed: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الجنس</label>
                    <select
                      value={animalForm.gender}
                      onChange={(e) => setAnimalForm({ ...animalForm, gender: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="ذكر">ذكر</option>
                      <option value="أنثى">أنثى</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">العمر</label>
                    <input
                      type="text" placeholder="مثال: 6 شهور"
                      value={animalForm.age}
                      onChange={(e) => setAnimalForm({ ...animalForm, age: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الوزن (كجم)</label>
                    <input
                      type="number" placeholder="0"
                      value={animalForm.weight}
                      onChange={(e) => setAnimalForm({ ...animalForm, weight: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">العنبر</label>
                    <input
                      type="text" placeholder="عنبر X"
                      value={animalForm.pen}
                      onChange={(e) => setAnimalForm({ ...animalForm, pen: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الحالة الصحية</label>
                  <select
                    value={animalForm.health}
                    onChange={(e) => setAnimalForm({ ...animalForm, health: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  >
                    <option value="جيدة">جيدة</option>
                    <option value="متوسطة">متوسطة</option>
                    <option value="ضعيفة">ضعيفة</option>
                  </select>
                </div>
                <button
                  onClick={handleAddAnimal}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ الحيوان
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Vaccine Modal */}
      <AnimatePresence>
        {showVaccineModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowVaccineModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تسجيل تطعيم</h3>
                <button onClick={() => setShowVaccineModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">رقم الحيوان</label>
                  <select
                    value={vaccineForm.animalTag}
                    onChange={(e) => setVaccineForm({ ...vaccineForm, animalTag: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  >
                    <option value="">اختر حيوان</option>
                    {animalList.map(a => (
                      <option key={a.id} value={a.tagNo}>{a.tagNo} - {a.type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">نوع التطعيم</label>
                  <select
                    value={vaccineForm.vaccine}
                    onChange={(e) => setVaccineForm({ ...vaccineForm, vaccine: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  >
                    <option value="">اختر تطعيم</option>
                    <option value="الحمة القلاعية">الحمة القلاعية</option>
                    <option value="الجدري">الجدري</option>
                    <option value="التوكسويد">التوكسويد</option>
                    <option value="الدرن">الدرن</option>
                    <option value="الحمة الواديية">الحمة الواديية</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">تاريخ التطعيم</label>
                    <input
                      type="date"
                      value={vaccineForm.date}
                      onChange={(e) => setVaccineForm({ ...vaccineForm, date: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">تاريخ التالي</label>
                    <input
                      type="date"
                      value={vaccineForm.nextDate}
                      onChange={(e) => setVaccineForm({ ...vaccineForm, nextDate: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">البيطري</label>
                  <input
                    type="text" placeholder="اسم الطبيب البيطري"
                    value={vaccineForm.vet}
                    onChange={(e) => setVaccineForm({ ...vaccineForm, vet: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <button
                  onClick={handleAddVaccine}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التطعيم
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Animal Detail Modal */}
      <AnimatePresence>
        {showDetailAnimal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailAnimal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-md"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تفاصيل الحيوان</h3>
                <button onClick={() => setShowDetailAnimal(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-3">
                {[
                  { label: 'رقم التعريف', value: showDetailAnimal.tagNo },
                  { label: 'النوع', value: showDetailAnimal.type },
                  { label: 'السلالة', value: showDetailAnimal.breed },
                  { label: 'الجنس', value: showDetailAnimal.gender },
                  { label: 'العمر', value: showDetailAnimal.age },
                  { label: 'الوزن', value: `${showDetailAnimal.weight} كجم` },
                  { label: 'العنبر', value: showDetailAnimal.pen },
                  { label: 'تاريخ الدخول', value: showDetailAnimal.entryDate },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-textSecondary text-sm">{item.label}</span>
                    <span className="font-semibold text-textPrimary">{item.value}</span>
                  </div>
                ))}
                <div className="flex items-center gap-4 pt-2">
                  <div className="flex-1"><StatusBadge status={showDetailAnimal.status} /></div>
                  <div className="flex-1 text-center"><span className={healthStyles[showDetailAnimal.health]}>{showDetailAnimal.health}</span></div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Animal Modal */}
      <AnimatePresence>
        {showEditAnimal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEditAnimal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تعديل بيانات الحيوان</h3>
                <button onClick={() => setShowEditAnimal(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الوزن (كجم)</label>
                    <input
                      type="number"
                      value={showEditAnimal.weight}
                      onChange={(e) => setShowEditAnimal({ ...showEditAnimal, weight: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الحالة الصحية</label>
                    <select
                      value={showEditAnimal.health}
                      onChange={(e) => setShowEditAnimal({ ...showEditAnimal, health: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    >
                      <option value="جيدة">جيدة</option>
                      <option value="متوسطة">متوسطة</option>
                      <option value="ضعيفة">ضعيفة</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">العنبر</label>
                  <input
                    type="text"
                    value={showEditAnimal.pen}
                    onChange={(e) => setShowEditAnimal({ ...showEditAnimal, pen: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الحالة</label>
                  <select
                    value={showEditAnimal.status}
                    onChange={(e) => setShowEditAnimal({ ...showEditAnimal, status: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  >
                    <option value="نشط">نشط</option>
                    <option value="جديد">جديد</option>
                    <option value="معالج">معالج</option>
                    <option value="مباع">مباع</option>
                  </select>
                </div>
                <button
                  onClick={() => { setAnimalList(animalList.map(a => a.id === showEditAnimal.id ? showEditAnimal : a)); setShowEditAnimal(null); }}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التعديلات
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
