import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, Plus, Search, X, Eye, Download, Filter, UserCircle, Building2, Phone, CalendarDays, Banknote, TrendingUp,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

// ─── Types ──────────────────────────────────────────────
interface Employee {
  id: string;
  name: string;
  department: string;
  position: string;
  branch: string;
  joinDate: string;
  phone: string;
  status: string;
  nationalId: string;
  address: string;
  salary: number;
  salaryHistory: { date: string; amount: number }[];
  attendance: { month: string; present: number; absent: number; late: number }[];
}

// ─── Mock Data ──────────────────────────────────────────
const employeesData: Employee[] = [
  { id: 'E-001', name: 'أحمد محمود', department: 'المبيعات', position: 'مندوب مبيعات', branch: 'القاهرة', joinDate: '2023-03-01', phone: '٠١٠٠١٢٣٤٥٦٧', status: 'نشط', nationalId: '٢٩٨٠٦٥٤٣٢١٠١٤٥', address: '١٥ شارع النصر، القاهرة', salary: 8500, salaryHistory: [{ date: '2023-03', amount: 7000 }, { date: '2024-01', amount: 8500 }], attendance: [{ month: 'ديسمبر', present: 22, absent: 1, late: 2 }] },
  { id: 'E-002', name: 'محمد علي', department: 'المخازن', position: 'مشرف مخازن', branch: 'الإسكندرية', joinDate: '2023-06-15', phone: '٠١١١٢٢٣٣٤٤٥', status: 'نشط', nationalId: '٣٠١٠٧٦٥٤٣٢١٥٦', address: '٨ شارع الجيش، الإسكندرية', salary: 7200, salaryHistory: [{ date: '2023-06', amount: 6000 }, { date: '2024-01', amount: 7200 }], attendance: [{ month: 'ديسمبر', present: 23, absent: 0, late: 1 }] },
  { id: 'E-003', name: 'فاطمة أحمد', department: 'الإنتاج', position: 'فني إنتاج', branch: 'طنطا', joinDate: '2023-09-01', phone: '٠١٢٢٣٣٤٤٥٥٦', status: 'في إجازة', nationalId: '٣١٢٠٨٧٦٥٤٣٢٦٧', address: '٢٠ شارع الجلاء، طنطا', salary: 6800, salaryHistory: [{ date: '2023-09', amount: 5500 }, { date: '2024-01', amount: 6800 }], attendance: [{ month: 'ديسمبر', present: 18, absent: 5, late: 0 }] },
  { id: 'E-004', name: 'خالد عمر', department: 'الحسابات', position: 'محاسب', branch: 'المنصورة', joinDate: '2024-01-10', phone: '٠١٥٥٤٣٣٢٢١', status: 'نشط', nationalId: '٢٨٥٠٥٤٣٢١٠٩٨٣', address: '٥ شارع الجمهورية، المنصورة', salary: 9000, salaryHistory: [{ date: '2024-01', amount: 9000 }], attendance: [{ month: 'ديسمبر', present: 23, absent: 0, late: 0 }] },
  { id: 'E-005', name: 'سارة محمود', department: 'المبيعات', position: 'مندوبة مبيعات', branch: 'القاهرة', joinDate: '2024-11-01', phone: '٠١٠٩٩٨٨٧٧٦', status: 'جديد', nationalId: '٣٠٥٠٩٨٧٦٥٤٣٧٨', address: '١٠ شارع الهرم، القاهرة', salary: 8000, salaryHistory: [{ date: '2024-11', amount: 8000 }], attendance: [{ month: 'ديسمبر', present: 20, absent: 1, late: 3 }] },
  { id: 'E-006', name: 'محمود سالم', department: 'الإنتاج', position: 'مشرف إنتاج', branch: 'القاهرة', joinDate: '2023-01-20', phone: '٠١١٥٥٦٦٧٧٨', status: 'نشط', nationalId: '٢٩٩٠٧٦٥٤٣٢١٠٩', address: '٣ شارع الأهرام، القاهرة', salary: 12000, salaryHistory: [{ date: '2023-01', amount: 10000 }, { date: '2024-01', amount: 12000 }], attendance: [{ month: 'ديسمبر', present: 23, absent: 0, late: 0 }] },
  { id: 'E-007', name: 'نورا إبراهيم', department: 'الحسابات', position: 'مراجع حسابات', branch: 'الإسكندرية', joinDate: '2024-05-01', phone: '٠١٢٣٤٥٦٧٨٩٠', status: 'نشط', nationalId: '٣١٤٠٩٨٧٦٥٤٣٩٠', address: '١٢ شارع سعد زغلول، الإسكندرية', salary: 10000, salaryHistory: [{ date: '2024-05', amount: 10000 }], attendance: [{ month: 'ديسمبر', present: 22, absent: 1, late: 1 }] },
  { id: 'E-008', name: 'عبدالله حسن', department: 'المخازن', position: 'أمين مخزن', branch: 'طنطا', joinDate: '2024-02-15', phone: '٠١٥٥٤٤٣٣٢٢', status: 'في إجازة', nationalId: '٣٠٠٠٨٧٦٥٤٣٢١٨', address: '٧ شارع النيل، طنطا', salary: 6500, salaryHistory: [{ date: '2024-02', amount: 6500 }], attendance: [{ month: 'ديسمبر', present: 15, absent: 8, late: 0 }] },
];

const deptOptions = ['الكل', 'المبيعات', 'المخازن', 'الإنتاج', 'الحسابات'];
const branchOptions = ['الكل', 'القاهرة', 'الإسكندرية', 'طنطا', 'المنصورة'];
const statusOptions = ['الكل', 'نشط', 'في إجازة', 'جديد'];
const statusColors: Record<string, string> = {
  'نشط': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'في إجازة': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'جديد': 'bg-gold-100 text-gold-700 dark:bg-gold-900/40 dark:text-gold-400',
};

export default function HREmployeesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDept, setFilterDept] = useState('الكل');
  const [filterBranch, setFilterBranch] = useState('الكل');
  const [filterStatus, setFilterStatus] = useState('الكل');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [addTab, setAddTab] = useState<'personal' | 'job' | 'docs'>('personal');

  const totalEmployees = employeesData.length;
  const activeCount = employeesData.filter(e => e.status === 'نشط').length;
  const onLeaveCount = employeesData.filter(e => e.status === 'في إجازة').length;
  const newThisMonth = employeesData.filter(e => e.status === 'جديد').length;

  const filteredData = useMemo(() => {
    let result = [...employeesData];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(e => e.name.includes(q) || e.id.toLowerCase().includes(q) || e.phone.includes(q) || e.position.includes(q));
    }
    if (filterDept !== 'الكل') result = result.filter(e => e.department === filterDept);
    if (filterBranch !== 'الكل') result = result.filter(e => e.branch === filterBranch);
    if (filterStatus !== 'الكل') result = result.filter(e => e.status === filterStatus);
    return result;
  }, [searchQuery, filterDept, filterBranch, filterStatus]);

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="دليل الموظفين"
        subtitle="إدارة بيانات الموظفين والسجلات الوظيفية"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الموارد البشرية', path: '/hr' },
          { label: 'الموظفين' },
        ]}
      >
        <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">
          <Download size={16} /> تصدير
        </button>
        <button onClick={() => setShowAddForm(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Plus size={16} /> إضافة موظف
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي الموظفين" value={String(totalEmployees)} icon={Users} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="نشطين" value={String(activeCount)} icon={UserCircle} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.1} />
        <KPICard title="في إجازة" value={String(onLeaveCount)} icon={CalendarDays} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.2} />
        <KPICard title="جدد هذا الشهر" value={String(newThisMonth)} icon={TrendingUp} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-700 dark:text-purple-400" delay={0.3} />
      </div>

      {/* Filters */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 text-textSecondary text-sm"><Filter size={14} /> تصفية:</div>
          <select value={filterDept} onChange={e => setFilterDept(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
            {deptOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'القسم' : o}</option>)}
          </select>
          <select value={filterBranch} onChange={e => setFilterBranch(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
            {branchOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'الفرع' : o}</option>)}
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
            {statusOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'الحالة' : o}</option>)}
          </select>
          <div className="relative flex-1 min-w-[200px] max-w-xs mr-auto">
            <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
            <input type="text" placeholder="بحث..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full h-9 pr-9 pl-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm text-textPrimary dark:text-darkText placeholder:text-textMuted focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
          </div>
        </div>
      </motion.div>

      {/* Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['الرقم', 'الاسم', 'القسم', 'المنصب', 'الفرع', 'تاريخ الانضمام', 'الهاتف', 'الحالة'].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
                <th className="px-4 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.id}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText font-medium">{row.name}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.department}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.position}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.branch}</td>
                  <td className="px-4 py-3 text-sm text-textMuted">{row.joinDate}</td>
                  <td className="px-4 py-3 text-sm text-textMuted">{row.phone}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[row.status]}`}>{row.status}</span></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setSelectedEmployee(row)} className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors" title="عرض التفاصيل"><Eye size={16} /></button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Add Employee Modal */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowAddForm(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">إضافة موظف جديد</h3>
                <button onClick={() => setShowAddForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              {/* Tabs */}
              <div className="flex border-b border-uiBorder dark:border-darkBorder">
                {[
                  { key: 'personal' as const, label: 'البيانات الشخصية' },
                  { key: 'job' as const, label: 'البيانات الوظيفية' },
                  { key: 'docs' as const, label: 'المستندات' },
                ].map(tab => (
                  <button key={tab.key} onClick={() => setAddTab(tab.key)} className={`flex-1 py-3 text-xs font-medium transition-colors ${addTab === tab.key ? 'text-green-700 border-b-2 border-green-700' : 'text-textMuted hover:text-textSecondary'}`}>{tab.label}</button>
                ))}
              </div>
              <div className="p-5 space-y-4">
                {addTab === 'personal' && (
                  <>
                    <div><label className="block text-xs font-medium text-textSecondary mb-1">الاسم الكامل</label><input type="text" placeholder="الاسم رباعي" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-medium text-textSecondary mb-1">رقم الهاتف</label><input type="text" placeholder="٠١٠٠٠٠٠٠٠٠٠" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                      <div><label className="block text-xs font-medium text-textSecondary mb-1">الرقم القومي</label><input type="text" placeholder="١٤ رقم" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                    </div>
                    <div><label className="block text-xs font-medium text-textSecondary mb-1">العنوان</label><textarea placeholder="العنوان بالتفصيل" className="w-full h-20 px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm resize-none" /></div>
                  </>
                )}
                {addTab === 'job' && (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-medium text-textSecondary mb-1">القسم</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>المبيعات</option><option>المخازن</option><option>الإنتاج</option><option>الحسابات</option></select></div>
                      <div><label className="block text-xs font-medium text-textSecondary mb-1">المنصب</label><input type="text" placeholder="المسمى الوظيفي" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs font-medium text-textSecondary mb-1">الفرع</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>القاهرة</option><option>الإسكندرية</option><option>طنطا</option><option>المنصورة</option></select></div>
                      <div><label className="block text-xs font-medium text-textSecondary mb-1">الراتب الأساسي</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                    </div>
                    <div><label className="block text-xs font-medium text-textSecondary mb-1">تاريخ الانضمام</label><input type="date" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  </>
                )}
                {addTab === 'docs' && (
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-uiBorder dark:border-darkBorder rounded-lg p-8 text-center">
                      <UserCircle size={32} className="mx-auto text-textMuted mb-2" />
                      <p className="text-sm text-textSecondary">صورة شخصية</p>
                      <p className="text-xs text-textMuted">اسحب الملف هنا أو اضغط لاختيار ملف</p>
                    </div>
                    <div className="border-2 border-dashed border-uiBorder dark:border-darkBorder rounded-lg p-8 text-center">
                      <Banknote size={32} className="mx-auto text-textMuted mb-2" />
                      <p className="text-sm text-textSecondary">صورة البطاقة الشخصية</p>
                      <p className="text-xs text-textMuted">الوجه الأمامي والخلفي</p>
                    </div>
                    <div className="border-2 border-dashed border-uiBorder dark:border-darkBorder rounded-lg p-8 text-center">
                      <Building2 size={32} className="mx-auto text-textMuted mb-2" />
                      <p className="text-sm text-textSecondary">عقد العمل</p>
                      <p className="text-xs text-textMuted">PDF أو صورة</p>
                    </div>
                  </div>
                )}
                <div className="flex justify-end gap-2 pt-2">
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">إلغاء</button>
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors">حفظ</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Employee Detail Modal */}
      <AnimatePresence>
        {selectedEmployee && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setSelectedEmployee(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center"><UserCircle size={24} className="text-green-700" /></div>
                  <div>
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">{selectedEmployee.name}</h3>
                    <p className="text-xs text-textMuted">{selectedEmployee.id} · {selectedEmployee.position}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[selectedEmployee.status]}`}>{selectedEmployee.status}</span>
                  <button onClick={() => setSelectedEmployee(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
                </div>
              </div>
              <div className="p-5 space-y-6">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><p className="text-xs text-textMuted">القسم</p><p className="text-sm font-bold text-textPrimary dark:text-darkText">{selectedEmployee.department}</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><p className="text-xs text-textMuted">الفرع</p><p className="text-sm font-bold text-textPrimary dark:text-darkText">{selectedEmployee.branch}</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><p className="text-xs text-textMuted">الراتب</p><p className="text-sm font-bold text-green-700">{selectedEmployee.salary.toLocaleString()} ج.م</p></div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-textMuted">الهاتف:</span> <span className="text-textPrimary dark:text-darkText">{selectedEmployee.phone}</span></div>
                  <div><span className="text-textMuted">تاريخ الانضمام:</span> <span className="text-textPrimary dark:text-darkText">{selectedEmployee.joinDate}</span></div>
                  <div><span className="text-textMuted">الرقم القومي:</span> <span className="text-textPrimary dark:text-darkText">{selectedEmployee.nationalId}</span></div>
                  <div><span className="text-textMuted">العنوان:</span> <span className="text-textPrimary dark:text-darkText">{selectedEmployee.address}</span></div>
                </div>
                {/* Salary History */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2"><Banknote size={16} className="text-gold-500" /> تاريخ الرواتب</h4>
                  <div className="bg-surface dark:bg-darkCard rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-uiBorder/30"><tr><th className="px-3 py-2 text-right text-xs">التاريخ</th><th className="px-3 py-2 text-right text-xs">المبلغ</th></tr></thead>
                      <tbody>
                        {selectedEmployee.salaryHistory.map((s, i) => (
                          <tr key={i} className="border-b border-uiBorder/30"><td className="px-3 py-2">{s.date}</td><td className="px-3 py-2 font-semibold text-green-700">{s.amount.toLocaleString()} ج.م</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                {/* Attendance Summary */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2"><CalendarDays size={16} className="text-blue-500" /> ملخص الحضور (ديسمبر)</h4>
                  <div className="bg-surface dark:bg-darkCard rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-uiBorder/30"><tr><th className="px-3 py-2 text-right text-xs">الشهر</th><th className="px-3 py-2 text-right text-xs">حضور</th><th className="px-3 py-2 text-right text-xs">غياب</th><th className="px-3 py-2 text-right text-xs">تأخير</th></tr></thead>
                      <tbody>
                        {selectedEmployee.attendance.map((a, i) => (
                          <tr key={i} className="border-b border-uiBorder/30">
                            <td className="px-3 py-2">{a.month}</td><td className="px-3 py-2 text-green-700 font-semibold">{a.present}</td>
                            <td className="px-3 py-2 text-red-600 font-semibold">{a.absent}</td><td className="px-3 py-2 text-gold-600 font-semibold">{a.late}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
