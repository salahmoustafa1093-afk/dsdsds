// @ts-nocheck
import { useState, useMemo } from 'react';
import {
  ClipboardList, Clock, CheckCircle2, AlertTriangle, Plus, Filter, Eye,
  Play, Pause, RotateCcw, X
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

/* ─── Types ─────────────────────────────────────────── */
interface ProductionOrder {
  id: number;
  orderNumber: string;
  product: string;
  quantity: string;
  line: string;
  priority: 'urgent' | 'normal' | 'low';
  status: 'scheduled' | 'preparing' | 'running' | 'completed' | 'cancelled';
  plannedDate: string;
  actualDate: string;
  yieldPercent: number;
  notes: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const ordersData: ProductionOrder[] = [
  { id: 1, orderNumber: 'PO-2025-001', product: 'علف دواجن بادئ ٥٠ كجم', quantity: '٥٠٠ طن', line: 'خط إنتاج علف دواجن ١', priority: 'urgent', status: 'running', plannedDate: '١٥/٠١/٢٠٢٥', actualDate: '١٥/٠١/٢٠٢٥', yieldPercent: 96.5, notes: '' },
  { id: 2, orderNumber: 'PO-2025-002', product: 'علف أبقار جاف ٢٥ كجم', quantity: '٣٠٠ طن', line: 'خط إنتاج علف أبقار ١', priority: 'normal', status: 'preparing', plannedDate: '١٥/٠١/٢٠٢٥', actualDate: '—', yieldPercent: 0, notes: '' },
  { id: 3, orderNumber: 'PO-2025-003', product: 'ردة ناعمة مجروشة', quantity: '٤٠٠ طن', line: 'خط إنتاج ردة ١', priority: 'normal', status: 'completed', plannedDate: '١٤/٠١/٢٠٢٥', actualDate: '١٤/٠١/٢٠٢٥', yieldPercent: 98.2, notes: '' },
  { id: 4, orderNumber: 'PO-2025-004', product: 'علف دواجن نامي ٥٠ كجم', quantity: '٦٠٠ طن', line: 'خط إنتاج علف دواجن ٢', priority: 'urgent', status: 'scheduled', plannedDate: '١٦/٠١/٢٠٢٥', actualDate: '—', yieldPercent: 0, notes: 'انتظار وصول صويا' },
  { id: 5, orderNumber: 'PO-2025-005', product: 'بريمكس دواجن ١٪', quantity: '٥٠ طن', line: 'خط خلط مركز ١', priority: 'low', status: 'running', plannedDate: '١٥/٠١/٢٠٢٥', actualDate: '١٥/٠١/٢٠٢٥', yieldPercent: 94.0, notes: '' },
  { id: 6, orderNumber: 'PO-2025-006', product: 'علف أغنام ٤٠ كجم', quantity: '١٥٠ طن', line: 'خط إنتاج علف أغنام ١', priority: 'normal', status: 'cancelled', plannedDate: '١٣/٠١/٢٠٢٥', actualDate: '—', yieldPercent: 0, notes: 'إلغاء لنقص خامات' },
  { id: 7, orderNumber: 'PO-2025-007', product: 'Pellets دواجن ٥٠ كجم', quantity: '٣٥٠ طن', line: 'خط ت pelletizing ١', priority: 'urgent', status: 'running', plannedDate: '١٥/٠١/٢٠٢٥', actualDate: '١٥/٠١/٢٠٢٥', yieldPercent: 97.1, notes: '' },
  { id: 8, orderNumber: 'PO-2025-008', product: 'كسب صويا مجروش', quantity: '٢٠٠ طن', line: 'خط طحن صويا ١', priority: 'normal', status: 'completed', plannedDate: '١٤/٠١/٢٠٢٥', actualDate: '١٤/٠١/٢٠٢٥', yieldPercent: 99.0, notes: '' },
  { id: 9, orderNumber: 'PO-2025-009', product: 'علف تسمين عجول ٥٠ كجم', quantity: '٢٥٠ طن', line: 'خط إنتاج علف أبقار ١', priority: 'normal', status: 'scheduled', plannedDate: '١٧/٠١/٢٠٢٥', actualDate: '—', yieldPercent: 0, notes: '' },
  { id: 10, orderNumber: 'PO-2025-010', product: 'علف دواجن ناهي ٥٠ كجم', quantity: '٤٥٠ طن', line: 'خط إنتاج علف دواجن ١', priority: 'low', status: 'preparing', plannedDate: '١٦/٠١/٢٠٢٥', actualDate: '—', yieldPercent: 0, notes: '' },
];

const todayOrders = ordersData.filter(o => o.plannedDate === '١٥/٠١/٢٠٢٥');
const inProgress = ordersData.filter(o => o.status === 'running' || o.status === 'preparing');
const completed = ordersData.filter(o => o.status === 'completed');
const delayed = ordersData.filter(o => o.status === 'scheduled' && o.plannedDate < '١٥/٠١/٢٠٢٥');

/* ─── Status Helpers ────────────────────────────────── */
const statusSteps = ['scheduled', 'preparing', 'running', 'completed'] as const;
const statusConfig: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  scheduled: { label: 'مجدولة', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300', icon: Clock },
  preparing: { label: 'قيد التحضير', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400', icon: Play },
  running: { label: 'قيد التشغيل', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400', icon: RotateCcw },
  completed: { label: 'مكتملة', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', icon: CheckCircle2 },
  cancelled: { label: 'ملغاة', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', icon: X },
};

const priorityConfig: Record<string, { label: string; color: string }> = {
  urgent: { label: 'عاجل', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' },
  normal: { label: 'عادي', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' },
  low: { label: 'منخفض', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300' },
};

/* ─── Page ──────────────────────────────────────────── */
export default function ProductionOrdersPage() {
  const [filterStatus, setFilterStatus] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [detailOrder, setDetailOrder] = useState<ProductionOrder | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const [formData, setFormData] = useState({
    product: '', quantity: '', line: '', priority: 'normal', plannedDate: '', notes: ''
  });

  const lines = ['خط إنتاج علف دواجن ١', 'خط إنتاج علف أبقار ١', 'خط إنتاج ردة ١', 'خط إنتاج علف أغنام ١', 'خط خلط مركز ١', 'خط ت pelletizing ١', 'خط طحن صويا ١', 'خط إنتاج علف دواجن ٢'];
  const products = ['علف دواجن بادئ ٥٠ كجم', 'علف دواجن نامي ٥٠ كجم', 'علف دواجن ناهي ٥٠ كجم', 'علف أبقار جاف ٢٥ كجم', 'علف تسمين عجول ٥٠ كجم', 'ردة ناعمة مجروشة', 'بريمكس دواجن ١٪', 'كسب صويا مجروش', 'Pellets دواجن ٥٠ كجم', 'علف أغنام ٤٠ كجم'];

  const filteredData = useMemo(() => {
    let data = [...ordersData];
    if (filterStatus !== 'all') data = data.filter(o => o.status === filterStatus);
    return data;
  }, [filterStatus]);

  const columns = [
    { key: 'orderNumber', header: 'رقم الأمر', sortable: true, width: '110px' },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'quantity', header: 'الكمية', sortable: true, width: '100px' },
    { key: 'line', header: 'الخط', sortable: true },
    {
      key: 'priority',
      header: 'الأولوية',
      sortable: true,
      width: '90px',
      render: (row: Record<string, unknown>) => {
        const cfg = priorityConfig[row.priority as string];
        return <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>{cfg.label}</span>;
      },
    },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: Record<string, unknown>) => {
        const cfg = statusConfig[row.status as string];
        const Icon = cfg.icon;
        return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}><Icon size={12} /> {cfg.label}</span>;
      },
    },
    { key: 'plannedDate', header: 'تاريخ المخطط', sortable: true, width: '100px' },
    { key: 'actualDate', header: 'الفعلي', width: '100px' },
    {
      key: 'yieldPercent',
      header: 'الناتج %',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => (
        row.yieldPercent ? <span className={`font-medium ${(row.yieldPercent as number) >= 95 ? 'text-green-600' : (row.yieldPercent as number) >= 90 ? 'text-amber-600' : 'text-red-600'}`}>{row.yieldPercent}%</span> : '—'
      ),
    },
  ];

  const openDetail = (order: ProductionOrder) => {
    setDetailOrder(order);
    setIsDetailOpen(true);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="أوامر الإنتاج"
        subtitle="إدارة ومتابعة أوامر الإنتاج اليومية"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الإنتاج' }, { label: 'أوامر الإنتاج' }]}
      >
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="bg-green-700 hover:bg-green-800 text-white gap-1">
              <Plus size={16} /> أمر إنتاج جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>إنشاء أمر إنتاج جديد</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-1.5">
                <Label>المنتج</Label>
                <select value={formData.product} onChange={e => setFormData({ ...formData, product: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30">
                  <option value="">اختر المنتج</option>
                  {products.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>الكمية</Label>
                  <Input value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} placeholder="طن" />
                </div>
                <div className="space-y-1.5">
                  <Label>الخط</Label>
                  <select value={formData.line} onChange={e => setFormData({ ...formData, line: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30">
                    <option value="">اختر الخط</option>
                    {lines.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>الأولوية</Label>
                  <select value={formData.priority} onChange={e => setFormData({ ...formData, priority: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30">
                    <option value="urgent">عاجل</option>
                    <option value="normal">عادي</option>
                    <option value="low">منخفض</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <Label>تاريخ التخطيط</Label>
                  <Input type="date" value={formData.plannedDate} onChange={e => setFormData({ ...formData, plannedDate: e.target.value })} />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>ملاحظات</Label>
                <textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} className="w-full h-20 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-green-500/30" placeholder="أي ملاحظات..." />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button>
                <Button className="bg-green-700 hover:bg-green-800 text-white">إنشاء الأمر</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="أوامر اليوم" value={String(todayOrders.length)} icon={ClipboardList} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="قيد التنفيذ" value={String(inProgress.length)} change={+12} icon={Clock} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.1} />
        <KPICard title="مكتملة" value={String(completed.length)} change={+8} icon={CheckCircle2} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.2} />
        <KPICard title="متأخرة" value={String(delayed.length)} change={-20} icon={AlertTriangle} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4">
        <div className="flex flex-wrap items-center gap-2">
          <Filter size={16} className="text-gray-400" />
          <Tabs value={filterStatus} onValueChange={setFilterStatus}>
            <TabsList className="h-9">
              <TabsTrigger value="all" className="text-xs">الكل</TabsTrigger>
              <TabsTrigger value="scheduled" className="text-xs">مجدولة</TabsTrigger>
              <TabsTrigger value="preparing" className="text-xs">قيد التحضير</TabsTrigger>
              <TabsTrigger value="running" className="text-xs">قيد التشغيل</TabsTrigger>
              <TabsTrigger value="completed" className="text-xs">مكتملة</TabsTrigger>
              <TabsTrigger value="cancelled" className="text-xs">ملغاة</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Table */}
      <DataTable
        columns={columns}
        data={filteredData as unknown as Record<string, unknown>[]}
        title="أوامر الإنتاج"
        rowActions={{ onView: (row) => openDetail(row as unknown as ProductionOrder), onEdit: () => {}, onDelete: () => {} }}
      />

      {/* Detail Modal */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader><DialogTitle>تفاصيل أمر الإنتاج</DialogTitle></DialogHeader>
          {detailOrder && (
            <div className="space-y-4 mt-2">
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <span className="text-sm text-gray-500">رقم الأمر</span>
                <span className="font-semibold">{detailOrder.orderNumber}</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                  <span className="text-xs text-gray-500 block">المنتج</span>
                  <span className="text-sm font-medium">{detailOrder.product}</span>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                  <span className="text-xs text-gray-500 block">الكمية</span>
                  <span className="text-sm font-medium">{detailOrder.quantity}</span>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium">سير العمل</p>
                <div className="flex items-center gap-1">
                  {statusSteps.map((step, i) => {
                    const cfg = statusConfig[step];
                    const currentIdx = statusSteps.indexOf(detailOrder.status as typeof statusSteps[number]);
                    const isActive = i <= currentIdx;
                    const Icon = cfg.icon;
                    return (
                      <div key={step} className="flex items-center gap-1 flex-1">
                        <div className={`flex flex-col items-center gap-1 ${isActive ? 'opacity-100' : 'opacity-40'}`}>
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isActive ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                            <Icon size={14} />
                          </div>
                          <span className="text-[10px]">{cfg.label}</span>
                        </div>
                        {i < statusSteps.length - 1 && <div className={`flex-1 h-0.5 ${i < currentIdx ? 'bg-green-600' : 'bg-gray-200'}`} />}
                      </div>
                    );
                  })}
                </div>
              </div>
              {detailOrder.notes && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                  <span className="text-xs text-amber-600 block">ملاحظات</span>
                  <span className="text-sm">{detailOrder.notes}</span>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
