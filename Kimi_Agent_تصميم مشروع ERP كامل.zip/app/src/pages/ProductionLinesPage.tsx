// @ts-nocheck
import { useState, useMemo } from 'react';
import {
  Factory, Activity, Gauge, Zap, Plus, Search, Filter,
  Settings2, CheckCircle2, AlertTriangle, XCircle, Wrench
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

/* ─── Types ─────────────────────────────────────────── */
interface ProductionLine {
  id: number;
  name: string;
  type: string;
  capacity: string;
  status: 'active' | 'maintenance' | 'offline';
  efficiency: number;
  utilization: number;
  lastMaintenance: string;
  assignedProducts: string;
  speed: string;
  shiftCount: number;
  notes: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const linesData: ProductionLine[] = [
  { id: 1, name: 'خط إنتاج علف دواجن ١', type: 'علف دواجن', capacity: '١٥ طن/ساعة', status: 'active', efficiency: 92, utilization: 85, lastMaintenance: '٢٠٢٥/٠١/١٠', assignedProducts: 'علف دواجن بادئ، علف دواجن نامي', speed: '١٢٠ طن/يوم', shiftCount: 3, notes: '' },
  { id: 2, name: 'خط إنتاج علف أبقار ١', type: 'علف أبقار', capacity: '٢٠ طن/ساعة', status: 'active', efficiency: 88, utilization: 78, lastMaintenance: '٢٠٢٥/٠١/٠٥', assignedProducts: 'علف أبقار جاف، تسمين عجول', speed: '١٦٠ طن/يوم', shiftCount: 2, notes: '' },
  { id: 3, name: 'خط إنتاج ردة ١', type: 'ردة', capacity: '٢٥ طن/ساعة', status: 'active', efficiency: 95, utilization: 90, lastMaintenance: '٢٠٢٥/٠١/١٢', assignedProducts: 'ردة ناعمة، ردة خشنة', speed: '٢٠٠ طن/يوم', shiftCount: 3, notes: '' },
  { id: 4, name: 'خط إنتاج علف أغنام ١', type: 'علف أغنام', capacity: '١٠ طن/ساعة', status: 'maintenance', efficiency: 0, utilization: 0, lastMaintenance: '٢٠٢٥/٠١/١٥', assignedProducts: 'علف أغنام، علف ماعز', speed: '٨٠ طن/يوم', shiftCount: 2, notes: 'صيانة دورية للمجفف' },
  { id: 5, name: 'خط خلط مركز ١', type: 'خلط مركز', capacity: '٨ طن/ساعة', status: 'active', efficiency: 90, utilization: 82, lastMaintenance: '٢٠٢٥/٠١/٠٨', assignedProducts: 'بريمكس دواجن، بريمكس أبقار', speed: '٦٤ طن/يوم', shiftCount: 2, notes: '' },
  { id: 6, name: 'خط تعبئة أعلاف ١', type: 'تعبئة', capacity: '٥٠ كيس/دقيقة', status: 'active', efficiency: 87, utilization: 75, lastMaintenance: '٢٠٢٥/٠١/٠٣', assignedProducts: 'أكياس ٢٥ كجم، أكياس ٥٠ كجم', speed: '٧٢٠٠ كيس/يوم', shiftCount: 2, notes: '' },
  { id: 7, name: 'خط إنتاج علف دواجن ٢', type: 'علف دواجن', capacity: '١٢ طن/ساعة', status: 'offline', efficiency: 0, utilization: 0, lastMaintenance: '٢٠٢٥/٠١/٠١', assignedProducts: '—', speed: '—', shiftCount: 0, notes: 'توقف لإنتظار قطع غيار' },
  { id: 8, name: 'خط ت pelletizing ١', type: 'Pelletizing', capacity: '٣٠ طن/ساعة', status: 'active', efficiency: 93, utilization: 88, lastMaintenance: '٢٠٢٥/٠١/١١', assignedProducts: 'Pellets دواجن، Pellets أبقار', speed: '٢٤٠ طن/يوم', shiftCount: 3, notes: '' },
  { id: 9, name: 'خط طحن صويا ١', type: 'طحن', capacity: '١٨ طن/ساعة', status: 'active', efficiency: 89, utilization: 80, lastMaintenance: '٢٠٢٥/٠١/٠٩', assignedProducts: 'كسب صويا مجروش', speed: '١٤٤ طن/يوم', shiftCount: 2, notes: '' },
  { id: 10, name: 'خط إنتاج علف أحصنة ١', type: 'علف أحصنة', capacity: '٦ طن/ساعة', status: 'maintenance', efficiency: 0, utilization: 0, lastMaintenance: '٢٠٢٥/٠١/١٤', assignedProducts: 'علف أحصنة رياضية', speed: '٤٨ طن/يوم', shiftCount: 1, notes: 'تغيير شفرات المطحنة' },
];

const lineTypes = ['الكل', 'علف دواجن', 'علف أبقار', 'ردة', 'علف أغنام', 'خلط مركز', 'تعبئة', 'Pelletizing', 'طحن', 'علف أحصنة'];

/* ─── Status Helpers ────────────────────────────────── */
const statusConfig = {
  active: { label: 'نشط', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', icon: CheckCircle2 },
  maintenance: { label: 'متوقف للصيانة', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400', icon: Wrench },
  offline: { label: 'خارج الخدمة', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', icon: XCircle },
};

const activeCount = linesData.filter(l => l.status === 'active').length;
const maintenanceCount = linesData.filter(l => l.status === 'maintenance').length;
const avgEfficiency = Math.round(linesData.filter(l => l.status === 'active').reduce((s, l) => s + l.efficiency, 0) / activeCount);
const dailyCapacity = '١٬٨٩٤ طن';

/* ─── Page ──────────────────────────────────────────── */
export default function ProductionLinesPage() {
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('الكل');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editLine, setEditLine] = useState<ProductionLine | null>(null);

  const [formData, setFormData] = useState({
    name: '', type: '', capacity: '', speed: '', shiftCount: 2, notes: ''
  });

  const filteredData = useMemo(() => {
    let data = [...linesData];
    if (filterStatus !== 'all') data = data.filter(l => l.status === filterStatus);
    if (filterType !== 'الكل') data = data.filter(l => l.type === filterType);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      data = data.filter(l => l.name.toLowerCase().includes(q) || l.type.toLowerCase().includes(q));
    }
    return data;
  }, [filterStatus, filterType, searchQuery]);

  const columns = [
    { key: 'name', header: 'اسم الخط', sortable: true },
    { key: 'type', header: 'النوع', sortable: true },
    { key: 'capacity', header: 'الطاقة', sortable: true, width: '120px' },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: ProductionLine) => {
        const cfg = statusConfig[row.status];
        const Icon = cfg.icon;
        return (
          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${cfg.color}`}>
            <Icon size={12} /> {cfg.label}
          </span>
        );
      },
    },
    {
      key: 'efficiency',
      header: 'الكفاءة %',
      sortable: true,
      width: '100px',
      render: (row: ProductionLine) => (
        <div className="flex items-center gap-2">
          <div className="w-16 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${row.efficiency >= 90 ? 'bg-green-500' : row.efficiency >= 75 ? 'bg-amber-500' : 'bg-red-500'}`}
              style={{ width: `${row.efficiency}%` }}
            />
          </div>
          <span className="text-xs">{row.efficiency}%</span>
        </div>
      ),
    },
    {
      key: 'utilization',
      header: 'الاستغلال %',
      sortable: true,
      width: '100px',
      render: (row: ProductionLine) => <span className="text-sm">{row.utilization}%</span>,
    },
    { key: 'lastMaintenance', header: 'آخر صيانة', sortable: true, width: '110px' },
    { key: 'assignedProducts', header: 'المنتجات المخصصة', width: '200px' },
  ];

  const openEdit = (line: ProductionLine) => {
    setEditLine(line);
    setFormData({
      name: line.name,
      type: line.type,
      capacity: line.capacity,
      speed: line.speed,
      shiftCount: line.shiftCount,
      notes: line.notes,
    });
    setIsAddOpen(true);
  };

  const resetForm = () => {
    setEditLine(null);
    setFormData({ name: '', type: '', capacity: '', speed: '', shiftCount: 2, notes: '' });
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="إدارة خطوط الإنتاج"
        subtitle="متابعة وتخطيط خطوط الإنتاج والتعبئة"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الإنتاج' }, { label: 'خطوط الإنتاج' }]}
      >
        <Dialog open={isAddOpen} onOpenChange={(open) => { if (!open) resetForm(); setIsAddOpen(open); }}>
          <DialogTrigger asChild>
            <Button className="bg-green-700 hover:bg-green-800 text-white gap-1">
              <Plus size={16} /> إضافة خط
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader>
              <DialogTitle>{editLine ? 'تعديل خط إنتاج' : 'إضافة خط إنتاج جديد'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>اسم الخط</Label>
                  <Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="مثال: خط إنتاج علف دواجن ٣" />
                </div>
                <div className="space-y-1.5">
                  <Label>النوع</Label>
                  <Input value={formData.type} onChange={e => setFormData({ ...formData, type: e.target.value })} placeholder="مثال: علف دواجن" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>الطاقة الإنتاجية</Label>
                  <Input value={formData.capacity} onChange={e => setFormData({ ...formData, capacity: e.target.value })} placeholder="طن/ساعة" />
                </div>
                <div className="space-y-1.5">
                  <Label>السرعة</Label>
                  <Input value={formData.speed} onChange={e => setFormData({ ...formData, speed: e.target.value })} placeholder="طن/يوم" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>عدد الورديات</Label>
                <Input type="number" value={formData.shiftCount} onChange={e => setFormData({ ...formData, shiftCount: Number(e.target.value) })} min={1} max={3} />
              </div>
              <div className="space-y-1.5">
                <Label>ملاحظات</Label>
                <textarea
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full h-20 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  placeholder="أي ملاحظات إضافية..."
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => { resetForm(); setIsAddOpen(false); }}>إلغاء</Button>
                <Button className="bg-green-700 hover:bg-green-800 text-white">{editLine ? 'حفظ التعديلات' : 'إضافة الخط'}</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="عدد الخطوط" value={String(linesData.length)} icon={Factory} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="خطوط نشطة" value={String(activeCount)} change={+5} icon={Activity} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.1} />
        <KPICard title="OEE متوسط" value={`${avgEfficiency}%`} change={+2.3} icon={Gauge} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="الطاقة اليومية" value={dailyCapacity} icon={Zap} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.3} />
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4 space-y-3">
        <div className="flex flex-col lg:flex-row gap-3 items-start lg:items-center justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <Filter size={16} className="text-gray-400" />
            <Tabs value={filterStatus} onValueChange={setFilterStatus}>
              <TabsList className="h-9">
                <TabsTrigger value="all" className="text-xs">الكل</TabsTrigger>
                <TabsTrigger value="active" className="text-xs">نشط</TabsTrigger>
                <TabsTrigger value="maintenance" className="text-xs">صيانة</TabsTrigger>
                <TabsTrigger value="offline" className="text-xs">خارج الخدمة</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Settings2 size={16} className="text-gray-400" />
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="h-9 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
            >
              {lineTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <DataTable
        columns={columns}
        data={filteredData as unknown as Record<string, unknown>[]}
        title="خطوط الإنتاج"
        rowActions={{
          onView: (row) => openEdit(row as unknown as ProductionLine),
          onEdit: (row) => openEdit(row as unknown as ProductionLine),
          onDelete: () => {},
        }}
      />
    </div>
  );
}
