// @ts-nocheck
import { useState } from 'react';
import { Warehouse, AlertTriangle, Plus, TrendingUp, Wheat, Package, Search } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';

/* ─── Types ─────────────────────────────────────────── */
interface RawMaterial {
  id: number;
  name: string;
  type: string;
  protein: number;
  currentStock: number;
  minLevel: number;
  unitPrice: number;
  suppliers: string[];
  unit: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const materialsData: RawMaterial[] = [
  { id: 1, name: 'ذرة صفراء مجروشة', type: 'حبوب', protein: 8.5, currentStock: 1250, minLevel: 500, unitPrice: 8500, suppliers: ['شركة الحبوب العربية', 'مؤسسة النصر'], unit: 'طن' },
  { id: 2, name: 'كسب فول صويا (٤٤٪)', type: 'كسب', protein: 44.0, currentStock: 680, minLevel: 300, unitPrice: 15200, suppliers: ['شركة الصويا الدولية'], unit: 'طن' },
  { id: 3, name: 'ردة قمح خشنة', type: 'مشتقات', protein: 14.0, currentStock: 320, minLevel: 200, unitPrice: 4200, suppliers: ['مطاحن القاهرة', 'مطاحن الدلتا'], unit: 'طن' },
  { id: 4, name: 'كسب عباد شمس', type: 'كسب', protein: 28.0, currentStock: 180, minLevel: 100, unitPrice: 9800, suppliers: ['شركة الزيوت المصرية'], unit: 'طن' },
  { id: 5, name: 'ملح طعام', type: 'إضافات', protein: 0, currentStock: 45, minLevel: 20, unitPrice: 1200, suppliers: ['شركة الملح الوطنية'], unit: 'طن' },
  { id: 6, name: 'فوسفات أحادي الكالسيوم', type: 'إضافات', protein: 0, currentStock: 85, minLevel: 50, unitPrice: 18500, suppliers: ['الشركة العربية للأسمدة'], unit: 'طن' },
  { id: 7, name: 'بريمكس فيتامينات', type: 'إضافات', protein: 0, currentStock: 12, minLevel: 10, unitPrice: 65000, suppliers: ['DSM مصر', 'Adisseo'], unit: 'طن' },
  { id: 8, name: 'ميثايونين', type: 'إضافات', protein: 58.0, currentStock: 8, minLevel: 5, unitPrice: 95000, suppliers: ['Evonik مصر'], unit: 'طن' },
  { id: 9, name: 'ليزين HCl', type: 'إضافات', protein: 95.0, currentStock: 6, minLevel: 5, unitPrice: 88000, suppliers: ['CJ مصر'], unit: 'طن' },
  { id: 10, name: 'شعير', type: 'حبوب', protein: 11.0, currentStock: 420, minLevel: 200, unitPrice: 7800, suppliers: ['شركة الحبوب العربية'], unit: 'طن' },
  { id: 11, name: 'دريس برسيم', type: 'أعلاف خضرة', protein: 16.0, currentStock: 150, minLevel: 100, unitPrice: 3200, suppliers: ['مزارع الوادي'], unit: 'طن' },
  { id: 12, name: 'كسب قطن (٤١٪)', type: 'كسب', protein: 41.0, currentStock: 95, minLevel: 80, unitPrice: 7200, suppliers: ['شركة القطن المصرية'], unit: 'طن' },
];

const priceHistoryData = [
  { month: 'أغسطس', price: 8200 }, { month: 'سبتمبر', price: 8400 }, { month: 'أكتوبر', price: 8300 },
  { month: 'نوفمبر', price: 8600 }, { month: 'ديسمبر', price: 8500 }, { month: 'يناير', price: 8500 },
];

/* ─── Stock Level Helper ────────────────────────────── */
const getStockLevel = (current: number, min: number) => {
  const ratio = current / min;
  if (ratio >= 2) return { color: 'bg-green-500', label: 'ممتاز', width: Math.min(100, ratio * 25) };
  if (ratio >= 1) return { color: 'bg-amber-500', label: 'مقبول', width: ratio * 50 };
  return { color: 'bg-red-500', label: 'منخفض', width: Math.max(5, ratio * 50) };
};

/* ─── Page ──────────────────────────────────────────── */
export default function FeedMaterialsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', type: '', protein: '', minLevel: '', unitPrice: '', suppliers: '' });
  const [selectedMaterial, setSelectedMaterial] = useState<RawMaterial | null>(null);
  const [isPriceOpen, setIsPriceOpen] = useState(false);

  const lowStockCount = materialsData.filter(m => m.currentStock < m.minLevel).length;

  const filteredData = materialsData.filter(m =>
    !searchQuery || m.name.toLowerCase().includes(searchQuery.toLowerCase()) || m.type.includes(searchQuery)
  );

  const columns = [
    { key: 'name', header: 'المادة الخام', sortable: true },
    { key: 'type', header: 'النوع', sortable: true },
    {
      key: 'protein',
      header: 'بروتين %',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => <span className="font-medium">{(row.protein as number) || '—'}</span>,
    },
    {
      key: 'currentStock',
      header: 'المخزون الحالي',
      sortable: true,
      render: (row: Record<string, unknown>) => {
        const level = getStockLevel(row.currentStock as number, row.minLevel as number);
        return (
          <div className="space-y-1 min-w-[120px]">
            <div className="flex items-center justify-between"><span className="text-sm">{row.currentStock} {row.unit}</span><span className={`text-[10px] ${level.color === 'bg-red-500' ? 'text-red-600' : 'text-green-600'}`}>{level.label}</span></div>
            <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden"><div className={`h-full ${level.color} rounded-full transition-all`} style={{ width: `${Math.min(100, level.width)}%` }} /></div>
          </div>
        );
      },
    },
    { key: 'minLevel', header: 'الحد الأدنى', width: '90px', render: (row: Record<string, unknown>) => <span>{row.minLevel} {row.unit}</span> },
    {
      key: 'unitPrice',
      header: 'السعر/طن',
      sortable: true,
      width: '100px',
      render: (row: Record<string, unknown>) => <span className="font-medium">{(row.unitPrice as number).toLocaleString()} ج.م</span>,
    },
    {
      key: 'suppliers',
      header: 'الموردين',
      render: (row: Record<string, unknown>) => <span className="text-xs">{(row.suppliers as string[]).join('، ')}</span>,
    },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="المخزون الخام" subtitle="إدارة وتتبع المواد الخام والمخزون" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الأعلاف' }, { label: 'المواد الخام' }]}>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild><Button className="bg-green-700 hover:bg-green-800 text-white gap-1"><Plus size={16} /> إضافة مادة</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>إضافة مادة خام جديدة</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>اسم المادة</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="مثال: ذرة صفراء" /></div>
                <div className="space-y-1.5"><Label>النوع</Label>
                  <select value={formData.type} onChange={e => setFormData({ ...formData, type: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option value="">اختر</option><option value="حبوب">حبوب</option><option value="كسب">كسب</option><option value="مشتقات">مشتقات</option><option value="إضافات">إضافات</option><option value="أعلاف خضرة">أعلاف خضرة</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5"><Label>بروتين %</Label><Input type="number" value={formData.protein} onChange={e => setFormData({ ...formData, protein: e.target.value })} placeholder="٠" /></div>
                <div className="space-y-1.5"><Label>الحد الأدنى</Label><Input type="number" value={formData.minLevel} onChange={e => setFormData({ ...formData, minLevel: e.target.value })} placeholder="طن" /></div>
                <div className="space-y-1.5"><Label>السعر/طن</Label><Input type="number" value={formData.unitPrice} onChange={e => setFormData({ ...formData, unitPrice: e.target.value })} placeholder="ج.م" /></div>
              </div>
              <div className="space-y-1.5"><Label>الموردين (مفصولة بفواصل)</Label><Input value={formData.suppliers} onChange={e => setFormData({ ...formData, suppliers: e.target.value })} placeholder="شركة ١، شركة ٢" /></div>
              <div className="flex justify-end gap-2 pt-2"><Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button><Button className="bg-green-700 hover:bg-green-800 text-white">حفظ المادة</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5 flex items-center gap-4">
          <div className="w-11 h-11 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center"><Warehouse size={22} className="text-green-700 dark:text-green-400" /></div>
          <div><h3 className="text-2xl font-bold">{materialsData.length}</h3><p className="text-xs text-gray-500">إجمالي المواد الخام</p></div>
        </div>
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5 flex items-center gap-4">
          <div className="w-11 h-11 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center"><AlertTriangle size={22} className="text-red-700 dark:text-red-400" /></div>
          <div><h3 className="text-2xl font-bold text-red-600">{lowStockCount}</h3><p className="text-xs text-gray-500">مواد منخفضة المخزون</p></div>
        </div>
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5 flex items-center gap-4">
          <div className="w-11 h-11 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center"><TrendingUp size={22} className="text-amber-700 dark:text-amber-400" /></div>
          <div><h3 className="text-2xl font-bold">{(materialsData.reduce((s, m) => s + m.unitPrice, 0) / materialsData.length / 1000).toFixed(1)}K</h3><p className="text-xs text-gray-500">متوسط السعر/طن</p></div>
        </div>
      </div>

      {/* Search & Price Chart */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <Input type="text" placeholder="بحث في المواد الخام..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pr-9" />
        </div>
        <Dialog open={isPriceOpen} onOpenChange={setIsPriceOpen}>
          <DialogTrigger asChild><Button variant="outline" className="gap-1"><TrendingUp size={16} /> سعر التاريخ</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>تاريخ أسعار {selectedMaterial?.name || 'الذرة الصفراء'}</DialogTitle></DialogHeader>
            <div className="mt-4">
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={priceHistoryData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="month" />
                  <YAxis domain={['dataMin - 200', 'dataMax + 200']} />
                  <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
                  <Line type="monotone" dataKey="price" name="السعر (ج.م/طن)" stroke="#108a56" strokeWidth={3} dot={{ r: 5, fill: '#108a56' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Table */}
      <DataTable columns={columns} data={filteredData as unknown as Record<string, unknown>[]} title="المواد الخام" rowActions={{
        onView: (row) => { setSelectedMaterial(row as unknown as RawMaterial); setIsPriceOpen(true); },
        onEdit: () => {}, onDelete: () => {},
      }} />
    </div>
  );
}
