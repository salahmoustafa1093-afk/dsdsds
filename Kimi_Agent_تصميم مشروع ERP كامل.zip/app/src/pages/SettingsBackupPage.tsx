import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Database, Calendar, Clock, HardDrive, Download,
  RotateCcw, Save, Check, Cloud, FileSpreadsheet,
  Package, Users, Receipt
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';

const backupHistory = [
  { id: 1, date: '2025-01-15 03:00', type: 'تلقائي', size: '245 MB', status: 'ناجح' },
  { id: 2, date: '2025-01-14 03:00', type: 'تلقائي', size: '243 MB', status: 'ناجح' },
  { id: 3, date: '2025-01-13 15:30', type: 'يدوي', size: '242 MB', status: 'ناجح' },
  { id: 4, date: '2025-01-13 03:00', type: 'تلقائي', size: '241 MB', status: 'ناجح' },
  { id: 5, date: '2025-01-12 03:00', type: 'تلقائي', size: '240 MB', status: 'فاشل' },
  { id: 6, date: '2025-01-11 03:00', type: 'تلقائي', size: '238 MB', status: 'ناجح' },
  { id: 7, date: '2025-01-10 12:00', type: 'يدوي', size: '237 MB', status: 'ناجح' },
];

export default function SettingsBackupPage() {
  const [saved, setSaved] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [schedule, setSchedule] = useState('daily');
  const [backupTime, setBackupTime] = useState('03:00');
  const [retention, setRetention] = useState(30);

  const handleBackupNow = () => {
    setIsBackingUp(true);
    setTimeout(() => setIsBackingUp(false), 2000);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const statusBadge = (status: string) => (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
      status === 'ناجح'
        ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400'
        : 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
    }`}>
      {status}
    </span>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="النسخ الاحتياطي والاستعادة"
        subtitle="جدولة النسخ الاحتياطي وإدارة النسخ السابقة"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الإعدادات', path: '/settings' },
          { label: 'نسخ احتياطي' },
        ]}
      />

      {/* Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="آخر نسخة" value="15 يناير 03:00" icon={Clock} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="حجم النسخة" value="245 MB" icon={HardDrive} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="الطريقة" value="تلقائي يومي" icon={Cloud} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Schedule Settings */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-2 flex items-center gap-2">
            <Calendar size={18} className="text-green-600" />
            إعدادات الجدولة
          </h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-textSecondary mb-2 block">التكرار</label>
              <div className="flex gap-2">
                {[
                  { key: 'daily', label: 'يومي' },
                  { key: 'weekly', label: 'أسبوعي' },
                  { key: 'monthly', label: 'شهري' },
                ].map((s) => (
                  <button
                    key={s.key}
                    onClick={() => setSchedule(s.key)}
                    className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${
                      schedule === s.key
                        ? 'bg-green-700 text-white border-green-700'
                        : 'border-uiBorder dark:border-darkBorder text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">وقت النسخ</label>
              <input type="time" value={backupTime} onChange={(e) => setBackupTime(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">الاحتفاظ بآخر (يوم)</label>
              <input type="number" value={retention} onChange={(e) => setRetention(Number(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
          </div>
          <div className="flex gap-2 pt-2">
            <button
              onClick={handleBackupNow}
              disabled={isBackingUp}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-green-700 hover:bg-green-800 disabled:opacity-70 text-white text-sm font-medium transition-colors"
            >
              <Database size={16} className={isBackingUp ? 'animate-spin' : ''} />
              {isBackingUp ? 'جاري النسخ...' : 'نسخ الآن'}
            </button>
            <button onClick={handleSave} className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">
              {saved ? <Check size={16} /> : <Save size={16} />}
              <span>{saved ? 'تم' : 'حفظ'}</span>
            </button>
          </div>
        </motion.div>

        {/* Export Data */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-2 flex items-center gap-2">
            <FileSpreadsheet size={18} className="text-green-600" />
            تصدير البيانات
          </h3>
          <div className="space-y-3">
            {[
              { icon: Package, label: 'المنتجات', description: 'قائمة المنتجات والأصناف' },
              { icon: Users, label: 'العملاء', description: 'بيانات العملاء' },
              { icon: Receipt, label: 'الحركات المالية', description: 'المعاملات والقيود المحاسبية' },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between p-4 rounded-lg bg-surface dark:bg-darkCard">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <item.icon size={18} className="text-green-700 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{item.label}</p>
                    <p className="text-xs text-textSecondary">{item.description}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button className="px-3 py-1.5 rounded-lg text-xs font-medium bg-green-700 hover:bg-green-800 text-white transition-colors">CSV</button>
                  <button className="px-3 py-1.5 rounded-lg text-xs font-medium border border-uiBorder dark:border-darkBorder text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">Excel</button>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-uiBorder dark:border-darkBorder">
            <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-red-300 dark:border-red-800 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20 text-sm font-medium transition-colors">
              <RotateCcw size={16} />
              استعادة من نسخة احتياطية
            </button>
          </div>
        </motion.div>
      </div>

      {/* Backup History */}
      <DataTable
        title="سجل النسخ الاحتياطي"
        columns={[
          { key: 'date', header: 'التاريخ', sortable: true },
          { key: 'type', header: 'النوع', render: (row) => (
            <span className={`text-xs font-medium ${(row.type as string) === 'تلقائي' ? 'text-blue-600' : 'text-amber-600'}`}>{row.type as string}</span>
          ) },
          { key: 'size', header: 'الحجم', sortable: true },
          { key: 'status', header: 'الحالة', render: (row) => statusBadge(row.status as string) },
          { key: 'download', header: 'تحميل', render: () => (
            <button className="flex items-center gap-1 text-xs text-green-600 hover:text-green-700 font-medium">
              <Download size={12} />
              تحميل
            </button>
          ) },
        ]}
        data={backupHistory as unknown as Record<string, unknown>[]}
        pageSize={7}
      />
    </div>
  );
}
