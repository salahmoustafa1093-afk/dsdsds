import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Warehouse, MapPin, UserCheck, Package, ArrowDownLeft, ArrowUpRight,
  Plus, X, Check, Ruler
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';

const warehouses = [
  { id: 1, name: 'المستودع الرئيسي', location: 'القاهرة - العاشر من رمضان', manager: 'محمد أحمد', type: 'رئيسي', products: 450, capacity: 5000, used: 4200, status: 'نشط' },
  { id: 2, name: 'مستودع الإسكندرية', location: 'الإسكندرية - برج العرب', manager: 'أحمد علي', type: 'فرعي', products: 280, capacity: 3000, used: 2100, status: 'نشط' },
  { id: 3, name: 'مستودع طنطا', location: 'الغربية - طنطا', manager: 'محمود سالم', type: 'فرعي', products: 120, capacity: 1500, used: 800, status: 'نشط' },
  { id: 4, name: 'مستودع المنصورة', location: 'الدقهلية - المنصورة', manager: 'خالد عمر', type: 'فرعي', products: 90, capacity: 1200, used: 650, status: 'صيانة' },
  { id: 5, name: 'مستودع أسيوط', location: 'أسيوط - الصناعية', manager: 'يوسف إبراهيم', type: 'خارجي', products: 65, capacity: 2000, used: 450, status: 'نشط' },
];

const warehouseProducts = [
  { id: 1, name: 'علف دواجن بادئ ٢٥ كجم', sku: 'FD-B-25', stock: 1200, min: 100, status: 'متوفر' },
  { id: 2, name: 'علف دواجن نامي ٢٥ كجم', sku: 'FD-N-25', stock: 850, min: 100, status: 'متوفر' },
  { id: 3, name: 'علف أبقار حلاب ٤٠ كجم', sku: 'FB-H-40', stock: 420, min: 50, status: 'متوفر' },
  { id: 4, name: 'ذرة صفراء مجروشة', sku: 'RM-Z-01', stock: 95, min: 200, status: 'منخفض' },
  { id: 5, name: 'صويا مبشورة ٤٨%', sku: 'RM-S-48', stock: 1800, min: 300, status: 'متوفر' },
];

const movements = [
  { id: 1, date: '2025-01-15', type: 'وارد', product: 'علف دواجن بادئ', quantity: 500, reference: 'GR-001' },
  { id: 2, date: '2025-01-14', type: 'صادر', product: 'ذرة صفراء مجروشة', quantity: 200, reference: 'GI-002' },
  { id: 3, date: '2025-01-14', type: 'وارد', product: 'صويا مبشورة', quantity: 1000, reference: 'GR-003' },
  { id: 4, date: '2025-01-13', type: 'صادر', product: 'علف أبقار حلاب', quantity: 150, reference: 'GI-004' },
];

export default function InventoryWarehousePage() {
  const [showForm, setShowForm] = useState(false);
  const [showDetail, setShowDetail] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'products' | 'movements'>('products');

  const [formName, setFormName] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formType, setFormType] = useState('فرعي');
  const [formCapacity, setFormCapacity] = useState('');
  const [formManager, setFormManager] = useState('');

  const totalWarehouses = warehouses.length;
  const totalCapacity = warehouses.reduce((s, w) => s + w.capacity, 0);
  const totalUsed = warehouses.reduce((s, w) => s + w.used, 0);
  const utilization = ((totalUsed / totalCapacity) * 100).toFixed(1);
  const todayMovements = movements.length;

  const handleAddWarehouse = () => {
    setShowForm(false);
    setFormName('');
    setFormLocation('');
    setFormCapacity('');
    setFormManager('');
  };

  const typeBadge = (type: string) => (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
      type === 'رئيسي' ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400' :
      type === 'فرعي' ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400' :
      'bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-400'
    }`}>
      {type}
    </span>
  );

  const statusBadge = (status: string) => (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
      status === 'نشط' ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400' :
      'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400'
    }`}>
      {status}
    </span>
  );

  const detailWarehouse = warehouses.find((w) => w.id === showDetail);

  return (
    <div className="space-y-6">
      <PageHeader
        title="المستودعات"
        subtitle="إدارة المستودعات والمخزون والحركات"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'المخزون', path: '/inventory' },
          { label: 'المستودعات' },
        ]}
      >
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>مستودع جديد</span>
        </button>
      </PageHeader>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="عدد المستودعات" value={String(totalWarehouses)} icon={Warehouse} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="إجمالي المساحة" value={`${totalCapacity.toLocaleString('ar-EG')} م²`} icon={Ruler} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="نسبة الاستغلال" value={`${utilization}%`} icon={Package} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="حركات اليوم" value={String(todayMovements)} icon={ArrowDownLeft} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-700 dark:text-purple-400" delay={0.3} />
      </div>

      {/* Warehouse Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {warehouses.map((w, i) => (
          <motion.div
            key={w.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.05 * i }}
            className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => setShowDetail(w.id)}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <Warehouse size={20} className="text-green-700 dark:text-green-400" />
              </div>
              <div className="flex gap-1">
                {typeBadge(w.type)}
                {statusBadge(w.status)}
              </div>
            </div>
            <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-1">{w.name}</h4>
            <p className="text-xs text-textMuted flex items-center gap-1 mb-3">
              <MapPin size={12} />
              {w.location}
            </p>
            <div className="flex justify-between text-xs text-textSecondary mb-2">
              <span className="flex items-center gap-1"><UserCheck size={12} /> {w.manager}</span>
              <span className="flex items-center gap-1"><Package size={12} /> {w.products} منتج</span>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-textMuted">الاستغلال: {((w.used / w.capacity) * 100).toFixed(0)}%</span>
                <span className="text-textMuted">{w.used}/{w.capacity} م²</span>
              </div>
              <div className="w-full h-2 bg-surface dark:bg-darkCard rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(w.used / w.capacity) * 100}%` }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  className={`h-full rounded-full ${(w.used / w.capacity) > 0.9 ? 'bg-red-500' : (w.used / w.capacity) > 0.7 ? 'bg-amber-500' : 'bg-green-500'}`}
                />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Warehouse Table */}
      <DataTable
        title="قائمة المستودعات"
        columns={[
          { key: 'name', header: 'المستودع', sortable: true },
          { key: 'location', header: 'الموقع', sortable: true },
          { key: 'type', header: 'النوع', render: (row) => typeBadge(row.type as string) },
          { key: 'products', header: 'المنتجات', sortable: true },
          { key: 'capacity', header: 'السعة (م²)', sortable: true },
          { key: 'used', header: 'المستخدم (م²)', sortable: true },
          { key: 'status', header: 'الحالة', render: (row) => statusBadge(row.status as string) },
        ]}
        data={warehouses as unknown as Record<string, unknown>[]}
        rowActions={{ onView: (row) => setShowDetail((row as {id: number}).id) }}
        pageSize={5}
      />

      {/* Add Warehouse Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إضافة مستودع جديد</h3>
                <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">اسم المستودع</label>
                  <input value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="اسم المستودع" />
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">الموقع</label>
                  <input value={formLocation} onChange={(e) => setFormLocation(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="المدينة - المنطقة" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">النوع</label>
                    <select value={formType} onChange={(e) => setFormType(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      <option>رئيسي</option>
                      <option>فرعي</option>
                      <option>خارجي</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">السعة (م²)</label>
                    <input type="number" value={formCapacity} onChange={(e) => setFormCapacity(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="0" />
                  </div>
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">المدير</label>
                  <input value={formManager} onChange={(e) => setFormManager(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="اسم المدير" />
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إلغاء</button>
                <button onClick={handleAddWarehouse} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors flex items-center gap-1">
                  <Check size={14} />
                  حفظ
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Warehouse Detail Modal */}
      <AnimatePresence>
        {showDetail && detailWarehouse && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowDetail(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <div>
                  <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{detailWarehouse.name}</h3>
                  <p className="text-xs text-textMuted flex items-center gap-1">
                    <MapPin size={12} />
                    {detailWarehouse.location}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {typeBadge(detailWarehouse.type)}
                  {statusBadge(detailWarehouse.status)}
                  <button onClick={() => setShowDetail(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                    <X size={18} />
                  </button>
                </div>
              </div>

              {/* Summary */}
              <div className="p-5 grid grid-cols-4 gap-3 border-b border-uiBorder dark:border-darkBorder">
                <div className="p-3 rounded-lg bg-surface dark:bg-darkCard text-center">
                  <p className="text-xs text-textSecondary">السعة</p>
                  <p className="text-lg font-bold text-textPrimary dark:text-darkText">{detailWarehouse.capacity} م²</p>
                </div>
                <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/20 text-center">
                  <p className="text-xs text-green-600">المستخدم</p>
                  <p className="text-lg font-bold text-green-700 dark:text-green-400">{detailWarehouse.used} م²</p>
                </div>
                <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/20 text-center">
                  <p className="text-xs text-blue-600">المنتجات</p>
                  <p className="text-lg font-bold text-blue-700 dark:text-blue-400">{detailWarehouse.products}</p>
                </div>
                <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/20 text-center">
                  <p className="text-xs text-amber-600">الاستغلال</p>
                  <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{((detailWarehouse.used / detailWarehouse.capacity) * 100).toFixed(0)}%</p>
                </div>
              </div>

              {/* Layout Placeholder */}
              <div className="p-5 border-b border-uiBorder dark:border-darkBorder">
                <p className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">مخطط المستودع</p>
                <div className="w-full h-40 rounded-xl border-2 border-dashed border-uiBorder dark:border-darkBorder flex items-center justify-center bg-surface dark:bg-darkCard">
                  <div className="text-center">
                    <Warehouse size={32} className="text-textMuted mx-auto mb-2" />
                    <p className="text-xs text-textMuted">مخطط المستودع (تفاعلي)</p>
                  </div>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-uiBorder dark:border-darkBorder">
                {[
                  { key: 'products' as const, label: 'المنتجات', icon: Package },
                  { key: 'movements' as const, label: 'الحركات', icon: ArrowDownLeft },
                ].map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-colors ${
                      activeTab === tab.key
                        ? 'border-green-600 text-green-700 dark:text-green-400'
                        : 'border-transparent text-textSecondary dark:text-darkTextSec'
                    }`}
                  >
                    <tab.icon size={14} />
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              <div className="flex-1 overflow-auto p-4">
                {activeTab === 'products' ? (
                  <DataTable
                    columns={[
                      { key: 'name', header: 'المنتج', sortable: true },
                      { key: 'sku', header: 'SKU', sortable: true },
                      { key: 'stock', header: 'المخزون', sortable: true },
                      { key: 'min', header: 'الحد الأدنى', sortable: true },
                      { key: 'status', header: 'الحالة', render: (row) => (
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                          row.status === 'متوفر' ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400' :
                          'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
                        }`}>
                          {row.status as string}
                        </span>
                      ) },
                    ]}
                    data={warehouseProducts as unknown as Record<string, unknown>[]}
                    pageSize={5}
                  />
                ) : (
                  <DataTable
                    columns={[
                      { key: 'date', header: 'التاريخ', sortable: true },
                      { key: 'type', header: 'النوع', render: (row) => (
                        <span className={`inline-flex items-center gap-1 text-xs font-medium ${
                          row.type === 'وارد' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {row.type === 'وارد' ? <ArrowDownLeft size={12} /> : <ArrowUpRight size={12} />}
                          {row.type as string}
                        </span>
                      ) },
                      { key: 'product', header: 'المنتج', sortable: true },
                      { key: 'quantity', header: 'الكمية', sortable: true },
                      { key: 'reference', header: 'المرجع', sortable: true },
                    ]}
                    data={movements as unknown as Record<string, unknown>[]}
                    pageSize={5}
                  />
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
