// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bean, Plus, Search, X, CheckCircle2, AlertTriangle, ArrowLeft,
  Clock, Package, TrendingUp, Thermometer, Droplets, Scale,
  ChevronRight, Pencil, Trash2, Eye, Truck, Factory, Filter,
  CircleDot, ArrowRight, Warehouse,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

/* ─── grade helpers ─── */
const gradeLabels: Record<string, string> = {
  excellent: 'ممتاز',
  first: 'أولى',
  second: 'ثانية',
  waste: 'هدر',
};

const gradeColors: Record<string, string> = {
  excellent: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  first: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  second: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
  waste: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

const productLabels: Record<string, string> = {
  fava: 'فول',
  lentil: 'عدس',
  chickpea: 'حمص',
  lupine: 'لوبيا',
};

/* ─── mock data ─── */
const receptionBatches = [
  { id: 1, batchNo: 'RCV-2024-001', supplier: 'مزارع النيل', product: 'fava', quantity: 2500, moisture: 12.5, purity: 98, status: 'مستلم', date: '2024-12-19', truck: 'TRK-101', driver: 'محمد سامي', notes: 'جودة ممتازة' },
  { id: 2, batchNo: 'RCV-2024-002', supplier: 'مزارع الدلتا', product: 'lentil', quantity: 1800, moisture: 13.2, purity: 96, status: 'قيد الفحص', date: '2024-12-19', truck: 'TRK-102', driver: 'أحمد كمال', notes: '' },
  { id: 3, batchNo: 'RCV-2024-003', supplier: 'مزارع الصعيد', product: 'chickpea', quantity: 3200, moisture: 11.8, purity: 97, status: 'مستلم', date: '2024-12-18', truck: 'TRK-103', driver: 'خالد محمود', notes: '' },
  { id: 4, batchNo: 'RCV-2024-004', supplier: 'مزارع النيل', product: 'lupine', quantity: 1500, moisture: 14.0, purity: 94, status: 'مرفوض', date: '2024-12-18', truck: 'TRK-104', driver: 'سامي رجب', notes: 'رطوبة عالية' },
  { id: 5, batchNo: 'RCV-2024-005', supplier: 'مزارع الدلتا', product: 'fava', quantity: 2100, moisture: 12.0, purity: 99, status: 'مستلم', date: '2024-12-17', truck: 'TRK-105', driver: 'علي حسن', notes: 'أفضل دفعة هذا الشهر' },
  { id: 6, batchNo: 'RCV-2024-006', supplier: 'مزارع الصعيد', product: 'lentil', quantity: 2800, moisture: 12.8, purity: 95, status: 'مستلم', date: '2024-12-17', truck: 'TRK-106', driver: 'محمود سعيد', notes: '' },
  { id: 7, batchNo: 'RCV-2024-007', supplier: 'مزارع النيل', product: 'chickpea', quantity: 1900, moisture: 13.5, purity: 93, status: 'قيد الفحص', date: '2024-12-16', truck: 'TRK-107', driver: 'كمال رأفت', notes: '' },
  { id: 8, batchNo: 'RCV-2024-008', supplier: 'مزارع الدلتا', product: 'fava', quantity: 3500, moisture: 11.5, purity: 98, status: 'مستلم', date: '2024-12-16', truck: 'TRK-108', driver: 'حسن علي', notes: '' },
  { id: 9, batchNo: 'RCV-2024-009', supplier: 'مزارع الصعيد', product: 'lupine', quantity: 1200, moisture: 12.2, purity: 97, status: 'مستلم', date: '2024-12-15', truck: 'TRK-109', driver: 'رأفت نبيل', notes: '' },
  { id: 10, batchNo: 'RCV-2024-010', supplier: 'مزارع النيل', product: 'lentil', quantity: 2600, moisture: 13.0, purity: 96, status: 'قيد الفحص', date: '2024-12-15', truck: 'TRK-110', driver: 'نبيل سمير', notes: '' },
];

const packagingOrders = [
  { id: 1, orderNo: 'PKG-2024-001', product: 'fava', grade: 'excellent', packageType: '50kg', qty: 500, status: 'قيد التنفيذ', customer: 'شركة التوزيع العربية' },
  { id: 2, orderNo: 'PKG-2024-002', product: 'lentil', grade: 'first', packageType: '25kg', qty: 1200, status: 'مجدولة', customer: 'هايبر ماركت المصري' },
  { id: 3, orderNo: 'PKG-2024-003', product: 'chickpea', grade: 'excellent', packageType: '50kg', qty: 800, status: 'مكتملة', customer: 'مخازن الأمل' },
  { id: 4, orderNo: 'PKG-2024-004', product: 'fava', grade: 'second', packageType: '50kg', qty: 300, status: 'قيد التنفيذ', customer: 'مصنع المعكرونة السعودي' },
  { id: 5, orderNo: 'PKG-2024-005', product: 'lupine', grade: 'excellent', packageType: '25kg', qty: 200, status: 'مجدولة', customer: 'شركة الصادرات الغذائية' },
];

const processingStages = [
  { name: 'الاستلام', icon: Truck, count: 8, color: '#0d6b43' },
  { name: 'التنظيف', icon: Filter, count: 6, color: '#2d8a5e' },
  { name: 'الفرز', icon: CircleDot, count: 5, color: '#daa520' },
  { name: 'التصنيف', icon: Scale, count: 4, color: '#e5a220' },
  { name: 'التعبئة', icon: Package, count: 3, color: '#0a4a30' },
];

const gradeDistribution = [
  { grade: 'ممتاز (كامل)', fava: 40, lentil: 35, chickpea: 45, lupine: 30 },
  { grade: 'أولى (كسر <5%)', fava: 30, lentil: 32, chickpea: 25, lupine: 35 },
  { grade: 'ثانية (كسر 5-15%)', fava: 20, lentil: 22, chickpea: 20, lupine: 25 },
  { grade: 'هدر (>15%)', fava: 10, lentil: 11, chickpea: 10, lupine: 10 },
];

/* ─── helper components ─── */
function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    'مستلم': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
    'قيد الفحص': 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
    'مرفوض': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
    'مجدولة': 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
    'قيد التنفيذ': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
    'مكتملة': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status] || 'bg-gray-100 text-gray-700'}`}>
      {status === 'مستلم' && <CheckCircle2 size={12} />}
      {status === 'مكتملة' && <CheckCircle2 size={12} />}
      {status === 'قيد الفحص' && <Clock size={12} />}
      {status === 'مرفوض' && <AlertTriangle size={12} />}
      {status}
    </span>
  );
}

function GradeBadge({ grade }: { grade: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${gradeColors[grade] || ''}`}>
      {gradeLabels[grade] || grade}
    </span>
  );
}

function ProcessingPipeline() {
  return (
    <div className="flex items-center justify-between gap-2 overflow-x-auto py-4">
      {processingStages.map((stage, i) => {
        const Icon = stage.icon;
        return (
          <div key={stage.name} className="flex items-center gap-2 flex-shrink-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.1 }}
              className="flex flex-col items-center gap-2 p-4 rounded-xl border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkSurface hover:shadow-md transition-all min-w-[100px]"
            >
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${stage.color}20` }}>
                <Icon size={20} style={{ color: stage.color }} />
              </div>
              <span className="text-xs font-semibold text-textPrimary dark:text-darkText">{stage.name}</span>
              <span className="text-lg font-bold" style={{ color: stage.color }}>{stage.count}</span>
              <span className="text-[10px] text-textMuted">دفعات</span>
            </motion.div>
            {i < processingStages.length - 1 && (
              <ArrowLeft size={20} className="text-textMuted flex-shrink-0" />
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ─── main page ─── */
export default function PulsesPage() {
  const [batches, setBatches] = useState(receptionBatches);
  const [packages, setPackages] = useState(packagingOrders);
  const [showReceptionModal, setShowReceptionModal] = useState(false);
  const [showPackagingModal, setShowPackagingModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterProduct, setFilterProduct] = useState('الكل');
  const [filterStatus, setFilterStatus] = useState('الكل');
  const [showDetailBatch, setShowDetailBatch] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState('reception');

  const [receptionForm, setReceptionForm] = useState({
    supplier: '', product: 'fava', quantity: '', moisture: '', purity: '', driver: '', truck: '', notes: '',
  });

  const [packagingForm, setPackagingForm] = useState({
    customer: '', product: 'fava', grade: 'excellent', packageType: '50kg', qty: '',
  });

  const todayBatches = batches.filter(b => b.date === '2024-12-19').length;
  const receivedQty = batches.filter(b => b.status === 'مستلم').reduce((s, b) => s + b.quantity, 0);
  const sortedQty = 8500;
  const packedQty = 4200;

  const filteredBatches = batches.filter(b => {
    const matchSearch = b.batchNo.toLowerCase().includes(searchQuery.toLowerCase()) || b.supplier.includes(searchQuery);
    const matchProduct = filterProduct === 'الكل' || b.product === filterProduct;
    const matchStatus = filterStatus === 'الكل' || b.status === filterStatus;
    return matchSearch && matchProduct && matchStatus;
  });

  const handleAddReception = () => {
    if (!receptionForm.supplier || !receptionForm.quantity) return;
    const newBatch = {
      id: batches.length + 1,
      batchNo: `RCV-2024-${String(batches.length + 1).padStart(3, '0')}`,
      supplier: receptionForm.supplier,
      product: receptionForm.product,
      quantity: Number(receptionForm.quantity),
      moisture: Number(receptionForm.moisture) || 0,
      purity: Number(receptionForm.purity) || 0,
      status: 'قيد الفحص',
      date: new Date().toISOString().split('T')[0],
      truck: receptionForm.truck || '-',
      driver: receptionForm.driver || '-',
      notes: receptionForm.notes || '',
    };
    setBatches([newBatch, ...batches]);
    setReceptionForm({ supplier: '', product: 'fava', quantity: '', moisture: '', purity: '', driver: '', truck: '', notes: '' });
    setShowReceptionModal(false);
  };

  const handleAddPackaging = () => {
    if (!packagingForm.customer || !packagingForm.qty) return;
    const newPkg = {
      id: packages.length + 1,
      orderNo: `PKG-2024-${String(packages.length + 1).padStart(3, '0')}`,
      product: packagingForm.product,
      grade: packagingForm.grade,
      packageType: packagingForm.packageType,
      qty: Number(packagingForm.qty),
      status: 'مجدولة',
      customer: packagingForm.customer,
    };
    setPackages([newPkg, ...packages]);
    setPackagingForm({ customer: '', product: 'fava', grade: 'excellent', packageType: '50kg', qty: '' });
    setShowPackagingModal(false);
  };

  const handleDeleteBatch = (id: number) => {
    if (confirm('هل أنت متأكد من حذف الدفعة؟')) {
      setBatches(batches.filter(b => b.id !== id));
    }
  };

  const receptionColumns = [
    { key: 'batchNo', header: 'رقم الدفعة', sortable: true },
    { key: 'supplier', header: 'المورد', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true, render: (row: any) => <span className="font-medium">{productLabels[row.product] || row.product}</span> },
    { key: 'quantity', header: 'الكمية (كجم)', sortable: true, render: (row: any) => <span className="font-semibold">{row.quantity.toLocaleString()}</span> },
    { key: 'moisture', header: 'رطوبة %', sortable: true, render: (row: any) => (
      <span className={row.moisture > 13 ? 'text-red-600 font-semibold' : 'text-green-600 font-semibold'}>{row.moisture}%</span>
    )},
    { key: 'purity', header: 'نقاء %', sortable: true, render: (row: any) => <span className="font-medium">{row.purity}%</span> },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <StatusBadge status={row.status} /> },
    { key: 'date', header: 'التاريخ', sortable: true },
  ];

  const packagingColumns = [
    { key: 'orderNo', header: 'رقم الطلب', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true, render: (row: any) => <span className="font-medium">{productLabels[row.product] || row.product}</span> },
    { key: 'grade', header: 'الدرجة', sortable: true, render: (row: any) => <GradeBadge grade={row.grade} /> },
    { key: 'packageType', header: 'التعبئة', sortable: true, render: (row: any) => <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-xs font-medium">{row.packageType}</span> },
    { key: 'qty', header: 'الكمية', sortable: true, render: (row: any) => <span className="font-semibold">{row.qty}</span> },
    { key: 'customer', header: 'العميل', sortable: true },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <StatusBadge status={row.status} /> },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="البقوليات"
        subtitle="استلام ومعالجة وتعبئة البقوليات"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'البقوليات' }]}
      >
        <button
          onClick={() => { setActiveTab('reception'); setShowReceptionModal(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all"
        >
          <Plus size={18} /> استلام دفعة
        </button>
        <button
          onClick={() => { setActiveTab('packaging'); setShowPackagingModal(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-uiBorder dark:border-darkBorder dark:bg-darkSurface text-textPrimary dark:text-darkText rounded-xl text-sm font-semibold hover:bg-surface dark:hover:bg-darkCard transition-all"
        >
          <Package size={18} /> أمر تعبئة
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="دفعات اليوم" value={String(todayBatches)} icon={Truck} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-600" change={1} delay={0} />
        <KPICard title="كمية مستلمة (كجم)" value={receivedQty.toLocaleString()} icon={Scale} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-600" change={5.2} delay={0.1} />
        <KPICard title="كمية مفرزة" value={sortedQty.toLocaleString()} icon={Filter} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-600" change={3.8} delay={0.2} />
        <KPICard title="كمية معبأة" value={packedQty.toLocaleString()} icon={Package} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-600" change={2.1} delay={0.3} />
      </div>

      {/* Processing Pipeline */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-2 flex items-center gap-2">
          <Factory size={18} className="text-[#0d6b43]" /> خطوط المعالجة
        </h3>
        <ProcessingPipeline />
      </motion.div>

      {/* Grades Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <TrendingUp size={18} className="text-[#0d6b43]" /> توزيع الدرجات (%)
        </h3>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={gradeDistribution}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="grade" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip />
            <Bar dataKey="fava" name="فول" fill="#0d6b43" radius={[4, 4, 0, 0]} />
            <Bar dataKey="lentil" name="عدس" fill="#daa520" radius={[4, 4, 0, 0]} />
            <Bar dataKey="chickpea" name="حمص" fill="#2d8a5e" radius={[4, 4, 0, 0]} />
            <Bar dataKey="lupine" name="لوبيا" fill="#e5a220" radius={[4, 4, 0, 0]} />
            <Legend />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Tabs */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-3 border-b border-uiBorder dark:border-darkBorder flex items-center gap-1 overflow-x-auto">
          {[
            { key: 'reception', label: 'الاستلام', icon: Truck },
            { key: 'packaging', label: 'التعبئة', icon: Package },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab.key
                    ? 'bg-[#0a4a30] text-white'
                    : 'text-textSecondary hover:bg-surface dark:hover:bg-darkCard'
                }`}
              >
                <Icon size={16} /> {tab.label}
              </button>
            );
          })}
        </div>

        {/* Reception Tab */}
        {activeTab === 'reception' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Truck size={18} className="text-[#0d6b43]" /> دفعات الاستلام
              </h3>
              <div className="flex items-center gap-2 flex-wrap">
                <div className="relative">
                  <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                  <input
                    type="text" placeholder="بحث..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-48 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
                  />
                </div>
                <select
                  value={filterProduct}
                  onChange={(e) => setFilterProduct(e.target.value)}
                  className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                >
                  <option value="الكل">جميع المنتجات</option>
                  <option value="fava">فول</option>
                  <option value="lentil">عدس</option>
                  <option value="chickpea">حمص</option>
                  <option value="lupine">لوبيا</option>
                </select>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                >
                  <option value="الكل">جميع الحالات</option>
                  <option value="مستلم">مستلم</option>
                  <option value="قيد الفحص">قيد الفحص</option>
                  <option value="مرفوض">مرفوض</option>
                </select>
              </div>
            </div>
            <DataTable
              columns={receptionColumns}
              data={filteredBatches}
              pageSize={8}
              searchable={false}
              rowActions={{
                onView: (row) => setShowDetailBatch(row),
                onDelete: (row) => handleDeleteBatch(row.id),
              }}
              emptyMessage="لا توجد دفعات استلام"
            />
          </div>
        )}

        {/* Packaging Tab */}
        {activeTab === 'packaging' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Package size={18} className="text-[#0d6b43]" /> أوامر التعبئة
              </h3>
            </div>
            <DataTable
              columns={packagingColumns}
              data={packages}
              pageSize={8}
              rowActions={{
                onDelete: (row) => { if (confirm('حذف أمر التعبئة؟')) setPackages(packages.filter(p => p.id !== row.id)); },
              }}
              emptyMessage="لا توجد أوامر تعبئة"
            />
          </div>
        )}
      </div>

      {/* Reception Modal */}
      <AnimatePresence>
        {showReceptionModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowReceptionModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">استلام دفعة جديدة</h3>
                <button onClick={() => setShowReceptionModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المورد</label>
                    <input
                      type="text" placeholder="اسم المورد"
                      value={receptionForm.supplier}
                      onChange={(e) => setReceptionForm({ ...receptionForm, supplier: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                    <select
                      value={receptionForm.product}
                      onChange={(e) => setReceptionForm({ ...receptionForm, product: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="fava">فول</option>
                      <option value="lentil">عدس</option>
                      <option value="chickpea">حمص</option>
                      <option value="lupine">لوبيا</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الكمية (كجم)</label>
                    <input
                      type="number" placeholder="0"
                      value={receptionForm.quantity}
                      onChange={(e) => setReceptionForm({ ...receptionForm, quantity: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">رطوبة %</label>
                    <input
                      type="number" step="0.1"
                      value={receptionForm.moisture}
                      onChange={(e) => setReceptionForm({ ...receptionForm, moisture: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">نقاء %</label>
                    <input
                      type="number"
                      value={receptionForm.purity}
                      onChange={(e) => setReceptionForm({ ...receptionForm, purity: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">السائق</label>
                    <input
                      type="text" placeholder="اسم السائق"
                      value={receptionForm.driver}
                      onChange={(e) => setReceptionForm({ ...receptionForm, driver: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">رقم السيارة</label>
                    <input
                      type="text" placeholder="TRK-XXX"
                      value={receptionForm.truck}
                      onChange={(e) => setReceptionForm({ ...receptionForm, truck: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">ملاحظات</label>
                  <textarea
                    placeholder="أي ملاحظات إضافية..."
                    value={receptionForm.notes}
                    onChange={(e) => setReceptionForm({ ...receptionForm, notes: e.target.value })}
                    className="w-full h-20 px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 resize-none"
                  />
                </div>
                <button
                  onClick={handleAddReception}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ الدفعة
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Packaging Modal */}
      <AnimatePresence>
        {showPackagingModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowPackagingModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">أمر تعبئة جديد</h3>
                <button onClick={() => setShowPackagingModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">العميل</label>
                  <input
                    type="text" placeholder="اسم العميل"
                    value={packagingForm.customer}
                    onChange={(e) => setPackagingForm({ ...packagingForm, customer: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                    <select
                      value={packagingForm.product}
                      onChange={(e) => setPackagingForm({ ...packagingForm, product: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="fava">فول</option>
                      <option value="lentil">عدس</option>
                      <option value="chickpea">حمص</option>
                      <option value="lupine">لوبيا</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الدرجة</label>
                    <select
                      value={packagingForm.grade}
                      onChange={(e) => setPackagingForm({ ...packagingForm, grade: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="excellent">ممتاز (كامل)</option>
                      <option value="first">أولى (كسر {'<'}5%)</option>
                      <option value="second">ثانية (كسر 5-15%)</option>
                      <option value="waste">هدر ({'>'}15%)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">التعبئة</label>
                    <select
                      value={packagingForm.packageType}
                      onChange={(e) => setPackagingForm({ ...packagingForm, packageType: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="25kg">25 كجم</option>
                      <option value="50kg">50 كجم</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الكمية (شوال)</label>
                  <input
                    type="number" placeholder="0"
                    value={packagingForm.qty}
                    onChange={(e) => setPackagingForm({ ...packagingForm, qty: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <button
                  onClick={handleAddPackaging}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  إنشاء أمر التعبئة
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailBatch && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailBatch(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-md"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تفاصيل الدفعة</h3>
                <button onClick={() => setShowDetailBatch(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-3">
                {[
                  { label: 'رقم الدفعة', value: showDetailBatch.batchNo },
                  { label: 'المورد', value: showDetailBatch.supplier },
                  { label: 'المنتج', value: productLabels[showDetailBatch.product] || showDetailBatch.product },
                  { label: 'الكمية', value: `${showDetailBatch.quantity.toLocaleString()} كجم` },
                  { label: 'السائق', value: showDetailBatch.driver },
                  { label: 'رقم السيارة', value: showDetailBatch.truck },
                  { label: 'التاريخ', value: showDetailBatch.date },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-textSecondary text-sm">{item.label}</span>
                    <span className="font-semibold text-textPrimary">{item.value}</span>
                  </div>
                ))}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-lg bg-surface dark:bg-darkCard border border-uiBorder/50 text-center">
                    <p className="text-xs text-textSecondary">الرطوبة</p>
                    <p className={`text-lg font-bold ${showDetailBatch.moisture > 13 ? 'text-red-600' : 'text-green-600'}`}>{showDetailBatch.moisture}%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-surface dark:bg-darkCard border border-uiBorder/50 text-center">
                    <p className="text-xs text-textSecondary">النقاء</p>
                    <p className="text-lg font-bold text-blue-600">{showDetailBatch.purity}%</p>
                  </div>
                </div>
                {showDetailBatch.notes && (
                  <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
                    <p className="text-xs text-amber-700 dark:text-amber-400 font-medium">ملاحظات: {showDetailBatch.notes}</p>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
