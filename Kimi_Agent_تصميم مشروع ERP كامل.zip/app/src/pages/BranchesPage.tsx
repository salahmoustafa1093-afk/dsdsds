// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2,
  MapPin,
  Users,
  Warehouse,
  TrendingUp,
  Plus,
  X,
  Eye,
  Edit3,
  Trash2,
  Search,
  Target,
  Phone,
  Mail,
  UserCircle,
  Package,
  ArrowUpRight,
  ArrowDownRight,
  Store,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
interface BranchEmployee {
  id: number;
  name: string;
  role: string;
  phone: string;
}

interface BranchTransfer {
  id: number;
  date: string;
  from: string;
  to: string;
  product: string;
  qty: number;
  status: 'مكتملة' | 'قيد النقل';
}

interface Branch {
  id: number;
  code: string;
  name: string;
  city: string;
  address: string;
  manager: string;
  managerPhone: string;
  employees: number;
  employeeList: BranchEmployee[];
  warehouses: number;
  warehouseNames: string[];
  revenue: number;
  target: number;
  status: 'نشطة' | 'مغلقة';
  color: string;
  zone: string;
  monthlySales: number[];
  transfers: BranchTransfer[];
}

/* ------------------------------------------------------------------ */
/*  MOCK DATA                                                          */
/* ------------------------------------------------------------------ */
const mockBranches: Branch[] = [
  {
    id: 1, code: 'BR-001', name: 'فرع القاهرة', city: 'القاهرة', address: 'طريق مصر إسماعيلية الصحراوي، المنطقة الصناعية', manager: 'محمد أحمد', managerPhone: '01001112233', employees: 45, employeeList: [
      { id: 1, name: 'محمد أحمد', role: 'مدير الفرع', phone: '01001112233' },
      { id: 2, name: 'أحمد محمود', role: 'محاسب', phone: '01002223344' },
      { id: 3, name: 'علي حسن', role: 'مشرف مبيعات', phone: '01003334455' },
      { id: 4, name: 'خالد سعيد', role: 'مستودع', phone: '01004445566' },
      { id: 5, name: 'سامي إبراهيم', role: 'سائق', phone: '01005556677' },
    ], warehouses: 3, warehouseNames: ['مستودع الأعلاف', 'مستودع الأدوية', 'مستودع التعبئة'], revenue: 4250000, target: 5000000, status: 'نشطة', color: '#14a86a', zone: 'المنطقة الوسطى', monthlySales: [320, 350, 380, 410, 390, 420, 450, 480, 460, 500, 520, 550],
    transfers: [
      { id: 1, date: '2024-01-15', from: 'القاهرة', to: 'الإسكندرية', product: 'بيض طازج', qty: 500, status: 'مكتملة' },
      { id: 2, date: '2024-01-12', from: 'القاهرة', to: 'طنطا', product: 'أعلاف', qty: 200, status: 'مكتملة' },
    ],
  },
  {
    id: 2, code: 'BR-002', name: 'فرع الإسكندرية', city: 'الإسكندرية', address: 'المنطقة الصناعية برج العرب', manager: 'خالد محمود', managerPhone: '01006667788', employees: 28, employeeList: [
      { id: 6, name: 'خالد محمود', role: 'مدير الفرع', phone: '01006667788' },
      { id: 7, name: 'محمد علي', role: 'محاسب', phone: '01007778899' },
      { id: 8, name: 'حسن عبدالله', role: 'مشرف إنتاج', phone: '01008889900' },
    ], warehouses: 2, warehouseNames: ['مستودع رئيسي', 'مستودع بارد'], revenue: 2800000, target: 3500000, status: 'نشطة', color: '#3b82f6', zone: 'المنطقة الساحلية', monthlySales: [200, 220, 240, 260, 250, 280, 300, 320, 310, 340, 360, 380],
    transfers: [
      { id: 3, date: '2024-01-14', from: 'الإسكندرية', to: 'المنصورة', product: 'بيض طازج', qty: 300, status: 'قيد النقل' },
    ],
  },
  {
    id: 3, code: 'BR-003', name: 'فرع طنطا', city: 'طنطا', address: 'المنطقة الصناعية طنطا', manager: 'سمير حسن', managerPhone: '01009990011', employees: 18, employeeList: [
      { id: 9, name: 'سمير حسن', role: 'مدير الفرع', phone: '01009990011' },
      { id: 10, name: 'عادل فؤاد', role: 'محاسب', phone: '01010001122' },
      { id: 11, name: 'وائل محمود', role: 'مبيعات', phone: '01011112233' },
    ], warehouses: 2, warehouseNames: ['مستودع رئيسي', 'مستودع كتكوت'], revenue: 1650000, target: 2000000, status: 'نشطة', color: '#daa520', zone: 'المنطقة الغربية', monthlySales: [120, 130, 140, 150, 145, 160, 170, 180, 175, 190, 200, 210],
    transfers: [
      { id: 4, date: '2024-01-10', from: 'طنطا', to: 'القاهرة', product: 'كتكوت', qty: 10000, status: 'مكتملة' },
    ],
  },
  {
    id: 4, code: 'BR-004', name: 'فرع المنصورة', city: 'المنصورة', address: 'المنطقة الصناعية المنصورة', manager: 'طارق عبدالرحمن', managerPhone: '01012223344', employees: 22, employeeList: [
      { id: 12, name: 'طارق عبدالرحمن', role: 'مدير الفرع', phone: '01012223344' },
      { id: 13, name: 'إبراهيم سمير', role: 'محاسب', phone: '01013334455' },
      { id: 14, name: 'محمود كمال', role: 'مشرف مستودع', phone: '01014445566' },
    ], warehouses: 1, warehouseNames: ['مستودع رئيسي'], revenue: 1950000, target: 2500000, status: 'نشطة', color: '#8b5cf6', zone: 'المنطقة الدلتا', monthlySales: [140, 155, 165, 175, 170, 185, 195, 210, 200, 220, 235, 250],
    transfers: [
      { id: 5, date: '2024-01-08', from: 'المنصورة', to: 'القاهرة', product: 'أدوية بيطرية', qty: 50, status: 'مكتملة' },
    ],
  },
];

/* ------------------------------------------------------------------ */
/*  STATUS BADGE                                                       */
/* ------------------------------------------------------------------ */
function StatusBadge({ status }: { status: string }) {
  return status === 'نشطة' ? (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 border border-green-300">
      <CheckCircle2 size={12} /> نشطة
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 border border-gray-300">
      <XCircle size={12} /> مغلقة
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function BranchesPage() {
  const [branches, setBranches] = useState<Branch[]>(mockBranches);
  const [searchQuery, setSearchQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);
  const [viewingBranch, setViewingBranch] = useState<Branch | null>(null);
  const [form, setForm] = useState<Partial<Branch>>({});

  /* ── KPIs ── */
  const totalBranches = branches.length;
  const activeBranches = branches.filter((b) => b.status === 'نشطة').length;
  const totalEmployees = branches.reduce((s, b) => s + b.employees, 0);
  const totalRevenue = branches.reduce((s, b) => s + b.revenue, 0);

  /* ── Filtered data ── */
  const filteredData = branches.filter(
    (b) =>
      !searchQuery ||
      b.name.includes(searchQuery) ||
      b.city.includes(searchQuery) ||
      b.code.toLowerCase().includes(searchQuery)
  );

  /* ── Form helpers ── */
  const openAdd = () => {
    setEditingBranch(null);
    setForm({ status: 'نشطة', color: '#14a86a', revenue: 0, target: 0, employees: 0, warehouses: 1 });
    setModalOpen(true);
  };

  const openEdit = (b: Branch) => {
    setEditingBranch(b);
    setForm({ ...b });
    setModalOpen(true);
  };

  const openDetail = (b: Branch) => {
    setViewingBranch(b);
    setDetailOpen(true);
  };

  const saveBranch = () => {
    if (!form.name || !form.city) return;
    if (editingBranch) {
      setBranches((prev) =>
        prev.map((b) => (b.id === editingBranch.id ? { ...b, ...form } as Branch : b))
      );
    } else {
      const newId = Math.max(...branches.map((b) => b.id)) + 1;
      setBranches((prev) => [
        ...prev,
        {
          ...form,
          id: newId,
          code: `BR-${String(newId).padStart(3, '0')}`,
          employeeList: [],
          warehouseNames: [],
          monthlySales: [],
          transfers: [],
        } as Branch,
      ]);
    }
    setModalOpen(false);
  };

  const deleteBranch = (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا الفرع؟')) {
      setBranches((prev) => prev.filter((b) => b.id !== id));
    }
  };

  /* ── Table columns ── */
  const columns = [
    { key: 'code', header: 'الكود', sortable: true, width: '80px' },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'city', header: 'المدينة', sortable: true, width: '90px' },
    { key: 'manager', header: 'المدير', sortable: true, width: '110px' },
    { key: 'employees', header: 'الموظفين', sortable: true, width: '80px' },
    { key: 'warehouses', header: 'المستودعات', sortable: true, width: '80px' },
    {
      key: 'revenue',
      header: 'الإيرادات',
      sortable: true,
      width: '110px',
      render: (row: Branch) => row.revenue.toLocaleString('ar-EG'),
    },
    {
      key: 'status',
      header: 'الحالة',
      width: '80px',
      render: (row: Branch) => <StatusBadge status={row.status} />,
    },
  ];

  return (
    <div className="gff-page-transition space-y-6">
      <PageHeader
        title="إدارة الفروع"
        subtitle="إدارة الفروع والموظفين والمستودعات والمبيعات"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الفروع' }]}
      >
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors shadow-sm"
        >
          <Plus size={16} /> فرع جديد
        </button>
      </PageHeader>

      {/* ── KPIs ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي الفروع" value={totalBranches.toLocaleString('ar-EG')} icon={Building2} iconBg="bg-blue-50" iconColor="text-blue-600" delay={0} />
        <KPICard title="نشطة" value={activeBranches.toLocaleString('ar-EG')} icon={CheckCircle2} iconBg="bg-green-50" iconColor="text-green-600" delay={0.05} />
        <KPICard title="الموظفين" value={totalEmployees.toLocaleString('ar-EG')} icon={Users} iconBg="bg-amber-50" iconColor="text-amber-600" delay={0.1} />
        <KPICard title="إجمالي الإيرادات" value={`${totalRevenue.toLocaleString('ar-EG')} ج.م`} icon={TrendingUp} iconBg="bg-purple-50" iconColor="text-purple-600" change={8} changeLabel="عن العام السابق" delay={0.15} />
      </div>

      {/* ── Branch Cards ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4"
      >
        {filteredData.map((branch, idx) => {
          const progress = Math.min(100, (branch.revenue / branch.target) * 100);
          return (
            <motion.div
              key={branch.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: idx * 0.05 }}
              onClick={() => openDetail(branch)}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5 cursor-pointer hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg"
                    style={{ backgroundColor: branch.color }}
                  >
                    {branch.name.charAt(branch.name.length - 1)}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText">{branch.name}</h3>
                    <p className="text-[11px] text-textMuted">{branch.zone}</p>
                  </div>
                </div>
                <StatusBadge status={branch.status} />
              </div>

              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="text-center">
                  <Users size={16} className="mx-auto mb-1 text-textMuted" />
                  <p className="text-sm font-bold text-textPrimary dark:text-darkText">{branch.employees}</p>
                  <p className="text-[10px] text-textMuted">موظف</p>
                </div>
                <div className="text-center">
                  <Warehouse size={16} className="mx-auto mb-1 text-textMuted" />
                  <p className="text-sm font-bold text-textPrimary dark:text-darkText">{branch.warehouses}</p>
                  <p className="text-[10px] text-textMuted">مستودع</p>
                </div>
                <div className="text-center">
                  <TrendingUp size={16} className="mx-auto mb-1 text-textMuted" />
                  <p className="text-sm font-bold text-textPrimary dark:text-darkText">{(branch.revenue / 1000000).toFixed(1)}M</p>
                  <p className="text-[10px] text-textMuted">إيرادات</p>
                </div>
              </div>

              {/* Target Progress */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] text-textSecondary">التقدم نحو الهدف</span>
                  <span className="text-[11px] font-semibold" style={{ color: branch.color }}>{Math.round(progress)}%</span>
                </div>
                <div className="w-full h-2 bg-gray-200 dark:bg-darkBorder rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.5, delay: idx * 0.1 }}
                    className="h-full rounded-full"
                    style={{ backgroundColor: branch.color }}
                  />
                </div>
                <p className="text-[10px] text-textMuted mt-1">{branch.revenue.toLocaleString('ar-EG')} / {branch.target.toLocaleString('ar-EG')}</p>
              </div>

              <div className="mt-3 pt-3 border-t border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <span className="text-[11px] text-textMuted flex items-center gap-1">
                  <UserCircle size={12} /> {branch.manager}
                </span>
                <button
                  onClick={(e) => { e.stopPropagation(); openEdit(branch); }}
                  className="text-[11px] text-green-700 hover:text-green-800 font-medium"
                >
                  تعديل
                </button>
              </div>
            </motion.div>
          );
        })}
      </motion.div>

      {/* ── Table ── */}
      <DataTable
        columns={columns}
        data={filteredData}
        pageSize={10}
        title={`الفروع (${filteredData.length})`}
        rowActions={{
          onView: openDetail,
          onEdit: openEdit,
          onDelete: (row) => deleteBranch(row.id),
        }}
      />

      {/* ═══════════════════ ADD/EDIT MODAL ═══════════════════ */}
      <AnimatePresence>
        {modalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">
                  {editingBranch ? 'تعديل فرع' : 'فرع جديد'}
                </h3>
                <button onClick={() => setModalOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الكود</label>
                  <input value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" dir="ltr" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">اسم الفرع *</label>
                  <input value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">المدينة</label>
                  <input value={form.city || ''} onChange={(e) => setForm({ ...form, city: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">المنطقة</label>
                  <input value={form.zone || ''} onChange={(e) => setForm({ ...form, zone: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">العنوان</label>
                  <input value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">المدير</label>
                  <input value={form.manager || ''} onChange={(e) => setForm({ ...form, manager: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">هاتف المدير</label>
                  <input value={form.managerPhone || ''} onChange={(e) => setForm({ ...form, managerPhone: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" dir="ltr" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">عدد الموظفين</label>
                  <input type="number" value={form.employees || 0} onChange={(e) => setForm({ ...form, employees: +e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">عدد المستودعات</label>
                  <input type="number" value={form.warehouses || 1} onChange={(e) => setForm({ ...form, warehouses: +e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الإيرادات</label>
                  <input type="number" value={form.revenue || 0} onChange={(e) => setForm({ ...form, revenue: +e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الهدف</label>
                  <input type="number" value={form.target || 0} onChange={(e) => setForm({ ...form, target: +e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">اللون</label>
                  <input type="color" value={form.color || '#14a86a'} onChange={(e) => setForm({ ...form, color: e.target.value })} className="w-full h-10 rounded-lg border border-uiBorder dark:border-darkBorder" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الحالة</label>
                  <select value={form.status || ''} onChange={(e) => setForm({ ...form, status: e.target.value as any })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
                    <option value="نشطة">نشطة</option>
                    <option value="مغلقة">مغلقة</option>
                  </select>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-uiBorder dark:border-darkBorder">
                <button onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm transition-colors">إلغاء</button>
                <button onClick={saveBranch} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">حفظ</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════════════ DETAIL MODAL ═══════════════════ */}
      <AnimatePresence>
        {detailOpen && viewingBranch && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg"
                    style={{ backgroundColor: viewingBranch.color }}
                  >
                    {viewingBranch.name.charAt(viewingBranch.name.length - 1)}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{viewingBranch.name}</h3>
                    <p className="text-xs text-textMuted">{viewingBranch.code} · {viewingBranch.zone}</p>
                  </div>
                </div>
                <button onClick={() => setDetailOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Info Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">المدينة</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingBranch.city}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">المدير</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingBranch.manager}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الموظفين</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingBranch.employees}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">المستودعات</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingBranch.warehouses}</p>
                  </div>
                </div>

                {/* Financial Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="rounded-lg p-4 border" style={{ backgroundColor: `${viewingBranch.color}15`, borderColor: `${viewingBranch.color}40` }}>
                    <p className="text-xs mb-1" style={{ color: viewingBranch.color }}>الإيرادات الفعلية</p>
                    <p className="text-xl font-bold text-textPrimary dark:text-darkText">{viewingBranch.revenue.toLocaleString('ar-EG')} ج.م</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-4 border border-uiBorder dark:border-darkBorder">
                    <p className="text-xs text-textMuted mb-1">الهدف السنوي</p>
                    <p className="text-xl font-bold text-textPrimary dark:text-darkText">{viewingBranch.target.toLocaleString('ar-EG')} ج.م</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-4 border border-uiBorder dark:border-darkBorder">
                    <p className="text-xs text-textMuted mb-1">نسبة الإنجاز</p>
                    <p className="text-xl font-bold" style={{ color: viewingBranch.color }}>{Math.round((viewingBranch.revenue / viewingBranch.target) * 100)}%</p>
                  </div>
                </div>

                {/* Target Progress */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-textSecondary">التقدم نحو الهدف</span>
                    <span className="text-sm font-semibold" style={{ color: viewingBranch.color }}>{Math.round((viewingBranch.revenue / viewingBranch.target) * 100)}%</span>
                  </div>
                  <div className="w-full h-3 bg-gray-200 dark:bg-darkBorder rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, (viewingBranch.revenue / viewingBranch.target) * 100)}%` }}
                      transition={{ duration: 0.5 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: viewingBranch.color }}
                    />
                  </div>
                </div>

                {/* Monthly Sales Chart */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">المبيعات الشهرية (آلاف ج.م)</h4>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-4 border border-uiBorder dark:border-darkBorder">
                    <div className="flex items-end gap-2 h-32">
                      {viewingBranch.monthlySales.map((val, i) => {
                        const maxVal = Math.max(...viewingBranch.monthlySales);
                        const height = (val / maxVal) * 100;
                        const months = ['ينا', 'فبر', 'مار', 'أبر', 'ماي', 'يون', 'يول', 'أغس', 'سبت', 'أكت', 'نوف', 'ديس'];
                        return (
                          <div key={i} className="flex-1 flex flex-col items-center gap-1">
                            <motion.div
                              initial={{ height: 0 }}
                              animate={{ height: `${height}%` }}
                              transition={{ duration: 0.3, delay: i * 0.03 }}
                              className="w-full rounded-t"
                              style={{ backgroundColor: viewingBranch.color, opacity: 0.7 + (i / viewingBranch.monthlySales.length) * 0.3 }}
                            />
                            <span className="text-[9px] text-textMuted">{months[i]}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Employees */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">الموظفون</h4>
                  <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الاسم</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الدور</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الهاتف</th>
                        </tr>
                      </thead>
                      <tbody>
                        {viewingBranch.employeeList.map((emp) => (
                          <tr key={emp.id} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{emp.name}</td>
                            <td className="px-3 py-2 text-textSecondary">{emp.role}</td>
                            <td className="px-3 py-2 text-textSecondary">{emp.phone}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Transfers */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">التحويلات</h4>
                  <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">من</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">إلى</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">المنتج</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الكمية</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الحالة</th>
                        </tr>
                      </thead>
                      <tbody>
                        {viewingBranch.transfers.map((t) => (
                          <tr key={t.id} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{t.date}</td>
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{t.from}</td>
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{t.to}</td>
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{t.product}</td>
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{t.qty.toLocaleString('ar-EG')}</td>
                            <td className="px-3 py-2">
                              <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${t.status === 'مكتملة' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{t.status}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
