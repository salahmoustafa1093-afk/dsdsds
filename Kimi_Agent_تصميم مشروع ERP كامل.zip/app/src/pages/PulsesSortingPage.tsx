// @ts-nocheck
import { useState } from 'react';
import {
  ArrowRight, Gem, Award, PackageOpen, Trash2, TrendingUp, Settings2, Filter,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer,
} from 'recharts';

/* ─── Types ─────────────────────────────────────────── */
interface SortingRecord {
  id: number;
  batch: string;
  product: string;
  inputQty: number;
  gradeA: number;
  gradeB: number;
  gradeC: number;
  waste: number;
  operator: string;
  status: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const sortingData: SortingRecord[] = [
  { id: 1, batch: 'FB-001', product: 'فول', inputQty: 45, gradeA: 38, gradeB: 4, gradeC: 1.5, waste: 1.5, operator: 'محمد علي', status: 'مكتمل' },
  { id: 2, batch: 'FB-002', product: 'عدس أصفر', inputQty: 60, gradeA: 52, gradeB: 5, gradeC: 1.8, waste: 1.2, operator: 'أحمد محمود', status: 'مكتمل' },
  { id: 3, batch: 'FB-003', product: 'حمص', inputQty: 35, gradeA: 29, gradeB: 3.5, gradeC: 1.2, waste: 1.3, operator: 'خالد سعيد', status: 'قيد الفرز' },
  { id: 4, batch: 'FB-004', product: 'لوبيا', inputQty: 25, gradeA: 20, gradeB: 3, gradeC: 0.8, waste: 1.2, operator: 'محمد علي', status: 'مكتمل' },
  { id: 5, batch: 'FB-005', product: 'فول', inputQty: 50, gradeA: 43, gradeB: 4.5, gradeC: 1.0, waste: 1.5, operator: 'أحمد محمود', status: 'قيد التنظيف' },
  { id: 6, batch: 'FB-006', product: 'عدس أخضر', inputQty: 40, gradeA: 34, gradeB: 3.5, gradeC: 1.2, waste: 1.3, operator: 'خالد سعيد', status: 'قيد الفرز' },
  { id: 7, batch: 'FB-007', product: 'حمص', inputQty: 30, gradeA: 26, gradeB: 2.5, gradeC: 0.7, waste: 0.8, operator: 'محمد علي', status: 'مكتمل' },
  { id: 8, batch: 'FB-008', product: 'فول', inputQty: 55, gradeA: 47, gradeB: 5, gradeC: 1.5, waste: 1.5, operator: 'أحمد محمود', status: 'قيد التصنيف' },
];

const wasteAnalysisData = [
  { product: 'فول', waste: 1.5 },
  { product: 'عدس', waste: 1.2 },
  { product: 'حمص', waste: 1.0 },
  { product: 'لوبيا', waste: 1.2 },
  { product: 'عدس أخضر', waste: 1.3 },
];

const workflowSteps = ['استلام', 'تنظيف', 'فرز', 'تصنيف', 'تعبئة'];

/* ─── Page ──────────────────────────────────────────── */
export default function PulsesSortingPage() {
  const [filter, setFilter] = useState('all');
  const [selectedRecord, setSelectedRecord] = useState<SortingRecord | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const todayQty = sortingData.reduce((s, r) => s + r.inputQty, 0);
  const gradeAQty = sortingData.reduce((s, r) => s + r.gradeA, 0);
  const gradeBQty = sortingData.reduce((s, r) => s + r.gradeB, 0);
  const avgWaste = (sortingData.reduce((s, r) => s + r.waste, 0) / sortingData.length).toFixed(1);

  const filteredData = filter === 'all' ? sortingData : sortingData.filter(s => s.status.includes(filter === 'completed' ? 'مكتمل' : filter === 'inprogress' ? 'قيد' : ''));

  const columns = [
    { key: 'batch', header: 'رقم الدفعة', sortable: true, width: '100px' },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'inputQty', header: 'كمية الداخل', sortable: true, width: '90px', render: (row: Record<string, unknown>) => <span>{row.inputQty} طن</span> },
    {
      key: 'gradeA',
      header: 'ممتاز',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => <span className="inline-flex items-center gap-1 text-green-600 font-medium"><Gem size={12} /> {row.gradeA} طن</span>,
    },
    {
      key: 'gradeB',
      header: 'أولى',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => <span className="inline-flex items-center gap-1 text-blue-600 font-medium"><Award size={12} /> {row.gradeB} طن</span>,
    },
    {
      key: 'gradeC',
      header: 'ثانية',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => <span className="inline-flex items-center gap-1 text-amber-600 font-medium"><PackageOpen size={12} /> {row.gradeC} طن</span>,
    },
    {
      key: 'waste',
      header: 'هدر %',
      sortable: true,
      width: '70px',
      render: (row: Record<string, unknown>) => <span className={`${(row.waste as number) > 2 ? 'text-red-600 font-bold' : 'text-red-400'}`}>{row.waste}%</span>,
    },
    { key: 'operator', header: 'المشغل', sortable: true },
    { key: 'status', header: 'الحالة', render: (row: Record<string, unknown>) => <Badge variant={row.status === 'مكتمل' ? 'default' : 'secondary'}>{row.status as string}</Badge> },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="الفرز والتصنيف" subtitle="فرز وتصنيف البقوليات حسب الجودة" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'البقوليات' }, { label: 'الفرز والتصنيف' }]} />

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="كميات اليوم" value={`${todayQty} طن`} icon={PackageOpen} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="فرز ممتاز" value={`${gradeAQty} طن`} change={+4.2} icon={Gem} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.1} />
        <KPICard title="فرز أولى" value={`${gradeBQty} طن`} change={+2.1} icon={Award} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.2} />
        <KPICard title="نسبة الهدر" value={`${avgWaste}%`} change={-0.3} icon={Trash2} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Workflow Visual */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
        <h3 className="text-sm font-semibold mb-4">سير العمل</h3>
        <div className="flex items-center justify-between gap-2 overflow-x-auto">
          {workflowSteps.map((step, i) => (
            <div key={step} className="flex items-center gap-2 flex-1 min-w-0">
              <div className="flex flex-col items-center gap-1 flex-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${i <= 3 ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-500 dark:bg-gray-700 dark:text-gray-400'}`}>
                  {i + 1}
                </div>
                <span className="text-xs font-medium whitespace-nowrap">{step}</span>
              </div>
              {i < workflowSteps.length - 1 && <ArrowRight size={16} className="text-gray-400 flex-shrink-0" />}
            </div>
          ))}
        </div>
      </div>

      {/* Grade Standards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-green-50 dark:bg-green-900/20 rounded-xl border border-green-200 dark:border-green-800 p-4">
          <div className="flex items-center gap-2 mb-2"><Gem size={16} className="text-green-600" /><h4 className="font-semibold text-sm">ممتاز (أ)</h4></div>
          <p className="text-xs text-gray-600 dark:text-gray-300">كامل، نظيف، كسر أقل من ٥%</p>
        </div>
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-200 dark:border-blue-800 p-4">
          <div className="flex items-center gap-2 mb-2"><Award size={16} className="text-blue-600" /><h4 className="font-semibold text-sm">أولى (ب)</h4></div>
          <p className="text-xs text-gray-600 dark:text-gray-300">كسر ٥-١٥%، لون جيد</p>
        </div>
        <div className="bg-amber-50 dark:bg-amber-900/20 rounded-xl border border-amber-200 dark:border-amber-800 p-4">
          <div className="flex items-center gap-2 mb-2"><PackageOpen size={16} className="text-amber-600" /><h4 className="font-semibold text-sm">ثانية (ج) / هدر</h4></div>
          <p className="text-xs text-gray-600 dark:text-gray-300">كسر أكثر من ١٥%</p>
        </div>
      </div>

      {/* Charts & Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <DataTable columns={columns} data={filteredData as unknown as Record<string, unknown>[]} title="سجلات الفرز" rowActions={{ onView: (row) => { setSelectedRecord(row as unknown as SortingRecord); setIsDetailOpen(true); }, onEdit: () => {}, onDelete: () => {} }} />
        </div>
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <h3 className="text-base font-semibold mb-4 text-gray-800 dark:text-gray-100 flex items-center gap-1"><Trash2 size={14} /> تحليل الهدر</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={wasteAnalysisData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="product" />
              <YAxis />
              <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
              <Bar dataKey="waste" name="نسبة الهدر %" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
