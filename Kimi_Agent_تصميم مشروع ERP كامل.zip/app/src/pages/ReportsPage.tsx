// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart3, TrendingUp, Package, ArrowLeftRight, Users, Truck,
  Factory, MapPin, Download, FileText, Calendar, Filter, Plus,
  Clock, CheckCircle2, Search, PieChart, LineChart,
  ClipboardList, DollarSign, AlertTriangle, XCircle,
  BarChart4, TrendingDown, Receipt, CreditCard, ShoppingCart,
  Egg, Bird, Fuel, Wrench, Layers, Activity, ChevronDown,
  Eye, Star, RefreshCw, Printer, Mail, Share2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

/* ─────────────────────── mock data ─────────────────────── */

const CATEGORIES = ['الكل', 'مالية', 'مبيعات', 'مخزون', 'إنتاج', 'عملاء'];

const REPORTS = [
  { id: 1, title: 'تقرير المبيعات اليومية', description: 'ملخص إجمالي المبيعات اليومية مع تحليل حسب المنتج والمنطقة والعميل وتفاصيل كل فاتورة', category: 'مبيعات', icon: BarChart3, lastGenerated: '2025-01-15 08:30', frequency: 'يومي', count: 42, color: '#0a4a30', bg: 'bg-emerald-50', iconColor: 'text-emerald-600' },
  { id: 2, title: 'تقرير الربح والخسارة', description: 'بيان الدخل الشامل مع تحليل الإيرادات والمصروفات والهوامش والأداء المالي للفترة', category: 'مالية', icon: TrendingUp, lastGenerated: '2025-01-14 18:00', frequency: 'شهري', count: 12, color: '#0d6b43', bg: 'bg-green-50', iconColor: 'text-green-600' },
  { id: 3, title: 'تقرير المخزون', description: 'حالة المخزون الحالية مع مستويات التنبيه والمنتجات المنخفضة واقتراحات الطلب', category: 'مخزون', icon: Package, lastGenerated: '2025-01-15 06:00', frequency: 'يومي', count: 38, color: '#2563eb', bg: 'bg-blue-50', iconColor: 'text-blue-600' },
  { id: 4, title: 'تقرير حركة المخزون', description: 'تفاصيل الإضافات والصادرات والتسويات للمخزون خلال الفترة مع أرصدة الافتتاح والختام', category: 'مخزون', icon: ArrowLeftRight, lastGenerated: '2025-01-14 22:00', frequency: 'أسبوعي', count: 18, color: '#7c3aed', bg: 'bg-purple-50', iconColor: 'text-purple-600' },
  { id: 5, title: 'تقرير العملاء', description: 'تحليل أداء العملاء مع حجم المشتريات والمدفوعات والآجل وتصنيف العملاء', category: 'عملاء', icon: Users, lastGenerated: '2025-01-13 14:30', frequency: 'شهري', count: 8, color: '#ea580c', bg: 'bg-orange-50', iconColor: 'text-orange-600' },
  { id: 6, title: 'تقرير الموردين', description: 'ملخص المشتريات من الموردين مع تقييم الأداء والالتزام بالمواعيد والجودة', category: 'عملاء', icon: Truck, lastGenerated: '2025-01-12 10:00', frequency: 'شهري', count: 6, color: '#0891b2', bg: 'bg-cyan-50', iconColor: 'text-cyan-600' },
  { id: 7, title: 'تقرير الإنتاج', description: 'إجمالي الإنتاج اليومي من بيض المائدة مع تحليل الجودة والهالك والكفاءة', category: 'إنتاج', icon: Factory, lastGenerated: '2025-01-15 07:00', frequency: 'يومي', count: 45, color: '#059669', bg: 'bg-teal-50', iconColor: 'text-teal-600' },
  { id: 8, title: 'تقرير التوصيلات', description: 'تحليل أداء التوصيل مع أوقات التسليم ومعدلات الرضا وأداء السائقين', category: 'مبيعات', icon: MapPin, lastGenerated: '2025-01-14 23:00', frequency: 'أسبوعي', count: 15, color: '#be185d', bg: 'bg-pink-50', iconColor: 'text-pink-600' },
  { id: 9, title: 'تقرير الكتاكيت', description: 'مبيعات وشراء الكتاكيت مع تحليل السلالات والموردين والأسعار التاريخية', category: 'إنتاج', icon: Bird, lastGenerated: '2025-01-13 09:00', frequency: 'أسبوعي', count: 10, color: '#854d0e', bg: 'bg-yellow-50', iconColor: 'text-yellow-600' },
  { id: 10, title: 'تقرير المصروفات', description: 'تفصيل المصروفات التشغيلية مع تصنيفاتها وتحليل الاتجاهات والمقارنات', category: 'مالية', icon: Receipt, lastGenerated: '2025-01-14 15:30', frequency: 'شهري', count: 22, color: '#dc2626', bg: 'bg-red-50', iconColor: 'text-red-600' },
  { id: 11, title: 'تقرير المركبات', description: 'أداء أسطول النقل مع تكاليف الوقود والصيانة وكفاءة كل مركبة', category: 'عملاء', icon: Fuel, lastGenerated: '2025-01-12 11:00', frequency: 'أسبوعي', count: 9, color: '#4338ca', bg: 'bg-indigo-50', iconColor: 'text-indigo-600' },
  { id: 12, title: 'تقرير جودة البيض', description: 'تحليل جودة إنتاج البيض حسب الدرجة ومؤشرات الالتزام ونسبة الهالك', category: 'إنتاج', icon: Egg, lastGenerated: '2025-01-15 08:00', frequency: 'يومي', count: 30, color: '#65a30d', bg: 'bg-lime-50', iconColor: 'text-lime-600' },
];

const RECENTLY_GENERATED = [
  { id: 1, title: 'تقرير المبيعات اليومية', date: '2025-01-15 08:30', status: 'جاهز', size: '1.2 MB', type: 'PDF' },
  { id: 2, title: 'تقرير المخزون', date: '2025-01-15 06:00', status: 'جاهز', size: '856 KB', type: 'PDF' },
  { id: 3, title: 'تقرير الإنتاج', date: '2025-01-15 07:00', status: 'جاهز', size: '2.1 MB', type: 'XLSX' },
  { id: 4, title: 'تقرير الربح والخسارة', date: '2025-01-14 18:00', status: 'جاهز', size: '1.8 MB', type: 'PDF' },
  { id: 5, title: 'تقرير حركة المخزون', date: '2025-01-14 22:00', status: 'جاهز', size: '1.4 MB', type: 'XLSX' },
  { id: 6, title: 'تقرير التوصيلات', date: '2025-01-14 23:00', status: 'جاهز', size: '3.2 MB', type: 'PDF' },
  { id: 7, title: 'تقرير العملاء', date: '2025-01-13 14:30', status: 'جاهز', size: '980 KB', type: 'PDF' },
  { id: 8, title: 'تقرير المصروفات', date: '2025-01-13 11:00', status: 'جاهز', size: '1.5 MB', type: 'XLSX' },
];

const SCHEDULED_REPORTS = [
  { id: 1, title: 'تقرير المبيعات اليومية', frequency: 'يومي', time: '08:00', nextRun: '2025-01-16 08:00', recipients: 'ahmed@company.sa, khaled@company.sa', active: true },
  { id: 2, title: 'تقرير المخزون', frequency: 'يومي', time: '06:00', nextRun: '2025-01-16 06:00', recipients: 'sami@company.sa', active: true },
  { id: 3, title: 'تقرير الربح والخسارة', frequency: 'شهري', time: '18:00', nextRun: '2025-02-01 18:00', recipients: 'ahmed@company.sa', active: true },
  { id: 4, title: 'تقرير العملاء', frequency: 'شهري', time: '10:00', nextRun: '2025-02-01 10:00', recipients: 'khaled@company.sa', active: false },
];

const FAVORITES = [
  { id: 1, title: 'تقرير المبيعات اليومية', icon: BarChart3, color: '#0a4a30' },
  { id: 2, title: 'تقرير الإنتاج', icon: Factory, color: '#059669' },
  { id: 3, title: 'تقرير المخزون', icon: Package, color: '#2563eb' },
];

/* ─────────────────────── mini components ─────────────────────── */

function MiniBarChart({ data, labels, color }: { data: number[]; labels: string[]; color: string }) {
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-1.5 h-16">
      {data.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
          <div className="w-full rounded-t-sm" style={{ height: `${(v / max) * 100}px`, backgroundColor: color, opacity: 0.5 + (i / data.length) * 0.5 }} />
          <span className="text-[9px] text-textMuted">{labels[i]}</span>
        </div>
      ))}


      {/* ─── Report Categories Breakdown ─── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.7 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5 mt-4"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <PieChart size={16} className="text-purple-500" />
          توزيع التقارير حسب الفئة
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            { category: 'مبيعات', count: 3, pct: '25%', icon: ShoppingCart, color: '#0a4a30', bg: 'bg-emerald-50', text: 'text-emerald-600' },
            { category: 'مالية', count: 2, pct: '17%', icon: DollarSign, color: '#0d6b43', bg: 'bg-green-50', text: 'text-green-600' },
            { category: 'مخزون', count: 2, pct: '17%', icon: Package, color: '#2563eb', bg: 'bg-blue-50', text: 'text-blue-600' },
            { category: 'إنتاج', count: 3, pct: '25%', icon: Factory, color: '#059669', bg: 'bg-teal-50', text: 'text-teal-600' },
            { category: 'عملاء', count: 2, pct: '16%', icon: Users, color: '#ea580c', bg: 'bg-orange-50', text: 'text-orange-600' },
          ].map((c, i) => (
            <motion.div key={c.category} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.06 }}
              className="flex items-center gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder hover:shadow-sm transition-all cursor-pointer"
            >
              <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', c.bg)}>
                <c.icon size={18} style={{ color: c.color }} />
              </div>
              <div>
                <p className="text-xs font-medium text-textPrimary dark:text-darkText">{c.category}</p>
                <p className="text-[11px] text-textMuted">{c.count} تقارير ({c.pct})</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ─── Report Templates ─── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.8 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5 mt-4 mb-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
            <ClipboardList size={16} className="text-cyan-600" />
            قوالب التقارير المتاحة
          </h3>
          <button className="text-xs text-[#0a4a30] hover:text-[#0d6b43] font-medium transition-colors">إنشاء قالب جديد</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { name: 'قالب المبيعات الشامل', desc: 'يشمل تحليل المنتجات والمناطق والعملاء', lastUsed: '2025-01-15' },
            { name: 'قالب المخزون التفصيلي', desc: 'عرض كامل للمخزون مع التنبيهات', lastUsed: '2025-01-14' },
            { name: 'قالب الإنتاج اليومي', desc: 'إحصائيات الإنتاج والجودة والهالك', lastUsed: '2025-01-15' },
            { name: 'قالب العملاء والمدفوعات', desc: 'تحليل آجل العملاء والمبالغ المستحقة', lastUsed: '2025-01-13' },
            { name: 'قالم المصروفات', desc: 'تفصيل المصروفات التشغيلية', lastUsed: '2025-01-12' },
            { name: 'قالب توصيل الطلبات', desc: 'أداء السائقين وأوقات التسليم', lastUsed: '2025-01-14' },
          ].map((t, i) => (
            <motion.div key={t.name} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
              className="flex items-start gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkBg transition-colors"
            >
              <FileText size={16} className="text-textMuted mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-textPrimary dark:text-darkText">{t.name}</p>
                <p className="text-[11px] text-textSecondary dark:text-darkTextSec truncate">{t.desc}</p>
                <p className="text-[10px] text-textMuted mt-1">آخر استخدام: {t.lastUsed}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

/* ─────────────────────── main page ─────────────────────── */

export default function ReportsPage() {
  const [activeCategory, setActiveCategory] = useState('الكل');
  const [dateFrom, setDateFrom] = useState('2025-01-01');
  const [dateTo, setDateTo] = useState('2025-01-15');
  const [generating, setGenerating] = useState<number[]>([]);
  const [searchQ, setSearchQ] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredReports = activeCategory === 'الكل'
    ? REPORTS.filter(r => !searchQ || r.title.includes(searchQ) || r.description.includes(searchQ))
    : REPORTS.filter(r => r.category === activeCategory && (!searchQ || r.title.includes(searchQ)));

  const handleGenerate = (id: number) => {
    setGenerating(prev => [...prev, id]);
    setTimeout(() => setGenerating(prev => prev.filter(x => x !== id)), 2000);
  };

  const totalGenerated = RECENTLY_GENERATED.length;
  const totalScheduled = SCHEDULED_REPORTS.filter(s => s.active).length;
  const totalFavorites = FAVORITES.length;

  return (
    <div className="p-4 md:p-6">
      <PageHeader title="التقارير" subtitle="إنشاء وتحميل التقارير الإدارية والمالية والتشغيلية">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-2 border border-uiBorder dark:border-darkBorder rounded-lg bg-white dark:bg-darkSurface">
            <Calendar size={14} className="text-textMuted" />
            <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
              className="text-xs text-textPrimary dark:text-darkText bg-transparent border-none outline-none w-28" />
            <span className="text-textMuted">-</span>
            <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
              className="text-xs text-textPrimary dark:text-darkText bg-transparent border-none outline-none w-28" />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-[#0a4a30] hover:bg-[#0d6b43] text-white rounded-lg text-sm font-medium transition-colors">
            <Plus size={16} />
            تقرير مخصص
          </button>
        </div>
      </PageHeader>

      {/* ─── KPIs ─── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <KPICard title="إجمالي التقارير" value={REPORTS.length.toString()} icon={FileText} iconBg="bg-emerald-50" iconColor="text-emerald-600" delay={0} />
        <KPICard title="منشأة مؤخراً" value={totalGenerated.toString()} icon={CheckCircle2} iconBg="bg-green-50" iconColor="text-green-600" delay={0.05} />
        <KPICard title="مجدولة" value={totalScheduled.toString()} icon={Clock} iconBg="bg-blue-50" iconColor="text-blue-600" delay={0.1} />
        <KPICard title="المفضلة" value={totalFavorites.toString()} icon={Star} iconBg="bg-amber-50" iconColor="text-amber-600" delay={0.15} />
      </div>

      {/* ─── Favorites Bar ─── */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-4 mb-6">
        <div className="flex items-center gap-2 mb-3">
          <Star size={16} className="text-amber-500 fill-amber-500" />
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText">التقارير المفضلة</h3>
        </div>
        <div className="flex items-center gap-3">
          {FAVORITES.map(f => (
            <button key={f.id} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkBg transition-colors">
              <f.icon size={16} style={{ color: f.color }} />
              <span className="text-xs font-medium text-textPrimary dark:text-darkText">{f.title}</span>
            </button>
          ))}
        </div>
      </motion.div>

      {/* ─── Search + Category Filter ─── */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => setActiveCategory(cat)}
              className={cn('px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap',
                activeCategory === cat
                  ? 'bg-[#0a4a30] text-white'
                  : 'bg-white dark:bg-darkSurface border border-uiBorder dark:border-darkBorder text-textSecondary hover:text-textPrimary dark:text-darkTextSec')}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <div className="relative w-48">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
            <input type="text" placeholder="بحث في التقارير..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
              className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
          </div>
        </div>
      </div>

      {/* ─── Report Cards ─── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <AnimatePresence mode="popLayout">
          {filteredReports.map((report, i) => (
            <motion.div
              key={report.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card hover:shadow-md transition-all p-5"
            >
              <div className="flex items-start gap-4">
                <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center shrink-0', report.bg)}>
                  <report.icon size={24} className={report.iconColor} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className="text-sm font-bold text-textPrimary dark:text-darkText">{report.title}</h3>
                    <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-surface dark:bg-darkBg text-textSecondary dark:text-darkTextSec">
                      {report.frequency}
                    </span>
                  </div>
                  <p className="text-xs text-textSecondary dark:text-darkTextSec mb-3 line-clamp-2">{report.description}</p>
                  <div className="flex items-center gap-4 mb-3">
                    <div className="flex items-center gap-1 text-[11px] text-textMuted">
                      <Clock size={12} />
                      آخر إنشاء: {report.lastGenerated}
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-textMuted">
                      <FileText size={12} />
                      {report.count} مرة
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleGenerate(report.id)}
                        disabled={generating.includes(report.id)}
                        className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors',
                          generating.includes(report.id)
                            ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                            : 'bg-[#0a4a30] hover:bg-[#0d6b43] text-white')}
                      >
                        {generating.includes(report.id) ? (
                          <>
                            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
                              <RefreshCw size={13} />
                            </motion.div>
                            جاري...
                          </>
                        ) : (
                          <>
                            <FileText size={13} />
                            إنشاء
                          </>
                        )}
                      </button>
                      <button className="flex items-center gap-1.5 px-3 py-1.5 border border-uiBorder dark:border-darkBorder rounded-lg text-xs text-textSecondary hover:bg-surface dark:hover:bg-darkBg transition-colors">
                        <Download size={13} />
                        PDF
                      </button>
                    </div>
                    <div className="flex items-center gap-1">
                      <button className="w-7 h-7 rounded-lg flex items-center justify-center text-textMuted hover:text-amber-500 hover:bg-amber-50 transition-colors" title="مفضل">
                        <Star size={14} />
                      </button>
                      <button className="w-7 h-7 rounded-lg flex items-center justify-center text-textMuted hover:text-blue-500 hover:bg-blue-50 transition-colors" title="طباعة">
                        <Printer size={14} />
                      </button>
                      <button className="w-7 h-7 rounded-lg flex items-center justify-center text-textMuted hover:text-green-500 hover:bg-green-50 transition-colors" title="مشاركة">
                        <Share2 size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* ─── Bottom Section: Scheduled + Recently Generated ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Scheduled Reports */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.2 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card"
        >
          <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
              <Clock size={18} className="text-blue-500" />
              تقارير مجدولة
            </h3>
            <button className="text-xs text-[#0a4a30] hover:text-[#0d6b43] font-medium transition-colors">إدارة</button>
          </div>
          <div className="divide-y divide-uiBorder/50 dark:divide-darkBorder/30">
            {SCHEDULED_REPORTS.map((s, i) => (
              <motion.div key={s.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                className="px-5 py-3 flex items-center gap-3 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/30 transition-colors"
              >
                <div className={cn('w-2 h-2 rounded-full shrink-0', s.active ? 'bg-green-500' : 'bg-slate-300')} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-textPrimary dark:text-darkText">{s.title}</p>
                  <p className="text-[11px] text-textMuted">{s.frequency} الساعة {s.time} | التالي: {s.nextRun}</p>
                </div>
                <span className={cn('px-2 py-0.5 rounded-full text-[10px] font-semibold', s.active ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600')}>
                  {s.active ? 'نشط' : 'متوقف'}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Recently Generated */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card"
        >
          <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
              <CheckCircle2 size={18} className="text-[#daa520]" />
              المنشأة مؤخراً
            </h3>
            <button className="text-xs text-[#0a4a30] hover:text-[#0d6b43] font-medium transition-colors">عرض الكل</button>
          </div>
          <div className="divide-y divide-uiBorder/50 dark:divide-darkBorder/30">
            {RECENTLY_GENERATED.map((r, i) => (
              <motion.div key={r.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                className="px-5 py-3 flex items-center gap-4 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/30 transition-colors"
              >
                <div className="w-9 h-9 rounded-lg bg-green-50 dark:bg-green-950/20 flex items-center justify-center shrink-0">
                  <FileText size={16} className="text-green-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-textPrimary dark:text-darkText">{r.title}</p>
                  <p className="text-[11px] text-textMuted">{r.date}</p>
                </div>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-surface dark:bg-darkBg text-textMuted">{r.type}</span>
                <span className="text-[11px] text-textMuted">{r.size}</span>
                <div className="flex items-center gap-1">
                  <button className="w-7 h-7 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkBg transition-colors">
                    <Eye size={14} />
                  </button>
                  <button className="w-7 h-7 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkBg transition-colors">
                    <Download size={14} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* ─── Monthly Summary Chart ─── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.4 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5 mt-4"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">إحصائيات إنشاء التقارير (آخر 6 أشهر)</h3>
        <MiniBarChart data={[45, 52, 38, 61, 55, 48]} labels={['أغس', 'سبت', 'أكتو', 'نوف', 'ديس', 'ينا']} color="#0a4a30" />
      </motion.div>

      {/* ─── Report Format Options ─── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.5 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5 mt-4"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <FileText size={16} className="text-emerald-600" />
          خيارات تصدير التقارير
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { format: 'PDF', desc: 'ملف محمول', icon: FileText, color: 'text-red-500', bg: 'bg-red-50' },
            { format: 'Excel', desc: 'جدول بيانات', icon: BarChart3, color: 'text-green-600', bg: 'bg-green-50' },
            { format: 'CSV', desc: 'بيانات نصية', icon: FileText, color: 'text-blue-500', bg: 'bg-blue-50' },
            { format: 'طباعة', desc: 'نسخة مطبوعة', icon: Printer, color: 'text-slate-600', bg: 'bg-slate-50' },
          ].map((f, i) => (
            <motion.div key={f.format} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="flex items-center gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkBg transition-colors cursor-pointer"
            >
              <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', f.bg)}>
                <f.icon size={18} className={f.color} />
              </div>
              <div>
                <p className="text-sm font-semibold text-textPrimary dark:text-darkText">{f.format}</p>
                <p className="text-[11px] text-textMuted">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ─── Quick Stats ─── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.6 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4"
      >
        {[
          { label: 'تقارير هذا الشهر', value: '48', change: '+12%', icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'متوسط الحجم', value: '1.4 MB', change: '-5%', icon: TrendingDown, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'تقارير فاشلة', value: '1', change: '-85%', icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'وقت الإنشاء', value: '12 ث', change: '-20%', icon: Clock, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
            className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-textSecondary dark:text-darkTextSec">{s.label}</span>
              <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center', s.bg)}>
                <s.icon size={16} className={s.color} />
              </div>
            </div>
            <p className="text-xl font-bold text-textPrimary dark:text-darkText">{s.value}</p>
            <p className={cn('text-[11px] font-medium', s.color)}>{s.change}</p>
          </motion.div>
        ))}
      </motion.div>


      {/* ─── Report Categories Breakdown ─── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.7 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5 mt-4"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <PieChart size={16} className="text-purple-500" />
          توزيع التقارير حسب الفئة
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            { category: 'مبيعات', count: 3, pct: '25%', icon: ShoppingCart, color: '#0a4a30', bg: 'bg-emerald-50', text: 'text-emerald-600' },
            { category: 'مالية', count: 2, pct: '17%', icon: DollarSign, color: '#0d6b43', bg: 'bg-green-50', text: 'text-green-600' },
            { category: 'مخزون', count: 2, pct: '17%', icon: Package, color: '#2563eb', bg: 'bg-blue-50', text: 'text-blue-600' },
            { category: 'إنتاج', count: 3, pct: '25%', icon: Factory, color: '#059669', bg: 'bg-teal-50', text: 'text-teal-600' },
            { category: 'عملاء', count: 2, pct: '16%', icon: Users, color: '#ea580c', bg: 'bg-orange-50', text: 'text-orange-600' },
          ].map((c, i) => (
            <motion.div key={c.category} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.06 }}
              className="flex items-center gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder hover:shadow-sm transition-all cursor-pointer"
            >
              <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', c.bg)}>
                <c.icon size={18} style={{ color: c.color }} />
              </div>
              <div>
                <p className="text-xs font-medium text-textPrimary dark:text-darkText">{c.category}</p>
                <p className="text-[11px] text-textMuted">{c.count} تقارير ({c.pct})</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ─── Report Templates ─── */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.8 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5 mt-4 mb-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
            <ClipboardList size={16} className="text-cyan-600" />
            قوالب التقارير المتاحة
          </h3>
          <button className="text-xs text-[#0a4a30] hover:text-[#0d6b43] font-medium transition-colors">إنشاء قالب جديد</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { name: 'قالب المبيعات الشامل', desc: 'يشمل تحليل المنتجات والمناطق والعملاء', lastUsed: '2025-01-15' },
            { name: 'قالب المخزون التفصيلي', desc: 'عرض كامل للمخزون مع التنبيهات', lastUsed: '2025-01-14' },
            { name: 'قالب الإنتاج اليومي', desc: 'إحصائيات الإنتاج والجودة والهالك', lastUsed: '2025-01-15' },
            { name: 'قالب العملاء والمدفوعات', desc: 'تحليل آجل العملاء والمبالغ المستحقة', lastUsed: '2025-01-13' },
            { name: 'قالم المصروفات', desc: 'تفصيل المصروفات التشغيلية', lastUsed: '2025-01-12' },
            { name: 'قالب توصيل الطلبات', desc: 'أداء السائقين وأوقات التسليم', lastUsed: '2025-01-14' },
          ].map((t, i) => (
            <motion.div key={t.name} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
              className="flex items-start gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkBg transition-colors"
            >
              <FileText size={16} className="text-textMuted mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-textPrimary dark:text-darkText">{t.name}</p>
                <p className="text-[11px] text-textSecondary dark:text-darkTextSec truncate">{t.desc}</p>
                <p className="text-[10px] text-textMuted mt-1">آخر استخدام: {t.lastUsed}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
