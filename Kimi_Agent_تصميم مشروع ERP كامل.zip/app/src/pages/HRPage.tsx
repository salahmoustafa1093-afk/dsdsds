// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, Plus, Search, X, CheckCircle2, Clock, CalendarDays,
  TrendingUp, DollarSign, UserPlus, UserMinus, Briefcase,
  Sun, Moon, MapPin, Phone, Mail, Award, FileText,
  ChevronRight, Edit3, Trash2, Eye, LogIn, LogOut, Receipt,
  Target, TrendingDown, AlertCircle, Check, XCircle, PauseCircle,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

/* ─── mock data ─── */
const employees = [
  { id: 1, empNo: 'EMP-001', name: 'أحمد خالد محمد', department: 'الإنتاج', position: 'مدير إنتاج', branch: 'الرئيسي', salary: 8500, phone: '01001234567', email: 'ahmed@company.com', joinDate: '2022-03-15', status: 'نشط' },
  { id: 2, empNo: 'EMP-002', name: 'محمد علي حسن', department: 'الإنتاج', position: 'مشغل خط', branch: 'الرئيسي', salary: 4500, phone: '01002345678', email: 'mohamed@company.com', joinDate: '2023-01-10', status: 'نشط' },
  { id: 3, empNo: 'EMP-003', name: 'سامي رجب إبراهيم', department: 'المبيعات', position: 'مندوب مبيعات', branch: 'فرع الغربية', salary: 3800, phone: '01003456789', email: 'samy@company.com', joinDate: '2023-06-20', status: 'نشط' },
  { id: 4, empNo: 'EMP-004', name: 'خالد محمود سعيد', department: 'المستودعات', position: 'أمين مستودع', branch: 'الرئيسي', salary: 4000, phone: '01004567890', email: 'khaled@company.com', joinDate: '2022-08-05', status: 'نشط' },
  { id: 5, empNo: 'EMP-005', name: 'فاطمة أحمد علي', department: 'الحسابات', position: 'محاسبة', branch: 'الرئيسي', salary: 5500, phone: '01005678901', email: 'fatma@company.com', joinDate: '2021-11-12', status: 'نشط' },
  { id: 6, empNo: 'EMP-006', name: 'محمود سامي نبيل', department: 'الإنتاج', position: 'فني صيانة', branch: 'الرئيسي', salary: 5000, phone: '01006789012', email: 'mahmoud@company.com', joinDate: '2022-05-18', status: 'نشط' },
  { id: 7, empNo: 'EMP-007', name: 'نبيل كمال رأفت', department: 'الجودة', position: 'فني جودة', branch: 'الرئيسي', salary: 4200, phone: '01007890123', email: 'nabil@company.com', joinDate: '2023-03-01', status: 'إجازة' },
  { id: 8, empNo: 'EMP-008', name: 'رأفت نبيل سمير', department: 'النقل', position: 'سائق', branch: 'فرع الغربية', salary: 3500, phone: '01008901234', email: 'raafat@company.com', joinDate: '2023-09-15', status: 'نشط' },
  { id: 9, empNo: 'EMP-009', name: 'سمير حسن علي', department: 'المبيعات', position: 'مشرف مبيعات', branch: 'فرع القاهرة', salary: 6200, phone: '01009012345', email: 'samir@company.com', joinDate: '2021-07-22', status: 'نشط' },
  { id: 10, empNo: 'EMP-010', name: 'علي خالد محمد', department: 'الإنتاج', position: 'مشغل خط', branch: 'الرئيسي', salary: 4300, phone: '01010123456', email: 'ali@company.com', joinDate: '2024-01-05', status: 'نشط' },
  { id: 11, empNo: 'EMP-011', name: 'حسن محمود سامي', department: 'الأعلاف', position: 'فني تركيبات', branch: 'الرئيسي', salary: 4800, phone: '01011234567', email: 'hassan@company.com', joinDate: '2022-09-10', status: 'غائب' },
  { id: 12, empNo: 'EMP-012', name: 'كمال رأفت نبيل', department: 'المبيعات', position: 'مندوب مبيعات', branch: 'فرع القاهرة', salary: 3600, phone: '01012345678', email: 'kamal@company.com', joinDate: '2024-02-14', status: 'نشط' },
  { id: 13, empNo: 'EMP-013', name: 'سارة أحمد خالد', department: 'الموارد البشرية', position: 'أخصائي موارد بشرية', branch: 'الرئيسي', salary: 5800, phone: '01013456789', email: 'sara@company.com', joinDate: '2021-04-01', status: 'نشط' },
  { id: 14, empNo: 'EMP-014', name: 'هاني سمير علي', department: 'الإنتاج', position: 'مشغل خط', branch: 'الرئيسي', salary: 4400, phone: '01014567890', email: 'hani@company.com', joinDate: '2023-11-20', status: 'نشط' },
  { id: 15, empNo: 'EMP-015', name: 'وليد محمد حسن', department: 'الصيانة', position: 'فني كهرباء', branch: 'الرئيسي', salary: 4600, phone: '01015678901', email: 'waleed@company.com', joinDate: '2024-03-10', status: 'جديد' },
];

const attendanceRecords = [
  { id: 1, empNo: 'EMP-001', name: 'أحمد خالد محمد', date: '2024-12-19', status: 'حاضر', clockIn: '07:55', clockOut: '16:05', department: 'الإنتاج' },
  { id: 2, empNo: 'EMP-002', name: 'محمد علي حسن', date: '2024-12-19', status: 'حاضر', clockIn: '08:00', clockOut: '16:00', department: 'الإنتاج' },
  { id: 3, empNo: 'EMP-003', name: 'سامي رجب إبراهيم', date: '2024-12-19', status: 'حاضر', clockIn: '07:45', clockOut: '-', department: 'المبيعات' },
  { id: 4, empNo: 'EMP-004', name: 'خالد محمود سعيد', date: '2024-12-19', status: 'متأخر', clockIn: '09:10', clockOut: '-', department: 'المستودعات' },
  { id: 5, empNo: 'EMP-005', name: 'فاطمة أحمد علي', date: '2024-12-19', status: 'حاضر', clockIn: '08:00', clockOut: '16:00', department: 'الحسابات' },
  { id: 6, empNo: 'EMP-006', name: 'محمود سامي نبيل', date: '2024-12-19', status: 'حاضر', clockIn: '07:50', clockOut: '-', department: 'الإنتاج' },
  { id: 7, empNo: 'EMP-007', name: 'نبيل كمال رأفت', date: '2024-12-19', status: 'إجازة', clockIn: '-', clockOut: '-', department: 'الجودة' },
  { id: 8, empNo: 'EMP-011', name: 'حسن محمود سامي', date: '2024-12-19', status: 'غائب', clockIn: '-', clockOut: '-', department: 'الأعلاف' },
  { id: 9, empNo: 'EMP-012', name: 'كمال رأفت نبيل', date: '2024-12-19', status: 'حاضر', clockIn: '08:05', clockOut: '-', department: 'المبيعات' },
  { id: 10, empNo: 'EMP-013', name: 'سارة أحمد خالد', date: '2024-12-19', status: 'حاضر', clockIn: '08:00', clockOut: '16:00', department: 'الموارد البشرية' },
];

const payrollRecords = [
  { id: 1, empNo: 'EMP-001', name: 'أحمد خالد محمد', basic: 8500, allowances: 1200, deductions: 340, insurance: 425, net: 8935, month: 'ديسمبر 2024' },
  { id: 2, empNo: 'EMP-002', name: 'محمد علي حسن', basic: 4500, allowances: 600, deductions: 150, insurance: 225, net: 4725, month: 'ديسمبر 2024' },
  { id: 3, empNo: 'EMP-003', name: 'سامي رجب إبراهيم', basic: 3800, allowances: 800, deductions: 120, insurance: 190, net: 4290, month: 'ديسمبر 2024' },
  { id: 4, empNo: 'EMP-004', name: 'خالد محمود سعيد', basic: 4000, allowances: 500, deductions: 100, insurance: 200, net: 4200, month: 'ديسمبر 2024' },
  { id: 5, empNo: 'EMP-005', name: 'فاطمة أحمد علي', basic: 5500, allowances: 700, deductions: 200, insurance: 275, net: 5725, month: 'ديسمبر 2024' },
  { id: 6, empNo: 'EMP-006', name: 'محمود سامي نبيل', basic: 5000, allowances: 650, deductions: 180, insurance: 250, net: 5220, month: 'ديسمبر 2024' },
  { id: 7, empNo: 'EMP-008', name: 'رأفت نبيل سمير', basic: 3500, allowances: 400, deductions: 90, insurance: 175, net: 3635, month: 'ديسمبر 2024' },
  { id: 8, empNo: 'EMP-009', name: 'سمير حسن علي', basic: 6200, allowances: 1500, deductions: 300, insurance: 310, net: 7090, month: 'ديسمبر 2024' },
  { id: 9, empNo: 'EMP-010', name: 'علي خالد محمد', basic: 4300, allowances: 500, deductions: 130, insurance: 215, net: 4455, month: 'ديسمبر 2024' },
  { id: 10, empNo: 'EMP-013', name: 'سارة أحمد خالد', basic: 5800, allowances: 800, deductions: 220, insurance: 290, net: 6090, month: 'ديسمبر 2024' },
];

const commissionRecords = [
  { id: 1, empNo: 'EMP-003', name: 'سامي رجب إبراهيم', target: 150000, achievement: 142000, achievementPct: 94.7, commissionRate: 2.5, commission: 3550 },
  { id: 2, empNo: 'EMP-009', name: 'سمير حسن علي', target: 200000, achievement: 235000, achievementPct: 117.5, commissionRate: 3.0, commission: 7050 },
  { id: 3, empNo: 'EMP-012', name: 'كمال رأفت نبيل', target: 100000, achievement: 78000, achievementPct: 78.0, commissionRate: 2.0, commission: 1560 },
  { id: 4, empNo: 'EMP-003', name: 'سامي رجب إبراهيم', target: 150000, achievement: 158000, achievementPct: 105.3, commissionRate: 2.5, commission: 3950, month: 'نوفمبر' },
  { id: 5, empNo: 'EMP-009', name: 'سمير حسن علي', target: 200000, achievement: 210000, achievementPct: 105.0, commissionRate: 3.0, commission: 6300, month: 'نوفمبر' },
];

const leaveRequests = [
  { id: 1, empNo: 'EMP-007', name: 'نبيل كمال رأفت', type: 'سنوية', startDate: '2024-12-15', endDate: '2024-12-25', days: 10, status: 'معتمد', approvedBy: 'سارة أحمد خالد' },
  { id: 2, empNo: 'EMP-005', name: 'فاطمة أحمد علي', type: 'عارضة', startDate: '2024-12-20', endDate: '2024-12-20', days: 1, status: 'قيد المراجعة', approvedBy: '-' },
  { id: 3, empNo: 'EMP-002', name: 'محمد علي حسن', type: 'مرضية', startDate: '2024-12-18', endDate: '2024-12-19', days: 2, status: 'معتمد', approvedBy: 'أحمد خالد محمد' },
  { id: 4, empNo: 'EMP-011', name: 'حسن محمود سامي', type: 'عارضة', startDate: '2024-12-19', endDate: '2024-12-19', days: 1, status: 'معتمد', approvedBy: 'أحمد خالد محمد' },
  { id: 5, empNo: 'EMP-013', name: 'سارة أحمد خالد', type: 'سنوية', startDate: '2025-01-01', endDate: '2025-01-10', days: 10, status: 'قيد المراجعة', approvedBy: '-' },
];

const deptDistribution = [
  { name: 'الإنتاج', value: 5 },
  { name: 'المبيعات', value: 3 },
  { name: 'الحسابات', value: 1 },
  { name: 'المستودعات', value: 1 },
  { name: 'الجودة', value: 1 },
  { name: 'النقل', value: 1 },
  { name: 'الأعلاف', value: 1 },
  { name: 'الموارد البشرية', value: 1 },
  { name: 'الصيانة', value: 1 },
];

const COLORS = ['#0d6b43', '#daa520', '#0a4a30', '#e5a220', '#2d8a5e', '#c9941a', '#1a6b4a', '#f0c040', '#2563eb'];

/* ─── helper components ─── */
function AttendanceBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    'حاضر': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
    'غائب': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
    'متأخر': 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
    'إجازة': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status] || ''}`}>
      {status === 'حاضر' && <CheckCircle2 size={12} />}
      {status === 'غائب' && <XCircle size={12} />}
      {status === 'متأخر' && <Clock size={12} />}
      {status === 'إجازة' && <Sun size={12} />}
      {status}
    </span>
  );
}

function EmployeeStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    'نشط': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
    'غائب': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
    'إجازة': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
    'جديد': 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-400',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status] || ''}`}>
      {status}
    </span>
  );
}

function LeaveStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    'معتمد': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
    'قيد المراجعة': 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
    'مرفوض': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status] || ''}`}>
      {status}
    </span>
  );
}

function PayslipModal({ record, onClose }: { record: any; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-md"
      >
        <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
          <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
            <Receipt size={20} className="text-[#daa520]" /> قسيمة الراتب
          </h3>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
            <X size={18} className="text-textMuted" />
          </button>
        </div>
        <div className="p-6 space-y-3">
          <div className="text-center pb-3 border-b border-uiBorder dark:border-darkBorder">
            <p className="text-sm text-textSecondary">{record.month}</p>
            <h4 className="text-xl font-bold text-textPrimary dark:text-darkText mt-1">{record.name}</h4>
            <p className="text-xs text-textMuted">{record.empNo}</p>
          </div>
          {[
            { label: 'الراتب الأساسي', value: record.basic, color: 'text-textPrimary' },
            { label: 'البدلات', value: record.allowances, color: 'text-green-600' },
            { label: 'الاستقطاعات', value: -record.deductions, color: 'text-red-500' },
            { label: 'التأمينات', value: -record.insurance, color: 'text-red-500' },
          ].map((item) => (
            <div key={item.label} className="flex justify-between items-center py-2">
              <span className="text-textSecondary text-sm">{item.label}</span>
              <span className={`font-semibold ${item.color}`}>{item.value > 0 ? '+' : ''}{item.value.toLocaleString()} ج</span>
            </div>
          ))}
          <div className="pt-3 border-t border-uiBorder dark:border-darkBorder">
            <div className="flex justify-between items-center">
              <span className="text-base font-bold text-textPrimary">الصافي</span>
              <span className="text-xl font-bold text-[#0d6b43]">{record.net.toLocaleString()} ج</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
          >
            إغلاق
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── main page ─── */
export default function HRPage() {
  const [employeeList, setEmployeeList] = useState(employees);
  const [attendanceList, setAttendanceList] = useState(attendanceRecords);
  const [leaveList, setLeaveList] = useState(leaveRequests);
  const [activeTab, setActiveTab] = useState('employees');
  const [searchQuery, setSearchQuery] = useState('');
  const [showEmployeeModal, setShowEmployeeModal] = useState(false);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [showPayslip, setShowPayslip] = useState<any | null>(null);
  const [showDetailEmployee, setShowDetailEmployee] = useState<any | null>(null);
  const [showEditEmployee, setShowEditEmployee] = useState<any | null>(null);

  const [employeeForm, setEmployeeForm] = useState({
    name: '', department: 'الإنتاج', position: '', branch: 'الرئيسي', salary: '', phone: '', email: '',
  });

  const [leaveForm, setLeaveForm] = useState({
    empNo: '', type: 'سنوية', startDate: '', endDate: '', days: '',
  });

  const presentCount = attendanceList.filter(a => a.status === 'حاضر').length;
  const absentCount = attendanceList.filter(a => a.status === 'غائب').length;
  const leaveCount = attendanceList.filter(a => a.status === 'إجازة').length;
  const newCount = employeeList.filter(e => e.status === 'جديد').length;

  const filteredEmployees = employeeList.filter(e =>
    e.name.includes(searchQuery) || e.empNo.toLowerCase().includes(searchQuery.toLowerCase()) || e.department.includes(searchQuery)
  );

  const filteredAttendance = attendanceList.filter(a =>
    a.name.includes(searchQuery) || a.empNo.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredLeaves = leaveList.filter(l =>
    l.name.includes(searchQuery) || l.empNo.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddEmployee = () => {
    if (!employeeForm.name || !employeeForm.salary) return;
    const newEmp = {
      id: employeeList.length + 1,
      empNo: `EMP-${String(employeeList.length + 1).padStart(3, '0')}`,
      name: employeeForm.name,
      department: employeeForm.department,
      position: employeeForm.position || 'موظف',
      branch: employeeForm.branch,
      salary: Number(employeeForm.salary),
      phone: employeeForm.phone || '-',
      email: employeeForm.email || '-',
      joinDate: new Date().toISOString().split('T')[0],
      status: 'جديد',
    };
    setEmployeeList([newEmp, ...employeeList]);
    setEmployeeForm({ name: '', department: 'الإنتاج', position: '', branch: 'الرئيسي', salary: '', phone: '', email: '' });
    setShowEmployeeModal(false);
  };

  const handleAddLeave = () => {
    if (!leaveForm.empNo || !leaveForm.startDate || !leaveForm.endDate) return;
    const emp = employeeList.find(e => e.empNo === leaveForm.empNo);
    const newLeave = {
      id: leaveList.length + 1,
      empNo: leaveForm.empNo,
      name: emp?.name || '-',
      type: leaveForm.type,
      startDate: leaveForm.startDate,
      endDate: leaveForm.endDate,
      days: Number(leaveForm.days) || 1,
      status: 'قيد المراجعة',
      approvedBy: '-',
    };
    setLeaveList([newLeave, ...leaveList]);
    setLeaveForm({ empNo: '', type: 'سنوية', startDate: '', endDate: '', days: '' });
    setShowLeaveModal(false);
  };

  const handleDeleteEmployee = (id: number) => {
    if (confirm('هل أنت متأكد من حذف الموظف؟')) {
      setEmployeeList(employeeList.filter(e => e.id !== id));
    }
  };

  const handleApproveLeave = (id: number) => {
    setLeaveList(leaveList.map(l => l.id === id ? { ...l, status: 'معتمد', approvedBy: 'سارة أحمد خالد' } : l));
  };

  const handleClockAction = (empNo: string, action: 'in' | 'out') => {
    setAttendanceList(attendanceList.map(a => {
      if (a.empNo === empNo) {
        const now = new Date();
        const time = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        return { ...a, [action === 'in' ? 'clockIn' : 'clockOut']: time, status: action === 'in' ? 'حاضر' : a.status };
      }
      return a;
    }));
  };

  const employeeColumns = [
    { key: 'empNo', header: 'الرقم الوظيفي', sortable: true },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'department', header: 'القسم', sortable: true },
    { key: 'position', header: 'المنصب', sortable: true },
    { key: 'branch', header: 'الفرع', sortable: true },
    { key: 'salary', header: 'الراتب', sortable: true, render: (row: any) => <span className="font-semibold">{row.salary.toLocaleString()} ج</span> },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <EmployeeStatusBadge status={row.status} /> },
  ];

  const attendanceColumns = [
    { key: 'empNo', header: 'الرقم', sortable: true },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'department', header: 'القسم', sortable: true },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <AttendanceBadge status={row.status} /> },
    { key: 'clockIn', header: 'تسجيل دخول', sortable: true, render: (row: any) => <span className="font-mono">{row.clockIn}</span> },
    { key: 'clockOut', header: 'تسجيل خروج', sortable: true, render: (row: any) => <span className="font-mono">{row.clockOut}</span> },
  ];

  const payrollColumns = [
    { key: 'empNo', header: 'الرقم', sortable: true },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'basic', header: 'أساسي', sortable: true, render: (row: any) => <span>{row.basic.toLocaleString()} ج</span> },
    { key: 'allowances', header: 'بدلات', sortable: true, render: (row: any) => <span className="text-green-600">+{row.allowances.toLocaleString()}</span> },
    { key: 'deductions', header: 'استقطاعات', sortable: true, render: (row: any) => <span className="text-red-500">-{row.deductions.toLocaleString()}</span> },
    { key: 'insurance', header: 'تأمين', sortable: true, render: (row: any) => <span className="text-red-400">-{row.insurance.toLocaleString()}</span> },
    { key: 'net', header: 'الصافي', sortable: true, render: (row: any) => <span className="font-bold text-[#0d6b43]">{row.net.toLocaleString()} ج</span> },
  ];

  const commissionColumns = [
    { key: 'empNo', header: 'الرقم', sortable: true },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'target', header: 'المستهدف', sortable: true, render: (row: any) => <span>{row.target.toLocaleString()} ج</span> },
    { key: 'achievement', header: 'الإنجاز', sortable: true, render: (row: any) => <span>{row.achievement.toLocaleString()} ج</span> },
    { key: 'achievementPct', header: 'النسبة %', sortable: true, render: (row: any) => (
      <span className={`font-bold ${row.achievementPct >= 100 ? 'text-green-600' : row.achievementPct >= 80 ? 'text-amber-600' : 'text-red-600'}`}>
        {row.achievementPct}%
      </span>
    )},
    { key: 'commission', header: 'العمولة', sortable: true, render: (row: any) => <span className="font-bold text-[#daa520]">{row.commission.toLocaleString()} ج</span> },
  ];

  const leaveColumns = [
    { key: 'empNo', header: 'الرقم', sortable: true },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'type', header: 'النوع', sortable: true },
    { key: 'startDate', header: 'من', sortable: true },
    { key: 'endDate', header: 'إلى', sortable: true },
    { key: 'days', header: 'أيام', sortable: true },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <LeaveStatusBadge status={row.status} /> },
    { key: 'approvedBy', header: 'معتمد من', sortable: true },
  ];

  const tabs = [
    { key: 'employees', label: 'الموظفين', icon: Users },
    { key: 'attendance', label: 'الحضور', icon: Clock },
    { key: 'payroll', label: 'الرواتب', icon: DollarSign },
    { key: 'commissions', label: 'العمولات', icon: Target },
    { key: 'leaves', label: 'الإجازات', icon: Sun },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="الموارد البشرية"
        subtitle="إدارة الموظفين والحضور والرواتب والعمولات"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الموارد البشرية' }]}
      >
        {activeTab === 'employees' && (
          <button onClick={() => setShowEmployeeModal(true)} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all">
            <Plus size={18} /> موظف جديد
          </button>
        )}
        {activeTab === 'leaves' && (
          <button onClick={() => setShowLeaveModal(true)} className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all">
            <Plus size={18} /> طلب إجازة
          </button>
        )}
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="إجمالي الموظفين" value={String(employeeList.length)} icon={Users} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-600" change={2} delay={0} />
        <KPICard title="حاضرين" value={String(presentCount)} icon={CheckCircle2} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-600" delay={0.05} />
        <KPICard title="غائبين" value={String(absentCount)} icon={UserMinus} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-600" delay={0.1} />
        <KPICard title="في إجازة" value={String(leaveCount)} icon={Sun} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-600" delay={0.15} />
        <KPICard title="جدد" value={String(newCount)} icon={UserPlus} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-600" delay={0.2} />
      </div>

      {/* Department Distribution */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <Users size={18} className="text-[#0d6b43]" /> توزيع الموظفين بالأقسام
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={deptDistribution} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" nameKey="name">
                  {deptDistribution.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 content-center">
            {deptDistribution.map((dept, i) => (
              <div key={dept.name} className="flex items-center gap-2 text-sm">
                <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[i] }} />
                <span className="text-textSecondary text-xs">{dept.name}</span>
                <span className="font-semibold text-textPrimary mr-auto">{dept.value}</span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-3 border-b border-uiBorder dark:border-darkBorder flex items-center gap-1 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab.key
                    ? 'bg-[#0a4a30] text-white'
                    : 'text-textSecondary hover:bg-surface dark:hover:bg-darkCard'
                }`}
              >
                <Icon size={16} /> {tab.label}
              </button>
            );
          })}
        </div>

        {/* Employees Tab */}
        {activeTab === 'employees' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Users size={18} className="text-[#0d6b43]" /> سجل الموظفين
              </h3>
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                <input
                  type="text" placeholder="بحث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-56 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                />
              </div>
            </div>
            <DataTable
              columns={employeeColumns}
              data={filteredEmployees}
              pageSize={10}
              searchable={false}
              rowActions={{
                onView: (row) => setShowDetailEmployee(row),
                onEdit: (row) => setShowEditEmployee({ ...row }),
                onDelete: (row) => handleDeleteEmployee(row.id),
              }}
              emptyMessage="لا يوجد موظفين"
            />
          </div>
        )}

        {/* Attendance Tab */}
        {activeTab === 'attendance' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Clock size={18} className="text-[#0d6b43]" /> سجل الحضور اليومي
              </h3>
              <span className="text-xs text-textMuted">{new Date().toLocaleDateString('ar-SA')}</span>
            </div>
            {/* Summary Bar */}
            <div className="px-5 py-3 border-b border-uiBorder dark:border-darkBorder grid grid-cols-4 gap-3">
              {[
                { label: 'حاضر', value: presentCount, color: 'text-green-600', bg: 'bg-green-50 dark:bg-green-900/20' },
                { label: 'متأخر', value: attendanceList.filter(a => a.status === 'متأخر').length, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20' },
                { label: 'غائب', value: absentCount, color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-900/20' },
                { label: 'إجازة', value: leaveCount, color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-900/20' },
              ].map((s) => (
                <div key={s.label} className={`${s.bg} rounded-xl p-3 text-center`}>
                  <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
                  <p className="text-[11px] text-textSecondary">{s.label}</p>
                </div>
              ))}
            </div>
            <DataTable
              columns={attendanceColumns}
              data={filteredAttendance}
              pageSize={10}
              searchable={false}
              rowActions={{
                onView: (row) => {
                  if (row.status !== 'إجازة') {
                    if (row.clockIn === '-') {
                      handleClockAction(row.empNo, 'in');
                    } else if (row.clockOut === '-') {
                      handleClockAction(row.empNo, 'out');
                    }
                  }
                },
              }}
              emptyMessage="لا توجد سجلات حضور"
            />
          </div>
        )}

        {/* Payroll Tab */}
        {activeTab === 'payroll' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <DollarSign size={18} className="text-[#0d6b43]" /> كشف الرواتب - ديسمبر 2024
              </h3>
              <span className="text-xs text-textMuted">
                الإجمالي: {payrollRecords.reduce((s, r) => s + r.net, 0).toLocaleString()} ج
              </span>
            </div>
            <DataTable
              columns={payrollColumns}
              data={payrollRecords}
              pageSize={10}
              rowActions={{
                onView: (row) => setShowPayslip(row),
              }}
              emptyMessage="لا توجد سجلات رواتب"
            />
          </div>
        )}

        {/* Commissions Tab */}
        {activeTab === 'commissions' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Target size={18} className="text-[#daa520]" /> عمولات المبيعات
              </h3>
            </div>
            <DataTable
              columns={commissionColumns}
              data={commissionRecords}
              pageSize={8}
              emptyMessage="لا توجد سجلات عمولات"
            />
          </div>
        )}

        {/* Leaves Tab */}
        {activeTab === 'leaves' && (
          <div>
            <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                <Sun size={18} className="text-[#0d6b43]" /> طلبات الإجازات
              </h3>
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                <input
                  type="text" placeholder="بحث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-48 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                />
              </div>
            </div>
            <DataTable
              columns={leaveColumns}
              data={filteredLeaves}
              pageSize={8}
              searchable={false}
              rowActions={{
                onEdit: (row) => { if (row.status === 'قيد المراجعة') handleApproveLeave(row.id); },
                onDelete: (row) => { if (confirm('حذف الطلب؟')) setLeaveList(leaveList.filter(l => l.id !== row.id)); },
              }}
              emptyMessage="لا توجد طلبات إجازة"
            />
          </div>
        )}
      </div>

      {/* Add Employee Modal */}
      <AnimatePresence>
        {showEmployeeModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEmployeeModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">موظف جديد</h3>
                <button onClick={() => setShowEmployeeModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الاسم الكامل</label>
                  <input
                    type="text" placeholder="اسم الموظف"
                    value={employeeForm.name}
                    onChange={(e) => setEmployeeForm({ ...employeeForm, name: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">القسم</label>
                    <select
                      value={employeeForm.department}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, department: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="الإنتاج">الإنتاج</option>
                      <option value="المبيعات">المبيعات</option>
                      <option value="الحسابات">الحسابات</option>
                      <option value="المستودعات">المستودعات</option>
                      <option value="الجودة">الجودة</option>
                      <option value="النقل">النقل</option>
                      <option value="الأعلاف">الأعلاف</option>
                      <option value="الموارد البشرية">الموارد البشرية</option>
                      <option value="الصيانة">الصيانة</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المنصب</label>
                    <input
                      type="text" placeholder="المنصب الوظيفي"
                      value={employeeForm.position}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, position: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الفرع</label>
                    <select
                      value={employeeForm.branch}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, branch: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    >
                      <option value="الرئيسي">الرئيسي</option>
                      <option value="فرع الغربية">فرع الغربية</option>
                      <option value="فرع القاهرة">فرع القاهرة</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الراتب</label>
                    <input
                      type="number" placeholder="0"
                      value={employeeForm.salary}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, salary: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الهاتف</label>
                    <input
                      type="text" placeholder="01XXXXXXXXX"
                      value={employeeForm.phone}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, phone: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">البريد الإلكتروني</label>
                    <input
                      type="email" placeholder="email@company.com"
                      value={employeeForm.email}
                      onChange={(e) => setEmployeeForm({ ...employeeForm, email: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                </div>
                <button
                  onClick={handleAddEmployee}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ الموظف
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Leave Request Modal */}
      <AnimatePresence>
        {showLeaveModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowLeaveModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">طلب إجازة جديد</h3>
                <button onClick={() => setShowLeaveModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الموظف</label>
                  <select
                    value={leaveForm.empNo}
                    onChange={(e) => setLeaveForm({ ...leaveForm, empNo: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  >
                    <option value="">اختر موظف</option>
                    {employeeList.map(e => (
                      <option key={e.id} value={e.empNo}>{e.empNo} - {e.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">نوع الإجازة</label>
                  <select
                    value={leaveForm.type}
                    onChange={(e) => setLeaveForm({ ...leaveForm, type: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  >
                    <option value="سنوية">سنوية</option>
                    <option value="عارضة">عارضة</option>
                    <option value="مرضية">مرضية</option>
                    <option value="بدون راتب">بدون راتب</option>
                  </select>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">من</label>
                    <input
                      type="date"
                      value={leaveForm.startDate}
                      onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">إلى</label>
                    <input
                      type="date"
                      value={leaveForm.endDate}
                      onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">عدد الأيام</label>
                    <input
                      type="number"
                      value={leaveForm.days}
                      onChange={(e) => setLeaveForm({ ...leaveForm, days: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                </div>
                <button
                  onClick={handleAddLeave}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  تقديم الطلب
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Payslip Modal */}
      <AnimatePresence>
        {showPayslip && <PayslipModal record={showPayslip} onClose={() => setShowPayslip(null)} />}
      </AnimatePresence>

      {/* Employee Detail Modal */}
      <AnimatePresence>
        {showDetailEmployee && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailEmployee(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-md"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">بيانات الموظف</h3>
                <button onClick={() => setShowDetailEmployee(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-3">
                {[
                  { label: 'الرقم الوظيفي', value: showDetailEmployee.empNo },
                  { label: 'الاسم', value: showDetailEmployee.name },
                  { label: 'القسم', value: showDetailEmployee.department },
                  { label: 'المنصب', value: showDetailEmployee.position },
                  { label: 'الفرع', value: showDetailEmployee.branch },
                  { label: 'الراتب', value: `${showDetailEmployee.salary.toLocaleString()} ج` },
                  { label: 'الهاتف', value: showDetailEmployee.phone },
                  { label: 'البريد الإلكتروني', value: showDetailEmployee.email },
                  { label: 'تاريخ التعيين', value: showDetailEmployee.joinDate },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-textSecondary text-sm">{item.label}</span>
                    <span className="font-semibold text-textPrimary">{item.value}</span>
                  </div>
                ))}
                <div className="pt-2">
                  <EmployeeStatusBadge status={showDetailEmployee.status} />
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Employee Modal */}
      <AnimatePresence>
        {showEditEmployee && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEditEmployee(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تعديل بيانات الموظف</h3>
                <button onClick={() => setShowEditEmployee(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الاسم</label>
                  <input
                    type="text"
                    value={showEditEmployee.name}
                    onChange={(e) => setShowEditEmployee({ ...showEditEmployee, name: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الراتب</label>
                    <input
                      type="number"
                      value={showEditEmployee.salary}
                      onChange={(e) => setShowEditEmployee({ ...showEditEmployee, salary: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المنصب</label>
                    <input
                      type="text"
                      value={showEditEmployee.position}
                      onChange={(e) => setShowEditEmployee({ ...showEditEmployee, position: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الحالة</label>
                  <select
                    value={showEditEmployee.status}
                    onChange={(e) => setShowEditEmployee({ ...showEditEmployee, status: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  >
                    <option value="نشط">نشط</option>
                    <option value="غائب">غائب</option>
                    <option value="إجازة">إجازة</option>
                    <option value="جديد">جديد</option>
                  </select>
                </div>
                <button
                  onClick={() => { setEmployeeList(employeeList.map(e => e.id === showEditEmployee.id ? showEditEmployee : e)); setShowEditEmployee(null); }}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التعديلات
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
