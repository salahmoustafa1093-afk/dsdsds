import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Wallet, TrendingUp, TrendingDown, Receipt,
  Plus, Filter, RotateCcw, X, Printer, Lock,
  Landmark, ChevronDown
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

/* ─── Mock Data ─── */
const kpi = {
  cashBalance: 156780,
  dailyRevenue: 45200,
  dailyExpenses: 28300,
  transactionsCount: 24,
};

const categories = [
  'مبيعات نقدية',
  'دفعات عملاء',
  'مصروفات تشغيل',
  'رواتب',
  'إيجارات',
  'نثرية',
  'أخرى',
];

const transactions = [
  { id: 1, number: 'TRX-001', date: '2025-01-15', type: 'قبض', amount: 15000, reason: 'دفعة عميل مزارع النور', category: 'دفعات عملاء', user: 'محمد أحمد', reference: 'INV-0015' },
  { id: 2, number: 'TRX-002', date: '2025-01-15', type: 'صرف', amount: 8500, reason: 'مصروفات تشغيل يومية', category: 'مصروفات تشغيل', user: 'أحمد علي', reference: 'EXP-0023' },
  { id: 3, number: 'TRX-003', date: '2025-01-15', type: 'قبض', amount: 22500, reason: 'مبيعات نقدية فرع القاهرة', category: 'مبيعات نقدية', user: 'محمود سالم', reference: 'CSH-0011' },
  { id: 4, number: 'TRX-004', date: '2025-01-14', type: 'صرف', amount: 32000, reason: 'رواتب موظفين يناير', category: 'رواتب', user: 'محمد أحمد', reference: 'SLR-0008' },
  { id: 5, number: 'TRX-005', date: '2025-01-14', type: 'قبض', amount: 18000, reason: 'دفعة مؤسسة الريف', category: 'دفعات عملاء', user: 'خالد عمر', reference: 'INV-0014' },
  { id: 6, number: 'TRX-006', date: '2025-01-14', type: 'صرف', amount: 12000, reason: 'إيجار مستودع الإسكندرية', category: 'إيجارات', user: 'محمد أحمد', reference: 'RNT-0005' },
  { id: 7, number: 'TRX-007', date: '2025-01-13', type: 'صرف', amount: 3500, reason: 'نثرية مصروفات', category: 'نثرية', user: 'يوسف إبراهيم', reference: 'PET-0012' },
  { id: 8, number: 'TRX-008', date: '2025-01-13', type: 'قبض', amount: 45000, reason: 'مبيعات نقدية جملة', category: 'مبيعات نقدية', user: 'أحمد علي', reference: 'CSH-0010' },
];

export default function AccountingTreasuryPage() {
  const [showForm, setShowForm] = useState(false);
  const [showClosing, setShowClosing] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterCategory, setFilterCategory] = useState('');

  /* form state */
  const [formType, setFormType] = useState('قبض');
  const [formAmount, setFormAmount] = useState('');
  const [formCategory, setFormCategory] = useState(categories[0]);
  const [formReason, setFormReason] = useState('');
  const [formReference, setFormReference] = useState('');
  const [formDate, setFormDate] = useState('2025-01-15');

  const filtered = transactions.filter((t) => {
    if (filterType && t.type !== filterType) return false;
    if (filterCategory && t.category !== filterCategory) return false;
    if (dateFrom && t.date < dateFrom) return false;
    if (dateTo && t.date > dateTo) return false;
    return true;
  });

  const openingBalance = 125000;
  const totalReceipts = filtered.filter((t) => t.type === 'قبض').reduce((s, t) => s + t.amount, 0);
  const totalPayments = filtered.filter((t) => t.type === 'صرف').reduce((s, t) => s + t.amount, 0);
  const closingBalance = openingBalance + totalReceipts - totalPayments;

  const handleAddTransaction = () => {
    setShowForm(false);
    setFormAmount('');
    setFormReason('');
    setFormReference('');
  };

  const resetFilters = () => {
    setDateFrom('');
    setDateTo('');
    setFilterType('');
    setFilterCategory('');
  };

  const statusBadge = (type: string) => (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
      type === 'قبض'
        ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400'
        : 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
    }`}>
      {type === 'قبض' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
      {type}
    </span>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="الخزينة / إدارة النقدية"
        subtitle="متابعة الرصيد النقدي وحركات الصرف والقبض"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الحسابات', path: '/accounting' },
          { label: 'الخزينة' },
        ]}
      >
        <button
          onClick={() => setShowClosing(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm font-medium text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard transition-colors"
        >
          <Lock size={16} />
          <span>إغلاق يومي</span>
        </button>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>إضافة حركة</span>
        </button>
      </PageHeader>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="الرصيد النقدي" value={formatCurrency(kpi.cashBalance)} icon={Wallet} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="إيرادات اليوم" value={formatCurrency(kpi.dailyRevenue)} change={12.5} icon={TrendingUp} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.1} />
        <KPICard title="مصروفات اليوم" value={formatCurrency(kpi.dailyExpenses)} change={-8.3} icon={TrendingDown} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.2} />
        <KPICard title="عدد الحركات" value={String(kpi.transactionsCount)} icon={Receipt} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.3} />
      </div>

      {/* Cash Register Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <Landmark size={18} className="text-green-600" />
          ملخص حركة الخزينة
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-center">
          <div className="p-4 rounded-lg bg-surface dark:bg-darkCard">
            <p className="text-xs text-textSecondary mb-1">الرصيد الافتتاحي</p>
            <p className="text-xl font-bold text-textPrimary dark:text-darkText">{formatCurrency(openingBalance)}</p>
          </div>
          <div className="p-4 rounded-lg bg-green-50 dark:bg-green-950/20">
            <p className="text-xs text-green-600 mb-1">إجمالي القبض</p>
            <p className="text-xl font-bold text-green-700 dark:text-green-400">+ {formatCurrency(totalReceipts)}</p>
          </div>
          <div className="p-4 rounded-lg bg-red-50 dark:bg-red-950/20">
            <p className="text-xs text-red-600 mb-1">إجمالي الصرف</p>
            <p className="text-xl font-bold text-red-700 dark:text-red-400">- {formatCurrency(totalPayments)}</p>
          </div>
          <div className="p-4 rounded-lg bg-amber-50 dark:bg-amber-950/20 border-2 border-amber-200 dark:border-amber-800">
            <p className="text-xs text-amber-600 mb-1">الرصيد الختامي</p>
            <p className="text-xl font-bold text-amber-700 dark:text-amber-400">{formatCurrency(closingBalance)}</p>
          </div>
        </div>
      </motion.div>

      {/* Filters */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 text-sm font-medium text-textPrimary dark:text-darkText mb-3"
        >
          <Filter size={16} />
          <span>فلترة الحركات</span>
          <ChevronDown size={14} className={`transition-transform ${showFilters ? 'rotate-180' : ''}`} />
        </button>
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2 border-t border-uiBorder dark:border-darkBorder">
                <div>
                  <label className="text-xs text-textSecondary mb-1 block">من تاريخ</label>
                  <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-full h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
                </div>
                <div>
                  <label className="text-xs text-textSecondary mb-1 block">إلى تاريخ</label>
                  <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-full h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
                </div>
                <div>
                  <label className="text-xs text-textSecondary mb-1 block">النوع</label>
                  <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="w-full h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="">الكل</option>
                    <option value="قبض">قبض</option>
                    <option value="صرف">صرف</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-textSecondary mb-1 block">الفئة</label>
                  <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="w-full h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="">الكل</option>
                    {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="flex items-end">
                  <button onClick={resetFilters} className="flex items-center gap-1 px-3 py-2 rounded-lg text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">
                    <RotateCcw size={14} />
                    <span>إعادة ضبط</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Transactions Table */}
      <DataTable
        title="سجل حركات الخزينة"
        columns={[
          { key: 'number', header: 'رقم الحركة', sortable: true },
          { key: 'date', header: 'التاريخ', sortable: true },
          { key: 'type', header: 'النوع', render: (row) => statusBadge(row.type as string) },
          { key: 'amount', header: 'المبلغ', render: (row) => <span className="font-medium">{formatCurrency(row.amount as number)}</span> },
          { key: 'category', header: 'الفئة', sortable: true },
          { key: 'reason', header: 'البيان', sortable: true },
          { key: 'reference', header: 'المرجع', sortable: true },
          { key: 'user', header: 'المستخدم', sortable: true },
        ]}
        data={filtered as unknown as Record<string, unknown>[]}
        pageSize={8}
      />

      {/* Add Transaction Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إضافة حركة خزينة</h3>
                <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">نوع الحركة</label>
                  <div className="flex gap-3">
                    {['قبض', 'صرف'].map((t) => (
                      <button
                        key={t}
                        onClick={() => setFormType(t)}
                        className={`flex-1 py-2 rounded-lg text-sm font-medium border transition-colors ${
                          formType === t
                            ? t === 'قبض'
                              ? 'bg-green-700 text-white border-green-700'
                              : 'bg-red-600 text-white border-red-600'
                            : 'border-uiBorder dark:border-darkBorder text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">المبلغ</label>
                  <input
                    type="number"
                    value={formAmount}
                    onChange={(e) => setFormAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  />
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">الفئة</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  >
                    {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">البيان</label>
                  <textarea
                    value={formReason}
                    onChange={(e) => setFormReason(e.target.value)}
                    rows={2}
                    className="w-full px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm resize-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">المرجع</label>
                    <input
                      type="text"
                      value={formReference}
                      onChange={(e) => setFormReference(e.target.value)}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">التاريخ</label>
                    <input
                      type="date"
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  إلغاء
                </button>
                <button
                  onClick={handleAddTransaction}
                  className={`px-4 py-2 rounded-lg text-white text-sm font-medium transition-colors ${
                    formType === 'قبض' ? 'bg-green-700 hover:bg-green-800' : 'bg-red-600 hover:bg-red-700'
                  }`}
                >
                  حفظ الحركة
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Daily Closing Modal */}
      <AnimatePresence>
        {showClosing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowClosing(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تقرير الإغلاق اليومي</h3>
                <button onClick={() => setShowClosing(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="text-center p-4 bg-amber-50 dark:bg-amber-950/20 rounded-lg">
                  <p className="text-sm text-amber-600 mb-1">تاريخ الإغلاق</p>
                  <p className="text-lg font-bold text-amber-700 dark:text-amber-400">15 يناير 2025</p>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-sm text-textSecondary">الرصيد الافتتاحي</span>
                    <span className="text-sm font-medium text-textPrimary dark:text-darkText">{formatCurrency(openingBalance)}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-sm text-textSecondary">إجمالي القبض</span>
                    <span className="text-sm font-medium text-green-600">{formatCurrency(totalReceipts)}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-sm text-textSecondary">إجمالي الصرف</span>
                    <span className="text-sm font-medium text-red-600">{formatCurrency(totalPayments)}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-sm text-textSecondary">عدد الحركات</span>
                    <span className="text-sm font-medium text-textPrimary dark:text-darkText">{filtered.length}</span>
                  </div>
                  <div className="flex justify-between py-3 bg-green-50 dark:bg-green-950/20 rounded-lg px-3">
                    <span className="text-sm font-semibold text-green-700 dark:text-green-400">الرصيد الختامي</span>
                    <span className="text-sm font-bold text-green-700 dark:text-green-400">{formatCurrency(closingBalance)}</span>
                  </div>
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowClosing(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors flex items-center gap-1">
                  <Printer size={14} />
                  طباعة
                </button>
                <button onClick={() => setShowClosing(false)} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors flex items-center gap-1">
                  <Lock size={14} />
                  تأكيد الإغلاق
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
