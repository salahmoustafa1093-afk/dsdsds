import { motion } from "framer-motion";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Legend
} from "recharts";
import {
  Crown, TrendingUp, TrendingDown, DollarSign, Package, Wallet,
  CreditCard, Receipt, Truck, AlertTriangle, AlertCircle, Info,
  Zap, Star, Building2, Gauge, Factory, Fuel, Car
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { ScrollArea } from "../components/ui/scroll-area";
import {
  execKPIs, salesTrend, salesByBranch, topCustomers, salesByCategory,
  branches, fleetSummary, productionSummary, alerts, aiRecommendations,
  branchRanking, cashFlowWeekly
} from "../data/execMockData";

const COLORS = ["#0a4a30", "#0d6b43", "#daa520", "#f0c040", "#b8860b"];

const fadeUp = { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.4 } };

export default function ExecutiveDashboard() {
  const kpiIcons = [
    DollarSign, DollarSign, DollarSign, Package, Wallet, CreditCard, Receipt, Truck
  ];
  const kpiColors = [
    "text-emerald-600", "text-emerald-700", "text-emerald-800",
    "text-amber-600", "text-blue-600", "text-purple-600", "text-red-600", "text-orange-600"
  ];

  return (
    <div className="p-6 space-y-6 bg-surface min-h-screen">
      {/* Header */}
      <motion.div {...fadeUp} className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
          <Crown className="w-6 h-6 text-gold" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-primary-dark">لوحة القيادة التنفيذية</h1>
          <p className="text-sm text-muted">مرحباً صلاح مصطفى — نظرة شاملة على أداء المجموعة</p>
        </div>
        <Badge className="mr-auto text-sm px-3 py-1" variant="secondary">
          {new Date().toLocaleDateString("ar-EG")}
        </Badge>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {execKPIs.map((kpi, i) => {
          const Icon = kpiIcons[i] || DollarSign;
          const color = kpiColors[i] || "text-primary";
          return (
            <motion.div key={kpi.label} {...fadeUp} transition={{ delay: i * 0.05, duration: 0.4 }}>
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <p className="text-xs text-muted">{kpi.label}</p>
                      <p className="text-xl font-bold text-primary-dark">{kpi.value}</p>
                    </div>
                    <div className={`p-2 rounded-lg bg-surface ${color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mt-2">
                    {kpi.trend === "up" ? <TrendingUp className="w-3 h-3 text-green-600" /> : <TrendingDown className="w-3 h-3 text-green-600" />}
                    <span className="text-xs text-green-600 font-medium">{kpi.change}</span>
                    <span className="text-xs text-muted">عن الشهر الماضي</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div {...fadeUp} transition={{ delay: 0.2 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" /> اتجاه المبيعات الشهرية
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={salesTrend}>
                  <defs>
                    <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0a4a30" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#0a4a30" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Area type="monotone" dataKey="sales" stroke="#0a4a30" fill="url(#salesGrad)" name="المبيعات (EGP M)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div {...fadeUp} transition={{ delay: 0.25 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Gauge className="w-4 h-4 text-primary" /> الربح الإجمالي vs الصافي
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={salesTrend}>
                  <defs>
                    <linearGradient id="grossGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#daa520" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#daa520" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0a4a30" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#0a4a30" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="sales" stroke="#daa520" fill="url(#grossGrad)" name="الإجمالي" />
                  <Area type="monotone" dataKey="profit" stroke="#0a4a30" fill="url(#netGrad)" name="الصافي" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div {...fadeUp} transition={{ delay: 0.3 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">المبيعات حسب الفرع</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={salesByBranch}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="sales" fill="#0a4a30" name="EGP M" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div {...fadeUp} transition={{ delay: 0.35 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">المبيعات حسب الفئة</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={salesByCategory} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name }) => name}>
                    {salesByCategory.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div {...fadeUp} transition={{ delay: 0.4 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">أفضل 10 عملاء</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={topCustomers} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                  <XAxis type="number" tick={{ fontSize: 11 }} />
                  <YAxis dataKey="name" type="category" tick={{ fontSize: 10 }} width={100} />
                  <Tooltip />
                  <Bar dataKey="sales" fill="#daa520" name="EGP M" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Branch Status + Fleet + Production */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Branch Status Grid */}
        <motion.div {...fadeUp} transition={{ delay: 0.45 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="w-4 h-4" /> حالة الفروع (16 فرع)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-60">
                <div className="grid grid-cols-2 gap-2">
                  {branches.map((b) => (
                    <div key={b.id} className="p-2 rounded-lg border border-border bg-surface/50">
                      <div className="flex items-center gap-2">
                        <div className={`w-2.5 h-2.5 rounded-full ${b.status === "active" ? "bg-green-500" : b.status === "warning" ? "bg-amber-500" : "bg-red-500"}`} />
                        <span className="text-xs font-medium">{b.name}</span>
                      </div>
                      <p className="text-[10px] text-muted mt-1">EGP {(b.todaySales / 1000).toFixed(0)}K · {b.staff} موظف</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>

        {/* Fleet Panel */}
        <motion.div {...fadeUp} transition={{ delay: 0.5 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Car className="w-4 h-4" /> لوحة الأسطول
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div className="p-2 rounded-lg bg-green-50 text-center">
                  <p className="text-lg font-bold text-green-700">{fleetSummary.totalVehicles}</p>
                  <p className="text-[10px] text-green-600">إجمالي المركبات</p>
                </div>
                <div className="p-2 rounded-lg bg-blue-50 text-center">
                  <p className="text-lg font-bold text-blue-700">{fleetSummary.activeTrips}</p>
                  <p className="text-[10px] text-blue-600">رحلات نشطة</p>
                </div>
                <div className="p-2 rounded-lg bg-amber-50 text-center">
                  <p className="text-lg font-bold text-amber-700">{fleetSummary.avgFuelConsumption}</p>
                  <p className="text-[10px] text-amber-600">L/100km</p>
                </div>
                <div className="p-2 rounded-lg bg-red-50 text-center">
                  <p className="text-lg font-bold text-red-700">{fleetSummary.maintenanceAlerts}</p>
                  <p className="text-[10px] text-red-600">تنبيهات صيانة</p>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1"><span>نسبة الاستغلال</span><span>{fleetSummary.utilizationRate}%</span></div>
                <Progress value={fleetSummary.utilizationRate} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Production Panel */}
        <motion.div {...fadeUp} transition={{ delay: 0.55 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Factory className="w-4 h-4" /> الإنتاج
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">خطوط التشغيل</span>
                <Badge variant={productionSummary.linesRunning >= 10 ? "success" : "warning"}>
                  {productionSummary.linesRunning}/{productionSummary.totalLines}
                </Badge>
              </div>
              <div className="p-2 rounded-lg bg-surface border border-border">
                <p className="text-xs text-muted">إنتاج اليوم</p>
                <p className="text-xl font-bold text-primary">{productionSummary.todayOutput.toLocaleString()} طن</p>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs"><span>معدل العائد</span><span>{productionSummary.yieldRate}%</span></div>
                <Progress value={productionSummary.yieldRate} className="h-2" />
                <div className="flex justify-between text-xs"><span>OEE</span><span>{productionSummary.oee}%</span></div>
                <Progress value={productionSummary.oee} className="h-2" />
              </div>
              <div className="p-2 rounded-lg bg-amber-50 flex items-center gap-2">
                <Fuel className="w-4 h-4 text-amber-600" />
                <span className="text-xs text-amber-700">توقف: {productionSummary.downtimeHours} ساعة</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Alerts + AI Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Live Alerts */}
        <motion.div {...fadeUp} transition={{ delay: 0.6 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" /> التنبيهات الحية
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {alerts.map((alert) => (
                    <div key={alert.id} className="flex items-start gap-2 p-2 rounded-lg bg-surface border border-border">
                      {alert.type === "danger" ? <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" /> :
                        alert.type === "warning" ? <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" /> :
                          <Info className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />}
                      <div className="flex-1">
                        <p className="text-xs">{alert.message}</p>
                        <p className="text-[10px] text-muted mt-0.5">{alert.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>

        {/* AI Recommendations */}
        <motion.div {...fadeUp} transition={{ delay: 0.65 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Zap className="w-4 h-4 text-gold" /> توصيات الذكاء الاصطناعي
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {aiRecommendations.map((rec) => (
                    <div key={rec.id} className="p-3 rounded-lg border border-gold/30 bg-gold/5">
                      <div className="flex items-start justify-between">
                        <h4 className="text-sm font-semibold">{rec.title}</h4>
                        <Badge variant="secondary" className="text-[10px]">{rec.confidence}% ثقة</Badge>
                      </div>
                      <p className="text-xs text-muted mt-1">{rec.desc}</p>
                      <p className="text-xs text-primary font-medium mt-1">التأثير: {rec.impact}</p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Branch Ranking + Cash Flow */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div {...fadeUp} transition={{ delay: 0.7 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Star className="w-4 h-4 text-gold" /> ترتيب الفروع
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="py-2 text-right">الفرع</th>
                      <th className="py-2 text-right">المبيعات</th>
                      <th className="py-2 text-right">الربح</th>
                      <th className="py-2 text-right">التدوير</th>
                    </tr>
                  </thead>
                  <tbody>
                    {branchRanking.map((b, i) => (
                      <tr key={b.name} className="border-b border-border/50">
                        <td className="py-2 font-medium">
                          <span className={`inline-block w-5 h-5 rounded-full text-center text-[10px] leading-5 ${i === 0 ? "bg-gold text-white" : i === 1 ? "bg-gray-300 text-gray-700" : i === 2 ? "bg-amber-600 text-white" : "bg-surface text-muted"}`}>{i + 1}</span>
                          <span className="mr-2">{b.name}</span>
                        </td>
                        <td className="py-2">{b.sales}M</td>
                        <td className="py-2">{b.profit}M</td>
                        <td className="py-2">{b.turnover}x</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div {...fadeUp} transition={{ delay: 0.75 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Wallet className="w-4 h-4 text-primary" /> التدفق النقدي الأسبوعي
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={cashFlowWeekly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                  <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="in" fill="#0a4a30" name="وارد" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="out" fill="#dc2626" name="صادر" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
