import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Star, Award, TrendingDown, ThumbsUp, ThumbsDown,
  Plus, X, Check, GitCompare, Shield
} from 'lucide-react';
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';

const ratingCriteria = [
  { name: 'الجودة', weight: 30 },
  { name: 'السعر', weight: 25 },
  { name: 'التسليم في الموعد', weight: 25 },
  { name: 'الخدمة', weight: 20 },
];

const suppliers = [
  { id: 1, name: 'شركة الأعلاف الكبرى', overall: 4.5, quality: 4.8, price: 3.8, delivery: 4.5, service: 4.2, recommend: true },
  { id: 2, name: 'مطاحن مصر الوسطى', overall: 4.2, quality: 4.5, price: 4.2, delivery: 3.8, service: 4.0, recommend: true },
  { id: 3, name: 'شركة النيل للحبوب', overall: 4.8, quality: 4.9, price: 4.0, delivery: 4.8, service: 4.7, recommend: true },
  { id: 4, name: 'مزارع الصعيد', overall: 3.5, quality: 3.2, price: 4.0, delivery: 3.0, service: 3.5, recommend: false },
  { id: 5, name: 'شركة الدلتا للمواد الخام', overall: 4.0, quality: 4.2, price: 3.5, delivery: 4.0, service: 3.8, recommend: true },
];

const radarData = [
  { criterion: 'الجودة', 'شركة النيل': 4.9, 'شركة الأعلاف': 4.8, 'مطاحن مصر': 4.5 },
  { criterion: 'السعر', 'شركة النيل': 4.0, 'شركة الأعلاف': 3.8, 'مطاحن مصر': 4.2 },
  { criterion: 'التسليم', 'شركة النيل': 4.8, 'شركة الأعلاف': 4.5, 'مطاحن مصر': 3.8 },
  { criterion: 'الخدمة', 'شركة النيل': 4.7, 'شركة الأعلاف': 4.2, 'مطاحن مصر': 4.0 },
];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          size={14}
          className={s <= Math.round(rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-300 dark:text-gray-600'}
        />
      ))}
      <span className="text-xs text-textSecondary mr-1">{rating}</span>
    </div>
  );
}

export default function SupplierRatingPage() {
  const [showForm, setShowForm] = useState(false);
  const [showCompare, setShowCompare] = useState(false);
  const [compareSupplier1, setCompareSupplier1] = useState(suppliers[0].id);
  const [compareSupplier2, setCompareSupplier2] = useState(suppliers[1].id);

  const [formSupplier, setFormSupplier] = useState(suppliers[0].id);
  const [formQuality, setFormQuality] = useState(3);
  const [formPrice, setFormPrice] = useState(3);
  const [formDelivery, setFormDelivery] = useState(3);
  const [formService, setFormService] = useState(3);
  const [formNotes, setFormNotes] = useState('');

  const excellentCount = suppliers.filter((s) => s.overall >= 4.5).length;
  const goodCount = suppliers.filter((s) => s.overall >= 3.5 && s.overall < 4.5).length;
  const acceptableCount = suppliers.filter((s) => s.overall >= 2.5 && s.overall < 3.5).length;
  const poorCount = suppliers.filter((s) => s.overall < 2.5).length;

  const s1 = suppliers.find((s) => s.id === compareSupplier1);
  const s2 = suppliers.find((s) => s.id === compareSupplier2);

  const handleAddEvaluation = () => {
    setShowForm(false);
    setFormQuality(3);
    setFormPrice(3);
    setFormDelivery(3);
    setFormService(3);
    setFormNotes('');
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="تقييم الموردين"
        subtitle="تقييم وتحليل أداء الموردين"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الموردين', path: '/suppliers' },
          { label: 'التقييم' },
        ]}
      >
        <button
          onClick={() => setShowCompare(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm font-medium text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard transition-colors"
        >
          <GitCompare size={16} />
          <span>مقارنة</span>
        </button>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>تقييم جديد</span>
        </button>
      </PageHeader>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
        <KPICard title="إجمالي الموردين" value={String(suppliers.length)} icon={Shield} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="ممتاز" value={String(excellentCount)} icon={Award} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.1} />
        <KPICard title="جيد" value={String(goodCount)} icon={ThumbsUp} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.2} />
        <KPICard title="مقبول" value={String(acceptableCount)} icon={TrendingDown} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.3} />
        <KPICard title="ضعيف" value={String(poorCount)} icon={ThumbsDown} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.4} />
      </div>

      {/* Rating Criteria */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {ratingCriteria.map((c, i) => (
          <motion.div
            key={c.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.05 * i }}
            className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
          >
            <div className="flex items-center justify-between mb-2">
              <Star size={18} className="text-amber-500" />
              <span className="text-lg font-bold text-amber-600">{c.weight}%</span>
            </div>
            <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{c.name}</h4>
          </motion.div>
        ))}
      </div>

      {/* Radar Chart + Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">مقارنة أفضل 3 موردين</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid />
              <PolarAngleAxis dataKey="criterion" tick={{ fontSize: 12 }} />
              <Radar name="شركة النيل" dataKey="شركة النيل" stroke="#14a86a" fill="#14a86a" fillOpacity={0.3} strokeWidth={2} />
              <Radar name="شركة الأعلاف" dataKey="شركة الأعلاف" stroke="#daa520" fill="#daa520" fillOpacity={0.3} strokeWidth={2} />
              <Radar name="مطاحن مصر" dataKey="مطاحن مصر" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} strokeWidth={2} />
              <Legend />
              <Tooltip />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <DataTable
            title="تقييم الموردين"
            columns={[
              { key: 'name', header: 'المورد', sortable: true },
              { key: 'overall', header: 'التقييم', render: (row) => <StarRating rating={row.overall as number} /> },
              { key: 'quality', header: 'الجودة', render: (row) => <span className="text-xs">{row.quality as number}/5</span> },
              { key: 'price', header: 'السعر', render: (row) => <span className="text-xs">{row.price as number}/5</span> },
              { key: 'delivery', header: 'التسليم', render: (row) => <span className="text-xs">{row.delivery as number}/5</span> },
              { key: 'service', header: 'الخدمة', render: (row) => <span className="text-xs">{row.service as number}/5</span> },
              { key: 'recommend', header: 'موصى به', render: (row) => (
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                  row.recommend ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400' : 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
                }`}>
                  {row.recommend ? 'نعم' : 'لا'}
                </span>
              ) },
            ]}
            data={suppliers as unknown as Record<string, unknown>[]}
            pageSize={5}
          />
        </motion.div>
      </div>

      {/* Add Evaluation Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تقييم مورد جديد</h3>
                <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">المورد</label>
                  <select value={formSupplier} onChange={(e) => setFormSupplier(Number(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                {[
                  { label: 'الجودة (30%)', value: formQuality, setter: setFormQuality },
                  { label: 'السعر (25%)', value: formPrice, setter: setFormPrice },
                  { label: 'التسليم (25%)', value: formDelivery, setter: setFormDelivery },
                  { label: 'الخدمة (20%)', value: formService, setter: setFormService },
                ].map((criterion) => (
                  <div key={criterion.label}>
                    <div className="flex justify-between mb-1">
                      <label className="text-sm text-textSecondary">{criterion.label}</label>
                      <span className="text-sm font-medium text-textPrimary dark:text-darkText">{criterion.value}/5</span>
                    </div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <button
                          key={s}
                          onClick={() => criterion.setter(s)}
                          className="flex-1 py-1 rounded-lg text-sm font-medium border transition-colors"
                          style={{
                            borderColor: s <= criterion.value ? '#daa520' : undefined,
                            backgroundColor: s <= criterion.value ? '#fef3c7' : undefined,
                            color: s <= criterion.value ? '#b8860b' : undefined,
                          }}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">ملاحظات</label>
                  <textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} rows={3} className="w-full px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm resize-none" />
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إلغاء</button>
                <button onClick={handleAddEvaluation} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors flex items-center gap-1">
                  <Check size={14} />
                  حفظ التقييم
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Comparison Modal */}
      <AnimatePresence>
        {showCompare && s1 && s2 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowCompare(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">مقارنة الموردين</h3>
                <button onClick={() => setShowCompare(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="text-xs text-textSecondary mb-1 block">المورد الأول</label>
                    <select value={compareSupplier1} onChange={(e) => setCompareSupplier1(Number(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-textSecondary mb-1 block">المورد الثاني</label>
                    <select value={compareSupplier2} onChange={(e) => setCompareSupplier2(Number(e.target.value))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                  </div>
                </div>
                <div className="space-y-3">
                  {[
                    { label: 'التقييم العام', key: 'overall' },
                    { label: 'الجودة', key: 'quality' },
                    { label: 'السعر', key: 'price' },
                    { label: 'التسليم', key: 'delivery' },
                    { label: 'الخدمة', key: 'service' },
                  ].map((item) => {
                    const v1 = s1[item.key as keyof typeof s1] as number;
                    const v2 = s2[item.key as keyof typeof s2] as number;
                    return (
                      <div key={item.key} className="grid grid-cols-3 gap-4 items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                        <div className="text-right">
                          <span className="text-sm font-medium text-textPrimary dark:text-darkText">{v1}</span>
                          <div className="w-full h-1.5 bg-surface dark:bg-darkCard rounded-full overflow-hidden mt-1">
                            <div className="h-full bg-green-500 rounded-full" style={{ width: `${(v1 / 5) * 100}%` }} />
                          </div>
                        </div>
                        <div className="text-center text-xs text-textSecondary font-semibold">{item.label}</div>
                        <div className="text-left">
                          <span className="text-sm font-medium text-textPrimary dark:text-darkText">{v2}</span>
                          <div className="w-full h-1.5 bg-surface dark:bg-darkCard rounded-full overflow-hidden mt-1">
                            <div className="h-full bg-amber-500 rounded-full" style={{ width: `${(v2 / 5) * 100}%` }} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="flex justify-center gap-8 mt-4">
                  <div className="text-center">
                    <StarRating rating={s1.overall} />
                    <p className="text-xs text-textMuted mt-1">{s1.name}</p>
                  </div>
                  <div className="text-center">
                    <StarRating rating={s2.overall} />
                    <p className="text-xs text-textMuted mt-1">{s2.name}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
