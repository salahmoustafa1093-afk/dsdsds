// @ts-nocheck
import { useState } from 'react';
import { DollarSign, TrendingDown, TrendingUp, PiggyBank, ArrowDown, ArrowUp } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts';

/* ─── Mock Data ─────────────────────────────────────── */
const costTrendData = [
  { month: 'أغسطس', avgCost: 4200, minCost: 3800, maxCost: 4800 },
  { month: 'سبتمبر', avgCost: 4350, minCost: 3950, maxCost: 4950 },
  { month: 'أكتوبر', avgCost: 4100, minCost: 3700, maxCost: 4700 },
  { month: 'نوفمبر', avgCost: 4500, minCost: 4000, maxCost: 5100 },
  { month: 'ديسمبر', avgCost: 4400, minCost: 3900, maxCost: 5000 },
  { month: 'يناير', avgCost: 4300, minCost: 3850, maxCost: 4900 },
];

const costBreakdownData = [
  { name: 'ذرة صفراء', value: 35, color: '#108a56' },
  { name: 'كسب فول صويا', value: 25, color: '#daa520' },
  { name: 'ردة قمح', value: 12, color: '#3b82f6' },
  { name: 'إضافات', value: 10, color: '#8b5cf6' },
  { name: 'عملية تصنيع', value: 8, color: '#14b8a6' },
  { name: 'تعبئة ونقل', value: 5, color: '#f59e0b' },
  { name: 'أخرى', value: 5, color: '#94a3b8' },
];

const formulaCosts = [
  { id: 1, formula: 'علف دواجن بادئ ٢٣٪', rawMaterialCost: 4100, laborCost: 280, overhead: 320, totalCost: 4700, costPerTon: 4850, lastUpdated: '١٥/٠١/٢٠٢٥', changeVsLast: -2.1 },
  { id: 2, formula: 'علف دواجن نامي ٢٠٪', rawMaterialCost: 3850, laborCost: 270, overhead: 310, totalCost: 4430, costPerTon: 4520, lastUpdated: '١٥/٠١/٢٠٢٥', changeVsLast: -1.5 },
  { id: 3, formula: 'علف أبقار جاف ١٤٪', rawMaterialCost: 3200, laborCost: 250, overhead: 290, totalCost: 3740, costPerTon: 3800, lastUpdated: '١٤/٠١/٢٠٢٥', changeVsLast: -3.2 },
  { id: 4, formula: 'علف تسمين عجول ١٦٪', rawMaterialCost: 3500, laborCost: 260, overhead: 300, totalCost: 4060, costPerTon: 4100, lastUpdated: '١٤/٠١/٢٠٢٥', changeVsLast: +0.8 },
  { id: 5, formula: 'علف أغنام ١٥٪', rawMaterialCost: 3350, laborCost: 250, overhead: 290, totalCost: 3890, costPerTon: 3950, lastUpdated: '١٣/٠١/٢٠٢٥', changeVsLast: -1.0 },
  { id: 6, formula: 'علف دواجن ناهي ١٨٪', rawMaterialCost: 3600, laborCost: 260, overhead: 300, totalCost: 4160, costPerTon: 4200, lastUpdated: '١٣/٠١/٢٠٢٥', changeVsLast: -2.5 },
  { id: 7, formula: 'علف أرانب ١٧٪', rawMaterialCost: 3750, laborCost: 270, overhead: 310, totalCost: 4330, costPerTon: 4300, lastUpdated: '١٢/٠١/٢٠٢٥', changeVsLast: +1.2 },
  { id: 8, formula: 'علف أحصنة ١٢٪', rawMaterialCost: 4500, laborCost: 300, overhead: 340, totalCost: 5140, costPerTon: 5200, lastUpdated: '١٢/٠١/٢٠٢٥', changeVsLast: +0.5 },
];

const COLORS = ['#108a56', '#daa520', '#3b82f6', '#8b5cf6', '#14b8a6', '#f59e0b', '#94a3b8'];

/* ─── Page ──────────────────────────────────────────── */
export default function FeedCostsPage() {
  const [range, setRange] = useState('6months');

  const avgCost = Math.round(formulaCosts.reduce((s, f) => s + f.costPerTon, 0) / formulaCosts.length);
  const minCost = Math.min(...formulaCosts.map(f => f.costPerTon));
  const maxCost = Math.max(...formulaCosts.map(f => f.costPerTon));
  const totalSaving = formulaCosts.reduce((s, f) => s + (f.changeVsLast < 0 ? Math.abs(f.changeVsLast) * f.costPerTon / 100 : 0), 0);

  const columns = [
    { key: 'formula', header: 'التركيبة', sortable: true },
    {
      key: 'rawMaterialCost',
      header: 'تكلفة الخامات',
      sortable: true,
      render: (row: Record<string, unknown>) => <span>{(row.rawMaterialCost as number).toLocaleString()} ج.م</span>,
    },
    {
      key: 'laborCost',
      header: 'العمالة',
      sortable: true,
      render: (row: Record<string, unknown>) => <span>{(row.laborCost as number).toLocaleString()} ج.م</span>,
    },
    {
      key: 'overhead',
      header: 'مصاريف عامة',
      sortable: true,
      render: (row: Record<string, unknown>) => <span>{(row.overhead as number).toLocaleString()} ج.م</span>,
    },
    {
      key: 'totalCost',
      header: 'إجمالي التكلفة',
      sortable: true,
      render: (row: Record<string, unknown>) => <span className="font-semibold">{(row.totalCost as number).toLocaleString()} ج.م</span>,
    },
    {
      key: 'costPerTon',
      header: 'تكلفة/طن',
      sortable: true,
      render: (row: Record<string, unknown>) => <span className="font-bold text-green-700 dark:text-green-400">{(row.costPerTon as number).toLocaleString()} ج.م</span>,
    },
    { key: 'lastUpdated', header: 'آخر تحديث', sortable: true },
    {
      key: 'changeVsLast',
      header: 'vs الشهر الماضي',
      sortable: true,
      render: (row: Record<string, unknown>) => {
        const val = row.changeVsLast as number;
        return (
          <span className={`inline-flex items-center gap-1 text-sm font-medium ${val < 0 ? 'text-green-600' : 'text-red-600'}`}>
            {val < 0 ? <ArrowDown size={14} /> : <ArrowUp size={14} />}
            {Math.abs(val)}%
          </span>
        );
      },
    },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="تحليل تكاليف الأعلاف" subtitle="تحليل ومقارنة تكاليف تركيبات الأعلاف" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الأعلاف' }, { label: 'تحليل التكاليف' }]}>
        <Button variant="outline" className="gap-1"><TrendingDown size={16} /> تصدير التقرير</Button>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="متوسط التكلفة/طن" value={`${avgCost.toLocaleString()} ج.م`} change={-1.8} icon={DollarSign} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="أقل تكلفة" value={`${minCost.toLocaleString()} ج.م`} icon={TrendingDown} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.1} />
        <KPICard title="أعلى تكلفة" value={`${maxCost.toLocaleString()} ج.م`} icon={TrendingUp} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.2} />
        <KPICard title="توفير الشهر" value={`${Math.round(totalSaving).toLocaleString()} ج.م`} change={+5.2} icon={PiggyBank} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.3} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-gray-800 dark:text-gray-100">اتجاه التكلفة (٦ أشهر)</h3>
            <Tabs value={range} onValueChange={setRange}><TabsList className="h-8"><TabsTrigger value="3months" className="text-[10px]">٣ شهور</TabsTrigger><TabsTrigger value="6months" className="text-[10px]">٦ شهور</TabsTrigger></TabsList></Tabs>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={costTrendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" />
              <YAxis />
              <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
              <Legend />
              <Line type="monotone" dataKey="avgCost" name="متوسط" stroke="#108a56" strokeWidth={3} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="minCost" name="الأقل" stroke="#3b82f6" strokeWidth={2} strokeDasharray="5 5" />
              <Line type="monotone" dataKey="maxCost" name="الأعلى" stroke="#ef4444" strokeWidth={2} strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <h3 className="text-base font-semibold mb-4 text-gray-800 dark:text-gray-100">تفاصيل التكلفة</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={costBreakdownData} cx="50%" cy="50%" outerRadius={100} dataKey="value" nameKey="name" label>
                {costBreakdownData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
              </Pie>
              <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Table */}
      <DataTable columns={columns} data={formulaCosts as unknown as Record<string, unknown>[]} title="تكاليف التركيبات" />
    </div>
  );
}
