// @ts-nocheck
import { useState } from 'react';
import { BarChart3, LineChart as LineChartIcon, Download, Calendar, TrendingUp, Clock } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell
} from 'recharts';

/* ─── Mock Data ─────────────────────────────────────── */
const dailyOutputData = [
  { day: '١', line1: 120, line2: 160, line3: 200 },
  { day: '٢', line1: 115, line2: 155, line3: 195 },
  { day: '٣', line1: 130, line2: 165, line3: 210 },
  { day: '٤', line1: 125, line2: 158, line3: 205 },
  { day: '٥', line1: 140, line2: 170, line3: 220 },
  { day: '٦', line1: 135, line2: 162, line3: 215 },
  { day: '٧', line1: 128, line2: 168, line3: 208 },
];

const oeeTrendData = [
  { day: '١', oee: 88, target: 90 },
  { day: '٢', oee: 90, target: 90 },
  { day: '٣', oee: 87, target: 90 },
  { day: '٤', oee: 92, target: 90 },
  { day: '٥', oee: 91, target: 90 },
  { day: '٦', oee: 89, target: 90 },
  { day: '٧', oee: 93, target: 90 },
];

const downtimeData = [
  { name: 'صيانة دورية', value: 35, color: '#108a56' },
  { name: 'أعطال مفاجئة', value: 25, color: '#daa520' },
  { name: 'تغيير منتج', value: 20, color: '#3b82f6' },
  { name: 'توقف لتغذية', value: 12, color: '#8b5cf6' },
  { name: 'أخرى', value: 8, color: '#94a3b8' },
];

const yieldByLineData = [
  { name: 'خط علف دواجن ١', planned: 500, actual: 485, yield: 97 },
  { name: 'خط علف أبقار ١', planned: 400, actual: 380, yield: 95 },
  { name: 'خط ردة ١', planned: 600, actual: 590, yield: 98.3 },
  { name: 'خط خلط مركز ١', planned: 80, actual: 76, yield: 95 },
  { name: 'خط Pelletizing ١', planned: 450, actual: 442, yield: 98.2 },
  { name: 'خط طحن صويا ١', planned: 200, actual: 198, yield: 99 },
];

const summaryData = [
  { id: 1, lineName: 'خط علف دواجن ١', plannedOutput: '٥٠٠ طن', actualOutput: '٤٨٥ طن', yield: 97, downtime: '٢.٥ ساعة', efficiency: '٩٤%' },
  { id: 2, lineName: 'خط علف أبقار ١', plannedOutput: '٤٠٠ طن', actualOutput: '٣٨٠ طن', yield: 95, downtime: '٤ ساعات', efficiency: '٩١%' },
  { id: 3, lineName: 'خط ردة ١', plannedOutput: '٦٠٠ طن', actualOutput: '٥٩٠ طن', yield: 98.3, downtime: '١.٥ ساعة', efficiency: '٩٦%' },
  { id: 4, lineName: 'خط خلط مركز ١', plannedOutput: '٨٠ طن', actualOutput: '٧٦ طن', yield: 95, downtime: '٣ ساعات', efficiency: '٩٠%' },
  { id: 5, lineName: 'خط Pelletizing ١', plannedOutput: '٤٥٠ طن', actualOutput: '٤٤٢ طن', yield: 98.2, downtime: '١ ساعة', efficiency: '٩٥%' },
  { id: 6, lineName: 'خط طحن صويا ١', plannedOutput: '٢٠٠ طن', actualOutput: '١٩٨ طن', yield: 99, downtime: '٠.٥ ساعة', efficiency: '٩٨%' },
];

const COLORS = ['#108a56', '#daa520', '#3b82f6', '#8b5cf6', '#94a3b8'];

/* ─── Page ──────────────────────────────────────────── */
export default function ProductionReportsPage() {
  const [range, setRange] = useState('week');

  const summaryColumns = [
    { key: 'lineName', header: 'الخط', sortable: true },
    { key: 'plannedOutput', header: 'المخطط', sortable: true },
    { key: 'actualOutput', header: 'الفعلي', sortable: true },
    {
      key: 'yield',
      header: 'الناتج %',
      sortable: true,
      render: (row: Record<string, unknown>) => (
        <span className={`font-medium ${(row.yield as number) >= 97 ? 'text-green-600' : (row.yield as number) >= 95 ? 'text-amber-600' : 'text-red-600'}`}>{row.yield}%</span>
      ),
    },
    { key: 'downtime', header: 'توقف', sortable: true },
    { key: 'efficiency', header: 'الكفاءة', sortable: true },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="تقارير وتحليلات الإنتاج"
        subtitle="تحليل شامل لأداء خطوط الإنتاج والكفاءة"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الإنتاج' }, { label: 'التقارير' }]}
      >
        <Button variant="outline" className="gap-1">
          <Download size={16} /> تصدير التقرير
        </Button>
      </PageHeader>

      {/* Date Range & KPI */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <Tabs value={range} onValueChange={setRange}>
          <TabsList>
            <TabsTrigger value="today" className="text-xs">اليوم</TabsTrigger>
            <TabsTrigger value="week" className="text-xs">أسبوع</TabsTrigger>
            <TabsTrigger value="month" className="text-xs">شهر</TabsTrigger>
            <TabsTrigger value="quarter" className="text-xs">ربع سنة</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Calendar size={14} />
          <span>١٥ يناير ٢٠٢٥ - ٢٢ يناير ٢٠٢٥</span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي الإنتاج" value="٤٬١٩١ طن" change={+5.2} icon={BarChart3} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="OEE متوسط" value="٩٢.٤%" change={+1.8} icon={TrendingUp} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.1} />
        <KPICard title="توقف إجمالي" value="١٢.٥ ساعة" change={-8} icon={Clock} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.2} />
        <KPICard title="الناتج المتوسط" value="٩٦.٨%" change={+0.5} icon={LineChartIcon} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.3} />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Daily Output Bar Chart */}
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <h3 className="text-base font-semibold mb-4 text-gray-800 dark:text-gray-100">الإنتاج اليومي حسب الخط (طن)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={dailyOutputData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="day" />
              <YAxis />
              <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
              <Legend />
              <Bar dataKey="line1" name="خط علف دواجن ١" fill="#108a56" radius={[4, 4, 0, 0]} />
              <Bar dataKey="line2" name="خط علف أبقار ١" fill="#daa520" radius={[4, 4, 0, 0]} />
              <Bar dataKey="line3" name="خط ردة ١" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* OEE Trend Line Chart */}
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <h3 className="text-base font-semibold mb-4 text-gray-800 dark:text-gray-100">مؤشر OEE (الكفاءة الشاملة)</h3>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={oeeTrendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="day" />
              <YAxis domain={[80, 100]} />
              <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
              <Legend />
              <Line type="monotone" dataKey="oee" name="OEE فعلي" stroke="#108a56" strokeWidth={3} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="target" name="الهدف" stroke="#daa520" strokeWidth={2} strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Downtime Pie Chart */}
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <h3 className="text-base font-semibold mb-4 text-gray-800 dark:text-gray-100">توزيع أسباب التوقف</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={downtimeData} cx="50%" cy="50%" outerRadius={100} dataKey="value" nameKey="name" label>
                {downtimeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Yield Comparison */}
        <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <h3 className="text-base font-semibold mb-4 text-gray-800 dark:text-gray-100">مقارنة الناتج حسب الخط</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={yieldByLineData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis type="number" domain={[0, 100]} />
              <YAxis dataKey="name" type="category" width={120} />
              <RechartsTooltip contentStyle={{ textAlign: 'right' }} />
              <Legend />
              <Bar dataKey="planned" name="المخطط" fill="#94a3b8" radius={[0, 4, 4, 0]} />
              <Bar dataKey="actual" name="الفعلي" fill="#108a56" radius={[0, 4, 4, 0]} />
              <Bar dataKey="yield" name="الناتج %" fill="#daa520" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Summary Table */}
      <DataTable
        columns={summaryColumns}
        data={summaryData as unknown as Record<string, unknown>[]}
        title="ملخص أداء الخطوط"
      />
    </div>
  );
}
