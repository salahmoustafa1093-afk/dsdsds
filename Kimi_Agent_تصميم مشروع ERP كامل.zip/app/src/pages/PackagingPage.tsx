// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Package, Plus, Search, X, CheckCircle2, Clock, AlertTriangle,
  TrendingUp, Factory, BarChart3, Wheat, ClipboardCheck,
  Pencil, Trash2, Eye, Settings2, Star, Thermometer, Droplets,
  Weight, Ruler, CircleCheck, CircleX,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

/* ─── mock data ─── */
const packagingLines = [
  { id: 1, name: 'خط الأرز', status: 'active', capacity: '15 طن/يوم', todayOutput: 12500, target: 15000, efficiency: 83, operator: 'أحمد خالد', product: 'أرز مصري' },
  { id: 2, name: 'خط العدس', status: 'active', capacity: '10 طن/يوم', todayOutput: 8200, target: 10000, efficiency: 82, operator: 'محمد سامي', product: 'عدس أصفر' },
  { id: 3, name: 'خط البقوليات', status: 'idle', capacity: '8 طن/يوم', todayOutput: 0, target: 8000, efficiency: 0, operator: '-', product: '-' },
];

const packagingOrders = [
  { id: 1, orderNo: 'PKG-2024-001', product: 'أرز مصري', packageType: '1 كجم', qty: 5000, completed: 4200, line: 'خط الأرز', status: 'قيد التنفيذ', customer: 'هايبر وان' },
  { id: 2, orderNo: 'PKG-2024-002', product: 'عدس أصفر', packageType: '½ كجم', qty: 3000, completed: 3000, line: 'خط العدس', status: 'مكتملة', customer: 'كارفور مصر' },
  { id: 3, orderNo: 'PKG-2024-003', product: 'فول مدمس', packageType: '400 غرام', qty: 8000, completed: 5600, line: 'خط البقوليات', status: 'قيد التنفيذ', customer: 'أولاد رجب' },
  { id: 4, orderNo: 'PKG-2024-004', product: 'حمص', packageType: '½ كجم', qty: 2500, completed: 2500, line: 'خط العدس', status: 'مكتملة', customer: 'سبينيس' },
  { id: 5, orderNo: 'PKG-2024-005', product: 'أرز مصري', packageType: '5 كجم', qty: 1500, completed: 300, line: 'خط الأرز', status: 'قيد التنفيذ', customer: 'خير زمان' },
  { id: 6, orderNo: 'PKG-2024-006', product: 'فول مدمس', packageType: '1 كجم', qty: 2000, completed: 0, line: 'خط البقوليات', status: 'مجدولة', customer: 'المنصور ماركت' },
  { id: 7, orderNo: 'PKG-2024-007', product: 'عدس أصفر', packageType: '1 كجم', qty: 4000, completed: 1800, line: 'خط العدس', status: 'قيد التنفيذ', customer: 'بنده مصر' },
  { id: 8, orderNo: 'PKG-2024-008', product: 'حمص', packageType: '1 كجم', qty: 3500, completed: 3500, line: 'خط البقوليات', status: 'مكتملة', customer: 'هايبر وان' },
  { id: 9, orderNo: 'PKG-2024-009', product: 'أرز مصري', packageType: '10 كجم', qty: 800, completed: 0, line: 'خط الأرز', status: 'مجدولة', customer: 'التعاون للغذاء' },
  { id: 10, orderNo: 'PKG-2024-010', product: 'فول مدمس', packageType: '½ كجم', qty: 6000, completed: 0, line: 'خط البقوليات', status: 'مجدولة', customer: 'الدليفرى' },
];

const dailyProduction = [
  { id: 1, date: '2024-12-19', line: 'خط الأرز', product: 'أرز مصري', output: 12500, rejects: 45, notes: 'عمل طبيعي' },
  { id: 2, date: '2024-12-19', line: 'خط العدس', product: 'عدس أصفر', output: 8200, rejects: 28, notes: 'تعديل بسيط في الوزن' },
  { id: 3, date: '2024-12-18', line: 'خط الأرز', product: 'أرز مصري', output: 14200, rejects: 38, notes: '' },
  { id: 4, date: '2024-12-18', line: 'خط العدس', product: 'عدس أصفر', output: 9500, rejects: 22, notes: '' },
  { id: 5, date: '2024-12-17', line: 'خط الأرز', product: 'أرز مصري', output: 13800, rejects: 52, notes: 'تغيير رول التعبئة' },
];

const efficiencyData = [
  { day: 'السبت', rice: 85, lentil: 80, pulses: 0 },
  { day: 'الأحد', rice: 88, lentil: 83, pulses: 0 },
  { day: 'الإثنين', rice: 86, lentil: 78, pulses: 0 },
  { day: 'الثلاثاء', rice: 90, lentil: 85, pulses: 0 },
  { day: 'الأربعاء', rice: 87, lentil: 82, pulses: 0 },
  { day: 'الخميس', rice: 89, lentil: 84, pulses: 0 },
  { day: 'الجمعة', rice: 83, lentil: 79, pulses: 0 },
];

const orderStatusStyles: Record<string, string> = {
  'مجدولة': 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
  'قيد التنفيذ': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'مكتملة': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'ملغاة': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

/* ─── helper components ─── */
function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${orderStatusStyles[status] || 'bg-gray-100 text-gray-700'}`}>
      {status === 'مكتملة' && <CheckCircle2 size={12} />}
      {status === 'قيد التنفيذ' && <Clock size={12} />}
      {status === 'مجدولة' && <Clock size={12} />}
      {status === 'ملغاة' && <X size={12} />}
      {status}
    </span>
  );
}

function LineStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    active: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
    idle: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
    maintenance: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-400',
  };
  const labels = { active: 'يعمل', idle: 'متوقف' };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status] || ''}`}>
      <CircleCheck size={12} /> {labels[status] || status}
    </span>
  );
}

function QualityChecklist() {
  const [checks, setChecks] = useState([
    { id: 1, label: 'وزن العبوة مطابق للمواصفات', checked: true },
    { id: 2, label: 'ختم العبوة محكم', checked: true },
    { id: 3, label: 'تاريخ الإنتاج وصلاحية واضح', checked: false },
    { id: 4, label: 'نظافة العبوة الخارجية', checked: true },
    { id: 5, label: 'الباركود مقروء وصحيح', checked: false },
  ]);

  const toggleCheck = (id: number) => {
    setChecks(checks.map(c => c.id === id ? { ...c, checked: !c.checked } : c));
  };

  const passed = checks.filter(c => c.checked).length;

  return (
    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
          <ClipboardCheck size={18} className="text-[#daa520]" /> قائمة فحص الجودة
        </h3>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${passed === checks.length ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
          {passed}/{checks.length} اجتاز
        </span>
      </div>
      <div className="space-y-2">
        {checks.map((check, i) => (
          <motion.div
            key={check.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.2, delay: i * 0.05 }}
            onClick={() => toggleCheck(check.id)}
            className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
              check.checked
                ? 'border-green-300 dark:border-green-700 bg-green-50 dark:bg-green-900/20'
                : 'border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard hover:border-amber-300'
            }`}
          >
            <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
              check.checked ? 'bg-green-500' : 'border-2 border-textMuted'
            }`}>
              {check.checked && <CheckCircle2 size={16} className="text-white" />}
            </div>
            <span className={`text-sm flex-1 ${check.checked ? 'font-medium text-green-800 dark:text-green-300' : 'text-textPrimary dark:text-darkText'}`}>
              {check.label}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ─── main page ─── */
export default function PackagingPage() {
  const [orders, setOrders] = useState(packagingOrders);
  const [entries, setEntries] = useState(dailyProduction);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showEntryModal, setShowEntryModal] = useState(false);
  const [showDetailOrder, setShowDetailOrder] = useState<any | null>(null);
  const [showEditOrder, setShowEditOrder] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('الكل');

  const [orderForm, setOrderForm] = useState({
    product: 'أرز مصري', packageType: '1 كجم', qty: '', line: 'خط الأرز', customer: '',
  });

  const [entryForm, setEntryForm] = useState({
    line: 'خط الأرز', product: '', output: '', rejects: '', notes: '',
  });

  const activeLines = packagingLines.filter(l => l.status === 'active').length;
  const todayProduction = packagingLines.reduce((s, l) => s + l.todayOutput, 0);
  const avgEfficiency = Math.round(packagingLines.filter(l => l.efficiency > 0).reduce((s, l) => s + l.efficiency, 0) / packagingLines.filter(l => l.efficiency > 0).length);
  const totalRejects = dailyProduction.reduce((s, d) => s + d.rejects, 0);

  const filteredOrders = orders.filter(o => {
    const matchSearch = o.orderNo.toLowerCase().includes(searchQuery.toLowerCase()) || o.product.includes(searchQuery) || o.customer.includes(searchQuery);
    const matchStatus = filterStatus === 'الكل' || o.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleCreateOrder = () => {
    if (!orderForm.qty || !orderForm.customer) return;
    const newOrder = {
      id: orders.length + 1,
      orderNo: `PKG-2024-${String(orders.length + 1).padStart(3, '0')}`,
      product: orderForm.product,
      packageType: orderForm.packageType,
      qty: Number(orderForm.qty),
      completed: 0,
      line: orderForm.line,
      status: 'مجدولة',
      customer: orderForm.customer,
    };
    setOrders([newOrder, ...orders]);
    setOrderForm({ product: 'أرز مصري', packageType: '1 كجم', qty: '', line: 'خط الأرز', customer: '' });
    setShowOrderModal(false);
  };

  const handleAddEntry = () => {
    if (!entryForm.product || !entryForm.output) return;
    const newEntry = {
      id: entries.length + 1,
      date: new Date().toISOString().split('T')[0],
      line: entryForm.line,
      product: entryForm.product,
      output: Number(entryForm.output),
      rejects: Number(entryForm.rejects) || 0,
      notes: entryForm.notes || '-',
    };
    setEntries([newEntry, ...entries]);
    setEntryForm({ line: 'خط الأرز', product: '', output: '', rejects: '', notes: '' });
    setShowEntryModal(false);
  };

  const handleDeleteOrder = (id: number) => {
    if (confirm('هل أنت متأكد من حذف أمر التعبئة؟')) {
      setOrders(orders.filter(o => o.id !== id));
    }
  };

  const orderColumns = [
    { key: 'orderNo', header: 'رقم الأمر', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'packageType', header: 'التعبئة', sortable: true, render: (row: any) => <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-xs font-medium">{row.packageType}</span> },
    { key: 'qty', header: 'الكمية', sortable: true, render: (row: any) => <span className="font-semibold">{row.qty.toLocaleString()}</span> },
    { key: 'line', header: 'الخط', sortable: true },
    { key: 'customer', header: 'العميل', sortable: true },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <StatusBadge status={row.status} /> },
    { key: 'progress', header: 'التقدم', sortable: false, render: (row: any) => (
      <div className="flex items-center gap-2">
        <div className="w-12 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div className="h-full bg-green-500 rounded-full" style={{ width: `${row.qty > 0 ? (row.completed / row.qty) * 100 : 0}%` }} />
        </div>
        <span className="text-xs">{Math.round(row.qty > 0 ? (row.completed / row.qty) * 100 : 0)}%</span>
      </div>
    )},
  ];

  const entryColumns = [
    { key: 'date', header: 'التاريخ', sortable: true },
    { key: 'line', header: 'الخط', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'output', header: 'الإنتاج', sortable: true, render: (row: any) => <span className="font-semibold text-green-600">{row.output.toLocaleString()}</span> },
    { key: 'rejects', header: 'الهالك', sortable: true, render: (row: any) => <span className="font-medium text-red-500">{row.rejects}</span> },
    { key: 'notes', header: 'ملاحظات', sortable: true },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="التعبئة والتغليف"
        subtitle="خطوط التعبئة وإنتاجية الأخط"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'التعبئة' }]}
      >
        <button
          onClick={() => setShowOrderModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all"
        >
          <Plus size={18} /> أمر تعبئة جديد
        </button>
        <button
          onClick={() => setShowEntryModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-uiBorder dark:border-darkBorder dark:bg-darkSurface text-textPrimary dark:text-darkText rounded-xl text-sm font-semibold hover:bg-surface dark:hover:bg-darkCard transition-all"
        >
          <BarChart3 size={18} /> تسجيل إنتاج
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="خطوط نشطة" value={String(activeLines)} icon={Factory} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-600" change={0} delay={0} />
        <KPICard title="إنتاج اليوم (كجم)" value={todayProduction.toLocaleString()} icon={Package} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-600" change={4.2} delay={0.1} />
        <KPICard title="كفاءة التعبئة" value={`${avgEfficiency}%`} icon={TrendingUp} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-600" change={1.8} delay={0.2} />
        <KPICard title="الهالك اليومي" value={String(totalRejects)} icon={AlertTriangle} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-600" change={-5} delay={0.3} />
      </div>

      {/* Packaging Lines */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <Factory size={18} className="text-[#0d6b43]" /> خطوط التعبئة
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {packagingLines.map((line) => (
            <motion.div
              key={line.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: line.id * 0.1 }}
              className="border border-uiBorder dark:border-darkBorder rounded-xl p-4 hover:shadow-md transition-all bg-surface/50 dark:bg-darkCard/50"
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-textPrimary dark:text-darkText">{line.name}</h4>
                <LineStatusBadge status={line.status} />
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-textSecondary">المنتج الحالي:</span><span className="font-medium">{line.product}</span></div>
                <div className="flex justify-between"><span className="text-textSecondary">السعة:</span><span className="font-medium">{line.capacity}</span></div>
                <div className="flex justify-between"><span className="text-textSecondary">المشغل:</span><span className="font-medium">{line.operator}</span></div>
                <div className="pt-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-textSecondary">الإنتاج اليوم</span>
                    <span className="font-semibold">{line.todayOutput.toLocaleString()} / {line.target.toLocaleString()}</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(line.todayOutput / line.target) * 100}%` }}
                      transition={{ duration: 1 }}
                      className="h-full bg-[#0d6b43] rounded-full"
                    />
                  </div>
                </div>
                <div className="flex justify-between text-xs pt-1">
                  <span className="text-textSecondary">الكفاءة</span>
                  <span className={`font-bold ${line.efficiency >= 80 ? 'text-green-600' : 'text-amber-600'}`}>{line.efficiency}%</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Efficiency Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <TrendingUp size={18} className="text-[#0d6b43]" /> كفاءة خطوط التعبئة
        </h3>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={efficiencyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="day" tick={{ fontSize: 12 }} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
            <Tooltip />
            <Line type="monotone" dataKey="rice" name="خط الأرز" stroke="#0d6b43" strokeWidth={2} dot={{ r: 4 }} />
            <Line type="monotone" dataKey="lentil" name="خط العدس" stroke="#daa520" strokeWidth={2} dot={{ r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Production Orders Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4 }}
      >
        <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
          <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
              <Package size={18} className="text-[#0d6b43]" /> أوامر التعبئة
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                <input
                  type="text" placeholder="بحث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-48 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
              >
                <option value="الكل">جميع الحالات</option>
                <option value="مجدولة">مجدولة</option>
                <option value="قيد التنفيذ">قيد التنفيذ</option>
                <option value="مكتملة">مكتملة</option>
              </select>
            </div>
          </div>
          <DataTable
            columns={orderColumns}
            data={filteredOrders}
            pageSize={8}
            searchable={false}
            rowActions={{
              onView: (row) => setShowDetailOrder(row),
              onEdit: (row) => setShowEditOrder({ ...row }),
              onDelete: (row) => handleDeleteOrder(row.id),
            }}
            emptyMessage="لا توجد أوامر تعبئة"
          />
        </div>
      </motion.div>

      {/* Daily Production + Quality Check */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.5 }}
        >
          <DataTable
            title="تسجيلات الإنتاج اليومية"
            columns={entryColumns}
            data={entries}
            pageSize={5}
            rowActions={{
              onDelete: (row) => { if (confirm('حذف التسجيل؟')) setEntries(entries.filter(e => e.id !== row.id)); },
            }}
            emptyMessage="لا توجد تسجيلات"
          />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.6 }}
        >
          <QualityChecklist />
        </motion.div>
      </div>

      {/* Create Order Modal */}
      <AnimatePresence>
        {showOrderModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowOrderModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">أمر تعبئة جديد</h3>
                <button onClick={() => setShowOrderModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                    <select
                      value={orderForm.product}
                      onChange={(e) => setOrderForm({ ...orderForm, product: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="أرز مصري">أرز مصري</option>
                      <option value="عدس أصفر">عدس أصفر</option>
                      <option value="فول مدمس">فول مدمس</option>
                      <option value="حمص">حمص</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">نوع التعبئة</label>
                    <select
                      value={orderForm.packageType}
                      onChange={(e) => setOrderForm({ ...orderForm, packageType: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="½ كجم">½ كجم</option>
                      <option value="1 كجم">1 كجم</option>
                      <option value="5 كجم">5 كجم</option>
                      <option value="10 كجم">10 كجم</option>
                      <option value="25 كجم">25 كجم</option>
                      <option value="50 كجم">50 كجم</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الكمية</label>
                    <input
                      type="number" placeholder="0"
                      value={orderForm.qty}
                      onChange={(e) => setOrderForm({ ...orderForm, qty: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الخط</label>
                    <select
                      value={orderForm.line}
                      onChange={(e) => setOrderForm({ ...orderForm, line: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="خط الأرز">خط الأرز</option>
                      <option value="خط العدس">خط العدس</option>
                      <option value="خط البقوليات">خط البقوليات</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">العميل</label>
                  <input
                    type="text" placeholder="اسم العميل"
                    value={orderForm.customer}
                    onChange={(e) => setOrderForm({ ...orderForm, customer: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <button
                  onClick={handleCreateOrder}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  إنشاء أمر التعبئة
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Entry Modal */}
      <AnimatePresence>
        {showEntryModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEntryModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تسجيل إنتاج يومي</h3>
                <button onClick={() => setShowEntryModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الخط</label>
                    <select
                      value={entryForm.line}
                      onChange={(e) => setEntryForm({ ...entryForm, line: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="خط الأرز">خط الأرز</option>
                      <option value="خط العدس">خط العدس</option>
                      <option value="خط البقوليات">خط البقوليات</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                    <input
                      type="text" placeholder="اسم المنتج"
                      value={entryForm.product}
                      onChange={(e) => setEntryForm({ ...entryForm, product: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الإنتاج (كجم)</label>
                    <input
                      type="number" placeholder="0"
                      value={entryForm.output}
                      onChange={(e) => setEntryForm({ ...entryForm, output: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الهالك</label>
                    <input
                      type="number" placeholder="0"
                      value={entryForm.rejects}
                      onChange={(e) => setEntryForm({ ...entryForm, rejects: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">ملاحظات</label>
                  <textarea
                    placeholder="أي ملاحظات..."
                    value={entryForm.notes}
                    onChange={(e) => setEntryForm({ ...entryForm, notes: e.target.value })}
                    className="w-full h-20 px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 resize-none"
                  />
                </div>
                <button
                  onClick={handleAddEntry}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التسجيل
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailOrder && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailOrder(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-md"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تفاصيل أمر التعبئة</h3>
                <button onClick={() => setShowDetailOrder(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-3">
                {[
                  { label: 'رقم الأمر', value: showDetailOrder.orderNo },
                  { label: 'المنتج', value: showDetailOrder.product },
                  { label: 'التعبئة', value: showDetailOrder.packageType },
                  { label: 'الكمية', value: showDetailOrder.qty.toLocaleString() },
                  { label: 'مكتمل', value: showDetailOrder.completed.toLocaleString() },
                  { label: 'الخط', value: showDetailOrder.line },
                  { label: 'العميل', value: showDetailOrder.customer },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-textSecondary text-sm">{item.label}</span>
                    <span className="font-semibold text-textPrimary">{item.value}</span>
                  </div>
                ))}
                <div className="py-2">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-textSecondary">نسبة الإنجاز</span>
                    <span className="font-semibold">{Math.round((showDetailOrder.completed / showDetailOrder.qty) * 100)}%</span>
                  </div>
                  <div className="w-full h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(showDetailOrder.completed / showDetailOrder.qty) * 100}%` }}
                      transition={{ duration: 0.8 }}
                      className="h-full bg-green-500 rounded-full"
                    />
                  </div>
                </div>
                <div className="pt-2">
                  <StatusBadge status={showDetailOrder.status} />
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {showEditOrder && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEditOrder(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تعديل أمر التعبئة</h3>
                <button onClick={() => setShowEditOrder(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                  <input
                    type="text"
                    value={showEditOrder.product}
                    onChange={(e) => setShowEditOrder({ ...showEditOrder, product: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الكمية</label>
                    <input
                      type="number"
                      value={showEditOrder.qty}
                      onChange={(e) => setShowEditOrder({ ...showEditOrder, qty: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">مكتمل</label>
                    <input
                      type="number"
                      value={showEditOrder.completed}
                      onChange={(e) => setShowEditOrder({ ...showEditOrder, completed: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الحالة</label>
                  <select
                    value={showEditOrder.status}
                    onChange={(e) => setShowEditOrder({ ...showEditOrder, status: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
                  >
                    <option value="مجدولة">مجدولة</option>
                    <option value="قيد التنفيذ">قيد التنفيذ</option>
                    <option value="مكتملة">مكتملة</option>
                  </select>
                </div>
                <button
                  onClick={() => { setOrders(orders.map(o => o.id === showEditOrder.id ? showEditOrder : o)); setShowEditOrder(null); }}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التعديلات
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
