import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line
} from 'recharts';
import {
  ShoppingCart, CalendarDays, CreditCard, TrendingUp,
  FileText, Play, Download
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

const dailySales = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  sales: Math.floor(200000 + Math.random() * 300000),
}));

const salesByChannel = [
  { name: 'القطاعي', value: 45, amount: 4025250, color: '#14a86a' },
  { name: 'الجملة', value: 30, amount: 2683500, color: '#daa520' },
  { name: 'الموزعين', value: 20, amount: 1789000, color: '#3b82f6' },
  { name: 'التصدير', value: 5, amount: 447250, color: '#8b5cf6' },
];

const topProducts = [
  { name: 'علف دواجن بادئ', sales: 1250000 },
  { name: 'علف دواجن نامي', sales: 980000 },
  { name: 'علف أبقار حلاب', sales: 850000 },
  { name: 'ذرة صفراء', sales: 720000 },
  { name: 'صويا مبشورة', sales: 650000 },
  { name: 'ردة خشنة', sales: 540000 },
  { name: 'كسب قطن', sales: 420000 },
  { name: 'أرز مصري', sales: 380000 },
  { name: 'علف ناعم', sales: 310000 },
  { name: 'مكملات غذائية', sales: 250000 },
];

const branchSales = [
  { name: 'القاهرة', sales: 3200000, target: 3000000 },
  { name: 'الإسكندرية', sales: 2100000, target: 2200000 },
  { name: 'طنطا', sales: 1800000, target: 1700000 },
  { name: 'المنصورة', sales: 1450000, target: 1500000 },
  { name: 'أسيوط', sales: 980000, target: 1200000 },
];

const customerRanking = [
  { name: 'مؤسسة الريف', sales: 850000, orders: 45, avgOrder: 18889 },
  { name: 'مزارع النور', sales: 620000, orders: 38, avgOrder: 16316 },
  { name: 'شركة الدلتا', sales: 580000, orders: 32, avgOrder: 18125 },
  { name: 'مؤسسة النيل', sales: 420000, orders: 28, avgOrder: 15000 },
  { name: 'مزرعة الذهبية', sales: 380000, orders: 25, avgOrder: 15200 },
];

const reportsList = [
  { id: 1, name: 'مبيعات يومية', description: 'تقرير المبيعات اليومية التفصيلي' },
  { id: 2, name: 'مبيعات عملاء', description: 'تحليل مبيعات كل عميل' },
  { id: 3, name: 'مبيعات منتجات', description: 'أداء كل منتج مبيعاتياً' },
  { id: 4, name: 'مبيعات فروع', description: 'مقارنة أداء الفروع' },
  { id: 5, name: 'عروض الأسعار', description: 'تقرير عروض الأسعار وتحويلها' },
];

export default function ReportsSalesPage() {
  const [selectedReport, setSelectedReport] = useState<number | null>(null);

  const totalSales = 8945000;
  const todaySales = 345678;
  const avgInvoice = 18400;
  const growth = 12.5;

  return (
    <div className="space-y-6">
      <PageHeader
        title="تقارير المبيعات"
        subtitle="تحليل المبيعات حسب القناة والمنتج والفرع والعميل"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'التقارير', path: '/reports' },
          { label: 'تقارير المبيعات' },
        ]}
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="إجمالي المبيعات" value={formatCurrency(totalSales)} icon={ShoppingCart} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="مبيعات اليوم" value={formatCurrency(todaySales)} icon={CalendarDays} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="متوسط الفاتورة" value={formatCurrency(avgInvoice)} icon={CreditCard} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="نسبة النمو" value={`${growth}%`} change={growth} icon={TrendingUp} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.3} />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Daily Sales Trend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">اتجاه المبيعات اليومية</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={dailySales}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="day" tick={{ fontSize: 11 }} />
              <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} tick={{ fontSize: 11 }} />
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Line type="monotone" dataKey="sales" name="المبيعات" stroke="#14a86a" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Sales by Channel Pie */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">المبيعات حسب القناة</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={salesByChannel} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
                {salesByChannel.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(_value, _name, props) => [`${props.payload.amount.toLocaleString('ar-EG')} ج.م`, props.payload.name]} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Top 10 Products */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">أفضل 10 منتجات مبيعاً</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={topProducts} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis type="number" tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} tick={{ fontSize: 11 }} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 11 }} width={100} />
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Bar dataKey="sales" name="المبيعات" fill="#daa520" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Branch Sales Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">مقارنة مبيعات الفروع</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={branchSales}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tickFormatter={(v) => `${(v / 1000000).toFixed(0)}M`} tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Legend />
              <Bar dataKey="sales" name="المبيعات الفعلية" fill="#14a86a" radius={[4, 4, 0, 0]} />
              <Bar dataKey="target" name="الهدف" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Customer Ranking Table */}
      <DataTable
        title="ترتيب العملاء"
        columns={[
          { key: 'name', header: 'العميل', sortable: true },
          { key: 'sales', header: 'المبيعات', sortable: true, render: (row) => <span className="font-medium text-green-600">{formatCurrency(row.sales as number)}</span> },
          { key: 'orders', header: 'عدد الطلبات', sortable: true },
          { key: 'avgOrder', header: 'متوسط الطلب', render: (row) => <span>{formatCurrency(row.avgOrder as number)}</span> },
        ]}
        data={customerRanking as unknown as Record<string, unknown>[]}
        pageSize={5}
      />

      {/* Reports List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.5 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">التقارير المتاحة</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {reportsList.map((report) => (
            <div
              key={report.id}
              className={`p-4 rounded-lg border transition-colors cursor-pointer ${
                selectedReport === report.id
                  ? 'border-green-500 bg-green-50 dark:bg-green-950/20'
                  : 'border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkCard'
              }`}
              onClick={() => setSelectedReport(report.id === selectedReport ? null : report.id)}
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <FileText size={18} className="text-green-700 dark:text-green-400" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{report.name}</h4>
                  <p className="text-xs text-textSecondary mt-0.5">{report.description}</p>
                </div>
                <div className="flex gap-1">
                  <button className="w-7 h-7 rounded flex items-center justify-center text-green-600 hover:bg-green-50 dark:hover:bg-green-950/30 transition-colors">
                    <Play size={14} />
                  </button>
                  <button className="w-7 h-7 rounded flex items-center justify-center text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">
                    <Download size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
