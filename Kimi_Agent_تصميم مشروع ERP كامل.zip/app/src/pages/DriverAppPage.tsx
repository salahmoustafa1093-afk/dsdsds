import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Truck,
  User,
  MapPin,
  Phone,
  Navigation,
  Camera,
  PenTool,
  Banknote,
  CreditCard,
  Landmark,
  Fuel,
  Wrench,
  Receipt,
  Plus,
  ChevronLeft,
  ChevronRight,
  Home,
  Package,
  CheckCircle2,
  Circle,
  Clock,
  WifiOff,
  Wifi,
  Check,
  X,
  Send,
  TrendingUp,
  Calendar,
  Power,
  AlertCircle,
  ScanLine,
  Image,
  Printer,
  ChevronDown,
  FileText,
  Settings,
  Route,
  BadgeCheck,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface Delivery {
  id: string;
  customer: string;
  phone: string;
  address: string;
  zone: string;
  products: { name: string; qty: number; unit: string }[];
  status: 'جديد' | 'قيد التحميل' | 'قيد التوصيل' | 'تم التسليم' | 'معلق';
  total: number;
  time: string;
}

interface DeliveryStep {
  id: number;
  label: string;
  icon: React.ElementType;
  done: boolean;
}

interface Expense {
  id: string;
  type: string;
  amount: number;
  notes: string;
  date: string;
}

/* ------------------------------------------------------------------ */
/*  Mock Data                                                          */
/* ------------------------------------------------------------------ */
const todayDeliveries: Delivery[] = [
  {
    id: 'DEL-2401',
    customer: 'شركة النيل للدواجن',
    phone: '01001234567',
    address: '45 شارع التحرير، مدينة نصر، القاهرة',
    zone: 'مدينة نصر',
    products: [
      { name: 'علف دواجن بادئ 25كجم', qty: 50, unit: 'شيكارة' },
      { name: 'علف ناهي 25كجم', qty: 30, unit: 'شيكارة' },
    ],
    status: 'قيد التوصيل',
    total: 42500,
    time: '09:30',
  },
  {
    id: 'DEL-2402',
    customer: 'مزرعة الصفوة',
    phone: '01119876543',
    address: 'طريق مصر إسكندرية الزراعي، ك 47، كفر الشيخ',
    zone: 'كفر الشيخ',
    products: [
      { name: 'ذرة صفراء مكسرة', qty: 100, unit: 'كجم' },
      { name: 'كسب صويا', qty: 75, unit: 'كجم' },
      { name: 'ردة ناعمة', qty: 50, unit: 'كجم' },
    ],
    status: 'قيد التحميل',
    total: 28700,
    time: '10:15',
  },
  {
    id: 'DEL-2403',
    customer: 'هايبر الهرم',
    phone: '01223456789',
    address: '12 شارع الهرم، الجيزة',
    zone: 'الهرم',
    products: [
      { name: 'بيض بلدي (كرتونة)', qty: 40, unit: 'كرتونة' },
      { name: 'أعلاف أرانب', qty: 20, unit: 'شيكارة' },
    ],
    status: 'جديد',
    total: 15300,
    time: '11:00',
  },
  {
    id: 'DEL-2404',
    customer: 'مؤسسة الرفاعي',
    phone: '01555667788',
    address: '78 شارع الجمهورية، طنطا، الغربية',
    zone: 'طنطا',
    products: [
      { name: 'علف بادي دواجن', qty: 100, unit: 'شيكارة' },
      { name: 'علف ناهي دواجن', qty: 60, unit: 'شيكارة' },
      { name: 'مكملات غذائية', qty: 25, unit: 'علبة' },
    ],
    status: 'تم التسليم',
    total: 67800,
    time: '08:00',
  },
  {
    id: 'DEL-2405',
    customer: 'شركة الخليج الزراعية',
    phone: '01098765432',
    address: 'منطقة الصناعات الغذائية، السادس من أكتوبر',
    zone: '6 أكتوبر',
    products: [
      { name: 'ذرة صفراء', qty: 500, unit: 'كجم' },
      { name: 'كسب صويا 48%', qty: 300, unit: 'كجم' },
    ],
    status: 'جديد',
    total: 92100,
    time: '12:00',
  },
];

const expenseTypes = [
  { value: 'وقود', icon: Fuel },
  { value: 'صيانة', icon: Wrench },
  { value: 'إيجار', icon: Receipt },
  { value: 'أخرى', icon: Plus },
];

/* ------------------------------------------------------------------ */
/*  Helper Components                                                  */
/* ------------------------------------------------------------------ */
function StatusBadge({ status }: { status: Delivery['status'] }) {
  const map: Record<string, string> = {
    'جديد': 'bg-blue-50 text-blue-700 border-blue-200',
    'قيد التحميل': 'bg-amber-50 text-amber-700 border-amber-200',
    'قيد التوصيل': 'bg-[#0d6b43]/10 text-[#0d6b43] border-[#0d6b43]/20',
    'تم التسليم': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'معلق': 'bg-red-50 text-red-700 border-red-200',
  };
  return (
    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${map[status] || ''}`}>
      {status}
    </span>
  );
}

function DeliveryStepper({ steps, onToggle }: { steps: DeliveryStep[]; onToggle: (id: number) => void }) {
  return (
    <div className="space-y-1">
      {steps.map((step, idx) => {
        const Icon = step.icon;
        const isLast = idx === steps.length - 1;
        return (
          <div key={step.id} className="flex items-start gap-3">
            <div className="flex flex-col items-center">
              <button
                onClick={() => onToggle(step.id)}
                className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                  step.done
                    ? 'bg-[#0d6b43] border-[#0d6b43] text-white'
                    : 'bg-white border-gray-300 text-gray-300'
                }`}
              >
                {step.done ? <Check size={14} /> : <Icon size={14} />}
              </button>
              {!isLast && (
                <div className={`w-0.5 h-6 ${step.done ? 'bg-[#0d6b43]' : 'bg-gray-200'}`} />
              )}
            </div>
            <div className="pt-1">
              <p className={`text-xs font-medium ${step.done ? 'text-[#0d6b43]' : 'text-gray-500'}`}>
                {step.label}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Page Component                                                */
/* ------------------------------------------------------------------ */
export default function DriverAppPage() {
  /* -- state -- */
  const [activeTab, setActiveTab] = useState<'home' | 'orders' | 'deliveries' | 'account'>('home');
  const [isOnline, setIsOnline] = useState(true);
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(null);
  const [deliverySteps, setDeliverySteps] = useState<DeliveryStep[]>([
    { id: 1, label: 'استلام الطلب', icon: Package, done: true },
    { id: 2, label: 'تحميل البضاعة', icon: Truck, done: true },
    { id: 3, label: 'التنقل للعميل', icon: Navigation, done: false },
    { id: 4, label: 'تسليم العميل', icon: CheckCircle2, done: false },
    { id: 5, label: 'التوقيع الرقمي', icon: PenTool, done: false },
    { id: 6, label: 'صورة الإيصال', icon: Camera, done: false },
    { id: 7, label: 'تحصيل المبلغ', icon: Banknote, done: false },
    { id: 8, label: 'إغلاق الطلب', icon: BadgeCheck, done: false },
  ]);
  const [deliveries, setDeliveries] = useState<Delivery[]>(todayDeliveries);
  const [expenses, setExpenses] = useState<Expense[]>([
    { id: 'EXP-001', type: 'وقود', amount: 350, notes: 'تعبئة بنزين', date: '2024-06-15' },
  ]);
  const [pendingSync, setPendingSync] = useState<string[]>(['تحديث حالة DEL-2401']);

  /* payment form */
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'نقدي' | 'شيك' | 'تحويل'>('نقدي');
  const [paymentRef, setPaymentRef] = useState('');

  /* expense form */
  const [expenseType, setExpenseType] = useState('وقود');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseNotes, setExpenseNotes] = useState('');

  /* current time */
  const [currentTime, setCurrentTime] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  /* -- actions -- */
  const toggleStep = (id: number) => {
    setDeliverySteps((prev) =>
      prev.map((s) => (s.id === id ? { ...s, done: !s.done } : s))
    );
  };

  const updateDeliveryStatus = (id: string, status: Delivery['status']) => {
    setDeliveries((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status } : d))
    );
    if (selectedDelivery?.id === id) {
      setSelectedDelivery((prev) => (prev ? { ...prev, status } : null));
    }
  };

  const submitPayment = () => {
    if (!paymentAmount) return;
    setDeliverySteps((prev) => prev.map((s) => (s.id === 7 ? { ...s, done: true } : s)));
    if (isOfflineMode) setPendingSync((p) => [...p, `تحصيل مبلغ ${paymentAmount} جنيه`]);
  };

  const addExpense = () => {
    if (!expenseAmount) return;
    const newExp: Expense = {
      id: `EXP-${String(expenses.length + 1).padStart(3, '0')}`,
      type: expenseType,
      amount: Number(expenseAmount),
      notes: expenseNotes,
      date: new Date().toISOString().split('T')[0],
    };
    setExpenses((p) => [newExp, ...p]);
    setExpenseAmount('');
    setExpenseNotes('');
    if (isOfflineMode) setPendingSync((p) => [...p, `مصروف ${expenseType}: ${expenseAmount} جنيه`]);
  };

  /* -- derived -- */
  const completedCount = deliveries.filter((d) => d.status === 'تم التسليم').length;
  const totalEarnings = deliveries
    .filter((d) => d.status === 'تم التسليم')
    .reduce((s, d) => s + d.total, 0);

  /* -- time formatter -- */
  const fmtTime = (d: Date) =>
    d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', hour12: false });
  const fmtDate = (d: Date) =>
    d.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  /* ================================================================== */
  /*  RENDER                                                            */
  /* ================================================================== */
  return (
    <div className="min-h-screen bg-[#f0f2f5] flex justify-center p-0 md:p-4">
      <div className="w-full max-w-[480px] bg-[#f8f9fa] min-h-[100dvh] md:min-h-0 md:rounded-3xl shadow-2xl overflow-hidden relative flex flex-col">
        <AnimatePresence mode="wait">
          {/* ====================== HOME TAB ======================*/}
          {activeTab === 'home' && !selectedDelivery && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col"
            >
              {/* -- Offline Banner -- */}
              <AnimatePresence>
                {isOfflineMode && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center gap-2"
                  >
                    <WifiOff size={14} className="text-amber-600 shrink-0" />
                    <p className="text-[11px] text-amber-700 font-medium">
                      أنت في وضع عدم الاتصال - سيتم المزامنة لاحقاً
                    </p>
                    {pendingSync.length > 0 && (
                      <Badge variant="warning" className="text-[10px] px-1.5 py-0">
                        {pendingSync.length}
                      </Badge>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* -- Header -- */}
              <div className="bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] text-white px-5 pt-6 pb-8 rounded-b-[28px] shadow-lg relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-full opacity-5">
                  <div className="absolute top-4 left-4 w-24 h-24 rounded-full border-[3px] border-white" />
                  <div className="absolute bottom-2 right-8 w-16 h-16 rounded-full border-[2px] border-white" />
                </div>
                <div className="relative flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm border border-white/30">
                      <User size={22} className="text-white" />
                    </div>
                    <div>
                      <p className="text-[10px] text-white/70">مرحباً بك</p>
                      <h2 className="text-sm font-bold">محمد علي أحمد</h2>
                      <p className="text-[10px] text-white/60 flex items-center gap-1">
                        <Truck size={10} /> السيارة: م ع أ 4521
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className="text-lg font-bold font-mono">{fmtTime(currentTime)}</p>
                    <p className="text-[10px] text-white/60">{fmtDate(currentTime)}</p>
                  </div>
                </div>
              </div>

              {/* -- Status Card -- */}
              <div className="px-4 -mt-4 relative z-10">
                <div className="bg-white rounded-2xl shadow-md p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isOnline ? 'bg-emerald-50' : 'bg-red-50'}`}>
                      <Power size={18} className={isOnline ? 'text-emerald-600' : 'text-red-500'} />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-gray-800">
                        {isOnline ? 'متصل - جاهز للطلبات' : 'غير متصل'}
                      </p>
                      <p className="text-[10px] text-gray-400">
                        {isOnline ? 'يتم استلام الطلبات الجديدة' : 'لن تصلك طلبات جديدة'}
                      </p>
                    </div>
                  </div>
                  <Switch checked={isOnline} onCheckedChange={setIsOnline} />
                </div>
              </div>

              {/* -- KPI Cards -- */}
              <div className="px-4 mt-4 grid grid-cols-3 gap-2">
                <div className="bg-white rounded-xl p-3 shadow-sm text-center">
                  <p className="text-xl font-bold text-[#0d6b43]">{deliveries.length}</p>
                  <p className="text-[10px] text-gray-500 mt-0.5">طلبات اليوم</p>
                </div>
                <div className="bg-white rounded-xl p-3 shadow-sm text-center">
                  <p className="text-xl font-bold text-emerald-600">{completedCount}</p>
                  <p className="text-[10px] text-gray-500 mt-0.5">تم التسليم</p>
                </div>
                <div className="bg-white rounded-xl p-3 shadow-sm text-center">
                  <p className="text-xl font-bold text-[#daa520]">{totalEarnings.toLocaleString()}</p>
                  <p className="text-[10px] text-gray-500 mt-0.5">التحصيل (ج.م)</p>
                </div>
              </div>

              {/* -- Deliveries List -- */}
              <div className="px-4 mt-5 flex-1 overflow-auto pb-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-gray-800">طلبات التوصيل</h3>
                  <button
                    onClick={() => setIsOfflineMode(!isOfflineMode)}
                    className="text-[10px] px-2 py-1 rounded-lg bg-gray-100 text-gray-500 hover:bg-gray-200 transition-colors"
                  >
                    {isOfflineMode ? <span className="flex items-center gap-1"><Wifi size={10} /> وضع متصل</span> : <span className="flex items-center gap-1"><WifiOff size={10} /> محاكاة عدم اتصال</span>}
                  </button>
                </div>

                <div className="space-y-3">
                  {deliveries.map((d, i) => (
                    <motion.div
                      key={d.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.08 }}
                      onClick={() => setSelectedDelivery(d)}
                      className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 active:scale-[0.98] transition-transform cursor-pointer"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="text-xs font-bold text-gray-800">{d.id}</p>
                            <StatusBadge status={d.status} />
                          </div>
                          <p className="text-xs font-semibold text-gray-600 mt-1">{d.customer}</p>
                        </div>
                        <div className="text-left">
                          <p className="text-[10px] text-gray-400 flex items-center gap-1">
                            <Clock size={10} /> {d.time}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-gray-500 mb-2">
                        <MapPin size={11} className="text-[#0d6b43] shrink-0" />
                        <span className="line-clamp-1">{d.address}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-[10px] text-gray-400">
                          {d.products.reduce((s, p) => s + p.qty, 0)} منتج
                        </p>
                        <p className="text-xs font-bold text-[#daa520]">{d.total.toLocaleString()} ج.م</p>
                      </div>
                      {/* Quick Actions */}
                      <div className="flex gap-2 mt-3 pt-2 border-t border-gray-50">
                        {d.status === 'جديد' && (
                          <>
                            <Button
                              size="sm"
                              className="flex-1 h-7 text-[11px] bg-[#0d6b43] hover:bg-[#0a4a30]"
                              onClick={(e) => { e.stopPropagation(); updateDeliveryStatus(d.id, 'قيد التحميل'); }}
                            >
                              <Check size={12} /> قبول
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="flex-1 h-7 text-[11px] border-red-200 text-red-600 hover:bg-red-50"
                              onClick={(e) => { e.stopPropagation(); updateDeliveryStatus(d.id, 'معلق'); }}
                            >
                              <X size={12} /> رفض
                            </Button>
                          </>
                        )}
                        {d.status === 'قيد التحميل' && (
                          <Button
                            size="sm"
                            className="flex-1 h-7 text-[11px] bg-[#0d6b43] hover:bg-[#0a4a30]"
                            onClick={(e) => { e.stopPropagation(); updateDeliveryStatus(d.id, 'قيد التوصيل'); }}
                          >
                            <Truck size={12} /> بدء التوصيل
                          </Button>
                        )}
                        {d.status === 'قيد التوصيل' && (
                          <Button
                            size="sm"
                            className="flex-1 h-7 text-[11px] bg-[#daa520] hover:bg-[#c9951f] text-white"
                            onClick={(e) => { e.stopPropagation(); setSelectedDelivery(d); setActiveTab('deliveries'); }}
                          >
                            <CheckCircle2 size={12} /> تأكيد التسليم
                          </Button>
                        )}
                        {d.status === 'تم التسليم' && (
                          <div className="flex items-center gap-1 text-emerald-600 text-[11px] font-medium">
                            <CheckCircle2 size={14} /> تم التسليم بنجاح
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* -- Pending Sync (offline) -- */}
                {isOfflineMode && pendingSync.length > 0 && (
                  <div className="mt-4 bg-amber-50 rounded-xl p-3 border border-amber-200">
                    <p className="text-[11px] font-bold text-amber-700 mb-2">بانتظار المزامنة</p>
                    <div className="space-y-1">
                      {pendingSync.map((item, i) => (
                        <div key={i} className="flex items-center gap-2 text-[10px] text-amber-600">
                          <Circle size={6} className="fill-amber-400" /> {item}
                        </div>
                      ))}
                    </div>
                    <Button
                      size="sm"
                      className="w-full mt-2 h-7 text-[11px] bg-[#0d6b43]"
                      onClick={() => { setPendingSync([]); setIsOfflineMode(false); }}
                    >
                      <Wifi size={12} /> مزامنة الآن
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* ====================== DELIVERY DETAIL ======================*/}
          {selectedDelivery && (
            <motion.div
              key="detail"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              className="flex-1 flex flex-col h-full"
            >
              {/* Detail Header */}
              <div className="bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] text-white px-4 pt-5 pb-6 rounded-b-[24px]">
                <button
                  onClick={() => setSelectedDelivery(null)}
                  className="flex items-center gap-1 text-white/80 text-xs mb-3 hover:text-white transition-colors"
                >
                  <ChevronRight size={16} /> رجوع
                </button>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-lg font-bold">{selectedDelivery.id}</p>
                    <p className="text-xs text-white/70 mt-0.5">{selectedDelivery.customer}</p>
                  </div>
                  <StatusBadge status={selectedDelivery.status} />
                </div>
              </div>

              <div className="flex-1 overflow-auto px-4 pb-4 -mt-2">
                {/* Customer Info Card */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">معلومات العميل</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <User size={13} className="text-[#0d6b43]" />
                      {selectedDelivery.customer}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <Phone size={13} className="text-[#0d6b43]" />
                      {selectedDelivery.phone}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <MapPin size={13} className="text-[#0d6b43]" />
                      {selectedDelivery.address}
                    </div>
                  </div>
                  <Button size="sm" className="w-full mt-3 h-8 text-[11px] bg-[#0d6b43]">
                    <Navigation size={12} /> فتح في خرائط Google
                  </Button>
                </div>

                {/* Map Placeholder */}
                <div className="bg-white rounded-xl shadow-sm mb-4 overflow-hidden">
                  <div className="h-36 bg-gradient-to-br from-[#e8f5e9] to-[#c8e6c9] relative flex items-center justify-center">
                    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 150">
                      <path d="M 50 120 Q 150 20, 250 80 T 380 40" stroke="#0d6b43" strokeWidth="2" fill="none" strokeDasharray="6 4" />
                      <circle cx="50" cy="120" r="8" fill="#0d6b43" />
                      <circle cx="380" cy="40" r="8" fill="#daa520" />
                    </svg>
                    <div className="absolute bottom-2 right-3 bg-white/90 rounded-lg px-2 py-1 text-[10px] font-medium text-gray-700">
                      المسافة: 12 كم | المتوقع: 25 دقيقة
                    </div>
                    <div className="absolute top-2 left-2 bg-[#0d6b43] text-white rounded-lg px-2 py-1 text-[10px] font-medium flex items-center gap-1">
                      <Navigation size={10} /> GPS متصل
                    </div>
                  </div>
                </div>

                {/* Products */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">المنتجات ({selectedDelivery.products.length})</h4>
                  <div className="space-y-2">
                    {selectedDelivery.products.map((p, i) => (
                      <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-[#0d6b43]/10 flex items-center justify-center">
                            <Package size={13} className="text-[#0d6b43]" />
                          </div>
                          <span className="text-xs font-medium text-gray-700">{p.name}</span>
                        </div>
                        <span className="text-xs font-bold text-gray-800">{p.qty} {p.unit}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-gray-100">
                    <span className="text-xs font-bold text-gray-600">الإجمالي</span>
                    <span className="text-sm font-bold text-[#daa520]">{selectedDelivery.total.toLocaleString()} ج.م</span>
                  </div>
                </div>

                {/* Delivery Steps Workflow */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">خطوات التوصيل</h4>
                  <DeliveryStepper steps={deliverySteps} onToggle={toggleStep} />
                </div>

                {/* Signature Placeholder */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">التوقيع الرقمي</h4>
                  <div className="h-28 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-2 bg-gray-50">
                    <PenTool size={24} className="text-gray-300" />
                    <p className="text-[11px] text-gray-400">اضغط للتوقيع هنا</p>
                  </div>
                </div>

                {/* Receipt Photo Placeholder */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">صورة الإيصال</h4>
                  <div className="h-28 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center gap-2 bg-gray-50">
                    <Camera size={24} className="text-gray-300" />
                    <p className="text-[11px] text-gray-400">اضغط لالتقاط صورة</p>
                  </div>
                </div>

                {/* Payment Collection */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h4 className="text-xs font-bold text-gray-800 mb-3">تحصيل المبلغ</h4>
                  <div className="space-y-3">
                    <div>
                      <label className="text-[11px] font-medium text-gray-500 mb-1 block">المبلغ المستحق</label>
                      <Input
                        value={selectedDelivery.total.toLocaleString()}
                        readOnly
                        className="h-9 text-xs bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-gray-500 mb-1 block">المبلغ المحصل</label>
                      <Input
                        type="number"
                        placeholder="أدخل المبلغ"
                        value={paymentAmount}
                        onChange={(e) => setPaymentAmount(e.target.value)}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-medium text-gray-500 mb-1 block">طريقة الدفع</label>
                      <div className="flex gap-2">
                        {(['نقدي', 'شيك', 'تحويل'] as const).map((m) => (
                          <button
                            key={m}
                            onClick={() => setPaymentMethod(m)}
                            className={`flex-1 h-9 rounded-lg text-[11px] font-medium border transition-all flex items-center justify-center gap-1 ${
                              paymentMethod === m
                                ? 'bg-[#0d6b43] text-white border-[#0d6b43]'
                                : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                            }`}
                          >
                            {m === 'نقدي' && <Banknote size={12} />}
                            {m === 'شيك' && <FileText size={12} />}
                            {m === 'تحويل' && <Landmark size={12} />}
                            {m}
                          </button>
                        ))}
                      </div>
                    </div>
                    {paymentMethod !== 'نقدي' && (
                      <div>
                        <label className="text-[11px] font-medium text-gray-500 mb-1 block">رقم المرجع</label>
                        <Input
                          placeholder="رقم الشيك أو التحويل"
                          value={paymentRef}
                          onChange={(e) => setPaymentRef(e.target.value)}
                          className="h-9 text-xs"
                        />
                      </div>
                    )}
                    <Button
                      className="w-full h-9 text-xs bg-[#daa520] hover:bg-[#c9951f] text-white"
                      onClick={submitPayment}
                    >
                      <CheckCircle2 size={14} /> تأكيد التحصيل
                    </Button>
                  </div>
                </div>

                {/* Close Order */}
                <Button
                  className="w-full h-11 text-sm font-bold bg-[#0a4a30] hover:bg-[#083d28] mb-4"
                  onClick={() => {
                    updateDeliveryStatus(selectedDelivery.id, 'تم التسليم');
                    setDeliverySteps((prev) => prev.map((s) => ({ ...s, done: true })));
                    setSelectedDelivery(null);
                  }}
                >
                  <BadgeCheck size={16} /> إغلاق الطلب
                </Button>
              </div>
            </motion.div>
          )}

          {/* ====================== ORDERS TAB ======================*/}
          {activeTab === 'orders' && (
            <motion.div
              key="orders"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col px-4 pt-5 overflow-auto pb-4"
            >
              <h2 className="text-base font-bold text-gray-800 mb-4">جميع الطلبات</h2>
              <div className="space-y-3">
                {deliveries.map((d, i) => (
                  <motion.div
                    key={d.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs font-bold">{d.id}</p>
                      <StatusBadge status={d.status} />
                    </div>
                    <p className="text-xs text-gray-600 mb-1">{d.customer}</p>
                    <div className="flex items-center gap-1 text-[10px] text-gray-400 mb-2">
                      <MapPin size={10} /> {d.zone}
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] text-gray-400">{d.time}</p>
                      <p className="text-xs font-bold text-[#daa520]">{d.total.toLocaleString()} ج.م</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* ====================== DELIVERIES TAB (GPS) ======================*/}
          {activeTab === 'deliveries' && (
            <motion.div
              key="deliveries"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col"
            >
              <div className="px-4 pt-5 pb-3">
                <h2 className="text-base font-bold text-gray-800">تتبع المسار</h2>
                <p className="text-[11px] text-gray-400">المسار الحالي للتوصيل</p>
              </div>

              {/* Large Map Placeholder */}
              <div className="mx-4 h-56 bg-gradient-to-br from-[#e8f5e9] to-[#c8e6c9] rounded-2xl shadow-sm relative overflow-hidden mb-4">
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 220">
                  {/* Road grid */}
                  <line x1="0" y1="50" x2="400" y2="50" stroke="#fff" strokeWidth="1" opacity="0.5" />
                  <line x1="0" y1="110" x2="400" y2="110" stroke="#fff" strokeWidth="1" opacity="0.5" />
                  <line x1="0" y1="170" x2="400" y2="170" stroke="#fff" strokeWidth="1" opacity="0.5" />
                  <line x1="100" y1="0" x2="100" y2="220" stroke="#fff" strokeWidth="1" opacity="0.5" />
                  <line x1="200" y1="0" x2="200" y2="220" stroke="#fff" strokeWidth="1" opacity="0.5" />
                  <line x1="300" y1="0" x2="300" y2="220" stroke="#fff" strokeWidth="1" opacity="0.5" />
                  {/* Route */}
                  <path d="M 80 180 Q 120 100, 200 80 T 340 40" stroke="#0d6b43" strokeWidth="3" fill="none" strokeDasharray="8 4" />
                  {/* Stops */}
                  <circle cx="80" cy="180" r="8" fill="#0d6b43" />
                  <circle cx="200" cy="80" r="6" fill="#daa520" />
                  <circle cx="340" cy="40" r="8" fill="#daa520" />
                </svg>
                {/* Current Location Marker */}
                <div className="absolute top-[45%] right-[30%] flex flex-col items-center">
                  <div className="w-10 h-10 bg-[#0d6b43] rounded-full flex items-center justify-center shadow-lg border-2 border-white">
                    <Truck size={18} className="text-white" />
                  </div>
                  <div className="w-2 h-2 bg-[#0d6b43] rounded-full mt-1 animate-ping" />
                </div>
                {/* Labels */}
                <div className="absolute bottom-3 right-3 bg-white/95 rounded-lg px-3 py-1.5 shadow-sm">
                  <p className="text-[10px] font-bold text-gray-700">الموقع الحالي</p>
                  <p className="text-[9px] text-gray-500">شارع التحرير، مدينة نصر</p>
                </div>
                <div className="absolute top-3 left-3 bg-[#daa520] text-white rounded-lg px-2 py-1 shadow-sm">
                  <p className="text-[10px] font-bold">ETA: 18 دقيقة</p>
                </div>
              </div>

              {/* Route Stops */}
              <div className="px-4 flex-1 overflow-auto pb-4">
                <h3 className="text-xs font-bold text-gray-700 mb-3">نقاط التوقف</h3>
                <div className="space-y-3">
                  {deliveries.filter(d => d.status !== 'تم التسليم').map((d, i) => (
                    <div key={d.id} className="bg-white rounded-xl p-3 shadow-sm flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#0d6b43]/10 flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-[#0d6b43]">{i + 1}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-gray-800 truncate">{d.customer}</p>
                        <p className="text-[10px] text-gray-400 truncate">{d.zone}</p>
                      </div>
                      <StatusBadge status={d.status} />
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* ====================== ACCOUNT TAB ======================*/}
          {activeTab === 'account' && (
            <motion.div
              key="account"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col overflow-auto pb-4"
            >
              {/* Profile Header */}
              <div className="bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] text-white px-5 pt-6 pb-10 rounded-b-[28px] text-center">
                <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-3 border-2 border-white/30">
                  <User size={36} className="text-white" />
                </div>
                <h2 className="text-base font-bold">محمد علي أحمد</h2>
                <p className="text-xs text-white/70 mt-1">سائق توصيل - فرع القاهرة</p>
                <div className="flex items-center justify-center gap-4 mt-3">
                  <div className="text-center">
                    <p className="text-lg font-bold">{completedCount}</p>
                    <p className="text-[10px] text-white/60">تسليمات</p>
                  </div>
                  <div className="w-px h-8 bg-white/20" />
                  <div className="text-center">
                    <p className="text-lg font-bold">4.8</p>
                    <p className="text-[10px] text-white/60">التقييم</p>
                  </div>
                  <div className="w-px h-8 bg-white/20" />
                  <div className="text-center">
                    <p className="text-lg font-bold">98%</p>
                    <p className="text-[10px] text-white/60">الالتزام</p>
                  </div>
                </div>
              </div>

              <div className="px-4 -mt-4 relative z-10 flex-1">
                {/* Stats Card */}
                <div className="bg-white rounded-xl p-4 shadow-md mb-4">
                  <h3 className="text-xs font-bold text-gray-800 mb-3">إحصائيات اليوم</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-gray-50 rounded-lg p-3 text-center">
                      <p className="text-lg font-bold text-[#daa520]">{totalEarnings.toLocaleString()}</p>
                      <p className="text-[10px] text-gray-500">إجمالي التحصيل</p>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3 text-center">
                      <p className="text-lg font-bold text-[#0d6b43]">{deliveries.length - completedCount}</p>
                      <p className="text-[10px] text-gray-500">المتبقي</p>
                    </div>
                  </div>
                </div>

                {/* Expenses Section */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h3 className="text-xs font-bold text-gray-800 mb-3">تسجيل مصروف</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">نوع المصروف</label>
                      <div className="flex gap-2 flex-wrap">
                        {expenseTypes.map((et) => (
                          <button
                            key={et.value}
                            onClick={() => setExpenseType(et.value)}
                            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-[11px] font-medium border transition-all ${
                              expenseType === et.value
                                ? 'bg-[#0d6b43] text-white border-[#0d6b43]'
                                : 'bg-white text-gray-600 border-gray-200'
                            }`}
                          >
                            <et.icon size={12} /> {et.value}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">المبلغ</label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={expenseAmount}
                        onChange={(e) => setExpenseAmount(e.target.value)}
                        className="h-9 text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 mb-1 block">ملاحظات</label>
                      <Textarea
                        placeholder="ملاحظات إضافية..."
                        value={expenseNotes}
                        onChange={(e) => setExpenseNotes(e.target.value)}
                        className="min-h-[60px] text-xs"
                      />
                    </div>
                    <Button
                      size="sm"
                      className="w-full h-8 text-[11px] bg-[#0d6b43]"
                      onClick={addExpense}
                    >
                      <Plus size={12} /> إضافة مصروف
                    </Button>
                  </div>
                </div>

                {/* Expenses List */}
                <div className="bg-white rounded-xl p-4 shadow-sm mb-4">
                  <h3 className="text-xs font-bold text-gray-800 mb-3">المصروفات اليوم</h3>
                  {expenses.length === 0 ? (
                    <p className="text-[11px] text-gray-400 text-center py-4">لا توجد مصروفات</p>
                  ) : (
                    <div className="space-y-2">
                      {expenses.map((e) => (
                        <div key={e.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-gray-100 flex items-center justify-center">
                              <Receipt size={12} className="text-gray-500" />
                            </div>
                            <div>
                              <p className="text-xs font-medium text-gray-700">{e.type}</p>
                              <p className="text-[9px] text-gray-400">{e.notes || '-'}</p>
                            </div>
                          </div>
                          <p className="text-xs font-bold text-gray-800">{e.amount} ج.م</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Vehicle Info */}
                <div className="bg-white rounded-xl p-4 shadow-sm">
                  <h3 className="text-xs font-bold text-gray-800 mb-3">معلومات المركبة</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500">رقم اللوحة</span>
                      <span className="font-bold text-gray-800">م ع أ 4521</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500">الموديل</span>
                      <span className="font-bold text-gray-800">نيسان كانتر 2022</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500">آخر صيانة</span>
                      <span className="font-bold text-gray-800">2024-06-01</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ====================== BOTTOM NAV ======================*/}
        <div className="shrink-0 bg-white border-t border-gray-100 px-2 py-1 flex items-center justify-around z-20">
          {[
            { key: 'home', label: 'الرئيسية', icon: Home },
            { key: 'orders', label: 'الطلبات', icon: Package },
            { key: 'deliveries', label: 'التسليمات', icon: Route },
            { key: 'account', label: 'الحساب', icon: User },
          ].map((item) => {
            const isActive = activeTab === item.key && !selectedDelivery;
            return (
              <button
                key={item.key}
                onClick={() => { setActiveTab(item.key as typeof activeTab); setSelectedDelivery(null); }}
                className={`flex flex-col items-center gap-0.5 py-2 px-3 rounded-xl transition-all ${
                  isActive ? 'text-[#0d6b43]' : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                <item.icon size={20} strokeWidth={isActive ? 2.5 : 1.5} />
                <span className={`text-[10px] font-medium ${isActive ? 'font-bold' : ''}`}>{item.label}</span>
                {isActive && <div className="w-1 h-1 rounded-full bg-[#0d6b43]" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
