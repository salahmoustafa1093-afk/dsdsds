// @ts-nocheck
import { useState } from 'react';
import {
  Palette, Eye, Pencil, Plus, CheckCircle2, Clock, Ban, FileText, Layers, Ruler, Droplet,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

/* ─── Types ─────────────────────────────────────────── */
interface PackageDesign {
  id: number;
  name: string;
  product: string;
  packageSize: string;
  lastModified: string;
  status: 'draft' | 'review' | 'approved' | 'old';
  approvedBy: string;
  dimensions: string;
  material: string;
  colors: string[];
  weight: number;
  labelPosition: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const designsData: PackageDesign[] = [
  { id: 1, name: 'تصميم أرز مصري ٥ كجم', product: 'أرز مصري', packageSize: '٥ كجم كيس', lastModified: '١٤/٠١/٢٠٢٥', status: 'approved', approvedBy: 'أحمد خالد', dimensions: '٢٥×١٥×٨ سم', material: 'PP مطبوع', colors: ['أخضر', 'ذهبي'], weight: 45, labelPosition: 'الواجهة الأمامية' },
  { id: 2, name: 'تصميم عدس أصفر ٢٥ كجم', product: 'عدس أصفر', packageSize: '٢٥ كجم شكاية', lastModified: '١٣/٠١/٢٠٢٥', status: 'approved', approvedBy: 'أحمد خالد', dimensions: '٤٠×٢٥×١٠ سم', material: 'PP منسوج', colors: ['أحمر', 'ذهبي'], weight: 120, labelPosition: 'الوسط' },
  { id: 3, name: 'تصميم فول مدمس ٥٠ كجم', product: 'فول مدمس', packageSize: '٥٠ كجم جوال', lastModified: '١٢/٠١/٢٠٢٥', status: 'review', approvedBy: '—', dimensions: '٦٠×٤٠×١٥ سم', material: 'PP منسوج سميك', colors: ['أزرق', 'أبيض'], weight: 280, labelPosition: 'الواجهة' },
  { id: 4, name: 'تصميم حمص ١ كجم', product: 'حمص', packageSize: '١ كجم سائب', lastModified: '١٠/٠١/٢٠٢٥', status: 'draft', approvedBy: '—', dimensions: '٢٠×١٢×٤ سم', material: 'OPP شفاف', colors: ['أخضر'], weight: 12, labelPosition: 'الخلف' },
  { id: 5, name: 'تصميم لوبيا ٥ كجم', product: 'لوبيا أبيض', packageSize: '٥ كجم كيس', lastModified: '٠٨/٠١/٢٠٢٥', status: 'approved', approvedBy: 'سارة محمود', dimensions: '٢٥×١٥×٨ سم', material: 'PP مطبوع', colors: ['أبيض', 'أخضر'], weight: 42, labelPosition: 'الواجهة الأمامية' },
  { id: 6, name: 'تصميم أرز عريض ٢٥ كجم', product: 'أرز عريض', packageSize: '٢٥ كجم شكاية', lastModified: '٠٥/٠١/٢٠٢٥', status: 'old', approvedBy: 'أحمد خالد', dimensions: '٤٠×٢٥×١٠ سم', material: 'PP منسوج', colors: ['ذهبي'], weight: 125, labelPosition: 'الوسط' },
  { id: 7, name: 'تصميم عدس أخضر ٥٠ كجم', product: 'عدس أخضر', packageSize: '٥٠ كجم جوال', lastModified: '٠٣/٠١/٢٠٢٥', status: 'review', approvedBy: '—', dimensions: '٦٠×٤٠×١٥ سم', material: 'PP منسوج سميك', colors: ['أخضر داكن', 'ذهبي'], weight: 275, labelPosition: 'الواجهة' },
  { id: 8, name: 'تصميم فول صغير ٥ كجم', product: 'فول صغير', packageSize: '٥ كجم كيس', lastModified: '٠١/٠١/٢٠٢٥', status: 'approved', approvedBy: 'سارة محمود', dimensions: '٢٥×١٥×٨ سم', material: 'PP مطبوع', colors: ['بني', 'ذهبي'], weight: 43, labelPosition: 'الواجهة الأمامية' },
];

const statusConfig: Record<string, { label: string; color: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof CheckCircle2 }> = {
  draft: { label: 'مسودة', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300', variant: 'secondary', icon: FileText },
  review: { label: 'قيد المراجعة', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400', variant: 'secondary', icon: Clock },
  approved: { label: 'معتمدة', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', variant: 'default', icon: CheckCircle2 },
  old: { label: 'قديمة', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', variant: 'destructive', icon: Ban },
};

const colorMap: Record<string, string> = {
  'أخضر': 'bg-green-500', 'ذهبي': 'bg-yellow-500', 'أحمر': 'bg-red-500', 'أزرق': 'bg-blue-500',
  'أبيض': 'bg-gray-200 border border-gray-300', 'بني': 'bg-amber-700', 'أخضر داكن': 'bg-green-800',
};

/* ─── Page ──────────────────────────────────────────── */
export default function PackagingDesignsPage() {
  const [filterStatus, setFilterStatus] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [detailDesign, setDetailDesign] = useState<PackageDesign | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', product: '', packageSize: '٥ كجم كيس', material: '', dimensions: '' });

  const draftCount = designsData.filter(d => d.status === 'draft').length;
  const reviewCount = designsData.filter(d => d.status === 'review').length;
  const approvedCount = designsData.filter(d => d.status === 'approved').length;
  const oldCount = designsData.filter(d => d.status === 'old').length;

  const filteredData = filterStatus === 'all' ? designsData : designsData.filter(d => d.status === filterStatus);

  const columns = [
    { key: 'name', header: 'اسم التصميم', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'packageSize', header: 'حجم العبوة', sortable: true },
    { key: 'lastModified', header: 'آخر تعديل', sortable: true },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: Record<string, unknown>) => {
        const cfg = statusConfig[row.status as string];
        const Icon = cfg.icon;
        return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}><Icon size={12} /> {cfg.label}</span>;
      },
    },
    { key: 'approvedBy', header: 'معتمد من', sortable: true },
  ];

  const openDetail = (d: PackageDesign) => { setDetailDesign(d); setIsDetailOpen(true); };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="إدارة تصاميم التعبئة" subtitle="تصاميم العبوات والتغليف للمنتجات" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'التعبئة' }, { label: 'التصاميم' }]}>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild><Button className="bg-green-700 hover:bg-green-800 text-white gap-1"><Plus size={16} /> تصميم جديد</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>إضافة تصميم تعبئة جديد</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-1.5"><Label>اسم التصميم</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="مثال: تصميم أرز مصري ١٠ كجم" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>المنتج</Label><Input value={formData.product} onChange={e => setFormData({ ...formData, product: e.target.value })} placeholder="اسم المنتج" /></div>
                <div className="space-y-1.5"><Label>حجم العبوة</Label>
                  <select value={formData.packageSize} onChange={e => setFormData({ ...formData, packageSize: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option>١ كجم سائب</option><option>٥ كجم كيس</option><option>٢٥ كجم شكاية</option><option>٥٠ كجم جوال</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>المادة</Label><Input value={formData.material} onChange={e => setFormData({ ...formData, material: e.target.value })} placeholder="PP، OPP..." /></div>
                <div className="space-y-1.5"><Label>الأبعاد</Label><Input value={formData.dimensions} onChange={e => setFormData({ ...formData, dimensions: e.target.value })} placeholder="٢٥×١٥×٨ سم" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2"><Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button><Button className="bg-green-700 hover:bg-green-800 text-white">حفظ التصميم</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="مسودة" value={String(draftCount)} icon={FileText} iconBg="bg-gray-100 dark:bg-gray-800" iconColor="text-gray-600 dark:text-gray-400" delay={0} />
        <KPICard title="قيد المراجعة" value={String(reviewCount)} icon={Clock} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.1} />
        <KPICard title="معتمدة" value={String(approvedCount)} change={+8} icon={CheckCircle2} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.2} />
        <KPICard title="قديمة" value={String(oldCount)} icon={Ban} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Gallery Grid */}
      <div>
        <h3 className="text-base font-semibold mb-3">معرض التصاميم</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {filteredData.map(design => (
            <button key={design.id} onClick={() => openDetail(design)} className="text-right bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4 hover:shadow-md transition-all cursor-pointer group">
              <div className="h-24 rounded-lg mb-3 flex items-center justify-center overflow-hidden" style={{ background: `linear-gradient(135deg, ${design.colors.map(c => c === 'أخضر' || c === 'أخضر داكن' ? '#108a56' : c === 'ذهبي' ? '#daa520' : c === 'أحمر' ? '#dc2626' : c === 'أزرق' ? '#2563eb' : c === 'بني' ? '#92400e' : '#f1f5f9').join(', ')})` }}>
                <Palette size={28} className="text-white/80" />
              </div>
              <p className="text-sm font-medium truncate">{design.name}</p>
              <p className="text-xs text-gray-500">{design.product} - {design.packageSize}</p>
              <div className="flex items-center gap-1 mt-2">
                <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium ${statusConfig[design.status].color}`}>{statusConfig[design.status].label}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Filters & Table */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4">
        <Tabs value={filterStatus} onValueChange={setFilterStatus}>
          <TabsList className="h-9"><TabsTrigger value="all" className="text-xs">الكل</TabsTrigger><TabsTrigger value="draft" className="text-xs">مسودة</TabsTrigger><TabsTrigger value="review" className="text-xs">قيد المراجعة</TabsTrigger><TabsTrigger value="approved" className="text-xs">معتمدة</TabsTrigger><TabsTrigger value="old" className="text-xs">قديمة</TabsTrigger></TabsList>
        </Tabs>
      </div>
      <DataTable columns={columns} data={filteredData as unknown as Record<string, unknown>[]} title="سجل التصاميم" rowActions={{ onView: (row) => openDetail(row as unknown as PackageDesign), onEdit: () => {}, onDelete: () => {} }} />

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader><DialogTitle>تفاصيل التصميم: {detailDesign?.name}</DialogTitle></DialogHeader>
          {detailDesign && (
            <div className="mt-4 space-y-4">
              <div className="h-32 rounded-xl flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${detailDesign.colors.map(c => c === 'أخضر' || c === 'أخضر داكن' ? '#108a56' : c === 'ذهبي' ? '#daa520' : c === 'أحمر' ? '#dc2626' : c === 'أزرق' ? '#2563eb' : c === 'بني' ? '#92400e' : '#f1f5f9').join(', ')})` }}>
                <Palette size={48} className="text-white/80" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block">المنتج</span><span className="font-semibold">{detailDesign.product}</span></div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block">حجم العبوة</span><span className="font-semibold">{detailDesign.packageSize}</span></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block flex items-center gap-1"><Ruler size={12} /> الأبعاد</span><span className="font-semibold">{detailDesign.dimensions}</span></div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block flex items-center gap-1"><Layers size={12} /> المادة</span><span className="font-semibold">{detailDesign.material}</span></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block flex items-center gap-1"><Droplet size={12} /> الألوان</span><div className="flex gap-1 mt-1">{detailDesign.colors.map(c => <span key={c} className={`w-5 h-5 rounded-full ${colorMap[c] || 'bg-gray-400'}`} title={c} />)}</div></div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block">وزن العبوة</span><span className="font-semibold">{detailDesign.weight} غرام</span></div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg"><span className="text-xs text-gray-500 block">موضع الملصق</span><span className="font-semibold">{detailDesign.labelPosition}</span></div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
