import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, PieChart, Pie, Cell, Legend
} from 'recharts';
import {
  TrendingUp, TrendingDown, DollarSign, Percent,
  Calendar, FileText, Download, Play
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import { formatCurrency } from '@/data/mockData';

/* ─── Mock Data ─── */
const plData = [
  { month: 'يناير', revenue: 8500000, costs: 6200000, profit: 2300000 },
  { month: 'فبراير', revenue: 7800000, costs: 5800000, profit: 2000000 },
  { month: 'مارس', revenue: 9200000, costs: 6500000, profit: 2700000 },
  { month: 'ابريل', revenue: 8100000, costs: 5900000, profit: 2200000 },
  { month: 'مايو', revenue: 9500000, costs: 6800000, profit: 2700000 },
  { month: 'يونيو', revenue: 8900000, costs: 6400000, profit: 2500000 },
];

const revenueTrend = [
  { month: 'يناير', revenue: 8500000 },
  { month: 'فبراير', revenue: 7800000 },
  { month: 'مارس', revenue: 9200000 },
  { month: 'ابريل', revenue: 8100000 },
  { month: 'مايو', revenue: 9500000 },
  { month: 'يونيو', revenue: 8900000 },
];

const costBreakdown = [
  { name: 'تكلفة البضاعة', value: 3500000, color: '#14a86a' },
  { name: 'مصاريف إدارية', value: 1200000, color: '#daa520' },
  { name: 'مصاريف بيعية', value: 950000, color: '#3b82f6' },
  { name: 'مصاريف تمويلية', value: 550000, color: '#f59e0b' },
];

const reportsList = [
  { id: 1, name: 'تقرير الدخل', description: 'تقرير شامل بالإيرادات والمصروفات وصافي الربح', lastGenerated: '2025-01-15', icon: FileText },
  { id: 2, name: 'الميزانية العمومية', description: 'الأصول والخصوم وحقوق الملكية', lastGenerated: '2025-01-10', icon: FileText },
  { id: 3, name: 'التدفقات النقدية', description: 'حركة النقدية من التشغيل والاستثمار والتمويل', lastGenerated: '2025-01-05', icon: FileText },
  { id: 4, name: 'أرباح وخسائر الفروع', description: 'مقارنة أداء الفروع المختلفة', lastGenerated: '2025-01-01', icon: FileText },
];

export default function ReportsFinancialPage() {
  const [dateFrom, setDateFrom] = useState('2025-01-01');
  const [dateTo, setDateTo] = useState('2025-06-30');
  const [selectedReport, setSelectedReport] = useState<number | null>(null);

  const totalRevenue = plData.reduce((s, d) => s + d.revenue, 0);
  const totalCosts = plData.reduce((s, d) => s + d.costs, 0);
  const netProfit = totalRevenue - totalCosts;
  const margin = ((netProfit / totalRevenue) * 100).toFixed(1);

  return (
    <div className="space-y-6">
      <PageHeader
        title="التقارير المالية"
        subtitle="تقارير الدخل والميزانية العمومية والتدفقات النقدية"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'التقارير', path: '/reports' },
          { label: 'التقارير المالية' },
        ]}
      />

      {/* Date Range */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4 flex flex-col sm:flex-row gap-3 items-center"
      >
        <Calendar size={18} className="text-green-600" />
        <span className="text-sm font-medium text-textPrimary dark:text-darkText">الفترة من</span>
        <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
        <span className="text-sm text-textSecondary">إلى</span>
        <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
      </motion.div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="الإيرادات" value={formatCurrency(totalRevenue)} icon={TrendingUp} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="التكاليف" value={formatCurrency(totalCosts)} icon={TrendingDown} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.1} />
        <KPICard title="صافي الربح" value={formatCurrency(netProfit)} icon={DollarSign} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.2} />
        <KPICard title="هامش الربح" value={`${margin}%`} icon={Percent} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.3} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* P&L Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">الإيرادات vs التكاليف vs الأرباح</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={plData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tickFormatter={(v) => `${(v / 1000000).toFixed(0)}M`} tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Legend />
              <Bar dataKey="revenue" name="الإيرادات" fill="#14a86a" radius={[4, 4, 0, 0]} />
              <Bar dataKey="costs" name="التكاليف" fill="#ef4444" radius={[4, 4, 0, 0]} />
              <Bar dataKey="profit" name="صافي الربح" fill="#daa520" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Revenue Trend Area Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">اتجاه الإيرادات</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={revenueTrend}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#14a86a" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#14a86a" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tickFormatter={(v) => `${(v / 1000000).toFixed(0)}M`} tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Area type="monotone" dataKey="revenue" name="الإيرادات" stroke="#14a86a" fillOpacity={1} fill="url(#revGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Cost Breakdown Pie Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">تحليل التكاليف</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={costBreakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {costBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Reports List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">التقارير المتاحة</h3>
          <div className="space-y-3">
            {reportsList.map((report) => (
              <div
                key={report.id}
                className={`p-4 rounded-lg border transition-colors cursor-pointer ${
                  selectedReport === report.id
                    ? 'border-green-500 bg-green-50 dark:bg-green-950/20'
                    : 'border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkCard'
                }`}
                onClick={() => setSelectedReport(report.id === selectedReport ? null : report.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                      <report.icon size={18} className="text-green-700 dark:text-green-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{report.name}</h4>
                      <p className="text-xs text-textSecondary mt-0.5">{report.description}</p>
                      <p className="text-[10px] text-textMuted mt-1">آخر إنشاء: {report.lastGenerated}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button className="w-8 h-8 rounded-lg flex items-center justify-center text-green-600 hover:bg-green-50 dark:hover:bg-green-950/30 transition-colors" title="تشغيل">
                      <Play size={14} />
                    </button>
                    <button className="w-8 h-8 rounded-lg flex items-center justify-center text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors" title="تحميل">
                      <Download size={14} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Preview Table */}
      {selectedReport && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">
            معاينة: {reportsList.find((r) => r.id === selectedReport)?.name}
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                  <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary">البيان</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary">القيمة</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary">النسبة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-uiBorder/50 dark:divide-darkBorder/30">
                <tr><td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">إجمالي الإيرادات</td><td className="px-4 py-3 text-sm font-medium text-green-600">{formatCurrency(totalRevenue)}</td><td className="px-4 py-3 text-sm text-textSecondary">100%</td></tr>
                <tr><td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">(-) تكلفة البضاعة المباعة</td><td className="px-4 py-3 text-sm font-medium text-red-600">{formatCurrency(3500000 * 6)}</td><td className="px-4 py-3 text-sm text-textSecondary">{(3500000 * 6 / totalRevenue * 100).toFixed(1)}%</td></tr>
                <tr><td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">(=) إجمالي الربح</td><td className="px-4 py-3 text-sm font-medium text-blue-600">{formatCurrency(totalRevenue - 3500000 * 6)}</td><td className="px-4 py-3 text-sm text-textSecondary">{((totalRevenue - 3500000 * 6) / totalRevenue * 100).toFixed(1)}%</td></tr>
                <tr><td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">(-) المصاريف التشغيلية</td><td className="px-4 py-3 text-sm font-medium text-red-600">{formatCurrency(2700000 * 6)}</td><td className="px-4 py-3 text-sm text-textSecondary">{(2700000 * 6 / totalRevenue * 100).toFixed(1)}%</td></tr>
                <tr className="bg-green-50 dark:bg-green-950/20">
                  <td className="px-4 py-3 text-sm font-bold text-green-700 dark:text-green-400">صافي الربح</td>
                  <td className="px-4 py-3 text-sm font-bold text-green-700 dark:text-green-400">{formatCurrency(netProfit)}</td>
                  <td className="px-4 py-3 text-sm font-bold text-green-700 dark:text-green-400">{margin}%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </motion.div>
      )}
    </div>
  );
}
