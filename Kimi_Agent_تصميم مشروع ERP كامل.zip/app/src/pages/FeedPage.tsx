// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FlaskConical, Plus, Search, X, CheckCircle2, AlertTriangle,
  TrendingUp, TrendingDown, DollarSign, Leaf, Beaker, ChevronDown,
  Wheat, Beef, Bird, CircleDollarSign, PieChart, Info, Edit3, Trash2, Eye,
  ChevronRight, Lock, Unlock,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { PieChart as RePieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

/* ─── NRC Standards ─── */
const nrcStandards = {
  'Broiler Starter': { protein: 23, energy: 3200, lysine: 1.1, methionine: 0.5, calcium: 1.0, phosphorus: 0.45 },
  'Broiler Finisher': { protein: 18, energy: 3200, lysine: 0.85, methionine: 0.38, calcium: 0.9, phosphorus: 0.35 },
  'Layer': { protein: 16, energy: 2850, lysine: 0.75, methionine: 0.36, calcium: 3.4, phosphorus: 0.28 },
  'Cattle': { protein: 14, energy: 2800, lysine: 0.65, methionine: 0.25, calcium: 0.6, phosphorus: 0.3 },
  'Sheep': { protein: 12, energy: 2600, lysine: 0.6, methionine: 0.2, calcium: 0.45, phosphorus: 0.3 },
};

/* ─── mock data ─── */
const feedFormulas = [
  { id: 1, name: 'علاف دواجن ناشئة', targetAnimal: 'دواجن', stage: 'Starter', protein: 23.0, energy: 3200, costPerTon: 2850, status: 'نشطة', nrcKey: 'Broiler Starter', ingredients: [{ name: 'ذرة صفراء', percent: 55 }, { name: 'فول صويا', percent: 28 }, { name: 'مسحوق سمك', percent: 5 }, { name: 'دهن دواجن', percent: 3 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 1.2 }, { name: 'فوسفات', percent: 1.5 }, { name: 'بريمكس', percent: 0.5 }, { name: 'مضاد سموم', percent: 0.1 }, { name: 'إنزيمات', percent: 0.2 }] },
  { id: 2, name: 'علاف دواجن نامية', targetAnimal: 'دواجن', stage: 'Grower', protein: 20.5, energy: 3150, costPerTon: 2700, status: 'نشطة', nrcKey: 'Broiler Starter', ingredients: [{ name: 'ذرة صفراء', percent: 60 }, { name: 'فول صويا', percent: 22 }, { name: 'مسحوق سمك', percent: 4 }, { name: 'دهن دواجن', percent: 3.5 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 1.0 }, { name: 'فوسفات', percent: 1.3 }, { name: 'بريمكس', percent: 0.5 }, { name: 'مضاد سموم', percent: 0.1 }, { name: 'إنزيمات', percent: 0.1 }] },
  { id: 3, name: 'علاف دواجن نهائية', targetAnimal: 'دواجن', stage: 'Finisher', protein: 18.0, energy: 3200, costPerTon: 2550, status: 'نشطة', nrcKey: 'Broiler Finisher', ingredients: [{ name: 'ذرة صفراء', percent: 65 }, { name: 'فول صويا', percent: 18 }, { name: 'مسحوق سمك', percent: 3 }, { name: 'دهن دواجن', percent: 4 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 0.8 }, { name: 'فوسفات', percent: 1.1 }, { name: 'بريمكس', percent: 0.4 }, { name: 'مضاد سموم', percent: 0.1 }, { name: 'إنزيمات', percent: 0.1 }] },
  { id: 4, name: 'علاف طيور بياضة', targetAnimal: 'دواجن', stage: 'Layer', protein: 16.5, energy: 2850, costPerTon: 2450, status: 'نشطة', nrcKey: 'Layer', ingredients: [{ name: 'ذرة صفراء', percent: 58 }, { name: 'فول صويا', percent: 20 }, { name: 'مسحوق سمك', percent: 3 }, { name: 'دهن دواجن', percent: 2.5 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 4.2 }, { name: 'فوسفات', percent: 1.0 }, { name: 'بريمكس', percent: 0.5 }, { name: 'مضاد سموم', percent: 0.1 }, { name: 'إنزيمات', percent: 0.2 }] },
  { id: 5, name: 'علاف أبقار حلابة', targetAnimal: 'أبقار', stage: 'Lactating', protein: 16.0, energy: 3000, costPerTon: 2200, status: 'نشطة', nrcKey: 'Cattle', ingredients: [{ name: 'ذرة صفراء', percent: 40 }, { name: 'دريس برسيم', percent: 25 }, { name: 'فول صويا', percent: 15 }, { name: 'ردة قمح', percent: 10 }, { name: 'كسب بذرة قطن', percent: 5 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 1.0 }, { name: 'فوسفات', percent: 0.8 }, { name: 'بريمكس أبقار', percent: 0.5 }, { name: 'خميرة', percent: 0.2 }] },
  { id: 6, name: 'علاف عجول تسمين', targetAnimal: 'أبقار', stage: 'Fattening', protein: 14.5, energy: 2900, costPerTon: 2100, status: 'نشطة', nrcKey: 'Cattle', ingredients: [{ name: 'ذرة صفراء', percent: 45 }, { name: 'دريس برسيم', percent: 20 }, { name: 'فول صويا', percent: 12 }, { name: 'ردة قمح', percent: 12 }, { name: 'كسب بذرة قطن', percent: 6 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 0.8 }, { name: 'فوسفات', percent: 0.8 }, { name: 'بريمكس عجول', percent: 0.4 }, { name: 'خميرة', percent: 0.2 }] },
  { id: 7, name: 'علاف أغنام ناشئة', targetAnimal: 'أغنام', stage: 'Starter', protein: 16.0, energy: 2650, costPerTon: 2300, status: 'غير نشطة', nrcKey: 'Sheep', ingredients: [{ name: 'شعير', percent: 35 }, { name: 'ذرة صفراء', percent: 25 }, { name: 'فول صويا', percent: 18 }, { name: 'دريس', percent: 12 }, { name: 'كسب بذرة قطن', percent: 5 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 0.8 }, { name: 'فوسفات', percent: 0.8 }, { name: 'بريمكس أغنام', percent: 0.4 }, { name: 'فيتامينات', percent: 0.2 }] },
  { id: 8, name: 'علاف جاموس حلاب', targetAnimal: 'جاموس', stage: 'Lactating', protein: 15.5, energy: 2950, costPerTon: 2150, status: 'نشطة', nrcKey: 'Cattle', ingredients: [{ name: 'ذرة صفراء', percent: 42 }, { name: 'دريس برسيم', percent: 22 }, { name: 'فول صويا', percent: 14 }, { name: 'ردة قمح', percent: 12 }, { name: 'كسب بذرة قطن', percent: 5 }, { name: 'ملح طعام', percent: 0.5 }, { name: 'كربونات كالسيوم', percent: 1.0 }, { name: 'فوسفات', percent: 0.8 }, { name: 'بريمكس جاموس', percent: 0.5 }, { name: 'خميرة', percent: 0.2 }] },
];

const monthlySavings = [
  { month: 'يوليو', target: 180000, actual: 195000 },
  { month: 'أغسطس', target: 185000, actual: 192000 },
  { month: 'سبتمبر', target: 190000, actual: 188000 },
  { month: 'أكتوبر', target: 195000, actual: 205000 },
  { month: 'نوفمبر', target: 200000, actual: 212000 },
  { month: 'ديسمبر', target: 205000, actual: 198000 },
];

const COLORS = ['#0d6b43', '#daa520', '#0a4a30', '#e5a220', '#2d8a5e', '#c9941a', '#1a6b4a', '#f0c040'];

/* ─── helper components ─── */
function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
      status === 'نشطة'
        ? 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400'
        : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
    }`}>
      {status === 'نشطة' ? <CheckCircle2 size={12} /> : <AlertTriangle size={12} />}
      {status}
    </span>
  );
}

function NRCComparison({ formula }: { formula: any }) {
  const nrc = nrcStandards[formula.nrcKey];
  if (!nrc) return null;

  const items = [
    { label: 'البروتين %', actual: formula.protein, target: nrc.protein, unit: '%' },
    { label: 'الطاقة', actual: formula.energy, target: nrc.energy, unit: 'kcal/kg' },
    { label: 'اللايسين', actual: nrc.lysine, target: nrc.lysine, unit: '%' },
    { label: 'الميثيونين', actual: nrc.methionine, target: nrc.methionine, unit: '%' },
    { label: 'الكالسيوم', actual: nrc.calcium, target: nrc.calcium, unit: '%' },
    { label: 'الفوسفور', actual: nrc.phosphorus, target: nrc.phosphorus, unit: '%' },
  ];

  return (
    <div className="mt-4 p-4 bg-surface dark:bg-darkCard rounded-xl border border-uiBorder dark:border-darkBorder">
      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2">
        <Beaker size={16} className="text-[#daa520]" />
        مقارنة مع معايير NRC ({formula.nrcKey})
      </h4>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {items.map((item) => {
          const diff = item.actual - item.target;
          const isMatch = Math.abs(diff) <= 0.5;
          return (
            <div key={item.label} className="p-3 rounded-lg bg-white dark:bg-darkSurface border border-uiBorder/50 dark:border-darkBorder/50">
              <p className="text-xs text-textSecondary mb-1">{item.label}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-textPrimary">{item.actual}{item.unit}</span>
                <span className={`text-[11px] font-medium px-1.5 py-0.5 rounded-full ${isMatch ? 'bg-green-100 text-green-700' : diff > 0 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
                  {isMatch ? 'مطابق' : diff > 0 ? `+${diff.toFixed(1)}` : diff.toFixed(1)}
                </span>
              </div>
              <p className="text-[11px] text-textMuted mt-1">المطلوب: {item.target}{item.unit}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CostBreakdown({ cost }: { cost: number }) {
  const data = [
    { name: 'مواد خام', value: Math.round(cost * 0.82), percent: 82 },
    { name: 'عمالة', value: Math.round(cost * 0.08), percent: 8 },
    { name: 'طاقة', value: Math.round(cost * 0.05), percent: 5 },
    { name: 'إهلاك', value: Math.round(cost * 0.03), percent: 3 },
    { name: 'أخرى', value: Math.round(cost * 0.02), percent: 2 },
  ];

  return (
    <div className="mt-4">
      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2">
        <PieChart size={16} className="text-[#0d6b43]" />
        تفاصيل التكلفة ({cost} ج/طن)
      </h4>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <RePieChart>
              <Pie data={data} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" nameKey="name">
                {data.map((_, index) => (
                  <Cell key={index} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(val: number) => `${val} ج`} />
              <Legend />
            </RePieChart>
          </ResponsiveContainer>
        </div>
        <div className="space-y-2 flex flex-col justify-center">
          {data.map((item, i) => (
            <div key={item.name} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                <span className="text-textSecondary">{item.name}</span>
              </div>
              <span className="font-semibold text-textPrimary">{item.value} ج <span className="text-textMuted text-xs">({item.percent}%)</span></span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── main page ─── */
export default function FeedPage() {
  const [formulas, setFormulas] = useState(feedFormulas);
  const [showFormulaModal, setShowFormulaModal] = useState(false);
  const [selectedFormula, setSelectedFormula] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [detailFormula, setDetailFormula] = useState<any | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editFormula, setEditFormula] = useState<any | null>(null);

  const [formulaForm, setFormulaForm] = useState({
    name: '', targetAnimal: 'دواجن', stage: 'Starter', protein: '', costPerTon: '', status: 'نشطة',
  });
  const [newIngredients, setNewIngredients] = useState([{ name: '', percent: '' }]);

  const activeCount = formulas.filter(f => f.status === 'نشطة').length;
  const avgCost = Math.round(formulas.reduce((s, f) => s + f.costPerTon, 0) / formulas.length);
  const monthlySaving = 14200;

  const filteredFormulas = formulas.filter(f =>
    f.name.includes(searchQuery) || f.targetAnimal.includes(searchQuery) || f.stage.includes(searchQuery)
  );

  const handleCreateFormula = () => {
    if (!formulaForm.name || !formulaForm.protein) return;
    const newFormula = {
      id: formulas.length + 1,
      name: formulaForm.name,
      targetAnimal: formulaForm.targetAnimal,
      stage: formulaForm.stage,
      protein: Number(formulaForm.protein),
      energy: 3000,
      costPerTon: Number(formulaForm.costPerTon) || 2500,
      status: formulaForm.status,
      nrcKey: formulaForm.targetAnimal === 'دواجن' ? 'Broiler Starter' : formulaForm.targetAnimal === 'أبقار' ? 'Cattle' : 'Sheep',
      ingredients: newIngredients.filter(ing => ing.name && ing.percent).map((ing, i) => ({
        name: ing.name,
        percent: Number(ing.percent),
      })),
    };
    if (newFormula.ingredients.length === 0) {
      newFormula.ingredients = [{ name: 'ذرة صفراء', percent: 50 }, { name: 'فول صويا', percent: 25 }, { name: 'مكونات أخرى', percent: 25 }];
    }
    setFormulas([newFormula, ...formulas]);
    setFormulaForm({ name: '', targetAnimal: 'دواجن', stage: 'Starter', protein: '', costPerTon: '', status: 'نشطة' });
    setNewIngredients([{ name: '', percent: '' }]);
    setShowFormulaModal(false);
  };

  const handleDeleteFormula = (id: number) => {
    if (confirm('هل أنت متأكد من حذف التركيبة؟')) {
      setFormulas(formulas.filter(f => f.id !== id));
    }
  };

  const addIngredientField = () => {
    setNewIngredients([...newIngredients, { name: '', percent: '' }]);
  };

  const updateIngredient = (index: number, field: string, value: string) => {
    const updated = [...newIngredients];
    updated[index] = { ...updated[index], [field]: value };
    setNewIngredients(updated);
  };

  const removeIngredient = (index: number) => {
    if (newIngredients.length > 1) {
      setNewIngredients(newIngredients.filter((_, i) => i !== index));
    }
  };

  const formulaColumns = [
    { key: 'name', header: 'اسم التركيبة', sortable: true },
    { key: 'targetAnimal', header: 'الحيوان المستهدف', sortable: true },
    { key: 'stage', header: 'المرحلة', sortable: true },
    { key: 'protein', header: 'بروتين %', sortable: true, render: (row: any) => <span className="font-semibold text-[#0d6b43]">{row.protein}%</span> },
    { key: 'costPerTon', header: 'تكلفة/طن (ج)', sortable: true, render: (row: any) => <span className="font-semibold">{row.costPerTon.toLocaleString()}</span> },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <StatusBadge status={row.status} /> },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="الأعلاف"
        subtitle="تركيبات الأعلاف والمقارنة مع معايير NRC"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الأعلاف' }]}
      >
        <button
          onClick={() => setShowFormulaModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg hover:from-[#0d6b43] hover:to-[#0a4a30] transition-all"
        >
          <Plus size={18} /> تركيبة جديدة
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="عدد التركيبات" value={String(formulas.length)} icon={FlaskConical} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-600" change={2} delay={0} />
        <KPICard title="تركيبات نشطة" value={String(activeCount)} icon={CheckCircle2} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-600" change={0} delay={0.1} />
        <KPICard title="تكلفة الطن المتوسطة" value={`${avgCost.toLocaleString()} ج`} icon={CircleDollarSign} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-600" change={-3.5} delay={0.2} />
        <KPICard title="توفير الشهر" value={`${monthlySaving.toLocaleString()} ج`} icon={TrendingUp} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-600" change={8.2} delay={0.3} />
      </div>

      {/* Savings Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <TrendingUp size={18} className="text-[#0d6b43]" /> أداء التكاليف الشهرية
        </h3>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={monthlySavings}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip formatter={(val: number) => `${val.toLocaleString()} ج`} />
            <Bar dataKey="target" name="المستهدف" fill="#e5e7eb" radius={[4, 4, 0, 0]} />
            <Bar dataKey="actual" name="الفعلي" fill="#0d6b43" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* NRC Standards Reference */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <Beaker size={18} className="text-[#daa520]" /> معايير NRC المرجعية
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                <th className="px-3 py-2 text-right font-semibold text-textSecondary">النوع</th>
                <th className="px-3 py-2 text-right font-semibold text-textSecondary">بروتين %</th>
                <th className="px-3 py-2 text-right font-semibold text-textSecondary">طاقة kcal/kg</th>
                <th className="px-3 py-2 text-right font-semibold text-textSecondary">لايسين %</th>
                <th className="px-3 py-2 text-right font-semibold text-textSecondary">ميثيونين %</th>
                <th className="px-3 py-2 text-right font-semibold text-textSecondary">كالسيوم %</th>
                <th className="px-3 py-2 text-right font-semibold text-textSecondary">فوسفور %</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(nrcStandards).map(([key, val]) => (
                <tr key={key} className="border-b border-uiBorder/30 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors">
                  <td className="px-3 py-2 font-medium text-textPrimary">{key}</td>
                  <td className="px-3 py-2 text-textPrimary">{val.protein}%</td>
                  <td className="px-3 py-2 text-textPrimary">{val.energy}</td>
                  <td className="px-3 py-2 text-textPrimary">{val.lysine}%</td>
                  <td className="px-3 py-2 text-textPrimary">{val.methionine}%</td>
                  <td className="px-3 py-2 text-textPrimary">{val.calcium}%</td>
                  <td className="px-3 py-2 text-textPrimary">{val.phosphorus}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Formulas Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4 }}
      >
        <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
          <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
              <FlaskConical size={18} className="text-[#0d6b43]" /> تركيبات الأعلاف
            </h3>
            <div className="relative">
              <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
              <input
                type="text"
                placeholder="بحث..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-56 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
              />
            </div>
          </div>
          <DataTable
            columns={formulaColumns}
            data={filteredFormulas}
            pageSize={8}
            searchable={false}
            rowActions={{
              onView: (row) => { setDetailFormula(row); setShowDetailModal(true); },
              onEdit: (row) => { setEditFormula({ ...row }); setShowEditModal(true); },
              onDelete: (row) => handleDeleteFormula(row.id),
            }}
            emptyMessage="لا توجد تركيبات"
          />
        </div>
      </motion.div>

      {/* Create Formula Modal */}
      <AnimatePresence>
        {showFormulaModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowFormulaModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-xl max-h-[90vh] overflow-y-auto"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تركيبة علف جديدة</h3>
                <button onClick={() => setShowFormulaModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">اسم التركيبة</label>
                    <input
                      type="text" placeholder="مثال: علاف دواجن ناشئة"
                      value={formulaForm.name}
                      onChange={(e) => setFormulaForm({ ...formulaForm, name: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الحيوان المستهدف</label>
                    <select
                      value={formulaForm.targetAnimal}
                      onChange={(e) => setFormulaForm({ ...formulaForm, targetAnimal: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="دواجن">دواجن</option>
                      <option value="أبقار">أبقار</option>
                      <option value="أغنام">أغنام</option>
                      <option value="جاموس">جاموس</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المرحلة</label>
                    <select
                      value={formulaForm.stage}
                      onChange={(e) => setFormulaForm({ ...formulaForm, stage: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="Starter">Starter</option>
                      <option value="Grower">Grower</option>
                      <option value="Finisher">Finisher</option>
                      <option value="Layer">Layer</option>
                      <option value="Lactating">Lactating</option>
                      <option value="Fattening">Fattening</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">بروتين %</label>
                    <input
                      type="number" step="0.1"
                      value={formulaForm.protein}
                      onChange={(e) => setFormulaForm({ ...formulaForm, protein: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">تكلفة/طن</label>
                    <input
                      type="number"
                      value={formulaForm.costPerTon}
                      onChange={(e) => setFormulaForm({ ...formulaForm, costPerTon: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>

                {/* Ingredients */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-textSecondary">المكونات</label>
                    <button onClick={addIngredientField} className="text-xs text-[#0d6b43] hover:underline font-medium">+ إضافة مكون</button>
                  </div>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {newIngredients.map((ing, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <input
                          type="text" placeholder="اسم المكون"
                          value={ing.name}
                          onChange={(e) => updateIngredient(i, 'name', e.target.value)}
                          className="flex-1 h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                        />
                        <input
                          type="number" placeholder="%"
                          value={ing.percent}
                          onChange={(e) => updateIngredient(i, 'percent', e.target.value)}
                          className="w-20 h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-center"
                        />
                        {newIngredients.length > 1 && (
                          <button onClick={() => removeIngredient(i)} className="w-8 h-9 rounded-lg text-red-500 hover:bg-red-50 flex items-center justify-center transition-colors">
                            <X size={14} />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                  <p className="text-[11px] text-textMuted mt-1">* تأكد أن مجموع النسب يساوي 100%</p>
                </div>

                <button
                  onClick={handleCreateFormula}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  إنشاء التركيبة
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailModal && detailFormula && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                  <FlaskConical size={20} className="text-[#0d6b43]" />
                  {detailFormula.name}
                </h3>
                <button onClick={() => setShowDetailModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6">
                {/* Info */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                  {[
                    { label: 'الحيوان', value: detailFormula.targetAnimal },
                    { label: 'المرحلة', value: detailFormula.stage },
                    { label: 'البروتين', value: `${detailFormula.protein}%` },
                    { label: 'التكلفة/طن', value: `${detailFormula.costPerTon.toLocaleString()} ج` },
                  ].map((item) => (
                    <div key={item.label} className="p-3 rounded-lg bg-surface dark:bg-darkCard border border-uiBorder/50 dark:border-darkBorder/50 text-center">
                      <p className="text-[11px] text-textSecondary">{item.label}</p>
                      <p className="text-sm font-bold text-textPrimary dark:text-darkText mt-1">{item.value}</p>
                    </div>
                  ))}
                </div>

                {/* Ingredients */}
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2">
                    <Wheat size={16} className="text-[#daa520]" />
                    قائمة المكونات
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    {detailFormula.ingredients.map((ing: any, i: number) => (
                      <div key={i} className="flex items-center justify-between p-2.5 rounded-lg bg-surface dark:bg-darkCard border border-uiBorder/50 dark:border-darkBorder/50">
                        <span className="text-sm text-textPrimary">{ing.name}</span>
                        <span className="text-sm font-bold text-[#0d6b43]">{ing.percent}%</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 flex items-center justify-between p-2 rounded-lg bg-[#0a4a30]/5 dark:bg-[#0d6b43]/10">
                    <span className="text-sm font-medium">المجموع</span>
                    <span className="text-sm font-bold text-[#0d6b43]">
                      {detailFormula.ingredients.reduce((s: number, ing: any) => s + ing.percent, 0)}%
                    </span>
                  </div>
                </div>

                {/* NRC */}
                <NRCComparison formula={detailFormula} />

                {/* Cost */}
                <CostBreakdown cost={detailFormula.costPerTon} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {showEditModal && editFormula && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEditModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تعديل التركيبة</h3>
                <button onClick={() => setShowEditModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">اسم التركيبة</label>
                  <input
                    type="text"
                    value={editFormula.name}
                    onChange={(e) => setEditFormula({ ...editFormula, name: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">البروتين %</label>
                    <input
                      type="number" step="0.1"
                      value={editFormula.protein}
                      onChange={(e) => setEditFormula({ ...editFormula, protein: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">التكلفة/طن</label>
                    <input
                      type="number"
                      value={editFormula.costPerTon}
                      onChange={(e) => setEditFormula({ ...editFormula, costPerTon: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">الحالة</label>
                  <select
                    value={editFormula.status}
                    onChange={(e) => setEditFormula({ ...editFormula, status: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                  >
                    <option value="نشطة">نشطة</option>
                    <option value="غير نشطة">غير نشطة</option>
                  </select>
                </div>
                <button
                  onClick={() => { setFormulas(formulas.map(f => f.id === editFormula.id ? editFormula : f)); setShowEditModal(false); }}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التعديلات
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
