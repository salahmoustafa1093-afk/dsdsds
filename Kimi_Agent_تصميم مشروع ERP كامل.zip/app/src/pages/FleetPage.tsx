// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Truck, Wrench, Fuel, Route, Users, BarChart3, Plus, Search,
  ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, ArrowUpDown,
  ArrowUp, ArrowDown, Eye, Edit3, Trash2, Phone, Star, MapPin,
  Calendar, AlertTriangle, CheckCircle2, XCircle, Clock, TrendingUp,
  TrendingDown, Filter, Download, Settings, Gauge, DollarSign,
  Activity, ClipboardList, PieChart, Layers
} from 'lucide-react';
import { cn } from '@/lib/utils';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

/* ─────────────────────────── mock data ─────────────────────────── */

const VEHICLES = [
  { id: 1, plate: 'أ ب ج 1234', type: 'براد', model: 'مرسيدس أكتروس', year: 2022, status: 'نشطة', mileage: 124500, fuelAvg: 32, lastService: '2024-11-15', nextService: '2025-02-15', driver: 'أحمد محمد' },
  { id: 2, plate: 'أ ب ج 1235', type: 'شاحنة', model: 'مان TGX', year: 2021, status: 'نشطة', mileage: 98700, fuelAvg: 28, lastService: '2024-10-20', nextService: '2025-01-20', driver: 'خالد العلي' },
  { id: 3, plate: 'أ ب ج 1236', type: 'فان', model: 'فورد ترانزيت', year: 2023, status: 'نشطة', mileage: 45200, fuelAvg: 12, lastService: '2024-12-01', nextService: '2025-03-01', driver: 'سامي الدوسري' },
  { id: 4, plate: 'أ ب ج 1237', type: 'براد', model: 'فولفو FH', year: 2020, status: 'في الصيانة', mileage: 178300, fuelAvg: 35, lastService: '2024-09-10', nextService: '2024-12-10', driver: '-' },
  { id: 5, plate: 'أ ب ج 1238', type: 'شاحنة', model: 'سكانيا R500', year: 2023, status: 'نشطة', mileage: 56700, fuelAvg: 30, lastService: '2024-11-25', nextService: '2025-02-25', driver: 'ناصر القحطاني' },
  { id: 6, plate: 'أ ب ج 1239', type: 'فان', model: 'مرسيدس سبرنتر', year: 2022, status: 'نشطة', mileage: 78900, fuelAvg: 14, lastService: '2024-10-15', nextService: '2025-01-15', driver: 'فهد السبيعي' },
  { id: 7, plate: 'أ ب ج 1240', type: 'براد', model: 'DAF XF', year: 2021, status: 'غير نشطة', mileage: 145000, fuelAvg: 34, lastService: '2024-08-20', nextService: '2024-11-20', driver: '-' },
  { id: 8, plate: 'أ ب ج 1241', type: 'شاحنة', model: 'رينو T', year: 2023, status: 'نشطة', mileage: 34200, fuelAvg: 27, lastService: '2024-12-10', nextService: '2025-03-10', driver: 'عبدالله الزهراني' },
  { id: 9, plate: 'أ ب ج 1242', type: 'فان', model: 'إيفيكو دايلي', year: 2022, status: 'نشطة', mileage: 91200, fuelAvg: 13, lastService: '2024-11-01', nextService: '2025-02-01', driver: 'ماجد العتيبي' },
  { id: 10, plate: 'أ ب ج 1243', type: 'براد', model: 'مرسيدس أكتروس', year: 2024, status: 'نشطة', mileage: 18900, fuelAvg: 31, lastService: '2024-12-20', nextService: '2025-03-20', driver: 'سلطان المالكي' },
  { id: 11, plate: 'أ ب ج 1244', type: 'شاحنة', model: 'مان TGS', year: 2020, status: 'في الصيانة', mileage: 198000, fuelAvg: 33, lastService: '2024-07-15', nextService: '2024-10-15', driver: '-' },
  { id: 12, plate: 'أ ب ج 1245', type: 'فان', model: 'فولكس فاجن كرافتر', year: 2023, status: 'نشطة', mileage: 45600, fuelAvg: 11, lastService: '2024-12-05', nextService: '2025-03-05', driver: 'بندر الشمري' },
  { id: 13, plate: 'أ ب ج 1246', type: 'براد', model: 'فولفو FM', year: 2021, status: 'نشطة', mileage: 112400, fuelAvg: 33, lastService: '2024-10-30', nextService: '2025-01-30', driver: 'تركي الفيصل' },
  { id: 14, plate: 'أ ب ج 1247', type: 'شاحنة', model: 'سكانيا G410', year: 2022, status: 'نشطة', mileage: 76400, fuelAvg: 29, lastService: '2024-11-18', nextService: '2025-02-18', driver: 'ياسر البلوي' },
  { id: 15, plate: 'أ ب ج 1248', type: 'فان', model: 'فورد ترانزيت', year: 2024, status: 'غير نشطة', mileage: 12300, fuelAvg: 12, lastService: '2024-12-25', nextService: '2025-03-25', driver: '-' },
];

const DRIVERS = [
  { id: 1, name: 'أحمد محمد', phone: '0555123456', license: 'أ123456', licenseExp: '2026-05-20', rating: 4.8, trips: 1240, status: 'متاح' },
  { id: 2, name: 'خالد العلي', phone: '0555234567', license: 'أ123457', licenseExp: '2025-08-15', rating: 4.6, trips: 980, status: 'في رحلة' },
  { id: 3, name: 'سامي الدوسري', phone: '0555345678', license: 'أ123458', licenseExp: '2027-01-10', rating: 4.9, trips: 1560, status: 'متاح' },
  { id: 4, name: 'ناصر القحطاني', phone: '0555456789', license: 'أ123459', licenseExp: '2025-12-01', rating: 4.5, trips: 870, status: 'في رحلة' },
  { id: 5, name: 'فهد السبيعي', phone: '0555567890', license: 'أ123460', licenseExp: '2026-03-25', rating: 4.7, trips: 1100, status: 'متاح' },
  { id: 6, name: 'عبدالله الزهراني', phone: '0555678901', license: 'أ123461', licenseExp: '2026-09-18', rating: 4.4, trips: 720, status: 'إجازة' },
  { id: 7, name: 'ماجد العتيبي', phone: '0555789012', license: 'أ123462', licenseExp: '2025-06-30', rating: 4.8, trips: 1350, status: 'في رحلة' },
  { id: 8, name: 'سلطان المالكي', phone: '0555890123', license: 'أ123463', licenseExp: '2027-04-12', rating: 4.6, trips: 640, status: 'متاح' },
  { id: 9, name: 'بندر الشمري', phone: '0555901234', license: 'أ123464', licenseExp: '2026-11-05', rating: 4.3, trips: 890, status: 'متاح' },
  { id: 10, name: 'تركي الفيصل', phone: '0555012345', license: 'أ123465', licenseExp: '2025-10-22', rating: 4.7, trips: 1020, status: 'في رحلة' },
  { id: 11, name: 'ياسر البلوي', phone: '0555123457', license: 'أ123466', licenseExp: '2026-07-14', rating: 4.5, trips: 760, status: 'متاح' },
  { id: 12, name: 'مبارك الهاجري', phone: '0555234568', license: 'أ123467', licenseExp: '2025-04-18', rating: 4.2, trips: 540, status: 'إجازة' },
  { id: 13, name: 'عبدالرحمن الشهراني', phone: '0555345679', license: 'أ123468', licenseExp: '2026-12-28', rating: 4.9, trips: 1480, status: 'متاح' },
];

const FUEL_LOGS = [
  { id: 1, vehicle: 'أ ب ج 1234', date: '2025-01-15', liters: 180, cost: 342, kmStart: 123800, kmEnd: 124200, efficiency: 29.2 },
  { id: 2, vehicle: 'أ ب ج 1235', date: '2025-01-15', liters: 220, cost: 418, kmStart: 98500, kmEnd: 98900, efficiency: 27.1 },
  { id: 3, vehicle: 'أ ب ج 1236', date: '2025-01-14', liters: 45, cost: 85.5, kmStart: 45000, kmEnd: 45350, efficiency: 13.2 },
  { id: 4, vehicle: 'أ ب ج 1238', date: '2025-01-14', liters: 200, cost: 380, kmStart: 56300, kmEnd: 56700, efficiency: 28.5 },
  { id: 5, vehicle: 'أ ب ج 1239', date: '2025-01-13', liters: 60, cost: 114, kmStart: 78500, kmEnd: 78900, efficiency: 14.1 },
  { id: 6, vehicle: 'أ ب ج 1241', date: '2025-01-13', liters: 190, cost: 361, kmStart: 33800, kmEnd: 34200, efficiency: 26.3 },
  { id: 7, vehicle: 'أ ب ج 1242', date: '2025-01-12', liters: 50, cost: 95, kmStart: 90800, kmEnd: 91200, efficiency: 12.8 },
  { id: 8, vehicle: 'أ ب ج 1243', date: '2025-01-12', liters: 170, cost: 323, kmStart: 18500, kmEnd: 18900, efficiency: 30.1 },
  { id: 9, vehicle: 'أ ب ج 1245', date: '2025-01-11', liters: 40, cost: 76, kmStart: 45200, kmEnd: 45600, efficiency: 11.5 },
  { id: 10, vehicle: 'أ ب ج 1246', date: '2025-01-11', liters: 210, cost: 399, kmStart: 111800, kmEnd: 112400, efficiency: 33.2 },
];

const MAINTENANCE = [
  { id: 1, vehicle: 'أ ب ج 1234', type: 'صيانة دورية', date: '2025-02-15', status: 'قادمة', cost: 2500, workshop: 'ورشة الرياض', priority: 'عادي' },
  { id: 2, vehicle: 'أ ب ج 1237', type: 'إصلاح محرك', date: '2025-01-15', status: 'قيد التنفيذ', cost: 8500, workshop: 'ورشة الصناعية', priority: 'عاجل' },
  { id: 3, vehicle: 'أ ب ج 1240', type: 'تبديل إطارات', date: '2025-01-20', status: 'قادمة', cost: 3200, workshop: 'ورشة الرياض', priority: 'عادي' },
  { id: 4, vehicle: 'أ ب ج 1244', type: 'صيانة فرامل', date: '2025-01-15', status: 'قيد التنفيذ', cost: 1800, workshop: 'ورشة جدة', priority: 'عاجل' },
  { id: 5, vehicle: 'أ ب ج 1235', type: 'صيانة دورية', date: '2025-01-25', status: 'قادمة', cost: 2200, workshop: 'ورشة الرياض', priority: 'عادي' },
  { id: 6, vehicle: 'أ ب ج 1239', type: 'تبديل زيت', date: '2025-01-18', status: 'قادمة', cost: 450, workshop: 'ورشة الدمام', priority: 'منخفض' },
  { id: 7, vehicle: 'أ ب ج 1241', type: 'فحص كهرباء', date: '2025-01-10', status: 'مكتملة', cost: 600, workshop: 'ورشة الرياض', priority: 'عادي' },
  { id: 8, vehicle: 'أ ب ج 1246', type: 'صيانة تكييف', date: '2025-01-22', status: 'قادمة', cost: 900, workshop: 'ورشة جدة', priority: 'منخفض' },
  { id: 9, vehicle: 'أ ب ج 1238', type: 'صيانة دورية', date: '2025-01-28', status: 'قادمة', cost: 2400, workshop: 'ورشة الدمام', priority: 'عادي' },
  { id: 10, vehicle: 'أ ب ج 1247', type: 'إصلاح هيكل', date: '2025-01-14', status: 'مكتملة', cost: 1500, workshop: 'ورشة الصناعية', priority: 'عادي' },
];

const TRIPS = [
  { id: 'TR-2025-001', vehicle: 'أ ب ج 1234', driver: 'أحمد محمد', from: 'الرياض', to: 'جدة', distance: 950, status: 'قيد التنفيذ', startDate: '2025-01-15', endDate: '-' },
  { id: 'TR-2025-002', vehicle: 'أ ب ج 1235', driver: 'خالد العلي', from: 'الدمام', to: 'الرياض', distance: 400, status: 'قيد التنفيذ', startDate: '2025-01-15', endDate: '-' },
  { id: 'TR-2025-003', vehicle: 'أ ب ج 1236', driver: 'سامي الدوسري', from: 'جدة', to: 'مكة', distance: 80, status: 'تم التسليم', startDate: '2025-01-14', endDate: '2025-01-14' },
  { id: 'TR-2025-004', vehicle: 'أ ب ج 1238', driver: 'ناصر القحطاني', from: 'الرياض', to: 'أبها', distance: 1050, status: 'قيد التنفيذ', startDate: '2025-01-14', endDate: '-' },
  { id: 'TR-2025-005', vehicle: 'أ ب ج 1239', driver: 'فهد السبيعي', from: 'الدمام', to: 'الأحساء', distance: 150, status: 'تم التسليم', startDate: '2025-01-13', endDate: '2025-01-13' },
  { id: 'TR-2025-006', vehicle: 'أ ب ج 1241', driver: 'عبدالله الزهراني', from: 'جدة', to: 'الطائف', distance: 180, status: 'قيد التنفيذ', startDate: '2025-01-13', endDate: '-' },
  { id: 'TR-2025-007', vehicle: 'أ ب ج 1242', driver: 'ماجد العتيبي', from: 'الرياض', to: 'بريدة', distance: 350, status: 'قيد التنفيذ', startDate: '2025-01-12', endDate: '-' },
  { id: 'TR-2025-008', vehicle: 'أ ب ج 1243', driver: 'سلطان المالكي', from: 'مكة', to: 'جدة', distance: 80, status: 'تم التسليم', startDate: '2025-01-12', endDate: '2025-01-12' },
  { id: 'TR-2025-009', vehicle: 'أ ب ج 1245', driver: 'بندر الشمري', from: 'الرياض', to: 'الخبر', distance: 420, status: 'قيد التنفيذ', startDate: '2025-01-11', endDate: '-' },
  { id: 'TR-2025-010', vehicle: 'أ ب ج 1246', driver: 'تركي الفيصل', from: 'أبها', to: 'جازان', distance: 200, status: 'قيد التنفيذ', startDate: '2025-01-11', endDate: '-' },
  { id: 'TR-2025-011', vehicle: 'أ ب ج 1247', driver: 'ياسر البلوي', from: 'جدة', to: 'ينبع', distance: 320, status: 'تم التسليم', startDate: '2025-01-10', endDate: '2025-01-10' },
  { id: 'TR-2025-012', vehicle: 'أ ب ج 1234', driver: 'أحمد محمد', from: 'الرياض', to: 'الدمام', distance: 400, status: 'تم التسليم', startDate: '2025-01-09', endDate: '2025-01-09' },
];

/* ─────────────────────── helpers ─────────────────────── */

const statusBadge = (status: string) => {
  const map: Record<string, string> = {
    'نشطة': 'bg-green-100 text-green-700',
    'غير نشطة': 'bg-slate-100 text-slate-600',
    'في الصيانة': 'bg-amber-100 text-amber-700',
    'متاح': 'bg-green-100 text-green-700',
    'في رحلة': 'bg-blue-100 text-blue-700',
    'إجازة': 'bg-purple-100 text-purple-700',
    'قيد التنفيذ': 'bg-blue-100 text-blue-700',
    'تم التسليم': 'bg-green-100 text-green-700',
    'ملغاة': 'bg-red-100 text-red-700',
    'قادمة': 'bg-sky-100 text-sky-700',
    'مكتملة': 'bg-green-100 text-green-700',
    'عاجل': 'bg-red-100 text-red-700',
    'عادي': 'bg-slate-100 text-slate-600',
    'منخفض': 'bg-green-100 text-green-700',
  };
  return map[status] || 'bg-slate-100 text-slate-600';
};

const TABS = [
  { key: 'vehicles', label: 'المركبات', icon: Truck },
  { key: 'drivers', label: 'السائقين', icon: Users },
  { key: 'fuel', label: 'الوقود', icon: Fuel },
  { key: 'maintenance', label: 'الصيانة', icon: Wrench },
  { key: 'trips', label: 'الرحلات', icon: Route },
  { key: 'analytics', label: 'التحليلات', icon: BarChart3 },
];

/* ─────────────────────── sub-components ─────────────────────── */

function VehicleCard({ v }: { v: typeof VEHICLES[0] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4 hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <h4 className="font-bold text-textPrimary dark:text-darkText text-sm">{v.plate}</h4>
          <p className="text-xs text-textSecondary dark:text-darkTextSec mt-0.5">{v.model}</p>
        </div>
        <span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(v.status))}>
          {v.status}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs mb-3">
        <div className="bg-surface dark:bg-darkBg rounded-lg p-2">
          <p className="text-textMuted mb-0.5">النوع</p>
          <p className="font-semibold text-textPrimary dark:text-darkText">{v.type}</p>
        </div>
        <div className="bg-surface dark:bg-darkBg rounded-lg p-2">
          <p className="text-textMuted mb-0.5">الموديل</p>
          <p className="font-semibold text-textPrimary dark:text-darkText">{v.year}</p>
        </div>
        <div className="bg-surface dark:bg-darkBg rounded-lg p-2">
          <p className="text-textMuted mb-0.5">المسافة</p>
          <p className="font-semibold text-textPrimary dark:text-darkText">{v.mileage.toLocaleString()} كم</p>
        </div>
        <div className="bg-surface dark:bg-darkBg rounded-lg p-2">
          <p className="text-textMuted mb-0.5">متوسط الوقود</p>
          <p className="font-semibold text-textPrimary dark:text-darkText">{v.fuelAvg} ل/100كم</p>
        </div>
      </div>
      <div className="flex items-center justify-between text-[11px] border-t border-uiBorder dark:border-darkBorder pt-2">
        <span className="text-textSecondary dark:text-darkTextSec">{v.driver}</span>
        <span className="text-textMuted">الصيانة القادمة: {v.nextService}</span>
      </div>
    </motion.div>
  );
}

function MiniPieChart({ data, colors }: { data: number[]; colors: string[] }) {
  const total = data.reduce((a, b) => a + b, 0);
  let offset = 0;
  return (
    <svg viewBox="0 0 100 100" className="w-28 h-28">
      {data.map((v, i) => {
        const pct = (v / total) * 360;
        const dash = `${pct} ${360 - pct}`;
        const el = (
          <circle
            key={i}
            cx="50" cy="50" r="40"
            fill="none"
            stroke={colors[i]}
            strokeWidth="20"
            strokeDasharray={dash}
            transform={`rotate(${offset - 90} 50 50)`}
          />
        );
        offset += pct;
        return el;
      })}
    </svg>
  );
}

function MiniBarChart({ data, labels, color }: { data: number[]; labels: string[]; color: string }) {
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-2 h-32">
      {data.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <span className="text-[10px] text-textMuted">{v}</span>
          <div
            className="w-full rounded-t-md transition-all"
            style={{ height: `${(v / max) * 100}px`, backgroundColor: color, opacity: 0.6 + (i / data.length) * 0.4 }}
          />
          <span className="text-[10px] text-textMuted">{labels[i]}</span>
        </div>
      ))}
    </div>
  );
}

/* ─────────────────────── main page ─────────────────────── */

export default function FleetPage() {
  const [activeTab, setActiveTab] = useState('vehicles');
  const [searchQ, setSearchQ] = useState('');

  /* KPIs */
  const activeV = VEHICLES.filter(v => v.status === 'نشطة').length;
  const maintV = VEHICLES.filter(v => v.status === 'في الصيانة').length;
  const dailyTrips = TRIPS.filter(t => t.startDate === '2025-01-15').length;
  const fuelCost = FUEL_LOGS.reduce((s, f) => s + f.cost, 0);
  const upcomingMaint = MAINTENANCE.filter(m => m.status === 'قادمة').length;

  /* Filter helpers */
  const filteredVehicles = VEHICLES.filter(v =>
    !searchQ || v.plate.includes(searchQ) || v.model.includes(searchQ) || v.type.includes(searchQ)
  );
  const filteredDrivers = DRIVERS.filter(d =>
    !searchQ || d.name.includes(searchQ) || d.phone.includes(searchQ)
  );
  const filteredFuel = FUEL_LOGS.filter(f =>
    !searchQ || f.vehicle.includes(searchQ)
  );
  const filteredMaint = MAINTENANCE.filter(m =>
    !searchQ || m.vehicle.includes(searchQ) || m.type.includes(searchQ)
  );
  const filteredTrips = TRIPS.filter(t =>
    !searchQ || t.id.includes(searchQ) || t.vehicle.includes(searchQ) || t.driver.includes(searchQ)
  );

  return (
    <div className="p-4 md:p-6">
      <PageHeader title="إدارة الأسطول" subtitle="إدارة المركبات والسائقين والصيانة والرحلات">
        <button className="flex items-center gap-2 px-4 py-2 bg-[#0a4a30] hover:bg-[#0d6b43] text-white rounded-lg text-sm font-medium transition-colors">
          <Plus size={16} />
          إضافة مركبة
        </button>
      </PageHeader>

      {/* ─── KPI Cards ─── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        <KPICard title="إجمالي المركبات" value={VEHICLES.length.toString()} icon={Truck} iconBg="bg-emerald-50" iconColor="text-emerald-600" delay={0} />
        <KPICard title="المركبات النشطة" value={activeV.toString()} change={5} icon={Activity} iconBg="bg-green-50" iconColor="text-green-600" delay={0.05} />
        <KPICard title="في الصيانة" value={maintV.toString()} change={-12} icon={Wrench} iconBg="bg-amber-50" iconColor="text-amber-600" delay={0.1} />
        <KPICard title="الرحلات اليوم" value={dailyTrips.toString()} change={8} icon={Route} iconBg="bg-blue-50" iconColor="text-blue-600" delay={0.15} />
        <KPICard title="تكلفة الوقود" value={`${fuelCost.toLocaleString()} ر.س`} change={-3} icon={Fuel} iconBg="bg-rose-50" iconColor="text-rose-600" delay={0.2} />
        <KPICard title="صيانة قادمة" value={upcomingMaint.toString()} icon={Calendar} iconBg="bg-purple-50" iconColor="text-purple-600" delay={0.25} />
      </div>

      {/* ─── Tabs ─── */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card mb-6">
        <div className="flex overflow-x-auto border-b border-uiBorder dark:border-darkBorder scrollbar-hide">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={cn(
                'flex items-center gap-2 px-5 py-3.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
                activeTab === t.key
                  ? 'border-[#0a4a30] text-[#0a4a30] dark:text-green-400'
                  : 'border-transparent text-textSecondary hover:text-textPrimary dark:text-darkTextSec'
              )}
            >
              <t.icon size={16} />
              {t.label}
            </button>
          ))}
        </div>

        <div className="p-4 md:p-5">
          <AnimatePresence mode="wait">

            {/* ─── Vehicles Tab ─── */}
            {activeTab === 'vehicles' && (
              <motion.div key="vehicles" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">قائمة المركبات</h3>
                  <div className="relative w-56">
                    <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                    <input
                      type="text" placeholder="بحث بالل plaque أو الموديل..."
                      value={searchQ} onChange={e => setSearchQ(e.target.value)}
                      className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  {filteredVehicles.map(v => <VehicleCard key={v.id} v={v} />)}
                </div>
              </motion.div>
            )}

            {/* ─── Drivers Tab ─── */}
            {activeTab === 'drivers' && (
              <motion.div key="drivers" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">قائمة السائقين</h3>
                  <div className="relative w-56">
                    <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                    <input
                      type="text" placeholder="بحث بالاسم أو الهاتف..."
                      value={searchQ} onChange={e => setSearchQ(e.target.value)}
                      className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                    />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                        {['الاسم', 'الهاتف', 'الرخصة', 'الصلاحية', 'التقييم', 'الرحلات', 'الحالة', ''].map(h => (
                          <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredDrivers.map((d, i) => (
                        <motion.tr key={d.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                          className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                        >
                          <td className="px-4 py-3 text-sm font-medium text-textPrimary dark:text-darkText">{d.name}</td>
                          <td className="px-4 py-3 text-sm text-textSecondary dark:text-darkTextSec">{d.phone}</td>
                          <td className="px-4 py-3 text-sm text-textSecondary dark:text-darkTextSec">{d.license}</td>
                          <td className="px-4 py-3 text-sm text-textSecondary dark:text-darkTextSec">{d.licenseExp}</td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1">
                              <Star size={12} className="text-amber-400 fill-amber-400" />
                              <span className="text-sm font-semibold text-textPrimary dark:text-darkText">{d.rating}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm text-textSecondary dark:text-darkTextSec">{d.trips.toLocaleString()}</td>
                          <td className="px-4 py-3"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(d.status))}>{d.status}</span></td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1 justify-center">
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors"><Eye size={15} /></button>
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-amber-500 hover:bg-amber-50 transition-colors"><Edit3 size={15} /></button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* ─── Fuel Tab ─── */}
            {activeTab === 'fuel' && (
              <motion.div key="fuel" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">سجل استهلاك الوقود</h3>
                  <div className="flex items-center gap-2">
                    <button className="flex items-center gap-1.5 px-3 py-1.5 border border-uiBorder rounded-lg text-xs text-textSecondary hover:bg-surface transition-colors">
                      <Download size={14} />
                      تصدير
                    </button>
                    <div className="relative w-48">
                      <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                      <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                        className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['المركبة', 'التاريخ', 'اللترات', 'التكلفة', 'من كم', 'إلى كم', 'الكفاءة'].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {filteredFuel.map((f, i) => (
                            <motion.tr key={f.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{f.vehicle}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{f.date}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{f.liters} ل</td>
                              <td className="px-3 py-2.5 text-sm font-semibold text-green-600">{f.cost} ر.س</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{f.kmStart.toLocaleString()}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{f.kmEnd.toLocaleString()}</td>
                              <td className="px-3 py-2.5">
                                <span className={cn('text-xs font-semibold', f.efficiency > 28 ? 'text-green-600' : f.efficiency > 15 ? 'text-amber-600' : 'text-red-600')}>
                                  {f.efficiency} ل/100كم
                                </span>
                              </td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">كفاءة الوقود حسب المركبة</h4>
                    <MiniBarChart
                      data={[29.2, 27.1, 13.2, 28.5, 14.1, 26.3, 12.8, 30.1, 11.5, 33.2]}
                      labels={['1234', '1235', '1236', '1238', '1239', '1241', '1242', '1243', '1245', '1246']}
                      color="#0a4a30"
                    />
                    <div className="mt-4 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-textSecondary">متوسط الكفاءة</span>
                        <span className="font-semibold text-textPrimary dark:text-darkText">22.6 ل/100كم</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-textSecondary">إجمالي التكلفة</span>
                        <span className="font-semibold text-green-600">{fuelCost.toLocaleString()} ر.س</span>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-textSecondary">إجمالي اللترات</span>
                        <span className="font-semibold text-textPrimary dark:text-darkText">{FUEL_LOGS.reduce((s, f) => s + f.liters, 0)} ل</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Maintenance Tab ─── */}
            {activeTab === 'maintenance' && (
              <motion.div key="maintenance" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  {/* Alerts */}
                  <div className="lg:col-span-1 space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2">
                        <AlertTriangle size={16} className="text-red-500" />
                        تنبيهات متأخرة
                      </h4>
                      {MAINTENANCE.filter(m => m.priority === 'عاجل' && m.status !== 'مكتملة').map(m => (
                        <div key={m.id} className="flex items-start gap-2 mb-2 p-2 bg-red-50 dark:bg-red-950/20 rounded-lg">
                          <XCircle size={14} className="text-red-500 mt-0.5 shrink-0" />
                          <div>
                            <p className="text-xs font-medium text-textPrimary dark:text-darkText">{m.vehicle} - {m.type}</p>
                            <p className="text-[11px] text-textMuted">{m.workshop} | {m.date}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2">
                        <CheckCircle2 size={16} className="text-green-500" />
                        صيانة قادمة
                      </h4>
                      {MAINTENANCE.filter(m => m.status === 'قادمة').slice(0, 4).map(m => (
                        <div key={m.id} className="flex items-start gap-2 mb-2 p-2 bg-surface dark:bg-darkBg rounded-lg">
                          <Calendar size={14} className="text-blue-500 mt-0.5 shrink-0" />
                          <div className="flex-1">
                            <p className="text-xs font-medium text-textPrimary dark:text-darkText">{m.vehicle} - {m.type}</p>
                            <p className="text-[11px] text-textMuted">{m.date} | {m.cost} ر.س</p>
                          </div>
                          <span className={cn('px-1.5 py-0.5 rounded-full text-[10px] font-semibold', m.priority === 'عاجل' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600')}>
                            {m.priority}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  {/* Schedule */}
                  <div className="lg:col-span-2">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">جدول الصيانة</h3>
                      <div className="relative w-48">
                        <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                        <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                          className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                      </div>
                    </div>
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['المركبة', 'نوع الصيانة', 'التاريخ', 'التكلفة', 'الورشة', 'الحالة', 'الأولوية'].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {filteredMaint.map((m, i) => (
                            <motion.tr key={m.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{m.vehicle}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.type}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.date}</td>
                              <td className="px-3 py-2.5 text-sm font-semibold text-green-600">{m.cost.toLocaleString()} ر.س</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{m.workshop}</td>
                              <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(m.status))}>{m.status}</span></td>
                              <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(m.priority))}>{m.priority}</span></td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Trips Tab ─── */}
            {activeTab === 'trips' && (
              <motion.div key="trips" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">سجل الرحلات</h3>
                  <div className="relative w-56">
                    <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                    <input
                      type="text" placeholder="بحث بالرقم أو المركبة أو السائق..."
                      value={searchQ} onChange={e => setSearchQ(e.target.value)}
                      className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm"
                    />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                    <thead>
                      <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                        {['رقم الرحلة', 'المركبة', 'السائق', 'المسار', 'المسافة', 'الحالة', 'تاريخ البدء', ''].map(h => (
                          <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredTrips.map((t, i) => (
                        <motion.tr key={t.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                          className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                        >
                          <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{t.id}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{t.vehicle}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{t.driver}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{t.from} → {t.to}</td>
                          <td className="px-3 py-2.5 text-sm font-semibold text-textPrimary dark:text-darkText">{t.distance} كم</td>
                          <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(t.status))}>{t.status}</span></td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{t.startDate}</td>
                          <td className="px-3 py-2.5">
                            <div className="flex items-center gap-1 justify-center">
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors"><Eye size={15} /></button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* ─── Analytics Tab ─── */}
            {activeTab === 'analytics' && (
              <motion.div key="analytics" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Utilization */}
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">حالة المركبات</h4>
                    <div className="flex items-center justify-center mb-4">
                      <MiniPieChart data={[10, 2, 2, 1]} colors={['#10b981', '#f59e0b', '#ef4444', '#64748b']} />
                    </div>
                    <div className="space-y-2">
                      {[
                        { label: 'نشطة', count: 10, color: 'bg-green-500' },
                        { label: 'في الصيانة', count: 2, color: 'bg-amber-500' },
                        { label: 'غير نشطة', count: 2, color: 'bg-slate-500' },
                        { label: 'متوقفة', count: 1, color: 'bg-red-500' },
                      ].map(item => (
                        <div key={item.label} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <div className={cn('w-3 h-3 rounded-full', item.color)} />
                            <span className="text-textSecondary dark:text-darkTextSec">{item.label}</span>
                          </div>
                          <span className="font-semibold text-textPrimary dark:text-darkText">{item.count}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  {/* Cost Breakdown */}
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">تكاليف التشغيل (آخر 6 أشهر)</h4>
                    <MiniBarChart data={[18500, 22000, 16800, 24500, 19200, 21000]} labels={['يول', 'أغس', 'سب', 'أكتو', 'نوف', 'ديس']} color="#daa520" />
                    <div className="mt-4 space-y-2">
                      {[
                        { label: 'وقود', value: '58%', color: 'bg-[#0a4a30]' },
                        { label: 'صيانة', value: '28%', color: 'bg-[#daa520]' },
                        { label: 'إطارات', value: '9%', color: 'bg-blue-500' },
                        { label: 'أخرى', value: '5%', color: 'bg-slate-400' },
                      ].map(item => (
                        <div key={item.label} className="flex items-center gap-2">
                          <div className={cn('w-3 h-3 rounded-full', item.color)} />
                          <span className="text-xs text-textSecondary dark:text-darkTextSec flex-1">{item.label}</span>
                          <span className="text-xs font-semibold text-textPrimary dark:text-darkText">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  {/* Driver Performance */}
                  <div className="md:col-span-2 bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">أداء السائقين (أعلى 5)</h4>
                    <div className="space-y-3">
                      {[...DRIVERS].sort((a, b) => b.rating - a.rating).slice(0, 5).map((d, i) => (
                        <div key={d.id} className="flex items-center gap-3">
                          <span className="text-xs font-bold text-textMuted w-4">{i + 1}</span>
                          <div className="w-32 text-xs font-medium text-textPrimary dark:text-darkText truncate">{d.name}</div>
                          <div className="flex-1 h-4 bg-surface dark:bg-darkBg rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${(d.rating / 5) * 100}%` }}
                              transition={{ duration: 0.6, delay: i * 0.1 }}
                              className="h-full rounded-full bg-gradient-to-l from-[#0a4a30] to-[#0d6b43]"
                            />
                          </div>
                          <div className="flex items-center gap-1 w-16">
                            <Star size={12} className="text-amber-400 fill-amber-400" />
                            <span className="text-xs font-semibold text-textPrimary dark:text-darkText">{d.rating}</span>
                          </div>
                          <span className="text-xs text-textMuted">{d.trips.toLocaleString()} رحلة</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
