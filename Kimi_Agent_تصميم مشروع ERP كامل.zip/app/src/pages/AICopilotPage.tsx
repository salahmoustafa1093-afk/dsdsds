import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send,
  Mic,
  Bot,
  User,
  TrendingUp,
  Package,
  Store,
  AlertTriangle,
  Wheat,
  BarChart3,
  MessageSquare,
  Clock,
  Sparkles,
  ChevronLeft,
  PanelLeft,
  Plus,
  PanelLeftClose,
  Zap,
  CircleDollarSign,
  ShoppingCart,
  Users,
  Truck,
  ArrowUpRight,
  ArrowDownRight,
  MoreHorizontal,
  Copy,
  ThumbsUp,
  ThumbsDown,
  RotateCcw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'text' | 'chart-bar' | 'chart-pie' | 'table' | 'kpi';
  chartData?: any[];
  tableData?: any[];
  kpiData?: any[];
}

interface Conversation {
  id: string;
  title: string;
  icon: React.ElementType;
  messages: ChatMessage[];
  date: string;
}

/* ------------------------------------------------------------------ */
/*  Mock Data for Charts                                               */
/* ------------------------------------------------------------------ */
const salesChartData = [
  { day: 'السبت', sales: 280000 },
  { day: 'الأحد', sales: 320000 },
  { day: 'الإثنين', sales: 295000 },
  { day: 'الثلاثاء', sales: 345678 },
  { day: 'الأربعاء', sales: 310000 },
  { day: 'الخميس', sales: 360000 },
  { day: 'الجمعة', sales: 250000 },
];

const topProductsData = [
  { name: 'علف بادئ', value: 85000 },
  { name: 'علف ناهي', value: 72000 },
  { name: 'ذرة صفراء', value: 65000 },
  { name: 'كسب صويا', value: 58000 },
  { name: 'ردة ناعمة', value: 45000 },
];

const branchPerformanceData = [
  { name: 'القاهرة', sales: 1200000 },
  { name: 'الإسكندرية', sales: 980000 },
  { name: 'طنطا', sales: 750000 },
  { name: 'المنصورة', sales: 620000 },
  { name: 'كفر الشيخ', sales: 510000 },
];

const inventoryPieData = [
  { name: 'متوفر', value: 340, color: '#0d6b43' },
  { name: 'منخفض', value: 23, color: '#daa520' },
  { name: 'نفذ', value: 5, color: '#dc2626' },
];

const COLORS = ['#0d6b43', '#0a4a30', '#daa520', '#4ade80', '#22c55e'];

/* ------------------------------------------------------------------ */
/*  Suggested Queries                                                  */
/* ------------------------------------------------------------------ */
const suggestedQueries = [
  { text: 'ما هي مبيعات اليوم؟', icon: TrendingUp },
  { text: 'أعلى 5 منتجات مبيعاً هذا الشهر', icon: ShoppingCart },
  { text: 'حالة المخزون الحالية', icon: Package },
  { text: 'أفضل فرع أداءً', icon: Store },
  { text: 'العملاء المتأخرين في السداد', icon: AlertTriangle },
  { text: 'تكلفة علف الدواجن اليوم', icon: Wheat },
];

/* ------------------------------------------------------------------ */
/*  Conversation History                                               */
/* ------------------------------------------------------------------ */
const createMockConversations = (): Conversation[] => [
  {
    id: 'conv-1',
    title: 'مبيعات اليوم',
    icon: TrendingUp,
    date: 'اليوم',
    messages: [
      {
        id: 'm-1', role: 'user', content: 'ما هي مبيعات اليوم؟',
        timestamp: new Date(2024, 5, 18, 9, 0), type: 'text',
      },
      {
        id: 'm-2', role: 'assistant', content: '',
        timestamp: new Date(2024, 5, 18, 9, 1), type: 'kpi',
        kpiData: [
          { label: 'إجمالي المبيعات', value: '345,678', unit: 'ج.م', change: 12, changeLabel: 'عن الأمس', icon: CircleDollarSign, color: '#0d6b43' },
          { label: 'عدد الطلبات', value: '42', unit: 'طلب', change: 8, changeLabel: 'عن الأمس', icon: ShoppingCart, color: '#daa520' },
          { label: 'متوسط قيمة الطلب', value: '8,230', unit: 'ج.م', change: -2, changeLabel: 'عن الأمس', icon: BarChart3, color: '#2563eb' },
        ],
      },
      {
        id: 'm-3', role: 'assistant', content: 'مبيعات اليوم: 345,678 جنيه، بزيادة 12% عن الأمس. عدد الطلبات: 42 طلب.',
        timestamp: new Date(2024, 5, 18, 9, 1), type: 'chart-bar',
        chartData: salesChartData,
      },
    ],
  },
  {
    id: 'conv-2',
    title: 'المنتجات الأكثر مبيعاً',
    icon: ShoppingCart,
    date: 'اليوم',
    messages: [
      {
        id: 'm-4', role: 'user', content: 'أعلى 5 منتجات مبيعاً هذا الشهر',
        timestamp: new Date(2024, 5, 18, 10, 30), type: 'text',
      },
      {
        id: 'm-5', role: 'assistant', content: '',
        timestamp: new Date(2024, 5, 18, 10, 31), type: 'chart-bar',
        chartData: topProductsData,
      },
      {
        id: 'm-6', role: 'assistant', content: 'أعلى 5 منتجات مبيعاً هذا الشهر:\n1. علف دواجن بادئ: 85,000 ج.م\n2. علف ناهي: 72,000 ج.م\n3. ذرة صفراء: 65,000 ج.م\n4. كسب صويا: 58,000 ج.م\n5. ردة ناعمة: 45,000 ج.م',
        timestamp: new Date(2024, 5, 18, 10, 31), type: 'text',
      },
    ],
  },
  {
    id: 'conv-3',
    title: 'حالة المخزون',
    icon: Package,
    date: 'أمس',
    messages: [
      {
        id: 'm-7', role: 'user', content: 'حالة المخزون الحالية',
        timestamp: new Date(2024, 5, 17, 14, 0), type: 'text',
      },
      {
        id: 'm-8', role: 'assistant', content: 'إجمالي المنتجات: 368 منتج. المخزون منخفض: 23 منتج تحت الحد الأدنى. النفاذ: 5 منتجات نفذت.',
        timestamp: new Date(2024, 5, 17, 14, 1), type: 'chart-pie',
        chartData: inventoryPieData,
      },
    ],
  },
  {
    id: 'conv-4',
    title: 'أداء الفروع',
    icon: Store,
    date: 'أمس',
    messages: [
      {
        id: 'm-9', role: 'user', content: 'أفضل فرع أداءً',
        timestamp: new Date(2024, 5, 17, 11, 0), type: 'text',
      },
      {
        id: 'm-10', role: 'assistant', content: 'أفضل فرع أداءً هذا الشهر هو فرع القاهرة بإجمالي مبيعات 1,200,000 جنيه.',
        timestamp: new Date(2024, 5, 17, 11, 1), type: 'chart-bar',
        chartData: branchPerformanceData,
      },
    ],
  },
  {
    id: 'conv-5',
    title: 'العملاء المتأخرين',
    icon: AlertTriangle,
    date: '17 يونيو',
    messages: [],
  },
  {
    id: 'conv-6',
    title: 'تكلفة الأعلاف',
    icon: Wheat,
    date: '16 يونيو',
    messages: [],
  },
];

/* ------------------------------------------------------------------ */
/*  Mock AI Responses                                                  */
/* ------------------------------------------------------------------ */
const mockAIResponses: Record<string, { content: string; type: ChatMessage['type']; chartData?: any[]; kpiData?: any[] }> = {
  'مبيعات اليوم': {
    content: 'مبيعات اليوم: 345,678 جنيه، بزيادة 12% عن الأمس. عدد الطلبات: 42 طلب.',
    type: 'chart-bar',
    chartData: salesChartData,
  },
  'أعلى 5 منتجات': {
    content: 'أعلى 5 منتجات مبيعاً هذا الشهر:\n1. علف دواجن بادئ (25كجم): 85,000 ج.م\n2. علف ناهي (25كجم): 72,000 ج.م\n3. ذرة صفراء مكسرة: 65,000 ج.م\n4. كسب صويا 48%: 58,000 ج.م\n5. ردة ناعمة: 45,000 ج.م',
    type: 'chart-bar',
    chartData: topProductsData,
  },
  'مخزون': {
    content: 'حالة المخزون الحالية: إجمالي المنتجات 368. منخفض: 23 منتج تحت الحد الأدنى. نفاذ: 5 منتجات.',
    type: 'chart-pie',
    chartData: inventoryPieData,
  },
  'فرع': {
    content: 'أفضل فرع أداءً هذا الشهر: القاهرة - 1,200,000 جنيه. يأتي بعده الإسكندرية بـ 980,000 جنيه.',
    type: 'chart-bar',
    chartData: branchPerformanceData,
  },
};

/* ------------------------------------------------------------------ */
/*  Helper Components                                                  */
/* ------------------------------------------------------------------ */
function ChartBarComponent({ data }: { data: any[] }) {
  const isProductData = data[0]?.name?.includes('علف') || data[0]?.name?.includes('ذرة');
  const isBranchData = data[0]?.name === 'القاهرة';
  const label = isProductData ? 'القيمة (ج.م)' : isBranchData ? 'المبيعات (ج.م)' : 'المبيعات';

  return (
    <div className="h-48 mt-3 bg-white rounded-xl p-3 border border-gray-100">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
          <XAxis dataKey={isProductData || isBranchData ? 'name' : 'day'} tick={{ fontSize: 10 }} interval={0} />
          <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => v >= 1000 ? `${(v / 1000).toFixed(0)}K` : v} />
          <Tooltip
            formatter={(value: number) => [value.toLocaleString(), label]}
            contentStyle={{ borderRadius: 8, fontSize: 12, border: '1px solid #e5e7eb' }}
          />
          <Bar dataKey="value" radius={[6, 6, 0, 0]}>
            {data.map((_, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function ChartPieComponent({ data }: { data: any[] }) {
  return (
    <div className="h-44 mt-3 flex items-center justify-center">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={45}
            outerRadius={70}
            paddingAngle={4}
            dataKey="value"
            stroke="none"
          >
            {data.map((entry, index) => (
              <Cell key={index} fill={entry.color || COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: number, name: string) => [`${value} منتج`, name]}
            contentStyle={{ borderRadius: 8, fontSize: 12, border: '1px solid #e5e7eb' }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

function KPICardsComponent({ data }: { data: any[] }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3">
      {data.map((kpi: any, i: number) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm"
        >
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${kpi.color}15` }}>
              <kpi.icon size={16} style={{ color: kpi.color }} />
            </div>
            {kpi.change !== undefined && (
              <div className={`flex items-center gap-0.5 text-[10px] font-bold ${kpi.change >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                {kpi.change >= 0 ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                {Math.abs(kpi.change)}%
              </div>
            )}
          </div>
          <p className="text-lg font-bold text-gray-800">{kpi.value}</p>
          <p className="text-[10px] text-gray-500">{kpi.label}</p>
          {kpi.unit && <p className="text-[9px] text-gray-400">{kpi.unit}</p>}
        </motion.div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Page Component                                                */
/* ------------------------------------------------------------------ */
export default function AICopilotPage() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [conversations, setConversations] = useState<Conversation[]>(createMockConversations);
  const [activeConvId, setActiveConvId] = useState<string>('conv-1');
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConversation = conversations.find((c) => c.id === activeConvId);

  /* scroll to bottom */
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConversation?.messages, isTyping]);

  /* send message */
  const sendMessage = (text?: string) => {
    const content = text || inputValue.trim();
    if (!content) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date(),
      type: 'text',
    };

    /* update conversation with user message */
    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConvId
          ? { ...c, messages: [...c.messages, userMsg], title: c.messages.length === 0 ? content.slice(0, 20) + '...' : c.title }
          : c
      )
    );

    setInputValue('');
    setIsTyping(true);

    /* mock AI response after delay */
    setTimeout(() => {
      setIsTyping(false);
      const lower = content.toLowerCase();
      let response = mockAIResponses['مبيعات اليوم']; // default

      if (lower.includes('منتج') || lower.includes('مبيع') || lower.includes('أعلى')) {
        response = mockAIResponses['أعلى 5 منتجات'];
      } else if (lower.includes('مخزون') || lower.includes('جرد') || lower.includes('库存')) {
        response = mockAIResponses['مخزون'];
      } else if (lower.includes('فرع') || lower.includes('أداء')) {
        response = mockAIResponses['فرع'];
      } else if (lower.includes('عميل') || lower.includes('متأخر') || lower.includes('سداد')) {
        response = {
          content: 'العملاء المتأخرين في السداد:\n1. شركة النيل للدواجن: 125,000 ج.م (متأخر 45 يوم)\n2. مزرعة الصفوة: 78,000 ج.م (متأخر 30 يوم)\n3. هايبر الهرم: 45,000 ج.م (متأخر 22 يوم)\n\nإجمالي المتأخرات: 248,000 ج.م',
          type: 'text',
        };
      } else if (lower.includes('تكلفة') || lower.includes('علف') || lower.includes('سعر')) {
        response = {
          content: 'تكلفة أعلاف الدواجن اليوم:\n\n• علف بادئ: 850 ج.م / شيكارة (زيادة 2%)\n• علف ناهي: 920 ج.م / شيكارة (ثابت)\n• علف واسع: 780 ج.م / شيكارة (انخفاض 1%)\n\nالمكونات:\n• الذرة الصفراء: 12.5 ج.م / كجم\n• كسب الصويا: 28 ج.م / كجم\n• ردة ناعمة: 8.5 ج.م / كجم',
          type: 'text',
        };
      }

      const aiMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: response.content,
        timestamp: new Date(),
        type: response.type || 'text',
        chartData: response.chartData,
        kpiData: response.kpiData,
      };

      setConversations((prev) =>
        prev.map((c) =>
          c.id === activeConvId ? { ...c, messages: [...c.messages, aiMsg] } : c
        )
      );
    }, 1200);
  };

  const startNewChat = () => {
    const newConv: Conversation = {
      id: `conv-${Date.now()}`,
      title: 'محادثة جديدة',
      icon: MessageSquare,
      date: 'الآن',
      messages: [],
    };
    setConversations((p) => [newConv, ...p]);
    setActiveConvId(newConv.id);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (d: Date) =>
    d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', hour12: false });

  /* ================================================================== */
  /*  RENDER                                                            */
  /* ================================================================== */
  return (
    <div className="min-h-[100dvh] bg-[#f0f2f5] flex">
      {/* ==================== SIDEBAR ==================== */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 280, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="bg-[#f8f9fa] border-l border-gray-200 overflow-hidden flex flex-col shrink-0"
          >
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] flex items-center justify-center">
                  <Sparkles size={16} className="text-white" />
                </div>
                <h2 className="text-sm font-bold text-gray-800">GFF مساعد</h2>
              </div>
              <Button
                onClick={startNewChat}
                className="w-full h-9 text-xs bg-[#0a4a30] hover:bg-[#083d28]"
              >
                <Plus size={14} /> محادثة جديدة
              </Button>
            </div>

            <div className="flex-1 overflow-auto p-3">
              <p className="text-[10px] font-bold text-gray-400 uppercase mb-2 px-2">المحادثات الحديثة</p>
              <div className="space-y-1">
                {conversations.map((conv) => {
                  const isActive = conv.id === activeConvId;
                  return (
                    <button
                      key={conv.id}
                      onClick={() => setActiveConvId(conv.id)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-right transition-all ${
                        isActive
                          ? 'bg-[#0d6b43]/10 text-[#0d6b43]'
                          : 'hover:bg-gray-100 text-gray-600'
                      }`}
                    >
                      <conv.icon size={16} strokeWidth={isActive ? 2.5 : 1.5} className="shrink-0" />
                      <div className="flex-1 min-w-0 text-right">
                        <p className={`text-xs font-medium truncate ${isActive ? 'font-bold' : ''}`}>
                          {conv.title}
                        </p>
                        <p className="text-[10px] text-gray-400">{conv.date}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-gray-200">
              <div className="flex items-center gap-2 px-2 py-2">
                <div className="w-7 h-7 rounded-full bg-[#0d6b43]/10 flex items-center justify-center">
                  <User size={14} className="text-[#0d6b43]" />
                </div>
                <div>
                  <p className="text-[11px] font-bold text-gray-700">مدير النظام</p>
                  <p className="text-[9px] text-gray-400">admin@gff.com</p>
                </div>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* ==================== MAIN CHAT AREA ==================== */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Chat Header */}
        <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center transition-colors text-gray-500"
          >
            {sidebarOpen ? <PanelLeftClose size={18} /> : <PanelLeft size={18} />}
          </button>
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] flex items-center justify-center">
            <Bot size={16} className="text-white" />
          </div>
          <div className="flex-1">
            <h1 className="text-sm font-bold text-gray-800">GFF مساعد الذكي</h1>
            <p className="text-[10px] text-gray-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              متصل
            </p>
          </div>
          <Button variant="ghost" size="icon" className="w-8 h-8 text-gray-400">
            <MoreHorizontal size={16} />
          </Button>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-auto px-4 py-6">
          <AnimatePresence mode="wait">
            {(!activeConversation || activeConversation.messages.length === 0) ? (
              /* Welcome Screen */
              <motion.div
                key="welcome"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-xl mx-auto text-center pt-10"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 260, damping: 20 }}
                  className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] flex items-center justify-center mx-auto mb-4 shadow-lg"
                >
                  <Sparkles size={28} className="text-white" />
                </motion.div>
                <h2 className="text-xl font-bold text-gray-800 mb-2">
                  مرحباً! أنا مساعد GFF الذكي
                </h2>
                <p className="text-sm text-gray-500 mb-8 leading-relaxed">
                  يمكنك سؤالي عن أي شيء يخص عمليات الشركة - المبيعات، المخزون، الفروع، العملاء، والمزيد
                </p>

                {/* Suggested Queries */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {suggestedQueries.map((sq, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.08 }}
                      onClick={() => sendMessage(sq.text)}
                      className="flex items-center gap-2.5 px-4 py-3 bg-white rounded-xl border border-gray-200 hover:border-[#0d6b43]/30 hover:shadow-md transition-all text-right"
                    >
                      <div className="w-8 h-8 rounded-lg bg-[#0d6b43]/10 flex items-center justify-center shrink-0">
                        <sq.icon size={15} className="text-[#0d6b43]" />
                      </div>
                      <span className="text-xs font-medium text-gray-700">{sq.text}</span>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            ) : (
              /* Chat Messages */
              <motion.div
                key="chat"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-2xl mx-auto space-y-5"
              >
                {activeConversation.messages.map((msg, i) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i < 4 ? i * 0.05 : 0 }}
                    className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
                  >
                    {/* Avatar */}
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      msg.role === 'assistant'
                        ? 'bg-gradient-to-br from-[#0a4a30] to-[#0d6b43]'
                        : 'bg-gray-200'
                    }`}>
                      {msg.role === 'assistant' ? (
                        <Bot size={15} className="text-white" />
                      ) : (
                        <User size={15} className="text-gray-600" />
                      )}
                    </div>

                    {/* Content */}
                    <div className={`flex-1 ${msg.role === 'user' ? 'text-left' : ''}`}>
                      <div className={`inline-block max-w-full ${msg.role === 'user' ? 'bg-[#0d6b43] text-white' : 'bg-white border border-gray-200'} rounded-2xl px-4 py-2.5 shadow-sm`}>
                        {/* Text */}
                        {msg.content && (
                          <p className="text-xs leading-relaxed whitespace-pre-line">
                            {msg.content}
                          </p>
                        )}

                        {/* KPI Cards */}
                        {msg.type === 'kpi' && msg.kpiData && <KPICardsComponent data={msg.kpiData} />}

                        {/* Bar Chart */}
                        {msg.type === 'chart-bar' && msg.chartData && <ChartBarComponent data={msg.chartData} />}

                        {/* Pie Chart */}
                        {msg.type === 'chart-pie' && msg.chartData && <ChartPieComponent data={msg.chartData} />}
                      </div>

                      {/* Timestamp + Actions */}
                      <div className={`flex items-center gap-2 mt-1 ${msg.role === 'user' ? 'justify-start flex-row-reverse' : 'justify-start'}`}>
                        <span className="text-[9px] text-gray-400">{formatTime(msg.timestamp)}</span>
                        {msg.role === 'assistant' && (
                          <div className="flex items-center gap-1">
                            <button className="w-5 h-5 rounded hover:bg-gray-100 flex items-center justify-center text-gray-300 hover:text-gray-500 transition-colors">
                              <Copy size={10} />
                            </button>
                            <button className="w-5 h-5 rounded hover:bg-gray-100 flex items-center justify-center text-gray-300 hover:text-gray-500 transition-colors">
                              <ThumbsUp size={10} />
                            </button>
                            <button className="w-5 h-5 rounded hover:bg-gray-100 flex items-center justify-center text-gray-300 hover:text-gray-500 transition-colors">
                              <ThumbsDown size={10} />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}

                {/* Typing Indicator */}
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex gap-3"
                  >
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0a4a30] to-[#0d6b43] flex items-center justify-center">
                      <Bot size={15} className="text-white" />
                    </div>
                    <div className="bg-white border border-gray-200 rounded-2xl px-4 py-3 shadow-sm">
                      <div className="flex items-center gap-1.5">
                        <motion.div
                          animate={{ opacity: [0.3, 1, 0.3] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0 }}
                          className="w-2 h-2 rounded-full bg-[#0d6b43]"
                        />
                        <motion.div
                          animate={{ opacity: [0.3, 1, 0.3] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                          className="w-2 h-2 rounded-full bg-[#0d6b43]"
                        />
                        <motion.div
                          animate={{ opacity: [0.3, 1, 0.3] }}
                          transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                          className="w-2 h-2 rounded-full bg-[#0d6b43]"
                        />
                      </div>
                    </div>
                  </motion.div>
                )}

                <div ref={messagesEndRef} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ==================== INPUT BAR ==================== */}
        <div className="bg-white border-t border-gray-200 px-4 py-3">
          <div className="max-w-2xl mx-auto flex items-center gap-2">
            {/* Voice Input Button */}
            <button
              onClick={() => setIsRecording(!isRecording)}
              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                isRecording
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
              title={isRecording ? 'جاري التسجيل...' : 'إدخال صوتي'}
            >
              <Mic size={18} />
            </button>

            {/* Text Input */}
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="اكتب سؤالك هنا..."
                className="w-full h-10 pr-4 pl-12 rounded-xl border border-gray-200 bg-gray-50 text-xs text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#0d6b43]/20 focus:border-[#0d6b43] transition-all"
                dir="rtl"
              />
              {/* Send Button inside input */}
              <button
                onClick={() => sendMessage()}
                disabled={!inputValue.trim() || isTyping}
                className={`absolute left-1.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                  inputValue.trim() && !isTyping
                    ? 'bg-[#0d6b43] text-white hover:bg-[#0a4a30]'
                    : 'bg-gray-200 text-gray-400'
                }`}
              >
                <Send size={14} />
              </button>
            </div>
          </div>

          {/* Quick Chips (when empty) */}
          {(!activeConversation || activeConversation.messages.length === 0) && (
            <div className="max-w-2xl mx-auto flex items-center gap-1.5 mt-2 overflow-x-auto pb-1">
              {['مبيعات الأسبوع', 'مخزون منخفض', 'أداء الفروع'].map((chip) => (
                <button
                  key={chip}
                  onClick={() => sendMessage(chip)}
                  className="text-[10px] px-3 py-1 rounded-full bg-gray-100 text-gray-600 hover:bg-[#0d6b43]/10 hover:text-[#0d6b43] transition-colors whitespace-nowrap shrink-0"
                >
                  {chip}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
