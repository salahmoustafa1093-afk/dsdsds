// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2, Settings, Users, DollarSign, Package, ShoppingCart,
  Factory, Database, ClipboardList, Save, Plus, Trash2, Edit3,
  Eye, Search, ChevronLeft, ChevronRight, Check, X, Globe,
  Calendar, Clock, CreditCard, Receipt, Percent, Truck,
  AlertTriangle, CheckCircle2, XCircle, Moon, Sun, Monitor,
  Shield, UserPlus, Lock, KeyRound, FileText, Activity,
  Download, RotateCcw, Filter, ToggleLeft, ToggleRight,
  Smartphone, Mail, MapPin, Phone, Hash, Image, Undo2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import PageHeader from '@/components/PageHeader';

/* ─────────────────────── mock data ─────────────────────── */

const TABS = [
  { key: 'company', label: 'الشركة', icon: Building2 },
  { key: 'system', label: 'النظام', icon: Settings },
  { key: 'users', label: 'المستخدمين', icon: Users },
  { key: 'financial', label: 'المالية', icon: DollarSign },
  { key: 'inventory', label: 'المخزون', icon: Package },
  { key: 'sales', label: 'المبيعات', icon: ShoppingCart },
  { key: 'production', label: 'الإنتاج', icon: Factory },
  { key: 'backup', label: 'نسخ احتياطي', icon: Database },
  { key: 'audit', label: 'سجل', icon: ClipboardList },
];

const USERS = [
  { id: 1, name: 'أحمد محمد', email: 'ahmed@company.sa', role: 'مدير', department: 'الإدارة', status: 'نشط', lastLogin: '2025-01-15 08:30' },
  { id: 2, name: 'خالد العلي', email: 'khaled@company.sa', role: 'مشرف', department: 'المبيعات', status: 'نشط', lastLogin: '2025-01-15 09:15' },
  { id: 3, name: 'سامي الدوسري', email: 'sami@company.sa', role: 'محاسب', department: 'المالية', status: 'نشط', lastLogin: '2025-01-14 16:45' },
  { id: 4, name: 'ناصر القحطاني', email: 'nasser@company.sa', role: 'مشغل', department: 'الإنتاج', status: 'نشط', lastLogin: '2025-01-15 07:00' },
  { id: 5, name: 'فهد السبيعي', email: 'fahd@company.sa', role: 'مشغل', department: 'المخزون', status: 'إجازة', lastLogin: '2025-01-10 14:20' },
  { id: 6, name: 'ماجد العتيبي', email: 'majed@company.sa', role: 'سائق', department: 'التوصيل', status: 'نشط', lastLogin: '2025-01-15 06:30' },
  { id: 7, name: 'سلطان المالكي', email: 'sultan@company.sa', role: 'مندوب', department: 'المبيعات', status: 'نشط', lastLogin: '2025-01-15 10:00' },
  { id: 8, name: 'تركي الشمري', email: 'turki@company.sa', role: 'فني', department: 'الصيانة', status: 'غير نشط', lastLogin: '2024-12-20 11:30' },
];

const ROLES = [
  { name: 'مدير', description: 'صلاحيات كاملة على النظام', users: 1, color: 'bg-purple-100 text-purple-700' },
  { name: 'مشرف', description: 'إدارة المستخدمين والتقارير', users: 1, color: 'bg-blue-100 text-blue-700' },
  { name: 'محاسب', description: 'الوصول للمالية والتقارير', users: 1, color: 'bg-green-100 text-green-700' },
  { name: 'مشغل', description: 'إدخال البيانات والعمليات', users: 2, color: 'bg-amber-100 text-amber-700' },
  { name: 'سائق', description: 'مشاهدة الطلبات والتوصيل', users: 1, color: 'bg-cyan-100 text-cyan-700' },
  { name: 'مندوب', description: 'المبيعات والعملاء', users: 1, color: 'bg-pink-100 text-pink-700' },
  { name: 'فني', description: 'الصيانة والمعدات', users: 1, color: 'bg-slate-100 text-slate-700' },
];

const PERMISSIONS = [
  { module: 'لوحة التحكم', actions: { view: ['مدير', 'مشرف'], edit: ['مدير'], delete: ['مدير'], export: ['مدير', 'مشرف'] } },
  { module: 'المبيعات', actions: { view: ['مدير', 'مشرف', 'محاسب', 'مشغل', 'مندوب'], edit: ['مدير', 'مشرف', 'مندوب'], delete: ['مدير', 'مشرف'], export: ['مدير', 'مشرف', 'محاسب'] } },
  { module: 'المشتريات', actions: { view: ['مدير', 'مشرف', 'محاسب'], edit: ['مدير', 'مشرف'], delete: ['مدير'], export: ['مدير', 'مشرف', 'محاسب'] } },
  { module: 'المخزون', actions: { view: ['مدير', 'مشرف', 'محاسب', 'مشغل'], edit: ['مدير', 'مشرف', 'مشغل'], delete: ['مدير', 'مشرف'], export: ['مدير', 'مشرف'] } },
  { module: 'المالية', actions: { view: ['مدير', 'مشرف', 'محاسب'], edit: ['مدير', 'محاسب'], delete: ['مدير'], export: ['مدير', 'مشرف', 'محاسب'] } },
  { module: 'الإنتاج', actions: { view: ['مدير', 'مشرف', 'مشغل'], edit: ['مدير', 'مشرف', 'مشغل'], delete: ['مدير', 'مشرف'], export: ['مدير', 'مشرف'] } },
  { module: 'التوصيل', actions: { view: ['مدير', 'مشرف', 'سائق', 'مشغل'], edit: ['مدير', 'مشرف', 'سائق'], delete: ['مدير', 'مشرف'], export: ['مدير', 'مشرف'] } },
  { module: 'التقارير', actions: { view: ['مدير', 'مشرف', 'محاسب'], edit: ['مدير'], delete: ['مدير'], export: ['مدير', 'مشرف', 'محاسب'] } },
  { module: 'الإعدادات', actions: { view: ['مدير'], edit: ['مدير'], delete: ['مدير'], export: ['مدير'] } },
];

const AUDIT_LOG = [
  { id: 1, user: 'أحمد محمد', action: 'تسجيل دخول', module: 'النظام', details: 'تسجيل دخول ناجح من IP 192.168.1.1', date: '2025-01-15 08:30:15', severity: 'info' },
  { id: 2, user: 'خالد العلي', action: 'إنشاء طلب', module: 'المبيعات', details: 'إنشاء طلب جديد ORD-2025-023', date: '2025-01-15 09:15:42', severity: 'info' },
  { id: 3, user: 'سامي الدوسري', action: 'تعديل فاتورة', module: 'المالية', details: 'تعديل فاتورة INV-2025-1045 - تغيير المبلغ', date: '2025-01-15 10:22:08', severity: 'warning' },
  { id: 4, user: 'أحمد محمد', action: 'تغيير صلاحية', module: 'الإعدادات', details: 'تعديل صلاحيات دور "مشرف" - إضافة تصدير', date: '2025-01-15 11:05:33', severity: 'warning' },
  { id: 5, user: 'ناصر القحطاني', action: 'إدخال إنتاج', module: 'الإنتاج', details: 'تسجيل إنتاج يومي: 125,000 بيضة', date: '2025-01-15 07:45:19', severity: 'info' },
  { id: 6, user: 'ماجد العتيبي', action: 'تحديث حالة', module: 'التوصيل', details: 'تحديث حالة الطلب ORD-2025-018 إلى "تم التسليم"', date: '2025-01-15 12:30:55', severity: 'info' },
  { id: 7, user: 'أحمد محمد', action: 'حذف سجل', module: 'المخزون', details: 'حذف حركة مخزون رقم STK-2025-0089', date: '2025-01-14 16:18:27', severity: 'danger' },
  { id: 8, user: 'سلطان المالكي', action: 'إضافة عميل', module: 'المبيعات', details: 'إضافة عميل جديد: مؤسسة الرفاهية', date: '2025-01-14 14:42:11', severity: 'info' },
  { id: 9, user: 'فهد السبيعي', action: 'تسجيل خروج', module: 'النظام', details: 'تسجيل خروج من النظام', date: '2025-01-14 17:00:05', severity: 'info' },
  { id: 10, user: 'أحمد محمد', action: 'نسخ احتياطي', module: 'الإعدادات', details: 'إنشاء نسخة احتياطية يدوية', date: '2025-01-14 23:30:00', severity: 'info' },
];

const BACKUP_HISTORY = [
  { id: 1, date: '2025-01-15 02:00', type: 'تلقائي', size: '2.4 GB', status: 'ناجح' },
  { id: 2, date: '2025-01-14 02:00', type: 'تلقائي', size: '2.4 GB', status: 'ناجح' },
  { id: 3, date: '2025-01-14 23:30', type: 'يدوي', size: '2.4 GB', status: 'ناجح' },
  { id: 4, date: '2025-01-13 02:00', type: 'تلقائي', size: '2.3 GB', status: 'ناجح' },
  { id: 5, date: '2025-01-12 02:00', type: 'تلقائي', size: '2.3 GB', status: 'ناجح' },
  { id: 6, date: '2025-01-11 02:00', type: 'تلقائي', size: '2.3 GB', status: 'فاشل' },
];

const severityBadge = (s: string) => {
  const map: Record<string, string> = {
    info: 'bg-blue-100 text-blue-700', warning: 'bg-amber-100 text-amber-700', danger: 'bg-red-100 text-red-700',
  };
  return map[s] || 'bg-slate-100 text-slate-600';
};

const userStatusBadge = (s: string) => {
  const map: Record<string, string> = { 'نشط': 'bg-green-100 text-green-700', 'إجازة': 'bg-amber-100 text-amber-700', 'غير نشط': 'bg-slate-100 text-slate-600' };
  return map[s] || 'bg-slate-100 text-slate-600';
};

/* ─────────────────────── Toggle component ─────────────────────── */

function ToggleSwitch({ label, defaultOn = false }: { label: string; defaultOn?: boolean }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <button onClick={() => setOn(!on)} className="flex items-center gap-3 w-full py-2 group">
      {on ? <ToggleRight size={22} className="text-[#0a4a30] shrink-0" /> : <ToggleLeft size={22} className="text-textMuted shrink-0" />}
      <span className="text-sm text-textSecondary dark:text-darkTextSec group-hover:text-textPrimary dark:group-hover:text-darkText transition-colors">{label}</span>
    </button>
  );
}

/* ─────────────────────── main page ─────────────────────── */

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('company');
  const [searchQ, setSearchQ] = useState('');
  const [backupSchedule, setBackupSchedule] = useState('daily');

  return (
    <div className="p-4 md:p-6">
      <PageHeader title="الإعدادات" subtitle="إدارة إعدادات النظام والشركة والمستخدمين">
        <button className="flex items-center gap-2 px-4 py-2 bg-[#0a4a30] hover:bg-[#0d6b43] text-white rounded-lg text-sm font-medium transition-colors">
          <Save size={16} />
          حفظ التغييرات
        </button>
      </PageHeader>

      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card">
        <div className="flex overflow-x-auto border-b border-uiBorder dark:border-darkBorder scrollbar-hide">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className={cn('flex items-center gap-2 px-4 py-3.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
                activeTab === t.key ? 'border-[#0a4a30] text-[#0a4a30] dark:text-green-400' : 'border-transparent text-textSecondary hover:text-textPrimary dark:text-darkTextSec')}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>

        <div className="p-4 md:p-5">
          <AnimatePresence mode="wait">

            {/* ─── Company ─── */}
            {activeTab === 'company' && (
              <motion.div key="company" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl space-y-4">
                  <div className="flex items-center gap-6 mb-6">
                    <div className="w-20 h-20 rounded-xl bg-[#0a4a30] flex items-center justify-center text-white text-2xl font-bold">مث</div>
                    <div>
                      <button className="flex items-center gap-2 px-3 py-1.5 border border-uiBorder rounded-lg text-xs text-textSecondary hover:bg-surface transition-colors">
                        <Image size={14} /> تغيير الشعار
                      </button>
                      <p className="text-[11px] text-textMuted mt-1">PNG, JPG - الحد الأقصى 2 ميجابايت</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">اسم الشركة</label>
                      <input type="text" defaultValue="مؤسسة دواجن الوطنية" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">الرقم الضريبي</label>
                      <input type="text" defaultValue="311234567800003" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">العنوان</label>
                      <input type="text" defaultValue="الرياض - الصناعية الثانية - شارع الملك فهد" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">البريد الإلكتروني</label>
                      <input type="email" defaultValue="info@poultry-co.sa" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">رقم الهاتف</label>
                      <input type="text" defaultValue="920012345" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">رقم الجوال</label>
                      <input type="text" defaultValue="0555123456" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">الموقع الإلكتروني</label>
                      <input type="text" defaultValue="www.poultry-co.sa" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── System ─── */}
            {activeTab === 'system' && (
              <motion.div key="system" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl space-y-6">
                  <div>
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">تنسيق التاريخ والوقت</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs text-textSecondary dark:text-darkTextSec mb-1.5">تنسيق التاريخ</label>
                        <select defaultValue="dd/mm/yyyy" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                          <option value="dd/mm/yyyy">DD/MM/YYYY</option>
                          <option value="mm/dd/yyyy">MM/DD/YYYY</option>
                          <option value="yyyy/mm/dd">YYYY/MM/DD</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-textSecondary dark:text-darkTextSec mb-1.5">المنطقة الزمنية</label>
                        <select defaultValue="riyadh" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                          <option value="riyadh">الرياض (GMT+3)</option>
                          <option value="jeddah">جدة (GMT+3)</option>
                          <option value="dubai">دبي (GMT+4)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="border-t border-uiBorder dark:border-darkBorder pt-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">العملة واللغة</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs text-textSecondary dark:text-darkTextSec mb-1.5">العملة</label>
                        <select defaultValue="sar" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                          <option value="sar">ريال سعودي (SAR)</option>
                          <option value="usd">دولار أمريكي (USD)</option>
                          <option value="aed">درهم إماراتي (AED)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs text-textSecondary dark:text-darkTextSec mb-1.5">اللغة</label>
                        <select defaultValue="ar" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                          <option value="ar">العربية</option>
                          <option value="en">English</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="border-t border-uiBorder dark:border-darkBorder pt-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">المظهر</h4>
                    <div className="flex items-center gap-3">
                      <button className="flex items-center gap-2 px-4 py-2 rounded-lg border-2 border-[#0a4a30] bg-green-50 text-[#0a4a30] text-sm font-medium">
                        <Sun size={16} /> فاتح
                      </button>
                      <button className="flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-textSecondary dark:text-darkTextSec text-sm font-medium hover:bg-surface dark:hover:bg-darkBg transition-colors">
                        <Moon size={16} /> داكن
                      </button>
                      <button className="flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-textSecondary dark:text-darkTextSec text-sm font-medium hover:bg-surface dark:hover:bg-darkBg transition-colors">
                        <Monitor size={16} /> تلقائي
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Users ─── */}
            {activeTab === 'users' && (
              <motion.div key="users" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                  <div className="lg:col-span-3">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">المستخدمون</h3>
                      <div className="flex items-center gap-2">
                        <button className="flex items-center gap-2 px-3 py-1.5 bg-[#0a4a30] text-white rounded-lg text-xs font-medium transition-colors">
                          <UserPlus size={14} /> إضافة مستخدم
                        </button>
                        <div className="relative w-48">
                          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                          <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                            className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                        </div>
                      </div>
                    </div>
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['الاسم', 'البريد', 'الدور', 'القسم', 'الحالة', 'آخر دخول', ''].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {USERS.filter(u => !searchQ || u.name.includes(searchQ) || u.email.includes(searchQ)).map((u, i) => (
                            <motion.tr key={u.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{u.name}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{u.email}</td>
                              <td className="px-3 py-2.5"><span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-purple-100 text-purple-700">{u.role}</span></td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{u.department}</td>
                              <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', userStatusBadge(u.status))}>{u.status}</span></td>
                              <td className="px-3 py-2.5 text-sm text-textMuted">{u.lastLogin}</td>
                              <td className="px-3 py-2.5">
                                <div className="flex items-center gap-1 justify-center">
                                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors"><Eye size={15} /></button>
                                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-amber-500 hover:bg-amber-50 transition-colors"><Edit3 size={15} /></button>
                                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-red-500 hover:bg-red-50 transition-colors"><Trash2 size={15} /></button>
                                </div>
                              </td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">الأدوار</h4>
                    <div className="space-y-2">
                      {ROLES.map((r, i) => (
                        <motion.div key={r.name} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                          className="bg-surface dark:bg-darkBg rounded-lg border border-uiBorder dark:border-darkBorder p-3"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', r.color)}>{r.name}</span>
                                <span className="text-[11px] text-textMuted">{r.users} مستخدم</span>
                          </div>
                          <p className="text-[11px] text-textSecondary dark:text-darkTextSec">{r.description}</p>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Permission Matrix */}
                <div className="mt-6">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
                    <Shield size={16} className="text-[#daa520]" />
                    مصفوفة الصلاحيات
                  </h4>
                  <div className="overflow-x-auto">
                    <table className="w-full bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder text-xs">
                      <thead>
                        <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                          <th className="px-3 py-3 text-right font-semibold text-textSecondary dark:text-darkTextSec">الوحدة</th>
                          <th className="px-3 py-3 text-center font-semibold text-textSecondary dark:text-darkTextSec">عرض</th>
                          <th className="px-3 py-3 text-center font-semibold text-textSecondary dark:text-darkTextSec">تعديل</th>
                          <th className="px-3 py-3 text-center font-semibold text-textSecondary dark:text-darkTextSec">حذف</th>
                          <th className="px-3 py-3 text-center font-semibold text-textSecondary dark:text-darkTextSec">تصدير</th>
                        </tr>
                      </thead>
                      <tbody>
                        {PERMISSIONS.map((p, i) => (
                          <tr key={p.module} className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors">
                            <td className="px-3 py-2.5 font-medium text-textPrimary dark:text-darkText">{p.module}</td>
                            <td className="px-3 py-2.5 text-center">
                              <span className="text-[10px] text-textSecondary">{p.actions.view.join(', ')}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center">
                              <span className="text-[10px] text-textSecondary">{p.actions.edit.join(', ')}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center">
                              <span className="text-[10px] text-textSecondary">{p.actions.delete.join(', ')}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center">
                              <span className="text-[10px] text-textSecondary">{p.actions.export.join(', ')}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Financial ─── */}
            {activeTab === 'financial' && (
              <motion.div key="financial" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">السنة المالية</label>
                      <select defaultValue="2025" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                        <option value="2024">2024</option>
                        <option value="2025">2025</option>
                        <option value="2026">2026</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">بداية السنة المالية</label>
                      <input type="date" defaultValue="2025-01-01" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">نسبة الضريبة (%)</label>
                      <input type="number" defaultValue="15" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">شروط الدفع الافتراضية</label>
                      <select defaultValue="30" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                        <option value="0">فوري</option>
                        <option value="15">15 يوم</option>
                        <option value="30">30 يوم</option>
                        <option value="60">60 يوم</option>
                        <option value="90">90 يوم</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">رقم الفاتورة التالي</label>
                      <input type="text" defaultValue="INV-2025-1046" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">رقم سند القبض التالي</label>
                      <input type="text" defaultValue="RCV-2025-0521" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                  </div>
                  <div className="border-t border-uiBorder dark:border-darkBorder pt-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">خيارات إضافية</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <ToggleSwitch label="تفعيل الضريبة على الفواتير" defaultOn />
                      <ToggleSwitch label="السماح بالخصم على الفواتير" defaultOn />
                      <ToggleSwitch label="تنبيه تجاوز الحد الائتماني" defaultOn />
                      <ToggleSwitch label="ربط مع بوابة الدفع الإلكتروني" />
                      <ToggleSwitch label="إصدار فواتير ضريبية مبسطة" />
                      <ToggleSwitch label="السماح بالدفع الأجل" defaultOn />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Inventory ─── */}
            {activeTab === 'inventory' && (
              <motion.div key="inventory" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">المستودع الافتراضي</label>
                      <select defaultValue="main" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                        <option value="main">المستودع الرئيسي - الرياض</option>
                        <option value="west">المستودع الغربي - جدة</option>
                        <option value="east">المستودع الشرقي - الدمام</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">طريقة التقييم</label>
                      <select defaultValue="fifo" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                        <option value="fifo">FIFO - أول داخل أول خارج</option>
                        <option value="lifo">LIFO - آخر داخل أول خارج</option>
                        <option value="avg">المتوسط المرجح</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">نسبة التنبيه المنخفض (%)</label>
                      <input type="number" defaultValue="20" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">نسبة التنبيه الحرج (%)</label>
                      <input type="number" defaultValue="10" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                  </div>
                  <div className="border-t border-uiBorder dark:border-darkBorder pt-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">خيارات المخزون</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <ToggleSwitch label="تتبع دفعات الإنتاج" defaultOn />
                      <ToggleSwitch label="تنبيه انتهاء الصلاحية" defaultOn />
                      <ToggleSwitch label="منع البيع تحت حد التنبيه" />
                      <ToggleSwitch label="التسوية التلقائية للهالك" defaultOn />
                      <ToggleSwitch label="إصدار تنبيهات للمستودع المنخفض" defaultOn />
                      <ToggleSwitch label="تتبع درجة حرارة التخزين" defaultOn />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Sales ─── */}
            {activeTab === 'sales' && (
              <motion.div key="sales" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">قناة البيع الافتراضية</label>
                      <select defaultValue="direct" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
                        <option value="direct">مباشر</option>
                        <option value="distributor">موزع</option>
                        <option value="online">أونلاين</option>
                        <option value="retail">تجزئة</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">الحد الأقصى للخصم (%)</label>
                      <input type="number" defaultValue="15" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                  </div>
                  <div className="border-t border-uiBorder dark:border-darkBorder pt-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">خيارات المبيعات</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <ToggleSwitch label="التحقق من الرصيد قبل البيع" defaultOn />
                      <ToggleSwitch label="السماح بالبيع الآجل" defaultOn />
                      <ToggleSwitch label="إصدار فاتورة تلقائية" defaultOn />
                      <ToggleSwitch label="تطبيق الأسعار حسب المنطقة" />
                      <ToggleSwitch label="إشعار العميل بالطلب" defaultOn />
                      <ToggleSwitch label="تتبع مرتجعات المبيعات" defaultOn />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Production ─── */}
            {activeTab === 'production' && (
              <motion.div key="production" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="max-w-2xl space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">ساعات الوردية</label>
                      <div className="flex items-center gap-2">
                        <input type="time" defaultValue="06:00" className="flex-1 h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                        <span className="text-textMuted">-</span>
                        <input type="time" defaultValue="14:00" className="flex-1 h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">وردية المساء</label>
                      <div className="flex items-center gap-2">
                        <input type="time" defaultValue="14:00" className="flex-1 h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                        <span className="text-textMuted">-</span>
                        <input type="time" defaultValue="22:00" className="flex-1 h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">هدف OEE (%)</label>
                      <input type="number" defaultValue="85" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">هدف العائد (%)</label>
                      <input type="number" defaultValue="78" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">السعة اليومية (بيضة)</label>
                      <input type="number" defaultValue="150000" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-textSecondary dark:text-darkTextSec mb-1.5">درجة حرارة التخزين المثالية (°C)</label>
                      <input type="number" defaultValue="18" step="0.5" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500" />
                    </div>
                  </div>
                  <div className="border-t border-uiBorder dark:border-darkBorder pt-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">خيارات الإنتاج</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      <ToggleSwitch label="تسجيل الإنتاج تلقائياً" />
                      <ToggleSwitch label="تنبيه تجاوز هدف الإنتاج" defaultOn />
                      <ToggleSwitch label="تتبع جودة البيض" defaultOn />
                      <ToggleSwitch label="ربط الإنتاج بالمخزون" defaultOn />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Backup ─── */}
            {activeTab === 'backup' && (
              <motion.div key="backup" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-1">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4 mb-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">جدولة النسخ الاحتياطي</h4>
                      <div className="space-y-3">
                        <label className="flex items-center gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder cursor-pointer hover:bg-surface dark:hover:bg-darkBg transition-colors">
                          <input type="radio" name="schedule" value="daily" checked={backupSchedule === 'daily'} onChange={e => setBackupSchedule(e.target.value)} className="text-[#0a4a30]" />
                          <div>
                            <p className="text-sm font-medium text-textPrimary dark:text-darkText">يومي</p>
                            <p className="text-[11px] text-textMuted">كل يوم الساعة 2:00 صباحاً</p>
                          </div>
                        </label>
                        <label className="flex items-center gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder cursor-pointer hover:bg-surface dark:hover:bg-darkBg transition-colors">
                          <input type="radio" name="schedule" value="weekly" checked={backupSchedule === 'weekly'} onChange={e => setBackupSchedule(e.target.value)} className="text-[#0a4a30]" />
                          <div>
                            <p className="text-sm font-medium text-textPrimary dark:text-darkText">أسبوعي</p>
                            <p className="text-[11px] text-textMuted">كل أحد الساعة 2:00 صباحاً</p>
                          </div>
                        </label>
                        <label className="flex items-center gap-3 p-3 rounded-lg border border-uiBorder dark:border-darkBorder cursor-pointer hover:bg-surface dark:hover:bg-darkBg transition-colors">
                          <input type="radio" name="schedule" value="manual" checked={backupSchedule === 'manual'} onChange={e => setBackupSchedule(e.target.value)} className="text-[#0a4a30]" />
                          <div>
                            <p className="text-sm font-medium text-textPrimary dark:text-darkText">يدوي</p>
                            <p className="text-[11px] text-textMuted">بدون جدولة تلقائية</p>
                          </div>
                        </label>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">نسخ احتياطي الآن</h4>
                      <p className="text-xs text-textSecondary dark:text-darkTextSec mb-3">إنشاء نسخة احتياطية يدوية فورية لجميع بيانات النظام</p>
                      <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-[#0a4a30] hover:bg-[#0d6b43] text-white rounded-lg text-sm font-medium transition-colors">
                        <Database size={16} /> إنشاء نسخة احتياطية
                      </button>
                    </div>
                  </div>
                  <div className="lg:col-span-2">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">سجل النسخ الاحتياطي</h4>
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['التاريخ', 'النوع', 'الحجم', 'الحالة', ''].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {BACKUP_HISTORY.map((b, i) => (
                            <motion.tr key={b.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{b.date}</td>
                              <td className="px-3 py-2.5">
                                <span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', b.type === 'تلقائي' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700')}>{b.type}</span>
                              </td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{b.size}</td>
                              <td className="px-3 py-2.5">
                                <span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', b.status === 'ناجح' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700')}>{b.status}</span>
                              </td>
                              <td className="px-3 py-2.5">
                                <div className="flex items-center gap-1 justify-center">
                                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors" title="تحميل"><Download size={15} /></button>
                                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-amber-500 hover:bg-amber-50 transition-colors" title="استعادة"><RotateCcw size={15} /></button>
                                </div>
                              </td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Audit Log ─── */}
            {activeTab === 'audit' && (
              <motion.div key="audit" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">سجل النشاطات</h3>
                  <div className="flex items-center gap-2">
                    <button className="flex items-center gap-1.5 px-3 py-1.5 border border-uiBorder rounded-lg text-xs text-textSecondary hover:bg-surface transition-colors">
                      <Download size={14} /> تصدير
                    </button>
                    <div className="relative w-48">
                      <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                      <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                        className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                    </div>
                  </div>
                </div>
                <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                        {['التاريخ', 'المستخدم', 'الإجراء', 'الوحدة', 'التفاصيل', 'الأهمية'].map(h => (
                          <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {AUDIT_LOG.filter(a => !searchQ || a.user.includes(searchQ) || a.action.includes(searchQ) || a.module.includes(searchQ)).map((a, i) => (
                        <motion.tr key={a.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                          className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                        >
                          <td className="px-3 py-2.5 text-[11px] text-textMuted whitespace-nowrap">{a.date}</td>
                          <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{a.user}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{a.action}</td>
                          <td className="px-3 py-2.5"><span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-surface dark:bg-darkBg text-textSecondary dark:text-darkTextSec">{a.module}</span></td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec max-w-xs truncate">{a.details}</td>
                          <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', severityBadge(a.severity))}>
                            {a.severity === 'info' ? 'معلومة' : a.severity === 'warning' ? 'تنبيه' : 'خطير'}
                          </span></td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
