import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DollarSign, Clock, AlertTriangle, Phone,
  Ban, Send, CalendarDays, Eye, X, TrendingDown
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

const agingData = [
  { id: 1, customer: 'مؤسسة الريف الزراعية', totalDebt: 450000, d030: 120000, d3060: 150000, d6090: 130000, d90plus: 50000, creditLimit: 600000 },
  { id: 2, customer: 'شركة الدلتا للأعلاف', totalDebt: 920000, d030: 200000, d3060: 350000, d6090: 250000, d90plus: 120000, creditLimit: 1000000 },
  { id: 3, customer: 'مؤسسة النيل للتسويق', totalDebt: 340000, d030: 180000, d3060: 120000, d6090: 40000, d90plus: 0, creditLimit: 500000 },
  { id: 4, customer: 'مزارع النور', totalDebt: 125000, d030: 45000, d3060: 50000, d6090: 30000, d90plus: 0, creditLimit: 200000 },
  { id: 5, customer: 'مزرعة الذهبية', totalDebt: 78000, d030: 0, d3060: 0, d6090: 28000, d90plus: 50000, creditLimit: 150000 },
  { id: 6, customer: 'شركة الصعيد الزراعية', totalDebt: 285000, d030: 85000, d3060: 100000, d6090: 80000, d90plus: 20000, creditLimit: 400000 },
  { id: 7, customer: 'مؤسسة الوفاء', totalDebt: 560000, d030: 60000, d3060: 120000, d6090: 200000, d90plus: 180000, creditLimit: 700000 },
  { id: 8, customer: 'مزارع السلام', totalDebt: 0, d030: 0, d3060: 0, d6090: 0, d90plus: 0, creditLimit: 100000 },
];

const paymentHistory = [
  { id: 1, date: '2025-01-10', amount: 50000, method: 'تحويل بنكي', reference: 'TRF-001' },
  { id: 2, date: '2025-01-05', amount: 75000, method: 'نقدي', reference: 'CSH-012' },
  { id: 3, date: '2024-12-28', amount: 30000, method: 'شيك', reference: 'CHK-005' },
  { id: 4, date: '2024-12-20', amount: 45000, method: 'تحويل بنكي', reference: 'TRF-002' },
];

export default function CustomerDebtsPage() {
  const [showDetail, setShowDetail] = useState<number | null>(null);
  const [showAction, setShowAction] = useState<{customerId: number, action: string} | null>(null);
  const [filterOverdue, setFilterOverdue] = useState(false);

  const totalDebt = agingData.reduce((s, c) => s + c.totalDebt, 0);
  const d30 = agingData.reduce((s, c) => s + c.d030, 0);
  const d60 = agingData.reduce((s, c) => s + c.d3060, 0);
  const d90 = agingData.reduce((s, c) => s + c.d6090, 0);
  const d90plus = agingData.reduce((s, c) => s + c.d90plus, 0);

  const filteredData = filterOverdue
    ? agingData.filter((c) => c.totalDebt > c.creditLimit * 0.8)
    : agingData;

  const agingRowColor = (row: typeof agingData[0]) => {
    if (row.d90plus > 0) return 'bg-red-50/50 dark:bg-red-950/10';
    if (row.d6090 > 0) return 'bg-orange-50/50 dark:bg-orange-950/10';
    if (row.d3060 > 0) return 'bg-yellow-50/50 dark:bg-yellow-950/10';
    if (row.totalDebt > 0) return 'bg-green-50/50 dark:bg-green-950/10';
    return '';
  };

  const percentOfCredit = (debt: number, limit: number) => ((debt / limit) * 100).toFixed(0);

  const detailCustomer = agingData.find((c) => c.id === showDetail);

  return (
    <div className="space-y-6">
      <PageHeader
        title="متابعة ديون العملاء"
        subtitle="تحليل عمر الديون ومتابعة التحصيل"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'العملاء', path: '/customers' },
          { label: 'الديون' },
        ]}
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="إجمالي الذمم" value={formatCurrency(totalDebt)} icon={DollarSign} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="آجل 30 يوم" value={formatCurrency(d30)} icon={Clock} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.1} />
        <KPICard title="آجل 60 يوم" value={formatCurrency(d60)} icon={AlertTriangle} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="آجل 90+ يوم" value={formatCurrency(d90plus)} icon={TrendingDown} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Aging Distribution Bars */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">توزيع عمر الديون</h3>
        <div className="w-full h-6 rounded-full overflow-hidden flex">
          {d30 > 0 && (
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(d30 / totalDebt) * 100}%` }}
              transition={{ duration: 0.5 }}
              className="h-full bg-green-500"
              title={`0-30 يوم: ${formatCurrency(d30)}`}
            />
          )}
          {d60 > 0 && (
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(d60 / totalDebt) * 100}%` }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="h-full bg-amber-400"
              title={`30-60 يوم: ${formatCurrency(d60)}`}
            />
          )}
          {d90 > 0 && (
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(d90 / totalDebt) * 100}%` }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="h-full bg-orange-500"
              title={`60-90 يوم: ${formatCurrency(d90)}`}
            />
          )}
          {d90plus > 0 && (
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(d90plus / totalDebt) * 100}%` }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="h-full bg-red-500"
              title={`90+ يوم: ${formatCurrency(d90plus)}`}
            />
          )}
        </div>
        <div className="flex gap-4 mt-2 text-xs">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" /> 0-30: {formatCurrency(d30)}</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-400" /> 30-60: {formatCurrency(d60)}</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-orange-500" /> 60-90: {formatCurrency(d90)}</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> 90+: {formatCurrency(d90plus)}</span>
        </div>
      </motion.div>

      {/* Filter */}
      <div className="flex gap-2">
        <button
          onClick={() => setFilterOverdue(!filterOverdue)}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            filterOverdue ? 'bg-red-600 text-white' : 'bg-white dark:bg-darkSurface border border-uiBorder dark:border-darkBorder text-textSecondary'
          }`}
        >
          {filterOverdue ? 'عرض الكل' : 'عرض المتأخر فقط'}
        </button>
      </div>

      {/* Aging Table */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">العميل</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">إجمالي الدين</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec"><span className="text-green-600">0-30 يوم</span></th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec"><span className="text-amber-500">30-60 يوم</span></th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec"><span className="text-orange-500">60-90 يوم</span></th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec"><span className="text-red-500">90+ يوم</span></th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">حد الائتمان</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-uiBorder/50 dark:divide-darkBorder/30">
              {filteredData.map((row) => (
                <motion.tr
                  key={row.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={`hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors ${agingRowColor(row)}`}
                >
                  <td className="px-4 py-3 text-sm font-medium text-textPrimary dark:text-darkText">{row.customer}</td>
                  <td className="px-4 py-3 text-sm font-bold text-textPrimary dark:text-darkText">{formatCurrency(row.totalDebt)}</td>
                  <td className="px-4 py-3 text-sm text-green-600">{row.d030 > 0 ? formatCurrency(row.d030) : '—'}</td>
                  <td className="px-4 py-3 text-sm text-amber-600">{row.d3060 > 0 ? formatCurrency(row.d3060) : '—'}</td>
                  <td className="px-4 py-3 text-sm text-orange-600">{row.d6090 > 0 ? formatCurrency(row.d6090) : '—'}</td>
                  <td className="px-4 py-3 text-sm text-red-600">{row.d90plus > 0 ? formatCurrency(row.d90plus) : '—'}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1">
                      <span className="text-xs text-textSecondary">{formatCurrency(row.creditLimit)}</span>
                      <div className="w-20 h-1.5 bg-surface dark:bg-darkCard rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${Number(percentOfCredit(row.totalDebt, row.creditLimit)) > 80 ? 'bg-red-500' : Number(percentOfCredit(row.totalDebt, row.creditLimit)) > 50 ? 'bg-amber-500' : 'bg-green-500'}`}
                          style={{ width: `${Math.min(100, Number(percentOfCredit(row.totalDebt, row.creditLimit)))}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setShowDetail(row.id)} className="w-7 h-7 rounded flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors" title="عرض">
                        <Eye size={14} />
                      </button>
                      <button onClick={() => setShowAction({customerId: row.id, action: 'reminder'})} className="w-7 h-7 rounded flex items-center justify-center text-green-500 hover:bg-green-50 dark:hover:bg-green-950/30 transition-colors" title="إرسال تذكير">
                        <Send size={14} />
                      </button>
                      <button onClick={() => setShowAction({customerId: row.id, action: 'call'})} className="w-7 h-7 rounded flex items-center justify-center text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/30 transition-colors" title="جدولة مكالمة">
                        <Phone size={14} />
                      </button>
                      {row.d90plus > 0 && (
                        <button onClick={() => setShowAction({customerId: row.id, action: 'block'})} className="w-7 h-7 rounded flex items-center justify-center text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors" title="حظر">
                          <Ban size={14} />
                        </button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetail && detailCustomer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowDetail(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{detailCustomer.customer}</h3>
                <button onClick={() => setShowDetail(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/20">
                    <p className="text-xs text-blue-600">إجمالي الدين</p>
                    <p className="text-lg font-bold text-blue-700 dark:text-blue-400">{formatCurrency(detailCustomer.totalDebt)}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 dark:bg-green-950/20">
                    <p className="text-xs text-green-600">حد الائتمان</p>
                    <p className="text-lg font-bold text-green-700 dark:text-green-400">{formatCurrency(detailCustomer.creditLimit)}</p>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-2">توزيع عمر الديون</h4>
                  <div className="space-y-2">
                    {[
                      { label: '0-30 يوم', value: detailCustomer.d030, color: 'text-green-600', bg: 'bg-green-500' },
                      { label: '30-60 يوم', value: detailCustomer.d3060, color: 'text-amber-600', bg: 'bg-amber-400' },
                      { label: '60-90 يوم', value: detailCustomer.d6090, color: 'text-orange-600', bg: 'bg-orange-500' },
                      { label: '90+ يوم', value: detailCustomer.d90plus, color: 'text-red-600', bg: 'bg-red-500' },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center gap-3">
                        <span className="text-xs text-textSecondary w-16">{item.label}</span>
                        <div className="flex-1 h-2 bg-surface dark:bg-darkCard rounded-full overflow-hidden">
                          <div className={`h-full ${item.bg} rounded-full`} style={{ width: `${detailCustomer.totalDebt > 0 ? (item.value / detailCustomer.totalDebt) * 100 : 0}%` }} />
                        </div>
                        <span className={`text-xs font-medium ${item.color} w-24 text-left`}>{formatCurrency(item.value)}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-2">سجل المدفوعات</h4>
                  <div className="space-y-1">
                    {paymentHistory.map((p) => (
                      <div key={p.id} className="flex items-center justify-between p-2 rounded-lg bg-surface dark:bg-darkCard text-xs">
                        <span className="text-textSecondary">{p.date}</span>
                        <span className="font-medium text-green-600">{formatCurrency(p.amount)}</span>
                        <span className="text-textMuted">{p.method}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Action Modal */}
      <AnimatePresence>
        {showAction && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowAction(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-sm p-5"
            >
              <div className="text-center mb-4">
                <div className={`w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center ${
                  showAction.action === 'reminder' ? 'bg-green-100' : showAction.action === 'call' ? 'bg-amber-100' : 'bg-red-100'
                }`}>
                  {showAction.action === 'reminder' && <Send size={20} className="text-green-600" />}
                  {showAction.action === 'call' && <Phone size={20} className="text-amber-600" />}
                  {showAction.action === 'block' && <Ban size={20} className="text-red-600" />}
                </div>
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">
                  {showAction.action === 'reminder' && 'إرسال تذكير بالدفع'}
                  {showAction.action === 'call' && 'جدولة مكالمة'}
                  {showAction.action === 'block' && 'حظر الحساب'}
                </h3>
                <p className="text-xs text-textSecondary mt-1">
                  {showAction.action === 'reminder' && 'سيتم إرسال إشعار للعميل بالمبالغ المستحقة'}
                  {showAction.action === 'call' && 'تحديد موعد للاتصال بالعميل'}
                  {showAction.action === 'block' && 'منع العميل من إجراء طلبات جديدة'}
                </p>
              </div>
              {showAction.action === 'call' && (
                <div className="mb-4">
                  <label className="text-xs text-textSecondary mb-1 block">تاريخ المكالمة</label>
                  <input type="date" className="w-full h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
                </div>
              )}
              <div className="flex gap-2">
                <button onClick={() => setShowAction(null)} className="flex-1 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary">إلغاء</button>
                <button onClick={() => setShowAction(null)} className={`flex-1 py-2 rounded-lg text-white text-sm font-medium ${
                  showAction.action === 'reminder' ? 'bg-green-700 hover:bg-green-800' :
                  showAction.action === 'call' ? 'bg-amber-600 hover:bg-amber-700' :
                  'bg-red-600 hover:bg-red-700'
                }`}>
                  تأكيد
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
