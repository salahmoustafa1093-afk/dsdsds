import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, Plus, X, Shield, Eye, Edit3, Trash2,
  Check, UserCheck, UserX
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';

const roles = [
  'مدير عام',
  'مدير فرع',
  'محاسب',
  'مندوب مبيعات',
  'أمين مخزن',
  'مدير إنتاج',
  'مدير HR',
];

const users = [
  { id: 1, name: 'محمد أحمد', email: 'm.ahmed@gff.com', role: 'مدير عام', branch: 'الرئيسي', lastLogin: '2025-01-15 09:30', status: 'نشط' },
  { id: 2, name: 'أحمد علي', email: 'a.ali@gff.com', role: 'محاسب', branch: 'الرئيسي', lastLogin: '2025-01-15 08:15', status: 'نشط' },
  { id: 3, name: 'محمود سالم', email: 'm.salem@gff.com', role: 'مندوب مبيعات', branch: 'الإسكندرية', lastLogin: '2025-01-14 16:45', status: 'نشط' },
  { id: 4, name: 'خالد عمر', email: 'k.omar@gff.com', role: 'مدير إنتاج', branch: 'الرئيسي', lastLogin: '2025-01-15 07:50', status: 'نشط' },
  { id: 5, name: 'يوسف إبراهيم', email: 'y.ibrahim@gff.com', role: 'أمين مخزن', branch: 'طنطا', lastLogin: '2025-01-13 10:20', status: 'غير نشط' },
  { id: 6, name: 'سارة محمود', email: 's.mahmoud@gff.com', role: 'مدير HR', branch: 'الرئيسي', lastLogin: '2025-01-15 09:00', status: 'نشط' },
  { id: 7, name: 'عبدالله حسن', email: 'a.hassan@gff.com', role: 'مدير فرع', branch: 'الإسكندرية', lastLogin: '2025-01-14 14:30', status: 'نشط' },
];

const modules = [
  'الرئيسية', 'المخزون', 'المنتجات', 'المبيعات', 'المشتريات',
  'العملاء', 'الموردين', 'الحسابات', 'الإنتاج', 'الموارد البشرية',
  'الفروع', 'التقارير', 'الإعدادات', 'B2B', 'الأسطول', 'التوصيل',
];

const actions = ['عرض', 'إنشاء', 'تعديل', 'حذف', 'اعتماد', 'تصدير'];

const defaultPermissions: Record<string, boolean[]> = {};
modules.forEach((m) => {
  defaultPermissions[m] = actions.map(() => false);
});

export default function SettingsUsersPage() {
  const [showForm, setShowForm] = useState(false);
  const [showPermissions, setShowPermissions] = useState(false);
  const [permissions, setPermissions] = useState(defaultPermissions);
  const [userList, setUserList] = useState(users);

  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formRole, setFormRole] = useState(roles[0]);
  const [formBranch, setFormBranch] = useState('الرئيسي');
  const [formPhone, setFormPhone] = useState('');

  const togglePermission = (mod: string, idx: number) => {
    setPermissions((prev) => ({
      ...prev,
      [mod]: prev[mod].map((v, i) => (i === idx ? !v : v)),
    }));
  };

  const applyTemplate = (role: string) => {
    const p: Record<string, boolean[]> = {};
    modules.forEach((m) => {
      p[m] = actions.map(() => false);
    });
    if (role === 'مدير عام') {
      modules.forEach((m) => { p[m] = actions.map(() => true); });
    } else if (role === 'محاسب') {
      ['الرئيسية', 'الحسابات', 'التقارير', 'المبيعات', 'المشتريات'].forEach((m) => {
        p[m] = [true, true, true, false, true, true];
      });
    } else if (role === 'مندوب مبيعات') {
      ['الرئيسية', 'المبيعات', 'العملاء'].forEach((m) => {
        p[m] = [true, true, true, false, false, false];
      });
    } else if (role === 'أمين مخزن') {
      ['الرئيسية', 'المخزون', 'المنتجات'].forEach((m) => {
        p[m] = [true, true, true, false, false, true];
      });
    }
    setPermissions(p);
  };

  const handleAddUser = () => {
    if (!formName || !formEmail) return;
    setUserList([{ id: Date.now(), name: formName, email: formEmail, role: formRole, branch: formBranch, lastLogin: '—', status: 'نشط' }, ...userList]);
    setShowForm(false);
    setFormName('');
    setFormEmail('');
    setFormPassword('');
    setFormPhone('');
  };

  const statusBadge = (status: string) => (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
      status === 'نشط'
        ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400'
        : 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
    }`}>
      {status === 'نشط' ? <UserCheck size={12} /> : <UserX size={12} />}
      {status}
    </span>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="المستخدمين والصلاحيات"
        subtitle="إدارة المستخدمين ومصفوفة الصلاحيات"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الإعدادات', path: '/settings' },
          { label: 'المستخدمين' },
        ]}
      >
        <button
          onClick={() => setShowPermissions(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm font-medium text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard transition-colors"
        >
          <Shield size={16} />
          <span>مصفوفة الصلاحيات</span>
        </button>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>مستخدم جديد</span>
        </button>
      </PageHeader>

      {/* Users Table */}
      <DataTable
        title="قائمة المستخدمين"
        columns={[
          { key: 'name', header: 'الاسم', sortable: true },
          { key: 'email', header: 'البريد الإلكتروني', sortable: true },
          { key: 'role', header: 'الدور', sortable: true },
          { key: 'branch', header: 'الفرع', sortable: true },
          { key: 'lastLogin', header: 'آخر دخول', sortable: true },
          { key: 'status', header: 'الحالة', render: (row) => statusBadge(row.status as string) },
        ]}
        data={userList as unknown as Record<string, unknown>[]}
        rowActions={{ onEdit: () => {}, onDelete: () => {} }}
        pageSize={7}
      />

      {/* Add User Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إضافة مستخدم جديد</h3>
                <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الاسم</label>
                    <input value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="الاسم الكامل" />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">البريد الإلكتروني</label>
                    <input type="email" value={formEmail} onChange={(e) => setFormEmail(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="email@example.com" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">كلمة المرور</label>
                    <input type="password" value={formPassword} onChange={(e) => setFormPassword(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="********" />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الهاتف</label>
                    <input value={formPhone} onChange={(e) => setFormPhone(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="01xxxxxxxxx" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الدور</label>
                    <select value={formRole} onChange={(e) => setFormRole(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      {roles.map((r) => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الفرع</label>
                    <select value={formBranch} onChange={(e) => setFormBranch(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      <option>الرئيسي</option>
                      <option>الإسكندرية</option>
                      <option>طنطا</option>
                      <option>المنصورة</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إلغاء</button>
                <button onClick={handleAddUser} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors flex items-center gap-1">
                  <Check size={14} />
                  حفظ
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Permission Matrix Modal */}
      <AnimatePresence>
        {showPermissions && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowPermissions(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">مصفوفة الصلاحيات</h3>
                <button onClick={() => setShowPermissions(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 border-b border-uiBorder dark:border-darkBorder flex gap-2 flex-wrap">
                <span className="text-sm text-textSecondary">قالب:</span>
                {roles.map((r) => (
                  <button
                    key={r}
                    onClick={() => applyTemplate(r)}
                    className="px-3 py-1 rounded-lg text-xs font-medium bg-surface dark:bg-darkCard border border-uiBorder dark:border-darkBorder text-textPrimary dark:text-darkText hover:border-green-500 transition-colors"
                  >
                    {r}
                  </button>
                ))}
              </div>
              <div className="flex-1 overflow-auto p-5">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                        <th className="px-3 py-2 text-right text-xs font-semibold text-textSecondary sticky right-0 bg-surface dark:bg-darkBg/60">الوحدة</th>
                        {actions.map((a) => (
                          <th key={a} className="px-3 py-2 text-center text-xs font-semibold text-textSecondary">{a}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-uiBorder/50 dark:divide-darkBorder/30">
                      {modules.map((mod) => (
                        <tr key={mod} className="hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors">
                          <td className="px-3 py-2 text-sm font-medium text-textPrimary dark:text-darkText sticky right-0 bg-white dark:bg-darkSurface">{mod}</td>
                          {actions.map((_, idx) => (
                            <td key={idx} className="px-3 py-2 text-center">
                              <button
                                onClick={() => togglePermission(mod, idx)}
                                className={`w-5 h-5 rounded border-2 transition-colors ${
                                  permissions[mod]?.[idx]
                                    ? 'bg-green-600 border-green-600'
                                    : 'border-uiBorder dark:border-darkBorder bg-transparent'
                                }`}
                              >
                                {permissions[mod]?.[idx] && <Check size={12} className="text-white mx-auto" />}
                              </button>
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowPermissions(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إغلاق</button>
                <button onClick={() => setShowPermissions(false)} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">حفظ الصلاحيات</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
