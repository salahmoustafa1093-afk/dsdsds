import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line
} from 'recharts';
import {
  Package, RefreshCw, AlertTriangle, Percent,
  Play, Download, FileText
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

const stockLevels = [
  { warehouse: 'الرئيسي', current: 4500, min: 1000, max: 8000 },
  { warehouse: 'الإسكندرية', current: 2800, min: 800, max: 5000 },
  { warehouse: 'طنطا', current: 1200, min: 600, max: 3000 },
  { warehouse: 'المنصورة', current: 900, min: 500, max: 2500 },
  { warehouse: 'أسيوط', current: 650, min: 400, max: 2000 },
];

const inventoryByCategory = [
  { name: 'أعلاف دواجن', value: 1800000, color: '#14a86a' },
  { name: 'أعلاف مواشي', value: 950000, color: '#daa520' },
  { name: 'مواد خام', value: 3200000, color: '#3b82f6' },
  { name: 'بقوليات', value: 450000, color: '#f59e0b' },
  { name: 'منتجات تامة', value: 1200000, color: '#8b5cf6' },
];

const turnoverTrend = [
  { month: 'يناير', turnover: 4.2 },
  { month: 'فبراير', turnover: 3.8 },
  { month: 'مارس', turnover: 4.5 },
  { month: 'ابريل', turnover: 4.0 },
  { month: 'مايو', turnover: 4.8 },
  { month: 'يونيو', turnover: 4.3 },
];

const stockAging = [
  { range: '0-30 يوم', count: 142, value: 4200000 },
  { range: '30-60 يوم', count: 38, value: 980000 },
  { range: '60-90 يوم', count: 15, value: 520000 },
  { range: '90+ يوم', count: 8, value: 200000 },
];

const reportsList = [
  { id: 1, name: 'تقرير جرد المخزون', description: 'جرد شامل لجميع المستودعات' },
  { id: 2, name: 'حركة الأصناف', description: 'حركة الصادر والوارد لكل صنف' },
  { id: 3, name: 'الأصناف الراكدة', description: 'أصناف لم تحرك لفترة طويلة' },
  { id: 4, name: 'الأصناف تحت الحد', description: 'أصناف وصلت للحد الأدنى' },
  { id: 5, name: 'تقرير الهدر', description: 'الهالك والهدر في المخزون' },
];

export default function ReportsInventoryPage() {
  const [selectedReport, setSelectedReport] = useState<number | null>(null);

  const totalInventory = inventoryByCategory.reduce((s, c) => s + c.value, 0);
  const avgTurnover = (turnoverTrend.reduce((s, t) => s + t.turnover, 0) / turnoverTrend.length).toFixed(1);
  const stagnantItems = stockAging.find((s) => s.range === '90+ يوم')?.count || 0;
  const wastePercent = 2.3;

  return (
    <div className="space-y-6">
      <PageHeader
        title="تقارير المخزون"
        subtitle="تحليل المخزون ودورانه والأصناف الراكدة"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'التقارير', path: '/reports' },
          { label: 'تقارير المخزون' },
        ]}
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="قيمة المخزون" value={formatCurrency(totalInventory)} icon={Package} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="دوران المخزون" value={avgTurnover} icon={RefreshCw} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="أصناف راكدة" value={String(stagnantItems)} icon={AlertTriangle} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.2} />
        <KPICard title="نسبة الهدر" value={`${wastePercent}%`} icon={Percent} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.3} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Stock Levels Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 lg:col-span-2"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">مستويات المخزون حسب المستودع</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={stockLevels}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="warehouse" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="current" name="الحالي" fill="#14a86a" radius={[4, 4, 0, 0]} />
              <Bar dataKey="min" name="الحد الأدنى" fill="#ef4444" radius={[4, 4, 0, 0]} />
              <Bar dataKey="max" name="السعة" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Inventory Value by Category Pie */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">قيمة المخزون حسب الفئة</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={inventoryByCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}>
                {inventoryByCategory.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Turnover Trend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 lg:col-span-2"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">اتجاه دوران المخزون</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={turnoverTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} domain={[2, 6]} />
              <Tooltip />
              <Line type="monotone" dataKey="turnover" name="معدل الدوران" stroke="#daa520" strokeWidth={3} dot={{ fill: '#daa520' }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Stock Aging */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">تحليل عمر المخزون</h3>
          <div className="space-y-3">
            {stockAging.map((s) => (
              <div key={s.range} className="flex items-center justify-between p-3 rounded-lg bg-surface dark:bg-darkCard">
                <div>
                  <p className="text-sm font-medium text-textPrimary dark:text-darkText">{s.range}</p>
                  <p className="text-xs text-textSecondary">{s.count} صنف</p>
                </div>
                <p className="text-sm font-bold text-textPrimary dark:text-darkText">{formatCurrency(s.value)}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Reports List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.5 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">التقارير المتاحة</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {reportsList.map((report) => (
            <div
              key={report.id}
              className={`p-4 rounded-lg border transition-colors cursor-pointer ${
                selectedReport === report.id
                  ? 'border-green-500 bg-green-50 dark:bg-green-950/20'
                  : 'border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkCard'
              }`}
              onClick={() => setSelectedReport(report.id === selectedReport ? null : report.id)}
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <FileText size={18} className="text-green-700 dark:text-green-400" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{report.name}</h4>
                  <p className="text-xs text-textSecondary mt-0.5">{report.description}</p>
                </div>
                <div className="flex gap-1">
                  <button className="w-7 h-7 rounded flex items-center justify-center text-green-600 hover:bg-green-50 dark:hover:bg-green-950/30 transition-colors">
                    <Play size={14} />
                  </button>
                  <button className="w-7 h-7 rounded flex items-center justify-center text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">
                    <Download size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Aging Table */}
      <DataTable
        title="تفاصيل تقادم المخزون"
        columns={[
          { key: 'range', header: 'الفترة', sortable: true },
          { key: 'count', header: 'عدد الأصناف', sortable: true },
          { key: 'value', header: 'القيمة', render: (row) => <span className="font-medium">{formatCurrency(row.value as number)}</span> },
          { key: 'percent', header: 'النسبة', render: (row) => <span>{((row.value as number) / totalInventory * 100).toFixed(1)}%</span> },
        ]}
        data={stockAging as unknown as Record<string, unknown>[]}
        pageSize={5}
      />
    </div>
  );
}
