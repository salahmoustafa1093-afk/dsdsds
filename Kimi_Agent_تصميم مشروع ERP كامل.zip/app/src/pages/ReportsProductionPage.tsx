import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend
} from 'recharts';
import {
  Factory, Gauge, Trash2, Zap,
  FileText, Play, Download, AlertCircle
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';

const dailyOutput = [
  { day: 'السبت', line1: 450, line2: 380, line3: 290 },
  { day: 'الأحد', line1: 470, line2: 400, line3: 310 },
  { day: 'الإثنين', line1: 440, line2: 370, line3: 280 },
  { day: 'الثلاثاء', line1: 480, line2: 410, line3: 320 },
  { day: 'الأربعاء', line1: 460, line2: 390, line3: 300 },
  { day: 'الخميس', line1: 420, line2: 350, line3: 270 },
  { day: 'الجمعة', line1: 200, line2: 150, line3: 100 },
];

const oeeTrend = [
  { month: 'يناير', oee: 82 },
  { month: 'فبراير', oee: 78 },
  { month: 'مارس', oee: 85 },
  { month: 'ابريل', oee: 80 },
  { month: 'مايو', oee: 88 },
  { month: 'يونيو', oee: 84 },
];

const wasteBreakdown = [
  { name: 'هدر المواد الخام', value: 45, color: '#14a86a' },
  { name: 'منتج تالف', value: 25, color: '#daa520' },
  { name: 'فاقد تشغيلي', value: 20, color: '#3b82f6' },
  { name: 'عيوب تعبئة', value: 10, color: '#ef4444' },
];

const lineComparison = [
  { name: 'الخط 1', output: 2920, capacity: 3500, efficiency: 83.4 },
  { name: 'الخط 2', output: 2450, capacity: 3000, efficiency: 81.7 },
  { name: 'الخط 3', output: 1870, capacity: 2500, efficiency: 74.8 },
];

const downtimeData = [
  { id: 1, line: 'الخط 1', date: '2025-01-15', duration: 45, reason: 'صيانة دورية', type: 'مخطط' },
  { id: 2, line: 'الخط 2', date: '2025-01-14', duration: 120, reason: 'عطل في المحرك', type: 'غير مخطط' },
  { id: 3, line: 'الخط 1', date: '2025-01-13', duration: 30, reason: 'تغيير القالب', type: 'مخطط' },
  { id: 4, line: 'الخط 3', date: '2025-01-12', duration: 90, reason: 'انقطاع كهرباء', type: 'غير مخطط' },
  { id: 5, line: 'الخط 2', date: '2025-01-11', duration: 20, reason: 'تنظيف', type: 'مخطط' },
];

const reportsList = [
  { id: 1, name: 'إنتاج يومي', description: 'تقرير الإنتاج اليومي لكل خط' },
  { id: 2, name: 'كفاءة الخطوط', description: 'تحليل OEE لكل خط إنتاج' },
  { id: 3, name: 'هدر الإنتاج', description: 'تحليل نسبة الهدر والفاقد' },
  { id: 4, name: 'تكلفة الإنتاج', description: 'تحليل تكلفة إنتاج الوحدة' },
  { id: 5, name: 'توقفات الخطوط', description: 'تحليل أسباب وتكرار التوقفات' },
];

export default function ReportsProductionPage() {
  const [selectedReport, setSelectedReport] = useState<number | null>(null);

  const dailyProd = 960;
  const oee = 84;
  const wasteRate = 3.2;
  const utilization = 78;

  return (
    <div className="space-y-6">
      <PageHeader
        title="تقارير الإنتاج"
        subtitle="تحليل الإنتاج وكفاءة الخطوط والهدر"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'التقارير', path: '/reports' },
          { label: 'تقارير الإنتاج' },
        ]}
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="الإنتاج اليومي" value={`${dailyProd} طن`} icon={Factory} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="OEE" value={`${oee}%`} icon={Gauge} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="معدل الهدر" value={`${wasteRate}%`} icon={Trash2} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.2} />
        <KPICard title="طاقة الاستيعاب" value={`${utilization}%`} icon={Zap} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.3} />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Daily Output Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">الإنتاج اليومي حسب الخط</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={dailyOutput}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="line1" name="الخط 1" fill="#14a86a" radius={[4, 4, 0, 0]} />
              <Bar dataKey="line2" name="الخط 2" fill="#daa520" radius={[4, 4, 0, 0]} />
              <Bar dataKey="line3" name="الخط 3" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* OEE Trend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">اتجاه OEE</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={oeeTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis domain={[60, 100]} tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value: number) => `${value}%`} />
              <Line type="monotone" dataKey="oee" name="OEE %" stroke="#14a86a" strokeWidth={3} dot={{ fill: '#14a86a' }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Waste Pie */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">تحليل نسبة الهدر</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={wasteBreakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={85} label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}>
                {wasteBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Line Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 lg:col-span-2"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">مقارنة الخطوط الإنتاجية</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={lineComparison}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="output" name="الإنتاج الفعلي" fill="#14a86a" radius={[4, 4, 0, 0]} />
              <Bar dataKey="capacity" name="الطاقة القصوى" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Line Efficiency Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {lineComparison.map((line, i) => (
          <motion.div
            key={line.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 * i }}
            className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{line.name}</h4>
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${line.efficiency >= 80 ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400' : 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400'}`}>
                {line.efficiency}%
              </span>
            </div>
            <div className="w-full h-2 bg-surface dark:bg-darkCard rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${line.efficiency}%` }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className={`h-full rounded-full ${line.efficiency >= 80 ? 'bg-green-500' : 'bg-amber-500'}`}
              />
            </div>
            <div className="flex justify-between mt-2 text-xs text-textSecondary">
              <span>الإنتاج: {line.output} طن</span>
              <span>الطاقة: {line.capacity} طن</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Downtime Analysis Table */}
      <DataTable
        title="تحليل التوقفات"
        columns={[
          { key: 'line', header: 'الخط', sortable: true },
          { key: 'date', header: 'التاريخ', sortable: true },
          { key: 'duration', header: 'المدة (دقيقة)', sortable: true },
          { key: 'reason', header: 'السبب', sortable: true },
          { key: 'type', header: 'النوع', render: (row) => (
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
              row.type === 'مخطط'
                ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400'
                : 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
            }`}>
              {row.type === 'مخطط' ? <Zap size={12} /> : <AlertCircle size={12} />}
              {row.type as string}
            </span>
          ) },
        ]}
        data={downtimeData as unknown as Record<string, unknown>[]}
        pageSize={5}
      />

      {/* Reports List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.5 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">التقارير المتاحة</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {reportsList.map((report) => (
            <div
              key={report.id}
              className={`p-4 rounded-lg border transition-colors cursor-pointer ${
                selectedReport === report.id
                  ? 'border-green-500 bg-green-50 dark:bg-green-950/20'
                  : 'border-uiBorder dark:border-darkBorder hover:bg-surface dark:hover:bg-darkCard'
              }`}
              onClick={() => setSelectedReport(report.id === selectedReport ? null : report.id)}
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <FileText size={18} className="text-green-700 dark:text-green-400" />
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{report.name}</h4>
                  <p className="text-xs text-textSecondary mt-0.5">{report.description}</p>
                </div>
                <div className="flex gap-1">
                  <button className="w-7 h-7 rounded flex items-center justify-center text-green-600 hover:bg-green-50 dark:hover:bg-green-950/30 transition-colors">
                    <Play size={14} />
                  </button>
                  <button className="w-7 h-7 rounded flex items-center justify-center text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">
                    <Download size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
