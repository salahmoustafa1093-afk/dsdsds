// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Egg, Package, Truck, BarChart3, DollarSign, TrendingUp, TrendingDown,
  AlertTriangle, CheckCircle2, XCircle, Plus, Search, Eye, Edit3,
  Trash2, Filter, Download, Star, Layers, Scale, Thermometer,
  Droplets, Gauge, ArrowUpDown, ArrowUp, ArrowDown, MapPin,
  Calendar, ChevronLeft, ChevronRight, Users, Factory, ClipboardList
} from 'lucide-react';
import { cn } from '@/lib/utils';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

/* ─────────────────────── mock data ─────────────────────── */

const INVENTORY = {
  gradeA: { qty: 52000, price: 0.45, today: 8500, quality: 98 },
  gradeB: { qty: 38000, price: 0.38, today: 6200, quality: 95 },
  gradeC: { qty: 24000, price: 0.28, today: 4100, quality: 92 },
  gradeD: { qty: 11000, price: 0.18, today: 1800, quality: 88 },
};

const DISTRIBUTION_ORDERS = [
  { id: 'DO-2025-001', customer: 'سوبر ماركت الراية', grade: 'A', qty: 5000, price: 0.45, total: 2250, driver: 'أحمد العلي', status: 'قيد التوصيل', zone: 'الرياض' },
  { id: 'DO-2025-002', customer: 'مخبز الصفوة', grade: 'B', qty: 3000, price: 0.38, total: 1140, driver: 'خالد السبيعي', status: 'تم التسليم', zone: 'جدة' },
  { id: 'DO-2025-003', customer: 'مصنع الحلويات', grade: 'A', qty: 8000, price: 0.42, total: 3360, driver: 'سامي الدوسري', status: 'قيد التوصيل', zone: 'الدمام' },
  { id: 'DO-2025-004', customer: 'مطعم البستان', grade: 'C', qty: 2000, price: 0.28, total: 560, driver: 'ناصر القحطاني', status: 'تم التسليم', zone: 'الرياض' },
  { id: 'DO-2025-005', customer: 'فندق الجوهرة', grade: 'A', qty: 6000, price: 0.45, total: 2700, driver: 'فهد الزهراني', status: 'قيد التوصيل', zone: 'مكة' },
  { id: 'DO-2025-006', customer: 'سوبر ماركت النور', grade: 'B', qty: 4500, price: 0.38, total: 1710, driver: 'ماجد العتيبي', status: 'تم التسليم', zone: 'الطائف' },
  { id: 'DO-2025-007', customer: 'مخبوزات العائلة', grade: 'A', qty: 3500, price: 0.45, total: 1575, driver: 'سلطان المالكي', status: 'قيد التوصيل', zone: 'أبها' },
  { id: 'DO-2025-008', customer: 'كافيه لاتيه آرت', grade: 'B', qty: 2500, price: 0.38, total: 950, driver: 'تركي الشمري', status: 'تم التسليم', zone: 'الرياض' },
  { id: 'DO-2025-009', customer: 'مصنع البسكويت', grade: 'C', qty: 4000, price: 0.28, total: 1120, driver: 'بندر الفيصل', status: 'جديد', zone: 'جدة' },
  { id: 'DO-2025-010', customer: 'مطعم الشواية', grade: 'A', qty: 5500, price: 0.44, total: 2420, driver: '-', status: 'جديد', zone: 'الدمام' },
];

const GRADING_BATCHES = [
  { id: 'GR-001', date: '2025-01-15', total: 21500, gradeA: 9500, gradeB: 6800, gradeC: 3800, gradeD: 1400, wastage: 120, grader: 'عبدالله النعيمي', status: 'مكتمل' },
  { id: 'GR-002', date: '2025-01-15', total: 20800, gradeA: 8900, gradeB: 6500, gradeC: 4100, gradeD: 1100, wastage: 95, grader: 'محمد العتيبي', status: 'مكتمل' },
  { id: 'GR-003', date: '2025-01-14', total: 22100, gradeA: 10200, gradeB: 7100, gradeC: 3500, gradeD: 1050, wastage: 78, grader: 'عبدالله النعيمي', status: 'مكتمل' },
  { id: 'GR-004', date: '2025-01-14', total: 19800, gradeA: 8400, gradeB: 6200, gradeC: 3900, gradeD: 1150, wastage: 150, grader: 'فهد السهلي', status: 'مكتمل' },
  { id: 'GR-005', date: '2025-01-13', total: 20500, gradeA: 9000, gradeB: 6600, gradeC: 3600, gradeD: 1250, wastage: 85, grader: 'محمد العتيبي', status: 'مكتمل' },
];

const PRICING_HISTORY = [
  { date: '2025-01-15', gradeA: 0.45, gradeB: 0.38, gradeC: 0.28, gradeD: 0.18 },
  { date: '2025-01-14', gradeA: 0.44, gradeB: 0.37, gradeC: 0.28, gradeD: 0.18 },
  { date: '2025-01-13', gradeA: 0.44, gradeB: 0.37, gradeC: 0.27, gradeD: 0.17 },
  { date: '2025-01-12', gradeA: 0.43, gradeB: 0.37, gradeC: 0.27, gradeD: 0.17 },
  { date: '2025-01-11', gradeA: 0.43, gradeB: 0.36, gradeC: 0.27, gradeD: 0.17 },
  { date: '2025-01-10', gradeA: 0.42, gradeB: 0.36, gradeC: 0.26, gradeD: 0.16 },
  { date: '2025-01-09', gradeA: 0.42, gradeB: 0.35, gradeC: 0.26, gradeD: 0.16 },
];

const QUALITY_PARAMS = [
  { param: 'الوزن', gradeA: '>63g', gradeB: '53-63g', gradeC: '43-53g', gradeD: '<43g' },
  { param: 'اللون', gradeA: 'بني فاتح/داكن', gradeB: 'بني فاتح/داكن', gradeC: 'أبيض/بني', gradeD: 'متنوع' },
  { param: 'القشرة', gradeA: 'نظيفة سليمة', gradeB: 'نظيفة', gradeC: 'بقع طفيفة', gradeD: 'شوائب' },
  { param: 'الشكل', gradeA: 'بيضاوي مثالي', gradeB: 'بيضاوي', gradeC: 'شكل طبيعي', gradeD: 'مشوه' },
  { param: 'HU (الهوغ)', gradeA: '>72', gradeB: '65-72', gradeC: '55-65', gradeD: '<55' },
];

const TABS = [
  { key: 'inventory', label: 'المخزون', icon: Package },
  { key: 'distribution', label: 'التوزيع', icon: Truck },
  { key: 'grading', label: 'التصنيف', icon: Layers },
  { key: 'pricing', label: 'التسعير', icon: DollarSign },
  { key: 'analytics', label: 'التحليلات', icon: BarChart3 },
];

const statusBadge = (s: string) => {
  const map: Record<string, string> = {
    'قيد التوصيل': 'bg-blue-100 text-blue-700', 'تم التسليم': 'bg-green-100 text-green-700',
    'جديد': 'bg-amber-100 text-amber-700', 'مكتمل': 'bg-green-100 text-green-700',
  };
  return map[s] || 'bg-slate-100 text-slate-600';
};

/* ─────────────────────── mini charts ─────────────────────── */

function MiniBarChart({ data, labels, color }: { data: number[]; labels: string[]; color: string }) {
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-2 h-28">
      {data.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <span className="text-[10px] text-textMuted">{v}</span>
          <div className="w-full rounded-t-sm" style={{ height: `${(v / max) * 100}px`, backgroundColor: color, opacity: 0.5 + (i / data.length) * 0.5 }} />
          <span className="text-[10px] text-textMuted">{labels[i]}</span>
        </div>
      ))}
    </div>
  );
}

function MiniPieChart({ data, colors }: { data: number[]; colors: string[] }) {
  const total = data.reduce((a, b) => a + b, 0);
  let offset = 0;
  return (
    <svg viewBox="0 0 100 100" className="w-24 h-24">
      {data.map((v, i) => {
        const pct = (v / total) * 360;
        const el = <circle key={i} cx="50" cy="50" r="40" fill="none" stroke={colors[i]} strokeWidth="20" strokeDasharray={`${pct} ${360 - pct}`} transform={`rotate(${offset - 90} 50 50)`} />;
        offset += pct;
        return el;
      })}
    </svg>
  );
}

/* ─────────────────────── main page ─────────────────────── */

export default function EggsPage() {
  const [activeTab, setActiveTab] = useState('inventory');
  const [searchQ, setSearchQ] = useState('');

  const totalStock = INVENTORY.gradeA.qty + INVENTORY.gradeB.qty + INVENTORY.gradeC.qty + INVENTORY.gradeD.qty;
  const todayProd = INVENTORY.gradeA.today + INVENTORY.gradeB.today + INVENTORY.gradeC.today + INVENTORY.gradeD.today;
  const todaySales = DISTRIBUTION_ORDERS.filter(o => o.status === 'تم التسليم').reduce((a, o) => a + o.total, 0);
  const avgPrice = ((INVENTORY.gradeA.price + INVENTORY.gradeB.price + INVENTORY.gradeC.price + INVENTORY.gradeD.price) / 4).toFixed(2);
  const totalWastage = GRADING_BATCHES.reduce((a, g) => a + g.wastage, 0);

  return (
    <div className="p-4 md:p-6">
      <PageHeader title="توزيع بيض المائدة" subtitle="إدارة مخزون البيض والتصنيف والتوزيع والتسعير">
        <button className="flex items-center gap-2 px-4 py-2 bg-[#0a4a30] hover:bg-[#0d6b43] text-white rounded-lg text-sm font-medium transition-colors">
          <Plus size={16} /> طلب توزيع جديد
        </button>
      </PageHeader>

      {/* ─── KPIs ─── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
        <KPICard title="إنتاج اليوم" value={todayProd.toLocaleString()} change={5} icon={Egg} iconBg="bg-amber-50" iconColor="text-amber-600" delay={0} />
        <KPICard title="المخزون" value={totalStock.toLocaleString()} icon={Package} iconBg="bg-blue-50" iconColor="text-blue-600" delay={0.05} />
        <KPICard title="مبيعات اليوم" value={`${todaySales.toLocaleString()} ر.س`} change={12} icon={DollarSign} iconBg="bg-green-50" iconColor="text-green-600" delay={0.1} />
        <KPICard title="متوسط السعر" value={`${avgPrice} ر.س`} change={3} icon={TrendingUp} iconBg="bg-purple-50" iconColor="text-purple-600" delay={0.15} />
        <KPICard title="الهالك" value={totalWastage.toString()} change={-8} icon={AlertTriangle} iconBg="bg-red-50" iconColor="text-red-600" delay={0.2} />
      </div>

      {/* ─── Tabs ─── */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card">
        <div className="flex overflow-x-auto border-b border-uiBorder dark:border-darkBorder scrollbar-hide">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className={cn('flex items-center gap-2 px-5 py-3.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
                activeTab === t.key ? 'border-[#0a4a30] text-[#0a4a30] dark:text-green-400' : 'border-transparent text-textSecondary hover:text-textPrimary dark:text-darkTextSec')}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>

        <div className="p-4 md:p-5">
          <AnimatePresence mode="wait">

            {/* ─── Inventory ─── */}
            {activeTab === 'inventory' && (
              <motion.div key="inventory" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">مخزون البيض حسب الدرجة</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 mb-4">
                  {[
                    { key: 'gradeA', label: 'درجة أ', qty: INVENTORY.gradeA.qty, price: INVENTORY.gradeA.price, today: INVENTORY.gradeA.today, quality: INVENTORY.gradeA.quality, color: 'bg-green-500', light: 'bg-green-50', text: 'text-green-700' },
                    { key: 'gradeB', label: 'درجة ب', qty: INVENTORY.gradeB.qty, price: INVENTORY.gradeB.price, today: INVENTORY.gradeB.today, quality: INVENTORY.gradeB.quality, color: 'bg-blue-500', light: 'bg-blue-50', text: 'text-blue-700' },
                    { key: 'gradeC', label: 'درجة ج', qty: INVENTORY.gradeC.qty, price: INVENTORY.gradeC.price, today: INVENTORY.gradeC.today, quality: INVENTORY.gradeC.quality, color: 'bg-amber-500', light: 'bg-amber-50', text: 'text-amber-700' },
                    { key: 'gradeD', label: 'درجة د', qty: INVENTORY.gradeD.qty, price: INVENTORY.gradeD.price, today: INVENTORY.gradeD.today, quality: INVENTORY.gradeD.quality, color: 'bg-slate-500', light: 'bg-slate-50', text: 'text-slate-700' },
                  ].map((g, i) => (
                    <motion.div key={g.key} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                      className={cn('rounded-xl border border-uiBorder dark:border-darkBorder p-4', g.light)}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <h4 className={cn('font-bold text-lg', g.text)}>{g.label}</h4>
                        <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', g.color)}>
                          <Egg size={20} className="text-white" />
                        </div>
                      </div>
                      <p className="text-3xl font-bold text-textPrimary dark:text-darkText mb-1">{g.qty.toLocaleString()}</p>
                      <p className="text-xs text-textMuted mb-3">بيضة</p>
                      <div className="space-y-2 bg-white/60 dark:bg-darkSurface/60 rounded-lg p-2.5">
                        <div className="flex justify-between text-xs">
                          <span className="text-textSecondary dark:text-darkTextSec">السعر</span>
                          <span className="font-semibold text-textPrimary dark:text-darkText">{g.price} ر.س</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-textSecondary dark:text-darkTextSec">إنتاج اليوم</span>
                          <span className="font-semibold text-textPrimary dark:text-darkText">+{g.today.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-textSecondary dark:text-darkTextSec">جودة</span>
                          <span className={cn('font-semibold', g.quality > 95 ? 'text-green-600' : g.quality > 90 ? 'text-amber-600' : 'text-red-600')}>{g.quality}%</span>
                        </div>
                      </div>
                      <div className="mt-3">
                        <div className="flex justify-between text-[11px] mb-0.5">
                          <span className="text-textMuted">نسبة المخزون</span>
                          <span className="text-textMuted">{((g.qty / totalStock) * 100).toFixed(1)}%</span>
                        </div>
                        <div className="h-2 bg-white dark:bg-darkBg rounded-full overflow-hidden">
                          <motion.div initial={{ width: 0 }} animate={{ width: `${(g.qty / totalStock) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                            className={cn('h-full rounded-full', g.color)} />
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">توزيع المخزون</h4>
                  <div className="flex items-center gap-4">
                    <MiniPieChart data={[INVENTORY.gradeA.qty, INVENTORY.gradeB.qty, INVENTORY.gradeC.qty, INVENTORY.gradeD.qty]} colors={['#22c55e', '#3b82f6', '#f59e0b', '#64748b']} />
                    <div className="flex-1 space-y-2">
                      {[
                        { label: 'درجة أ', pct: ((INVENTORY.gradeA.qty / totalStock) * 100).toFixed(1), color: 'bg-green-500' },
                        { label: 'درجة ب', pct: ((INVENTORY.gradeB.qty / totalStock) * 100).toFixed(1), color: 'bg-blue-500' },
                        { label: 'درجة ج', pct: ((INVENTORY.gradeC.qty / totalStock) * 100).toFixed(1), color: 'bg-amber-500' },
                        { label: 'درجة د', pct: ((INVENTORY.gradeD.qty / totalStock) * 100).toFixed(1), color: 'bg-slate-500' },
                      ].map(item => (
                        <div key={item.label} className="flex items-center gap-2">
                          <div className={cn('w-3 h-3 rounded-full', item.color)} />
                          <span className="text-xs text-textSecondary dark:text-darkTextSec flex-1">{item.label}</span>
                          <span className="text-xs font-semibold text-textPrimary dark:text-darkText">{item.pct}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Distribution ─── */}
            {activeTab === 'distribution' && (
              <motion.div key="distribution" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">طلبات التوزيع</h3>
                  <div className="flex items-center gap-2">
                    <button className="flex items-center gap-1.5 px-3 py-1.5 border border-uiBorder rounded-lg text-xs text-textSecondary hover:bg-surface transition-colors">
                      <Download size={14} /> تصدير
                    </button>
                    <div className="relative w-48">
                      <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                      <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                        className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                    </div>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                    <thead>
                      <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                        {['رقم الطلب', 'العميل', 'الدرجة', 'الكمية', 'السعر', 'الإجمالي', 'السائق', 'المنطقة', 'الحالة', ''].map(h => (
                          <th key={h} className="px-2 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {DISTRIBUTION_ORDERS.filter(o => !searchQ || o.customer.includes(searchQ) || o.id.includes(searchQ)).map((o, i) => (
                        <motion.tr key={o.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                          className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                        >
                          <td className="px-2 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{o.id}</td>
                          <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{o.customer}</td>
                          <td className="px-2 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', o.grade === 'A' ? 'bg-green-100 text-green-700' : o.grade === 'B' ? 'bg-blue-100 text-blue-700' : o.grade === 'C' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600')}>درجة {o.grade}</span></td>
                          <td className="px-2 py-2.5 text-sm font-semibold text-textPrimary dark:text-darkText">{o.qty.toLocaleString()}</td>
                          <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{o.price} ر.س</td>
                          <td className="px-2 py-2.5 text-sm font-bold text-green-600">{o.total.toLocaleString()} ر.س</td>
                          <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{o.driver}</td>
                          <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{o.zone}</td>
                          <td className="px-2 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(o.status))}>{o.status}</span></td>
                          <td className="px-2 py-2.5">
                            <div className="flex items-center gap-1 justify-center">
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors"><Eye size={15} /></button>
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-amber-500 hover:bg-amber-50 transition-colors"><Edit3 size={15} /></button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* ─── Grading ─── */}
            {activeTab === 'grading' && (
              <motion.div key="grading" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">دفعات التصنيف</h3>
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['الدفعة', 'التاريخ', 'الإجمالي', 'درجة أ', 'درجة ب', 'درجة ج', 'درجة د', 'الهالك', 'النسبة', 'الحالة'].map(h => (
                              <th key={h} className="px-2 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {GRADING_BATCHES.map((g, i) => {
                            const totalGrade = g.gradeA + g.gradeB + g.gradeC + g.gradeD;
                            return (
                              <motion.tr key={g.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                                className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                              >
                                <td className="px-2 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{g.id}</td>
                                <td className="px-2 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{g.date}</td>
                                <td className="px-2 py-2.5 text-sm font-bold text-textPrimary dark:text-darkText">{g.total.toLocaleString()}</td>
                                <td className="px-2 py-2.5 text-sm text-green-600 font-semibold">{g.gradeA.toLocaleString()}</td>
                                <td className="px-2 py-2.5 text-sm text-blue-600 font-semibold">{g.gradeB.toLocaleString()}</td>
                                <td className="px-2 py-2.5 text-sm text-amber-600 font-semibold">{g.gradeC.toLocaleString()}</td>
                                <td className="px-2 py-2.5 text-sm text-slate-500 font-semibold">{g.gradeD.toLocaleString()}</td>
                                <td className="px-2 py-2.5 text-sm text-red-600 font-semibold">{g.wastage}</td>
                                <td className="px-2 py-2.5 text-sm text-red-600">{((g.wastage / g.total) * 100).toFixed(2)}%</td>
                                <td className="px-2 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(g.status))}>{g.status}</span></td>
                              </motion.tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">معايير الجودة</h4>
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="border-b border-uiBorder dark:border-darkBorder">
                              <th className="py-2 text-right text-textSecondary dark:text-darkTextSec">المعيار</th>
                              <th className="py-2 text-center text-green-600">أ</th>
                              <th className="py-2 text-center text-blue-600">ب</th>
                              <th className="py-2 text-center text-amber-600">ج</th>
                              <th className="py-2 text-center text-slate-500">د</th>
                            </tr>
                          </thead>
                          <tbody>
                            {QUALITY_PARAMS.map((q, i) => (
                              <tr key={i} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                                <td className="py-2 text-textSecondary dark:text-darkTextSec font-medium">{q.param}</td>
                                <td className="py-2 text-center text-textPrimary dark:text-darkText">{q.gradeA}</td>
                                <td className="py-2 text-center text-textPrimary dark:text-darkText">{q.gradeB}</td>
                                <td className="py-2 text-center text-textPrimary dark:text-darkText">{q.gradeC}</td>
                                <td className="py-2 text-center text-textPrimary dark:text-darkText">{q.gradeD}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">إحصائيات التصنيف</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'إجمالي المصنف', value: `${GRADING_BATCHES.reduce((a, g) => a + g.total, 0).toLocaleString()} بيضة` },
                          { label: 'متوسط الهالك', value: `${(GRADING_BATCHES.reduce((a, g) => a + g.wastage, 0) / GRADING_BATCHES.length).toFixed(0)} بيضة/دفعة` },
                          { label: 'متوسط نسبة الهالك', value: `${((GRADING_BATCHES.reduce((a, g) => a + g.wastage, 0) / GRADING_BATCHES.reduce((a, g) => a + g.total, 0)) * 100).toFixed(2)}%` },
                          { label: 'أعلى إنتاجية', value: 'عبدالله النعيمي' },
                        ].map(s => (
                          <div key={s.label} className="flex items-center justify-between text-xs">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{s.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Pricing ─── */}
            {activeTab === 'pricing' && (
              <motion.div key="pricing" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">قائمة الأسعار اليومية</h3>
                    <div className="overflow-x-auto bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['التاريخ', 'درجة أ', 'درجة ب', 'درجة ج', 'درجة د', 'متوسط', 'تغيير'].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {PRICING_HISTORY.map((p, i) => {
                            const avg = ((p.gradeA + p.gradeB + p.gradeC + p.gradeD) / 4).toFixed(2);
                            const prevAvg = i < PRICING_HISTORY.length - 1 ? ((PRICING_HISTORY[i + 1].gradeA + PRICING_HISTORY[i + 1].gradeB + PRICING_HISTORY[i + 1].gradeC + PRICING_HISTORY[i + 1].gradeD) / 4) : 0;
                            const change = prevAvg ? (((parseFloat(avg) - prevAvg) / prevAvg) * 100).toFixed(1) : '0';
                            return (
                              <motion.tr key={p.date} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                                className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                              >
                                <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{p.date}</td>
                                <td className="px-3 py-2.5 text-sm text-green-600 font-semibold">{p.gradeA} ر.س</td>
                                <td className="px-3 py-2.5 text-sm text-blue-600 font-semibold">{p.gradeB} ر.س</td>
                                <td className="px-3 py-2.5 text-sm text-amber-600 font-semibold">{p.gradeC} ر.س</td>
                                <td className="px-3 py-2.5 text-sm text-slate-500 font-semibold">{p.gradeD} ر.س</td>
                                <td className="px-3 py-2.5 text-sm font-bold text-textPrimary dark:text-darkText">{avg} ر.س</td>
                                <td className="px-3 py-2.5">
                                  <span className={cn('text-xs font-semibold', parseFloat(change) >= 0 ? 'text-green-600' : 'text-red-600')}>
                                    {parseFloat(change) >= 0 ? '+' : ''}{change}%
                                  </span>
                                </td>
                              </motion.tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">أسعار اليوم</h4>
                      {[
                        { grade: 'درجة أ', price: INVENTORY.gradeA.price, unit: 'بيضة', trend: 'up' },
                        { grade: 'درجة ب', price: INVENTORY.gradeB.price, unit: 'بيضة', trend: 'up' },
                        { grade: 'درجة ج', price: INVENTORY.gradeC.price, unit: 'بيضة', trend: 'stable' },
                        { grade: 'درجة د', price: INVENTORY.gradeD.price, unit: 'بيضة', trend: 'up' },
                      ].map((p, i) => (
                        <div key={p.grade} className="flex items-center justify-between py-2 border-b border-uiBorder/50 last:border-0">
                          <div className="flex items-center gap-2">
                            <Egg size={16} className={i === 0 ? 'text-green-500' : i === 1 ? 'text-blue-500' : i === 2 ? 'text-amber-500' : 'text-slate-500'} />
                            <span className="text-xs font-medium text-textPrimary dark:text-darkText">{p.grade}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-textPrimary dark:text-darkText">{p.price} ر.س</span>
                            {p.trend === 'up' ? <TrendingUp size={14} className="text-green-500" /> : p.trend === 'down' ? <TrendingDown size={14} className="text-red-500" /> : <Minus size={14} className="text-slate-400" />}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">تحليل الهامش</h4>
                      {[
                        { grade: 'درجة أ', revenue: 0.45, cost: 0.28, margin: 0.17 },
                        { grade: 'درجة ب', revenue: 0.38, cost: 0.22, margin: 0.16 },
                        { grade: 'درجة ج', revenue: 0.28, cost: 0.18, margin: 0.10 },
                        { grade: 'درجة د', revenue: 0.18, cost: 0.12, margin: 0.06 },
                      ].map((m, i) => (
                        <div key={m.grade} className="mb-3">
                          <div className="flex justify-between text-xs mb-0.5">
                            <span className="text-textSecondary dark:text-darkTextSec">{m.grade}</span>
                            <span className="font-semibold text-green-600">{((m.margin / m.revenue) * 100).toFixed(0)}% هامش</span>
                          </div>
                          <div className="h-3 bg-surface dark:bg-darkBg rounded-full overflow-hidden flex">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(m.cost / m.revenue) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className="h-full bg-red-400" title="التكلفة" />
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(m.margin / m.revenue) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 + 0.2 }}
                              className="h-full bg-green-500" title="الهامش" />
                          </div>
                          <div className="flex justify-between text-[10px] mt-0.5">
                            <span className="text-textMuted">تكلفة: {m.cost} ر.س</span>
                            <span className="text-textMuted">هامش: {m.margin} ر.س</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Analytics ─── */}
            {activeTab === 'analytics' && (
              <motion.div key="analytics" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">إنتاج البيض (آخر 7 أيام)</h4>
                    <MiniBarChart data={[112000, 118000, 125000, 121000, 119000, 124000, 125000]} labels={['9', '10', '11', '12', '13', '14', '15']} color="#0a4a30" />
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">المبيعات حسب الدرجة</h4>
                    <div className="flex items-center justify-center mb-4">
                      <MiniPieChart data={[28000, 18000, 12000, 5000]} colors={['#22c55e', '#3b82f6', '#f59e0b', '#64748b']} />
                    </div>
                    <div className="space-y-1.5">
                      {[
                        { label: 'درجة أ', value: '28,000', color: 'bg-green-500' },
                        { label: 'درجة ب', value: '18,000', color: 'bg-blue-500' },
                        { label: 'درجة ج', value: '12,000', color: 'bg-amber-500' },
                        { label: 'درجة د', value: '5,000', color: 'bg-slate-500' },
                      ].map(item => (
                        <div key={item.label} className="flex items-center gap-2">
                          <div className={cn('w-3 h-3 rounded-full', item.color)} />
                          <span className="text-xs text-textSecondary dark:text-darkTextSec flex-1">{item.label}</span>
                          <span className="text-xs font-semibold text-textPrimary dark:text-darkText">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">الهالك يومياً</h4>
                    <MiniBarChart data={[145, 98, 120, 78, 150, 95, 88]} labels={['9', '10', '11', '12', '13', '14', '15']} color="#ef4444" />
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">أفضل العملاء</h4>
                    <div className="space-y-2">
                      {[
                        { name: 'مؤسسة الدواجن الذهبية', qty: 18500 },
                        { name: 'شركة النور للدواجن', qty: 12200 },
                        { name: 'مطعم البستان', qty: 9800 },
                        { name: 'فندق الجوهرة', qty: 7600 },
                        { name: 'مخبز الصفوة', qty: 6200 },
                      ].map((c, i) => (
                        <div key={c.name} className="flex items-center gap-3">
                          <span className="text-xs font-bold text-textMuted w-4">{i + 1}</span>
                          <div className="flex-1 text-xs font-medium text-textPrimary dark:text-darkText truncate">{c.name}</div>
                          <div className="w-20 h-2 bg-surface dark:bg-darkBg rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(c.qty / 18500) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className="h-full rounded-full bg-[#daa520]" />
                          </div>
                          <span className="text-xs text-textMuted w-14 text-left">{c.qty.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
