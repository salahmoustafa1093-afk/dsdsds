import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeftRight, Plus, X, Eye, TrendingUp, CheckCircle2, Clock, XCircle, Package, Truck, UserCheck,
  Send, Loader2, MapPin,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

// ─── Types ──────────────────────────────────────────────
interface Transfer {
  id: string;
  fromBranch: string;
  toBranch: string;
  products: string;
  quantity: number;
  status: string;
  requester: string;
  date: string;
  steps: { label: string; completed: boolean; date?: string }[];
}

// ─── Mock Data ──────────────────────────────────────────
const transfersData: Transfer[] = [
  { id: 'T-1001', fromBranch: 'القاهرة', toBranch: 'الإسكندرية', products: 'علف دواجن بادئ ٢٥ كجم', quantity: 150, status: 'مكتملة', requester: 'محمد أحمد', date: '2025-01-15', steps: [
    { label: 'طلب', completed: true, date: '2025-01-15' },
    { label: 'موافقة المدير', completed: true, date: '2025-01-15' },
    { label: 'تحميل', completed: true, date: '2025-01-16' },
    { label: 'توصيل', completed: true, date: '2025-01-17' },
    { label: 'تأكيد', completed: true, date: '2025-01-17' },
  ]},
  { id: 'T-1002', fromBranch: 'طنطا', toBranch: 'المنصورة', products: 'ذرة صفراء مجروشة', quantity: 50, status: 'قيد التنفيذ', requester: 'محمود سالم', date: '2025-01-16', steps: [
    { label: 'طلب', completed: true, date: '2025-01-16' },
    { label: 'موافقة المدير', completed: true, date: '2025-01-16' },
    { label: 'تحميل', completed: true, date: '2025-01-17' },
    { label: 'توصيل', completed: false },
    { label: 'تأكيد', completed: false },
  ]},
  { id: 'T-1003', fromBranch: 'الإسكندرية', toBranch: 'القاهرة', products: 'علف أبقار حلاب ٤٠ كجم', quantity: 80, status: 'قيد التنفيذ', requester: 'أحمد علي', date: '2025-01-17', steps: [
    { label: 'طلب', completed: true, date: '2025-01-17' },
    { label: 'موافقة المدير', completed: true, date: '2025-01-17' },
    { label: 'تحميل', completed: false },
    { label: 'توصيل', completed: false },
    { label: 'تأكيد', completed: false },
  ]},
  { id: 'T-1004', fromBranch: 'المنصورة', toBranch: 'طنطا', products: 'ردة خشنة', quantity: 30, status: 'مرفوضة', requester: 'خالد عمر', date: '2025-01-14', steps: [
    { label: 'طلب', completed: true, date: '2025-01-14' },
    { label: 'موافقة المدير', completed: false, date: '2025-01-14' },
    { label: 'تحميل', completed: false },
    { label: 'توصيل', completed: false },
    { label: 'تأكيد', completed: false },
  ]},
  { id: 'T-1005', fromBranch: 'القاهرة', toBranch: 'طنطا', products: 'صويا مبشورة ٤٨٪', quantity: 100, status: 'مكتملة', requester: 'محمد أحمد', date: '2025-01-10', steps: [
    { label: 'طلب', completed: true, date: '2025-01-10' },
    { label: 'موافقة المدير', completed: true, date: '2025-01-10' },
    { label: 'تحميل', completed: true, date: '2025-01-11' },
    { label: 'توصيل', completed: true, date: '2025-01-12' },
    { label: 'تأكيد', completed: true, date: '2025-01-12' },
  ]},
];

const workflowSteps = ['طلب', 'موافقة المدير', 'تحميل', 'توصيل', 'تأكيد'];

const statusColors: Record<string, string> = {
  'مكتملة': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'قيد التنفيذ': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'مرفوضة': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

const statusIcons: Record<string, typeof CheckCircle2> = {
  'مكتملة': CheckCircle2,
  'قيد التنفيذ': Clock,
  'مرفوضة': XCircle,
};

export default function BranchesTransfersPage() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState<Transfer | null>(null);

  const todayCount = transfersData.filter(t => t.date === '2025-01-17').length;
  const inProgress = transfersData.filter(t => t.status === 'قيد التنفيذ').length;
  const completedCount = transfersData.filter(t => t.status === 'مكتملة').length;
  const rejectedCount = transfersData.filter(t => t.status === 'مرفوضة').length;

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="التحويلات بين الفروع"
        subtitle="إدارة عمليات نقل المخزون بين الفروع"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الفروع', path: '/branches' },
          { label: 'التحويلات' },
        ]}
      >
        <button onClick={() => setShowCreateForm(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Plus size={16} /> طلب تحويل
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="تحويلات اليوم" value={String(todayCount)} icon={ArrowLeftRight} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="قيد التنفيذ" value={String(inProgress)} icon={Clock} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.1} />
        <KPICard title="مكتملة" value={String(completedCount)} icon={CheckCircle2} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.2} />
        <KPICard title="مرفوضة" value={String(rejectedCount)} icon={XCircle} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Workflow Legend */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
        <div className="flex items-center justify-center gap-2 flex-wrap">
          {workflowSteps.map((step, idx) => (
            <div key={step} className="flex items-center gap-2">
              <div className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-surface dark:bg-darkCard border border-uiBorder dark:border-darkBorder">
                {idx === 0 && <Send size={12} className="text-textMuted" />}
                {idx === 1 && <UserCheck size={12} className="text-textMuted" />}
                {idx === 2 && <Package size={12} className="text-textMuted" />}
                {idx === 3 && <Truck size={12} className="text-textMuted" />}
                {idx === 4 && <CheckCircle2 size={12} className="text-textMuted" />}
                <span className="text-xs text-textSecondary">{step}</span>
              </div>
              {idx < workflowSteps.length - 1 && <ArrowLeftRight size={12} className="text-textMuted" />}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Transfers Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">سجل التحويلات</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['رقم التحويل', 'من فرع', 'إلى فرع', 'المنتجات', 'الكمية', 'الحالة', 'الطالب', 'التاريخ'].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
                <th className="px-4 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {transfersData.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.id}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.fromBranch}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.toBranch}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText max-w-[150px] truncate">{row.products}</td>
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.quantity}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[row.status]}`}>{row.status}</span></td>
                  <td className="px-4 py-3 text-sm text-textMuted">{row.requester}</td>
                  <td className="px-4 py-3 text-sm text-textMuted">{row.date}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => setSelectedTransfer(row)} className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors"><Eye size={16} /></button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Create Transfer Modal */}
      <AnimatePresence>
        {showCreateForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowCreateForm(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">طلب تحويل جديد</h3>
                <button onClick={() => setShowCreateForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">من فرع</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>القاهرة</option><option>الإسكندرية</option><option>طنطا</option><option>المنصورة</option></select></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">إلى فرع</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>الإسكندرية</option><option>القاهرة</option><option>طنطا</option><option>المنصورة</option></select></div>
                </div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">المنتج</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>علف دواجن بادئ ٢٥ كجم</option><option>علف دواجن نامي ٢٥ كجم</option><option>علف أبقار حلاب ٤٠ كجم</option><option>ذرة صفراء مجروشة</option><option>ردة خشنة</option><option>صويا مبشورة ٤٨٪</option></select></div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">الكمية</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">ملاحظات</label><textarea placeholder="ملاحظات اختيارية" className="w-full h-16 px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm resize-none" /></div>
                <div className="flex justify-end gap-2 pt-2">
                  <button onClick={() => setShowCreateForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary">إلغاء</button>
                  <button onClick={() => setShowCreateForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800">إرسال الطلب</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Transfer Detail Modal */}
      <AnimatePresence>
        {selectedTransfer && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setSelectedTransfer(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div><h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تحويل {selectedTransfer.id}</h3><p className="text-xs text-textMuted">{selectedTransfer.date}</p></div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[selectedTransfer.status]}`}>{selectedTransfer.status}</span>
                  <button onClick={() => setSelectedTransfer(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
                </div>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-textMuted">من:</span> <span className="text-textPrimary dark:text-darkText font-medium">{selectedTransfer.fromBranch}</span></div>
                  <div><span className="text-textMuted">إلى:</span> <span className="text-textPrimary dark:text-darkText font-medium">{selectedTransfer.toBranch}</span></div>
                  <div><span className="text-textMuted">المنتج:</span> <span className="text-textPrimary dark:text-darkText">{selectedTransfer.products}</span></div>
                  <div><span className="text-textMuted">الكمية:</span> <span className="text-textPrimary dark:text-darkText font-medium">{selectedTransfer.quantity}</span></div>
                  <div><span className="text-textMuted">الطالب:</span> <span className="text-textPrimary dark:text-darkText">{selectedTransfer.requester}</span></div>
                </div>
                {/* Progress Steps */}
                <div>
                  <h4 className="text-xs font-semibold text-textSecondary mb-3">مراحل التحويل</h4>
                  <div className="relative">
                    {selectedTransfer.steps.map((step, idx) => (
                      <div key={step.label} className="flex items-start gap-3 mb-3 last:mb-0">
                        <div className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step.completed ? 'bg-green-500 text-white' : 'bg-gray-200 dark:bg-gray-600 text-gray-500'}`}>
                            {step.completed ? <CheckCircle2 size={16} /> : <Clock size={16} />}
                          </div>
                          {idx < selectedTransfer.steps.length - 1 && (
                            <div className={`w-0.5 h-6 ${step.completed && selectedTransfer.steps[idx + 1].completed ? 'bg-green-500' : 'bg-gray-200 dark:bg-gray-600'}`} />
                          )}
                        </div>
                        <div className="pt-1">
                          <p className={`text-sm font-medium ${step.completed ? 'text-green-700 dark:text-green-400' : 'text-textSecondary'}`}>{step.label}</p>
                          {step.date && <p className="text-xs text-textMuted">{step.date}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
