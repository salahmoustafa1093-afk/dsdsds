// @ts-nocheck
import { useState, useMemo } from 'react';
import {
  FlaskConical, CheckCircle2, AlertCircle, Ban, Plus, Eye, Beaker, Wheat, Beef
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

/* ─── Types ─────────────────────────────────────────── */
interface FeedFormula {
  id: number;
  name: string;
  targetAnimal: string;
  growthStage: string;
  protein: number;
  energy: number;
  costPerTon: number;
  status: 'approved' | 'review' | 'old';
  createdBy: string;
  ingredients: { name: string; percent: number }[];
  nrc: { protein: number; energy: number; calcium: number; lysine: number; methionine: number };
}

/* ─── Mock Data ─────────────────────────────────────── */
const formulasData: FeedFormula[] = [
  {
    id: 1, name: 'علف دواجن بادئ ٢٣٪', targetAnimal: 'دواجن', growthStage: 'بادئ (٠-٢ أسبوع)', protein: 23.0, energy: 3200, costPerTon: 4850, status: 'approved', createdBy: 'د. أحمد محمود',
    ingredients: [
      { name: 'ذرة صفراء', percent: 52 }, { name: 'كسب فول صويا', percent: 28 }, { name: 'ردة قمح', percent: 8 }, { name: 'كسب قطن', percent: 4 }, { name: 'ملح', percent: 0.3 }, { name: 'مصدر كالسيوم', percent: 1.5 }, { name: 'فايتمينات', percent: 0.5 }, { name: 'فوسفات', percent: 1.2 }, { name: 'ميثايونين', percent: 0.2 }, { name: 'ليزين', percent: 0.15 },
    ],
    nrc: { protein: 23.0, energy: 3200, calcium: 1.0, lysine: 1.1, methionine: 0.5 },
  },
  {
    id: 2, name: 'علف دواجن نامي ٢٠٪', targetAnimal: 'دواجن', growthStage: 'نامي (٣-٦ أسابيع)', protein: 20.0, energy: 3150, costPerTon: 4520, status: 'approved', createdBy: 'د. أحمد محمود',
    ingredients: [
      { name: 'ذرة صفراء', percent: 56 }, { name: 'كسب فول صويا', percent: 25 }, { name: 'ردة قمح', percent: 10 }, { name: 'كسب قطن', percent: 3 }, { name: 'ملح', percent: 0.3 }, { name: 'مصدر كالسيوم', percent: 1.3 }, { name: 'فايتمينات', percent: 0.5 }, { name: 'فوسفات', percent: 1.0 },
    ],
    nrc: { protein: 20.0, energy: 3150, calcium: 0.9, lysine: 1.0, methionine: 0.38 },
  },
  {
    id: 3, name: 'علف دواجن ناهي ١٨٪', targetAnimal: 'دواجن', growthStage: 'ناهي (٧+ أسابيع)', protein: 18.0, energy: 3100, costPerTon: 4200, status: 'review', createdBy: 'د. سارة خالد',
    ingredients: [
      { name: 'ذرة صفراء', percent: 60 }, { name: 'كسب فول صويا', percent: 22 }, { name: 'ردة قمح', percent: 12 }, { name: 'ملح', percent: 0.3 }, { name: 'مصدر كالسيوم', percent: 1.0 }, { name: 'فايتمينات', percent: 0.4 },
    ],
    nrc: { protein: 18.0, energy: 3100, calcium: 0.8, lysine: 0.85, methionine: 0.32 },
  },
  {
    id: 4, name: 'علف أبقار جاف ١٤٪', targetAnimal: 'أبقار', growthStage: 'بالغة جافة', protein: 14.0, energy: 2800, costPerTon: 3800, status: 'approved', createdBy: 'د. محمد علي',
    ingredients: [
      { name: 'ردة قمح', percent: 35 }, { name: 'ذرة صفراء', percent: 25 }, { name: 'كسب فول صويا', percent: 15 }, { name: 'تبن', percent: 18 }, { name: 'ملح', percent: 0.5 }, { name: 'مصدر كالسيوم', percent: 1.5 }, { name: 'فايتمينات', percent: 0.3 },
    ],
    nrc: { protein: 14.0, energy: 2800, calcium: 0.6, lysine: 0.65, methionine: 0.2 },
  },
  {
    id: 5, name: 'علف تسمين عجول ١٦٪', targetAnimal: 'عجول', growthStage: 'تسمين (٣-١٢ شهر)', protein: 16.0, energy: 3000, costPerTon: 4100, status: 'approved', createdBy: 'د. محمد علي',
    ingredients: [
      { name: 'ذرة صفراء', percent: 45 }, { name: 'ردة قمح', percent: 20 }, { name: 'كسب فول صويا', percent: 18 }, { name: 'كسب عباد', percent: 10 }, { name: 'ملح', percent: 0.4 }, { name: 'مصدر كالسيوم', percent: 1.3 }, { name: 'فايتمينات', percent: 0.4 },
    ],
    nrc: { protein: 16.0, energy: 3000, calcium: 0.7, lysine: 0.75, methionine: 0.25 },
  },
  {
    id: 6, name: 'علف أغنام ١٥٪', targetAnimal: 'أغنام', growthStage: 'بالغة', protein: 15.0, energy: 2900, costPerTon: 3950, status: 'old', createdBy: 'د. سارة خالد',
    ingredients: [
      { name: 'ردة قمح', percent: 40 }, { name: 'ذرة صفراء', percent: 20 }, { name: 'كسب فول صويا', percent: 16 }, { name: 'تبن', percent: 18 }, { name: 'ملح', percent: 0.5 }, { name: 'فايتمينات', percent: 0.3 },
    ],
    nrc: { protein: 15.0, energy: 2900, calcium: 0.5, lysine: 0.6, methionine: 0.2 },
  },
  {
    id: 7, name: 'علف أرانب ١٧٪', targetAnimal: 'أرانب', growthStage: 'نمو', protein: 17.0, energy: 2600, costPerTon: 4300, status: 'review', createdBy: 'د. أحمد محمود',
    ingredients: [
      { name: 'ذرة صفراء', percent: 30 }, { name: 'ردة قمح', percent: 25 }, { name: 'كسب فول صويا', percent: 20 }, { name: 'دريس برسيم', percent: 20 }, { name: 'ملح', percent: 0.4 }, { name: 'فايتمينات', percent: 0.6 },
    ],
    nrc: { protein: 17.0, energy: 2600, calcium: 1.1, lysine: 0.8, methionine: 0.6 },
  },
  {
    id: 8, name: 'علف أحصنة رياضية ١٢٪', targetAnimal: 'أحصنة', growthStage: 'رياضية', protein: 12.0, energy: 2700, costPerTon: 5200, status: 'approved', createdBy: 'د. محمد علي',
    ingredients: [
      { name: 'شعير', percent: 35 }, { name: 'دريس', percent: 30 }, { name: 'ردة', percent: 20 }, { name: 'كسب فول صويا', percent: 10 }, { name: 'ملح', percent: 0.5 }, { name: 'فايتمينات', percent: 0.5 },
    ],
    nrc: { protein: 12.0, energy: 2700, calcium: 0.4, lysine: 0.4, methionine: 0.15 },
  },
];

/* ─── Status Helpers ────────────────────────────────── */
const statusConfig = {
  approved: { label: 'معتمدة', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', icon: CheckCircle2 },
  review: { label: 'تحت المراجعة', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400', icon: AlertCircle },
  old: { label: 'قديمة', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300', icon: Ban },
};

const animalIcons: Record<string, typeof Beef> = {
  'دواجن': FlaskConical, 'أبقار': Beef, 'عجول': Beef, 'أغنام': Wheat, 'أرانب': FlaskConical, 'أحصنة': FlaskConical,
};

/* ─── Page ──────────────────────────────────────────── */
export default function FeedFormulasPage() {
  const [filterStatus, setFilterStatus] = useState('all');
  const [detailFormula, setDetailFormula] = useState<FeedFormula | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', targetAnimal: '', growthStage: '', protein: '', energy: '', notes: '' });

  const filteredData = useMemo(() => {
    if (filterStatus === 'all') return formulasData;
    return formulasData.filter(f => f.status === filterStatus);
  }, [filterStatus]);

  const activeCount = formulasData.filter(f => f.status === 'approved').length;
  const reviewCount = formulasData.filter(f => f.status === 'review').length;
  const oldCount = formulasData.filter(f => f.status === 'old').length;

  const columns = [
    { key: 'name', header: 'اسم التركيبة', sortable: true },
    {
      key: 'targetAnimal',
      header: 'الحيوان المستهدف',
      sortable: true,
      render: (row: Record<string, unknown>) => {
        const Icon = animalIcons[row.targetAnimal as string] || FlaskConical;
        return <span className="inline-flex items-center gap-1"><Icon size={14} className="text-green-600" /> {row.targetAnimal as string}</span>;
      },
    },
    { key: 'growthStage', header: 'مرحلة النمو', sortable: true },
    {
      key: 'protein',
      header: 'بروتين %',
      sortable: true,
      width: '90px',
      render: (row: Record<string, unknown>) => <span className="font-medium">{row.protein as number}%</span>,
    },
    {
      key: 'energy',
      header: 'طاقة kcal/kg',
      sortable: true,
      width: '110px',
      render: (row: Record<string, unknown>) => <span>{row.energy as number}</span>,
    },
    {
      key: 'costPerTon',
      header: 'تكلفة/طن',
      sortable: true,
      width: '100px',
      render: (row: Record<string, unknown>) => <span className="font-medium text-green-700 dark:text-green-400">{row.costPerTon as number} ج.م</span>,
    },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: Record<string, unknown>) => {
        const cfg = statusConfig[row.status as keyof typeof statusConfig];
        const Icon = cfg.icon;
        return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}><Icon size={12} /> {cfg.label}</span>;
      },
    },
    { key: 'createdBy', header: 'تم إنشاؤها بواسطة', sortable: true },
  ];

  const openDetail = (f: FeedFormula) => { setDetailFormula(f); setIsDetailOpen(true); };

  const getNrcColor = (actual: number, target: number) => {
    const diff = Math.abs(actual - target) / target;
    if (diff <= 0.02) return 'text-green-600';
    if (diff <= 0.05) return 'text-amber-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="تركيبات الأعلاف" subtitle="إدارة ومراجعة تركيبات الأعلاف الغذائية" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الأعلاف' }, { label: 'التركيبات' }]}>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild><Button className="bg-green-700 hover:bg-green-800 text-white gap-1"><Plus size={16} /> تركيبة جديدة</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>إنشاء تركيبة جديدة</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-1.5"><Label>اسم التركيبة</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="مثال: علف دواجن بادئ ٢٣٪" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>الحيوان المستهدف</Label><Input value={formData.targetAnimal} onChange={e => setFormData({ ...formData, targetAnimal: e.target.value })} placeholder="دواجن، أبقار..." /></div>
                <div className="space-y-1.5"><Label>مرحلة النمو</Label><Input value={formData.growthStage} onChange={e => setFormData({ ...formData, growthStage: e.target.value })} placeholder="بادئ، نامي، ناهي" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>نسبة البروتين %</Label><Input type="number" value={formData.protein} onChange={e => setFormData({ ...formData, protein: e.target.value })} placeholder="٢٣" /></div>
                <div className="space-y-1.5"><Label>الطاقة kcal/kg</Label><Input type="number" value={formData.energy} onChange={e => setFormData({ ...formData, energy: e.target.value })} placeholder="٣٢٠٠" /></div>
              </div>
              <div className="space-y-1.5"><Label>ملاحظات</Label><textarea value={formData.notes} onChange={e => setFormData({ ...formData, notes: e.target.value })} className="w-full h-20 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-green-500/30" placeholder="ملاحظات..." /></div>
              <div className="flex justify-end gap-2 pt-2"><Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button><Button className="bg-green-700 hover:bg-green-800 text-white">حفظ التركيبة</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="عدد التركيبات" value={String(formulasData.length)} icon={FlaskConical} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="نشطة" value={String(activeCount)} change={+3} icon={CheckCircle2} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.1} />
        <KPICard title="تحت المراجعة" value={String(reviewCount)} icon={AlertCircle} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="متوقفة" value={String(oldCount)} icon={Ban} iconBg="bg-gray-100 dark:bg-gray-800" iconColor="text-gray-600 dark:text-gray-400" delay={0.3} />
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4">
        <Tabs value={filterStatus} onValueChange={setFilterStatus}>
          <TabsList className="h-9"><TabsTrigger value="all" className="text-xs">الكل</TabsTrigger><TabsTrigger value="approved" className="text-xs">معتمدة</TabsTrigger><TabsTrigger value="review" className="text-xs">تحت المراجعة</TabsTrigger><TabsTrigger value="old" className="text-xs">قديمة</TabsTrigger></TabsList>
        </Tabs>
      </div>

      {/* Table */}
      <DataTable columns={columns} data={filteredData as unknown as Record<string, unknown>[]} title="التركيبات الغذائية" rowActions={{ onView: (row) => openDetail(row as unknown as FeedFormula), onEdit: () => {}, onDelete: () => {} }} />

      {/* Detail Modal */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" dir="rtl">
          <DialogHeader><DialogTitle>تفاصيل التركيبة: {detailFormula?.name}</DialogTitle></DialogHeader>
          {detailFormula && (
            <div className="space-y-6 mt-2">
              {/* Info */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg text-center"><span className="text-xs text-gray-500 block">الحيوان</span><span className="font-semibold">{detailFormula.targetAnimal}</span></div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg text-center"><span className="text-xs text-gray-500 block">المرحلة</span><span className="font-semibold">{detailFormula.growthStage}</span></div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg text-center"><span className="text-xs text-gray-500 block">الحالة</span><span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${statusConfig[detailFormula.status].color}`}>{statusConfig[detailFormula.status].label}</span></div>
              </div>

              {/* Ingredients */}
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-1"><Beaker size={14} /> مكونات التركيبة</h4>
                <div className="grid grid-cols-2 gap-2">
                  {detailFormula.ingredients.map((ing, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800/30 rounded-lg">
                      <span className="text-sm">{ing.name}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden"><div className="h-full bg-green-600 rounded-full" style={{ width: `${ing.percent * 1.5}%` }} /></div>
                        <span className="text-xs font-medium w-10 text-left">{ing.percent}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* NRC Comparison */}
              <div>
                <h4 className="text-sm font-semibold mb-3">مقارنة مع معايير NRC</h4>
                <div className="grid grid-cols-5 gap-2">
                  {[
                    { label: 'بروتين %', actual: detailFormula.protein, target: detailFormula.nrc.protein },
                    { label: 'طاقة', actual: detailFormula.energy, target: detailFormula.nrc.energy },
                    { label: 'كالسيوم %', actual: detailFormula.ingredients.find(i => i.name.includes('كالسيوم')) ? 1.0 : 0.8, target: detailFormula.nrc.calcium },
                    { label: 'ليزين %', actual: detailFormula.nrc.lysine - 0.05, target: detailFormula.nrc.lysine },
                    { label: 'ميثايونين %', actual: detailFormula.nrc.methionine + 0.02, target: detailFormula.nrc.methionine },
                  ].map((item) => (
                    <div key={item.label} className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg text-center">
                      <span className="text-xs text-gray-500 block mb-1">{item.label}</span>
                      <span className={`text-sm font-bold ${getNrcColor(item.actual, item.target)}`}>{item.actual}</span>
                      <span className="text-xs text-gray-400 block">هدف: {item.target}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
