// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShoppingCart,
  Clock,
  CheckCircle2,
  CircleDollarSign,
  Plus,
  X,
  Eye,
  Edit3,
  Trash2,
  Search,
  ChevronLeft,
  ClipboardList,
  Send,
  PackageCheck,
  Lock,
  FileText,
  ArrowLeft,
  ArrowRight,
  Calendar,
  User,
  Building2,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
interface POProduct {
  product: string;
  qty: number;
  unitPrice: number;
  total: number;
}

interface PurchaseOrder {
  id: number;
  poNumber: string;
  supplier: string;
  supplierCode: string;
  total: number;
  status: 'مسودة' | 'معتمدة' | 'مُرسلة' | 'قيد التنفيذ' | 'مُستلمة' | 'مغلقة';
  expectedDate: string;
  branch: string;
  createdDate: string;
  notes: string;
  products: POProduct[];
}

/* ------------------------------------------------------------------ */
/*  MOCK DATA                                                          */
/* ------------------------------------------------------------------ */
const mockPOs: PurchaseOrder[] = [
  { id: 1, poNumber: 'PO-2024-001', supplier: 'شركة الدلتا للأعلاف', supplierCode: 'SUP-001', total: 200000, status: 'مُستلمة', expectedDate: '2024-01-20', branch: 'القاهرة', createdDate: '2024-01-05', notes: '', products: [{ product: 'علف ناهي', qty: 50, unitPrice: 2500, total: 125000 }, { product: 'علف بادي', qty: 30, unitPrice: 2500, total: 75000 }] },
  { id: 2, poNumber: 'PO-2024-002', supplier: 'مزارع الغرب لإنتاج الكتكوت', supplierCode: 'SUP-003', total: 180000, status: 'قيد التنفيذ', expectedDate: '2024-01-25', branch: 'القاهرة', createdDate: '2024-01-08', notes: 'كتكوت أبيض ساسو', products: [{ product: 'كتكوت أبيض', qty: 20000, unitPrice: 9, total: 180000 }] },
  { id: 3, poNumber: 'PO-2024-003', supplier: 'مصنع الشرق للأدوية البيطرية', supplierCode: 'SUP-002', total: 75000, status: 'مُرسلة', expectedDate: '2024-02-01', branch: 'الإسكندرية', createdDate: '2024-01-10', notes: '', products: [{ product: 'لقاح إن بي', qty: 5000, unitPrice: 9, total: 45000 }, { product: 'فيتامينات', qty: 100, unitPrice: 300, total: 30000 }] },
  { id: 4, poNumber: 'PO-2024-004', supplier: 'إنتاج الوادي للتعبئة', supplierCode: 'SUP-004', total: 35000, status: 'مسودة', expectedDate: '2024-02-05', branch: 'طنطا', createdDate: '2024-01-12', notes: 'بانتظار الاعتماد', products: [{ product: 'كرتون بيض', qty: 10000, unitPrice: 3.5, total: 35000 }] },
  { id: 5, poNumber: 'PO-2024-005', supplier: 'شركة الفارما بيطري', supplierCode: 'SUP-007', total: 28000, status: 'معتمدة', expectedDate: '2024-01-28', branch: 'القاهرة', createdDate: '2024-01-14', notes: '', products: [{ product: 'مضاد حيوي', qty: 200, unitPrice: 140, total: 28000 }] },
  { id: 6, poNumber: 'PO-2024-006', supplier: 'مزارع الصعيد للأعلاف', supplierCode: 'SUP-006', total: 125000, status: 'مغلقة', expectedDate: '2024-01-15', branch: 'القاهرة', createdDate: '2024-01-02', notes: 'تم الاستلام والفحص', products: [{ product: 'علف ناهي', qty: 25, unitPrice: 2500, total: 62500 }, { product: 'علف بادي', qty: 25, unitPrice: 2500, total: 62500 }] },
  { id: 7, poNumber: 'PO-2024-007', supplier: 'شركة الأمل لإنتاج الكتكوت', supplierCode: 'SUP-008', total: 135000, status: 'مُستلمة', expectedDate: '2024-01-22', branch: 'الإسكندرية', createdDate: '2024-01-09', notes: '', products: [{ product: 'كتكوت أبيض', qty: 15000, unitPrice: 9, total: 135000 }] },
  { id: 8, poNumber: 'PO-2024-008', supplier: 'شركة النيل للمعدات', supplierCode: 'SUP-005', total: 45000, status: 'قيد التنفيذ', expectedDate: '2024-02-10', branch: 'القاهرة', createdDate: '2024-01-15', notes: 'معدات جديدة', products: [{ product: 'سير ناقل', qty: 5, unitPrice: 9000, total: 45000 }] },
  { id: 9, poNumber: 'PO-2024-009', supplier: 'شركة الدلتا للأعلاف', supplierCode: 'SUP-001', total: 250000, status: 'مُرسلة', expectedDate: '2024-02-15', branch: 'القاهرة', createdDate: '2024-01-16', notes: 'طلبية شهر فبراير', products: [{ product: 'علف ناهي', qty: 100, unitPrice: 2500, total: 250000 }] },
  { id: 10, poNumber: 'PO-2024-010', supplier: 'مصنع الشرق للأدوية البيطرية', supplierCode: 'SUP-002', total: 55000, status: 'مسودة', expectedDate: '2024-02-20', branch: 'طنطا', createdDate: '2024-01-17', notes: '', products: [{ product: 'لقاح برونشايتس', qty: 3000, unitPrice: 12, total: 36000 }, { product: 'فيتامينات', qty: 50, unitPrice: 380, total: 19000 }] },
  { id: 11, poNumber: 'PO-2024-011', supplier: 'مزارع الغرب لإنتاج الكتكوت', supplierCode: 'SUP-003', total: 50000, status: 'معتمدة', expectedDate: '2024-02-01', branch: 'القاهرة', createdDate: '2024-01-18', notes: 'كتكوت ساسو', products: [{ product: 'كتكوت ساسو', qty: 5000, unitPrice: 10, total: 50000 }] },
  { id: 12, poNumber: 'PO-2024-012', supplier: 'شركة التقنية للمعدات', supplierCode: 'SUP-010', total: 78000, status: 'مغلقة', expectedDate: '2024-01-10', branch: 'المنصورة', createdDate: '2023-12-28', notes: 'تم التركيب والتشغيل', products: [{ product: 'منافذ تغذية أوتوماتيك', qty: 100, unitPrice: 780, total: 78000 }] },
];

/* ------------------------------------------------------------------ */
/*  STATUS HELPER                                                      */
/* ------------------------------------------------------------------ */
const statusSteps = ['مسودة', 'معتمدة', 'مُرسلة', 'قيد التنفيذ', 'مُستلمة', 'مغلقة'];

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    مسودة: 'bg-gray-100 text-gray-600 border-gray-300',
    معتمدة: 'bg-blue-100 text-blue-700 border-blue-300',
    مُرسلة: 'bg-cyan-100 text-cyan-700 border-cyan-300',
    'قيد التنفيذ': 'bg-amber-100 text-amber-700 border-amber-300',
    مُستلمة: 'bg-green-100 text-green-700 border-green-300',
    مغلقة: 'bg-purple-100 text-purple-700 border-purple-300',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${styles[status] || styles['مسودة']}`}>
      {status}
    </span>
  );
}

function ProgressSteps({ currentStatus }: { currentStatus: string }) {
  const currentIndex = statusSteps.indexOf(currentStatus);
  return (
    <div className="flex items-center gap-1 flex-wrap">
      {statusSteps.map((step, i) => (
        <div key={step} className="flex items-center">
          <div className={`w-2 h-2 rounded-full ${i <= currentIndex ? 'bg-green-600' : 'bg-gray-300'}`} />
          <span className={`text-[10px] mr-1 ${i <= currentIndex ? 'text-green-700 font-medium' : 'text-gray-400'}`}>{step}</span>
          {i < statusSteps.length - 1 && (
            <div className={`w-4 h-0.5 mx-1 ${i < currentIndex ? 'bg-green-500' : 'bg-gray-200'}`} />
          )}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function PurchasesPage() {
  const [pos, setPos] = useState<PurchaseOrder[]>(mockPOs);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [viewingPO, setViewingPO] = useState<PurchaseOrder | null>(null);
  const [formSupplier, setFormSupplier] = useState('');
  const [formExpectedDate, setFormExpectedDate] = useState('');
  const [formBranch, setFormBranch] = useState('القاهرة');
  const [formNotes, setFormNotes] = useState('');
  const [formProducts, setFormProducts] = useState<POProduct[]>([{ product: '', qty: 0, unitPrice: 0, total: 0 }]);

  /* ── KPIs ── */
  const totalPOs = pos.length;
  const inProgress = pos.filter((p) => ['معتمدة', 'مُرسلة', 'قيد التنفيذ'].includes(p.status)).length;
  const completed = pos.filter((p) => p.status === 'مغلقة').length;
  const totalValue = pos.reduce((s, p) => s + p.total, 0);

  /* ── Filtered data ── */
  const filteredData = useMemo(() => {
    let result = [...pos];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) => p.supplier.includes(q) || p.poNumber.toLowerCase().includes(q) || p.branch.includes(q)
      );
    }
    if (filterStatus) result = result.filter((p) => p.status === filterStatus);
    return result;
  }, [pos, searchQuery, filterStatus]);

  const branches = [...new Set(mockPOs.map((p) => p.branch))];
  const suppliers = [...new Set(mockPOs.map((p) => p.supplier))];

  /* ── Form helpers ── */
  const openAdd = () => {
    setFormSupplier(suppliers[0]);
    setFormExpectedDate('');
    setFormBranch('القاهرة');
    setFormNotes('');
    setFormProducts([{ product: '', qty: 0, unitPrice: 0, total: 0 }]);
    setModalOpen(true);
  };

  const addProduct = () => {
    setFormProducts([...formProducts, { product: '', qty: 0, unitPrice: 0, total: 0 }]);
  };

  const removeProduct = (i: number) => {
    setFormProducts(formProducts.filter((_, idx) => idx !== i));
  };

  const updateProduct = (i: number, field: string, value: any) => {
    setFormProducts((prev) => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: value };
      if (field === 'qty' || field === 'unitPrice') {
        next[i].total = next[i].qty * next[i].unitPrice;
      }
      return next;
    });
  };

  const formTotal = formProducts.reduce((s, p) => s + p.total, 0);

  const savePO = () => {
    if (!formSupplier) return;
    const newId = Math.max(...pos.map((p) => p.id)) + 1;
    const newPO: PurchaseOrder = {
      id: newId,
      poNumber: `PO-2024-${String(newId).padStart(3, '0')}`,
      supplier: formSupplier,
      supplierCode: `SUP-${String(newId).padStart(3, '0')}`,
      total: formTotal,
      status: 'مسودة',
      expectedDate: formExpectedDate || new Date().toISOString().split('T')[0],
      branch: formBranch,
      createdDate: new Date().toISOString().split('T')[0],
      notes: formNotes,
      products: formProducts.filter((p) => p.product),
    };
    setPos((prev) => [newPO, ...prev]);
    setModalOpen(false);
  };

  const openDetail = (po: PurchaseOrder) => {
    setViewingPO(po);
    setDetailOpen(true);
  };

  const deletePO = (id: number) => {
    if (confirm('هل أنت متأكد من حذف أمر الشراء؟')) {
      setPos((prev) => prev.filter((p) => p.id !== id));
    }
  };

  const advanceStatus = (id: number) => {
    setPos((prev) =>
      prev.map((p) => {
        if (p.id !== id) return p;
        const idx = statusSteps.indexOf(p.status);
        if (idx < statusSteps.length - 1) {
          return { ...p, status: statusSteps[idx + 1] as any };
        }
        return p;
      })
    );
    if (viewingPO && viewingPO.id === id) {
      const idx = statusSteps.indexOf(viewingPO.status);
      if (idx < statusSteps.length - 1) {
        setViewingPO({ ...viewingPO, status: statusSteps[idx + 1] as any });
      }
    }
  };

  const resetFilters = () => {
    setSearchQuery('');
    setFilterStatus('');
  };

  /* ── Table columns ── */
  const columns = [
    { key: 'poNumber', header: 'رقم الأمر', sortable: true, width: '110px' },
    { key: 'supplier', header: 'المورد', sortable: true },
    {
      key: 'total',
      header: 'الإجمالي',
      sortable: true,
      width: '110px',
      render: (row: PurchaseOrder) => row.total.toLocaleString('ar-EG'),
    },
    {
      key: 'status',
      header: 'الحالة',
      width: '100px',
      render: (row: PurchaseOrder) => <StatusBadge status={row.status} />,
    },
    { key: 'expectedDate', header: 'التاريخ المتوقع', sortable: true, width: '110px' },
    { key: 'branch', header: 'الفرع', sortable: true, width: '90px' },
  ];

  return (
    <div className="gff-page-transition space-y-6">
      <PageHeader
        title="أوامر الشراء"
        subtitle="إدارة أوامر الشراء ومتابعة حالة الطلبات"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'المشتريات' }]}
      >
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors shadow-sm"
        >
          <Plus size={16} /> أمر شراء جديد
        </button>
      </PageHeader>

      {/* ── KPIs ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="أوامر الشراء" value={totalPOs.toLocaleString('ar-EG')} icon={ClipboardList} iconBg="bg-blue-50" iconColor="text-blue-600" change={5} delay={0} />
        <KPICard title="قيد التنفيذ" value={inProgress.toLocaleString('ar-EG')} icon={Clock} iconBg="bg-amber-50" iconColor="text-amber-600" delay={0.05} />
        <KPICard title="مكتملة" value={completed.toLocaleString('ar-EG')} icon={CheckCircle2} iconBg="bg-green-50" iconColor="text-green-600" change={8} delay={0.1} />
        <KPICard title="إجمالي القيمة" value={totalValue.toLocaleString('ar-EG')} icon={CircleDollarSign} iconBg="bg-purple-50" iconColor="text-purple-600" change={12} changeLabel="عن الشهر السابق" delay={0.15} />
      </div>

      {/* ── Filters ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4"
      >
        <div className="flex flex-col lg:flex-row gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[220px]">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
            <input
              type="text"
              placeholder="بحث برقم الأمر أو المورد..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pr-10 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
            />
          </div>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل الحالات</option>
            {statusSteps.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <button onClick={resetFilters} className="h-10 px-4 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm transition-colors">
            إعادة ضبط
          </button>
        </div>
      </motion.div>

      {/* ── Table ── */}
      <DataTable
        columns={columns}
        data={filteredData}
        pageSize={10}
        title={`أوامر الشراء (${filteredData.length})`}
        rowActions={{
          onView: openDetail,
          onEdit: (row) => openDetail(row),
          onDelete: (row) => deletePO(row.id),
        }}
      />

      {/* ═══════════════════ CREATE PO MODAL ═══════════════════ */}
      <AnimatePresence>
        {modalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">أمر شراء جديد</h3>
                <button onClick={() => setModalOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-5">
                {/* Header Info */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-textSecondary mb-1.5">المورد</label>
                    <select value={formSupplier} onChange={(e) => setFormSupplier(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      {suppliers.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-textSecondary mb-1.5">التاريخ المتوقع</label>
                    <input type="date" value={formExpectedDate} onChange={(e) => setFormExpectedDate(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-textSecondary mb-1.5">الفرع</label>
                    <select value={formBranch} onChange={(e) => setFormBranch(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      {branches.map((b) => (
                        <option key={b} value={b}>{b}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Products */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-sm font-medium text-textSecondary">المنتجات</label>
                    <button onClick={addProduct} className="text-xs text-green-700 hover:text-green-800 font-medium flex items-center gap-1">
                      <Plus size={14} /> إضافة منتج
                    </button>
                  </div>
                  <div className="space-y-2">
                    {formProducts.map((p, i) => (
                      <div key={i} className="grid grid-cols-12 gap-2 items-center bg-surface dark:bg-darkCard rounded-lg p-2">
                        <div className="col-span-4">
                          <input value={p.product} onChange={(e) => updateProduct(i, 'product', e.target.value)} placeholder="اسم المنتج" className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm" />
                        </div>
                        <div className="col-span-2">
                          <input type="number" value={p.qty || ''} onChange={(e) => updateProduct(i, 'qty', +e.target.value)} placeholder="الكمية" className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm" />
                        </div>
                        <div className="col-span-2">
                          <input type="number" value={p.unitPrice || ''} onChange={(e) => updateProduct(i, 'unitPrice', +e.target.value)} placeholder="السعر" className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm" />
                        </div>
                        <div className="col-span-2">
                          <p className="text-sm font-medium text-textPrimary dark:text-darkText text-center">{p.total.toLocaleString('ar-EG')}</p>
                        </div>
                        <div className="col-span-2">
                          {formProducts.length > 1 && (
                            <button onClick={() => removeProduct(i)} className="w-8 h-8 rounded flex items-center justify-center text-red-500 hover:bg-red-50 transition-colors">
                              <Trash2 size={14} />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Total */}
                <div className="flex items-center justify-between bg-green-50 dark:bg-green-950/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                  <span className="text-sm font-medium text-green-700 dark:text-green-300">الإجمالي</span>
                  <span className="text-xl font-bold text-green-800 dark:text-green-200">{formTotal.toLocaleString('ar-EG')} ج.م</span>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">ملاحظات</label>
                  <textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} rows={2} className="w-full px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm resize-none" />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-uiBorder dark:border-darkBorder">
                <button onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm transition-colors">إلغاء</button>
                <button onClick={savePO} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">حفظ</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════════════ DETAIL MODAL ═══════════════════ */}
      <AnimatePresence>
        {detailOpen && viewingPO && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-700 flex items-center justify-center text-white">
                    <ClipboardList size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{viewingPO.poNumber}</h3>
                    <p className="text-xs text-textMuted">{viewingPO.supplier}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {viewingPO.status !== 'مغلقة' && (
                    <button onClick={() => advanceStatus(viewingPO.id)} className="px-3 py-1.5 bg-green-700 hover:bg-green-800 text-white rounded-lg text-xs font-medium transition-colors">
                      {viewingPO.status === 'مسودة' ? 'اعتماد' : viewingPO.status === 'معتمدة' ? 'إرسال' : viewingPO.status === 'مُرسلة' ? 'تنفيذ' : viewingPO.status === 'قيد التنفيذ' ? 'استلام' : 'إغلاق'}
                    </button>
                  )}
                  <button onClick={() => setDetailOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                    <X size={18} />
                  </button>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Progress Steps */}
                <div className="bg-surface dark:bg-darkCard rounded-lg p-4">
                  <ProgressSteps currentStatus={viewingPO.status} />
                </div>

                {/* Info Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">المورد</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingPO.supplier}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الحالة</p>
                    <StatusBadge status={viewingPO.status} />
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">التاريخ المتوقع</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingPO.expectedDate}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الفرع</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingPO.branch}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">تاريخ الإنشاء</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingPO.createdDate}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">إجمالي الأصناف</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingPO.products.length}</p>
                  </div>
                  <div className="md:col-span-2 bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">ملاحظات</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingPO.notes || '-'}</p>
                  </div>
                </div>

                {/* Total */}
                <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-4 border border-green-200 dark:border-green-800 flex items-center justify-between">
                  <span className="text-sm font-medium text-green-700 dark:text-green-300">إجمالي أمر الشراء</span>
                  <span className="text-xl font-bold text-green-800 dark:text-green-200">{viewingPO.total.toLocaleString('ar-EG')} ج.م</span>
                </div>

                {/* Products Table */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">المنتجات</h4>
                  <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">#</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">المنتج</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الكمية</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">سعر الوحدة</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الإجمالي</th>
                        </tr>
                      </thead>
                      <tbody>
                        {viewingPO.products.map((p, i) => (
                          <tr key={i} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                            <td className="px-3 py-2 text-textMuted">{i + 1}</td>
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{p.product}</td>
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{p.qty.toLocaleString('ar-EG')}</td>
                            <td className="px-3 py-2 text-textPrimary dark:text-darkText">{p.unitPrice.toLocaleString('ar-EG')} ج.م</td>
                            <td className="px-3 py-2 font-medium text-textPrimary dark:text-darkText">{p.total.toLocaleString('ar-EG')} ج.م</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
