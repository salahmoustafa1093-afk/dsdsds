// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Percent, Plus, X, TrendingUp, CheckCircle2, Clock, Banknote, ArrowRight, Calculator, Award,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

// ─── Types ──────────────────────────────────────────────
interface CommissionRule {
  id: string;
  role: string;
  targetAmount: number;
  commissionPercent: number;
  bonusThreshold: number;
  bonusAmount: number;
}

interface SalesRep {
  id: string;
  name: string;
  salesAchieved: number;
  target: number;
  achievementPercent: number;
  commissionEarned: number;
  bonus: number;
  status: string;
}

// ─── Mock Data ──────────────────────────────────────────
const commissionRules: CommissionRule[] = [
  { id: 'R-001', role: 'مندوب مبيعات', targetAmount: 500000, commissionPercent: 3, bonusThreshold: 120, bonusAmount: 2000 },
  { id: 'R-002', role: 'مشرف مبيعات', targetAmount: 800000, commissionPercent: 4, bonusThreshold: 130, bonusAmount: 5000 },
  { id: 'R-003', role: 'مدير مبيعات', targetAmount: 1500000, commissionPercent: 5, bonusThreshold: 150, bonusAmount: 10000 },
];

const salesReps: SalesRep[] = [
  { id: 'E-001', name: 'أحمد محمود', salesAchieved: 520000, target: 500000, achievementPercent: 104, commissionEarned: 15600, bonus: 2000, status: 'معتمدة' },
  { id: 'E-005', name: 'سارة محمود', salesAchieved: 480000, target: 500000, achievementPercent: 96, commissionEarned: 14400, bonus: 0, status: 'معتمدة' },
  { id: 'E-009', name: 'يوسف إبراهيم', salesAchieved: 650000, target: 500000, achievementPercent: 130, commissionEarned: 19500, bonus: 2000, status: 'قيد المراجعة' },
  { id: 'E-010', name: 'ليلى سالم', salesAchieved: 380000, target: 500000, achievementPercent: 76, commissionEarned: 11400, bonus: 0, status: 'محسوبة' },
  { id: 'E-011', name: 'عمر خالد', salesAchieved: 920000, target: 800000, achievementPercent: 115, commissionEarned: 36800, bonus: 5000, status: 'معتمدة' },
  { id: 'E-012', name: 'نادية علي', salesAchieved: 780000, target: 800000, achievementPercent: 97.5, commissionEarned: 31200, bonus: 0, status: 'قيد المراجعة' },
];

const statusColors: Record<string, string> = {
  'محسوبة': 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400',
  'قيد المراجعة': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'معتمدة': 'bg-gold-100 text-gold-700 dark:bg-gold-900/40 dark:text-gold-400',
  'مدفوعة': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
};

const workflowSteps = ['محسوبة', 'قيد المراجعة', 'معتمدة', 'مدفوعة'];

export default function HRCommissionsPage() {
  const [showCalc, setShowCalc] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [calcSales, setCalcSales] = useState('');
  const [calcRole, setCalcRole] = useState('مندوب مبيعات');
  const [calcResult, setCalcResult] = useState<{ commission: number; bonus: number; total: number } | null>(null);

  const totalCommissions = salesReps.reduce((s, r) => s + r.commissionEarned, 0);
  const totalDue = salesReps.filter(r => r.status === 'معتمدة').reduce((s, r) => s + r.commissionEarned + r.bonus, 0);
  const totalPaid = salesReps.filter(r => r.status === 'مدفوعة').reduce((s, r) => s + r.commissionEarned + r.bonus, 0);
  const avgRate = (salesReps.reduce((s, r) => s + r.achievementPercent, 0) / salesReps.length).toFixed(1);

  const chartData = salesReps.map(r => ({ name: r.name.split(' ')[0], achieved: r.salesAchieved, target: r.target }));

  const handleCalculate = () => {
    const sales = parseFloat(calcSales);
    if (!sales) return;
    const rule = commissionRules.find(r => r.role === calcRole) || commissionRules[0];
    const commission = (sales * rule.commissionPercent) / 100;
    const achievement = (sales / rule.targetAmount) * 100;
    const bonus = achievement >= rule.bonusThreshold ? rule.bonusAmount : 0;
    setCalcResult({ commission: Math.round(commission), bonus, total: Math.round(commission + bonus) });
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="عمولات المبيعات"
        subtitle="إدارة وحساب عمولات مندوبي المبيعات"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الموارد البشرية', path: '/hr' },
          { label: 'العمولات' },
        ]}
      >
        <button onClick={() => setShowReport(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">
          <Banknote size={16} /> تقرير شهري
        </button>
        <button onClick={() => setShowCalc(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gold-500 text-white text-sm font-medium hover:bg-gold-600 transition-colors shadow-sm">
          <Calculator size={16} /> حاسبة العمولة
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي العمولات" value={`${totalCommissions.toLocaleString()} ج.م`} icon={Percent} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="المستحقة" value={`${totalDue.toLocaleString()} ج.م`} icon={Clock} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.1} />
        <KPICard title="المدفوعة" value={`${totalPaid.toLocaleString()} ج.م`} icon={CheckCircle2} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.2} />
        <KPICard title="معدل الإنجاز" value={`%${avgRate}`} icon={TrendingUp} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-700 dark:text-purple-400" delay={0.3} />
      </div>

      {/* Commission Rules Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">قواعد العمولة</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['الدور', 'المستهدف', 'نسبة العمولة', 'عتبة البonus', 'مبلغ البonus'].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {commissionRules.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.role}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.targetAmount.toLocaleString()} ج.م</td>
                  <td className="px-4 py-3 text-sm text-green-700 font-semibold">%{row.commissionPercent}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">%{row.bonusThreshold}</td>
                  <td className="px-4 py-3 text-sm text-gold-600 font-semibold">{row.bonusAmount.toLocaleString()} ج.م</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Sales Reps Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">مندوبو المبيعات</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['الاسم', 'المبيعات', 'المستهدف', 'الإنجاز %', 'العمولة', 'البونص', 'الحالة', ''].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {salesReps.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.name}</td>
                  <td className="px-4 py-3 text-sm text-green-700 font-semibold">{row.salesAchieved.toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.target.toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm">
                    <span className={`font-semibold ${row.achievementPercent >= 100 ? 'text-green-700' : 'text-red-600'}`}>%{row.achievementPercent}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gold-600 font-semibold">{row.commissionEarned.toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm text-blue-600 font-semibold">{row.bonus > 0 ? row.bonus.toLocaleString() : '-'}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[row.status]}`}>{row.status}</span></td>
                  <td className="px-4 py-3">
                    {/* Workflow steps */}
                    <div className="flex items-center gap-0.5">
                      {workflowSteps.map((step, si) => {
                        const isActive = workflowSteps.indexOf(row.status) >= si;
                        return (
                          <div key={step} className="flex items-center">
                            <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`} title={step} />
                            {si < workflowSteps.length - 1 && <div className={`w-3 h-0.5 ${isActive && workflowSteps.indexOf(row.status) > si ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'}`} />}
                          </div>
                        );
                      })}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Achievement Chart */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5">
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">مقارنة المبيعات والمستهدف</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Legend />
              <Bar dataKey="achieved" name="المبيعات" fill="#14a86a" radius={[4, 4, 0, 0]} />
              <Bar dataKey="target" name="المستهدف" fill="#daa520" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Commission Calculator Modal */}
      <AnimatePresence>
        {showCalc && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowCalc(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">حاسبة العمولة</h3>
                <button onClick={() => setShowCalc(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div><label className="block text-xs font-medium text-textSecondary mb-1">الدور الوظيفي</label><select value={calcRole} onChange={e => { setCalcRole(e.target.value); setCalcResult(null); }} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">{commissionRules.map(r => <option key={r.id}>{r.role}</option>)}</select></div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">مبلغ المبيعات (ج.م)</label><input type="number" value={calcSales} onChange={e => { setCalcSales(e.target.value); setCalcResult(null); }} placeholder="أدخل مبلغ المبيعات" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                <button onClick={handleCalculate} className="w-full py-2.5 rounded-lg bg-gold-500 text-white text-sm font-medium hover:bg-gold-600 transition-colors">احسب العمولة</button>
                {calcResult && (
                  <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="bg-gold-50 dark:bg-gold-900/20 rounded-lg p-4 space-y-2 border border-gold-200 dark:border-gold-800">
                    <div className="flex justify-between text-sm"><span className="text-textSecondary">العمولة</span><span className="font-semibold text-gold-700">{calcResult.commission.toLocaleString()} ج.م</span></div>
                    <div className="flex justify-between text-sm"><span className="text-textSecondary">البونص</span><span className="font-semibold text-blue-600">{calcResult.bonus > 0 ? `${calcResult.bonus.toLocaleString()} ج.م` : '-'}</span></div>
                    <div className="border-t border-gold-200 pt-2 flex justify-between font-bold text-gold-800"><span>الإجمالي</span><span>{calcResult.total.toLocaleString()} ج.م</span></div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Monthly Report Modal */}
      <AnimatePresence>
        {showReport && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowReport(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تقرير عمولات يناير 2025</h3>
                <button onClick={() => setShowReport(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-3">
                {[
                  ['إجمالي المبيعات', `${salesReps.reduce((s, r) => s + r.salesAchieved, 0).toLocaleString()} ج.م`],
                  ['إجمالي العمولات', `${totalCommissions.toLocaleString()} ج.م`],
                  ['إجمالي البونص', `${salesReps.reduce((s, r) => s + r.bonus, 0).toLocaleString()} ج.م`],
                  ['المستحقة الدفع', `${totalDue.toLocaleString()} ج.م`],
                  ['عدد المندوبين', `${salesReps.length}`],
                  ['معدل الإنجاز', `%${avgRate}`],
                ].map(([label, val]) => (
                  <div key={label} className="flex justify-between py-2 border-b border-uiBorder/30 last:border-0"><span className="text-sm text-textSecondary">{label}</span><span className="text-sm font-semibold text-textPrimary dark:text-darkText">{val}</span></div>
                ))}
                <div className="pt-2 flex justify-end gap-2">
                  <button onClick={() => setShowReport(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary">إغلاق</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
