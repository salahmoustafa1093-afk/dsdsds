// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import {
  Package,
  AlertTriangle,
  Layers,
  DollarSign,
  Search,
  Plus,
  Eye,
  Edit3,
  Trash2,
  Filter,
  X,
  Barcode,
  Archive,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

/* ──────────────────────────── mock data ──────────────────────────── */

interface Product {
  id: string;
  sku: string;
  name: string;
  category: string;
  unit: string;
  stock: number;
  minStock: number;
  maxStock: number;
  price: number;
  barcode: string;
  description: string;
  status: 'active' | 'inactive';
}

const CATEGORIES = ['أعلاف دواجن', 'حبوب', 'مكملات غذائية', 'ردة ونخالة', 'مستلزمات'];
const UNITS = ['طن', 'شيكارة', 'كجم', 'لتر', 'علبة'];

const PRODUCTS: Product[] = [
  { id: '1', sku: 'AF-B-001', name: 'أعلاف دواجن بادئ', category: 'أعلاف دواجن', unit: 'شيكارة', stock: 450, minStock: 100, maxStock: 800, price: 450, barcode: '6287012340012', description: 'علف بادئ للكتاكيت من عمر يوم حتى ٢١ يوم', status: 'active' },
  { id: '2', sku: 'AF-N-002', name: 'أعلاف دواجن نامي', category: 'أعلاف دواجن', unit: 'شيكارة', stock: 320, minStock: 150, maxStock: 700, price: 650, barcode: '6287012340029', description: 'علف نامي للدواجن من عمر ٢٢ حتى ٣٥ يوم', status: 'active' },
  { id: '3', sku: 'AF-F-003', name: 'أعلاف دواجن ناهي', category: 'أعلاف دواجن', unit: 'شيكارة', stock: 180, minStock: 200, maxStock: 600, price: 750, barcode: '6287012340036', description: 'علف ناهي للدواجن من عمر ٣٦ يوم حتى الذبح', status: 'active' },
  { id: '4', sku: 'GR-001', name: 'ذرة صفراء', category: 'حبوب', unit: 'طن', stock: 85, minStock: 50, maxStock: 200, price: 800, barcode: '6287012340043', description: 'ذرة صفراء مجروشة درجة أولى', status: 'active' },
  { id: '5', sku: 'SB-001', name: 'كسب فول صويا', category: 'حبوب', unit: 'طن', stock: 120, minStock: 40, maxStock: 180, price: 1400, barcode: '6287012340050', description: 'كسب فول صويا ٤٤-٤٨٪ بروتين', status: 'active' },
  { id: '6', sku: 'WF-001', name: 'ردة قمح', category: 'ردة ونخالة', unit: 'طن', stock: 25, minStock: 30, maxStock: 150, price: 280, barcode: '6287012340067', description: 'ردة قمح خشنة للتسمين', status: 'active' },
  { id: '7', sku: 'AF-B-004', name: 'أعلاف دواجن بادئ سوبر', category: 'أعلاف دواجن', unit: 'شيكارة', stock: 600, minStock: 200, maxStock: 1000, price: 520, barcode: '6287012340074', description: 'علف بادئ عالي الجودة بمحتوى بروتين ٢٣٪', status: 'active' },
  { id: '8', sku: 'BR-001', name: 'نخالة قمح', category: 'ردة ونخالة', unit: 'طن', stock: 300, minStock: 100, maxStock: 500, price: 180, barcode: '6287012340081', description: 'نخالة قمح للأبقار والجاموس', status: 'active' },
  { id: '9', sku: 'MS-001', name: 'مسحوق عظام', category: 'مكملات غذائية', unit: 'كجم', stock: 90, minStock: 50, maxStock: 300, price: 12, barcode: '6287012340098', description: 'مسحوق عظام كمصدر للكالسيوم والفوسفور', status: 'active' },
  { id: '10', sku: 'LS-001', name: 'حجر جيري', category: 'مكملات غذائية', unit: 'كجم', stock: 500, minStock: 200, maxStock: 1000, price: 5, barcode: '6287012340104', description: 'حجر جيري مطحون كمصدر للكالسيوم', status: 'active' },
  { id: '11', sku: 'SS-001', name: 'ملح طعام صناعي', category: 'مكملات غذائية', unit: 'كجم', stock: 15, minStock: 20, maxStock: 250, price: 8, barcode: '6287012340111', description: 'ملح طعام مدعم باليود للدواجن', status: 'active' },
  { id: '12', sku: 'VM-001', name: 'خلطة فيتامينات', category: 'مكملات غذائية', unit: 'علبة', stock: 80, minStock: 30, maxStock: 200, price: 350, barcode: '6287012340128', description: 'خلطة فيتامينات شاملة A-D3-E-K', status: 'active' },
  { id: '13', sku: 'GR-002', name: 'شعير', category: 'حبوب', unit: 'طن', stock: 55, minStock: 25, maxStock: 120, price: 650, barcode: '6287012340135', description: 'شعير مجروش للتغذية الحيوانية', status: 'active' },
  { id: '14', sku: 'SF-001', name: 'فول صويا كامل', category: 'حبوب', unit: 'طن', stock: 200, minStock: 80, maxStock: 350, price: 1100, barcode: '6287012340142', description: 'فول صويا مبستر كامل للتغذية', status: 'active' },
  { id: '15', sku: 'CG-001', name: 'كسر ذرة', category: 'حبوب', unit: 'طن', stock: 8, minStock: 15, maxStock: 100, price: 550, barcode: '6287012340159', description: 'كسر ذرة لخفض تكلفة العلف', status: 'active' },
  { id: '16', sku: 'PR-001', name: 'بروتين نباتي مركز', category: 'مكملات غذائية', unit: 'كجم', stock: 40, minStock: 50, maxStock: 200, price: 18, barcode: '6287012340166', description: 'بروتين نباتي ٦٠٪ بروتين', status: 'active' },
  { id: '17', sku: 'AF-L-001', name: 'أعلاف أرانب', category: 'أعلاف دواجن', unit: 'شيكارة', stock: 150, minStock: 50, maxStock: 300, price: 380, barcode: '6287012340173', description: 'علف أرانب نامي وبادئ', status: 'active' },
  { id: '18', sku: 'EQ-001', name: 'أعلاف خيول', category: 'أعلاف دواجن', unit: 'شيكارة', stock: 60, minStock: 30, maxStock: 200, price: 900, barcode: '6287012340180', description: 'علف خيول سباق وركوب', status: 'active' },
  { id: '19', sku: 'DS-001', name: 'دواجن سلالة', category: 'مستلزمات', unit: 'كجم', stock: 1200, minStock: 500, maxStock: 3000, price: 45, barcode: '6287012340197', description: 'كتاكيت سلالة بياض لاحم', status: 'active' },
  { id: '20', sku: 'TR-001', name: 'حصيرة بلاستيك', category: 'مستلزمات', unit: 'علبة', stock: 5, minStock: 10, maxStock: 100, price: 1200, barcode: '6287012340203', description: 'حصائر بلاستيكية للدواجن', status: 'inactive' },
];

/* ──────────────────────────── component ──────────────────────────── */

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [stockFilter, setStockFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [viewProduct, setViewProduct] = useState<Product | null>(null);

  const pageSize = 8;

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const q = search.trim();
      const matchSearch = q === '' || p.name.includes(q) || p.sku.includes(q) || p.barcode.includes(q);
      const matchCategory = categoryFilter === 'all' || p.category === categoryFilter;
      const matchStatus = statusFilter === 'all' || p.status === statusFilter;
      const matchStock =
        stockFilter === 'all' ? true :
        stockFilter === 'low' ? p.stock < p.minStock :
        stockFilter === 'near' ? p.stock >= p.minStock && p.stock <= p.minStock * 1.5 :
        stockFilter === 'ok' ? p.stock > p.minStock * 1.5 : true;
      return matchSearch && matchCategory && matchStatus && matchStock;
    });
  }, [products, search, categoryFilter, statusFilter, stockFilter]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const totalProducts = products.length;
  const lowStock = products.filter((p) => p.stock < p.minStock).length;
  const totalCategories = new Set(products.map((p) => p.category)).size;
  const inventoryValue = products.reduce((s, p) => s + p.stock * p.price, 0);

  const resetFilters = () => {
    setSearch('');
    setCategoryFilter('all');
    setStatusFilter('all');
    setStockFilter('all');
    setPage(1);
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const saveProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    setEditProduct(null);
  };

  const formatEGP = (n: number) => n.toLocaleString('ar-EG') + ' ج.م';

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="قائمة المنتجات"
        subtitle="كتالوج المنتجات وإدارة المخزون"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'إدارة المخازن', path: '/inventory' }, { label: 'المنتجات' }]}
      >
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-[#0a4a30] hover:bg-[#0d6b43] text-white gap-2">
              <Plus size={16} />
              منتج جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-right text-lg">إضافة منتج جديد</DialogTitle>
            </DialogHeader>
            <ProductForm
              product={null}
              onSave={(p) => { setProducts((prev) => [p, ...prev]); }}
            />
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي المنتجات" value={totalProducts.toString()} icon={Package} iconBg="bg-green-100" iconColor="text-green-600" change={3} delay={0} />
        <KPICard title="منتجات تحت الحد" value={lowStock.toString()} icon={AlertTriangle} iconBg="bg-red-100" iconColor="text-red-600" change={-2} delay={0.1} />
        <KPICard title="فئات المنتجات" value={totalCategories.toString()} icon={Layers} iconBg="bg-blue-100" iconColor="text-blue-600" delay={0.2} />
        <KPICard title="قيمة المخزون" value={formatEGP(inventoryValue)} icon={DollarSign} iconBg="bg-amber-100" iconColor="text-amber-600" change={8} delay={0.3} />
      </div>

      {/* Filters */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <Input
                  placeholder="بحث باسم المنتج أو SKU أو الباركود..."
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                  className="pr-9 text-right"
                />
              </div>
              <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="gap-2">
                <Filter size={16} />
                فلترة
              </Button>
              {(categoryFilter !== 'all' || statusFilter !== 'all' || stockFilter !== 'all' || search) && (
                <Button variant="ghost" onClick={resetFilters} className="text-red-500 gap-1">
                  <X size={14} />
                  إلغاء الفلتر
                </Button>
              )}
            </div>
            <AnimatePresence>
              {showFilters && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                  <div className="flex flex-wrap gap-3 pt-2">
                    <div className="w-44">
                      <Label className="text-xs text-gray-500 mb-1 block">الفئة</Label>
                      <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                        <SelectTrigger className="text-right"><SelectValue placeholder="الكل" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">الكل</SelectItem>
                          {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-44">
                      <Label className="text-xs text-gray-500 mb-1 block">الحالة</Label>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="text-right"><SelectValue placeholder="الكل" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">الكل</SelectItem>
                          <SelectItem value="active">نشط</SelectItem>
                          <SelectItem value="inactive">غير نشط</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-44">
                      <Label className="text-xs text-gray-500 mb-1 block">حالة المخزون</Label>
                      <Select value={stockFilter} onValueChange={setStockFilter}>
                        <SelectTrigger className="text-right"><SelectValue placeholder="الكل" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">الكل</SelectItem>
                          <SelectItem value="low">تحت الحد</SelectItem>
                          <SelectItem value="near">قرب الحد</SelectItem>
                          <SelectItem value="ok">متوفر</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border border-gray-200 dark:border-gray-700 overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                  <TableHead className="text-right font-semibold text-xs">SKU</TableHead>
                  <TableHead className="text-right font-semibold text-xs">اسم المنتج</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الفئة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الوحدة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">المخزون</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الحد الأدنى</TableHead>
                  <TableHead className="text-right font-semibold text-xs">السعر</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الحالة</TableHead>
                  <TableHead className="text-center font-semibold text-xs">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.map((p) => {
                  const stockPct = Math.min(100, (p.stock / p.maxStock) * 100);
                  const isLow = p.stock < p.minStock;
                  const isNear = p.stock >= p.minStock && p.stock <= p.minStock * 1.5;
                  const barColor = isLow ? 'bg-red-500' : isNear ? 'bg-amber-500' : 'bg-green-500';
                  return (
                    <TableRow key={p.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                      <TableCell className="font-mono text-[11px] text-gray-500">{p.sku}</TableCell>
                      <TableCell className="text-sm font-medium">{p.name}</TableCell>
                      <TableCell><Badge variant="outline" className="text-[10px]">{p.category}</Badge></TableCell>
                      <TableCell className="text-xs text-gray-500">{p.unit}</TableCell>
                      <TableCell className="min-w-[120px]">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold tabular-nums">{p.stock.toLocaleString('ar-EG')}</span>
                          <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div className={cn('h-full rounded-full transition-all', barColor)} style={{ width: `${stockPct}%` }} />
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs text-gray-500">{p.minStock.toLocaleString('ar-EG')}</TableCell>
                      <TableCell className="text-sm font-semibold text-[#0a4a30]">{formatEGP(p.price)}</TableCell>
                      <TableCell>
                        <Badge className={cn('text-[10px] border-0', p.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600')}>
                          {p.status === 'active' ? 'نشط' : 'غير نشط'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600" onClick={() => setViewProduct(p)}>
                            <Eye size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600" onClick={() => setEditProduct(p)}>
                            <Edit3 size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => deleteProduct(p.id)}>
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {paged.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-12 text-gray-400">
                      لا توجد منتجات مطابقة للبحث
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {/* Pagination */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 dark:border-gray-700">
            <span className="text-xs text-gray-500">
              عرض {filtered.length > 0 ? (page - 1) * pageSize + 1 : 0} - {Math.min(page * pageSize, filtered.length)} من {filtered.length}
            </span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(1)}>الأولى</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(page - 1)}>السابق</Button>
              <span className="text-xs px-2">{page} / {totalPages}</span>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(page + 1)}>التالي</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(totalPages)}>الأخيرة</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* View Product Dialog */}
      <Dialog open={!!viewProduct} onOpenChange={() => setViewProduct(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-right text-lg flex items-center gap-2">
              <Package size={20} className="text-[#0a4a30]" />
              {viewProduct?.name}
            </DialogTitle>
          </DialogHeader>
          {viewProduct && (
            <div className="space-y-3" dir="rtl">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <span className="text-gray-500 text-xs block">SKU</span>
                  <span className="font-mono font-semibold">{viewProduct.sku}</span>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <span className="text-gray-500 text-xs block">الباركود</span>
                  <span className="font-mono font-semibold">{viewProduct.barcode}</span>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <span className="text-gray-500 text-xs block">الفئة</span>
                  <span className="font-semibold">{viewProduct.category}</span>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <span className="text-gray-500 text-xs block">الوحدة</span>
                  <span className="font-semibold">{viewProduct.unit}</span>
                </div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <span className="text-gray-500 text-xs block mb-1">الوصف</span>
                <p className="text-sm">{viewProduct.description}</p>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-green-50 p-3 rounded-lg text-center">
                  <span className="text-gray-500 text-xs block">المخزون</span>
                  <span className="text-lg font-bold text-green-700">{viewProduct.stock}</span>
                </div>
                <div className="bg-amber-50 p-3 rounded-lg text-center">
                  <span className="text-gray-500 text-xs block">الحد الأدنى</span>
                  <span className="text-lg font-bold text-amber-700">{viewProduct.minStock}</span>
                </div>
                <div className="bg-blue-50 p-3 rounded-lg text-center">
                  <span className="text-gray-500 text-xs block">السعر</span>
                  <span className="text-lg font-bold text-blue-700">{formatEGP(viewProduct.price)}</span>
                </div>
              </div>
              <StockBar product={viewProduct} />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Product Dialog */}
      <Dialog open={!!editProduct} onOpenChange={() => setEditProduct(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-right text-lg">تعديل المنتج</DialogTitle>
          </DialogHeader>
          {editProduct && <ProductForm product={editProduct} onSave={saveProduct} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ──────────────────────────── Stock Bar ──────────────────────────── */

function StockBar({ product }: { product: Product }) {
  const pct = Math.min(100, Math.max(0, (product.stock / product.maxStock) * 100));
  const isLow = product.stock < product.minStock;
  const isNear = product.stock >= product.minStock && product.stock <= product.minStock * 1.5;
  const color = isLow ? 'bg-red-500' : isNear ? 'bg-amber-500' : 'bg-green-500';
  const label = isLow ? 'مخزون منخفض' : isNear ? 'قرب الحد الأدنى' : 'مخزون جيد';

  return (
    <div className="bg-gray-50 p-3 rounded-lg">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-gray-500">نسبة المخزون</span>
        <span className={cn('text-xs font-semibold', isLow ? 'text-red-600' : isNear ? 'text-amber-600' : 'text-green-600')}>
          {label} ({Math.round(pct)}%)
        </span>
      </div>
      <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.5 }}
          className={cn('h-full rounded-full', color)}
        />
      </div>
      <div className="flex justify-between mt-1 text-[10px] text-gray-400">
        <span>0</span>
        <span>{product.maxStock.toLocaleString('ar-EG')}</span>
      </div>
    </div>
  );
}

/* ──────────────────────────── Product Form ──────────────────────────── */

function ProductForm({ product, onSave }: { product: Product | null; onSave: (p: Product) => void }) {
  const [name, setName] = useState(product?.name || '');
  const [sku, setSku] = useState(product?.sku || '');
  const [category, setCategory] = useState(product?.category || '');
  const [unit, setUnit] = useState(product?.unit || '');
  const [stock, setStock] = useState(product?.stock || 0);
  const [minStock, setMinStock] = useState(product?.minStock || 0);
  const [maxStock, setMaxStock] = useState(product?.maxStock || 500);
  const [price, setPrice] = useState(product?.price || 0);
  const [barcode, setBarcode] = useState(product?.barcode || '');
  const [description, setDescription] = useState(product?.description || '');
  const [status, setStatus] = useState<'active' | 'inactive'>(product?.status || 'active');

  const handleSubmit = () => {
    onSave({
      id: product?.id || Date.now().toString(),
      sku,
      name: name || 'منتج جديد',
      category,
      unit,
      stock: Number(stock),
      minStock: Number(minStock),
      maxStock: Number(maxStock),
      price: Number(price),
      barcode,
      description,
      status,
    });
  };

  return (
    <div className="space-y-3" dir="rtl">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">اسم المنتج *</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="اسم المنتج" className="text-right" />
        </div>
        <div>
          <Label className="text-xs">SKU *</Label>
          <Input value={sku} onChange={(e) => setSku(e.target.value)} placeholder="كود المنتج" className="text-right font-mono" />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">الفئة</Label>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر الفئة" /></SelectTrigger>
            <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">الوحدة</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر الوحدة" /></SelectTrigger>
            <SelectContent>{UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div>
          <Label className="text-xs">المخزون الحالي</Label>
          <Input type="number" value={stock} onChange={(e) => setStock(parseFloat(e.target.value) || 0)} className="text-center" />
        </div>
        <div>
          <Label className="text-xs">الحد الأدنى</Label>
          <Input type="number" value={minStock} onChange={(e) => setMinStock(parseFloat(e.target.value) || 0)} className="text-center" />
        </div>
        <div>
          <Label className="text-xs">الحد الأقصى</Label>
          <Input type="number" value={maxStock} onChange={(e) => setMaxStock(parseFloat(e.target.value) || 0)} className="text-center" />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">السعر</Label>
          <Input type="number" value={price} onChange={(e) => setPrice(parseFloat(e.target.value) || 0)} className="text-center" placeholder="0.00" />
        </div>
        <div>
          <Label className="text-xs">الباركود</Label>
          <Input value={barcode} onChange={(e) => setBarcode(e.target.value)} className="text-right font-mono text-xs" placeholder="6287..." />
        </div>
      </div>
      <div>
        <Label className="text-xs">الوصف</Label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} className="w-full border rounded-md p-2 text-xs text-right min-h-[60px]" placeholder="وصف المنتج..." />
      </div>
      <div>
        <Label className="text-xs">الحالة</Label>
        <Select value={status} onValueChange={(v) => setStatus(v as 'active' | 'inactive')}>
          <SelectTrigger className="text-right"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="active">نشط</SelectItem>
            <SelectItem value="inactive">غير نشط</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button onClick={handleSubmit} className="w-full bg-[#0a4a30] hover:bg-[#0d6b43] text-white">
        {product ? 'حفظ التعديلات' : 'إضافة المنتج'}
      </Button>
    </div>
  );
}
