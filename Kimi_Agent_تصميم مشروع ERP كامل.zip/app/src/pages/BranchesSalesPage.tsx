import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  TrendingUp, Trophy, Target, Plus, X, TrendingDown, Medal, Award, Crown,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

// ─── Mock Data ──────────────────────────────────────────
const branchSalesData = [
  { branch: 'القاهرة', monthlySales: 3200000, target: 3000000, achievement: 106.7, growth: 8.5, profit: 850000, color: '#14a86a' },
  { branch: 'الإسكندرية', monthlySales: 2100000, target: 2200000, achievement: 95.5, growth: -2.3, profit: 520000, color: '#3b82f6' },
  { branch: 'طنطا', monthlySales: 1800000, target: 1700000, achievement: 105.9, growth: 12.1, profit: 480000, color: '#daa520' },
  { branch: 'المنصورة', monthlySales: 1450000, target: 1500000, achievement: 96.7, growth: 3.8, profit: 350000, color: '#8b5cf6' },
];

const monthlyTrend = [
  { month: 'سبتمبر', القاهرة: 2900000, الإسكندرية: 2200000, طنطا: 1600000, المنصورة: 1400000 },
  { month: 'أكتوبر', القاهرة: 3000000, الإسكندرية: 2150000, طنطا: 1650000, المنصورة: 1380000 },
  { month: 'نوفمبر', القاهرة: 3100000, الإسكندرية: 2180000, طنطا: 1700000, المنصورة: 1420000 },
  { month: 'ديسمبر', القاهرة: 2950000, الإسكندرية: 2050000, طنطا: 1620000, المنصورة: 1390000 },
  { month: 'يناير', القاهرة: 3200000, الإسكندرية: 2100000, طنطا: 1800000, المنصورة: 1450000 },
];

const productMixData = [
  { branch: 'القاهرة', data: [{ name: 'أعلاف دواجن', value: 45 }, { name: 'أعلاف مواشي', value: 30 }, { name: 'مواد خام', value: 20 }, { name: 'بقوليات', value: 5 }] },
  { branch: 'الإسكندرية', data: [{ name: 'أعلاف دواجن', value: 50 }, { name: 'أعلاف مواشي', value: 25 }, { name: 'مواد خام', value: 15 }, { name: 'بقوليات', value: 10 }] },
  { branch: 'طنطا', data: [{ name: 'أعلاف دواجن', value: 35 }, { name: 'أعلاف مواشي', value: 40 }, { name: 'مواد خام', value: 15 }, { name: 'بقوليات', value: 10 }] },
  { branch: 'المنصورة', data: [{ name: 'أعلاف دواجن', value: 40 }, { name: 'أعلاف مواشي', value: 35 }, { name: 'مواد خام', value: 15 }, { name: 'بقوليات', value: 10 }] },
];

const pieColors = ['#14a86a', '#daa520', '#3b82f6', '#8b5cf6'];

export default function BranchesSalesPage() {
  const [showTargetForm, setShowTargetForm] = useState(false);
  const [selectedBranchTab, setSelectedBranchTab] = useState(0);

  const totalSales = branchSalesData.reduce((s, b) => s + b.monthlySales, 0);
  const bestBranch = branchSalesData.reduce((best, b) => b.monthlySales > best.monthlySales ? b : best, branchSalesData[0]);
  const worstBranch = branchSalesData.reduce((worst, b) => b.monthlySales < worst.monthlySales ? b : worst, branchSalesData[0]);
  const avgBranch = Math.round(totalSales / branchSalesData.length);

  // Ranking with medals
  const ranked = [...branchSalesData].sort((a, b) => b.monthlySales - a.monthlySales);
  const medalColors = ['text-gold-500', 'text-gray-400', 'text-orange-400', 'text-gray-300'];
  const medalBg = ['bg-gold-50 dark:bg-gold-900/20', 'bg-gray-50 dark:bg-gray-800', 'bg-orange-50 dark:bg-orange-900/20', 'bg-gray-50 dark:bg-gray-800'];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="مقارنة مبيعات الفروع"
        subtitle="تحليل ومقارنة أداء مبيعات الفروع"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الفروع', path: '/branches' },
          { label: 'المبيعات' },
        ]}
      >
        <button onClick={() => setShowTargetForm(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Target size={16} /> تحديد targets
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي المبيعات" value={`${(totalSales / 1000000).toFixed(1)} مليون`} icon={TrendingUp} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} change={5.2} />
        <KPICard title="أفضل فرع" value={bestBranch.branch} icon={Crown} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.1} />
        <KPICard title="أقل فرع" value={worstBranch.branch} icon={TrendingDown} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.2} />
        <KPICard title="متوسط الفرع" value={`${(avgBranch / 1000000).toFixed(1)} مليون`} icon={Award} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.3} />
      </div>

      {/* Ranking with Medals */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2"><Trophy size={18} className="text-gold-500" /> ترتيب الفروع</h3>
        </div>
        <div className="p-4 space-y-2">
          {ranked.map((branch, idx) => (
            <motion.div key={branch.branch} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: idx * 0.1 }}
              className={`flex items-center gap-4 p-3 rounded-lg ${medalBg[idx]}`}
            >
              <div className={`text-2xl font-bold ${medalColors[idx]} w-8 text-center`}>
                {idx === 0 && <Crown size={24} />}
                {idx === 1 && <Medal size={24} />}
                {idx === 2 && <Award size={24} />}
                {idx === 3 && <span className="text-lg">#4</span>}
              </div>
              <div className="flex-1"><p className="text-sm font-semibold text-textPrimary dark:text-darkText">{branch.branch}</p><p className="text-xs text-textMuted">الإنجاز: %{branch.achievement} · النمو: %{branch.growth}</p></div>
              <div className="text-left"><p className="text-sm font-bold text-green-700">{(branch.monthlySales / 1000000).toFixed(1)}M</p><p className="text-xs text-textMuted">هدف: {(branch.target / 1000000).toFixed(1)}M</p></div>
              <div className="w-24 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${Math.min(branch.achievement, 100)}%`, backgroundColor: branch.color }} />
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Branch Sales Comparison Bar Chart */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5">
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">مقارنة المبيعات والأهداف</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={branchSalesData.map(b => ({ name: b.branch, sales: b.monthlySales, target: b.target }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Legend />
              <Bar dataKey="sales" name="المبيعات" fill="#14a86a" radius={[4, 4, 0, 0]} />
              <Bar dataKey="target" name="الهدف" fill="#daa520" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Monthly Trend Line Chart */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5">
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">الاتجاه الشهري للمبيعات</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={monthlyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Legend />
              <Line type="monotone" dataKey="القاهرة" stroke="#14a86a" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="الإسكندرية" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="طنطا" stroke="#daa520" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="المنصورة" stroke="#8b5cf6" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Product Mix Pie Charts */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5">
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">مزيج المنتجات حسب الفرع</h3>
        <div className="flex gap-2 mb-4">
          {productMixData.map((p, idx) => (
            <button key={p.branch} onClick={() => setSelectedBranchTab(idx)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selectedBranchTab === idx ? 'bg-green-700 text-white' : 'bg-surface dark:bg-darkCard text-textSecondary hover:text-textPrimary'}`}>{p.branch}</button>
          ))}
        </div>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={productMixData[selectedBranchTab].data}
                cx="50%" cy="50%"
                outerRadius={80}
                innerRadius={50}
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {productMixData[selectedBranchTab].data.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Sales Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تفاصيل الأداء</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['الفرع', 'المبيعات الشهرية', 'الهدف', 'الإنجاز %', 'النمو %', 'الربح', 'الترتيب'].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ranked.map((row, idx) => (
                <motion.tr key={row.branch} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.branch}</td>
                  <td className="px-4 py-3 text-sm text-green-700 font-semibold">{row.monthlySales.toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.target.toLocaleString()}</td>
                  <td className="px-4 py-3 text-sm">
                    <span className={`font-semibold ${row.achievement >= 100 ? 'text-green-700' : 'text-red-600'}`}>%{row.achievement}</span>
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <span className={`font-semibold ${row.growth >= 0 ? 'text-green-700' : 'text-red-600'}`}>%{row.growth}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gold-600 font-semibold">{row.profit.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${idx === 0 ? 'bg-gold-100 text-gold-700' : idx === 1 ? 'bg-gray-100 text-gray-600' : idx === 2 ? 'bg-orange-100 text-orange-700' : 'bg-gray-50 text-gray-500'}`}>
                      {idx === 0 && <Crown size={12} />}
                      {idx + 1}
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Target Setting Modal */}
      <AnimatePresence>
        {showTargetForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowTargetForm(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تحديد targets الشهرية</h3>
                <button onClick={() => setShowTargetForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                {branchSalesData.map(b => (
                  <div key={b.branch} className="grid grid-cols-2 gap-3 items-center">
                    <span className="text-sm text-textPrimary dark:text-darkText font-medium">{b.branch}</span>
                    <input type="number" defaultValue={b.target} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                  </div>
                ))}
                <div><label className="block text-xs font-medium text-textSecondary mb-1">ملاحظات</label><textarea className="w-full h-16 px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm resize-none" /></div>
                <div className="flex justify-end gap-2 pt-2">
                  <button onClick={() => setShowTargetForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary">إلغاء</button>
                  <button onClick={() => setShowTargetForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800">حفظ Targets</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
