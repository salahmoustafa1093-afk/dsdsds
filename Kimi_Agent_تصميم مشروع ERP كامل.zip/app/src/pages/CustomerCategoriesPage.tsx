import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart3, Crown, UserCheck, User, UserPlus, UserX,
  Plus, X, Check, Tag, TrendingUp
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

const categories = [
  { id: 1, name: 'VIP', color: '#daa520', icon: Crown, criteria: 'أكثر من 50 طلب أو 500,000 ج.م', count: 8, avgOrder: 42000, totalSales: 1680000 },
  { id: 2, name: 'نشط', color: '#14a86a', icon: UserCheck, criteria: '20-50 طلب أو 200,000 ج.م', count: 23, avgOrder: 28000, totalSales: 6440000 },
  { id: 3, name: 'متوسط', color: '#3b82f6', icon: User, criteria: '5-20 طلب أو 50,000 ج.م', count: 45, avgOrder: 14500, totalSales: 3262500 },
  { id: 4, name: 'جديد', color: '#8b5cf6', icon: UserPlus, criteria: 'أقل من 5 طلبات', count: 32, avgOrder: 8500, totalSales: 272000 },
  { id: 5, name: 'متوقف', color: '#64748b', icon: UserX, criteria: 'لا طلبات من 6 أشهر', count: 15, avgOrder: 0, totalSales: 0 },
];

const performanceData = categories
  .filter((c) => c.totalSales > 0)
  .map((c) => ({ name: c.name, sales: c.totalSales, color: c.color }));

const customersForAssignment = [
  { id: 1, name: 'مؤسسة الريف', currentCategory: 'VIP', sales: 850000 },
  { id: 2, name: 'مزارع النور', currentCategory: 'نشط', sales: 420000 },
  { id: 3, name: 'شركة الدلتا', currentCategory: 'VIP', sales: 920000 },
  { id: 4, name: 'مؤسسة النيل', currentCategory: 'نشط', sales: 380000 },
  { id: 5, name: 'مزرعة الذهبية', currentCategory: 'متوسط', sales: 120000 },
];

export default function CustomerCategoriesPage() {
  const [showForm, setShowForm] = useState(false);
  const [assignMode, setAssignMode] = useState(false);
  const [selectedCustomers, setSelectedCustomers] = useState<number[]>([]);
  const [targetCategory, setTargetCategory] = useState('');

  const [formName, setFormName] = useState('');
  const [formColor, setFormColor] = useState('#14a86a');
  const [formMinOrders, setFormMinOrders] = useState('');
  const [formMinAmount, setFormMinAmount] = useState('');
  const [formFrequency, setFormFrequency] = useState('');

  const handleAddCategory = () => {
    setShowForm(false);
    setFormName('');
    setFormColor('#14a86a');
    setFormMinOrders('');
    setFormMinAmount('');
    setFormFrequency('');
  };

  const toggleCustomer = (id: number) => {
    setSelectedCustomers((prev) => prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]);
  };

  const handleBulkAssign = () => {
    setAssignMode(false);
    setSelectedCustomers([]);
    setTargetCategory('');
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="تصنيف العملاء"
        subtitle="فئات العملاء ومعايير التصنيف والأداء"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'العملاء', path: '/customers' },
          { label: 'التصنيف' },
        ]}
      >
        <button
          onClick={() => setAssignMode(!assignMode)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm font-medium text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard transition-colors"
        >
          <Tag size={16} />
          <span>{assignMode ? 'إنهاء' : 'تعيين الفئة'}</span>
        </button>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>فئة جديدة</span>
        </button>
      </PageHeader>

      {/* Category Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-11 h-11 rounded-full flex items-center justify-center" style={{ backgroundColor: `${cat.color}20` }}>
                <cat.icon size={22} style={{ color: cat.color }} />
              </div>
              <span className="text-2xl font-bold text-textPrimary dark:text-darkText">{cat.count}</span>
            </div>
            <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-1">{cat.name}</h4>
            <p className="text-xs text-textSecondary mb-3">{cat.criteria}</p>
            <div className="flex justify-between text-xs">
              <span className="text-textMuted">متوسط الطلب</span>
              <span className="font-medium text-textPrimary dark:text-darkText">{cat.avgOrder > 0 ? formatCurrency(cat.avgOrder) : '—'}</span>
            </div>
            <div className="flex justify-between text-xs mt-1">
              <span className="text-textMuted">إجمالي المبيعات</span>
              <span className="font-medium text-green-600">{cat.totalSales > 0 ? formatCurrency(cat.totalSales) : '—'}</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Performance Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <TrendingUp size={16} className="text-green-600" />
          أداء الفئات
        </h3>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={performanceData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="name" tick={{ fontSize: 12 }} />
            <YAxis tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} tick={{ fontSize: 12 }} />
            <Tooltip formatter={(value: number) => formatCurrency(value)} />
            <Bar dataKey="sales" name="المبيعات" radius={[4, 4, 0, 0]}>
              {performanceData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Assignment Mode */}
      {assignMode && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 dark:bg-amber-950/20 rounded-xl border border-amber-200 dark:border-amber-800 p-5"
        >
          <h3 className="text-sm font-semibold text-amber-700 dark:text-amber-400 mb-3">تعيين الفئة بالجملة</h3>
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <label className="text-xs text-textSecondary mb-1 block">الفئة المستهدفة</label>
              <select value={targetCategory} onChange={(e) => setTargetCategory(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkSurface text-textPrimary dark:text-darkText text-sm">
                <option value="">اختر الفئة</option>
                {categories.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
            </div>
            <button onClick={handleBulkAssign} disabled={!targetCategory || selectedCustomers.length === 0} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 disabled:opacity-50 text-white text-sm font-medium transition-colors">
              تعيين ({selectedCustomers.length})
            </button>
          </div>
        </motion.div>
      )}

      {/* Customers Table */}
      <DataTable
        title="تعيين العملاء للفئات"
        columns={[
          ...(assignMode ? [{ key: 'select', header: '', render: (row: Record<string, unknown>) => (
            <button
              onClick={() => toggleCustomer(row.id as number)}
              className={`w-5 h-5 rounded border-2 transition-colors ${
                selectedCustomers.includes(row.id as number)
                  ? 'bg-green-600 border-green-600'
                  : 'border-uiBorder dark:border-darkBorder'
              }`}
            >
              {selectedCustomers.includes(row.id as number) && <Check size={12} className="text-white" />}
            </button>
          )}] : []),
          { key: 'name', header: 'العميل', sortable: true },
          { key: 'currentCategory', header: 'الفئة الحالية', render: (row) => {
            const cat = categories.find((c) => c.name === row.currentCategory);
            return (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: `${cat?.color}20`, color: cat?.color }}>
                {cat?.icon && <cat.icon size={10} />}
                {row.currentCategory as string}
              </span>
            );
          }},
          { key: 'sales', header: 'المبيعات', sortable: true, render: (row) => <span className="font-medium">{formatCurrency(row.sales as number)}</span> },
        ]}
        data={customersForAssignment as unknown as Record<string, unknown>[]}
        pageSize={5}
      />

      {/* Categories Detail Table */}
      <DataTable
        title="تفاصيل الفئات"
        columns={[
          { key: 'name', header: 'الفئة', sortable: true },
          { key: 'criteria', header: 'المعيار', sortable: true },
          { key: 'count', header: 'العدد', sortable: true },
          { key: 'avgOrder', header: 'متوسط الطلب', render: (row) => <span>{(row.avgOrder as number) > 0 ? formatCurrency(row.avgOrder as number) : '—'}</span> },
          { key: 'totalSales', header: 'إجمالي المبيعات', render: (row) => <span className="font-medium text-green-600">{(row.totalSales as number) > 0 ? formatCurrency(row.totalSales as number) : '—'}</span> },
        ]}
        data={categories as unknown as Record<string, unknown>[]}
        pageSize={5}
      />

      {/* Add Category Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إضافة فئة جديدة</h3>
                <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">اسم الفئة</label>
                    <input value={formName} onChange={(e) => setFormName(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="اسم الفئة" />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">اللون</label>
                    <div className="flex gap-2 flex-wrap">
                      {['#14a86a', '#daa520', '#3b82f6', '#8b5cf6', '#ef4444', '#64748b'].map((c) => (
                        <button
                          key={c}
                          onClick={() => setFormColor(c)}
                          className={`w-8 h-8 rounded-full transition-transform ${formColor === c ? 'ring-2 ring-offset-2 ring-green-600 scale-110' : ''}`}
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الحد الأدنى للطلبات</label>
                    <input type="number" value={formMinOrders} onChange={(e) => setFormMinOrders(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="0" />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الحد الأدنى للمبلغ</label>
                    <input type="number" value={formMinAmount} onChange={(e) => setFormMinAmount(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="0" />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">التكرار (شهرياً)</label>
                    <input type="number" value={formFrequency} onChange={(e) => setFormFrequency(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="0" />
                  </div>
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إلغاء</button>
                <button onClick={handleAddCategory} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors flex items-center gap-1">
                  <Check size={14} />
                  حفظ
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}


