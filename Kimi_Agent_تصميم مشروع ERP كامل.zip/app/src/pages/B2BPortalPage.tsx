// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2,
  CreditCard,
  ShoppingCart,
  FileText,
  Receipt,
  ClipboardList,
  Wallet,
  Tag,
  Plus,
  X,
  CheckCircle2,
  Clock,
  Truck,
  PackageCheck,
  ChevronDown,
  Download,
  Search,
  TrendingUp,
  TrendingDown,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Star,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
interface B2BOrder {
  id: number;
  orderNumber: string;
  date: string;
  products: { name: string; qty: number; price: number; total: number }[];
  total: number;
  status: 'جديد' | 'قيد التجهيز' | 'تم الشحن' | 'تم التوصيل' | 'ملغي';
  deliveryDate: string;
  trackingSteps: { label: string; done: boolean; date?: string }[];
}

interface B2BInvoice {
  id: number;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  amount: number;
  paid: number;
  status: 'مسددة' | 'جزئي' | 'مستحقة';
}

interface StatementRow {
  id: number;
  date: string;
  type: 'فاتورة' | 'دفعة' | 'مردود';
  ref: string;
  debit: number;
  credit: number;
  balance: number;
}

interface Payment {
  id: number;
  date: string;
  amount: number;
  method: 'تحويل بنكي' | 'كاش' | 'شيك';
  reference: string;
}

interface PriceItem {
  id: number;
  product: string;
  unit: string;
  basePrice: number;
  yourPrice: number;
  discount: number;
  volumeDiscounts: { minQty: number; price: number }[];
}

/* ------------------------------------------------------------------ */
/*  MOCK DATA                                                          */
/* ------------------------------------------------------------------ */
const mockOrders: B2BOrder[] = [
  { id: 1, orderNumber: 'ORD-2024-089', date: '2024-01-18', products: [{ name: 'بيض طازج كبير', qty: 500, price: 95, total: 47500 }, { name: 'بيض متوسط', qty: 300, price: 85, total: 25500 }], total: 73000, status: 'تم التوصيل', deliveryDate: '2024-01-19', trackingSteps: [{ label: 'استلام الطلب', done: true, date: '2024-01-18' }, { label: 'التجهيز', done: true, date: '2024-01-18' }, { label: 'الشحن', done: true, date: '2024-01-19' }, { label: 'التوصيل', done: true, date: '2024-01-19' }] },
  { id: 2, orderNumber: 'ORD-2024-090', date: '2024-01-17', products: [{ name: 'بيض طازج كبير', qty: 1000, price: 92, total: 92000 }], total: 92000, status: 'تم الشحن', deliveryDate: '2024-01-20', trackingSteps: [{ label: 'استلام الطلب', done: true, date: '2024-01-17' }, { label: 'التجهيز', done: true, date: '2024-01-17' }, { label: 'الشحن', done: true, date: '2024-01-18' }, { label: 'التوصيل', done: false }] },
  { id: 3, orderNumber: 'ORD-2024-091', date: '2024-01-16', products: [{ name: 'بيض صغير', qty: 200, price: 78, total: 15600 }, { name: 'بيض كرتون 30 بيضة', qty: 100, price: 105, total: 10500 }], total: 26100, status: 'قيد التجهيز', deliveryDate: '2024-01-21', trackingSteps: [{ label: 'استلام الطلب', done: true, date: '2024-01-16' }, { label: 'التجهيز', done: true, date: '2024-01-18' }, { label: 'الشحن', done: false }, { label: 'التوصيل', done: false }] },
  { id: 4, orderNumber: 'ORD-2024-088', date: '2024-01-14', products: [{ name: 'بيض طازج كبير', qty: 800, price: 95, total: 76000 }], total: 76000, status: 'تم التوصيل', deliveryDate: '2024-01-15', trackingSteps: [{ label: 'استلام الطلب', done: true }, { label: 'التجهيز', done: true }, { label: 'الشحن', done: true }, { label: 'التوصيل', done: true }] },
  { id: 5, orderNumber: 'ORD-2024-087', date: '2024-01-12', products: [{ name: 'بيض متوسط', qty: 600, price: 88, total: 52800 }], total: 52800, status: 'تم التوصيل', deliveryDate: '2024-01-13', trackingSteps: [{ label: 'استلام الطلب', done: true }, { label: 'التجهيز', done: true }, { label: 'الشحن', done: true }, { label: 'التوصيل', done: true }] },
];

const mockInvoices: B2BInvoice[] = [
  { id: 1, invoiceNumber: 'INV-2024-152', date: '2024-01-18', dueDate: '2024-02-17', amount: 73000, paid: 73000, status: 'مسددة' },
  { id: 2, invoiceNumber: 'INV-2024-148', date: '2024-01-14', dueDate: '2024-02-13', amount: 76000, paid: 50000, status: 'جزئي' },
  { id: 3, invoiceNumber: 'INV-2024-145', date: '2024-01-10', dueDate: '2024-02-09', amount: 52800, paid: 52800, status: 'مسددة' },
  { id: 4, invoiceNumber: 'INV-2024-140', date: '2024-01-05', dueDate: '2024-02-04', amount: 125000, paid: 0, status: 'مستحقة' },
];

const mockStatements: StatementRow[] = [
  { id: 1, date: '2024-01-18', type: 'فاتورة', ref: 'INV-152', debit: 73000, credit: 0, balance: 125000 },
  { id: 2, date: '2024-01-15', type: 'دفعة', ref: 'PAY-89', debit: 0, credit: 45000, balance: 52000 },
  { id: 3, date: '2024-01-14', type: 'فاتورة', ref: 'INV-148', debit: 76000, credit: 0, balance: 97000 },
  { id: 4, date: '2024-01-10', type: 'دفعة', ref: 'PAY-85', debit: 0, credit: 50000, balance: 21000 },
  { id: 5, date: '2024-01-08', type: 'فاتورة', ref: 'INV-145', debit: 52800, credit: 0, balance: 71000 },
  { id: 6, date: '2024-01-05', type: 'فاتورة', ref: 'INV-140', debit: 125000, credit: 0, balance: 18200 },
  { id: 7, date: '2024-01-01', type: 'دفعة', ref: 'PAY-80', debit: 0, credit: 75000, balance: -106800 },
  { id: 8, date: '2023-12-28', type: 'فاتورة', ref: 'INV-135', debit: 98000, credit: 0, balance: -31800 },
];

const mockPayments: Payment[] = [
  { id: 1, date: '2024-01-15', amount: 45000, method: 'تحويل بنكي', reference: 'TRF-2024-015' },
  { id: 2, date: '2024-01-10', amount: 50000, method: 'تحويل بنكي', reference: 'TRF-2024-012' },
  { id: 3, date: '2024-01-01', amount: 75000, method: 'شيك', reference: 'CHK-2024-008' },
];

const mockPriceList: PriceItem[] = [
  { id: 1, product: 'بيض طازج كبير', unit: 'كرتونة (30 بيضة)', basePrice: 105, yourPrice: 95, discount: 9.5, volumeDiscounts: [{ minQty: 500, price: 92 }, { minQty: 1000, price: 88 }] },
  { id: 2, product: 'بيض متوسط', unit: 'كرتونة (30 بيضة)', basePrice: 95, yourPrice: 85, discount: 10.5, volumeDiscounts: [{ minQty: 500, price: 82 }, { minQty: 1000, price: 78 }] },
  { id: 3, product: 'بيض صغير', unit: 'كرتونة (30 بيضة)', basePrice: 88, yourPrice: 78, discount: 11.4, volumeDiscounts: [{ minQty: 300, price: 75 }, { minQty: 600, price: 72 }] },
  { id: 4, product: 'بيض كرتون 30 بيضة', unit: 'كرتون', basePrice: 120, yourPrice: 105, discount: 12.5, volumeDiscounts: [{ minQty: 100, price: 100 }, { minQty: 300, price: 95 }] },
];

/* ------------------------------------------------------------------ */
/*  CUSTOMER INFO                                                      */
/* ------------------------------------------------------------------ */
const customerInfo = {
  name: 'مزرعة النيل للدواجن',
  code: 'CUST-001',
  creditLimit: 500000,
  usedCredit: 125000,
  availableCredit: 375000,
  contact: 'أحمد عبدالله',
  phone: '01001234567',
  email: 'nile@farm.com',
  address: 'طريق مصر إسماعيلية الصحراوي',
  city: 'القاهرة',
};

/* ------------------------------------------------------------------ */
/*  HELPERS                                                            */
/* ------------------------------------------------------------------ */
function OrderStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    جديد: 'bg-blue-100 text-blue-700 border-blue-300',
    'قيد التجهيز': 'bg-amber-100 text-amber-700 border-amber-300',
    'تم الشحن': 'bg-cyan-100 text-cyan-700 border-cyan-300',
    'تم التوصيل': 'bg-green-100 text-green-700 border-green-300',
    ملغي: 'bg-red-100 text-red-700 border-red-300',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${styles[status] || ''}`}>
      {status}
    </span>
  );
}

function InvoiceStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    مسددة: 'bg-green-100 text-green-700 border-green-300',
    جزئي: 'bg-amber-100 text-amber-700 border-amber-300',
    مستحقة: 'bg-red-100 text-red-700 border-red-300',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${styles[status] || ''}`}>
      {status}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function B2BPortalPage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [orders, setOrders] = useState<B2BOrder[]>(mockOrders);
  const [payments, setPayments] = useState<Payment[]>(mockPayments);
  const [orderProducts, setOrderProducts] = useState([{ product: '', qty: 0 }]);
  const [orderDeliveryDate, setOrderDeliveryDate] = useState('');

  const creditPercent = (customerInfo.usedCredit / customerInfo.creditLimit) * 100;

  const tabs = [
    { key: 'dashboard', label: 'لوحة التحكم', icon: TrendingUp },
    { key: 'orders', label: 'الطلبات', icon: ShoppingCart },
    { key: 'invoices', label: 'الفواتير', icon: FileText },
    { key: 'statements', label: 'الكشوف', icon: ClipboardList },
    { key: 'payments', label: 'المدفوعات', icon: Wallet },
    { key: 'prices', label: 'قائمة الأسعار', icon: Tag },
  ];

  const addOrderProduct = () => setOrderProducts([...orderProducts, { product: '', qty: 0 }]);
  const removeOrderProduct = (i: number) => setOrderProducts(orderProducts.filter((_, idx) => idx !== i));
  const updateOrderProduct = (i: number, field: string, value: any) => {
    setOrderProducts((prev) => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: value };
      return next;
    });
  };

  const submitOrder = () => {
    const newId = Math.max(...orders.map((o) => o.id)) + 1;
    const products = orderProducts.filter((p) => p.product).map((p) => ({
      name: p.product,
      qty: p.qty,
      price: 95,
      total: p.qty * 95,
    }));
    const total = products.reduce((s, p) => s + p.total, 0);
    const newOrder: B2BOrder = {
      id: newId,
      orderNumber: `ORD-2024-${String(newId + 100).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      products,
      total,
      status: 'جديد',
      deliveryDate: orderDeliveryDate || new Date(Date.now() + 86400000).toISOString().split('T')[0],
      trackingSteps: [
        { label: 'استلام الطلب', done: true },
        { label: 'التجهيز', done: false },
        { label: 'الشحن', done: false },
        { label: 'التوصيل', done: false },
      ],
    };
    setOrders((prev) => [newOrder, ...prev]);
    setOrderModalOpen(false);
    setOrderProducts([{ product: '', qty: 0 }]);
  };

  const submitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const amount = +(form.elements.namedItem('amount') as HTMLInputElement).value;
    const method = (form.elements.namedItem('method') as HTMLSelectElement).value;
    const ref = (form.elements.namedItem('ref') as HTMLInputElement).value;
    const newPayment: Payment = {
      id: Math.max(...payments.map((p) => p.id)) + 1,
      date: new Date().toISOString().split('T')[0],
      amount,
      method: method as any,
      reference: ref,
    };
    setPayments((prev) => [newPayment, ...prev]);
    setPaymentModalOpen(false);
  };

  return (
    <div className="gff-page-transition space-y-6">
      {/* ── Customer Header ── */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <div className="flex flex-col lg:flex-row lg:items-center gap-4 lg:justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-green-700 flex items-center justify-center text-white font-bold text-xl">
              {customerInfo.name.charAt(0)}
            </div>
            <div>
              <h1 className="text-xl font-bold text-textPrimary dark:text-darkText">{customerInfo.name}</h1>
              <p className="text-sm text-textMuted">{customerInfo.code} · {customerInfo.contact}</p>
              <div className="flex items-center gap-3 mt-1 text-xs text-textSecondary">
                <span className="flex items-center gap-1"><Phone size={12} /> {customerInfo.phone}</span>
                <span className="flex items-center gap-1"><Mail size={12} /> {customerInfo.email}</span>
                <span className="flex items-center gap-1"><MapPin size={12} /> {customerInfo.city}</span>
              </div>
            </div>
          </div>

          {/* Credit Info */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="bg-surface dark:bg-darkCard rounded-lg p-3 min-w-[150px]">
              <p className="text-[11px] text-textMuted mb-0.5">الحد الائتماني</p>
              <p className="text-lg font-bold text-textPrimary dark:text-darkText">{customerInfo.creditLimit.toLocaleString('ar-EG')} ج.م</p>
            </div>
            <div className="bg-red-50 dark:bg-red-950/20 rounded-lg p-3 min-w-[150px] border border-red-200 dark:border-red-800">
              <p className="text-[11px] text-red-600 mb-0.5">المستخدم</p>
              <p className="text-lg font-bold text-red-700">{customerInfo.usedCredit.toLocaleString('ar-EG')} ج.م</p>
            </div>
            <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-3 min-w-[150px] border border-green-200 dark:border-green-800">
              <p className="text-[11px] text-green-600 mb-0.5">المتاح</p>
              <p className="text-lg font-bold text-green-700">{customerInfo.availableCredit.toLocaleString('ar-EG')} ج.م</p>
            </div>
          </div>
        </div>

        {/* Credit Bar */}
        <div className="mt-4">
          <div className="w-full h-3 bg-gray-200 dark:bg-darkBorder rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${creditPercent}%` }}
              transition={{ duration: 0.5 }}
              className={`h-full rounded-full ${creditPercent > 80 ? 'bg-red-500' : creditPercent > 50 ? 'bg-amber-500' : 'bg-green-500'}`}
            />
          </div>
          <p className="text-[11px] text-textMuted mt-1">تم استهلاك {Math.round(creditPercent)}% من الحد الائتماني</p>
        </div>
      </motion.div>

      {/* ── KPIs ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="الطلبات النشطة" value={orders.filter((o) => o.status !== 'تم التوصيل' && o.status !== 'ملغي').length.toLocaleString('ar-EG')} icon={ShoppingCart} iconBg="bg-blue-50" iconColor="text-blue-600" delay={0} />
        <KPICard title="الفواتير المستحقة" value={`${mockInvoices.filter((i) => i.status === 'مستحقة' || i.status === 'جزئي').length}`} icon={Receipt} iconBg="bg-red-50" iconColor="text-red-600" delay={0.05} />
        <KPICard title="آخر طلب" value={orders[0]?.orderNumber || '-'} icon={PackageCheck} iconBg="bg-green-50" iconColor="text-green-600" delay={0.1} />
        <KPICard title="المتاح" value={`${customerInfo.availableCredit.toLocaleString('ar-EG')} ج.م`} icon={CreditCard} iconBg="bg-purple-50" iconColor="text-purple-600" delay={0.15} />
      </div>

      {/* ── Tabs ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card"
      >
        <div className="flex items-center border-b border-uiBorder dark:border-darkBorder overflow-x-auto">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === t.key
                  ? 'border-green-700 text-green-700'
                  : 'border-transparent text-textSecondary hover:text-textPrimary'
              }`}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>

        <div className="p-6">
          {/* ══════════ DASHBOARD ══════════ */}
          {activeTab === 'dashboard' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-surface dark:bg-darkCard rounded-xl p-5 border border-uiBorder dark:border-darkBorder">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">آخر الطلبات</h4>
                  <div className="space-y-3">
                    {orders.slice(0, 4).map((o) => (
                      <div key={o.id} className="flex items-center justify-between py-2 border-b border-uiBorder/50 last:border-0">
                        <div>
                          <p className="text-sm font-medium text-textPrimary dark:text-darkText">{o.orderNumber}</p>
                          <p className="text-[11px] text-textMuted">{o.date} · {o.products.length} منتج</p>
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-semibold text-textPrimary dark:text-darkText">{o.total.toLocaleString('ar-EG')} ج.م</p>
                          <OrderStatusBadge status={o.status} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-surface dark:bg-darkCard rounded-xl p-5 border border-uiBorder dark:border-darkBorder">
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">الفواتير المستحقة</h4>
                  <div className="space-y-3">
                    {mockInvoices.filter((i) => i.status !== 'مسددة').map((inv) => (
                      <div key={inv.id} className="flex items-center justify-between py-2 border-b border-uiBorder/50 last:border-0">
                        <div>
                          <p className="text-sm font-medium text-textPrimary dark:text-darkText">{inv.invoiceNumber}</p>
                          <p className="text-[11px] text-textMuted">استحقاق: {inv.dueDate}</p>
                        </div>
                        <div className="text-left">
                          <p className="text-sm font-semibold text-textPrimary dark:text-darkText">{inv.amount.toLocaleString('ar-EG')} ج.م</p>
                          <InvoiceStatusBadge status={inv.status} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ══════════ ORDERS ══════════ */}
          {activeTab === 'orders' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">الطلبات</h3>
                <button onClick={() => setOrderModalOpen(true)} className="inline-flex items-center gap-2 px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors">
                  <Plus size={16} /> طلب جديد
                </button>
              </div>
              <div className="space-y-3">
                {orders.map((o) => (
                  <motion.div
                    key={o.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-surface dark:bg-darkCard rounded-xl border border-uiBorder dark:border-darkBorder p-4"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <span className="text-sm font-semibold text-textPrimary dark:text-darkText">{o.orderNumber}</span>
                        <span className="text-xs text-textMuted mr-2">{o.date}</span>
                      </div>
                      <OrderStatusBadge status={o.status} />
                    </div>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {o.products.map((p, i) => (
                        <span key={i} className="text-xs bg-white dark:bg-darkSurface px-2 py-1 rounded border border-uiBorder dark:border-darkBorder">
                          {p.name} × {p.qty}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-xs text-textMuted">
                        <Calendar size={12} /> توصيل: {o.deliveryDate}
                      </div>
                      <span className="text-sm font-bold text-textPrimary dark:text-darkText">{o.total.toLocaleString('ar-EG')} ج.م</span>
                    </div>
                    {/* Tracking */}
                    <div className="mt-3 flex items-center gap-2">
                      {o.trackingSteps.map((step, i) => (
                        <div key={i} className="flex items-center gap-1">
                          <div className={`w-2 h-2 rounded-full ${step.done ? 'bg-green-500' : 'bg-gray-300'}`} />
                          <span className={`text-[10px] ${step.done ? 'text-green-600 font-medium' : 'text-gray-400'}`}>{step.label}</span>
                          {i < o.trackingSteps.length - 1 && <div className={`w-4 h-0.5 ${step.done ? 'bg-green-400' : 'bg-gray-200'}`} />}
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* ══════════ INVOICES ══════════ */}
          {activeTab === 'invoices' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-3">الفواتير</h3>
              <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">رقم الفاتورة</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">تاريخ الاستحقاق</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">المبلغ</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">المدفوع</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">الحالة</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">تحميل</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockInvoices.map((inv) => (
                      <tr key={inv.id} className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-surface dark:hover:bg-darkCard/50 transition-colors">
                        <td className="px-3 py-2.5 font-medium text-textPrimary dark:text-darkText">{inv.invoiceNumber}</td>
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{inv.date}</td>
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{inv.dueDate}</td>
                        <td className="px-3 py-2.5 font-medium text-textPrimary dark:text-darkText">{inv.amount.toLocaleString('ar-EG')}</td>
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{inv.paid.toLocaleString('ar-EG')}</td>
                        <td className="px-3 py-2.5"><InvoiceStatusBadge status={inv.status} /></td>
                        <td className="px-3 py-2.5">
                          <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors">
                            <Download size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* ══════════ STATEMENTS ══════════ */}
          {activeTab === 'statements' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-3">كشف الحساب</h3>
              <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">النوع</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">المرجع</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">مدين</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">دائن</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">الرصيد</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockStatements.map((s) => (
                      <tr key={s.id} className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-surface dark:hover:bg-darkCard/50 transition-colors">
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{s.date}</td>
                        <td className="px-3 py-2.5">
                          <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${
                            s.type === 'فاتورة' ? 'bg-blue-100 text-blue-700' : s.type === 'دفعة' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                          }`}>{s.type}</span>
                        </td>
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{s.ref}</td>
                        <td className="px-3 py-2.5 text-red-600 font-medium">{s.debit > 0 ? s.debit.toLocaleString('ar-EG') : '-'}</td>
                        <td className="px-3 py-2.5 text-green-600 font-medium">{s.credit > 0 ? s.credit.toLocaleString('ar-EG') : '-'}</td>
                        <td className={`px-3 py-2.5 font-semibold ${s.balance >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                          {Math.abs(s.balance).toLocaleString('ar-EG')} {s.balance >= 0 ? 'مدين' : 'دائن'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* ══════════ PAYMENTS ══════════ */}
          {activeTab === 'payments' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">سجل المدفوعات</h3>
                <button onClick={() => setPaymentModalOpen(true)} className="inline-flex items-center gap-2 px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors">
                  <Plus size={16} /> سداد
                </button>
              </div>
              <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">المبلغ</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">الطريقة</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">المرجع</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map((p) => (
                      <tr key={p.id} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{p.date}</td>
                        <td className="px-3 py-2.5 font-medium text-green-600">{p.amount.toLocaleString('ar-EG')} ج.م</td>
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{p.method}</td>
                        <td className="px-3 py-2.5 text-textSecondary">{p.reference}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* ══════════ PRICE LIST ══════════ */}
          {activeTab === 'prices' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-3">قائمة الأسعار الخاصة بك</h3>
              <div className="space-y-4">
                {mockPriceList.map((item) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-surface dark:bg-darkCard rounded-xl border border-uiBorder dark:border-darkBorder p-4"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
                      <div>
                        <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{item.product}</h4>
                        <p className="text-xs text-textMuted">{item.unit}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-center">
                          <p className="text-[11px] text-textMuted line-through">{item.basePrice} ج.م</p>
                          <p className="text-lg font-bold text-green-700">{item.yourPrice} ج.م</p>
                        </div>
                        <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          خصم {item.discount}%
                        </span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-lg p-3 border border-uiBorder dark:border-darkBorder">
                      <p className="text-xs text-textSecondary mb-2">خصومات الكمية</p>
                      <div className="flex gap-3">
                        {item.volumeDiscounts.map((vd, i) => (
                          <div key={i} className="flex items-center gap-2 bg-green-50 dark:bg-green-950/20 rounded-lg px-3 py-1.5">
                            <span className="text-xs text-green-700 font-medium">{vd.minQty}+</span>
                            <span className="text-xs text-green-600">{vd.price} ج.م</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>

      {/* ═══════════════════ CREATE ORDER MODAL ═══════════════════ */}
      <AnimatePresence>
        {orderModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">طلب جديد</h3>
                <button onClick={() => setOrderModalOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">تاريخ التوصيل المتوقع</label>
                  <input type="date" value={orderDeliveryDate} onChange={(e) => setOrderDeliveryDate(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-medium text-textSecondary">المنتجات</label>
                    <button onClick={addOrderProduct} className="text-xs text-green-700 hover:text-green-800 font-medium flex items-center gap-1">
                      <Plus size={14} /> إضافة منتج
                    </button>
                  </div>
                  <div className="space-y-2">
                    {orderProducts.map((p, i) => (
                      <div key={i} className="grid grid-cols-12 gap-2 items-center bg-surface dark:bg-darkCard rounded-lg p-2">
                        <div className="col-span-7">
                          <select value={p.product} onChange={(e) => updateOrderProduct(i, 'product', e.target.value)} className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
                            <option value="">اختر المنتج</option>
                            <option value="بيض طازج كبير">بيض طازج كبير</option>
                            <option value="بيض متوسط">بيض متوسط</option>
                            <option value="بيض صغير">بيض صغير</option>
                            <option value="بيض كرتون 30 بيضة">بيض كرتون 30 بيضة</option>
                          </select>
                        </div>
                        <div className="col-span-3">
                          <input type="number" value={p.qty || ''} onChange={(e) => updateOrderProduct(i, 'qty', +e.target.value)} placeholder="الكمية" className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm" />
                        </div>
                        <div className="col-span-2">
                          {orderProducts.length > 1 && (
                            <button onClick={() => removeOrderProduct(i)} className="w-8 h-8 rounded flex items-center justify-center text-red-500 hover:bg-red-50">
                              <X size={14} />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-uiBorder dark:border-darkBorder">
                <button onClick={() => setOrderModalOpen(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm">إلغاء</button>
                <button onClick={submitOrder} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">إرسال الطلب</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════════════ PAYMENT MODAL ═══════════════════ */}
      <AnimatePresence>
        {paymentModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">سداد</h3>
                <button onClick={() => setPaymentModalOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>
              <form onSubmit={submitPayment} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">المبلغ (ج.م)</label>
                  <input type="number" name="amount" required className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">طريقة الدفع</label>
                  <select name="method" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
                    <option value="تحويل بنكي">تحويل بنكي</option>
                    <option value="كاش">كاش</option>
                    <option value="شيك">شيك</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">رقم المرجع</label>
                  <input type="text" name="ref" placeholder="رقم التحويل أو الشيك" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-uiBorder dark:border-darkBorder">
                  <button type="button" onClick={() => setPaymentModalOpen(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm">إلغاء</button>
                  <button type="submit" className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">تأكيد السداد</button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
