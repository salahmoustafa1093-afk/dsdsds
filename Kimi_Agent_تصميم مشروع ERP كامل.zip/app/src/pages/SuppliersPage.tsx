// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Truck,
  UserCheck,
  ShoppingCart,
  Wallet,
  Search,
  Plus,
  X,
  Eye,
  Edit3,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Star,
  StarOff,
  Building2,
  Package,
  Factory,
  Warehouse,
  Sprout,
  ThumbsUp,
  ThumbsDown,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
interface Supplier {
  id: number;
  code: string;
  name: string;
  category: 'أعلاف' | 'أدوية بيطرية' | 'كتكوت' | 'تعبئة' | 'معدات';
  phone: string;
  email: string;
  address: string;
  city: string;
  taxNumber: string;
  totalPurchases: number;
  balance: number;
  rating: number;
  status: 'نشط' | 'متوقف';
  commercialTerms: string;
  notes: string;
  joinDate: string;
  purchaseHistory: { date: string; product: string; qty: number; amount: number }[];
  evaluation: { quality: number; price: number; delivery: number; service: number };
}

/* ------------------------------------------------------------------ */
/*  MOCK DATA                                                          */
/* ------------------------------------------------------------------ */
const mockSuppliers: Supplier[] = [
  { id: 1, code: 'SUP-001', name: 'شركة الدلتا للأعلاف', category: 'أعلاف', phone: '01001234567', email: 'delta@feed.com', address: 'المنطقة الصناعية', city: 'القاهرة', taxNumber: '401-223-556', totalPurchases: 4850000, balance: 320000, rating: 5, status: 'نشط', commercialTerms: '30 يوم', notes: 'مورد رئيسي للأعلاف', joinDate: '2021-02-10', purchaseHistory: [{ date: '2024-01-15', product: 'علف ناهي', qty: 50, amount: 125000 }, { date: '2024-01-01', product: 'علف بادي', qty: 30, amount: 75000 }], evaluation: { quality: 5, price: 4, delivery: 5, service: 4 } },
  { id: 2, code: 'SUP-002', name: 'مصنع الشرق للأدوية البيطرية', category: 'أدوية بيطرية', phone: '01002345678', email: 'east@vaccine.com', address: 'مدينة العبور', city: 'القليوبية', taxNumber: '402-334-667', totalPurchases: 2100000, balance: 145000, rating: 4, status: 'نشط', commercialTerms: 'نقدي', notes: '', joinDate: '2021-08-22', purchaseHistory: [{ date: '2024-01-12', product: 'لقاح إن بي', qty: 5000, amount: 45000 }, { date: '2024-01-05', product: 'مضاد حيوي', qty: 200, amount: 30000 }], evaluation: { quality: 4, price: 3, delivery: 4, service: 5 } },
  { id: 3, code: 'SUP-003', name: 'مزارع الغرب لإنتاج الكتكوت', category: 'كتكوت', phone: '01003456789', email: 'west@chick.com', address: 'كفر الشيخ', city: 'كفر الشيخ', taxNumber: '403-445-778', totalPurchases: 3600000, balance: 280000, rating: 5, status: 'نشط', commercialTerms: '15 يوم', notes: 'مورد كتاكيت معتمد', joinDate: '2021-05-15', purchaseHistory: [{ date: '2024-01-14', product: 'كتكوت أبيض', qty: 20000, amount: 180000 }, { date: '2024-01-03', product: 'كتكوت ساسو', qty: 5000, amount: 50000 }], evaluation: { quality: 5, price: 4, delivery: 5, service: 5 } },
  { id: 4, code: 'SUP-004', name: 'إنتاج الوادي للتعبئة', category: 'تعبئة', phone: '01004567890', email: 'wadi@pack.com', address: 'المنصورة', city: 'الدقهلية', taxNumber: '404-556-889', totalPurchases: 1200000, balance: 95000, rating: 4, status: 'نشط', commercialTerms: '30 يوم', notes: '', joinDate: '2022-03-01', purchaseHistory: [{ date: '2024-01-10', product: 'كرتون بيض', qty: 10000, amount: 35000 }], evaluation: { quality: 4, price: 5, delivery: 3, service: 4 } },
  { id: 5, code: 'SUP-005', name: 'شركة النيل للمعدات', category: 'معدات', phone: '01005678901', email: 'nile@equip.com', address: 'القاهرة', city: 'القاهرة', taxNumber: '405-667-990', totalPurchases: 890000, balance: 0, rating: 3, status: 'نشط', commercialTerms: 'نقدي', notes: '', joinDate: '2023-01-10', purchaseHistory: [{ date: '2024-01-08', product: 'منافذ تغذية', qty: 50, amount: 25000 }], evaluation: { quality: 3, price: 3, delivery: 3, service: 3 } },
  { id: 6, code: 'SUP-006', name: 'مزارع الصعيد للأعلاف', category: 'أعلاف', phone: '01006789012', email: 'saida@feed.com', address: 'أسيوط', city: 'أسيوط', taxNumber: '406-778-001', totalPurchases: 1950000, balance: 125000, rating: 4, status: 'نشط', commercialTerms: '45 يوم', notes: '', joinDate: '2022-06-18', purchaseHistory: [{ date: '2024-01-11', product: 'علف ناهي', qty: 25, amount: 62500 }], evaluation: { quality: 4, price: 5, delivery: 3, service: 4 } },
  { id: 7, code: 'SUP-007', name: 'مصنع الفارما بيطري', category: 'أدوية بيطرية', phone: '01007890123', email: 'pharma@vet.com', address: 'العاشر من رمضان', city: 'الشرقية', taxNumber: '407-889-112', totalPurchases: 1560000, balance: 88000, rating: 5, status: 'نشط', commercialTerms: '30 يوم', notes: 'مورد ممتاز', joinDate: '2022-02-28', purchaseHistory: [{ date: '2024-01-13', product: 'فيتامينات', qty: 100, amount: 28000 }], evaluation: { quality: 5, price: 4, delivery: 5, service: 5 } },
  { id: 8, code: 'SUP-008', name: 'شركة الأمل لإنتاج الكتكوت', category: 'كتكوت', phone: '01008901234', email: 'amal@chick.com', address: 'الإسكندرية', city: 'الإسكندرية', taxNumber: '408-990-223', totalPurchases: 2700000, balance: 195000, rating: 4, status: 'نشط', commercialTerms: '30 يوم', notes: '', joinDate: '2021-10-05', purchaseHistory: [{ date: '2024-01-09', product: 'كتكوت أبيض', qty: 15000, amount: 135000 }], evaluation: { quality: 4, price: 4, delivery: 4, service: 4 } },
  { id: 9, code: 'SUP-009', name: 'مؤسسة البركة للتعبئة', category: 'تعبئة', phone: '01009012345', email: 'baraka@pack.com', address: 'طنطا', city: 'الغربية', taxNumber: '409-001-334', totalPurchases: 750000, balance: 0, rating: 3, status: 'متوقف', commercialTerms: 'نقدي', notes: 'متوقف مؤقتاً', joinDate: '2023-04-20', purchaseHistory: [], evaluation: { quality: 3, price: 3, delivery: 2, service: 3 } },
  { id: 10, code: 'SUP-010', name: 'شركة التقنية للمعدات', category: 'معدات', phone: '01010123456', email: 'tech@equip.com', address: 'القاهرة', city: 'القاهرة', taxNumber: '410-112-445', totalPurchases: 1340000, balance: 65000, rating: 4, status: 'نشط', commercialTerms: 'نقدي', notes: '', joinDate: '2022-09-12', purchaseHistory: [{ date: '2024-01-07', product: 'سير ناقل', qty: 5, amount: 45000 }], evaluation: { quality: 4, price: 3, delivery: 5, service: 4 } },
];

/* ------------------------------------------------------------------ */
/*  STAR RATING                                                        */
/* ------------------------------------------------------------------ */
function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) =>
        i <= rating ? (
          <Star key={i} size={14} className="text-gold-500 fill-gold-500" />
        ) : (
          <StarOff key={i} size={14} className="text-gray-300" />
        )
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  CATEGORY BADGE                                                     */
/* ------------------------------------------------------------------ */
function CategoryBadge({ cat }: { cat: string }) {
  const styles: Record<string, string> = {
    أعلاف: 'bg-green-100 text-green-700 border-green-300',
    'أدوية بيطرية': 'bg-blue-100 text-blue-700 border-blue-300',
    كتكوت: 'bg-amber-100 text-amber-700 border-amber-300',
    تعبئة: 'bg-purple-100 text-purple-700 border-purple-300',
    معدات: 'bg-gray-100 text-gray-700 border-gray-300',
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${styles[cat] || styles['معدات']}`}>
      {cat}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  STATUS BADGE                                                       */
/* ------------------------------------------------------------------ */
function StatusBadge({ status }: { status: string }) {
  return status === 'نشط' ? (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 border border-green-300">
      <CheckCircle2 size={12} /> نشط
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 border border-gray-300">
      <XCircle size={12} /> متوقف
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState<Supplier[]>(mockSuppliers);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterRating, setFilterRating] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [viewingSupplier, setViewingSupplier] = useState<Supplier | null>(null);
  const [form, setForm] = useState<Partial<Supplier>>({});

  /* ── KPIs ── */
  const totalSuppliers = suppliers.length;
  const activeSuppliers = suppliers.filter((s) => s.status === 'نشط').length;
  const monthlyPurchases = 1250000;
  const totalPayables = suppliers.reduce((s, c) => s + c.balance, 0);

  /* ── Filtered data ── */
  const filteredData = useMemo(() => {
    let result = [...suppliers];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (s) => s.name.includes(q) || s.code.toLowerCase().includes(q) || s.phone.includes(q)
      );
    }
    if (filterCategory) result = result.filter((s) => s.category === filterCategory);
    if (filterStatus) result = result.filter((s) => s.status === filterStatus);
    if (filterRating) result = result.filter((s) => s.rating === +filterRating);
    return result;
  }, [suppliers, searchQuery, filterCategory, filterStatus, filterRating]);

  /* ── Form helpers ── */
  const openAdd = () => {
    setEditingSupplier(null);
    setForm({ status: 'نشط', rating: 3, balance: 0, totalPurchases: 0, commercialTerms: 'نقدي', city: 'القاهرة', category: 'أعلاف' });
    setModalOpen(true);
  };

  const openEdit = (s: Supplier) => {
    setEditingSupplier(s);
    setForm({ ...s });
    setModalOpen(true);
  };

  const openDetail = (s: Supplier) => {
    setViewingSupplier(s);
    setDetailOpen(true);
  };

  const saveSupplier = () => {
    if (!form.name) return;
    if (editingSupplier) {
      setSuppliers((prev) =>
        prev.map((s) => (s.id === editingSupplier.id ? { ...s, ...form } as Supplier : s))
      );
    } else {
      const newId = Math.max(...suppliers.map((s) => s.id)) + 1;
      setSuppliers((prev) => [
        ...prev,
        { ...form, id: newId, code: `SUP-${String(newId).padStart(3, '0')}`, purchaseHistory: [], evaluation: { quality: 3, price: 3, delivery: 3, service: 3 } } as Supplier,
      ]);
    }
    setModalOpen(false);
  };

  const deleteSupplier = (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا المورد؟')) {
      setSuppliers((prev) => prev.filter((s) => s.id !== id));
    }
  };

  const resetFilters = () => {
    setSearchQuery('');
    setFilterCategory('');
    setFilterStatus('');
    setFilterRating('');
  };

  /* ── Table columns ── */
  const columns = [
    { key: 'code', header: 'الكود', sortable: true, width: '90px' },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'category', header: 'الفئة', width: '100px', render: (row: Supplier) => <CategoryBadge cat={row.category} /> },
    { key: 'phone', header: 'الهاتف', width: '110px' },
    { key: 'city', header: 'المدينة', sortable: true, width: '90px' },
    { key: 'totalPurchases', header: 'إجمالي المشتريات', sortable: true, width: '120px', render: (row: Supplier) => row.totalPurchases.toLocaleString('ar-EG') },
    { key: 'balance', header: 'الرصيد', sortable: true, width: '100px', render: (row: Supplier) => row.balance.toLocaleString('ar-EG') },
    { key: 'rating', header: 'التقييم', width: '100px', render: (row: Supplier) => <StarRating rating={row.rating} /> },
    { key: 'status', header: 'الحالة', width: '80px', render: (row: Supplier) => <StatusBadge status={row.status} /> },
  ];

  return (
    <div className="gff-page-transition space-y-6">
      <PageHeader
        title="إدارة الموردين"
        subtitle="إدارة الموردين والتقييم ومتابعة المشتريات"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الموردين' }]}
      >
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors shadow-sm"
        >
          <Plus size={16} /> مورد جديد
        </button>
      </PageHeader>

      {/* ── KPIs ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي الموردين" value={totalSuppliers.toLocaleString('ar-EG')} icon={Truck} iconBg="bg-blue-50" iconColor="text-blue-600" change={2} delay={0} />
        <KPICard title="نشطين" value={activeSuppliers.toLocaleString('ar-EG')} icon={UserCheck} iconBg="bg-green-50" iconColor="text-green-600" change={5} delay={0.05} />
        <KPICard title="مشتريات الشهر" value={monthlyPurchases.toLocaleString('ar-EG')} icon={ShoppingCart} iconBg="bg-amber-50" iconColor="text-amber-600" change={12} changeLabel="عن الشهر السابق" delay={0.1} />
        <KPICard title="مستحقات" value={totalPayables.toLocaleString('ar-EG')} icon={Wallet} iconBg="bg-red-50" iconColor="text-red-600" change={-3} changeLabel="عن الشهر السابق" delay={0.15} />
      </div>

      {/* ── Filters ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4"
      >
        <div className="flex flex-col lg:flex-row gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[220px]">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
            <input
              type="text"
              placeholder="بحث بالاسم أو الكود أو الهاتف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pr-10 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
            />
          </div>
          <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل الفئات</option>
            <option value="أعلاف">أعلاف</option>
            <option value="أدوية بيطرية">أدوية بيطرية</option>
            <option value="كتكوت">كتكوت</option>
            <option value="تعبئة">تعبئة</option>
            <option value="معدات">معدات</option>
          </select>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل الحالات</option>
            <option value="نشط">نشط</option>
            <option value="متوقف">متوقف</option>
          </select>
          <select value={filterRating} onChange={(e) => setFilterRating(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل التقييمات</option>
            <option value="5">5 نجوم</option>
            <option value="4">4 نجوم</option>
            <option value="3">3 نجوم</option>
          </select>
          <button onClick={resetFilters} className="h-10 px-4 rounded-lg border border-uiBorder dark:border-darkBorder text-textSecondary hover:bg-surface dark:hover:bg-darkCard text-sm transition-colors">
            إعادة ضبط
          </button>
        </div>
      </motion.div>

      {/* ── Table ── */}
      <DataTable
        columns={columns}
        data={filteredData}
        pageSize={10}
        title={`الموردين (${filteredData.length})`}
        rowActions={{
          onView: openDetail,
          onEdit: openEdit,
          onDelete: (row) => deleteSupplier(row.id),
        }}
      />

      {/* ═══════════════════ ADD/EDIT MODAL ═══════════════════ */}
      <AnimatePresence>
        {modalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">
                  {editingSupplier ? 'تعديل مورد' : 'مورد جديد'}
                </h3>
                <button onClick={() => setModalOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">اسم المورد *</label>
                  <input value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الفئة</label>
                  <select value={form.category || ''} onChange={(e) => setForm({ ...form, category: e.target.value as any })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="أعلاف">أعلاف</option>
                    <option value="أدوية بيطرية">أدوية بيطرية</option>
                    <option value="كتكوت">كتكوت</option>
                    <option value="تعبئة">تعبئة</option>
                    <option value="معدات">معدات</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الهاتف</label>
                  <input value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" dir="ltr" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">البريد الإلكتروني</label>
                  <input value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" dir="ltr" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">العنوان</label>
                  <input value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">المدينة</label>
                  <input value={form.city || ''} onChange={(e) => setForm({ ...form, city: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الرقم الضريبي</label>
                  <input value={form.taxNumber || ''} onChange={(e) => setForm({ ...form, taxNumber: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" dir="ltr" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">التقييم</label>
                  <select value={form.rating || 3} onChange={(e) => setForm({ ...form, rating: +e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value={5}>5 نجوم</option>
                    <option value={4}>4 نجوم</option>
                    <option value={3}>3 نجوم</option>
                    <option value={2}>2 نجوم</option>
                    <option value={1}>1 نجمة</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الشروط التجارية</label>
                  <select value={form.commercialTerms || ''} onChange={(e) => setForm({ ...form, commercialTerms: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="نقدي">نقدي</option>
                    <option value="15 يوم">15 يوم</option>
                    <option value="30 يوم">30 يوم</option>
                    <option value="45 يوم">45 يوم</option>
                    <option value="60 يوم">60 يوم</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الحالة</label>
                  <select value={form.status || ''} onChange={(e) => setForm({ ...form, status: e.target.value as any })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="نشط">نشط</option>
                    <option value="متوقف">متوقف</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">ملاحظات</label>
                  <textarea value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={3} className="w-full px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm resize-none" />
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-uiBorder dark:border-darkBorder">
                <button onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm transition-colors">إلغاء</button>
                <button onClick={saveSupplier} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">حفظ</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════════════ DETAIL MODAL ═══════════════════ */}
      <AnimatePresence>
        {detailOpen && viewingSupplier && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-600 flex items-center justify-center text-white font-bold text-lg">
                    <Truck size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{viewingSupplier.name}</h3>
                    <p className="text-xs text-textMuted">{viewingSupplier.code} · {viewingSupplier.category}</p>
                  </div>
                </div>
                <button onClick={() => setDetailOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Info Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الفئة</p>
                    <CategoryBadge cat={viewingSupplier.category} />
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الهاتف</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingSupplier.phone}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">المدينة</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingSupplier.city}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الرقم الضريبي</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingSupplier.taxNumber}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الشروط التجارية</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingSupplier.commercialTerms}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">تاريخ الالتحاق</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingSupplier.joinDate}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">التقييم</p>
                    <StarRating rating={viewingSupplier.rating} />
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الحالة</p>
                    <StatusBadge status={viewingSupplier.status} />
                  </div>
                </div>

                {/* Financial Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                    <p className="text-xs text-green-600 dark:text-green-400 mb-1">إجمالي المشتريات</p>
                    <p className="text-xl font-bold text-green-700 dark:text-green-300">{viewingSupplier.totalPurchases.toLocaleString('ar-EG')} ج.م</p>
                  </div>
                  <div className="bg-amber-50 dark:bg-amber-950/20 rounded-lg p-4 border border-amber-200 dark:border-amber-800">
                    <p className="text-xs text-amber-600 dark:text-amber-400 mb-1">الرصيد المستحق</p>
                    <p className="text-xl font-bold text-amber-700 dark:text-amber-300">{viewingSupplier.balance.toLocaleString('ar-EG')} ج.م</p>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
                    <p className="text-xs text-blue-600 dark:text-blue-400 mb-1">التقييم العام</p>
                    <div className="flex items-center gap-2">
                      <span className="text-xl font-bold text-blue-700 dark:text-blue-300">{viewingSupplier.rating}/5</span>
                      <StarRating rating={viewingSupplier.rating} />
                    </div>
                  </div>
                </div>

                {/* Evaluation */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">تقييم الأداء</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { label: 'الجودة', value: viewingSupplier.evaluation.quality },
                      { label: 'السعر', value: viewingSupplier.evaluation.price },
                      { label: 'التوصيل', value: viewingSupplier.evaluation.delivery },
                      { label: 'الخدمة', value: viewingSupplier.evaluation.service },
                    ].map((e) => (
                      <div key={e.label} className="bg-surface dark:bg-darkCard rounded-lg p-4 text-center">
                        <p className="text-xs text-textMuted mb-2">{e.label}</p>
                        <div className="flex items-center justify-center gap-1 mb-2">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star key={i} size={16} className={i < e.value ? 'text-gold-500 fill-gold-500' : 'text-gray-300'} />
                          ))}
                        </div>
                        <p className="text-lg font-bold text-textPrimary dark:text-darkText">{e.value}/5</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Purchase History */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">سجل المشتريات</h4>
                  <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">المنتج</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">الكمية</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">المبلغ</th>
                        </tr>
                      </thead>
                      <tbody>
                        {viewingSupplier.purchaseHistory.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="px-3 py-6 text-center text-textMuted text-sm">لا توجد مشتريات</td>
                          </tr>
                        ) : (
                          viewingSupplier.purchaseHistory.map((p, i) => (
                            <tr key={i} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                              <td className="px-3 py-2 text-textPrimary dark:text-darkText">{p.date}</td>
                              <td className="px-3 py-2 text-textPrimary dark:text-darkText">{p.product}</td>
                              <td className="px-3 py-2 text-textPrimary dark:text-darkText">{p.qty.toLocaleString('ar-EG')}</td>
                              <td className="px-3 py-2 font-medium text-textPrimary dark:text-darkText">{p.amount.toLocaleString('ar-EG')} ج.م</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
