import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Syringe, Plus, X, ChevronLeft, ChevronRight, CheckCircle2, AlertTriangle, Clock, Calendar as CalendarIcon,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

// ─── Types ──────────────────────────────────────────────
interface VaccineRecord {
  id: string;
  animalOrBatch: string;
  animalType: string;
  vaccineName: string;
  dateGiven: string;
  nextDue: string;
  veterinarian: string;
  notes: string;
  status: string;
}

// ─── Mock Data ──────────────────────────────────────────
const vaccineRecords: VaccineRecord[] = [
  { id: 'V-001', animalOrBatch: 'A-1001', animalType: 'عجول', vaccineName: 'حماية مجتمعة', dateGiven: '2024-06-15', nextDue: '2025-06-15', veterinarian: 'د. أحمد محمود', notes: 'جرعة أولى', status: 'مكتملة' },
  { id: 'V-002', animalOrBatch: 'A-1002', animalType: 'عجول', vaccineName: 'حماية مجتمعة', dateGiven: '2024-08-20', nextDue: '2025-08-20', veterinarian: 'د. أحمد محمود', notes: 'جرعة أولى', status: 'مكتملة' },
  { id: 'V-003', animalOrBatch: 'A-1003', animalType: 'أغنام', vaccineName: 'جلعجل', dateGiven: '2024-10-10', nextDue: '2025-01-10', veterinarian: 'د. سمير علي', notes: 'معززة', status: 'قادمة' },
  { id: 'V-004', animalOrBatch: 'A-1004', animalType: 'أغنام', vaccineName: 'حماية مجتمعة', dateGiven: '2024-09-01', nextDue: '2025-03-01', veterinarian: 'د. سمير علي', notes: '—', status: 'قادمة' },
  { id: 'V-005', animalOrBatch: 'A-1005', animalType: 'جاموس', vaccineName: 'حماية مجتمعة', dateGiven: '2024-04-20', nextDue: '2025-04-20', veterinarian: 'د. أحمد محمود', notes: 'جرعة سنوية', status: 'مكتملة' },
  { id: 'V-006', animalOrBatch: 'A-1006', animalType: 'جاموس', vaccineName: 'جلعجل', dateGiven: '2024-11-05', nextDue: '2025-02-05', veterinarian: 'د. سمير علي', notes: 'قيد المتابعة', status: 'قادمة' },
  { id: 'V-007', animalOrBatch: 'A-1007', animalType: 'عجول', vaccineName: 'حماية مجتمعة', dateGiven: '2024-07-12', nextDue: '2025-01-12', veterinarian: 'د. أحمد محمود', notes: 'متأخرة', status: 'متأخرة' },
  { id: 'V-008', animalOrBatch: 'A-1010', animalType: 'جاموس', vaccineName: 'جلعجل', dateGiven: '2024-09-18', nextDue: '2025-03-18', veterinarian: 'د. سمير علي', notes: '—', status: 'قادمة' },
];

const statusColors: Record<string, string> = {
  'مكتملة': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'قادمة': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'متأخرة': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

const scheduleData = [
  { type: 'عجول', ages: ['1 شهر', '3 أشهر', '6 أشهر', '9 أشهر'], vaccines: ['حماية مجتمعة', 'جلعجل', 'حماية مجتمعة (معززة)', 'Newcastle'] },
  { type: 'أغنام', ages: ['1 شهر', '4 أشهر', '8 أشهر'], vaccines: ['حماية مجتمعة', 'جلعجل', 'PPR'] },
  { type: 'جاموس', ages: ['1 شهر', '3 أشهر', '6 أشهر'], vaccines: ['حماية مجتمعة', 'جلعجل', 'حمى القلاعية'] },
];

const calendarDays = Array.from({ length: 31 }, (_, i) => {
  const day = i + 1;
  const dayRecords = vaccineRecords.filter(v => {
    const dueDay = parseInt(v.nextDue.split('-')[2]);
    return dueDay === day;
  });
  const hasCompleted = dayRecords.some(r => r.status === 'مكتملة');
  const hasUpcoming = dayRecords.some(r => r.status === 'قادمة');
  const hasOverdue = dayRecords.some(r => r.status === 'متأخرة');
  return { day, hasCompleted, hasUpcoming, hasOverdue, count: dayRecords.length };
});

export default function LivestockVaccinesPage() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [filterStatus, setFilterStatus] = useState('الكل');

  const totalVaccines = vaccineRecords.length;
  const thisWeekCount = vaccineRecords.filter(v => v.status === 'قادمة').length;
  const completedCount = vaccineRecords.filter(v => v.status === 'مكتملة').length;
  const overdueCount = vaccineRecords.filter(v => v.status === 'متأخرة').length;

  const filtered = filterStatus === 'الكل' ? vaccineRecords : vaccineRecords.filter(v => v.status === filterStatus);

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="سجل التحصينات"
        subtitle="متابعة التحصينات والمواعيد القادمة"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'المواشي', path: '/livestock' },
          { label: 'التحصينات' },
        ]}
      >
        <button onClick={() => setShowAddForm(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Plus size={16} /> تسجيل تحصينة
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي التحصينات" value={String(totalVaccines)} icon={Syringe} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="القادمة هذا الأسبوع" value={String(thisWeekCount)} icon={Clock} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.1} />
        <KPICard title="مكتملة" value={String(completedCount)} icon={CheckCircle2} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.2} />
        <KPICard title="متأخرة" value={String(overdueCount)} icon={AlertTriangle} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} change={overdueCount > 0 ? undefined : undefined} />
      </div>

      {/* Calendar View */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2"><CalendarIcon size={18} /> يناير 2025</h3>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" /> مكتملة</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" /> قادمة</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> متأخرة</span>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1">
          {['السبت', 'الجمعة', 'الخميس', 'الأربعاء', 'الثلاثاء', 'الإثنين', 'الأحد'].map(d => (
            <div key={d} className="text-center text-xs font-semibold text-textMuted py-2">{d}</div>
          ))}
          {Array.from({ length: 3 }, (_, i) => (
            <div key={`empty-${i}`} className="h-10" />
          ))}
          {calendarDays.map(d => (
            <div key={d.day} className="relative h-10 rounded-lg border border-uiBorder/50 flex items-center justify-center text-sm text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard transition-colors cursor-pointer">
              {d.day}
              {d.count > 0 && (
                <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
                  {d.hasCompleted && <span className="w-1.5 h-1.5 rounded-full bg-green-500" />}
                  {d.hasUpcoming && <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />}
                  {d.hasOverdue && <span className="w-1.5 h-1.5 rounded-full bg-red-500" />}
                </div>
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Vaccination Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">سجل التحصينات</h3>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
            <option>الكل</option><option>مكتملة</option><option>قادمة</option><option>متأخرة</option>
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['الحيوان/الدفعة', 'النوع', 'التحصينة', 'تاريخ الإعطاء', 'التالي', 'البيطري', 'ملاحظات', 'الحالة'].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.animalOrBatch}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.animalType}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.vaccineName}</td>
                  <td className="px-4 py-3 text-sm text-textMuted">{row.dateGiven}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.nextDue}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.veterinarian}</td>
                  <td className="px-4 py-3 text-sm text-textMuted">{row.notes}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[row.status]}`}>{row.status}</span></td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Vaccination Schedule */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">جدول التحصينات حسب نوع الحيوان</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">نوع الحيوان</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">المراحل العمرية</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">التحصينات المطلوبة</th>
              </tr>
            </thead>
            <tbody>
              {scheduleData.map((s, idx) => (
                <motion.tr key={s.type} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{s.type}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{s.ages.join(' → ')}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{s.vaccines.join(' → ')}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Add Vaccination Modal */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowAddForm(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تسجيل تحصينة جديدة</h3>
                <button onClick={() => setShowAddForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الحيوان/الدفعة</label><input type="text" placeholder="مثال: A-1001" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">نوع الحيوان</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>عجول</option><option>أغنام</option><option>جاموس</option></select></div>
                </div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">التحصينة</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>حماية مجتمعة</option><option>جلعجل</option><option>Junior Newcastle</option><option>PPR</option><option>حمى القلاعية</option></select></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">تاريخ الإعطاء</label><input type="date" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الموعد التالي</label><input type="date" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">البيطري</label><input type="text" placeholder="اسم الطبيب البيطري" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">ملاحظات</label><input type="text" placeholder="ملاحظات اختيارية" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">إلغاء</button>
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors">حفظ</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
