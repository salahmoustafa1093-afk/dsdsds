import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, ChevronDown, ChevronLeft, Search,
  Plus, X, Edit3, Eye, FolderOpen, FolderClosed
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

/* ─── Types ─── */
interface Account {
  id: number;
  code: string;
  nameAr: string;
  nameEn: string;
  type: string;
  balance: number;
  status: 'نشط' | 'معطل';
  parentId?: number;
  children?: Account[];
}

/* ─── Chart of Accounts Data ─── */
const chartData: Account[] = [
  {
    id: 1, code: '1', nameAr: 'أصول', nameEn: 'Assets', type: 'أصل', balance: 5200000, status: 'نشط',
    children: [
      {
        id: 11, code: '11', nameAr: 'أصول متداولة', nameEn: 'Current Assets', type: 'أصل', balance: 2100000, status: 'نشط', parentId: 1,
        children: [
          { id: 111, code: '111', nameAr: 'النقدية بالخزينة', nameEn: 'Cash on Hand', type: 'أصل', balance: 156780, status: 'نشط', parentId: 11 },
          { id: 112, code: '112', nameAr: 'النقدية بالبنوك', nameEn: 'Cash in Banks', type: 'أصل', balance: 1770000, status: 'نشط', parentId: 11 },
          { id: 113, code: '113', nameAr: 'العملاء', nameEn: 'Accounts Receivable', type: 'أصل', balance: 980000, status: 'نشط', parentId: 11 },
        ],
      },
      {
        id: 12, code: '12', nameAr: 'أصول ثابتة', nameEn: 'Fixed Assets', type: 'أصل', balance: 3100000, status: 'نشط', parentId: 1,
        children: [
          { id: 121, code: '121', nameAr: 'الأراضي', nameEn: 'Land', type: 'أصل', balance: 1500000, status: 'نشط', parentId: 12 },
          { id: 122, code: '122', nameAr: 'المباني', nameEn: 'Buildings', type: 'أصل', balance: 1200000, status: 'نشط', parentId: 12 },
          { id: 123, code: '123', nameAr: 'الآلات والمعدات', nameEn: 'Machinery', type: 'أصل', balance: 800000, status: 'نشط', parentId: 12 },
        ],
      },
    ],
  },
  {
    id: 2, code: '2', nameAr: 'خصوم', nameEn: 'Liabilities', type: 'خصم', balance: 2800000, status: 'نشط',
    children: [
      {
        id: 21, code: '21', nameAr: 'خصوم قصيرة الأجل', nameEn: 'Current Liabilities', type: 'خصم', balance: 1800000, status: 'نشط', parentId: 2,
        children: [
          { id: 211, code: '211', nameAr: 'موردون', nameEn: 'Accounts Payable', type: 'خصم', balance: 1250000, status: 'نشط', parentId: 21 },
          { id: 212, code: '212', nameAr: 'قروض قصيرة الأجل', nameEn: 'Short-term Loans', type: 'خصم', balance: 550000, status: 'نشط', parentId: 21 },
        ],
      },
      {
        id: 22, code: '22', nameAr: 'خصوم طويلة الأجل', nameEn: 'Long-term Liabilities', type: 'خصم', balance: 1000000, status: 'نشط', parentId: 2,
        children: [
          { id: 221, code: '221', nameAr: 'قروض طويلة الأجل', nameEn: 'Long-term Loans', type: 'خصم', balance: 1000000, status: 'نشط', parentId: 22 },
        ],
      },
    ],
  },
  {
    id: 3, code: '3', nameAr: 'حقوق ملكية', nameEn: 'Equity', type: 'حقوق ملكية', balance: 2400000, status: 'نشط',
    children: [
      { id: 31, code: '31', nameAr: 'رأس المال', nameEn: 'Capital', type: 'حقوق ملكية', balance: 2000000, status: 'نشط', parentId: 3 },
      { id: 32, code: '32', nameAr: 'الأرباح المحتجزة', nameEn: 'Retained Earnings', type: 'حقوق ملكية', balance: 400000, status: 'نشط', parentId: 3 },
    ],
  },
  {
    id: 4, code: '4', nameAr: 'إيرادات', nameEn: 'Revenue', type: 'إيراد', balance: 8945000, status: 'نشط',
    children: [
      {
        id: 41, code: '41', nameAr: 'إيرادات تشغيلية', nameEn: 'Operating Revenue', type: 'إيراد', balance: 8500000, status: 'نشط', parentId: 4,
        children: [
          { id: 411, code: '411', nameAr: 'مبيعات الأعلاف', nameEn: 'Feed Sales', type: 'إيراد', balance: 6500000, status: 'نشط', parentId: 41 },
          { id: 412, code: '412', nameAr: 'مبيعات الدواجن', nameEn: 'Poultry Sales', type: 'إيراد', balance: 2000000, status: 'نشط', parentId: 41 },
        ],
      },
      {
        id: 42, code: '42', nameAr: 'إيرادات أخرى', nameEn: 'Other Revenue', type: 'إيراد', balance: 445000, status: 'نشط', parentId: 4,
        children: [
          { id: 421, code: '421', nameAr: 'إيرادات إيجارية', nameEn: 'Rental Income', type: 'إيراد', balance: 200000, status: 'نشط', parentId: 42 },
          { id: 422, code: '422', nameAr: 'إيرادات فوائد', nameEn: 'Interest Income', type: 'إيراد', balance: 245000, status: 'نشط', parentId: 42 },
        ],
      },
    ],
  },
  {
    id: 5, code: '5', nameAr: 'مصروفات', nameEn: 'Expenses', type: 'مصروف', balance: 6200000, status: 'نشط',
    children: [
      {
        id: 51, code: '51', nameAr: 'تكلفة البضاعة المباعة', nameEn: 'COGS', type: 'مصروف', balance: 3500000, status: 'نشط', parentId: 5,
        children: [
          { id: 511, code: '511', nameAr: 'تكلفة المواد الخام', nameEn: 'Raw Material Cost', type: 'مصروف', balance: 2200000, status: 'نشط', parentId: 51 },
          { id: 512, code: '512', nameAr: 'تكلفة التصنيع', nameEn: 'Manufacturing Cost', type: 'مصروف', balance: 1300000, status: 'نشط', parentId: 51 },
        ],
      },
      {
        id: 52, code: '52', nameAr: 'مصاريف إدارية', nameEn: 'Administrative Expenses', type: 'مصروف', balance: 1200000, status: 'نشط', parentId: 5,
        children: [
          { id: 521, code: '521', nameAr: 'رواتب وأجور', nameEn: 'Salaries & Wages', type: 'مصروف', balance: 800000, status: 'نشط', parentId: 52 },
          { id: 522, code: '522', nameAr: 'إيجارات', nameEn: 'Rent', type: 'مصروف', balance: 250000, status: 'نشط', parentId: 52 },
          { id: 523, code: '523', nameAr: 'مصاريف إهلاك', nameEn: 'Depreciation', type: 'مصروف', balance: 150000, status: 'نشط', parentId: 52 },
        ],
      },
      {
        id: 53, code: '53', nameAr: 'مصاريف بيعية', nameEn: 'Selling Expenses', type: 'مصروف', balance: 950000, status: 'نشط', parentId: 5,
        children: [
          { id: 531, code: '531', nameAr: 'عمولات مبيعات', nameEn: 'Sales Commissions', type: 'مصروف', balance: 450000, status: 'نشط', parentId: 53 },
          { id: 532, code: '532', nameAr: 'إعلان وتسويق', nameEn: 'Marketing', type: 'مصروف', balance: 300000, status: 'نشط', parentId: 53 },
          { id: 533, code: '533', nameAr: 'نقل وتوزيع', nameEn: 'Distribution', type: 'مصروف', balance: 200000, status: 'نشط', parentId: 53 },
        ],
      },
      {
        id: 54, code: '54', nameAr: 'مصاريف تمويلية', nameEn: 'Financial Expenses', type: 'مصروف', balance: 550000, status: 'نشط', parentId: 5,
        children: [
          { id: 541, code: '541', nameAr: 'فوائد بنكية', nameEn: 'Bank Interest', type: 'مصروف', balance: 400000, status: 'نشط', parentId: 54 },
          { id: 542, code: '542', nameAr: 'مصاريف بنكية', nameEn: 'Bank Charges', type: 'مصروف', balance: 150000, status: 'نشط', parentId: 54 },
        ],
      },
    ],
  },
];

function flattenAccounts(accounts: Account[], level = 0): (Account & { level: number })[] {
  const result: (Account & { level: number })[] = [];
  for (const acc of accounts) {
    result.push({ ...acc, level });
    if (acc.children) {
      result.push(...flattenAccounts(acc.children, level + 1));
    }
  }
  return result;
}

const allAccounts = flattenAccounts(chartData);

export default function AccountingChartPage() {
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set([1, 2, 3, 4, 5]));
  const [showAddForm, setShowAddForm] = useState(false);
  const [showDetail, setShowDetail] = useState<Account | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleExpand = (id: number) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const isExpanded = (id: number) => expandedIds.has(id);

  const filteredAccounts = searchQuery
    ? allAccounts.filter(
        (a) =>
          a.nameAr.includes(searchQuery) ||
          a.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
          a.code.includes(searchQuery)
      )
    : allAccounts;

  const statusBadge = (status: string) => (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
      status === 'نشط'
        ? 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400'
        : 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400'
    }`}>
      {status}
    </span>
  );

  const typeColor = (type: string) => {
    const colors: Record<string, string> = {
      'أصل': 'text-blue-600',
      'خصم': 'text-red-600',
      'حقوق ملكية': 'text-purple-600',
      'إيراد': 'text-green-600',
      'مصروف': 'text-amber-600',
    };
    return colors[type] || 'text-textSecondary';
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="شجرة الحسابات"
        subtitle="دليل الحسابات المحاسبية - شجرة الحسابات الكاملة"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الحسابات', path: '/accounting' },
          { label: 'شجرة الحسابات' },
        ]}
      >
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>إضافة حساب</span>
        </button>
      </PageHeader>

      {/* Search & Summary */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-center bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
        <div className="relative w-full sm:w-80">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
          <input
            type="text"
            placeholder="بحث برقم أو اسم الحساب..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
          />
        </div>
        <div className="flex gap-4 text-xs text-textSecondary">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" /> أصول</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> خصوم</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-purple-500" /> حقوق ملكية</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" /> إيرادات</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500" /> مصروفات</span>
        </div>
      </div>

      {/* Tree Table */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">كود</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">اسم الحساب (عربي)</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">اسم الحساب (English)</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">النوع</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">الرصيد</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">الحالة</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-uiBorder/50 dark:divide-darkBorder/30">
              {filteredAccounts.map((acc, idx) => (
                <motion.tr
                  key={acc.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.2, delay: idx * 0.02 }}
                  className="hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">
                    <span style={{ paddingRight: `${acc.level * 24}px` }} className="inline-flex items-center gap-1">
                      {acc.children && acc.children.length > 0 ? (
                        <button onClick={() => toggleExpand(acc.id)} className="w-5 h-5 rounded flex items-center justify-center hover:bg-surface dark:hover:bg-darkCard transition-colors">
                          {isExpanded(acc.id) ? <ChevronDown size={14} className="text-textMuted" /> : <ChevronLeft size={14} className="text-textMuted" />}
                        </button>
                      ) : (
                        <span className="w-5" />
                      )}
                      {acc.code}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-sm text-textPrimary dark:text-darkText">
                    <span style={{ paddingRight: `${acc.level * 8}px` }} className="inline-flex items-center gap-2">
                      {acc.children && acc.children.length > 0
                        ? (isExpanded(acc.id) ? <FolderOpen size={14} className={typeColor(acc.type)} /> : <FolderClosed size={14} className={typeColor(acc.type)} />)
                        : <BookOpen size={14} className={typeColor(acc.type)} />
                      }
                      <span className={acc.level === 0 ? 'font-bold' : acc.level === 1 ? 'font-semibold' : ''}>{acc.nameAr}</span>
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{acc.nameEn}</td>
                  <td className="px-4 py-2.5">
                    <span className={`text-xs font-medium ${typeColor(acc.type)}`}>{acc.type}</span>
                  </td>
                  <td className="px-4 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{formatCurrency(acc.balance)}</td>
                  <td className="px-4 py-2.5">{statusBadge(acc.status)}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setShowDetail(acc)} className="w-7 h-7 rounded flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors" title="عرض">
                        <Eye size={14} />
                      </button>
                      <button className="w-7 h-7 rounded flex items-center justify-center text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/30 transition-colors" title="تعديل">
                        <Edit3 size={14} />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Add Account Modal */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowAddForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إضافة حساب جديد</h3>
                <button onClick={() => setShowAddForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">كود الحساب</label>
                    <input className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="مثال: 511" />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الرصيد الافتتاحي</label>
                    <input type="number" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="0.00" />
                  </div>
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">اسم الحساب (عربي)</label>
                  <input className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="اسم الحساب بالعربية" />
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">اسم الحساب (English)</label>
                  <input className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="Account name in English" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">الحساب الأب</label>
                    <select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      <option>بدون (حساب رئيسي)</option>
                      {allAccounts.map((a) => <option key={a.id} value={a.id}>{a.code} - {a.nameAr}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">النوع</label>
                    <select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                      <option>أصل</option>
                      <option>خصم</option>
                      <option>حقوق ملكية</option>
                      <option>إيراد</option>
                      <option>مصروف</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إلغاء</button>
                <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">حفظ الحساب</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Account Detail Modal */}
      <AnimatePresence>
        {showDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowDetail(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تفاصيل الحساب</h3>
                <button onClick={() => setShowDetail(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="text-center p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
                  <p className="text-2xl font-bold text-green-700 dark:text-green-400">{showDetail.code}</p>
                  <p className="text-sm text-textPrimary dark:text-darkText mt-1">{showDetail.nameAr}</p>
                  <p className="text-xs text-textMuted">{showDetail.nameEn}</p>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-sm text-textSecondary">النوع</span>
                    <span className={`text-sm font-medium ${typeColor(showDetail.type)}`}>{showDetail.type}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-sm text-textSecondary">الرصيد الحالي</span>
                    <span className="text-sm font-bold text-textPrimary dark:text-darkText">{formatCurrency(showDetail.balance)}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                    <span className="text-sm text-textSecondary">الحالة</span>
                    <span>{statusBadge(showDetail.status)}</span>
                  </div>
                  {showDetail.parentId && (
                    <div className="flex justify-between py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                      <span className="text-sm text-textSecondary">الحساب الأب</span>
                      <span className="text-sm font-medium text-textPrimary dark:text-darkText">
                        {allAccounts.find((a) => a.id === showDetail.parentId)?.nameAr || '—'}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
