import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Wheat, Plus, TrendingUp, Calculator, X, UtensilsCrossed,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

// ─── Types ──────────────────────────────────────────────
interface FeedRecord {
  id: string;
  animalType: string;
  feedType: string;
  dailyRation: number;
  actualConsumed: number;
  costPerDay: number;
  fcr: number;
  lastWeighed: string;
}

// ─── Mock Data ──────────────────────────────────────────
const feedData: FeedRecord[] = [
  { id: 'F-001', animalType: 'عجول', feedType: 'علف مركز', dailyRation: 4.5, actualConsumed: 4.3, costPerDay: 125, fcr: 6.2, lastWeighed: '2025-01-10' },
  { id: 'F-002', animalType: 'عجول', feedType: 'علف نامي', dailyRation: 3.8, actualConsumed: 3.9, costPerDay: 98, fcr: 5.8, lastWeighed: '2025-01-12' },
  { id: 'F-003', animalType: 'أغنام', feedType: 'علف أغنام', dailyRation: 1.5, actualConsumed: 1.4, costPerDay: 32, fcr: 4.5, lastWeighed: '2025-01-11' },
  { id: 'F-004', animalType: 'أغنام', feedType: 'تبن + مركز', dailyRation: 1.8, actualConsumed: 1.7, costPerDay: 28, fcr: 4.2, lastWeighed: '2025-01-09' },
  { id: 'F-005', animalType: 'جاموس', feedType: 'علف جاموس', dailyRation: 5.5, actualConsumed: 5.2, costPerDay: 142, fcr: 7.1, lastWeighed: '2025-01-13' },
  { id: 'F-006', animalType: 'جاموس', feedType: 'علف نامي', dailyRation: 4.0, actualConsumed: 3.8, costPerDay: 105, fcr: 6.5, lastWeighed: '2025-01-08' },
  { id: 'F-007', animalType: 'عجول', feedType: 'علف مركز', dailyRation: 5.0, actualConsumed: 4.8, costPerDay: 138, fcr: 6.0, lastWeighed: '2025-01-14' },
  { id: 'F-008', animalType: 'أغنام', feedType: 'علف أغنام', dailyRation: 1.2, actualConsumed: 1.1, costPerDay: 26, fcr: 4.8, lastWeighed: '2025-01-07' },
];

const fcrChartData = [
  { month: 'سبتمبر', عجول: 7.2, أغنام: 5.1, جاموس: 8.0 },
  { month: 'أكتوبر', عجول: 6.8, أغنام: 4.8, جاموس: 7.6 },
  { month: 'نوفمبر', عجول: 6.5, أغنام: 4.6, جاموس: 7.3 },
  { month: 'ديسمبر', عجول: 6.3, أغنام: 4.4, جاموس: 7.2 },
  { month: 'يناير', عجول: 6.0, أغنام: 4.3, جاموس: 6.8 },
];

const rationSuggestions: Record<string, { rations: { weightRange: string; dailyRation: number; feedType: string; costPerKg: number }[] }> = {
  'عجول': {
    rations: [
      { weightRange: '100-150 كجم', dailyRation: 3.0, feedType: 'علف نامي', costPerKg: 28 },
      { weightRange: '150-250 كجم', dailyRation: 4.5, feedType: 'علف مركز', costPerKg: 32 },
      { weightRange: '250-350 كجم', dailyRation: 5.5, feedType: 'علف مركز', costPerKg: 35 },
    ],
  },
  'أغنام': {
    rations: [
      { weightRange: '15-25 كجم', dailyRation: 1.0, feedType: 'علف أغنام', costPerKg: 22 },
      { weightRange: '25-40 كجم', dailyRation: 1.5, feedType: 'علف أغنام', costPerKg: 24 },
      { weightRange: '40-60 كجم', dailyRation: 2.0, feedType: 'تبن + مركز', costPerKg: 20 },
    ],
  },
  'جاموس': {
    rations: [
      { weightRange: '150-200 كجم', dailyRation: 4.0, feedType: 'علف نامي', costPerKg: 26 },
      { weightRange: '200-300 كجم', dailyRation: 5.5, feedType: 'علف جاموس', costPerKg: 30 },
      { weightRange: '300-450 كجم', dailyRation: 6.5, feedType: 'علف جاموس', costPerKg: 32 },
    ],
  },
};

export default function LivestockFeedingPage() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [calcType, setCalcType] = useState('عجول');
  const [calcWeight, setCalcWeight] = useState('');
  const [calcResult, setCalcResult] = useState<typeof rationSuggestions[string]['rations'][0] | null>(null);

  const dailyConsumption = feedData.reduce((s, f) => s + f.actualConsumed, 0);
  const dailyCost = feedData.reduce((s, f) => s + f.costPerDay, 0);
  const avgFCR = (feedData.reduce((s, f) => s + f.fcr, 0) / feedData.length).toFixed(1);
  const stockLevel = 4850;

  const handleCalculate = () => {
    const w = parseInt(calcWeight);
    if (!w) return;
    const suggestions = rationSuggestions[calcType]?.rations || [];
    const match = suggestions.find(r => {
      const [min, max] = r.weightRange.split('-').map(s => parseInt(s));
      return w >= min && w <= max;
    }) || suggestions[0];
    setCalcResult(match || null);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="إدارة التغذية"
        subtitle="متابعة استهلاك العلف ونسبة التحويل الغذائي"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'المواشي', path: '/livestock' },
          { label: 'التغذية' },
        ]}
      >
        <button onClick={() => setShowCalculator(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gold-500 text-white text-sm font-medium hover:bg-gold-600 transition-colors shadow-sm">
          <Calculator size={16} /> حاسبة الكميات
        </button>
        <button onClick={() => setShowAddForm(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Plus size={16} /> تسجيل استهلاك
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="استهلاك اليوم" value={`${dailyConsumption.toFixed(1)} كجم`} icon={Wheat} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} change={3.2} />
        <KPICard title="تكلفة اليوم" value={`${dailyCost.toLocaleString()} ج.م`} icon={UtensilsCrossed} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.1} change={-1.5} />
        <KPICard title="FCR متوسط" value={String(avgFCR)} icon={TrendingUp} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.2} change={-0.3} changeLabel="تحسن عن الشهر الماضي" />
        <KPICard title="مخزون العلف" value={`${stockLevel.toLocaleString()} كجم`} icon={Wheat} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-700 dark:text-purple-400" delay={0.3} change={-5} />
      </div>

      {/* FCR Chart */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5">
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">نسبة التحويل الغذائي (FCR) عبر الزمن</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={fcrChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} domain={[3, 9]} />
              <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
              <Legend />
              <Line type="monotone" dataKey="عجول" stroke="#14a86a" strokeWidth={2} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="أغنام" stroke="#daa520" strokeWidth={2} dot={{ r: 4 }} />
              <Line type="monotone" dataKey="جاموس" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Feed Records Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">سجلات التغذية</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['نوع الحيوان', 'نوع العلف', 'الكمية اليومية (كجم)', 'الاستهلاك الفعلي', 'التكلفة/يوم', 'FCR', 'آن وزن'].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {feedData.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText font-medium">{row.animalType}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.feedType}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.dailyRation}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.actualConsumed}</td>
                  <td className="px-4 py-3 text-sm text-green-700 font-semibold">{row.costPerDay} ج.م</td>
                  <td className="px-4 py-3 text-sm">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${row.fcr <= 5 ? 'bg-green-100 text-green-700' : row.fcr <= 6.5 ? 'bg-gold-100 text-gold-700' : 'bg-red-100 text-red-700'}`}>{row.fcr}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-textMuted">{row.lastWeighed}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Add Feed Record Modal */}
      {showAddForm && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowAddForm(false)}>
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
            <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تسجيل استهلاك علف</h3>
              <button onClick={() => setShowAddForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
            </div>
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-xs font-medium text-textSecondary mb-1">التاريخ</label><input type="date" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">نوع الحيوان</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>عجول</option><option>أغنام</option><option>جاموس</option></select></div>
              </div>
              <div><label className="block text-xs font-medium text-textSecondary mb-1">نوع العلف</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>علف مركز</option><option>علف نامي</option><option>علف أغنام</option><option>علف جاموس</option><option>تبن + مركز</option></select></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block text-xs font-medium text-textSecondary mb-1">الكمية (كجم)</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">التكلفة (ج.م)</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">إلغاء</button>
                <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors">حفظ</button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Calculator Modal */}
      {showCalculator && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowCalculator(false)}>
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
            <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
              <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">حاسبة الكميات اليومية</h3>
              <button onClick={() => setShowCalculator(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-textSecondary mb-1">نوع الحيوان</label>
                <select value={calcType} onChange={e => { setCalcType(e.target.value); setCalcResult(null); }} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
                  <option>عجول</option><option>أغنام</option><option>جاموس</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-textSecondary mb-1">الوزن الحالي (كجم)</label>
                <input type="number" value={calcWeight} onChange={e => { setCalcWeight(e.target.value); setCalcResult(null); }} placeholder="أدخل الوزن" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
              </div>
              <button onClick={handleCalculate} className="w-full py-2.5 rounded-lg bg-gold-500 text-white text-sm font-medium hover:bg-gold-600 transition-colors">احسب الكمية المقترحة</button>
              {calcResult && (
                <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 space-y-2 border border-green-200 dark:border-green-800">
                  <p className="text-sm text-green-800 dark:text-green-300 font-medium">الكمية المقترحة: <span className="text-lg font-bold">{calcResult.dailyRation} كجم/يوم</span></p>
                  <p className="text-xs text-green-700 dark:text-green-400">نوع العلف: {calcResult.feedType}</p>
                  <p className="text-xs text-green-700 dark:text-green-400">النطاق: {calcResult.weightRange}</p>
                  <p className="text-xs text-green-700 dark:text-green-400">التكلفة التقريبية: {(calcResult.dailyRation * calcResult.costPerKg).toFixed(0)} ج.م/يوم</p>
                </motion.div>
              )}
              <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                <p className="text-xs font-medium text-textSecondary mb-2">النطاقات المتاحة:</p>
                <div className="space-y-1">
                  {rationSuggestions[calcType]?.rations.map((r, i) => (
                    <div key={i} className="flex justify-between text-xs text-textPrimary dark:text-darkText"><span>{r.weightRange}</span><span>{r.dailyRation} كجم - {r.feedType}</span></div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
