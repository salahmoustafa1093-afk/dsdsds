import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, CheckCircle2, FileText, AlertTriangle,
  Plus, X, Trash2, Eye, Send, RotateCcw
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { formatCurrency } from '@/data/mockData';

/* ─── Types ─── */
interface EntryRow {
  id: number;
  account: string;
  debit: number;
  credit: number;
  description: string;
}

interface JournalEntry {
  id: number;
  number: string;
  date: string;
  description: string;
  totalDebit: number;
  totalCredit: number;
  status: 'مسودة' | 'معتمدة' | 'مرحلة';
  createdBy: string;
  notes: string;
  rows: EntryRow[];
}

/* ─── Mock Data ─── */
const initialEntries: JournalEntry[] = [
  {
    id: 1, number: 'JV-2025-001', date: '2025-01-15',
    description: 'قيود يومية - مبيعات ومصروفات',
    totalDebit: 320000, totalCredit: 320000, status: 'معتمدة',
    createdBy: 'محمد أحمد', notes: '—',
    rows: [
      { id: 1, account: '111 - النقدية بالخزينة', debit: 150000, credit: 0, description: 'مقبوضات نقدية' },
      { id: 2, account: '412 - إيرادات المبيعات', debit: 0, credit: 150000, description: 'مبيعات يومية' },
      { id: 3, account: '521 - تكلفة البضاعة المباعة', debit: 120000, credit: 0, description: 'تكلفة المبيعات' },
      { id: 4, account: '131 - المخزون', debit: 0, credit: 120000, description: 'صرف بضاعة' },
      { id: 5, account: '511 - مصاريف التشغيل', debit: 50000, credit: 0, description: 'مصروفات يومية' },
      { id: 6, account: '111 - النقدية بالخزينة', debit: 0, credit: 50000, description: 'صرف نقدي' },
    ],
  },
  {
    id: 2, number: 'JV-2025-002', date: '2025-01-14',
    description: 'رواتب شهر يناير',
    totalDebit: 180000, totalCredit: 180000, status: 'مرحلة',
    createdBy: 'أحمد علي', notes: 'تمت المراجعة والاعتماد',
    rows: [
      { id: 1, account: '521 - رواتب وأجور', debit: 180000, credit: 0, description: 'رواتب الموظفين' },
      { id: 2, account: '213 - مستحقات الموظفين', debit: 0, credit: 180000, description: 'استحقاق الرواتب' },
    ],
  },
  {
    id: 3, number: 'JV-2025-003', date: '2025-01-14',
    description: 'شراء مواد خام',
    totalDebit: 250000, totalCredit: 250000, status: 'مسودة',
    createdBy: 'محمود سالم', notes: 'في انتظار المراجعة',
    rows: [
      { id: 1, account: '131 - مخزون المواد الخام', debit: 250000, credit: 0, description: 'شراء ذرة صفراء' },
      { id: 2, account: '221 - موردون', debit: 0, credit: 250000, description: 'شراء آجل' },
    ],
  },
  {
    id: 4, number: 'JV-2025-004', date: '2025-01-13',
    description: 'إهلاك الأصول الثابتة',
    totalDebit: 15000, totalCredit: 15000, status: 'معتمدة',
    createdBy: 'محمد أحمد', notes: 'إهلاك شهري',
    rows: [
      { id: 1, account: '522 - مصاريف الإهلاك', debit: 15000, credit: 0, description: 'إهلاك معدات' },
      { id: 2, account: '122 - مجمع الإهلاك', debit: 0, credit: 15000, description: 'إهلاك متراكم' },
    ],
  },
];

const accounts = [
  '111 - النقدية بالخزينة',
  '112 - النقدية بالبنوك',
  '121 - الأصول الثابتة',
  '122 - مجمع الإهلاك',
  '131 - المخزون',
  '131 - مخزون المواد الخام',
  '211 - الدائنون',
  '213 - مستحقات الموظفين',
  '221 - موردون',
  '311 - رأس المال',
  '411 - إيرادات التشغيل',
  '412 - إيرادات المبيعات',
  '511 - مصاريف التشغيل',
  '521 - تكلفة البضاعة المباعة',
  '521 - رواتب وأجور',
  '522 - مصاريف الإهلاك',
];

export default function AccountingEntriesPage() {
  const [entries, setEntries] = useState<JournalEntry[]>(initialEntries);
  const [showForm, setShowForm] = useState(false);
  const [showDetail, setShowDetail] = useState<JournalEntry | null>(null);
  const [filterStatus, setFilterStatus] = useState('');

  /* New entry form state */
  const [formDesc, setFormDesc] = useState('');
  const [formDate, setFormDate] = useState('2025-01-15');
  const [formNotes, setFormNotes] = useState('');
  const [formRows, setFormRows] = useState<EntryRow[]>([
    { id: 1, account: accounts[0], debit: 0, credit: 0, description: '' },
  ]);

  const addRow = () => {
    setFormRows([...formRows, { id: Date.now(), account: accounts[0], debit: 0, credit: 0, description: '' }]);
  };

  const removeRow = (id: number) => {
    if (formRows.length > 1) setFormRows(formRows.filter((r) => r.id !== id));
  };

  const updateRow = (id: number, field: keyof EntryRow, value: string | number) => {
    setFormRows(formRows.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
  };

  const totalDebit = formRows.reduce((s, r) => s + (Number(r.debit) || 0), 0);
  const totalCredit = formRows.reduce((s, r) => s + (Number(r.credit) || 0), 0);
  const isBalanced = totalDebit === totalCredit && totalDebit > 0;

  const handleSave = () => {
    if (!isBalanced || !formDesc) return;
    const newEntry: JournalEntry = {
      id: Date.now(),
      number: `JV-2025-${String(entries.length + 1).padStart(3, '0')}`,
      date: formDate,
      description: formDesc,
      totalDebit,
      totalCredit,
      status: 'مسودة',
      createdBy: 'محمد أحمد',
      notes: formNotes || '—',
      rows: formRows,
    };
    setEntries([newEntry, ...entries]);
    setShowForm(false);
    setFormDesc('');
    setFormNotes('');
    setFormRows([{ id: Date.now(), account: accounts[0], debit: 0, credit: 0, description: '' }]);
  };

  const advanceStatus = (entry: JournalEntry) => {
    const flow: Record<string, string> = { 'مسودة': 'معتمدة', 'معتمدة': 'مرحلة', 'مرحلة': 'مرحلة' };
    setEntries(entries.map((e) => e.id === entry.id ? { ...e, status: flow[e.status] as JournalEntry['status'] } : e));
  };

  const filteredEntries = filterStatus
    ? entries.filter((e) => e.status === filterStatus)
    : entries;

  const statusBadge = (status: string) => {
    const classes: Record<string, string> = {
      'مسودة': 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
      'معتمدة': 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400',
      'مرحلة': 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-400',
    };
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${classes[status]}`}>
        {status === 'مسودة' && <FileText size={12} />}
        {status === 'معتمدة' && <CheckCircle2 size={12} />}
        {status === 'مرحلة' && <AlertTriangle size={12} />}
        {status}
      </span>
    );
  };

  const kpiToday = entries.filter((e) => e.date === '2025-01-15').length;
  const kpiBalanced = entries.filter((e) => e.totalDebit === e.totalCredit).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="القيود المحاسبية"
        subtitle="إنشاء ومراجعة واعتماد القيود اليومية"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الحسابات', path: '/accounting' },
          { label: 'القيود' },
        ]}
      >
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          <Plus size={16} />
          <span>قيد جديد</span>
        </button>
      </PageHeader>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="قيود اليوم" value={String(kpiToday)} icon={BookOpen} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="إجمالي مدين" value={formatCurrency(entries.reduce((s, e) => s + e.totalDebit, 0))} icon={Plus} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="إجمالي دائن" value={formatCurrency(entries.reduce((s, e) => s + e.totalCredit, 0))} icon={RotateCcw} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="متوازنة" value={`${kpiBalanced}/${entries.length}`} icon={CheckCircle2} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.3} />
      </div>

      {/* Status Filter */}
      <div className="flex gap-2 flex-wrap">
        {['الكل', 'مسودة', 'معتمدة', 'مرحلة'].map((s) => (
          <button
            key={s}
            onClick={() => setFilterStatus(s === 'الكل' ? '' : s)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              (s === 'الكل' && !filterStatus) || filterStatus === s
                ? 'bg-green-700 text-white'
                : 'bg-white dark:bg-darkSurface border border-uiBorder dark:border-darkBorder text-textSecondary hover:text-textPrimary dark:text-darkTextSec'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Entries Table */}
      <DataTable
        columns={[
          { key: 'number', header: 'رقم القيد', sortable: true },
          { key: 'date', header: 'التاريخ', sortable: true },
          { key: 'description', header: 'البيان', sortable: true },
          { key: 'totalDebit', header: 'إجمالي مدين', render: (row) => <span className="font-medium text-green-600">{formatCurrency(row.totalDebit as number)}</span> },
          { key: 'totalCredit', header: 'إجمالي دائن', render: (row) => <span className="font-medium text-amber-600">{formatCurrency(row.totalCredit as number)}</span> },
          { key: 'status', header: 'الحالة', render: (row) => statusBadge(row.status as string) },
          { key: 'createdBy', header: 'أنشئ بواسطة', sortable: true },
          { key: 'notes', header: 'ملاحظات' },
        ]}
        data={filteredEntries as unknown as Record<string, unknown>[]}
        rowActions={{
          onView: (row) => setShowDetail(row as unknown as JournalEntry),
          onEdit: (row) => advanceStatus(row as unknown as JournalEntry),
        }}
        pageSize={6}
      />

      {/* Create Entry Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">إنشاء قيد محاسبي جديد</h3>
                <button onClick={() => setShowForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">البيان</label>
                    <input value={formDesc} onChange={(e) => setFormDesc(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" placeholder="وصف القيد" />
                  </div>
                  <div>
                    <label className="text-sm text-textSecondary mb-1 block">التاريخ</label>
                    <input type="date" value={formDate} onChange={(e) => setFormDate(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
                  </div>
                </div>
                <div>
                  <label className="text-sm text-textSecondary mb-1 block">ملاحظات</label>
                  <textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} rows={2} className="w-full px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm resize-none" />
                </div>

                {/* Rows */}
                <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                  <div className="bg-surface dark:bg-darkCard px-4 py-2 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                    <span className="text-sm font-semibold text-textPrimary dark:text-darkText">بنود القيد</span>
                    <button onClick={addRow} className="text-xs flex items-center gap-1 text-green-700 hover:text-green-800 font-medium">
                      <Plus size={14} /> إضافة بند
                    </button>
                  </div>
                  <div className="divide-y divide-uiBorder dark:divide-darkBorder">
                    {formRows.map((row, idx) => (
                      <div key={row.id} className="p-3 grid grid-cols-12 gap-2 items-end">
                        <div className="col-span-4">
                          <label className="text-[10px] text-textMuted mb-0.5 block">الحساب</label>
                          <select value={row.account} onChange={(e) => updateRow(row.id, 'account', e.target.value)} className="w-full h-9 px-2 rounded border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-xs">
                            {accounts.map((a) => <option key={a} value={a}>{a}</option>)}
                          </select>
                        </div>
                        <div className="col-span-2">
                          <label className="text-[10px] text-textMuted mb-0.5 block">مدين</label>
                          <input type="number" value={row.debit || ''} onChange={(e) => updateRow(row.id, 'debit', Number(e.target.value))} className="w-full h-9 px-2 rounded border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-xs" placeholder="0" />
                        </div>
                        <div className="col-span-2">
                          <label className="text-[10px] text-textMuted mb-0.5 block">دائن</label>
                          <input type="number" value={row.credit || ''} onChange={(e) => updateRow(row.id, 'credit', Number(e.target.value))} className="w-full h-9 px-2 rounded border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-xs" placeholder="0" />
                        </div>
                        <div className="col-span-3">
                          <label className="text-[10px] text-textMuted mb-0.5 block">البيان</label>
                          <input value={row.description} onChange={(e) => updateRow(row.id, 'description', e.target.value)} className="w-full h-9 px-2 rounded border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-xs" />
                        </div>
                        <div className="col-span-1 flex justify-end">
                          <button onClick={() => removeRow(row.id)} className="w-7 h-7 rounded flex items-center justify-center text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Balance Check */}
                <div className={`p-4 rounded-lg border-2 transition-colors ${
                  isBalanced
                    ? 'bg-green-50 border-green-300 dark:bg-green-950/20 dark:border-green-700'
                    : 'bg-red-50 border-red-300 dark:bg-red-950/20 dark:border-red-700'
                }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-8">
                      <div>
                        <p className="text-xs text-textSecondary">إجمالي مدين</p>
                        <p className={`text-lg font-bold ${totalDebit === totalCredit ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>{formatCurrency(totalDebit)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-textSecondary">إجمالي دائن</p>
                        <p className={`text-lg font-bold ${totalDebit === totalCredit ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>{formatCurrency(totalCredit)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {isBalanced ? (
                        <span className="flex items-center gap-1 text-green-700 dark:text-green-400 text-sm font-semibold">
                          <CheckCircle2 size={16} /> القيد متوازن
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-red-700 dark:text-red-400 text-sm font-semibold">
                          <AlertTriangle size={16} /> فرق: {formatCurrency(Math.abs(totalDebit - totalCredit))}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-5 border-t border-uiBorder dark:border-darkBorder flex justify-end gap-2">
                <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder dark:border-darkBorder text-sm text-textSecondary hover:bg-surface dark:hover:bg-darkCard transition-colors">إلغاء</button>
                <button
                  onClick={handleSave}
                  disabled={!isBalanced || !formDesc}
                  className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors flex items-center gap-1"
                >
                  <Send size={14} />
                  حفظ القيد
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Entry Detail Modal */}
      <AnimatePresence>
        {showDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowDetail(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <div>
                  <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{showDetail.number}</h3>
                  <p className="text-xs text-textMuted">{showDetail.date}</p>
                </div>
                <div className="flex items-center gap-2">
                  {statusBadge(showDetail.status)}
                  <button onClick={() => setShowDetail(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                    <X size={18} />
                  </button>
                </div>
              </div>
              <div className="p-5 space-y-4">
                <p className="text-sm text-textPrimary dark:text-darkText font-medium">{showDetail.description}</p>
                <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-surface dark:bg-darkCard">
                      <tr>
                        <th className="px-3 py-2 text-right text-xs font-semibold text-textSecondary">الحساب</th>
                        <th className="px-3 py-2 text-right text-xs font-semibold text-textSecondary">مدين</th>
                        <th className="px-3 py-2 text-right text-xs font-semibold text-textSecondary">دائن</th>
                        <th className="px-3 py-2 text-right text-xs font-semibold text-textSecondary">البيان</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-uiBorder dark:divide-darkBorder">
                      {showDetail.rows.map((r) => (
                        <tr key={r.id}>
                          <td className="px-3 py-2 text-sm text-textPrimary dark:text-darkText">{r.account}</td>
                          <td className="px-3 py-2 text-sm text-green-600 font-medium">{r.debit ? formatCurrency(r.debit) : '—'}</td>
                          <td className="px-3 py-2 text-sm text-amber-600 font-medium">{r.credit ? formatCurrency(r.credit) : '—'}</td>
                          <td className="px-3 py-2 text-sm text-textSecondary">{r.description}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-surface dark:bg-darkCard border-t border-uiBorder dark:border-darkBorder">
                      <tr>
                        <td className="px-3 py-2 text-xs font-bold text-textPrimary dark:text-darkText">الإجمالي</td>
                        <td className="px-3 py-2 text-xs font-bold text-green-600">{formatCurrency(showDetail.totalDebit)}</td>
                        <td className="px-3 py-2 text-xs font-bold text-amber-600">{formatCurrency(showDetail.totalCredit)}</td>
                        <td />
                      </tr>
                    </tfoot>
                  </table>
                </div>
                <div className="flex justify-between text-xs text-textSecondary">
                  <span>أنشئ بواسطة: {showDetail.createdBy}</span>
                  <span>ملاحظات: {showDetail.notes}</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
