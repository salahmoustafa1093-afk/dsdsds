import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Building2, Globe, Monitor, Bell, Moon, Sun, Smartphone,
  Save, Upload, Check
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';

export default function SettingsGeneralPage() {
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<'company' | 'system' | 'display' | 'notifications'>('company');

  /* Company info */
  const [companyName, setCompanyName] = useState('Golden Farmonia Fidex');
  const [taxNumber, setTaxNumber] = useState('123-456-789');
  const [commercialRegister, setCommercialRegister] = useState('145678');
  const [address, setAddress] = useState('القاهرة، مصر');
  const [phone, setPhone] = useState('02-12345678');
  const [email, setEmail] = useState('info@goldenfarmonia.com');

  /* System settings */
  const [dateFormat, setDateFormat] = useState('DD/MM/YYYY');
  const [timezone, setTimezone] = useState('Africa/Cairo');
  const [currency, setCurrency] = useState('EGP');
  const [language, setLanguage] = useState('ar');
  const [fiscalYear, setFiscalYear] = useState('01-01');

  /* Display settings */
  const [theme, setTheme] = useState<'light' | 'dark' | 'auto'>('light');
  const [isRTL, setIsRTL] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  /* Notification settings */
  const [emailNotif, setEmailNotif] = useState(true);
  const [smsNotif, setSmsNotif] = useState(false);
  const [pushNotif, setPushNotif] = useState(true);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const tabs = [
    { key: 'company' as const, label: 'بيانات الشركة', icon: Building2 },
    { key: 'system' as const, label: 'إعدادات النظام', icon: Globe },
    { key: 'display' as const, label: 'إعدادات العرض', icon: Monitor },
    { key: 'notifications' as const, label: 'الإشعارات', icon: Bell },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="الإعدادات العامة"
        subtitle="إدارة بيانات الشركة وإعدادات النظام"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الإعدادات', path: '/settings' },
          { label: 'عام' },
        ]}
      >
        <button
          onClick={handleSave}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors"
        >
          {saved ? <Check size={16} /> : <Save size={16} />}
          <span>{saved ? 'تم الحفظ' : 'حفظ'}</span>
        </button>
      </PageHeader>

      {/* Tabs */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-1 flex gap-1 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              activeTab === tab.key
                ? 'bg-green-700 text-white'
                : 'text-textSecondary hover:text-textPrimary hover:bg-surface dark:text-darkTextSec dark:hover:bg-darkCard'
            }`}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Company Info */}
      {activeTab === 'company' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">بيانات الشركة</h3>
          {/* Logo Upload */}
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 rounded-xl border-2 border-dashed border-uiBorder dark:border-darkBorder flex flex-col items-center justify-center bg-surface dark:bg-darkCard cursor-pointer hover:border-green-500 transition-colors">
              <Upload size={20} className="text-textMuted" />
              <span className="text-[10px] text-textMuted mt-1">شعار الشركة</span>
            </div>
            <div>
              <p className="text-sm text-textPrimary dark:text-darkText font-medium">رفع شعار الشركة</p>
              <p className="text-xs text-textMuted">PNG, JPG حتى 2MB</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-textSecondary mb-1 block">اسم الشركة</label>
              <input value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">الرقم الضريبي</label>
              <input value={taxNumber} onChange={(e) => setTaxNumber(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">السجل التجاري</label>
              <input value={commercialRegister} onChange={(e) => setCommercialRegister(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">البريد الإلكتروني</label>
              <input value={email} onChange={(e) => setEmail(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">الهاتف</label>
              <input value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">العنوان</label>
              <input value={address} onChange={(e) => setAddress(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
          </div>
        </motion.div>
      )}

      {/* System Settings */}
      {activeTab === 'system' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">إعدادات النظام</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-textSecondary mb-1 block">صيغة التاريخ</label>
              <select value={dateFormat} onChange={(e) => setDateFormat(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                <option>DD/MM/YYYY</option>
                <option>MM/DD/YYYY</option>
                <option>YYYY-MM-DD</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">المنطقة الزمنية</label>
              <select value={timezone} onChange={(e) => setTimezone(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                <option value="Africa/Cairo">Africa/Cairo (GMT+2)</option>
                <option value="Asia/Riyadh">Asia/Riyadh (GMT+3)</option>
                <option value="UTC">UTC</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">العملة</label>
              <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                <option value="EGP">جنيه مصري (EGP)</option>
                <option value="USD">دولار أمريكي (USD)</option>
                <option value="SAR">ريال سعودي (SAR)</option>
                <option value="AED">درهم إماراتي (AED)</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">اللغة</label>
              <select value={language} onChange={(e) => setLanguage(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                <option value="ar">العربية</option>
                <option value="en">English</option>
              </select>
            </div>
            <div>
              <label className="text-sm text-textSecondary mb-1 block">بداية السنة المالية</label>
              <input type="date" value={`2025-${fiscalYear}`} onChange={(e) => setFiscalYear(e.target.value.slice(5))} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm" />
            </div>
          </div>
        </motion.div>
      )}

      {/* Display Settings */}
      {activeTab === 'display' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-5"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">إعدادات العرض</h3>
          {/* Theme */}
          <div>
            <label className="text-sm text-textSecondary mb-2 block">السمة</label>
            <div className="flex gap-3">
              {([
                { key: 'light' as const, label: 'فاتح', icon: Sun },
                { key: 'dark' as const, label: 'داكن', icon: Moon },
                { key: 'auto' as const, label: 'تلقائي', icon: Monitor },
              ]).map((t) => (
                <button
                  key={t.key}
                  onClick={() => setTheme(t.key)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-sm font-medium transition-colors ${
                    theme === t.key
                      ? 'border-green-600 bg-green-50 text-green-700 dark:bg-green-950/20 dark:text-green-400'
                      : 'border-uiBorder dark:border-darkBorder text-textPrimary dark:text-darkText hover:bg-surface dark:hover:bg-darkCard'
                  }`}
                >
                  <t.icon size={16} />
                  {t.label}
                </button>
              ))}
            </div>
          </div>
          {/* RTL Toggle */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-surface dark:bg-darkCard">
            <div className="flex items-center gap-3">
              <Globe size={18} className="text-green-600" />
              <div>
                <p className="text-sm font-medium text-textPrimary dark:text-darkText">اتجاه RTL</p>
                <p className="text-xs text-textSecondary">الواجهة من اليمين لليسار</p>
              </div>
            </div>
            <button
              onClick={() => setIsRTL(!isRTL)}
              className={`w-12 h-6 rounded-full transition-colors relative ${isRTL ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'}`}
            >
              <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${isRTL ? 'right-0.5' : 'left-0.5'}`} />
            </button>
          </div>
          {/* Sidebar Collapsed */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-surface dark:bg-darkCard">
            <div className="flex items-center gap-3">
              <Monitor size={18} className="text-green-600" />
              <div>
                <p className="text-sm font-medium text-textPrimary dark:text-darkText">الشريط الجانبي مطوي افتراضياً</p>
                <p className="text-xs text-textSecondary">بدء التطبيق بالشريط مطوي</p>
              </div>
            </div>
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className={`w-12 h-6 rounded-full transition-colors relative ${sidebarCollapsed ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'}`}
            >
              <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${sidebarCollapsed ? 'right-0.5' : 'left-0.5'}`} />
            </button>
          </div>
        </motion.div>
      )}

      {/* Notification Settings */}
      {activeTab === 'notifications' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 space-y-4"
        >
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">إعدادات الإشعارات</h3>
          {/* Email */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-surface dark:bg-darkCard">
            <div className="flex items-center gap-3">
              <Bell size={18} className="text-blue-600" />
              <div>
                <p className="text-sm font-medium text-textPrimary dark:text-darkText">إشعارات البريد الإلكتروني</p>
                <p className="text-xs text-textSecondary">استلام إشعارات عبر البريد الإلكتروني</p>
              </div>
            </div>
            <button
              onClick={() => setEmailNotif(!emailNotif)}
              className={`w-12 h-6 rounded-full transition-colors relative ${emailNotif ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'}`}
            >
              <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${emailNotif ? 'right-0.5' : 'left-0.5'}`} />
            </button>
          </div>
          {/* SMS */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-surface dark:bg-darkCard">
            <div className="flex items-center gap-3">
              <Smartphone size={18} className="text-amber-600" />
              <div>
                <p className="text-sm font-medium text-textPrimary dark:text-darkText">إشعارات SMS</p>
                <p className="text-xs text-textSecondary">استلام إشعارات عبر الرسائل القصيرة</p>
              </div>
            </div>
            <button
              onClick={() => setSmsNotif(!smsNotif)}
              className={`w-12 h-6 rounded-full transition-colors relative ${smsNotif ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'}`}
            >
              <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${smsNotif ? 'right-0.5' : 'left-0.5'}`} />
            </button>
          </div>
          {/* Push */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-surface dark:bg-darkCard">
            <div className="flex items-center gap-3">
              <Monitor size={18} className="text-green-600" />
              <div>
                <p className="text-sm font-medium text-textPrimary dark:text-darkText">إشعارات Push</p>
                <p className="text-xs text-textSecondary">إشعارات فورية في المتصفح</p>
              </div>
            </div>
            <button
              onClick={() => setPushNotif(!pushNotif)}
              className={`w-12 h-6 rounded-full transition-colors relative ${pushNotif ? 'bg-green-600' : 'bg-gray-300 dark:bg-gray-600'}`}
            >
              <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${pushNotif ? 'right-0.5' : 'left-0.5'}`} />
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
