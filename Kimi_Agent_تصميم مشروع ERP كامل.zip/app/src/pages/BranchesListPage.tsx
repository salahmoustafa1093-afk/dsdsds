import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Building2, Plus, X, Eye, MapPin, Users, Warehouse, TrendingUp, Phone, UserCircle, Filter,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// ─── Types ──────────────────────────────────────────────
interface Branch {
  id: string;
  code: string;
  name: string;
  city: string;
  manager: string;
  employees: number;
  warehouseCount: number;
  monthlyRevenue: number;
  status: string;
  address: string;
  phone: string;
  targetRevenue: number;
}

// ─── Mock Data ──────────────────────────────────────────
const branchesData: Branch[] = [
  { id: 'B-001', code: 'CAI-01', name: 'الفرع الرئيسي - القاهرة', city: 'القاهرة', manager: 'محمد أحمد', employees: 25, warehouseCount: 3, monthlyRevenue: 3200000, status: 'نشط', address: '١٢ شارع رمسيس، القاهرة', phone: '٠٢٢٥٧٨٩٠٠٠', targetRevenue: 3000000 },
  { id: 'B-002', code: 'ALX-01', name: 'فرع الإسكندرية', city: 'الإسكندرية', manager: 'أحمد علي', employees: 18, warehouseCount: 2, monthlyRevenue: 2100000, status: 'نشط', address: '٤٥ شارع سعد زغلول، الإسكندرية', phone: '٠٣٣٤٥٦٧٨٩', targetRevenue: 2200000 },
  { id: 'B-003', code: 'TAN-01', name: 'فرع طنطا', city: 'طنطا', manager: 'محمود سالم', employees: 12, warehouseCount: 1, monthlyRevenue: 1800000, status: 'نشط', address: '٨ شارع الجيش، طنطا', phone: '٠٤٠٣٣٣٤٤٥٥', targetRevenue: 1700000 },
  { id: 'B-004', code: 'MAN-01', name: 'فرع المنصورة', city: 'المنصورة', manager: 'خالد عمر', employees: 10, warehouseCount: 1, monthlyRevenue: 1450000, status: 'نشط', address: '٢٠ شارع الجمهورية، المنصورة', phone: '٠٥٠٢٢٣٣٤٤٥', targetRevenue: 1500000 },
];

const zoneCards = [
  { city: 'القاهرة', color: 'bg-green-700', count: 1, revenue: '٣.٢ مليون' },
  { city: 'الإسكندرية', color: 'bg-blue-600', count: 1, revenue: '٢.١ مليون' },
  { city: 'طنطا', color: 'bg-gold-500', count: 1, revenue: '١.٨ مليون' },
  { city: 'المنصورة', color: 'bg-purple-600', count: 1, revenue: '١.٤ مليون' },
];

const cityOptions = ['الكل', 'القاهرة', 'الإسكندرية', 'طنطا', 'المنصورة'];
const statusOptions = ['الكل', 'نشط', 'قيد الإنشاء', 'مغلق'];
const statusColors: Record<string, string> = {
  'نشط': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'قيد الإنشاء': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'مغلق': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

export default function BranchesListPage() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(null);
  const [filterCity, setFilterCity] = useState('الكل');
  const [filterStatus, setFilterStatus] = useState('الكل');

  const totalBranches = branchesData.length;
  const activeCount = branchesData.filter(b => b.status === 'نشط').length;
  const underConstruction = branchesData.filter(b => b.status === 'قيد الإنشاء').length;
  const closedCount = branchesData.filter(b => b.status === 'مغلق').length;

  const filtered = branchesData.filter(b => {
    const cityMatch = filterCity === 'الكل' || b.city === filterCity;
    const statusMatch = filterStatus === 'الكل' || b.status === filterStatus;
    return cityMatch && statusMatch;
  });

  const salesChartData = branchesData.map(b => ({ name: b.city, revenue: b.monthlyRevenue, target: b.targetRevenue }));

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="دليل الفروع"
        subtitle="إدارة وفروع الشركة ومواقعها"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الفروع', path: '/branches' },
          { label: 'الفروع' },
        ]}
      >
        <button onClick={() => setShowAddForm(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Plus size={16} /> إضافة فرع
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي الفروع" value={String(totalBranches)} icon={Building2} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="نشطة" value={String(activeCount)} icon={TrendingUp} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.1} />
        <KPICard title="قيد الإنشاء" value={String(underConstruction)} icon={Building2} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.2} />
        <KPICard title="مغلقة" value={String(closedCount)} icon={Building2} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Zone Cards */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {zoneCards.map((zone, idx) => (
          <motion.div key={zone.city} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.1 }}
            className={`${zone.color} rounded-xl p-5 text-white shadow-md`}
          >
            <MapPin size={20} className="mb-2 opacity-80" />
            <h4 className="text-lg font-bold">{zone.city}</h4>
            <p className="text-xs opacity-80 mt-1">{zone.count} فرع</p>
            <p className="text-sm font-semibold mt-2">{zone.revenue} ج.م/شهر</p>
          </motion.div>
        ))}
      </motion.div>

      {/* Filters */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 text-textSecondary text-sm"><Filter size={14} /> تصفية:</div>
          <select value={filterCity} onChange={e => setFilterCity(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
            {cityOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'المدينة' : o}</option>)}
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
            {statusOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'الحالة' : o}</option>)}
          </select>
        </div>
      </motion.div>

      {/* Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['الكود', 'الاسم', 'المدينة', 'المدير', 'الموظفين', 'المخازن', 'الإيراد الشهري', 'الحالة'].map(h => (
                  <th key={h} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                ))}
                <th className="px-4 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-4 py-3 text-sm font-semibold text-textPrimary dark:text-darkText">{row.code}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText font-medium">{row.name}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.city}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.manager}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.employees}</td>
                  <td className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">{row.warehouseCount}</td>
                  <td className="px-4 py-3 text-sm text-green-700 font-semibold">{row.monthlyRevenue.toLocaleString()}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[row.status]}`}>{row.status}</span></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setSelectedBranch(row)} className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors" title="عرض التفاصيل"><Eye size={16} /></button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Add Branch Modal */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowAddForm(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">إضافة فرع جديد</h3>
                <button onClick={() => setShowAddForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الكود</label><input type="text" placeholder="مثال: CAI-02" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الاسم</label><input type="text" placeholder="اسم الفرع" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">المدينة</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>القاهرة</option><option>الإسكندرية</option><option>طنطا</option><option>المنصورة</option><option>أخرى</option></select></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">المدير</label><input type="text" placeholder="اسم المدير" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">العنوان</label><input type="text" placeholder="العنوان بالتفصيل" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الهاتف</label><input type="text" placeholder="رقم الهاتف" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">عدد المخازن</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">الإيراد المستهدف</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                <div className="flex justify-end gap-2 pt-2">
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">إلغاء</button>
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors">حفظ</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Branch Detail Modal */}
      <AnimatePresence>
        {selectedBranch && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setSelectedBranch(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center"><Building2 size={20} className="text-green-700" /></div>
                  <div>
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">{selectedBranch.name}</h3>
                    <p className="text-xs text-textMuted">{selectedBranch.code}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[selectedBranch.status]}`}>{selectedBranch.status}</span>
                  <button onClick={() => setSelectedBranch(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
                </div>
              </div>
              <div className="p-5 space-y-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><Users size={16} className="mx-auto text-blue-500 mb-1" /><p className="text-lg font-bold text-textPrimary dark:text-darkText">{selectedBranch.employees}</p><p className="text-xs text-textMuted">موظف</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><Warehouse size={16} className="mx-auto text-gold-500 mb-1" /><p className="text-lg font-bold text-textPrimary dark:text-darkText">{selectedBranch.warehouseCount}</p><p className="text-xs text-textMuted">مخزن</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><TrendingUp size={16} className="mx-auto text-green-500 mb-1" /><p className="text-lg font-bold text-green-700">{(selectedBranch.monthlyRevenue / 1000000).toFixed(1)}M</p><p className="text-xs text-textMuted">إيراد شهري</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><MapPin size={16} className="mx-auto text-purple-500 mb-1" /><p className="text-lg font-bold text-textPrimary dark:text-darkText">{selectedBranch.city}</p><p className="text-xs text-textMuted">المدينة</p></div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-textMuted">المدير:</span> <span className="text-textPrimary dark:text-darkText">{selectedBranch.manager}</span></div>
                  <div><span className="text-textMuted">الهاتف:</span> <span className="text-textPrimary dark:text-darkText">{selectedBranch.phone}</span></div>
                  <div className="col-span-2"><span className="text-textMuted">العنوان:</span> <span className="text-textPrimary dark:text-darkText">{selectedBranch.address}</span></div>
                </div>
                {/* Monthly Sales Chart */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2"><TrendingUp size={16} className="text-green-600" /> المبيعات الشهرية</h4>
                  <div className="h-48 bg-surface dark:bg-darkCard rounded-lg p-3">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={[{ month: 'سبتمبر', sales: selectedBranch.monthlyRevenue * 0.9 }, { month: 'أكتوبر', sales: selectedBranch.monthlyRevenue * 0.95 }, { month: 'نوفمبر', sales: selectedBranch.monthlyRevenue * 0.97 }, { month: 'ديسمبر', sales: selectedBranch.monthlyRevenue * 1.02 }, { month: 'يناير', sales: selectedBranch.monthlyRevenue }]}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} />
                        <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                        <Bar dataKey="sales" name="المبيعات" fill="#14a86a" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
