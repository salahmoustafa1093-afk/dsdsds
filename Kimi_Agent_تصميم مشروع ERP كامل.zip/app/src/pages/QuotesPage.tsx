// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import {
  FileText,
  Calendar,
  CheckCircle,
  Clock,
  Search,
  Plus,
  Eye,
  Edit3,
  Trash2,
  Send,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Copy,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

/* ──────────────────────────── mock data ──────────────────────────── */

interface QuoteItem {
  id: string;
  number: string;
  date: string;
  customer: string;
  products: { name: string; qty: number; unitPrice: number; total: number }[];
  total: number;
  validUntil: string;
  status: 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired';
  notes: string;
  createdBy: string;
}

const CUSTOMERS = [
  'مزارع الصفا للدواجن',
  'شركة النور للتسويق',
  'مزرعة الفيوم',
  'مطاحن الأمل',
  'شركة البديع للدواجن',
  'مزارع السلام',
  'شركة البركة للتجارة',
  'مزرعة الجزيرة',
  'مطاحن النصر',
  'شركة الرحمة للتسويق',
  'مزارع التوفيق',
  'شركة الأمانة للتجارة',
  'مزرعة الهنا',
  'مطاحن البركة',
  'شركة الفلاح للمواشي',
];

const PRODUCTS = [
  { name: 'أعلاف دواجن بادئ', unitPrice: 450 },
  { name: 'أعلاف دواجن نامي', unitPrice: 650 },
  { name: 'أعلاف دواجن ناهي', unitPrice: 750 },
  { name: 'ذرة صفراء', unitPrice: 800 },
  { name: 'كسب فول صويا', unitPrice: 1400 },
  { name: 'ردة قمح', unitPrice: 280 },
  { name: 'نخالة قمح', unitPrice: 180 },
  { name: 'مسحوق عظام', unitPrice: 12 },
  { name: 'حجر جيري', unitPrice: 5 },
  { name: 'خلطة فيتامينات', unitPrice: 350 },
];

const QUOTES: QuoteItem[] = [
  { id: '1', number: 'QOT-001', date: '2025-06-20', customer: 'مزارع الصفا للدواجن', products: [{ name: 'أعلاف دواجن بادئ', qty: 100, unitPrice: 440, total: 44000 }, { name: 'أعلاف دواجن نامي', qty: 50, unitPrice: 640, total: 32000 }], total: 76000, validUntil: '2025-06-27', status: 'sent', notes: 'عرض خاص للكميات الكبيرة', createdBy: 'أحمد محمود' },
  { id: '2', number: 'QOT-002', date: '2025-06-20', customer: 'شركة النور للتسويق', products: [{ name: 'كسب فول صويا', qty: 100, unitPrice: 1380, total: 138000 }, { name: 'ذرة صفراء', qty: 50, unitPrice: 780, total: 39000 }], total: 177000, validUntil: '2025-07-05', status: 'draft', notes: '', createdBy: 'سعيد فؤاد' },
  { id: '3', number: 'QOT-003', date: '2025-06-19', customer: 'مزرعة الفيوم', products: [{ name: 'أعلاف دواجن ناهي', qty: 30, unitPrice: 730, total: 21900 }], total: 21900, validUntil: '2025-06-26', status: 'accepted', notes: 'تم القبول - إنشاء فاتورة', createdBy: 'أحمد محمود' },
  { id: '4', number: 'QOT-004', date: '2025-06-19', customer: 'مطاحن الأمل', products: [{ name: 'ذرة صفراء', qty: 150, unitPrice: 790, total: 118500 }], total: 118500, validUntil: '2025-07-03', status: 'sent', notes: '', createdBy: 'محمد رضا' },
  { id: '5', number: 'QOT-005', date: '2025-06-18', customer: 'شركة البديع للدواجن', products: [{ name: 'أعلاف دواجن بادئ', qty: 200, unitPrice: 430, total: 86000 }, { name: 'أعلاف دواجن نامي', qty: 200, unitPrice: 630, total: 126000 }, { name: 'كسب فول صويا', qty: 100, unitPrice: 1350, total: 135000 }], total: 347000, validUntil: '2025-07-02', status: 'accepted', notes: 'عميل مميز - خصم إضافي', createdBy: 'أحمد محمود' },
  { id: '6', number: 'QOT-006', date: '2025-06-18', customer: 'مزارع السلام', products: [{ name: 'ردة قمح', qty: 80, unitPrice: 270, total: 21600 }], total: 21600, validUntil: '2025-06-15', status: 'expired', notes: 'انتهت صلاحية العرض', createdBy: 'خالد حسن' },
  { id: '7', number: 'QOT-007', date: '2025-06-17', customer: 'شركة البركة للتجارة', products: [{ name: 'كسب فول صويا', qty: 60, unitPrice: 1390, total: 83400 }], total: 83400, validUntil: '2025-07-01', status: 'rejected', notes: 'السعر غير مناسب - سيتفاوض مرة أخرى', createdBy: 'سعيد فؤاد' },
  { id: '8', number: 'QOT-008', date: '2025-06-17', customer: 'مزرعة الجزيرة', products: [{ name: 'أعلاف دواجن نامي', qty: 70, unitPrice: 640, total: 44800 }], total: 44800, validUntil: '2025-06-24', status: 'sent', notes: '', createdBy: 'أحمد محمود' },
  { id: '9', number: 'QOT-009', date: '2025-06-16', customer: 'مطاحن النصر', products: [{ name: 'ذرة صفراء', qty: 250, unitPrice: 770, total: 192500 }], total: 192500, validUntil: '2025-06-30', status: 'draft', notes: 'في انتظار موافقة الإدارة', createdBy: 'محمد رضا' },
  { id: '10', number: 'QOT-010', date: '2025-06-16', customer: 'شركة الرحمة للتسويق', products: [{ name: 'أعلاف دواجن ناهي', qty: 100, unitPrice: 740, total: 74000 }, { name: 'ردة قمح', qty: 150, unitPrice: 285, total: 42750 }], total: 116750, validUntil: '2025-06-23', status: 'sent', notes: '', createdBy: 'خالد حسن' },
  { id: '11', number: 'QOT-011', date: '2025-06-15', customer: 'مزارع التوفيق', products: [{ name: 'أعلاف دواجن بادئ', qty: 80, unitPrice: 445, total: 35600 }], total: 35600, validUntil: '2025-06-22', status: 'expired', notes: 'لم يتم الرد', createdBy: 'أحمد محمود' },
  { id: '12', number: 'QOT-012', date: '2025-06-14', customer: 'شركة الأمانة للتجارة', products: [{ name: 'كسب فول صويا', qty: 180, unitPrice: 1360, total: 244800 }, { name: 'ذرة صفراء', qty: 80, unitPrice: 775, total: 62000 }], total: 306800, validUntil: '2025-06-28', status: 'accepted', notes: 'تم تحويل لأمر بيع', createdBy: 'سعيد فؤاد' },
];

const STATUS_MAP: Record<string, { label: string; color: string; bg: string }> = {
  draft: { label: 'مسودة', color: 'text-gray-700', bg: 'bg-gray-100 dark:bg-gray-900/30' },
  sent: { label: 'مرسل', color: 'text-blue-700', bg: 'bg-blue-100 dark:bg-blue-900/30' },
  accepted: { label: 'مقبول', color: 'text-green-700', bg: 'bg-green-100 dark:bg-green-900/30' },
  rejected: { label: 'مرفوض', color: 'text-red-700', bg: 'bg-red-100 dark:bg-red-900/30' },
  expired: { label: 'منتهي', color: 'text-orange-700', bg: 'bg-orange-100 dark:bg-orange-900/30' },
};

/* ──────────────────────────── component ──────────────────────────── */

export default function QuotesPage() {
  const [quotes, setQuotes] = useState<QuoteItem[]>(QUOTES);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(1);

  const pageSize = 8;

  const filtered = useMemo(() => {
    return quotes.filter((q) => {
      const qu = search.trim();
      const matchSearch = qu === '' || q.number.includes(qu) || q.customer.includes(qu) || q.createdBy.includes(qu);
      const matchStatus = statusFilter === 'all' || q.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [quotes, search, statusFilter]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const todayQuotes = quotes.filter((q) => q.date === '2025-06-20').length;
  const monthQuotes = quotes.length;
  const acceptedQuotes = quotes.filter((q) => q.status === 'accepted').length;

  const resetFilters = () => {
    setSearch('');
    setStatusFilter('all');
    setPage(1);
  };

  const deleteQuote = (id: string) => {
    setQuotes((prev) => prev.filter((q) => q.id !== id));
  };

  const handleCreate = (newQ: QuoteItem) => {
    setQuotes((prev) => [newQ, ...prev]);
  };

  const formatEGP = (n: number) => n.toLocaleString('ar-EG') + ' ج.م';

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="عروض الأسعار"
        subtitle="إنشاء وإدارة عروض أسعار العملاء"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'المبيعات', path: '/sales' }, { label: 'عروض أسعار' }]}
      >
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-[#0a4a30] hover:bg-[#0d6b43] text-white gap-2">
              <Plus size={16} />
              عرض سعر جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle className="text-right text-lg">إنشاء عرض سعر جديد</DialogTitle>
            </DialogHeader>
            <QuoteForm onSave={handleCreate} />
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KPICard title="عروض اليوم" value={todayQuotes.toString()} icon={Calendar} iconBg="bg-blue-100" iconColor="text-blue-600" change={3} delay={0} />
        <KPICard title="عروض الشهر" value={monthQuotes.toString()} icon={FileText} iconBg="bg-amber-100" iconColor="text-amber-600" change={12} delay={0.1} />
        <KPICard title="العروض المقبولة" value={acceptedQuotes.toString()} icon={CheckCircle} iconBg="bg-green-100" iconColor="text-green-600" change={5} delay={0.2} />
      </div>

      {/* Filters */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <Input
                placeholder="بحث برقم العرض أو العميل..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                className="pr-9 text-right"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 text-right text-xs"><SelectValue placeholder="الحالة" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الحالات</SelectItem>
                <SelectItem value="draft">مسودة</SelectItem>
                <SelectItem value="sent">مرسل</SelectItem>
                <SelectItem value="accepted">مقبول</SelectItem>
                <SelectItem value="rejected">مرفوض</SelectItem>
                <SelectItem value="expired">منتهي</SelectItem>
              </SelectContent>
            </Select>
            {(statusFilter !== 'all' || search) && (
              <Button variant="ghost" size="sm" className="text-red-500 text-xs" onClick={resetFilters}>
                <X size={12} />
                إلغاء
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border border-gray-200 dark:border-gray-700 overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                  <TableHead className="text-right font-semibold text-xs">رقم العرض</TableHead>
                  <TableHead className="text-right font-semibold text-xs">التاريخ</TableHead>
                  <TableHead className="text-right font-semibold text-xs">العميل</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الإجمالي</TableHead>
                  <TableHead className="text-right font-semibold text-xs">صلاحية</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الحالة</TableHead>
                  <TableHead className="text-center font-semibold text-xs">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.map((q) => {
                  const sm = STATUS_MAP[q.status];
                  const isExpired = q.status === 'expired' || (new Date(q.validUntil) < new Date('2025-06-20'));
                  return (
                    <TableRow key={q.id} className={cn('hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors', isExpired && 'opacity-60')}>
                      <TableCell className="font-mono text-xs font-medium">{q.number}</TableCell>
                      <TableCell className="text-xs text-gray-500">{q.date}</TableCell>
                      <TableCell className="text-sm font-medium">{q.customer}</TableCell>
                      <TableCell className="text-sm font-semibold text-[#0a4a30]">{formatEGP(q.total)}</TableCell>
                      <TableCell className="text-xs flex items-center gap-1">
                        <Calendar size={10} className={isExpired ? 'text-red-400' : 'text-green-400'} />
                        <span className={isExpired ? 'text-red-500' : 'text-gray-500'}>
                          {isExpired ? 'منتهي: ' : 'حتى: '}
                          {q.validUntil}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge className={cn('text-[10px] border-0', sm.bg, sm.color)}>
                          {sm.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          {q.status === 'draft' && (
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600" title="إرسال">
                              <Send size={14} />
                            </Button>
                          )}
                          {q.status === 'sent' && (
                            <>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600" title="قبول">
                                <CheckCircle2 size={14} />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" title="رفض">
                                <XCircle size={14} />
                              </Button>
                            </>
                          )}
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600">
                            <Eye size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-500">
                            <Copy size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => deleteQuote(q.id)}>
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {paged.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-12 text-gray-400">
                      لا توجد عروض مطابقة
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {/* Pagination */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 dark:border-gray-700">
            <span className="text-xs text-gray-500">
              عرض {filtered.length > 0 ? (page - 1) * pageSize + 1 : 0} - {Math.min(page * pageSize, filtered.length)} من {filtered.length}
            </span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(1)}>الأولى</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(page - 1)}>السابق</Button>
              <span className="text-xs px-2">{page} / {totalPages}</span>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(page + 1)}>التالي</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(totalPages)}>الأخيرة</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ──────────────────────────── Quote Form ──────────────────────────── */

function QuoteForm({ onSave }: { onSave: (q: QuoteItem) => void }) {
  const [customer, setCustomer] = useState('');
  const [validDays, setValidDays] = useState(7);
  const [notes, setNotes] = useState('');
  const [lines, setLines] = useState([{ name: '', qty: 1, unitPrice: 0 }]);

  const addLine = () => setLines([...lines, { name: '', qty: 1, unitPrice: 0 }]);
  const removeLine = (i: number) => setLines(lines.filter((_, idx) => idx !== i));
  const updateLine = (i: number, field: string, value: string | number) => {
    const nl = [...lines];
    nl[i] = { ...nl[i], [field]: value };
    if (field === 'name') {
      const prod = PRODUCTS.find((p) => p.name === value);
      if (prod) nl[i].unitPrice = prod.unitPrice;
    }
    setLines(nl);
  };

  const lineTotal = (l: typeof lines[0]) => l.qty * l.unitPrice;
  const grandTotal = lines.reduce((s, l) => s + lineTotal(l), 0);

  const getValidUntil = () => {
    const d = new Date();
    d.setDate(d.getDate() + validDays);
    return d.toISOString().split('T')[0];
  };

  const handleSubmit = () => {
    onSave({
      id: Date.now().toString(),
      number: `QOT-${String(QUOTES.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      customer: customer || 'عميل جديد',
      products: lines.map((l) => ({ ...l, total: lineTotal(l) })),
      total: grandTotal,
      validUntil: getValidUntil(),
      status: 'draft',
      notes,
      createdBy: 'المستخدم الحالي',
    });
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">العميل *</Label>
          <Select value={customer} onValueChange={setCustomer}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر العميل" /></SelectTrigger>
            <SelectContent>{CUSTOMERS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">مدة الصلاحية (يوم)</Label>
          <Input type="number" value={validDays} onChange={(e) => setValidDays(parseInt(e.target.value) || 7)} className="text-center" />
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs font-semibold">بنود العرض</Label>
          <Button type="button" variant="outline" size="sm" onClick={addLine} className="h-7 text-xs gap-1">
            <Plus size={12} />
            بند جديد
          </Button>
        </div>
        <div className="space-y-2 max-h-[250px] overflow-auto pr-1">
          {lines.map((line, i) => (
            <Card key={i} className="p-2 border border-gray-200">
              <div className="grid grid-cols-12 gap-2 items-end">
                <div className="col-span-5">
                  <Label className="text-[10px] text-gray-500">المنتج</Label>
                  <Select value={line.name} onValueChange={(v) => updateLine(i, 'name', v)}>
                    <SelectTrigger className="text-right h-8 text-xs"><SelectValue placeholder="اختر" /></SelectTrigger>
                    <SelectContent>{PRODUCTS.map((p) => <SelectItem key={p.name} value={p.name}>{p.name} ({p.unitPrice} ج.م)</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label className="text-[10px] text-gray-500">الكمية</Label>
                  <Input type="number" value={line.qty} onChange={(e) => updateLine(i, 'qty', parseInt(e.target.value) || 0)} className="h-8 text-xs text-center" />
                </div>
                <div className="col-span-2">
                  <Label className="text-[10px] text-gray-500">السعر</Label>
                  <Input type="number" value={line.unitPrice} onChange={(e) => updateLine(i, 'unitPrice', parseFloat(e.target.value) || 0)} className="h-8 text-xs text-center" />
                </div>
                <div className="col-span-2 pb-1">
                  <span className="text-xs font-semibold text-[#0a4a30]">{lineTotal(line).toLocaleString('ar-EG')} ج.م</span>
                </div>
                <div className="col-span-1 pb-1">
                  {lines.length > 1 && (
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500" onClick={() => removeLine(i)}>
                      <Trash2 size={12} />
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <div className="border-t pt-3 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-500">صلاحية العرض حتى: <strong className="text-[#0a4a30]">{getValidUntil()}</strong></span>
          <span className="text-lg font-bold text-[#0a4a30]">
            الإجمالي: {grandTotal.toLocaleString('ar-EG')} ج.م
          </span>
        </div>
        <div>
          <Label className="text-xs">ملاحظات</Label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full border rounded-md p-2 text-xs text-right min-h-[60px]" placeholder="ملاحظات العرض..." />
        </div>
        <Button onClick={handleSubmit} className="w-full bg-[#0a4a30] hover:bg-[#0d6b43] text-white">
          حفظ عرض السعر
        </Button>
      </div>
    </div>
  );
}
