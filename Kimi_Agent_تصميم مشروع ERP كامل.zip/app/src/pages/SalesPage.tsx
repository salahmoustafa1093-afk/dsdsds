// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import {
  ShoppingCart,
  Receipt,
  Clock,
  TrendingUp,
  Search,
  Plus,
  Eye,
  Edit3,
  Trash2,
  Filter,
  X,
  Printer,
  ChevronDown,
  Calendar,
  Package,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

/* ──────────────────────────── mock data ──────────────────────────── */

interface Invoice {
  id: string;
  number: string;
  date: string;
  customer: string;
  channel: string;
  total: number;
  status: 'paid' | 'pending' | 'credit' | 'returned';
  branch: string;
  paymentMethod: string;
  notes: string;
  items: { product: string; qty: number; unitPrice: number; discount: number; total: number }[];
}

const CHANNELS = ['قطاعي', 'جملة', 'موزعين'];
const BRANCHES = ['القاهرة', 'الإسكندرية', 'طنطا', 'المنصورة'];

const INVOICES: Invoice[] = [
  { id: '1', number: 'INV-001', date: '2025-06-20', customer: 'مزارع الصفا للدواجن', channel: 'جملة', total: 45500, status: 'paid', branch: 'القاهرة', paymentMethod: 'كاش', notes: '', items: [{ product: 'أعلاف دواجن بادئ', qty: 50, unitPrice: 450, discount: 500, total: 22000 }, { product: 'ذرة صفراء', qty: 30, unitPrice: 750, discount: 250, total: 22250 }] },
  { id: '2', number: 'INV-002', date: '2025-06-20', customer: 'شركة النور للتسويق', channel: 'موزعين', total: 128000, status: 'pending', branch: 'الإسكندرية', paymentMethod: 'تحويل بنكي', notes: 'تسليم خلال ٣ أيام', items: [{ product: 'كسب فول صويا', qty: 80, unitPrice: 1400, discount: 0, total: 112000 }, { product: 'ردة قمح', qty: 40, unitPrice: 400, discount: 0, total: 16000 }] },
  { id: '3', number: 'INV-003', date: '2025-06-19', customer: 'مزرعة الفيوم', channel: 'قطاعي', total: 18750, status: 'paid', branch: 'القاهرة', paymentMethod: 'كاش', notes: '', items: [{ product: 'أعلاف دواجن ناهي', qty: 25, unitPrice: 750, discount: 0, total: 18750 }] },
  { id: '4', number: 'INV-004', date: '2025-06-19', customer: 'مطاحن الأمل', channel: 'جملة', total: 96000, status: 'credit', branch: 'طنطا', paymentMethod: 'آجل 30 يوم', notes: '', items: [{ product: 'ذرة صفراء', qty: 120, unitPrice: 800, discount: 0, total: 96000 }] },
  { id: '5', number: 'INV-005', date: '2025-06-18', customer: 'شركة البديع للدواجن', channel: 'موزعين', total: 234000, status: 'paid', branch: 'القاهرة', paymentMethod: 'شيك', notes: '', items: [{ product: 'أعلاف دواجن بادئ', qty: 100, unitPrice: 450, discount: 2000, total: 43000 }, { product: 'أعلاف دواجن نامي', qty: 150, unitPrice: 650, discount: 2500, total: 95000 }, { product: 'كسب فول صويا', qty: 70, unitPrice: 1400, discount: 0, total: 98000 }] },
  { id: '6', number: 'INV-006', date: '2025-06-18', customer: 'مزارع السلام', channel: 'قطاعي', total: 12500, status: 'returned', branch: 'المنصورة', paymentMethod: 'كاش', notes: 'مرتجع جزئي', items: [{ product: 'ردة قمح', qty: 50, unitPrice: 250, discount: 0, total: 12500 }] },
  { id: '7', number: 'INV-007', date: '2025-06-17', customer: 'شركة البركة للتجارة', channel: 'جملة', total: 67000, status: 'paid', branch: 'الإسكندرية', paymentMethod: 'تحويل بنكي', notes: '', items: [{ product: 'كسب فول صويا', qty: 50, unitPrice: 1340, discount: 0, total: 67000 }] },
  { id: '8', number: 'INV-008', date: '2025-06-17', customer: 'مزرعة الجزيرة', channel: 'قطاعي', total: 34000, status: 'pending', branch: 'القاهرة', paymentMethod: 'كاش', notes: '', items: [{ product: 'أعلاف دواجن نامي', qty: 50, unitPrice: 680, discount: 0, total: 34000 }] },
  { id: '9', number: 'INV-009', date: '2025-06-16', customer: 'مطاحن النصر', channel: 'جملة', total: 156000, status: 'credit', branch: 'طنطا', paymentMethod: 'آجل 60 يوم', notes: 'عميل مميز', items: [{ product: 'ذرة صفراء', qty: 200, unitPrice: 780, discount: 0, total: 156000 }] },
  { id: '10', number: 'INV-010', date: '2025-06-16', customer: 'شركة الرحمة للتسويق', channel: 'موزعين', total: 89000, status: 'paid', branch: 'المنصورة', paymentMethod: 'شيك', notes: '', items: [{ product: 'أعلاف دواجن ناهي', qty: 80, unitPrice: 750, discount: 0, total: 60000 }, { product: 'ردة قمح', qty: 100, unitPrice: 290, discount: 0, total: 29000 }] },
  { id: '11', number: 'INV-011', date: '2025-06-15', customer: 'مزارع التوفيق', channel: 'قطاعي', total: 22500, status: 'paid', branch: 'القاهرة', paymentMethod: 'كاش', notes: '', items: [{ product: 'أعلاف دواجن بادئ', qty: 50, unitPrice: 450, discount: 0, total: 22500 }] },
  { id: '12', number: 'INV-012', date: '2025-06-15', customer: 'شركة الأمانة للتجارة', channel: 'جملة', total: 345000, status: 'pending', branch: 'الإسكندرية', paymentMethod: 'تحويل بنكي', notes: 'طلب خاص', items: [{ product: 'كسب فول صويا', qty: 200, unitPrice: 1380, discount: 9000, total: 267000 }, { product: 'ذرة صفراء', qty: 100, unitPrice: 780, discount: 0, total: 78000 }] },
  { id: '13', number: 'INV-013', date: '2025-06-14', customer: 'مزرعة الهنا', channel: 'قطاعي', total: 18000, status: 'credit', branch: 'القاهرة', paymentMethod: 'آجل 15 يوم', notes: '', items: [{ product: 'أعلاف دواجن نامي', qty: 30, unitPrice: 600, discount: 0, total: 18000 }] },
  { id: '14', number: 'INV-014', date: '2025-06-14', customer: 'مطاحن البركة', channel: 'جملة', total: 78000, status: 'paid', branch: 'طنطا', paymentMethod: 'كاش', notes: '', items: [{ product: 'ردة قمح', qty: 300, unitPrice: 260, discount: 0, total: 78000 }] },
  { id: '15', number: 'INV-015', date: '2025-06-13', customer: 'شركة الفلاح للمواشي', channel: 'موزعين', total: 198000, status: 'paid', branch: 'المنصورة', paymentMethod: 'شيك', notes: '', items: [{ product: 'أعلاف دواجن بادئ', qty: 120, unitPrice: 450, discount: 0, total: 54000 }, { product: 'كسب فول صويا', qty: 100, unitPrice: 1400, discount: 6000, total: 134000 }, { product: 'ذرة صفراء', qty: 20, unitPrice: 500, discount: 0, total: 10000 }] },
];

const STATUS_MAP: Record<string, { label: string; color: string; bg: string }> = {
  paid: { label: 'مدفوعة', color: 'text-green-700', bg: 'bg-green-100 dark:bg-green-900/30' },
  pending: { label: 'معلقة', color: 'text-amber-700', bg: 'bg-amber-100 dark:bg-amber-900/30' },
  credit: { label: 'آجلة', color: 'text-blue-700', bg: 'bg-blue-100 dark:bg-blue-900/30' },
  returned: { label: 'مرتجعة', color: 'text-red-700', bg: 'bg-red-100 dark:bg-red-900/30' },
};

/* ──────────────────────────── component ──────────────────────────── */

export default function SalesPage() {
  const [invoices, setInvoices] = useState<Invoice[]>(INVOICES);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [channelFilter, setChannelFilter] = useState<string>('all');
  const [branchFilter, setBranchFilter] = useState<string>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [page, setPage] = useState(1);
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const pageSize = 10;

  const filtered = useMemo(() => {
    return invoices.filter((inv) => {
      const q = search.trim();
      const matchSearch = q === '' || inv.number.includes(q) || inv.customer.includes(q);
      const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
      const matchChannel = channelFilter === 'all' || inv.channel === channelFilter;
      const matchBranch = branchFilter === 'all' || inv.branch === branchFilter;
      const matchDateFrom = !dateFrom || inv.date >= dateFrom;
      const matchDateTo = !dateTo || inv.date <= dateTo;
      return matchSearch && matchStatus && matchChannel && matchBranch && matchDateFrom && matchDateTo;
    });
  }, [invoices, search, statusFilter, channelFilter, branchFilter, dateFrom, dateTo]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const todayInvoices = invoices.filter((i) => i.date === '2025-06-20' && i.status !== 'returned');
  const monthInvoices = invoices;
  const totalSales = invoices.filter((i) => i.status !== 'returned').reduce((s, i) => s + i.total, 0);
  const pendingCount = invoices.filter((i) => i.status === 'pending').length;

  const resetFilters = () => {
    setSearch('');
    setStatusFilter('all');
    setChannelFilter('all');
    setBranchFilter('all');
    setDateFrom('');
    setDateTo('');
    setPage(1);
  };

  const deleteInvoice = (id: string) => {
    setInvoices((prev) => prev.filter((i) => i.id !== id));
  };

  const formatEGP = (n: number) => n.toLocaleString('ar-EG') + ' ج.م';

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="إدارة المبيعات"
        subtitle="فواتير المبيعات والتحصيل"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'المبيعات' }]}
      >
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-[#0a4a30] hover:bg-[#0d6b43] text-white gap-2">
              <Plus size={16} />
              فاتورة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle className="text-right text-lg">إنشاء فاتورة جديدة</DialogTitle>
            </DialogHeader>
            <CreateInvoiceForm
              onCreate={(newInv) => {
                setInvoices((prev) => [newInv, ...prev]);
              }}
            />
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="فواتير اليوم" value={todayInvoices.length.toString()} icon={Receipt} iconBg="bg-green-100" iconColor="text-green-600" change={12} delay={0} />
        <KPICard title="فواتير الشهر" value={monthInvoices.length.toString()} icon={ShoppingCart} iconBg="bg-blue-100" iconColor="text-blue-600" change={8} delay={0.1} />
        <KPICard title="إجمالي المبيعات" value={formatEGP(totalSales)} icon={TrendingUp} iconBg="bg-amber-100" iconColor="text-amber-600" change={15} delay={0.2} />
        <KPICard title="الفواتير المعلقة" value={pendingCount.toString()} icon={Clock} iconBg="bg-red-100" iconColor="text-red-600" change={-3} delay={0.3} />
      </div>

      {/* Filters */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <Input
                  placeholder="بحث برقم الفاتورة أو العميل..."
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                  className="pr-9 text-right"
                />
              </div>
              <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="gap-2">
                <Filter size={16} />
                فلترة
                <ChevronDown size={14} className={cn('transition-transform', showFilters && 'rotate-180')} />
              </Button>
              {(statusFilter !== 'all' || channelFilter !== 'all' || branchFilter !== 'all' || dateFrom || dateTo || search) && (
                <Button variant="ghost" onClick={resetFilters} className="text-red-500 gap-1">
                  <X size={14} />
                  إلغاء الفلتر
                </Button>
              )}
            </div>
            <AnimatePresence>
              {showFilters && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="flex flex-wrap gap-3 pt-2">
                    <div className="w-40">
                      <Label className="text-xs text-gray-500 mb-1 block">الحالة</Label>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="text-right"><SelectValue placeholder="الكل" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">الكل</SelectItem>
                          <SelectItem value="paid">مدفوعة</SelectItem>
                          <SelectItem value="pending">معلقة</SelectItem>
                          <SelectItem value="credit">آجلة</SelectItem>
                          <SelectItem value="returned">مرتجعة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-40">
                      <Label className="text-xs text-gray-500 mb-1 block">القناة</Label>
                      <Select value={channelFilter} onValueChange={setChannelFilter}>
                        <SelectTrigger className="text-right"><SelectValue placeholder="الكل" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">الكل</SelectItem>
                          {CHANNELS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-40">
                      <Label className="text-xs text-gray-500 mb-1 block">الفرع</Label>
                      <Select value={branchFilter} onValueChange={setBranchFilter}>
                        <SelectTrigger className="text-right"><SelectValue placeholder="الكل" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">الكل</SelectItem>
                          {BRANCHES.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="w-44">
                      <Label className="text-xs text-gray-500 mb-1 block">من تاريخ</Label>
                      <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="text-right" />
                    </div>
                    <div className="w-44">
                      <Label className="text-xs text-gray-500 mb-1 block">إلى تاريخ</Label>
                      <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="text-right" />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border border-gray-200 dark:border-gray-700 overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                  <TableHead className="text-right font-semibold text-xs">رقم الفاتورة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">التاريخ</TableHead>
                  <TableHead className="text-right font-semibold text-xs">العميل</TableHead>
                  <TableHead className="text-right font-semibold text-xs">القناة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الإجمالي</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الحالة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الفرع</TableHead>
                  <TableHead className="text-center font-semibold text-xs">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.map((inv) => {
                  const st = STATUS_MAP[inv.status];
                  return (
                    <TableRow key={inv.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                      <TableCell className="font-mono text-xs font-medium">{inv.number}</TableCell>
                      <TableCell className="text-xs text-gray-500 flex items-center gap-1">
                        <Calendar size={12} />
                        {inv.date}
                      </TableCell>
                      <TableCell className="text-sm font-medium">{inv.customer}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-[10px]">{inv.channel}</Badge>
                      </TableCell>
                      <TableCell className="font-semibold text-sm text-[#0a4a30]">{formatEGP(inv.total)}</TableCell>
                      <TableCell>
                        <Badge className={cn('text-[10px] font-medium border-0', st.bg, st.color)}>
                          {st.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-gray-500">{inv.branch}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600" onClick={() => setViewInvoice(inv)}>
                            <Eye size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600">
                            <Edit3 size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => deleteInvoice(inv.id)}>
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {paged.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-12 text-gray-400">
                      لا توجد فواتير مطابقة للبحث
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {/* Pagination */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 dark:border-gray-700">
            <span className="text-xs text-gray-500">
              عرض {filtered.length > 0 ? (page - 1) * pageSize + 1 : 0} - {Math.min(page * pageSize, filtered.length)} من {filtered.length}
            </span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(1)}>الأولى</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(page - 1)}>السابق</Button>
              <span className="text-xs px-2">{page} / {totalPages}</span>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(page + 1)}>التالي</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(totalPages)}>الأخيرة</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* View Invoice Dialog */}
      <Dialog open={!!viewInvoice} onOpenChange={() => setViewInvoice(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-right text-lg flex items-center gap-2">
              <Receipt size={20} className="text-[#0a4a30]" />
              تفاصيل الفاتورة {viewInvoice?.number}
            </DialogTitle>
          </DialogHeader>
          {viewInvoice && <InvoiceView invoice={viewInvoice} formatEGP={formatEGP} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ──────────────────────────── Invoice View ──────────────────────────── */

function InvoiceView({ invoice, formatEGP }: { invoice: Invoice; formatEGP: (n: number) => string }) {
  const st = STATUS_MAP[invoice.status];
  return (
    <div className="space-y-4" dir="rtl">
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">العميل</span>
          <span className="font-semibold">{invoice.customer}</span>
        </div>
        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">التاريخ</span>
          <span className="font-semibold">{invoice.date}</span>
        </div>
        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">القناة / الفرع</span>
          <span className="font-semibold">{invoice.channel} — {invoice.branch}</span>
        </div>
        <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
          <span className="text-gray-500 text-xs block">طريقة الدفع</span>
          <span className="font-semibold">{invoice.paymentMethod}</span>
        </div>
      </div>
      <div>
        <h4 className="font-semibold text-sm mb-2">بنود الفاتورة</h4>
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead className="text-right text-xs">المنتج</TableHead>
              <TableHead className="text-right text-xs">الكمية</TableHead>
              <TableHead className="text-right text-xs">السعر</TableHead>
              <TableHead className="text-right text-xs">الخصم</TableHead>
              <TableHead className="text-right text-xs">الإجمالي</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoice.items.map((item, i) => (
              <TableRow key={i}>
                <TableCell className="text-sm">{item.product}</TableCell>
                <TableCell className="text-sm">{item.qty}</TableCell>
                <TableCell className="text-sm">{formatEGP(item.unitPrice)}</TableCell>
                <TableCell className="text-sm text-red-500">{item.discount > 0 ? formatEGP(item.discount) : '-'}</TableCell>
                <TableCell className="text-sm font-semibold">{formatEGP(item.total)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <div className="flex items-center justify-between border-t pt-4">
        <Badge className={cn('text-xs border-0', st.bg, st.color)}>{st.label}</Badge>
        <div className="text-lg font-bold text-[#0a4a30]">
          الإجمالي: {formatEGP(invoice.total)}
        </div>
      </div>
      {invoice.notes && (
        <div className="text-xs text-gray-500 bg-amber-50 dark:bg-amber-900/20 p-2 rounded">
          ملاحظات: {invoice.notes}
        </div>
      )}
      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" className="gap-2 text-xs">
          <Printer size={14} />
          طباعة
        </Button>
        <Button className="bg-[#0a4a30] hover:bg-[#0d6b43] text-white text-xs">تحميل PDF</Button>
      </div>
    </div>
  );
}

/* ──────────────────────────── Create Invoice Form ──────────────────────────── */

function CreateInvoiceForm({ onCreate }: { onCreate: (inv: Invoice) => void }) {
  const [customer, setCustomer] = useState('');
  const [channel, setChannel] = useState('');
  const [branch, setBranch] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [notes, setNotes] = useState('');
  const [lines, setLines] = useState([{ product: '', qty: 1, unitPrice: 0, discount: 0 }]);

  const addLine = () => setLines([...lines, { product: '', qty: 1, unitPrice: 0, discount: 0 }]);
  const removeLine = (i: number) => setLines(lines.filter((_, idx) => idx !== i));
  const updateLine = (i: number, field: string, value: string | number) => {
    const newLines = [...lines];
    newLines[i] = { ...newLines[i], [field]: value };
    setLines(newLines);
  };

  const lineTotal = (l: typeof lines[0]) => l.qty * l.unitPrice - l.discount;
  const grandTotal = lines.reduce((s, l) => s + lineTotal(l), 0);

  const handleSubmit = () => {
    const newInv: Invoice = {
      id: Date.now().toString(),
      number: `INV-${String(INVOICES.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      customer: customer || 'عميل جديد',
      channel: channel || 'قطاعي',
      total: grandTotal,
      status: 'pending',
      branch: branch || 'القاهرة',
      paymentMethod: paymentMethod || 'كاش',
      notes,
      items: lines.map((l) => ({ ...l, total: lineTotal(l) })),
    };
    onCreate(newInv);
  };

  const products = ['أعلاف دواجن بادئ', 'أعلاف دواجن نامي', 'أعلاف دواجن ناهي', 'ذرة صفراء', 'كسب فول صويا', 'ردة قمح'];

  return (
    <div className="space-y-4" dir="rtl">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">العميل</Label>
          <Input value={customer} onChange={(e) => setCustomer(e.target.value)} placeholder="اسم العميل" className="text-right" />
        </div>
        <div>
          <Label className="text-xs">القناة</Label>
          <Select value={channel} onValueChange={setChannel}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر" /></SelectTrigger>
            <SelectContent>{CHANNELS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">الفرع</Label>
          <Select value={branch} onValueChange={setBranch}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر" /></SelectTrigger>
            <SelectContent>{BRANCHES.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">طريقة الدفع</Label>
          <Select value={paymentMethod} onValueChange={setPaymentMethod}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="كاش">كاش</SelectItem>
              <SelectItem value="تحويل بنكي">تحويل بنكي</SelectItem>
              <SelectItem value="شيك">شيك</SelectItem>
              <SelectItem value="آجل">آجل</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs font-semibold">بنود الفاتورة</Label>
          <Button type="button" variant="outline" size="sm" onClick={addLine} className="h-7 text-xs gap-1">
            <Plus size={12} />
            بند جديد
          </Button>
        </div>
        <div className="space-y-2 max-h-[240px] overflow-auto pr-1">
          {lines.map((line, i) => (
            <Card key={i} className="p-2 border border-gray-200">
              <div className="grid grid-cols-12 gap-2 items-end">
                <div className="col-span-4">
                  <Label className="text-[10px] text-gray-500">المنتج</Label>
                  <Select value={line.product} onValueChange={(v) => updateLine(i, 'product', v)}>
                    <SelectTrigger className="text-right h-8 text-xs"><SelectValue placeholder="اختر" /></SelectTrigger>
                    <SelectContent>{products.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label className="text-[10px] text-gray-500">الكمية</Label>
                  <Input type="number" value={line.qty} onChange={(e) => updateLine(i, 'qty', parseInt(e.target.value) || 0)} className="h-8 text-xs text-center" />
                </div>
                <div className="col-span-2">
                  <Label className="text-[10px] text-gray-500">السعر</Label>
                  <Input type="number" value={line.unitPrice} onChange={(e) => updateLine(i, 'unitPrice', parseFloat(e.target.value) || 0)} className="h-8 text-xs text-center" />
                </div>
                <div className="col-span-2">
                  <Label className="text-[10px] text-gray-500">الخصم</Label>
                  <Input type="number" value={line.discount} onChange={(e) => updateLine(i, 'discount', parseFloat(e.target.value) || 0)} className="h-8 text-xs text-center" />
                </div>
                <div className="col-span-1 pb-1">
                  <span className="text-xs font-semibold text-[#0a4a30]">{lineTotal(line).toLocaleString('ar-EG')}</span>
                </div>
                <div className="col-span-1 pb-1">
                  {lines.length > 1 && (
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500" onClick={() => removeLine(i)}>
                      <Trash2 size={12} />
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <div className="border-t pt-3">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-bold text-[#0a4a30]">
            الإجمالي: {grandTotal.toLocaleString('ar-EG')} ج.م
          </span>
        </div>
        <div className="mb-3">
          <Label className="text-xs">ملاحظات</Label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full border rounded-md p-2 text-xs text-right min-h-[60px]" placeholder="أي ملاحظات إضافية..." />
        </div>
        <Button onClick={handleSubmit} className="w-full bg-[#0a4a30] hover:bg-[#0d6b43] text-white">
          حفظ الفاتورة
        </Button>
      </div>
    </div>
  );
}
