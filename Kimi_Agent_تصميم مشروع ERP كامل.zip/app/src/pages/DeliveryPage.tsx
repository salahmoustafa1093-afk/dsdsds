// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ClipboardList, Truck, MapPin, Package, Clock, TrendingUp, TrendingDown,
  Users, BarChart3, Plus, Search, ChevronLeft, ChevronRight, Eye, Edit3,
  Trash2, CheckCircle2, XCircle, RotateCcw, AlertTriangle, Navigation,
  Camera, PenTool, Send, ArrowLeft, ArrowRight, Phone, Star, Filter,
  Download, ThumbsUp, ThumbsDown, Minus, QrCode, Box, Warehouse,
  Loader2, Calendar, DollarSign, Gauge, Activity
} from 'lucide-react';
import { cn } from '@/lib/utils';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

/* ─────────────────────── mock data ─────────────────────── */

const ORDERS = [
  { id: 'ORD-2025-001', customer: 'مؤسسة النخبة', phone: '0555123456', address: 'الرياض - حي الورود', items: 12, total: 2450, driver: 'أحمد العلي', status: 'قيد الانتظار', time: '08:30', estimated: '10:30' },
  { id: 'ORD-2025-002', customer: 'شركة السلام', phone: '0555234567', address: 'جدة - حي الروضة', items: 8, total: 1800, driver: '-', status: 'قيد الانتظار', time: '08:45', estimated: '11:00' },
  { id: 'ORD-2025-003', customer: 'مطعم البستان', phone: '0555345678', address: 'الدمام - حي الشاطئ', items: 25, total: 5200, driver: 'خالد السبيعي', status: 'قيد التنفيذ', time: '09:00', estimated: '11:30' },
  { id: 'ORD-2025-004', customer: 'فندق الجوهرة', phone: '0555456789', address: 'مكة - العزيزية', items: 40, total: 8900, driver: 'سامي الدوسري', status: 'قيد التنفيذ', time: '09:15', estimated: '12:00' },
  { id: 'ORD-2025-005', customer: 'سوبر ماركة النور', phone: '0555567890', address: 'الرياض - حي الصحافة', items: 60, total: 12500, driver: 'ناصر القحطاني', status: 'قيد التنفيذ', time: '07:30', estimated: '10:00' },
  { id: 'ORD-2025-006', customer: 'مخبوزات العائلة', phone: '0555678901', address: 'أبها - السودة', items: 15, total: 3200, driver: 'فهد الزهراني', status: 'تم التسليم', time: '07:00', estimated: '09:30' },
  { id: 'ORD-2025-007', customer: 'مطعم كشري التحرير', phone: '0555789012', address: 'جدة - حي البوادي', items: 20, total: 4100, driver: 'ماجد العتيبي', status: 'تم التسليم', time: '06:45', estimated: '09:00' },
  { id: 'ORD-2025-008', customer: 'كفتيريا الياسمين', phone: '0555890123', address: 'الطائف - الشهداء', items: 18, total: 3600, driver: 'سلطان المالكي', status: 'قيد التنفيذ', time: '09:30', estimated: '12:30' },
  { id: 'ORD-2025-009', customer: 'شركة الوفاء', phone: '0555901234', address: 'الرياض - حي الياسمين', items: 35, total: 7800, driver: '-', status: 'قيد الانتظار', time: '10:00', estimated: '13:00' },
  { id: 'ORD-2025-010', customer: 'مخبز السعادة', phone: '0555012345', address: 'الدمام - حي النور', items: 22, total: 4700, driver: 'تركي الشمري', status: 'قيد التنفيذ', time: '08:00', estimated: '10:30' },
  { id: 'ORD-2025-011', customer: 'مطعم الصياد', phone: '0555123457', address: 'جدة - حي الكورنيش', items: 30, total: 6500, driver: 'بندر الفيصل', status: 'تم التسليم', time: '06:30', estimated: '08:30' },
  { id: 'ORD-2025-012', customer: 'كافيه لاتيه آرت', phone: '0555234568', address: 'الرياض - حي العليا', items: 10, total: 2100, driver: 'ياسر البلوي', status: 'مرتجع', time: '08:15', estimated: '10:00' },
  { id: 'ORD-2025-013', customer: 'مطعم بيتزا هت فرع النخيل', phone: '0555345679', address: 'الخبر - حي النخيل', items: 45, total: 9800, driver: 'عبدالله القحطاني', status: 'قيد التنفيذ', time: '09:45', estimated: '12:00' },
  { id: 'ORD-2025-014', customer: 'فندق الريتز', phone: '0555456780', address: 'الرياض - حي المروج', items: 55, total: 14500, driver: '-', status: 'قيد الانتظار', time: '10:30', estimated: '14:00' },
  { id: 'ORD-2025-015', customer: 'مخبوزات لذة', phone: '0555567891', address: 'مكة - بطحة قريش', items: 16, total: 3400, driver: 'مبارك الهاجري', status: 'قيد الانتظار', time: '11:00', estimated: '14:30' },
  { id: 'ORD-2025-016', customer: 'مطعم الشواية', phone: '0555678902', address: 'المدينة - حي العزيزية', items: 28, total: 5900, driver: 'عبدالرحمن الشهراني', status: 'قيد التنفيذ', time: '08:30', estimated: '11:00' },
  { id: 'ORD-2025-017', customer: 'كافيه دروب', phone: '0555789013', address: 'الرياض - حي النرجس', items: 14, total: 2800, driver: 'نواف العنزي', status: 'تم التسليم', time: '07:00', estimated: '09:00' },
  { id: 'ORD-2025-018', customer: 'مطعم الساحل', phone: '0555890124', address: 'جدة - حي الشاطئ', items: 32, total: 7200, driver: 'فيصل السالم', status: 'مرتجع', time: '09:00', estimated: '11:30' },
  { id: 'ORD-2025-019', customer: 'شركة المراعي فرع شرق', phone: '0555901235', address: 'الدمام - الصناعية الثانية', items: 70, total: 18500, driver: 'مشعل الدوسري', status: 'قيد التنفيذ', time: '07:00', estimated: '10:00' },
  { id: 'ORD-2025-020', customer: 'سوبر ماركت الراية', phone: '0555012346', address: 'الرياض - حي الورود', items: 50, total: 11200, driver: '-', status: 'قيد الانتظار', time: '11:30', estimated: '15:00' },
  { id: 'ORD-2025-021', customer: 'مطعم كودو', phone: '0555123458', address: 'جدة - طريق الملك', items: 38, total: 8400, driver: 'عمر السهلي', status: 'قيد التنفيذ', time: '08:45', estimated: '11:30' },
  { id: 'ORD-2025-022', customer: 'بقالة أهل البيت', phone: '0555234569', address: 'الطائف - الهدا', items: 20, total: 4300, driver: 'إبراهيم المقيرن', status: 'قيد الانتظار', time: '12:00', estimated: '15:30' },
];

const DRIVERS = [
  { id: 1, name: 'أحمد العلي', phone: '0555123456', rating: 4.8, trips: 1240, status: 'متاح', zone: 'الرياض' },
  { id: 2, name: 'خالد السبيعي', phone: '0555234567', rating: 4.6, trips: 980, status: 'في توصيل', zone: 'الرياض' },
  { id: 3, name: 'سامي الدوسري', phone: '0555345678', rating: 4.9, trips: 1560, status: 'في توصيل', zone: 'جدة' },
  { id: 4, name: 'ناصر القحطاني', phone: '0555456789', rating: 4.5, trips: 870, status: 'في توصيل', zone: 'الرياض' },
  { id: 5, name: 'فهد الزهراني', phone: '0555567890', rating: 4.7, trips: 1100, status: 'متاح', zone: 'أبها' },
  { id: 6, name: 'ماجد العتيبي', phone: '0555678901', rating: 4.4, trips: 720, status: 'في توصيل', zone: 'جدة' },
];

const RETURNS = [
  { id: 'RET-001', order: 'ORD-2025-012', customer: 'كافيه لاتيه آرت', reason: 'منتج تالف', date: '2025-01-15', status: 'قيد المراجعة', refund: 2100 },
  { id: 'RET-002', order: 'ORD-2025-018', customer: 'مطعم الساحل', reason: 'خطأ في الطلب', date: '2025-01-15', status: 'تم القبول', refund: 7200 },
  { id: 'RET-003', order: 'ORD-2025-006', customer: 'مخبوزات العائلة', reason: 'تأخر التوصيل', date: '2025-01-14', status: 'تم الاستبدال', refund: 0 },
];

const TABS = [
  { key: 'dashboard', label: 'لوحة التحكم', icon: Gauge },
  { key: 'orders', label: 'الطلبات', icon: ClipboardList },
  { key: 'loading', label: 'التحميل', icon: Package },
  { key: 'routes', label: 'المسارات', icon: MapPin },
  { key: 'pod', label: 'POD', icon: CheckCircle2 },
  { key: 'returns', label: 'المرتجعات', icon: RotateCcw },
  { key: 'analytics', label: 'التحليلات', icon: BarChart3 },
];

const statusBadge = (status: string) => {
  const map: Record<string, string> = {
    'قيد الانتظار': 'bg-slate-100 text-slate-600',
    'قيد التنفيذ': 'bg-blue-100 text-blue-700',
    'تم التسليم': 'bg-green-100 text-green-700',
    'مرتجع': 'bg-red-100 text-red-700',
    'متاح': 'bg-green-100 text-green-700',
    'في توصيل': 'bg-blue-100 text-blue-700',
    'قيد المراجعة': 'bg-amber-100 text-amber-700',
    'تم القبول': 'bg-green-100 text-green-700',
    'تم الاستبدال': 'bg-purple-100 text-purple-700',
  };
  return map[status] || 'bg-slate-100 text-slate-600';
};

/* ─────────────────────── mini-components ─────────────────────── */

function MiniPieChart({ data, colors }: { data: number[]; colors: string[] }) {
  const total = data.reduce((a, b) => a + b, 0);
  let offset = 0;
  return (
    <svg viewBox="0 0 100 100" className="w-24 h-24">
      {data.map((v, i) => {
        const pct = (v / total) * 360;
        const dash = `${pct} ${360 - pct}`;
        const el = (
          <circle key={i} cx="50" cy="50" r="40" fill="none" stroke={colors[i]} strokeWidth="20" strokeDasharray={dash} transform={`rotate(${offset - 90} 50 50)`} />
        );
        offset += pct;
        return el;
      })}
    </svg>
  );
}

function MiniBarChart({ data, labels, color }: { data: number[]; labels: string[]; color: string }) {
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-2 h-28">
      {data.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1">
          <span className="text-[10px] text-textMuted">{v}</span>
          <div className="w-full rounded-t-md transition-all" style={{ height: `${(v / max) * 100}px`, backgroundColor: color, opacity: 0.5 + (i / data.length) * 0.5 }} />
          <span className="text-[10px] text-textMuted">{labels[i]}</span>
        </div>
      ))}
    </div>
  );
}

/* ─────────────────────── kanban card ─────────────────────── */

function KanbanCard({ order }: { order: typeof ORDERS[0] }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white dark:bg-darkSurface rounded-lg border border-uiBorder dark:border-darkBorder p-3 cursor-move hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between mb-2">
        <span className="text-[11px] font-semibold text-textPrimary dark:text-darkText">{order.id}</span>
        <span className="text-[11px] text-textMuted">{order.time}</span>
      </div>
      <p className="text-xs font-medium text-textPrimary dark:text-darkText mb-1">{order.customer}</p>
      <p className="text-[11px] text-textSecondary dark:text-darkTextSec mb-2">{order.address}</p>
      <div className="flex items-center justify-between text-[11px]">
        <span className="text-textSecondary dark:text-darkTextSec">{order.items} صنف</span>
        <span className="font-semibold text-green-600">{order.total.toLocaleString()} ر.س</span>
      </div>
      {order.driver !== '-' && (
        <div className="mt-2 pt-2 border-t border-uiBorder/50 flex items-center gap-1 text-[11px] text-textMuted">
          <Truck size={10} />
          {order.driver}
        </div>
      )}
    </motion.div>
  );
}

/* ─────────────────────── main page ─────────────────────── */

export default function DeliveryPage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchQ, setSearchQ] = useState('');
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [loadingStep, setLoadingStep] = useState(2);

  const pendingO = ORDERS.filter(o => o.status === 'قيد الانتظار');
  const activeO = ORDERS.filter(o => o.status === 'قيد التنفيذ');
  const deliveredO = ORDERS.filter(o => o.status === 'تم التسليم');
  const returnedO = ORDERS.filter(o => o.status === 'مرتجع');

  const toggleSelect = (id: string) => {
    setSelectedOrders(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  return (
    <div className="p-4 md:p-6">
      <PageHeader title="إدارة التوصيل" subtitle="تتبع الطلبات والتوصيل والمرتجعات">
        <button className="flex items-center gap-2 px-4 py-2 bg-[#0a4a30] hover:bg-[#0d6b43] text-white rounded-lg text-sm font-medium transition-colors">
          <Plus size={16} />
          طلب جديد
        </button>
      </PageHeader>

      {/* ─── KPIs ─── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        <KPICard title="طلبات اليوم" value={ORDERS.length.toString()} change={12} icon={ClipboardList} iconBg="bg-blue-50" iconColor="text-blue-600" delay={0} />
        <KPICard title="قيد التوصيل" value={activeO.length.toString()} change={5} icon={Truck} iconBg="bg-amber-50" iconColor="text-amber-600" delay={0.05} />
        <KPICard title="تم التسليم" value={deliveredO.length.toString()} change={8} icon={CheckCircle2} iconBg="bg-green-50" iconColor="text-green-600" delay={0.1} />
        <KPICard title="المرتجعات" value={returnedO.length.toString()} change={-15} icon={RotateCcw} iconBg="bg-red-50" iconColor="text-red-600" delay={0.15} />
        <KPICard title="متوسط وقت التوصيل" value="42 دقيقة" change={-10} icon={Clock} iconBg="bg-purple-50" iconColor="text-purple-600" delay={0.2} />
        <KPICard title="رضا العملاء" value="94.2%" change={3} icon={ThumbsUp} iconBg="bg-emerald-50" iconColor="text-emerald-600" delay={0.25} />
      </div>

      {/* ─── Tabs ─── */}
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card">
        <div className="flex overflow-x-auto border-b border-uiBorder dark:border-darkBorder scrollbar-hide">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className={cn('flex items-center gap-2 px-5 py-3.5 text-sm font-medium border-b-2 transition-colors whitespace-nowrap',
                activeTab === t.key ? 'border-[#0a4a30] text-[#0a4a30] dark:text-green-400' : 'border-transparent text-textSecondary hover:text-textPrimary dark:text-darkTextSec')}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>

        <div className="p-4 md:p-5">
          <AnimatePresence mode="wait">

            {/* ─── Dashboard Tab: Kanban ─── */}
            {activeTab === 'dashboard' && (
              <motion.div key="dashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                  {/* Pending */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-slate-400" />
                        قيد الانتظار <span className="text-textMuted font-normal">({pendingO.length})</span>
                      </h4>
                    </div>
                    <div className="space-y-2">
                      {pendingO.map(o => <KanbanCard key={o.id} order={o} />)}
                    </div>
                  </div>
                  {/* Active */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-blue-500" />
                        قيد التنفيذ <span className="text-textMuted font-normal">({activeO.length})</span>
                      </h4>
                    </div>
                    <div className="space-y-2">
                      {activeO.map(o => <KanbanCard key={o.id} order={o} />)}
                    </div>
                  </div>
                  {/* Delivered */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-green-500" />
                        تم التسليم <span className="text-textMuted font-normal">({deliveredO.length})</span>
                      </h4>
                    </div>
                    <div className="space-y-2">
                      {deliveredO.map(o => <KanbanCard key={o.id} order={o} />)}
                    </div>
                  </div>
                  {/* Returned */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500" />
                        مرتجع <span className="text-textMuted font-normal">({returnedO.length})</span>
                      </h4>
                    </div>
                    <div className="space-y-2">
                      {returnedO.map(o => <KanbanCard key={o.id} order={o} />)}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Orders Tab ─── */}
            {activeTab === 'orders' && (
              <motion.div key="orders" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">قائمة الطلبات</h3>
                  <div className="flex items-center gap-2">
                    {selectedOrders.length > 0 && (
                      <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0a4a30] text-white rounded-lg text-xs font-medium transition-colors">
                        <Truck size={14} />
                        تعيين سائق ({selectedOrders.length})
                      </button>
                    )}
                    <div className="relative w-52">
                      <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                      <input type="text" placeholder="بحث..." value={searchQ} onChange={e => setSearchQ(e.target.value)}
                        className="w-full h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                    </div>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                        {['', 'الطلب', 'العميل', 'العنوان', 'الأصناف', 'الإجمالي', 'السائق', 'الحالة', ''].map(h => (
                          <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {ORDERS.filter(o => !searchQ || o.customer.includes(searchQ) || o.id.includes(searchQ)).map((o, i) => (
                        <motion.tr key={o.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }}
                          className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                        >
                          <td className="px-3 py-2.5">
                            <input type="checkbox" checked={selectedOrders.includes(o.id)} onChange={() => toggleSelect(o.id)}
                              className="rounded border-uiBorder text-[#0a4a30] focus:ring-[#0a4a30]" />
                          </td>
                          <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{o.id}</td>
                          <td className="px-3 py-2.5">
                            <div>
                              <p className="text-sm font-medium text-textPrimary dark:text-darkText">{o.customer}</p>
                              <p className="text-[11px] text-textMuted">{o.phone}</p>
                            </div>
                          </td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{o.address}</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{o.items}</td>
                          <td className="px-3 py-2.5 text-sm font-semibold text-green-600">{o.total.toLocaleString()} ر.س</td>
                          <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{o.driver}</td>
                          <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(o.status))}>{o.status}</span></td>
                          <td className="px-3 py-2.5">
                            <div className="flex items-center gap-1 justify-center">
                              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors"><Eye size={15} /></button>
                              {o.status === 'قيد الانتظار' && (
                                <button className="w-8 h-8 rounded-lg flex items-center justify-center text-green-500 hover:bg-green-50 transition-colors"><Truck size={15} /></button>
                              )}
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* ─── Loading Tab ─── */}
            {activeTab === 'loading' && (
              <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-6">سير عملية التحميل</h3>
                <div className="flex items-center justify-center mb-8">
                  <div className="flex items-center gap-2">
                    {[
                      { label: 'Picking', icon: Package, desc: 'جمع المنتجات' },
                      { label: 'تأكيد المستودع', icon: Warehouse, desc: 'مراجعة وفحص' },
                      { label: 'تم التحميل', icon: Box, desc: 'تحميل في المركبة' },
                      { label: 'قبول السائق', icon: CheckCircle2, desc: 'تأكيد الاستلام' },
                    ].map((step, i) => (
                      <div key={step.label} className="flex items-center gap-2">
                        <div className={cn('flex flex-col items-center gap-1 p-3 rounded-xl border-2 transition-all w-28',
                          loadingStep >= i ? 'border-[#0a4a30] bg-green-50 dark:bg-green-950/20' : 'border-uiBorder bg-white dark:bg-darkSurface'
                        )}>
                          <step.icon size={20} className={loadingStep >= i ? 'text-[#0a4a30]' : 'text-textMuted'} />
                          <span className={cn('text-xs font-semibold', loadingStep >= i ? 'text-[#0a4a30]' : 'text-textMuted')}>{step.label}</span>
                          <span className="text-[10px] text-textMuted">{step.desc}</span>
                        </div>
                        {i < 3 && <ArrowLeft size={16} className={loadingStep > i ? 'text-[#0a4a30]' : 'text-textMuted'} />}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">طلبات قيد التحميل</h4>
                    {ORDERS.filter(o => o.status === 'قيد الانتظار').slice(0, 4).map(o => (
                      <div key={o.id} className="flex items-center justify-between py-2 border-b border-uiBorder/50 last:border-0">
                        <div>
                          <p className="text-xs font-medium text-textPrimary dark:text-darkText">{o.id}</p>
                          <p className="text-[11px] text-textMuted">{o.customer}</p>
                        </div>
                        <span className="text-xs font-semibold text-green-600">{o.items} صنف</span>
                      </div>
                    ))}
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">تم التحميل اليوم</h4>
                    {ORDERS.filter(o => o.status === 'قيد التنفيذ').slice(0, 4).map(o => (
                      <div key={o.id} className="flex items-center justify-between py-2 border-b border-uiBorder/50 last:border-0">
                        <div>
                          <p className="text-xs font-medium text-textPrimary dark:text-darkText">{o.id}</p>
                          <p className="text-[11px] text-textMuted">{o.driver}</p>
                        </div>
                        <CheckCircle2 size={14} className="text-green-500" />
                      </div>
                    ))}
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">إحصائيات التحميل</h4>
                    <div className="space-y-3">
                      {[
                        { label: 'إجمالي الأصناف', value: '487 صنف' },
                        { label: 'متوسط وقت التحميل', value: '18 دقيقة' },
                        { label: 'دقة التحميل', value: '99.2%' },
                        { label: 'أخطاء التحميل', value: '3' },
                      ].map(s => (
                        <div key={s.label} className="flex items-center justify-between text-xs">
                          <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                          <span className="font-semibold text-textPrimary dark:text-darkText">{s.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Routes Tab ─── */}
            {activeTab === 'routes' && (
              <motion.div key="routes" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">خطة المسارات اليومية</h3>
                    <div className="space-y-3">
                      {DRIVERS.filter(d => d.status === 'في توصيل').map((driver, i) => (
                        <motion.div key={driver.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}
                          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-[#0a4a30] flex items-center justify-center text-white font-bold text-sm">
                                {driver.name.charAt(0)}
                              </div>
                              <div>
                                <p className="text-sm font-semibold text-textPrimary dark:text-darkText">{driver.name}</p>
                                <div className="flex items-center gap-2 text-[11px] text-textMuted">
                                  <MapPin size={10} /> {driver.zone}
                                  <Star size={10} className="text-amber-400 fill-amber-400" /> {driver.rating}
                                </div>
                              </div>
                            </div>
                            <span className="px-2 py-1 rounded-full text-[11px] font-semibold bg-blue-100 text-blue-700">
                              {ORDERS.filter(o => o.driver === driver.name).length} طلبات
                            </span>
                          </div>
                          <div className="flex items-center gap-2 overflow-x-auto pb-2">
                            {ORDERS.filter(o => o.driver === driver.name).map((o, idx) => (
                              <div key={o.id} className="flex items-center gap-2 shrink-0">
                                <div className="px-3 py-2 bg-surface dark:bg-darkBg rounded-lg text-center min-w-[100px]">
                                  <p className="text-[11px] font-medium text-textPrimary dark:text-darkText">{o.customer}</p>
                                  <p className="text-[10px] text-textMuted">{o.address.split(' - ')[1] || o.address}</p>
                                </div>
                                {idx < ORDERS.filter(order => order.driver === driver.name).length - 1 && (
                                  <ArrowLeft size={14} className="text-textMuted shrink-0" />
                                )}
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2">
                        <Navigation size={16} className="text-green-500" />
                        تتبع GPS
                      </h4>
                      <div className="bg-surface dark:bg-darkBg rounded-lg p-4 text-center">
                        <MapPin size={48} className="text-[#0a4a30] mx-auto mb-2" />
                        <p className="text-xs text-textSecondary dark:text-darkTextSec">6 سائقين نشطين حالياً</p>
                        <p className="text-xs text-textMuted mt-1">يتم التتبع في الوقت الفعلي</p>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">ملخص المسارات</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'إجمالي المسافة', value: '1,240 كم' },
                          { label: 'متوسط المسافة للطلب', value: '18.5 كم' },
                          { label: 'وقت التشغيل الإجمالي', value: '8.2 ساعة' },
                          { label: 'الوقود المستهلك', value: '95 لتر' },
                        ].map(s => (
                          <div key={s.label} className="flex items-center justify-between text-xs">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{s.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── POD Tab ─── */}
            {activeTab === 'pod' && (
              <motion.div key="pod" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">إثبات التسليم (POD)</h4>
                    {ORDERS.filter(o => o.status === 'تم التسليم').slice(0, 5).map((o, i) => (
                      <motion.div key={o.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                        className="flex items-center gap-3 p-3 border-b border-uiBorder/50 last:border-0"
                      >
                        <div className="w-10 h-10 rounded-lg bg-green-50 dark:bg-green-950/20 flex items-center justify-center">
                          <CheckCircle2 size={18} className="text-green-600" />
                        </div>
                        <div className="flex-1">
                          <p className="text-xs font-medium text-textPrimary dark:text-darkText">{o.id} - {o.customer}</p>
                          <p className="text-[11px] text-textMuted">{o.driver} | {o.estimated}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <button className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 transition-colors" title="توقيع"><PenTool size={14} /></button>
                          <button className="w-8 h-8 rounded-lg flex items-center justify-center text-purple-500 hover:bg-purple-50 transition-colors" title="صورة"><Camera size={14} /></button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">تسليم فاشل</h4>
                      {ORDERS.filter(o => o.status === 'مرتجع').map((o, i) => (
                        <motion.div key={o.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                          className="flex items-center gap-3 p-3 bg-red-50 dark:bg-red-950/20 rounded-lg mb-2"
                        >
                          <XCircle size={18} className="text-red-500 shrink-0" />
                          <div className="flex-1">
                            <p className="text-xs font-medium text-textPrimary dark:text-darkText">{o.id} - {o.customer}</p>
                            <p className="text-[11px] text-textMuted">{o.address}</p>
                          </div>
                          <button className="px-3 py-1 bg-red-500 text-white rounded-lg text-[11px] font-medium hover:bg-red-600 transition-colors">إعادة جدولة</button>
                        </motion.div>
                      ))}
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">إحصائيات POD</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'معدل التسليم الناجح', value: '92.3%' },
                          { label: 'متوسط وقت التسليم', value: '38 دقيقة' },
                          { label: 'تسليم بتوقيع', value: '87%' },
                          { label: 'تسليم بصورة', value: '65%' },
                        ].map(s => (
                          <div key={s.label} className="flex items-center justify-between text-xs">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{s.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Returns Tab ─── */}
            {activeTab === 'returns' && (
              <motion.div key="returns" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2">
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4">سير عمل المرتجعات</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder">
                        <thead>
                          <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                            {['رقم المرتجع', 'الطلب', 'العميل', 'السبب', 'المبلغ', 'التاريخ', 'الحالة'].map(h => (
                              <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {RETURNS.map((r, i) => (
                            <motion.tr key={r.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
                              className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                            >
                              <td className="px-3 py-2.5 text-sm font-medium text-textPrimary dark:text-darkText">{r.id}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{r.order}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{r.customer}</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{r.reason}</td>
                              <td className="px-3 py-2.5 text-sm font-semibold text-red-600">{r.refund.toLocaleString()} ر.س</td>
                              <td className="px-3 py-2.5 text-sm text-textSecondary dark:text-darkTextSec">{r.date}</td>
                              <td className="px-3 py-2.5"><span className={cn('px-2 py-0.5 rounded-full text-[11px] font-semibold', statusBadge(r.status))}>{r.status}</span></td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">أسباب المرتجعات</h4>
                      {[
                        { reason: 'منتج تالف', count: 8, pct: 35 },
                        { reason: 'خطأ في الطلب', count: 6, pct: 26 },
                        { reason: 'تأخر التوصيل', count: 5, pct: 22 },
                        { reason: 'عميل غير موجود', count: 4, pct: 17 },
                      ].map(item => (
                        <div key={item.reason} className="mb-3">
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-textSecondary dark:text-darkTextSec">{item.reason}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{item.count} ({item.pct}%)</span>
                          </div>
                          <div className="h-2 bg-surface dark:bg-darkBg rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${item.pct}%` }} transition={{ duration: 0.5 }}
                              className="h-full rounded-full bg-[#daa520]" />
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                      <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">ملخص المرتجعات</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'إجمالي المرتجعات', value: '23' },
                          { label: 'نسبة المرتجعات', value: '3.2%' },
                          { label: 'إجمالي المبالغ المستردة', value: '45,200 ر.س' },
                          { label: 'متوسط وقت المعالجة', value: '2.1 يوم' },
                        ].map(s => (
                          <div key={s.label} className="flex items-center justify-between text-xs">
                            <span className="text-textSecondary dark:text-darkTextSec">{s.label}</span>
                            <span className="font-semibold text-textPrimary dark:text-darkText">{s.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* ─── Analytics Tab ─── */}
            {activeTab === 'analytics' && (
              <motion.div key="analytics" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">نسبة التوصيل في الوقت المحدد</h4>
                    <div className="flex items-center justify-center mb-4">
                      <MiniPieChart data={[87, 13]} colors={['#10b981', '#ef4444']} />
                    </div>
                    <div className="flex items-center justify-center gap-6">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-green-500" />
                        <span className="text-xs text-textSecondary dark:text-darkTextSec">في الوقت 87%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500" />
                        <span className="text-xs text-textSecondary dark:text-darkTextSec">متأخر 13%</span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">توصيلات السائقين (الأسبوع)</h4>
                    <MiniBarChart data={[45, 38, 52, 41, 48, 35]} labels={['أحمد', 'خالد', 'سامي', 'ناصر', 'ماجد', 'فهد']} color="#0a4a30" />
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">أوقات الذروة</h4>
                    <MiniBarChart data={[12, 25, 48, 62, 45, 38, 28, 52, 68, 55, 42, 30]} labels={['6ص', '7ص', '8ص', '9ص', '10ص', '11ص', '12ظ', '1م', '2م', '3م', '4م', '5م']} color="#daa520" />
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                    <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">ترتيب السائقين</h4>
                    <div className="space-y-2">
                      {[...DRIVERS].sort((a, b) => b.rating - a.rating).map((d, i) => (
                        <div key={d.id} className="flex items-center gap-3">
                          <span className="text-xs font-bold text-textMuted w-4">{i + 1}</span>
                          <div className="w-24 text-xs font-medium text-textPrimary dark:text-darkText truncate">{d.name}</div>
                          <div className="flex-1 h-3 bg-surface dark:bg-darkBg rounded-full overflow-hidden">
                            <motion.div initial={{ width: 0 }} animate={{ width: `${(d.rating / 5) * 100}%` }} transition={{ duration: 0.5, delay: i * 0.1 }}
                              className="h-full rounded-full bg-gradient-to-l from-[#0a4a30] to-[#0d6b43]" />
                          </div>
                          <div className="flex items-center gap-1 w-14">
                            <Star size={10} className="text-amber-400 fill-amber-400" />
                            <span className="text-xs font-semibold">{d.rating}</span>
                          </div>
                          <span className="text-[11px] text-textMuted">{d.trips.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
