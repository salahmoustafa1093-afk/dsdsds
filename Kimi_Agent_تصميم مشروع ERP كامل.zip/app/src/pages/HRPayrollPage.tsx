import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Banknote, Calculator, X, Printer, FileSpreadsheet, TrendingUp, Wallet, ArrowDown, ArrowUp, ChevronLeft, ChevronRight,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

// ─── Types ──────────────────────────────────────────────
interface PayrollRecord {
  id: string;
  employee: string;
  basicSalary: number;
  housing: number;
  transport: number;
  food: number;
  overtime: number;
  insurance: number;
  tax: number;
  loans: number;
  netSalary: number;
}

// ─── Mock Data ──────────────────────────────────────────
const payrollData: PayrollRecord[] = [
  { id: 'E-001', employee: 'أحمد محمود', basicSalary: 8500, housing: 1200, transport: 500, food: 400, overtime: 600, insurance: 425, tax: 340, loans: 0, netSalary: 10435 },
  { id: 'E-002', employee: 'محمد علي', basicSalary: 7200, housing: 1000, transport: 400, food: 350, overtime: 300, insurance: 360, tax: 250, loans: 500, netSalary: 8140 },
  { id: 'E-003', employee: 'فاطمة أحمد', basicSalary: 6800, housing: 950, transport: 350, food: 300, overtime: 450, insurance: 340, tax: 220, loans: 0, netSalary: 8090 },
  { id: 'E-004', employee: 'خالد عمر', basicSalary: 9000, housing: 1300, transport: 550, food: 450, overtime: 0, insurance: 450, tax: 400, loans: 1000, netSalary: 9450 },
  { id: 'E-005', employee: 'سارة محمود', basicSalary: 8000, housing: 1100, transport: 450, food: 380, overtime: 500, insurance: 400, tax: 350, loans: 0, netSalary: 9680 },
  { id: 'E-006', employee: 'محمود سالم', basicSalary: 12000, housing: 1800, transport: 600, food: 500, overtime: 800, insurance: 600, tax: 600, loans: 0, netSalary: 14500 },
  { id: 'E-007', employee: 'نورا إبراهيم', basicSalary: 10000, housing: 1400, transport: 500, food: 400, overtime: 350, insurance: 500, tax: 480, loans: 0, netSalary: 11270 },
  { id: 'E-008', employee: 'عبدالله حسن', basicSalary: 6500, housing: 900, transport: 350, food: 300, overtime: 200, insurance: 325, tax: 200, loans: 0, netSalary: 7725 },
];

const months = ['يناير 2025', 'ديسمبر 2024', 'نوفمبر 2024', 'أكتوبر 2024'];

export default function HRPayrollPage() {
  const [selectedMonth, setSelectedMonth] = useState(0);
  const [showSlip, setShowSlip] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<PayrollRecord | null>(null);
  const [showGenerate, setShowGenerate] = useState(false);

  const totalSalaries = payrollData.reduce((s, r) => s + r.basicSalary, 0);
  totalSalaries.toLocaleString();
  const totalAllowances = payrollData.reduce((s, r) => s + r.housing + r.transport + r.food + r.overtime, 0);
  const totalDeductions = payrollData.reduce((s, r) => s + r.insurance + r.tax + r.loans, 0);
  const totalNet = payrollData.reduce((s, r) => s + r.netSalary, 0);

  const openSlip = (record: PayrollRecord) => {
    setSelectedRecord(record);
    setShowSlip(true);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="إدارة الرواتب"
        subtitle="حساب وتوليد كشوف الرواتب الشهرية"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الموارد البشرية', path: '/hr' },
          { label: 'الرواتب' },
        ]}
      >
        <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">
          <FileSpreadsheet size={16} /> تصدير Excel
        </button>
        <button onClick={() => setShowGenerate(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Calculator size={16} /> توليد كشوف
        </button>
      </PageHeader>

      {/* Month Selector */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4 flex items-center gap-3">
        <span className="text-sm text-textSecondary font-medium">شهر/سنة:</span>
        <div className="flex items-center gap-1">
          <button onClick={() => setSelectedMonth(m => Math.min(months.length - 1, m + 1))} disabled={selectedMonth === months.length - 1} className="w-8 h-8 rounded-lg flex items-center justify-center disabled:opacity-30 hover:bg-surface"><ChevronRight size={16} /></button>
          <span className="text-sm font-semibold text-textPrimary dark:text-darkText px-3 min-w-[120px] text-center">{months[selectedMonth]}</span>
          <button onClick={() => setSelectedMonth(m => Math.max(0, m - 1))} disabled={selectedMonth === 0} className="w-8 h-8 rounded-lg flex items-center justify-center disabled:opacity-30 hover:bg-surface"><ChevronLeft size={16} /></button>
        </div>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="إجمالي الرواتب" value={`${totalSalaries.toLocaleString()} ج.م`} icon={Banknote} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0} />
        <KPICard title="البدلات" value={`${totalAllowances.toLocaleString()} ج.م`} icon={TrendingUp} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.1} />
        <KPICard title="الاستقطاعات" value={`${totalDeductions.toLocaleString()} ج.م`} icon={ArrowDown} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.2} />
        <KPICard title="الصافي" value={`${totalNet.toLocaleString()} ج.م`} icon={Wallet} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.3} />
      </div>

      {/* Salary Formula */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-green-50 dark:bg-green-900/20 rounded-xl border border-green-200 dark:border-green-800 p-4">
        <p className="text-sm text-green-800 dark:text-green-300 font-medium text-center">
          الأساسي + سكن + مواصلات + غذاء + إضافي - تأمين - ضريبة - سلف = الصافي
        </p>
      </motion.div>

      {/* Payroll Table */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">كشوف الرواتب - {months[selectedMonth]}</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {['الموظف', 'الأساسي', 'سكن', 'مواصلات', 'غذاء', 'إضافي', 'تأمين', 'ضريبة', 'سلف', 'الصافي', ''].map(h => (
                  <th key={h} className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {payrollData.map((row, idx) => (
                <motion.tr key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}
                  className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                >
                  <td className="px-3 py-3 text-sm font-semibold text-textPrimary dark:text-darkText whitespace-nowrap">{row.employee}</td>
                  <td className="px-3 py-3 text-sm text-textPrimary dark:text-darkText">{row.basicSalary.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm text-green-700">{row.housing.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm text-green-700">{row.transport.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm text-green-700">{row.food.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm text-green-700">{row.overtime.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm text-red-600">{row.insurance.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm text-red-600">{row.tax.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm text-red-600">{row.loans.toLocaleString()}</td>
                  <td className="px-3 py-3 text-sm font-bold text-green-700">{row.netSalary.toLocaleString()}</td>
                  <td className="px-3 py-3">
                    <button onClick={() => openSlip(row)} className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors" title="عرض قسيمة الراتب">
                      <Printer size={16} />
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Salary Slip Modal (Printable) */}
      <AnimatePresence>
        {showSlip && selectedRecord && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowSlip(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white rounded-xl border shadow-modal w-full max-w-md print:shadow-none print:border-0">
              <div className="p-6">
                {/* Company Header */}
                <div className="text-center border-b border-uiBorder pb-4 mb-4">
                  <h2 className="text-xl font-bold text-green-800">شركة GFF للأعلاف</h2>
                  <p className="text-sm text-textSecondary mt-1">قسيمة راتب - {months[selectedMonth]}</p>
                </div>
                {/* Employee Info */}
                <div className="flex items-center justify-between mb-4">
                  <div><p className="text-xs text-textMuted">الموظف</p><p className="text-sm font-bold text-textPrimary">{selectedRecord.employee}</p></div>
                  <div><p className="text-xs text-textMuted">الرقم</p><p className="text-sm font-bold text-textPrimary">{selectedRecord.id}</p></div>
                </div>
                {/* Earnings */}
                <div className="mb-4">
                  <h4 className="text-xs font-semibold text-green-700 mb-2 bg-green-50 p-1 rounded">المستحقات</h4>
                  <div className="space-y-1 text-sm">
                    {[
                      ['الراتب الأساسي', selectedRecord.basicSalary],
                      ['بدل سكن', selectedRecord.housing],
                      ['بدل مواصلات', selectedRecord.transport],
                      ['بدل غذاء', selectedRecord.food],
                      ['بدل إضافي', selectedRecord.overtime],
                    ].map(([label, val]) => (
                      <div key={label as string} className="flex justify-between"><span className="text-textSecondary">{label}</span><span className="font-medium">{Number(val).toLocaleString()} ج.م</span></div>
                    ))}
                  </div>
                </div>
                {/* Deductions */}
                <div className="mb-4">
                  <h4 className="text-xs font-semibold text-red-700 mb-2 bg-red-50 p-1 rounded">الاستقطاعات</h4>
                  <div className="space-y-1 text-sm">
                    {[
                      ['تأمين اجتماعي', selectedRecord.insurance],
                      ['ضريبة', selectedRecord.tax],
                      ['سلف', selectedRecord.loans],
                    ].map(([label, val]) => (
                      <div key={label as string} className="flex justify-between"><span className="text-textSecondary">{label}</span><span className="font-medium text-red-600">-{Number(val).toLocaleString()} ج.م</span></div>
                    ))}
                  </div>
                </div>
                {/* Net */}
                <div className="border-t border-uiBorder pt-3 flex justify-between items-center">
                  <span className="text-base font-bold text-textPrimary">الصافي</span>
                  <span className="text-xl font-bold text-green-700">{selectedRecord.netSalary.toLocaleString()} ج.م</span>
                </div>
              </div>
              <div className="px-5 py-3 border-t border-uiBorder flex justify-end gap-2 print:hidden">
                <button onClick={() => setShowSlip(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary">إغلاق</button>
                <button onClick={() => window.print()} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800"><Printer size={14} className="inline ml-1" /> طباعة</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Generate Payroll Modal */}
      <AnimatePresence>
        {showGenerate && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowGenerate(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-sm">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">توليد كشوف الرواتب</h3>
                <button onClick={() => setShowGenerate(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1">الشهر/السنة</label>
                  <select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">
                    <option>يناير 2025</option><option>فبراير 2025</option><option>مارس 2025</option>
                  </select>
                </div>
                <div className="bg-gold-50 dark:bg-gold-900/20 rounded-lg p-3 border border-gold-200 dark:border-gold-800">
                  <p className="text-xs text-gold-800 dark:text-gold-300">سيتم توليد كشوف رواتب لـ {payrollData.length} موظف بناءً على بيانات الحضور والبدلات المسجلة.</p>
                </div>
                <div className="flex justify-end gap-2">
                  <button onClick={() => setShowGenerate(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary">إلغاء</button>
                  <button onClick={() => setShowGenerate(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800">تأكيد التوليد</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
