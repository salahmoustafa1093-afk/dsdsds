import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line
} from 'recharts';
import {
  ShoppingCart, Store, Truck, Ship, Globe,
  Target, TrendingUp, Eye, X
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import { formatCurrency } from '@/data/mockData';

const channelData = [
  { channel: 'القطاعي', sales: 4025250, target: 4500000, profitMargin: 22, growth: 8.5 },
  { channel: 'الجملة', sales: 2683500, target: 2500000, profitMargin: 15, growth: 12.3 },
  { channel: 'الموزعين', sales: 1789000, target: 2000000, profitMargin: 12, growth: -3.2 },
  { channel: 'التصدير', sales: 447250, target: 500000, profitMargin: 30, growth: 25.0 },
];

const channelTrend = [
  { month: 'يناير', قطاعي: 650000, جملة: 420000, موزعين: 280000, تصدير: 60000 },
  { month: 'فبراير', قطاعي: 580000, جملة: 380000, موزعين: 250000, تصدير: 70000 },
  { month: 'مارس', قطاعي: 720000, جملة: 490000, موزعين: 320000, تصدير: 80000 },
  { month: 'ابريل', قطاعي: 610000, جملة: 410000, موزعين: 290000, تصدير: 75000 },
  { month: 'مايو', قطاعي: 750000, جملة: 520000, موزعين: 350000, تصدير: 90000 },
  { month: 'يونيو', قطاعي: 714250, جملة: 463500, موزعين: 289000, تصدير: 72250 },
];

const channelPie = [
  { name: 'القطاعي', value: 45, color: '#14a86a' },
  { name: 'الجملة', value: 30, color: '#daa520' },
  { name: 'الموزعين', value: 20, color: '#3b82f6' },
  { name: 'التصدير', value: 5, color: '#8b5cf6' },
];

const channelIcons: Record<string, React.ElementType> = {
  'القطاعي': Store,
  'الجملة': Truck,
  'الموزعين': Ship,
  'التصدير': Globe,
};

const channelCustomers: Record<string, { name: string; sales: number; orders: number; avgOrder: number }[]> = {
  'القطاعي': [
    { name: 'مزارع النور', sales: 320000, orders: 25, avgOrder: 12800 },
    { name: 'مزرعة الذهبية', sales: 180000, orders: 18, avgOrder: 10000 },
    { name: 'مزارع السلام', sales: 95000, orders: 12, avgOrder: 7917 },
  ],
  'الجملة': [
    { name: 'شركة الدلتا', sales: 850000, orders: 15, avgOrder: 56667 },
    { name: 'مؤسسة الريف', sales: 620000, orders: 12, avgOrder: 51667 },
  ],
  'الموزعين': [
    { name: 'مؤسسة النيل', sales: 420000, orders: 22, avgOrder: 19091 },
    { name: 'شركة الصعيد', sales: 285000, orders: 18, avgOrder: 15833 },
  ],
  'التصدير': [
    { name: 'Gulf Feed Co.', sales: 280000, orders: 5, avgOrder: 56000 },
    { name: 'African Agri Ltd.', sales: 167250, orders: 3, avgOrder: 55750 },
  ],
};

export default function SalesChannelPage() {
  const [showDetail, setShowDetail] = useState<string | null>(null);
  const [targets, setTargets] = useState<Record<string, number>>({
    'القطاعي': 4500000,
    'الجملة': 2500000,
    'الموزعين': 2000000,
    'التصدير': 500000,
  });

  const totalSales = channelData.reduce((s, c) => s + c.sales, 0);
  const totalTarget = Object.values(targets).reduce((s, t) => s + t, 0);

  const handleTargetChange = (channel: string, value: string) => {
    setTargets((prev) => ({ ...prev, [channel]: Number(value) || 0 }));
  };

  const detailData = showDetail ? channelCustomers[showDetail] : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="المبيعات حسب القناة"
        subtitle="تحليل المبيعات والأداء حسب قنوات التوزيع"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'المبيعات', path: '/sales' },
          { label: 'القنوات' },
        ]}
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <KPICard title="إجمالي المبيعات" value={formatCurrency(totalSales)} icon={ShoppingCart} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="القطاعي" value={formatCurrency(channelData[0].sales)} icon={Store} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="الجملة" value={formatCurrency(channelData[1].sales)} icon={Truck} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.2} />
        <KPICard title="الموزعين" value={formatCurrency(channelData[2].sales)} icon={Ship} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-700 dark:text-purple-400" delay={0.3} />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">توزيع المبيعات حسب القناة</h3>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={channelPie} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                {channelPie.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
        >
          <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">اتجاه المبيعات (6 أشهر)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={channelTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="قطاعي" stroke="#14a86a" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="جملة" stroke="#daa520" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="موزعين" stroke="#3b82f6" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="تصدير" stroke="#8b5cf6" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Channel Comparison */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4">مقارنة القنوات</h3>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={channelData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="channel" tick={{ fontSize: 12 }} />
            <YAxis tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`} tick={{ fontSize: 12 }} />
            <Tooltip formatter={(value: number) => formatCurrency(value)} />
            <Legend />
            <Bar dataKey="sales" name="المبيعات" fill="#14a86a" radius={[4, 4, 0, 0]} />
            <Bar dataKey="target" name="الهدف" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Channel Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {channelData.map((ch, i) => {
          const Icon = channelIcons[ch.channel] || Store;
          const achievement = ((ch.sales / targets[ch.channel]) * 100).toFixed(1);
          return (
            <motion.div
              key={ch.channel}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.05 * i }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <Icon size={20} className="text-green-700 dark:text-green-400" />
                </div>
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${ch.growth >= 0 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                  {ch.growth >= 0 ? '+' : ''}{ch.growth}%
                </span>
              </div>
              <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{ch.channel}</h4>
              <p className="text-lg font-bold text-green-700 dark:text-green-400 mt-1">{formatCurrency(ch.sales)}</p>
              <div className="mt-2">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-textMuted">التحقيق</span>
                  <span className="font-medium">{achievement}%</span>
                </div>
                <div className="w-full h-1.5 bg-surface dark:bg-darkCard rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, Number(achievement))}%` }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className={`h-full rounded-full ${Number(achievement) >= 100 ? 'bg-green-500' : Number(achievement) >= 80 ? 'bg-amber-500' : 'bg-red-500'}`}
                  />
                </div>
              </div>
              <p className="text-xs text-textSecondary mt-2">هامش الربح: {ch.profitMargin}%</p>
              <button
                onClick={() => setShowDetail(ch.channel)}
                className="mt-3 w-full flex items-center justify-center gap-1 py-1.5 rounded-lg text-xs font-medium text-green-700 bg-green-50 hover:bg-green-100 dark:bg-green-950/20 dark:text-green-400 transition-colors"
              >
                <Eye size={12} />
                عرض التفاصيل
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Target Setting */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5"
      >
        <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <Target size={16} className="text-green-600" />
          تحديد الأهداف السنوية
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {channelData.map((ch) => (
            <div key={ch.channel}>
              <label className="text-xs text-textSecondary mb-1 block">{ch.channel}</label>
              <input
                type="number"
                value={targets[ch.channel]}
                onChange={(e) => handleTargetChange(ch.channel, e.target.value)}
                className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm"
              />
            </div>
          ))}
        </div>
        <div className="mt-3 p-3 rounded-lg bg-green-50 dark:bg-green-950/20">
          <p className="text-sm text-green-700 dark:text-green-400">إجمالي الهدف: {formatCurrency(totalTarget)}</p>
        </div>
      </motion.div>

      {/* Channel Detail Modal */}
      <AnimatePresence>
        {showDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
            onClick={() => setShowDetail(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg"
            >
              <div className="flex items-center justify-between p-5 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{showDetail} - أفضل العملاء</h3>
                <button onClick={() => setShowDetail(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-5">
                <div className="space-y-3">
                  {detailData.map((c, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-surface dark:bg-darkCard">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-textPrimary dark:text-darkText">{c.name}</span>
                        <span className="text-sm font-bold text-green-600">{formatCurrency(c.sales)}</span>
                      </div>
                      <div className="flex gap-4 mt-1 text-xs text-textSecondary">
                        <span>{c.orders} طلب</span>
                        <span>متوسط: {formatCurrency(c.avgOrder)}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-3 rounded-lg bg-blue-50 dark:bg-blue-950/20">
                  <p className="text-sm text-blue-700 dark:text-blue-400">
                    متوسط قيمة الطلب: {formatCurrency(Math.round(detailData.reduce((s, c) => s + c.avgOrder, 0) / detailData.length))}
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
