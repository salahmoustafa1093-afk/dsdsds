// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users,
  UserCheck,
  UserPlus,
  AlertTriangle,
  Search,
  Plus,
  X,
  Eye,
  Edit3,
  Trash2,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  FileText,
  Crown,
  Star,
  TrendingUp,
  Building2,
  Store,
  Truck,
  XCircle,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
interface Customer {
  id: number;
  code: string;
  name: string;
  type: 'مربي' | 'موزع' | 'تاجر جملة';
  phone: string;
  email: string;
  address: string;
  city: string;
  taxNumber: string;
  sales: number;
  balance: number;
  creditLimit: number;
  classification: 'VIP' | 'نشط' | 'متوسط' | 'جديد' | 'متوقف';
  status: 'نشط' | 'متوقف';
  paymentTerms: string;
  notes: string;
  joinDate: string;
  transactions: { date: string; type: string; ref: string; amount: number }[];
  debtAging: { bucket30: number; bucket60: number; bucket90: number; bucket120: number };
}

/* ------------------------------------------------------------------ */
/*  MOCK DATA                                                          */
/* ------------------------------------------------------------------ */
const mockCustomers: Customer[] = [
  { id: 1, code: 'CUST-001', name: 'مزرعة النيل للدواجن', type: 'مربي', phone: '01001234567', email: 'nile@farm.com', address: 'طريق مصر إسماعيلية الصحراوي', city: 'القاهرة', taxNumber: '301-245-889', sales: 2850000, balance: 125000, creditLimit: 500000, classification: 'VIP', status: 'نشط', paymentTerms: '30 يوم', notes: 'من كبار العملاء', joinDate: '2022-01-15', transactions: [{ date: '2024-01-10', type: 'فاتورة', ref: 'INV-1001', amount: 45000 }, { date: '2024-01-05', type: 'دفعة', ref: 'PAY-501', amount: -30000 }], debtAging: { bucket30: 75000, bucket60: 30000, bucket90: 20000, bucket120: 0 } },
  { id: 2, code: 'CUST-002', name: 'شركة مصر للإنتاج الداجني', type: 'تاجر جملة', phone: '01002345678', email: 'misr@poultry.com', address: 'المنطقة الصناعية', city: 'الإسكندرية', taxNumber: '302-156-774', sales: 4200000, balance: 320000, creditLimit: 800000, classification: 'VIP', status: 'نشط', paymentTerms: '45 يوم', notes: 'تاجر جملة كبير', joinDate: '2021-06-20', transactions: [{ date: '2024-01-12', type: 'فاتورة', ref: 'INV-1010', amount: 120000 }], debtAging: { bucket30: 150000, bucket60: 100000, bucket90: 70000, bucket120: 0 } },
  { id: 3, code: 'CUST-003', name: 'مزارع الأمل', type: 'مربي', phone: '01003456789', email: 'amal@farms.com', address: 'كفر الشيخ', city: 'كفر الشيخ', taxNumber: '303-789-112', sales: 890000, balance: 45000, creditLimit: 200000, classification: 'نشط', status: 'نشط', paymentTerms: 'نقدي', notes: '', joinDate: '2023-03-10', transactions: [{ date: '2024-01-08', type: 'فاتورة', ref: 'INV-1005', amount: 22000 }], debtAging: { bucket30: 45000, bucket60: 0, bucket90: 0, bucket120: 0 } },
  { id: 4, code: 'CUST-004', name: 'دواجن السلام', type: 'مربي', phone: '01004567890', email: 'salam@eggs.com', address: 'طنطا', city: 'الغربية', taxNumber: '304-334-556', sales: 1560000, balance: 180000, creditLimit: 300000, classification: 'نشط', status: 'نشط', paymentTerms: '30 يوم', notes: '', joinDate: '2022-08-05', transactions: [{ date: '2024-01-15', type: 'فاتورة', ref: 'INV-1020', amount: 60000 }], debtAging: { bucket30: 80000, bucket60: 60000, bucket90: 40000, bucket120: 0 } },
  { id: 5, code: 'CUST-005', name: 'شركة الدلتا للتوزيع', type: 'موزع', phone: '01005678901', email: 'delta@dist.com', address: 'المنصورة', city: 'الدقهلية', taxNumber: '305-667-990', sales: 3100000, balance: 210000, creditLimit: 600000, classification: 'VIP', status: 'نشط', paymentTerms: '60 يوم', notes: 'موزع رئيسي', joinDate: '2021-11-01', transactions: [{ date: '2024-01-14', type: 'فاتورة', ref: 'INV-1018', amount: 95000 }], debtAging: { bucket30: 100000, bucket60: 80000, bucket90: 30000, bucket120: 0 } },
  { id: 6, code: 'CUST-006', name: 'مزرعة الهدى', type: 'مربي', phone: '01006789012', email: 'huda@farm.com', address: 'بنها', city: 'القليوبية', taxNumber: '306-112-338', sales: 520000, balance: 15000, creditLimit: 100000, classification: 'جديد', status: 'نشط', paymentTerms: 'نقدي', notes: 'عميل جديد', joinDate: '2023-12-01', transactions: [{ date: '2024-01-02', type: 'فاتورة', ref: 'INV-998', amount: 15000 }], debtAging: { bucket30: 15000, bucket60: 0, bucket90: 0, bucket120: 0 } },
  { id: 7, code: 'CUST-007', name: 'مؤسسة النور للدواجن', type: 'موزع', phone: '01007890123', email: 'nour@poultry.com', address: 'الزقازيق', city: 'الشرقية', taxNumber: '307-445-771', sales: 1780000, balance: 95000, creditLimit: 400000, classification: 'متوسط', status: 'نشط', paymentTerms: '30 يوم', notes: '', joinDate: '2022-04-18', transactions: [{ date: '2024-01-11', type: 'فاتورة', ref: 'INV-1008', amount: 35000 }], debtAging: { bucket30: 50000, bucket60: 45000, bucket90: 0, bucket120: 0 } },
  { id: 8, code: 'CUST-008', name: 'مزارع البركة', type: 'مربي', phone: '01008901234', email: 'baraka@farm.com', address: 'دمنهور', city: 'البحيرة', taxNumber: '308-778-003', sales: 640000, balance: 85000, creditLimit: 150000, classification: 'متوسط', status: 'نشط', paymentTerms: 'نقدي', notes: '', joinDate: '2023-01-22', transactions: [{ date: '2024-01-09', type: 'فاتورة', ref: 'INV-1006', amount: 28000 }], debtAging: { bucket30: 35000, bucket60: 30000, bucket90: 20000, bucket120: 0 } },
  { id: 9, code: 'CUST-009', name: 'شركة الصفا للتجارة', type: 'تاجر جملة', phone: '01009012345', email: 'safa@trade.com', address: 'أسيوط', city: 'أسيوط', taxNumber: '309-001-224', sales: 2340000, balance: 0, creditLimit: 700000, classification: 'VIP', status: 'نشط', paymentTerms: '45 يوم', notes: 'دقيق في المواعيد', joinDate: '2021-09-14', transactions: [{ date: '2024-01-01', type: 'دفعة', ref: 'PAY-500', amount: -50000 }], debtAging: { bucket30: 0, bucket60: 0, bucket90: 0, bucket120: 0 } },
  { id: 10, code: 'CUST-010', name: 'مزرعة الفردوس', type: 'مربي', phone: '01010123456', email: 'firdaus@farm.com', address: 'سوهاج', city: 'سوهاج', taxNumber: '310-556-887', sales: 375000, balance: 22000, creditLimit: 80000, classification: 'جديد', status: 'نشط', paymentTerms: 'نقدي', notes: '', joinDate: '2023-11-15', transactions: [{ date: '2024-01-07', type: 'فاتورة', ref: 'INV-1004', amount: 12000 }], debtAging: { bucket30: 22000, bucket60: 0, bucket90: 0, bucket120: 0 } },
  { id: 11, code: 'CUST-011', name: 'توزيع الغربية', type: 'موزع', phone: '01011234567', email: 'gharbia@dist.com', address: 'طنطا', city: 'الغربية', taxNumber: '311-889-330', sales: 1950000, balance: 145000, creditLimit: 350000, classification: 'نشط', status: 'نشط', paymentTerms: '30 يوم', notes: '', joinDate: '2022-07-30', transactions: [{ date: '2024-01-13', type: 'فاتورة', ref: 'INV-1015', amount: 55000 }], debtAging: { bucket30: 80000, bucket60: 45000, bucket90: 20000, bucket120: 0 } },
  { id: 12, code: 'CUST-012', name: 'مزرعة الرحمة', type: 'مربي', phone: '01012345678', email: 'rahma@farm.com', address: 'شبين الكوم', city: 'المنوفية', taxNumber: '312-223-665', sales: 280000, balance: 0, creditLimit: 50000, classification: 'متوقف', status: 'متوقف', paymentTerms: 'نقدي', notes: 'متوقف مؤقتاً', joinDate: '2023-05-20', transactions: [], debtAging: { bucket30: 0, bucket60: 0, bucket90: 0, bucket120: 0 } },
  { id: 13, code: 'CUST-013', name: 'شركة بدر للإنتاج', type: 'تاجر جملة', phone: '01013456789', email: 'badr@prod.com', address: 'دمياط', city: 'دمياط', taxNumber: '313-667-118', sales: 3560000, balance: 280000, creditLimit: 900000, classification: 'VIP', status: 'نشط', paymentTerms: '60 يوم', notes: 'تاجر جملة ممتاز', joinDate: '2021-03-01', transactions: [{ date: '2024-01-16', type: 'فاتورة', ref: 'INV-1022', amount: 140000 }], debtAging: { bucket30: 150000, bucket60: 80000, bucket90: 50000, bucket120: 0 } },
  { id: 14, code: 'CUST-014', name: 'مزرعة النجمة', type: 'مربي', phone: '01014567890', email: 'najma@farm.com', address: 'الفيوم', city: 'الفيوم', taxNumber: '314-990-442', sales: 740000, balance: 35000, creditLimit: 120000, classification: 'نشط', status: 'نشط', paymentTerms: 'نقدي', notes: '', joinDate: '2023-02-14', transactions: [{ date: '2024-01-06', type: 'فاتورة', ref: 'INV-1003', amount: 20000 }], debtAging: { bucket30: 35000, bucket60: 0, bucket90: 0, bucket120: 0 } },
  { id: 15, code: 'CUST-015', name: 'مؤسسة الأمانة للتوزيع', type: 'موزع', phone: '01015678901', email: 'amana@dist.com', address: 'المنيا', city: 'المنيا', taxNumber: '315-334-775', sales: 1420000, balance: 68000, creditLimit: 250000, classification: 'متوسط', status: 'نشط', paymentTerms: '30 يوم', notes: '', joinDate: '2022-10-05', transactions: [{ date: '2024-01-04', type: 'فاتورة', ref: 'INV-1002', amount: 25000 }], debtAging: { bucket30: 40000, bucket60: 28000, bucket90: 0, bucket120: 0 } },
];

/* ------------------------------------------------------------------ */
/*  CLASSIFICATION BADGE                                               */
/* ------------------------------------------------------------------ */
function ClassificationBadge({ cls }: { cls: string }) {
  const styles: Record<string, string> = {
    VIP: 'bg-gold-100 text-gold-700 border-gold-300',
    نشط: 'bg-green-100 text-green-700 border-green-300',
    متوسط: 'bg-blue-100 text-blue-700 border-blue-300',
    جديد: 'bg-cyan-100 text-cyan-700 border-cyan-300',
    متوقف: 'bg-gray-100 text-gray-600 border-gray-300',
  };
  const icons: Record<string, React.ElementType> = {
    VIP: Crown,
    نشط: Star,
    متوسط: TrendingUp,
    جديد: UserPlus,
    متوقف: XCircle,
  };
  const Icon = icons[cls] || Star;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${styles[cls] || styles['متوسط']}`}>
      <Icon size={12} /> {cls}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  STATUS BADGE                                                       */
/* ------------------------------------------------------------------ */
function StatusBadge({ status }: { status: string }) {
  return status === 'نشط' ? (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 border border-green-300">
      <CheckCircle2 size={12} /> نشط
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 border border-gray-300">
      <XCircle size={12} /> متوقف
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>(mockCustomers);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterCity, setFilterCity] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterClassification, setFilterClassification] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null);
  const [form, setForm] = useState<Partial<Customer>>({});

  const cities = [...new Set(mockCustomers.map((c) => c.city))];

  /* ── KPIs ── */
  const totalCustomers = customers.length;
  const activeCustomers = customers.filter((c) => c.status === 'نشط').length;
  const newThisMonth = customers.filter((c) => {
    const d = new Date(c.joinDate);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).length;
  const totalDebt = customers.reduce((s, c) => s + c.balance, 0);
  const overLimitCount = customers.filter((c) => c.balance > c.creditLimit).length;

  /* ── Filtered data ── */
  const filteredData = useMemo(() => {
    let result = [...customers];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (c) =>
          c.name.includes(q) || c.code.toLowerCase().includes(q) || c.phone.includes(q)
      );
    }
    if (filterType) result = result.filter((c) => c.type === filterType);
    if (filterCity) result = result.filter((c) => c.city === filterCity);
    if (filterStatus) result = result.filter((c) => c.status === filterStatus);
    if (filterClassification) result = result.filter((c) => c.classification === filterClassification);
    return result;
  }, [customers, searchQuery, filterType, filterCity, filterStatus, filterClassification]);

  /* ── Form helpers ── */
  const openAdd = () => {
    setEditingCustomer(null);
    setForm({ status: 'نشط', classification: 'جديد', creditLimit: 0, balance: 0, sales: 0, paymentTerms: 'نقدي', city: 'القاهرة', type: 'مربي' });
    setModalOpen(true);
  };

  const openEdit = (c: Customer) => {
    setEditingCustomer(c);
    setForm({ ...c });
    setModalOpen(true);
  };

  const openDetail = (c: Customer) => {
    setViewingCustomer(c);
    setDetailOpen(true);
  };

  const saveCustomer = () => {
    if (!form.name) return;
    if (editingCustomer) {
      setCustomers((prev) =>
        prev.map((c) => (c.id === editingCustomer.id ? { ...c, ...form } as Customer : c))
      );
    } else {
      const newId = Math.max(...customers.map((c) => c.id)) + 1;
      setCustomers((prev) => [
        ...prev,
        { ...form, id: newId, code: `CUST-${String(newId).padStart(3, '0')}`, transactions: [], debtAging: { bucket30: 0, bucket60: 0, bucket90: 0, bucket120: 0 } } as Customer,
      ]);
    }
    setModalOpen(false);
  };

  const deleteCustomer = (id: number) => {
    if (confirm('هل أنت متأكد من حذف هذا العميل؟')) {
      setCustomers((prev) => prev.filter((c) => c.id !== id));
    }
  };

  const resetFilters = () => {
    setSearchQuery('');
    setFilterType('');
    setFilterCity('');
    setFilterStatus('');
    setFilterClassification('');
  };

  /* ── Table columns ── */
  const columns = [
    { key: 'code', header: 'الكود', sortable: true, width: '90px' },
    { key: 'name', header: 'الاسم', sortable: true },
    { key: 'type', header: 'النوع', sortable: true, width: '90px' },
    { key: 'phone', header: 'الهاتف', width: '110px' },
    { key: 'city', header: 'المدينة', sortable: true, width: '90px' },
    {
      key: 'sales',
      header: 'المبيعات',
      sortable: true,
      width: '110px',
      render: (row: Customer) => row.sales.toLocaleString('ar-EG'),
    },
    {
      key: 'balance',
      header: 'الرصيد',
      sortable: true,
      width: '100px',
      render: (row: Customer) => (
        <span className={row.balance > row.creditLimit ? 'text-red-600 font-semibold' : ''}>
          {row.balance.toLocaleString('ar-EG')}
        </span>
      ),
    },
    {
      key: 'creditLimit',
      header: 'الحد الائتماني',
      sortable: true,
      width: '100px',
      render: (row: Customer) => row.creditLimit.toLocaleString('ar-EG'),
    },
    {
      key: 'classification',
      header: 'التصنيف',
      width: '90px',
      render: (row: Customer) => <ClassificationBadge cls={row.classification} />,
    },
    {
      key: 'status',
      header: 'الحالة',
      width: '80px',
      render: (row: Customer) => <StatusBadge status={row.status} />,
    },
  ];

  return (
    <div className="gff-page-transition space-y-6">
      <PageHeader
        title="إدارة العملاء"
        subtitle="إدارة قاعدة بيانات العملاء والتصنيفات والمتابعة"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'العملاء' }]}
      >
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors shadow-sm"
        >
          <Plus size={16} /> عميل جديد
        </button>
      </PageHeader>

      {/* ── KPIs ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="إجمالي العملاء" value={totalCustomers.toLocaleString('ar-EG')} icon={Users} iconBg="bg-blue-50" iconColor="text-blue-600" change={8} delay={0} />
        <KPICard title="نشطين" value={activeCustomers.toLocaleString('ar-EG')} icon={UserCheck} iconBg="bg-green-50" iconColor="text-green-600" change={3} delay={0.05} />
        <KPICard title="جدد هذا الشهر" value={newThisMonth.toLocaleString('ar-EG')} icon={UserPlus} iconBg="bg-cyan-50" iconColor="text-cyan-600" delay={0.1} />
        <KPICard title="إجمالي المديونية" value={totalDebt.toLocaleString('ar-EG')} icon={CreditCard} iconBg="bg-amber-50" iconColor="text-amber-600" change={-2} changeLabel="عن الشهر السابق" delay={0.15} />
        <KPICard title="فوق الحد الائتماني" value={overLimitCount.toLocaleString('ar-EG')} icon={AlertTriangle} iconBg="bg-red-50" iconColor="text-red-600" change={-1} changeLabel="تحسن" delay={0.2} />
      </div>

      {/* ── Filters ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.25 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4"
      >
        <div className="flex flex-col lg:flex-row gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[220px]">
            <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
            <input
              type="text"
              placeholder="بحث بالاسم أو الكود أو الهاتف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pr-10 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
            />
          </div>
          <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل الأنواع</option>
            <option value="مربي">مربي</option>
            <option value="موزع">موزع</option>
            <option value="تاجر جملة">تاجر جملة</option>
          </select>
          <select value={filterCity} onChange={(e) => setFilterCity(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل المدن</option>
            {cities.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل الحالات</option>
            <option value="نشط">نشط</option>
            <option value="متوقف">متوقف</option>
          </select>
          <select value={filterClassification} onChange={(e) => setFilterClassification(e.target.value)} className="h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm">
            <option value="">كل التصنيفات</option>
            <option value="VIP">VIP</option>
            <option value="نشط">نشط</option>
            <option value="متوسط">متوسط</option>
            <option value="جديد">جديد</option>
            <option value="متوقف">متوقف</option>
          </select>
          <button onClick={resetFilters} className="h-10 px-4 rounded-lg border border-uiBorder dark:border-darkBorder text-textSecondary hover:bg-surface dark:hover:bg-darkCard text-sm transition-colors">
            إعادة ضبط
          </button>
        </div>
      </motion.div>

      {/* ── Table ── */}
      <DataTable
        columns={columns}
        data={filteredData}
        pageSize={10}
        title={`العملاء (${filteredData.length})`}
        rowActions={{
          onView: openDetail,
          onEdit: openEdit,
          onDelete: (row) => deleteCustomer(row.id),
        }}
      />

      {/* ═══════════════════ ADD/EDIT MODAL ═══════════════════ */}
      <AnimatePresence>
        {modalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">
                  {editingCustomer ? 'تعديل عميل' : 'عميل جديد'}
                </h3>
                <button onClick={() => setModalOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface dark:hover:bg-darkCard transition-colors">
                  <X size={18} />
                </button>
              </div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">اسم العميل *</label>
                  <input value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">النوع</label>
                  <select value={form.type || ''} onChange={(e) => setForm({ ...form, type: e.target.value as any })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="مربي">مربي</option>
                    <option value="موزع">موزع</option>
                    <option value="تاجر جملة">تاجر جملة</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الهاتف</label>
                  <input value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" dir="ltr" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">البريد الإلكتروني</label>
                  <input value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" dir="ltr" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">العنوان</label>
                  <input value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">المدينة</label>
                  <input value={form.city || ''} onChange={(e) => setForm({ ...form, city: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الرقم الضريبي</label>
                  <input value={form.taxNumber || ''} onChange={(e) => setForm({ ...form, taxNumber: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" dir="ltr" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الحد الائتماني</label>
                  <input type="number" value={form.creditLimit || 0} onChange={(e) => setForm({ ...form, creditLimit: +e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">شروط الدفع</label>
                  <select value={form.paymentTerms || ''} onChange={(e) => setForm({ ...form, paymentTerms: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="نقدي">نقدي</option>
                    <option value="30 يوم">30 يوم</option>
                    <option value="45 يوم">45 يوم</option>
                    <option value="60 يوم">60 يوم</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">التصنيف</label>
                  <select value={form.classification || ''} onChange={(e) => setForm({ ...form, classification: e.target.value as any })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="VIP">VIP</option>
                    <option value="نشط">نشط</option>
                    <option value="متوسط">متوسط</option>
                    <option value="جديد">جديد</option>
                    <option value="متوقف">متوقف</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">الحالة</label>
                  <select value={form.status || ''} onChange={(e) => setForm({ ...form, status: e.target.value as any })} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm">
                    <option value="نشط">نشط</option>
                    <option value="متوقف">متوقف</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-textSecondary mb-1.5">ملاحظات</label>
                  <textarea value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={3} className="w-full px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm resize-none" />
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-uiBorder dark:border-darkBorder">
                <button onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm transition-colors">إلغاء</button>
                <button onClick={saveCustomer} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 text-white text-sm font-medium transition-colors">حفظ</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ═══════════════════ DETAIL MODAL ═══════════════════ */}
      <AnimatePresence>
        {detailOpen && viewingCustomer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-700 flex items-center justify-center text-white font-bold text-lg">
                    {viewingCustomer.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">{viewingCustomer.name}</h3>
                    <p className="text-xs text-textMuted">{viewingCustomer.code}</p>
                  </div>
                </div>
                <button onClick={() => setDetailOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Info Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">النوع</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingCustomer.type}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">التصنيف</p>
                    <ClassificationBadge cls={viewingCustomer.classification} />
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الهاتف</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText dir-ltr text-left">{viewingCustomer.phone}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">المدينة</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingCustomer.city}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الرقم الضريبي</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingCustomer.taxNumber}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">شروط الدفع</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingCustomer.paymentTerms}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">تاريخ الالتحاق</p>
                    <p className="text-sm font-medium text-textPrimary dark:text-darkText">{viewingCustomer.joinDate}</p>
                  </div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3">
                    <p className="text-[11px] text-textMuted mb-1">الحالة</p>
                    <StatusBadge status={viewingCustomer.status} />
                  </div>
                </div>

                {/* Financial Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                    <p className="text-xs text-green-600 dark:text-green-400 mb-1">إجمالي المبيعات</p>
                    <p className="text-xl font-bold text-green-700 dark:text-green-300">{viewingCustomer.sales.toLocaleString('ar-EG')} ج.م</p>
                  </div>
                  <div className="bg-amber-50 dark:bg-amber-950/20 rounded-lg p-4 border border-amber-200 dark:border-amber-800">
                    <p className="text-xs text-amber-600 dark:text-amber-400 mb-1">الرصيد المستحق</p>
                    <p className={`text-xl font-bold ${viewingCustomer.balance > viewingCustomer.creditLimit ? 'text-red-600' : 'text-amber-700 dark:text-amber-300'}`}>{viewingCustomer.balance.toLocaleString('ar-EG')} ج.م</p>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
                    <p className="text-xs text-blue-600 dark:text-blue-400 mb-1">الحد الائتماني</p>
                    <p className="text-xl font-bold text-blue-700 dark:text-blue-300">{viewingCustomer.creditLimit.toLocaleString('ar-EG')} ج.م</p>
                  </div>
                </div>

                {/* Credit Usage Bar */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-textSecondary">نسبة استهلاك الائتمان</span>
                    <span className="text-sm font-semibold text-textPrimary">{Math.round((viewingCustomer.balance / viewingCustomer.creditLimit) * 100)}%</span>
                  </div>
                  <div className="w-full h-3 bg-surface dark:bg-darkCard rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, (viewingCustomer.balance / viewingCustomer.creditLimit) * 100)}%` }}
                      transition={{ duration: 0.5 }}
                      className={`h-full rounded-full ${viewingCustomer.balance > viewingCustomer.creditLimit ? 'bg-red-500' : viewingCustomer.balance > viewingCustomer.creditLimit * 0.8 ? 'bg-amber-500' : 'bg-green-500'}`}
                    />
                  </div>
                </div>

                {/* Debt Aging */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">تقسيم المديونية</h4>
                  <div className="grid grid-cols-4 gap-3">
                    {[
                      { label: '0-30 يوم', value: viewingCustomer.debtAging.bucket30, color: 'bg-green-500' },
                      { label: '31-60 يوم', value: viewingCustomer.debtAging.bucket60, color: 'bg-amber-500' },
                      { label: '61-90 يوم', value: viewingCustomer.debtAging.bucket90, color: 'bg-orange-500' },
                      { label: '120+ يوم', value: viewingCustomer.debtAging.bucket120, color: 'bg-red-500' },
                    ].map((b) => (
                      <div key={b.label} className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center">
                        <p className="text-[11px] text-textMuted mb-1">{b.label}</p>
                        <p className="text-base font-bold text-textPrimary dark:text-darkText">{b.value.toLocaleString('ar-EG')}</p>
                        <div className="w-full h-1.5 bg-gray-200 dark:bg-darkBorder rounded-full mt-2 overflow-hidden">
                          <div className={`h-full ${b.color} rounded-full`} style={{ width: `${Math.max(5, (b.value / Math.max(viewingCustomer.balance, 1)) * 100)}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Transaction History */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">سجل المعاملات</h4>
                  <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">النوع</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">المرجع</th>
                          <th className="px-3 py-2 text-right text-xs text-textSecondary">المبلغ</th>
                        </tr>
                      </thead>
                      <tbody>
                        {viewingCustomer.transactions.length === 0 ? (
                          <tr>
                            <td colSpan={4} className="px-3 py-6 text-center text-textMuted text-sm">لا توجد معاملات</td>
                          </tr>
                        ) : (
                          viewingCustomer.transactions.map((t, i) => (
                            <tr key={i} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                              <td className="px-3 py-2 text-textPrimary dark:text-darkText">{t.date}</td>
                              <td className="px-3 py-2">
                                <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${t.type === 'فاتورة' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>{t.type}</span>
                              </td>
                              <td className="px-3 py-2 text-textPrimary dark:text-darkText">{t.ref}</td>
                              <td className={`px-3 py-2 font-medium ${t.amount > 0 ? 'text-red-600' : 'text-green-600'}`}>{t.amount > 0 ? '+' : ''}{t.amount.toLocaleString('ar-EG')}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
