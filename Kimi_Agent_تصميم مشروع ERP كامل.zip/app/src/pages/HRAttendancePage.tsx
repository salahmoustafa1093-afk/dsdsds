import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Clock, LogIn, LogOut, CalendarDays, TrendingUp, X, CheckCircle2, AlertCircle,
  UserCheck, UserX, Timer,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

// ─── Mock Data ──────────────────────────────────────────
const employees = ['أحمد محمود', 'محمد علي', 'فاطمة أحمد', 'خالد عمر', 'سارة محمود', 'محمود سالم', 'نورا إبراهيم', 'عبدالله حسن'];

const attendanceData: Record<number, Record<string, string>> = {
  1: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'غ', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  2: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ت', 'عبدالله حسن': 'ح' },
  3: { 'أحمد محمود': 'ح', 'محمد علي': 'غ', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  4: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'غ' },
  5: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ت', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  6: { 'أحمد محمود': 'إ', 'محمد علي': 'إ', 'فاطمة أحمد': 'إ', 'خالد عمر': 'إ', 'سارة محمود': 'إ', 'محمود سالم': 'إ', 'نورا إبراهيم': 'إ', 'عبدالله حسن': 'إ' },
  7: { 'أحمد محمود': 'إ', 'محمد علي': 'إ', 'فاطمة أحمد': 'إ', 'خالد عمر': 'إ', 'سارة محمود': 'إ', 'محمود سالم': 'إ', 'نورا إبراهيم': 'إ', 'عبدالله حسن': 'إ' },
  8: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'غ', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ت' },
  9: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  10: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ت', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  11: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  12: { 'أحمد محمود': 'ح', 'محمد علي': 'ت', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'غ', 'عبدالله حسن': 'ح' },
  13: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  14: { 'أحمد محمود': 'ح', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ت', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
  15: { 'أحمد محمود': 'غ', 'محمد علي': 'ح', 'فاطمة أحمد': 'ح', 'خالد عمر': 'ح', 'سارة محمود': 'ح', 'محمود سالم': 'ح', 'نورا إبراهيم': 'ح', 'عبدالله حسن': 'ح' },
};

const statusMap: Record<string, { label: string; color: string }> = {
  'ح': { label: 'حاضر', color: 'bg-green-500' },
  'غ': { label: 'غائب', color: 'bg-red-500' },
  'ت': { label: 'متأخر', color: 'bg-orange-500' },
  'إ': { label: 'إجازة', color: 'bg-blue-500' },
};

export default function HRAttendancePage() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showManualForm, setShowManualForm] = useState(false);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [checkedIn, setCheckedIn] = useState(false);
  const [checkedOut, setCheckedOut] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (d: Date) => d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  const formatDate = (d: Date) => d.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  const totalDays = Object.keys(attendanceData).length;
  const presentCount = Object.values(attendanceData).reduce((s, day) => s + Object.values(day).filter(v => v === 'ح').length, 0);
  const absentCount = Object.values(attendanceData).reduce((s, day) => s + Object.values(day).filter(v => v === 'غ').length, 0);
  const lateCount = Object.values(attendanceData).reduce((s, day) => s + Object.values(day).filter(v => v === 'ت').length, 0);
  const overtimeHours = 24;

  const presentRate = Math.round((presentCount / (employees.length * totalDays)) * 100);

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="تتبع الحضور والانصراف"
        subtitle="تسجيل ومتابعة حضور الموظفين"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'الموارد البشرية', path: '/hr' },
          { label: 'الحضور' },
        ]}
      >
        <button onClick={() => setShowManualForm(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm">
          <Clock size={16} /> تسجيل يدوي
        </button>
      </PageHeader>

      {/* Digital Clock & Action Buttons */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="lg:col-span-1 bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-6 text-center">
          <Clock size={32} className="mx-auto text-green-600 mb-3" />
          <div className="text-[42px] font-bold text-textPrimary dark:text-darkText font-mono leading-tight">{formatTime(currentTime)}</div>
          <p className="text-sm text-textSecondary mt-2">{formatDate(currentTime)}</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }} className="lg:col-span-2 grid grid-cols-2 gap-4">
          <button
            onClick={() => setCheckedIn(true)}
            disabled={checkedIn}
            className={`rounded-xl border-2 flex flex-col items-center justify-center gap-2 transition-all ${checkedIn ? 'border-green-700 bg-green-50 dark:bg-green-900/20' : 'border-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 bg-white dark:bg-darkSurface'}`}
          >
            <LogIn size={36} className={checkedIn ? 'text-green-700' : 'text-green-600'} />
            <span className={`text-lg font-bold ${checkedIn ? 'text-green-800' : 'text-green-700'}`}>{checkedIn ? 'تم تسجيل الحضور' : 'تسجيل حضور'}</span>
            {checkedIn && <CheckCircle2 size={16} className="text-green-600" />}
          </button>
          <button
            onClick={() => setCheckedOut(true)}
            disabled={!checkedIn || checkedOut}
            className={`rounded-xl border-2 flex flex-col items-center justify-center gap-2 transition-all ${checkedOut ? 'border-red-700 bg-red-50 dark:bg-red-900/20' : 'border-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 bg-white dark:bg-darkSurface'}`}
          >
            <LogOut size={36} className={checkedOut ? 'text-red-700' : 'text-red-500'} />
            <span className={`text-lg font-bold ${checkedOut ? 'text-red-800' : 'text-red-600'}`}>{checkedOut ? 'تم تسجيل الانصراف' : 'تسجيل انصراف'}</span>
            {checkedOut && <CheckCircle2 size={16} className="text-red-600" />}
          </button>
        </motion.div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="نسبة الحضور" value={`%${presentRate}`} icon={UserCheck} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} change={2} />
        <KPICard title="عدد الغياب" value={String(absentCount)} icon={UserX} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.1} change={-3} />
        <KPICard title="التأخير" value={String(lateCount)} icon={AlertCircle} iconBg="bg-orange-100 dark:bg-orange-900/30" iconColor="text-orange-600 dark:text-orange-400" delay={0.2} />
        <KPICard title="ساعات إضافية" value={String(overtimeHours)} icon={Timer} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.3} />
      </div>

      {/* Monthly Attendance Grid */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
        <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2"><CalendarDays size={18} /> شبكة الحضور الشهرية - يناير 2025</h3>
          <div className="flex items-center gap-3 text-xs">
            {Object.entries(statusMap).map(([key, val]) => (
              <span key={key} className="flex items-center gap-1"><span className={`w-2.5 h-2.5 rounded-full ${val.color}`} /> {val.label}</span>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                <th className="px-3 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec min-w-[120px] sticky right-0 bg-surface dark:bg-darkBg/60 z-10">الموظف</th>
                {Array.from({ length: 15 }, (_, i) => (
                  <th key={i + 1} className="px-2 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec w-10">{i + 1}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.map((emp) => (
                <tr key={emp} className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors">
                  <td className="px-3 py-2 text-sm font-medium text-textPrimary dark:text-darkText sticky right-0 bg-white dark:bg-darkSurface z-10">{emp}</td>
                  {Array.from({ length: 15 }, (_, i) => {
                    const day = i + 1;
                    const code = attendanceData[day]?.[emp] || '';
                    const status = statusMap[code];
                    return (
                      <td key={day} className="px-1 py-2 text-center">
                        {status && (
                          <button
                            onClick={() => setSelectedDay(day)}
                            className={`w-6 h-6 rounded-full ${status.color} text-white text-[10px] font-bold inline-flex items-center justify-center hover:scale-110 transition-transform`}
                            title={`${emp} - ${day} يناير: ${status.label}`}
                          >
                            {code}
                          </button>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Day Detail Modal */}
      <AnimatePresence>
        {selectedDay && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setSelectedDay(null)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تفاصيل يوم {selectedDay} يناير 2025</h3>
                <button onClick={() => setSelectedDay(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-2">
                {employees.map(emp => {
                  const code = attendanceData[selectedDay]?.[emp] || '';
                  const status = statusMap[code];
                  return (
                    <div key={emp} className="flex items-center justify-between py-2 border-b border-uiBorder/30 last:border-0">
                      <span className="text-sm text-textPrimary dark:text-darkText">{emp}</span>
                      {status ? (
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold text-white ${status.color}`}>{status.label}</span>
                      ) : (
                        <span className="text-xs text-textMuted">—</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Manual Entry Modal */}
      <AnimatePresence>
        {showManualForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowManualForm(false)}>
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} onClick={e => e.stopPropagation()} className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-md">
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">تسجيل حضور يدوي</h3>
                <button onClick={() => setShowManualForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div><label className="block text-xs font-medium text-textSecondary mb-1">الموظف</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm">{employees.map(e => <option key={e}>{e}</option>)}</select></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">التاريخ</label><input type="date" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الحالة</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>حاضر</option><option>غائب</option><option>متأخر</option><option>إجازة</option></select></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">وقت الدخول</label><input type="time" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">وقت الخروج</label><input type="time" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div><label className="block text-xs font-medium text-textSecondary mb-1">ملاحظات</label><textarea className="w-full h-16 px-3 py-2 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm resize-none" /></div>
                <div className="flex justify-end gap-2 pt-2">
                  <button onClick={() => setShowManualForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">إلغاء</button>
                  <button onClick={() => setShowManualForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors">حفظ</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
