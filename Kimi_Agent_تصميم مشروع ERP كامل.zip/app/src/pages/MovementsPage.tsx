// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import {
  ArrowLeftRight,
  TrendingUp,
  TrendingDown,
  ArrowRightLeft,
  Search,
  Plus,
  Eye,
  Edit3,
  Trash2,
  Filter,
  X,
  Calendar,
  User,
  Package,
  FileText,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

/* ──────────────────────────── mock data ──────────────────────────── */

interface Movement {
  id: string;
  number: string;
  date: string;
  type: 'in' | 'out' | 'transfer' | 'adjust';
  product: string;
  qty: number;
  unit: string;
  warehouse: string;
  reference: string;
  user: string;
  notes: string;
  fromWarehouse?: string;
  toWarehouse?: string;
}

const WAREHOUSES = ['القاهرة', 'الإسكندرية', 'طنطا', 'المنصورة'];

const MOVEMENTS: Movement[] = [
  { id: '1', number: 'MOV-001', date: '2025-06-20 08:30', type: 'in', product: 'ذرة صفراء', qty: 120, unit: 'طن', warehouse: 'القاهرة', reference: 'PO-2025-089', user: 'محمد علي', notes: 'استلام من مورد النصر' },
  { id: '2', number: 'MOV-002', date: '2025-06-20 10:15', type: 'out', product: 'أعلاف دواجن بادئ', qty: 50, unit: 'شيكارة', warehouse: 'القاهرة', reference: 'INV-001', user: 'خالد حسن', notes: 'صادر لفاتورة مزارع الصفا' },
  { id: '3', number: 'MOV-003', date: '2025-06-20 11:00', type: 'transfer', product: 'كسب فول صويا', qty: 80, unit: 'طن', warehouse: 'القاهرة', fromWarehouse: 'القاهرة', toWarehouse: 'الإسكندرية', reference: 'TR-2025-012', user: 'أحمد محمود', notes: 'تحويل لمستودع الإسكندرية' },
  { id: '4', number: 'MOV-004', date: '2025-06-20 14:30', type: 'in', product: 'أعلاف دواجن ناهي', qty: 80, unit: 'شيكارة', warehouse: 'الإسكندرية', reference: 'PO-2025-090', user: 'سعيد فؤاد', notes: 'استلام انتاج المصنع' },
  { id: '5', number: 'MOV-005', date: '2025-06-19 09:00', type: 'out', product: 'كسب فول صويا', qty: 40, unit: 'طن', warehouse: 'الإسكندرية', reference: 'INV-007', user: 'محمد رضا', notes: 'صادر للبركة للتجارة' },
  { id: '6', number: 'MOV-006', date: '2025-06-19 11:30', type: 'transfer', product: 'نخالة قمح', qty: 100, unit: 'طن', warehouse: 'الإسكندرية', fromWarehouse: 'الإسكندرية', toWarehouse: 'طنطا', reference: 'TR-2025-011', user: 'سعيد فؤاد', notes: 'تحويل داخلي' },
  { id: '7', number: 'MOV-007', date: '2025-06-19 14:00', type: 'in', product: 'ردة قمح', qty: 200, unit: 'طن', warehouse: 'القاهرة', reference: 'PO-2025-088', user: 'محمد علي', notes: 'استلام من مطاحن الأمل' },
  { id: '8', number: 'MOV-008', date: '2025-06-18 07:30', type: 'out', product: 'ردة قمح', qty: 150, unit: 'طن', warehouse: 'طنطا', reference: 'INV-004', user: 'علي سالم', notes: 'صادر لمطاحن الأمل' },
  { id: '9', number: 'MOV-009', date: '2025-06-18 10:00', type: 'adjust', product: 'مسحوق عظام', qty: -5, unit: 'كجم', warehouse: 'المنصورة', reference: 'ADJ-2025-003', user: 'علي سالم', notes: 'تسوية مخزون - عجز' },
  { id: '10', number: 'MOV-010', date: '2025-06-18 12:00', type: 'in', product: 'فول صويا كامل', qty: 100, unit: 'طن', warehouse: 'المنصورة', reference: 'PO-2025-087', user: 'علي سالم', notes: 'استلام من مورد البركة' },
  { id: '11', number: 'MOV-011', date: '2025-06-17 09:00', type: 'out', product: 'أعلاف دواجن نامي', qty: 60, unit: 'شيكارة', warehouse: 'المنصورة', reference: 'INV-010', user: 'محمد رضا', notes: 'صادر لشركة الرحمة' },
  { id: '12', number: 'MOV-012', date: '2025-06-17 11:00', type: 'transfer', product: 'أعلاف دواجن بادئ', qty: 100, unit: 'شيكارة', warehouse: 'القاهرة', fromWarehouse: 'القاهرة', toWarehouse: 'المنصورة', reference: 'TR-2025-010', user: 'أحمد محمود', notes: 'تحويل بين الفروع' },
  { id: '13', number: 'MOV-013', date: '2025-06-16 08:00', type: 'in', product: 'ذرة صفراء', qty: 200, unit: 'طن', warehouse: 'طنطا', reference: 'PO-2025-086', user: 'محمد رضا', notes: 'استلام دفعة كبيرة' },
  { id: '14', number: 'MOV-014', date: '2025-06-16 13:00', type: 'adjust', product: 'حجر جيري', qty: 10, unit: 'كجم', warehouse: 'القاهرة', reference: 'ADJ-2025-002', user: 'محمد علي', notes: 'تسوية إيجابية' },
  { id: '15', number: 'MOV-015', date: '2025-06-15 10:00', type: 'out', product: 'أعلاف دواجن ناهي', qty: 25, unit: 'شيكارة', warehouse: 'القاهرة', reference: 'INV-003', user: 'خالد حسن', notes: 'صادر لمزرعة الفيوم' },
];

const TYPE_MAP: Record<string, { label: string; color: string; bg: string; icon: any }> = {
  in: { label: 'وارد', color: 'text-green-700', bg: 'bg-green-100 dark:bg-green-900/30', icon: TrendingUp },
  out: { label: 'صادر', color: 'text-red-700', bg: 'bg-red-100 dark:bg-red-900/30', icon: TrendingDown },
  transfer: { label: 'تحويل', color: 'text-blue-700', bg: 'bg-blue-100 dark:bg-blue-900/30', icon: ArrowRightLeft },
  adjust: { label: 'تعديل', color: 'text-amber-700', bg: 'bg-amber-100 dark:bg-amber-900/30', icon: TrendingUp },
};

/* ──────────────────────────── component ──────────────────────────── */

export default function MovementsPage() {
  const [movements, setMovements] = useState<Movement[]>(MOVEMENTS);
  const [activeTab, setActiveTab] = useState('all');
  const [search, setSearch] = useState('');
  const [warehouseFilter, setWarehouseFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [page, setPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  const pageSize = 10;

  const filtered = useMemo(() => {
    return movements.filter((m) => {
      const q = search.trim();
      const matchSearch = q === '' || m.number.includes(q) || m.product.includes(q) || m.reference.includes(q) || m.user.includes(q);
      const matchType = activeTab === 'all' || m.type === activeTab;
      const matchWarehouse = warehouseFilter === 'all' || m.warehouse === warehouseFilter;
      const matchDateFrom = !dateFrom || m.date >= dateFrom;
      const matchDateTo = !dateTo || m.date <= dateTo + ' 23:59';
      return matchSearch && matchType && matchWarehouse && matchDateFrom && matchDateTo;
    });
  }, [movements, search, activeTab, warehouseFilter, dateFrom, dateTo]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const todayCount = movements.filter((m) => m.date.startsWith('2025-06-20')).length;
  const inCount = movements.filter((m) => m.type === 'in').length;
  const outCount = movements.filter((m) => m.type === 'out').length;
  const transferCount = movements.filter((m) => m.type === 'transfer').length;

  const resetFilters = () => {
    setSearch('');
    setWarehouseFilter('all');
    setDateFrom('');
    setDateTo('');
    setPage(1);
  };

  const deleteMovement = (id: string) => {
    setMovements((prev) => prev.filter((m) => m.id !== id));
  };

  const handleCreate = (newM: Movement) => {
    setMovements((prev) => [newM, ...prev]);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="حركات المخزون"
        subtitle="تتبع حركات المخزون الوارد والصادر والتحويلات"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'إدارة المخازن', path: '/inventory' }, { label: 'حركات المخزون' }]}
      >
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-[#0a4a30] hover:bg-[#0d6b43] text-white gap-2">
              <Plus size={16} />
              حركة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="text-right text-lg">تسجيل حركة جديدة</DialogTitle>
            </DialogHeader>
            <MovementForm onSave={handleCreate} />
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="حركات اليوم" value={todayCount.toString()} icon={ArrowLeftRight} iconBg="bg-blue-100" iconColor="text-blue-600" change={5} delay={0} />
        <KPICard title="وارد" value={inCount.toString()} icon={TrendingUp} iconBg="bg-green-100" iconColor="text-green-600" change={8} delay={0.1} />
        <KPICard title="صادر" value={outCount.toString()} icon={TrendingDown} iconBg="bg-red-100" iconColor="text-red-600" change={-2} delay={0.2} />
        <KPICard title="تحويلات" value={transferCount.toString()} icon={ArrowRightLeft} iconBg="bg-purple-100" iconColor="text-purple-600" delay={0.3} />
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => { setActiveTab(v); setPage(1); }}>
        <TabsList className="bg-gray-100 p-1 gap-1">
          <TabsTrigger value="all" className="text-xs data-[state=active]:bg-white data-[state=active]:text-[#0a4a30] data-[state=active]:shadow">الكل</TabsTrigger>
          <TabsTrigger value="in" className="text-xs data-[state=active]:bg-green-600 data-[state=active]:text-white">وارد</TabsTrigger>
          <TabsTrigger value="out" className="text-xs data-[state=active]:bg-red-600 data-[state=active]:text-white">صادر</TabsTrigger>
          <TabsTrigger value="transfer" className="text-xs data-[state=active]:bg-blue-600 data-[state=active]:text-white">تحويلات</TabsTrigger>
          <TabsTrigger value="adjust" className="text-xs data-[state=active]:bg-amber-600 data-[state=active]:text-white">تسويات</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Filters */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <Input
                placeholder="بحث برقم الحركة أو المنتج أو المرجع..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                className="pr-9 text-right"
              />
            </div>
            <Select value={warehouseFilter} onValueChange={setWarehouseFilter}>
              <SelectTrigger className="w-36 text-right text-xs"><SelectValue placeholder="المستودع" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل المستودعات</SelectItem>
                {WAREHOUSES.map((w) => <SelectItem key={w} value={w}>{w}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="w-36">
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="text-xs text-right" />
            </div>
            <span className="text-xs text-gray-400">-</span>
            <div className="w-36">
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="text-xs text-right" />
            </div>
            {(warehouseFilter !== 'all' || dateFrom || dateTo || search) && (
              <Button variant="ghost" size="sm" className="text-red-500 text-xs" onClick={resetFilters}>
                <X size={12} />
                إلغاء
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border border-gray-200 dark:border-gray-700 overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                  <TableHead className="text-right font-semibold text-xs">رقم الحركة</TableHead>
                  <TableHead className="text-right font-semibold text-xs">التاريخ</TableHead>
                  <TableHead className="text-right font-semibold text-xs">النوع</TableHead>
                  <TableHead className="text-right font-semibold text-xs">المنتج</TableHead>
                  <TableHead className="text-right font-semibold text-xs">الكمية</TableHead>
                  <TableHead className="text-right font-semibold text-xs">المستودع</TableHead>
                  <TableHead className="text-right font-semibold text-xs">المرجع</TableHead>
                  <TableHead className="text-right font-semibold text-xs">المستخدم</TableHead>
                  <TableHead className="text-center font-semibold text-xs">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.map((m) => {
                  const tm = TYPE_MAP[m.type];
                  const IconComp = tm.icon;
                  return (
                    <TableRow key={m.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors">
                      <TableCell className="font-mono text-xs font-medium">{m.number}</TableCell>
                      <TableCell className="text-xs text-gray-500 flex items-center gap-1">
                        <Calendar size={10} />
                        {m.date}
                      </TableCell>
                      <TableCell>
                        <Badge className={cn('text-[10px] border-0 gap-1', tm.bg, tm.color)}>
                          <IconComp size={10} />
                          {tm.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{m.product}</TableCell>
                      <TableCell className={cn('text-sm font-semibold tabular-nums', m.qty < 0 ? 'text-red-600' : 'text-green-600')}>
                        {m.qty > 0 ? '+' : ''}{m.qty.toLocaleString('ar-EG')} {m.unit}
                      </TableCell>
                      <TableCell className="text-xs">{m.warehouse}</TableCell>
                      <TableCell className="text-xs font-mono text-gray-500">{m.reference}</TableCell>
                      <TableCell className="text-xs flex items-center gap-1">
                        <User size={10} />
                        {m.user}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-blue-600">
                            <Eye size={14} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => deleteMovement(m.id)}>
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {paged.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-12 text-gray-400">
                      لا توجد حركات مطابقة
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {/* Pagination */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 dark:border-gray-700">
            <span className="text-xs text-gray-500">
              عرض {filtered.length > 0 ? (page - 1) * pageSize + 1 : 0} - {Math.min(page * pageSize, filtered.length)} من {filtered.length}
            </span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(1)}>الأولى</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(page - 1)}>السابق</Button>
              <span className="text-xs px-2">{page} / {totalPages}</span>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(page + 1)}>التالي</Button>
              <Button variant="outline" size="sm" className="h-7 text-xs" disabled={page === totalPages} onClick={() => setPage(totalPages)}>الأخيرة</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

/* ──────────────────────────── Movement Form ──────────────────────────── */

function MovementForm({ onSave }: { onSave: (m: Movement) => void }) {
  const [type, setType] = useState<'in' | 'out' | 'transfer' | 'adjust'>('in');
  const [product, setProduct] = useState('');
  const [qty, setQty] = useState(1);
  const [unit, setUnit] = useState('طن');
  const [warehouse, setWarehouse] = useState('');
  const [fromWarehouse, setFromWarehouse] = useState('');
  const [toWarehouse, setToWarehouse] = useState('');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = () => {
    onSave({
      id: Date.now().toString(),
      number: `MOV-${String(MOVEMENTS.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString().slice(0, 16).replace('T', ' '),
      type,
      product: product || 'منتج جديد',
      qty: type === 'out' || type === 'adjust' ? -Math.abs(qty) : Math.abs(qty),
      unit,
      warehouse: warehouse || 'القاهرة',
      fromWarehouse: type === 'transfer' ? fromWarehouse || warehouse : undefined,
      toWarehouse: type === 'transfer' ? toWarehouse : undefined,
      reference: reference || `REF-${Date.now().toString().slice(-6)}`,
      user: 'المستخدم الحالي',
      notes,
    });
  };

  const products = ['أعلاف دواجن بادئ', 'أعلاف دواجن نامي', 'أعلاف دواجن ناهي', 'ذرة صفراء', 'كسب فول صويا', 'ردة قمح', 'نخالة قمح', 'مسحوق عظام'];

  return (
    <div className="space-y-3" dir="rtl">
      <div>
        <Label className="text-xs">نوع الحركة</Label>
        <Select value={type} onValueChange={(v) => setType(v as any)}>
          <SelectTrigger className="text-right"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="in">وارد</SelectItem>
            <SelectItem value="out">صادر</SelectItem>
            <SelectItem value="transfer">تحويل</SelectItem>
            <SelectItem value="adjust">تسوية</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">المنتج</Label>
          <Select value={product} onValueChange={setProduct}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر المنتج" /></SelectTrigger>
            <SelectContent>{products.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">المستودع</Label>
          <Select value={warehouse} onValueChange={setWarehouse}>
            <SelectTrigger className="text-right"><SelectValue placeholder="اختر المستودع" /></SelectTrigger>
            <SelectContent>{WAREHOUSES.map((w) => <SelectItem key={w} value={w}>{w}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>
      {type === 'transfer' && (
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-xs">من مستودع</Label>
            <Select value={fromWarehouse} onValueChange={setFromWarehouse}>
              <SelectTrigger className="text-right"><SelectValue placeholder="اختر" /></SelectTrigger>
              <SelectContent>{WAREHOUSES.map((w) => <SelectItem key={w} value={w}>{w}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">إلى مستودع</Label>
            <Select value={toWarehouse} onValueChange={setToWarehouse}>
              <SelectTrigger className="text-right"><SelectValue placeholder="اختر" /></SelectTrigger>
              <SelectContent>{WAREHOUSES.map((w) => <SelectItem key={w} value={w}>{w}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      )}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">الكمية</Label>
          <Input type="number" value={qty} onChange={(e) => setQty(parseFloat(e.target.value) || 0)} className="text-center" />
        </div>
        <div>
          <Label className="text-xs">الوحدة</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger className="text-right"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="طن">طن</SelectItem>
              <SelectItem value="شيكارة">شيكارة</SelectItem>
              <SelectItem value="كجم">كجم</SelectItem>
              <SelectItem value="علبة">علبة</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-xs">المرجع</Label>
          <Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="رقم المرجع" className="text-right" />
        </div>
        <div>
          <Label className="text-xs">ملاحظات</Label>
          <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ملاحظات" className="text-right" />
        </div>
      </div>
      <Button onClick={handleSubmit} className="w-full bg-[#0a4a30] hover:bg-[#0d6b43] text-white">
        حفظ الحركة
      </Button>
    </div>
  );
}
