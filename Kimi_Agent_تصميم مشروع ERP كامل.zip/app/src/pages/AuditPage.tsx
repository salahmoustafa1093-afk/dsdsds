import PageHeader from '@/components/PageHeader';
import { ClipboardCheck } from 'lucide-react';

export default function AuditPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="الجرد"
        subtitle="جرد المخزون والتسويات"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'إدارة المخازن', path: '/inventory' },
          { label: 'الجرد' },
        ]}
      />
      <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-12 text-center">
        <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
          <ClipboardCheck size={32} className="text-green-600 dark:text-green-400" />
        </div>
        <h2 className="text-lg font-semibold text-textPrimary dark:text-darkText mb-2">
          صفحة الجرد
        </h2>
        <p className="text-sm text-textSecondary dark:text-darkTextSec">
          سيتم إضافة المحتوى قريباً
        </p>
      </div>
    </div>
  );
}
