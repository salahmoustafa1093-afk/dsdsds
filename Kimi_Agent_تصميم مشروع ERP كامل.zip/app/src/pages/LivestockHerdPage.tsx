// @ts-nocheck
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Beef, Plus, Search, Filter, X, Eye, Syringe, Wheat, HeartPulse,
  TrendingUp, TrendingDown, Minus, ChevronLeft, ChevronRight,
  ArrowUpDown, ArrowUp, ArrowDown, PackageX
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

// ─── Types ──────────────────────────────────────────────
interface Animal {
  id: string;
  type: string;
  breed: string;
  gender: string;
  birthDate: string;
  age: string;
  weight: number;
  pen: string;
  status: string;
  purchasePrice: number;
  source: string;
  weightHistory: { date: string; weight: number }[];
  feedRecords: { date: string; feedType: string; quantity: number }[];
  vaccinations: { date: string; vaccine: string; nextDue: string; vet: string }[];
  medicalHistory: { date: string; condition: string; treatment: string }[];
}

// ─── Mock Data ──────────────────────────────────────────
const herdData: Animal[] = [
  { id: 'A-1001', type: 'عجول', breed: 'بلدي', gender: 'ذكر', birthDate: '2024-03-15', age: '10 أشهر', weight: 280, pen: 'حظيرة 1', status: 'نشط', purchasePrice: 4500, source: 'سوق المحلة', weightHistory: [{ date: '2024-09', weight: 150 }, { date: '2024-10', weight: 180 }, { date: '2024-11', weight: 210 }, { date: '2024-12', weight: 250 }, { date: '2025-01', weight: 280 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف مركز', quantity: 4.5 }, { date: '2025-01-11', feedType: 'علف مركز', quantity: 4.2 }], vaccinations: [{ date: '2024-06-15', vaccine: 'حماية مجتمعة', nextDue: '2025-06-15', vet: 'د. أحمد' }], medicalHistory: [{ date: '2024-08-10', condition: 'حمى خفيفة', treatment: 'مضاد حيوي' }] },
  { id: 'A-1002', type: 'عجول', breed: 'مستورد', gender: 'أنثى', birthDate: '2024-05-20', age: '8 أشهر', weight: 240, pen: 'حظيرة 1', status: 'نشط', purchasePrice: 6200, source: 'مزرعة النور', weightHistory: [{ date: '2024-09', weight: 130 }, { date: '2024-10', weight: 160 }, { date: '2024-11', weight: 195 }, { date: '2024-12', weight: 220 }, { date: '2025-01', weight: 240 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف نامي', quantity: 3.8 }, { date: '2025-01-11', feedType: 'علف نامي', quantity: 4.0 }], vaccinations: [{ date: '2024-08-20', vaccine: 'حماية مجتمعة', nextDue: '2025-08-20', vet: 'د. أحمد' }], medicalHistory: [] },
  { id: 'A-1003', type: 'أغنام', breed: 'رحماني', gender: 'ذكر', birthDate: '2024-07-10', age: '6 أشهر', weight: 45, pen: 'حظيرة 2', status: 'نشط', purchasePrice: 1800, source: 'سوق بركة السبع', weightHistory: [{ date: '2024-09', weight: 22 }, { date: '2024-10', weight: 28 }, { date: '2024-11', weight: 34 }, { date: '2024-12', weight: 40 }, { date: '2025-01', weight: 45 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف أغنام', quantity: 1.5 }, { date: '2025-01-11', feedType: 'علف أغنام', quantity: 1.6 }], vaccinations: [{ date: '2024-10-10', vaccine: 'جلعجل', nextDue: '2025-01-10', vet: 'د. سمير' }], medicalHistory: [] },
  { id: 'A-1004', type: 'أغنام', breed: 'بلدي', gender: 'أنثى', birthDate: '2024-06-01', age: '7 أشهر', weight: 38, pen: 'حظيرة 2', status: 'للبيع', purchasePrice: 1200, source: 'سوق المنصورة', weightHistory: [{ date: '2024-09', weight: 20 }, { date: '2024-10', weight: 25 }, { date: '2024-11', weight: 30 }, { date: '2024-12', weight: 35 }, { date: '2025-01', weight: 38 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف أغنام', quantity: 1.2 }], vaccinations: [{ date: '2024-09-01', vaccine: 'حماية مجتمعة', nextDue: '2025-03-01', vet: 'د. سمير' }], medicalHistory: [] },
  { id: 'A-1005', type: 'جاموس', breed: 'بلدي', gender: 'ذكر', birthDate: '2024-01-20', age: '12 شهر', weight: 320, pen: 'حظيرة 3', status: 'نشط', purchasePrice: 5500, source: 'مزرعة الدلتا', weightHistory: [{ date: '2024-09', weight: 220 }, { date: '2024-10', weight: 250 }, { date: '2024-11', weight: 275 }, { date: '2024-12', weight: 300 }, { date: '2025-01', weight: 320 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف جاموس', quantity: 5.5 }, { date: '2025-01-11', feedType: 'علف جاموس', quantity: 5.2 }], vaccinations: [{ date: '2024-04-20', vaccine: 'حماية مجتمعة', nextDue: '2025-04-20', vet: 'د. أحمد' }], medicalHistory: [{ date: '2024-07-15', condition: 'إسهال', treatment: 'محلول مغذي' }] },
  { id: 'A-1006', type: 'جاموس', breed: 'مستورد', gender: 'أنثى', birthDate: '2024-08-05', age: '5 أشهر', weight: 180, pen: 'حظيرة 3', status: 'نشط', purchasePrice: 8000, source: 'مستورد من إيطاليا', weightHistory: [{ date: '2024-09', weight: 100 }, { date: '2024-10', weight: 125 }, { date: '2024-11', weight: 150 }, { date: '2024-12', weight: 165 }, { date: '2025-01', weight: 180 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف نامي', quantity: 3.5 }], vaccinations: [{ date: '2024-11-05', vaccine: 'جلعجل', nextDue: '2025-02-05', vet: 'د. سمير' }], medicalHistory: [] },
  { id: 'A-1007', type: 'عجول', breed: 'رحماني', gender: 'ذكر', birthDate: '2024-04-12', age: '9 أشهر', weight: 260, pen: 'حظيرة 1', status: 'مباع', purchasePrice: 5000, source: 'سوق طنطا', weightHistory: [{ date: '2024-09', weight: 140 }, { date: '2024-10', weight: 170 }, { date: '2024-11', weight: 200 }, { date: '2024-12', weight: 235 }, { date: '2025-01', weight: 260 }], feedRecords: [{ date: '2025-01-01', feedType: 'علف مركز', quantity: 4.0 }], vaccinations: [{ date: '2024-07-12', vaccine: 'حماية مجتمعة', nextDue: '2025-01-12', vet: 'د. أحمد' }], medicalHistory: [] },
  { id: 'A-1008', type: 'أغنام', breed: 'مستورد', gender: 'أنثى', birthDate: '2024-09-01', age: '4 أشهر', weight: 28, pen: 'حظيرة 2', status: 'نشط', purchasePrice: 3500, source: 'مستورد من أستراليا', weightHistory: [{ date: '2024-10', weight: 15 }, { date: '2024-11', weight: 20 }, { date: '2024-12', weight: 25 }, { date: '2025-01', weight: 28 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف أغنام', quantity: 1.0 }], vaccinations: [{ date: '2024-12-01', vaccine: 'حماية مجتمعة', nextDue: '2025-03-01', vet: 'د. سمير' }], medicalHistory: [] },
  { id: 'A-1009', type: 'عجول', breed: 'بلدي', gender: 'أنثى', birthDate: '2024-02-28', age: '11 شهر', weight: 300, pen: 'حظيرة 1', status: 'نافق', purchasePrice: 4200, source: 'سوق القاهرة', weightHistory: [{ date: '2024-09', weight: 200 }, { date: '2024-10', weight: 230 }, { date: '2024-11', weight: 260 }, { date: '2024-12', weight: 290 }, { date: '2025-01', weight: 300 }], feedRecords: [{ date: '2025-01-05', feedType: 'علف مركز', quantity: 4.5 }], vaccinations: [{ date: '2024-05-28', vaccine: 'حماية مجتمعة', nextDue: '2025-02-28', vet: 'د. أحمد' }], medicalHistory: [{ date: '2025-01-08', condition: 'التهاب رئوي', treatment: '—' }] },
  { id: 'A-1010', type: 'جاموس', breed: 'بلدي', gender: 'ذكر', birthDate: '2024-06-18', age: '7 أشهر', weight: 210, pen: 'حظيرة 3', status: 'للبيع', purchasePrice: 4800, source: 'سوق دمنهور', weightHistory: [{ date: '2024-09', weight: 120 }, { date: '2024-10', weight: 145 }, { date: '2024-11', weight: 170 }, { date: '2024-12', weight: 195 }, { date: '2025-01', weight: 210 }], feedRecords: [{ date: '2025-01-10', feedType: 'علف جاموس', quantity: 4.0 }], vaccinations: [{ date: '2024-09-18', vaccine: 'جلعجل', nextDue: '2025-03-18', vet: 'د. سمير' }], medicalHistory: [] },
];

const typeOptions = ['الكل', 'عجول', 'أغنام', 'جاموس'];
const breedOptions = ['الكل', 'بلدي', 'مستورد', 'رحماني'];
const genderOptions = ['الكل', 'ذكر', 'أنثى'];
const statusOptions = ['الكل', 'نشط', 'للبيع', 'مباع', 'نافق'];
const statusColors: Record<string, string> = {
  'نشط': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'للبيع': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'مباع': 'bg-gold-100 text-gold-700 dark:bg-gold-900/40 dark:text-gold-400',
  'نافق': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

// ─── Component ──────────────────────────────────────────
export default function LivestockHerdPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('الكل');
  const [filterBreed, setFilterBreed] = useState('الكل');
  const [filterGender, setFilterGender] = useState('الكل');
  const [filterStatus, setFilterStatus] = useState('الكل');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;

  // KPI calculations
  const totalAnimals = herdData.length;
  const calvesCount = herdData.filter(a => a.type === 'عجول').length;
  const sheepCount = herdData.filter(a => a.type === 'أغنام').length;
  const buffaloCount = herdData.filter(a => a.type === 'جاموس').length;
  const growthRate = 12.5;

  const filteredData = useMemo(() => {
    let result = [...herdData];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a =>
        a.id.toLowerCase().includes(q) ||
        a.type.includes(q) || a.breed.includes(q) ||
        a.pen.includes(q) || a.status.includes(q)
      );
    }
    if (filterType !== 'الكل') result = result.filter(a => a.type === filterType);
    if (filterBreed !== 'الكل') result = result.filter(a => a.breed === filterBreed);
    if (filterGender !== 'الكل') result = result.filter(a => a.gender === filterGender);
    if (filterStatus !== 'الكل') result = result.filter(a => a.status === filterStatus);
    return result;
  }, [searchQuery, filterType, filterBreed, filterGender, filterStatus]);

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const paginatedData = filteredData.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const columns = [
    { key: 'id', header: 'رقم الحيوان', sortable: true },
    { key: 'type', header: 'النوع', sortable: true },
    { key: 'breed', header: 'السلالة', sortable: true },
    { key: 'gender', header: 'الجنس', sortable: true },
    { key: 'age', header: 'العمر', sortable: true },
    { key: 'weight', header: 'الوزن (كجم)', sortable: true, render: (a: Animal) => <span className="font-semibold">{a.weight}</span> },
    { key: 'pen', header: 'الحظيرة', sortable: true },
    { key: 'status', header: 'الحالة', render: (a: Animal) => (
      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[a.status] || 'bg-gray-100 text-gray-600'}`}>{a.status}</span>
    )},
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader
        title="سجل القطيع"
        subtitle="إدارة وتسجيل جميع الحيوانات في المزرعة"
        breadcrumb={[
          { label: 'الرئيسية', path: '/' },
          { label: 'المواشي', path: '/livestock' },
          { label: 'سجل القطيع' },
        ]}
      >
        <button
          onClick={() => setShowAddForm(true)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors shadow-sm"
        >
          <Plus size={16} />
          إضافة حيوان
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="إجمالي القطيع" value={String(totalAnimals)} icon={Beef} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} change={growthRate} />
        <KPICard title="عجول" value={String(calvesCount)} icon={Beef} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-700 dark:text-blue-400" delay={0.1} />
        <KPICard title="أغنام" value={String(sheepCount)} icon={Beef} iconBg="bg-gold-100 dark:bg-gold-900/30" iconColor="text-gold-600 dark:text-gold-400" delay={0.2} />
        <KPICard title="جاموس" value={String(buffaloCount)} icon={Beef} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-700 dark:text-purple-400" delay={0.3} />
        <KPICard title="نسبة النمو" value={`%${growthRate}`} icon={TrendingUp} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0.4} change={2.3} />
      </div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-4"
      >
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 text-textSecondary text-sm"><Filter size={14} /> تصفية:</div>
          <select value={filterType} onChange={e => setFilterType(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm text-textPrimary dark:text-darkText focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
            {typeOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'النوع' : o}</option>)}
          </select>
          <select value={filterBreed} onChange={e => setFilterBreed(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm text-textPrimary dark:text-darkText focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
            {breedOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'السلالة' : o}</option>)}
          </select>
          <select value={filterGender} onChange={e => setFilterGender(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm text-textPrimary dark:text-darkText focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
            {genderOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'الجنس' : o}</option>)}
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm text-textPrimary dark:text-darkText focus:ring-2 focus:ring-green-500/30 focus:border-green-500">
            {statusOptions.map(o => <option key={o} value={o}>{o === 'الكل' ? 'الحالة' : o}</option>)}
          </select>
          <div className="relative flex-1 min-w-[200px] max-w-xs mr-auto">
            <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
            <input
              type="text" placeholder="بحث..."
              value={searchQuery} onChange={e => { setSearchQuery(e.target.value); setCurrentPage(1); }}
              className="w-full h-9 pr-9 pl-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm text-textPrimary dark:text-darkText placeholder:text-textMuted focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
            />
          </div>
        </div>
      </motion.div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface dark:bg-darkBg/60 border-b border-uiBorder dark:border-darkBorder">
                {columns.map(col => (
                  <th key={col.key} className="px-4 py-3 text-right text-xs font-semibold text-textSecondary dark:text-darkTextSec uppercase tracking-wider">
                    {col.header}
                  </th>
                ))}
                <th className="px-4 py-3 text-center text-xs font-semibold text-textSecondary dark:text-darkTextSec">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length === 0 ? (
                <tr>
                  <td colSpan={columns.length + 1} className="px-4 py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-16 h-16 rounded-full bg-surface dark:bg-darkCard flex items-center justify-center"><PackageX size={32} className="text-textMuted" /></div>
                      <p className="text-textSecondary dark:text-darkTextSec text-sm">لا توجد بيانات</p>
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedData.map((row, index) => (
                  <motion.tr
                    key={row.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-[#f1f5f9] dark:hover:bg-darkCard/50 transition-colors"
                  >
                    {columns.map(col => (
                      <td key={col.key} className="px-4 py-3 text-sm text-textPrimary dark:text-darkText">
                        {col.render ? col.render(row) : String((row as Record<string, unknown>)[col.key] ?? '-')}
                      </td>
                    ))}
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => setSelectedAnimal(row)} className="w-8 h-8 rounded-lg flex items-center justify-center text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors" title="عرض التفاصيل">
                          <Eye size={16} />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {filteredData.length > pageSize && (
          <div className="px-5 py-3 border-t border-uiBorder dark:border-darkBorder flex items-center justify-between">
            <p className="text-xs text-textMuted">عرض {(currentPage - 1) * pageSize + 1} إلى {Math.min(currentPage * pageSize, filteredData.length)} من {filteredData.length} عنصر</p>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1} className="w-8 h-8 rounded-lg flex items-center justify-center disabled:opacity-30"><ChevronRight size={16} /></button>
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="w-8 h-8 rounded-lg flex items-center justify-center disabled:opacity-30"><ArrowUp size={16} /></button>
              <span className="text-xs px-2">{currentPage} / {totalPages}</span>
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="w-8 h-8 rounded-lg flex items-center justify-center disabled:opacity-30"><ArrowDown size={16} /></button>
              <button onClick={() => setCurrentPage(totalPages)} disabled={currentPage === totalPages} className="w-8 h-8 rounded-lg flex items-center justify-center disabled:opacity-30"><ChevronLeft size={16} /></button>
            </div>
          </div>
        )}
      </motion.div>

      {/* Add Animal Form Modal */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
            onClick={() => setShowAddForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-lg max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">إضافة حيوان جديد</h3>
                <button onClick={() => setShowAddForm(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">النوع</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>عجول</option><option>أغنام</option><option>جاموس</option></select></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">السلالة</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>بلدي</option><option>مستورد</option><option>رحماني</option></select></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الجنس</label><select className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm"><option>ذكر</option><option>أنثى</option></select></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">تاريخ الميلاد</label><input type="date" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الوزن (كجم)</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">الحظيرة</label><input type="text" placeholder="رقم الحظيرة" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">سعر الشراء</label><input type="number" placeholder="0" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                  <div><label className="block text-xs font-medium text-textSecondary mb-1">المصدر</label><input type="text" placeholder="مصدر الشراء" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" /></div>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-sm text-textSecondary hover:bg-surface transition-colors">إلغاء</button>
                  <button onClick={() => setShowAddForm(false)} className="px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-medium hover:bg-green-800 transition-colors">حفظ</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Animal Detail Modal */}
      <AnimatePresence>
        {selectedAnimal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50"
            onClick={() => setSelectedAnimal(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              onClick={e => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-3xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-uiBorder dark:border-darkBorder">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center"><Beef size={20} className="text-green-700" /></div>
                  <div>
                    <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">{selectedAnimal.id} — {selectedAnimal.type}</h3>
                    <p className="text-xs text-textMuted">{selectedAnimal.breed} · {selectedAnimal.gender} · {selectedAnimal.age}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusColors[selectedAnimal.status]}`}>{selectedAnimal.status}</span>
                  <button onClick={() => setSelectedAnimal(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:text-textPrimary"><X size={18} /></button>
                </div>
              </div>

              <div className="p-5 space-y-6">
                {/* Profile Info */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><p className="text-xs text-textMuted">الوزن</p><p className="text-lg font-bold text-textPrimary dark:text-darkText">{selectedAnimal.weight} كجم</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><p className="text-xs text-textMuted">الحظيرة</p><p className="text-lg font-bold text-textPrimary dark:text-darkText">{selectedAnimal.pen}</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><p className="text-xs text-textMuted">سعر الشراء</p><p className="text-lg font-bold text-green-700">{selectedAnimal.purchasePrice.toLocaleString()} ج.م</p></div>
                  <div className="bg-surface dark:bg-darkCard rounded-lg p-3 text-center"><p className="text-xs text-textMuted">المصدر</p><p className="text-sm font-semibold text-textPrimary dark:text-darkText">{selectedAnimal.source}</p></div>
                </div>

                {/* Weight History Chart */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2"><TrendingUp size={16} className="text-green-600" /> تاريخ الوزن</h4>
                  <div className="h-48 bg-surface dark:bg-darkCard rounded-lg p-3">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={selectedAnimal.weightHistory}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                        <YAxis tick={{ fontSize: 11 }} />
                        <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                        <Line type="monotone" dataKey="weight" stroke="#14a86a" strokeWidth={2} dot={{ fill: '#14a86a', r: 3 }} name="الوزن (كجم)" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Feed Records */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2"><Wheat size={16} className="text-gold-500" /> سجلات التغذية</h4>
                  <div className="bg-surface dark:bg-darkCard rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-uiBorder/30"><tr><th className="px-3 py-2 text-right text-xs">التاريخ</th><th className="px-3 py-2 text-right text-xs">نوع العلف</th><th className="px-3 py-2 text-right text-xs">الكمية (كجم)</th></tr></thead>
                      <tbody>
                        {selectedAnimal.feedRecords.map((f, i) => (
                          <tr key={i} className="border-b border-uiBorder/30"><td className="px-3 py-2">{f.date}</td><td className="px-3 py-2">{f.feedType}</td><td className="px-3 py-2 font-semibold">{f.quantity}</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Vaccination Log */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2"><Syringe size={16} className="text-blue-500" /> سجل التحصينات</h4>
                  <div className="bg-surface dark:bg-darkCard rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-uiBorder/30"><tr><th className="px-3 py-2 text-right text-xs">التاريخ</th><th className="px-3 py-2 text-right text-xs">التحصينة</th><th className="px-3 py-2 text-right text-xs">التالي</th><th className="px-3 py-2 text-right text-xs">البيطري</th></tr></thead>
                      <tbody>
                        {selectedAnimal.vaccinations.map((v, i) => (
                          <tr key={i} className="border-b border-uiBorder/30"><td className="px-3 py-2">{v.date}</td><td className="px-3 py-2">{v.vaccine}</td><td className="px-3 py-2">{v.nextDue}</td><td className="px-3 py-2">{v.vet}</td></tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Medical History */}
                <div>
                  <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3 flex items-center gap-2"><HeartPulse size={16} className="text-red-500" /> التاريخ المرضي</h4>
                  <div className="bg-surface dark:bg-darkCard rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-uiBorder/30"><tr><th className="px-3 py-2 text-right text-xs">التاريخ</th><th className="px-3 py-2 text-right text-xs">الحالة</th><th className="px-3 py-2 text-right text-xs">العلاج</th></tr></thead>
                      <tbody>
                        {selectedAnimal.medicalHistory.length === 0 ? (
                          <tr><td colSpan={3} className="px-3 py-4 text-center text-textMuted text-xs">لا يوجد تاريخ مرضي</td></tr>
                        ) : (
                          selectedAnimal.medicalHistory.map((m, i) => (
                            <tr key={i} className="border-b border-uiBorder/30"><td className="px-3 py-2">{m.date}</td><td className="px-3 py-2">{m.condition}</td><td className="px-3 py-2">{m.treatment}</td></tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
