// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Factory, Plus, Search, X, CheckCircle2, Clock, AlertTriangle,
  PauseCircle, PlayCircle, Wrench, Zap, TrendingUp, Package,
  CalendarDays, BarChart3, Pencil, Trash2, Eye, Settings2, ChevronDown,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';
import DataTable from '@/components/DataTable';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

/* ─── mock data ─── */
const productionLines = [
  { id: 1, name: 'خط الأعلاف 1', status: 'active', capacity: 80, efficiency: 92, currentBatch: 'علاف دواجن - د 12-24', output: 640, target: 700, manager: 'أحمد خالد', uptime: '18h 30m' },
  { id: 2, name: 'خط الأعلاف 2', status: 'idle', capacity: 60, efficiency: 0, currentBatch: '-', output: 0, target: 500, manager: 'محمد علي', uptime: '0h' },
  { id: 3, name: 'خط البقوليات 1', status: 'maintenance', capacity: 45, efficiency: 0, currentBatch: '-', output: 0, target: 400, manager: 'سامي حسن', uptime: '2h 15m' },
];

const productionOrders = [
  { id: 1, orderNo: 'PO-2024-001', product: 'علاف دواجن ناشئة', quantity: 120, line: 'خط الأعلاف 1', priority: 'عالية', status: 'قيد التشغيل', plannedDate: '2024-12-20', completion: 78 },
  { id: 2, orderNo: 'PO-2024-002', product: 'علاف أبقار حلاب', quantity: 85, line: 'خط الأعلاف 1', priority: 'متوسطة', status: 'قيد التحضير', plannedDate: '2024-12-21', completion: 15 },
  { id: 3, orderNo: 'PO-2024-003', product: 'علاف أغنام ناشئة', quantity: 60, line: 'خط الأعلاف 2', priority: 'عالية', status: 'مجدولة', plannedDate: '2024-12-22', completion: 0 },
  { id: 4, orderNo: 'PO-2024-004', product: 'علاف دواجن نامية', quantity: 200, line: 'خط الأعلاف 1', priority: 'منخفضة', status: 'مكتملة', plannedDate: '2024-12-18', completion: 100 },
  { id: 5, orderNo: 'PO-2024-005', product: 'علاف جاموس', quantity: 95, line: 'خط الأعلاف 2', priority: 'متوسطة', status: 'مجدولة', plannedDate: '2024-12-23', completion: 0 },
  { id: 6, orderNo: 'PO-2024-006', product: 'علاف دواجن بياضة', quantity: 150, line: 'خط الأعلاف 1', priority: 'عالية', status: 'قيد التشغيل', plannedDate: '2024-12-19', completion: 45 },
  { id: 7, orderNo: 'PO-2024-007', product: 'علاف عجول تسمين', quantity: 110, line: 'خط الأعلاف 1', priority: 'متوسطة', status: 'قيد التحضير', plannedDate: '2024-12-24', completion: 5 },
  { id: 8, orderNo: 'PO-2024-008', product: 'علاف دواجن ناشئة', quantity: 75, line: 'خط الأعلاف 2', priority: 'منخفضة', status: 'ملغاة', plannedDate: '2024-12-20', completion: 0 },
  { id: 9, orderNo: 'PO-2024-009', product: 'علاف أبقار تسمين', quantity: 130, line: 'خط الأعلاف 1', priority: 'عالية', status: 'قيد التشغيل', plannedDate: '2024-12-19', completion: 60 },
  { id: 10, orderNo: 'PO-2024-010', product: 'علاف أغنام حلاب', quantity: 50, line: 'خط الأعلاف 2', priority: 'متوسطة', status: 'مجدولة', plannedDate: '2024-12-25', completion: 0 },
];

const dailyEntries = [
  { id: 1, date: '2024-12-19', line: 'خط الأعلاف 1', product: 'علاف دواجن ناشئة', planned: 700, actual: 640, waste: 12, downtime: '45 دقيقة - صيانة بسيطة', operator: 'أحمد خالد' },
  { id: 2, date: '2024-12-19', line: 'خط الأعلاف 1', product: 'علاف دواجن بياضة', planned: 500, actual: 460, waste: 8, downtime: '30 دقيقة - تبديل قالب', operator: 'محمد علي' },
  { id: 3, date: '2024-12-18', line: 'خط الأعلاف 1', product: 'علاف دواجن نامية', planned: 600, actual: 580, waste: 15, downtime: '20 دقيقة - فحص جودة', operator: 'أحمد خالد' },
];

const efficiencyTrend = [
  { day: 'السبت', line1: 88, line2: 82, line3: 0 },
  { day: 'الأحد', line1: 91, line2: 85, line3: 0 },
  { day: 'الإثنين', line1: 89, line2: 80, line3: 0 },
  { day: 'الثلاثاء', line1: 93, line2: 78, line3: 0 },
  { day: 'الأربعاء', line1: 90, line2: 84, line3: 0 },
  { day: 'الخميس', line1: 92, line2: 81, line3: 0 },
  { day: 'الجمعة', line1: 87, line2: 79, line3: 0 },
];

const orderStatusStyles: Record<string, string> = {
  'مجدولة': 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
  'قيد التحضير': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400',
  'قيد التشغيل': 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
  'مكتملة': 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
  'ملغاة': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
};

const priorityStyles: Record<string, string> = {
  'عالية': 'text-red-600 font-bold',
  'متوسطة': 'text-amber-600 font-semibold',
  'منخفضة': 'text-slate-500',
};

/* ─── components ─── */
function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${orderStatusStyles[status] || 'bg-gray-100 text-gray-700'}`}>
      {status === 'مكتملة' && <CheckCircle2 size={12} />}
      {status === 'قيد التشغيل' && <PlayCircle size={12} />}
      {status === 'قيد التحضير' && <Clock size={12} />}
      {status === 'مجدولة' && <CalendarDays size={12} />}
      {status === 'ملغاة' && <X size={12} />}
      {status}
    </span>
  );
}

function LineStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    active: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400',
    idle: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
    maintenance: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-400',
  };
  const labels = { active: 'نشط', idle: 'متوقف', maintenance: 'صيانة' };
  const icons = { active: PlayCircle, idle: PauseCircle, maintenance: Wrench };
  const Icon = icons[status] || Clock;
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status]}`}>
      <Icon size={12} /> {labels[status] || status}
    </span>
  );
}

function EfficiencyBar({ value }: { value: number }) {
  const color = value >= 90 ? 'bg-green-500' : value >= 70 ? 'bg-amber-500' : value >= 50 ? 'bg-orange-500' : 'bg-red-500';
  return (
    <div className="w-full">
      <div className="flex justify-between text-xs mb-1">
        <span className="text-textSecondary">الكفاءة</span>
        <span className="font-semibold text-textPrimary">{value}%</span>
      </div>
      <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className={`h-full ${color} rounded-full`}
        />
      </div>
    </div>
  );
}

/* ─── main page ─── */
export default function ProductionPage() {
  const [orders, setOrders] = useState(productionOrders);
  const [entries, setEntries] = useState(dailyEntries);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showEntryModal, setShowEntryModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState<Order | null>(null);
  const [showEditModal, setShowEditModal] = useState<Order | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('الكل');

  const [orderForm, setOrderForm] = useState({
    product: '', quantity: '', line: 'خط الأعلاف 1', priority: 'متوسطة', plannedDate: '',
  });

  const [entryForm, setEntryForm] = useState({
    line: 'خط الأعلاف 1', product: '', planned: '', actual: '', waste: '', downtime: '',
  });

  const activeLines = productionLines.filter(l => l.status === 'active').length;
  const avgEfficiency = Math.round(productionLines.reduce((s, l) => s + l.efficiency, 0) / productionLines.length);
  const dailyEnergy = '2,450 kWh';
  const runningOrders = orders.filter(o => o.status === 'قيد التشغيل').length;

  const filteredOrders = orders.filter(o => {
    const matchSearch = o.orderNo.toLowerCase().includes(searchQuery.toLowerCase()) || o.product.includes(searchQuery);
    const matchStatus = filterStatus === 'الكل' || o.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleCreateOrder = () => {
    if (!orderForm.product || !orderForm.quantity || !orderForm.plannedDate) return;
    const newOrder = {
      id: orders.length + 1,
      orderNo: `PO-2024-${String(orders.length + 1).padStart(3, '0')}`,
      product: orderForm.product,
      quantity: Number(orderForm.quantity),
      line: orderForm.line,
      priority: orderForm.priority,
      status: 'مجدولة',
      plannedDate: orderForm.plannedDate,
      completion: 0,
    };
    setOrders([newOrder, ...orders]);
    setOrderForm({ product: '', quantity: '', line: 'خط الأعلاف 1', priority: 'متوسطة', plannedDate: '' });
    setShowOrderModal(false);
  };

  const handleDeleteOrder = (id: number) => {
    if (confirm('هل أنت متأكد من حذف أمر الإنتاج؟')) {
      setOrders(orders.filter(o => o.id !== id));
    }
  };

  const handleAddEntry = () => {
    if (!entryForm.product || !entryForm.actual) return;
    const newEntry = {
      id: entries.length + 1,
      date: new Date().toISOString().split('T')[0],
      line: entryForm.line,
      product: entryForm.product,
      planned: Number(entryForm.planned) || 0,
      actual: Number(entryForm.actual),
      waste: Number(entryForm.waste) || 0,
      downtime: entryForm.downtime || '-',
      operator: 'أحمد خالد',
    };
    setEntries([newEntry, ...entries]);
    setEntryForm({ line: 'خط الأعلاف 1', product: '', planned: '', actual: '', waste: '', downtime: '' });
    setShowEntryModal(false);
  };

  const orderColumns = [
    { key: 'orderNo', header: 'رقم الأمر', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'quantity', header: 'الكمية (طن)', sortable: true },
    { key: 'line', header: 'خط الإنتاج', sortable: true },
    { key: 'priority', header: 'الأولوية', sortable: true, render: (row: any) => <span className={priorityStyles[row.priority]}>{row.priority}</span> },
    { key: 'status', header: 'الحالة', sortable: true, render: (row: any) => <StatusBadge status={row.status} /> },
    { key: 'plannedDate', header: 'تاريخ التنفيذ', sortable: true },
    { key: 'completion', header: 'نسبة الإنجاز', sortable: true, render: (row: any) => (
      <div className="flex items-center gap-2">
        <div className="w-16 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
          <div className="h-full bg-green-500 rounded-full" style={{ width: `${row.completion}%` }} />
        </div>
        <span className="text-xs">{row.completion}%</span>
      </div>
    )},
  ];

  const entryColumns = [
    { key: 'date', header: 'التاريخ', sortable: true },
    { key: 'line', header: 'خط الإنتاج', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'planned', header: 'المخطط', sortable: true },
    { key: 'actual', header: 'الفعلي', sortable: true, render: (row: any) => (
      <span className={row.actual >= row.planned ? 'text-green-600 font-semibold' : 'text-amber-600 font-semibold'}>{row.actual}</span>
    )},
    { key: 'waste', header: 'الهالك', sortable: true, render: (row: any) => <span className="text-red-500">{row.waste}</span> },
    { key: 'downtime', header: 'توقف', sortable: true },
    { key: 'operator', header: 'المشغل', sortable: true },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="الإنتاج"
        subtitle="إدارة خطوط الإنتاج وأوامر التشغيل"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'الإنتاج' }]}
      >
        <button
          onClick={() => setShowOrderModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg hover:from-[#0d6b43] hover:to-[#0a4a30] transition-all"
        >
          <Plus size={18} /> أمر إنتاج جديد
        </button>
        <button
          onClick={() => setShowEntryModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-uiBorder dark:border-darkBorder dark:bg-darkSurface text-textPrimary dark:text-darkText rounded-xl text-sm font-semibold hover:bg-surface dark:hover:bg-darkCard transition-all"
        >
          <BarChart3 size={18} /> تسجيل إنتاج يومي
        </button>
      </PageHeader>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="خطوط نشطة" value={String(activeLines)} icon={Factory} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-600" change={0} delay={0} />
        <KPICard title="معدل الكفاءة (OEE)" value={`${avgEfficiency}%`} icon={TrendingUp} iconBg="bg-blue-100 dark:bg-blue-900/30" iconColor="text-blue-600" change={3.2} delay={0.1} />
        <KPICard title="الطاقة اليومية" value={dailyEnergy} icon={Zap} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-600" change={-1.5} delay={0.2} />
        <KPICard title="أوامر قيد التنفيذ" value={String(runningOrders)} icon={Package} iconBg="bg-purple-100 dark:bg-purple-900/30" iconColor="text-purple-600" change={2} delay={0.3} />
      </div>

      {/* Production Lines */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
            <Factory size={18} className="text-[#0d6b43]" /> خطوط الإنتاج
          </h3>
          <span className="text-xs text-textMuted">{productionLines.length} خط</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {productionLines.map((line) => (
            <motion.div
              key={line.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: line.id * 0.1 }}
              className="border border-uiBorder dark:border-darkBorder rounded-xl p-4 hover:shadow-md transition-all bg-surface/50 dark:bg-darkCard/50"
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-textPrimary dark:text-darkText">{line.name}</h4>
                <LineStatusBadge status={line.status} />
              </div>
              <EfficiencyBar value={line.efficiency} />
              <div className="mt-3 space-y-1.5 text-xs">
                <div className="flex justify-between"><span className="text-textSecondary">الطاقة الاستيعابية:</span><span className="font-medium text-textPrimary">{line.capacity} طن/ساعة</span></div>
                <div className="flex justify-between"><span className="text-textSecondary">الدفعة الحالية:</span><span className="font-medium text-textPrimary truncate max-w-[120px]">{line.currentBatch}</span></div>
                <div className="flex justify-between"><span className="text-textSecondary">الإنتاج:</span><span className="font-medium">{line.output} / {line.target}</span></div>
                <div className="flex justify-between"><span className="text-textSecondary">مدير الخط:</span><span className="font-medium text-textPrimary">{line.manager}</span></div>
                <div className="flex justify-between"><span className="text-textSecondary">وقت التشغيل:</span><span className="font-medium text-textPrimary">{line.uptime}</span></div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Efficiency Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card p-5"
      >
        <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-4 flex items-center gap-2">
          <TrendingUp size={18} className="text-[#0d6b43]" /> مؤشر الكفاءة اليومي
        </h3>
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={efficiencyTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="day" tick={{ fontSize: 12 }} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
            <Tooltip />
            <Line type="monotone" dataKey="line1" name="خط الأعلاف 1" stroke="#0d6b43" strokeWidth={2} dot={{ r: 4 }} />
            <Line type="monotone" dataKey="line2" name="خط الأعلاف 2" stroke="#daa520" strokeWidth={2} dot={{ r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Production Orders Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4 }}
      >
        <div className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card overflow-hidden">
          <div className="px-5 py-4 border-b border-uiBorder dark:border-darkBorder flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="text-base font-semibold text-textPrimary dark:text-darkText flex items-center gap-2">
              <Package size={18} className="text-[#0d6b43]" /> أوامر الإنتاج
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                <input
                  type="text"
                  placeholder="بحث في الأوامر..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-56 h-9 pr-9 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText placeholder:text-textMuted focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500 text-sm transition-all"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="h-9 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
              >
                <option value="الكل">جميع الحالات</option>
                <option value="مجدولة">مجدولة</option>
                <option value="قيد التحضير">قيد التحضير</option>
                <option value="قيد التشغيل">قيد التشغيل</option>
                <option value="مكتملة">مكتملة</option>
                <option value="ملغاة">ملغاة</option>
              </select>
            </div>
          </div>
          <DataTable
            columns={orderColumns}
            data={filteredOrders}
            pageSize={8}
            searchable={false}
            rowActions={{
              onView: (row) => setShowDetailModal(row),
              onEdit: (row) => setShowEditModal(row),
              onDelete: (row) => handleDeleteOrder(row.id),
            }}
            emptyMessage="لا توجد أوامر إنتاج"
          />
        </div>
      </motion.div>

      {/* Daily Production Entries */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.5 }}
      >
        <DataTable
          title="تسجيلات الإنتاج اليومية"
          columns={entryColumns}
          data={entries}
          pageSize={5}
          rowActions={{
            onDelete: (row) => { if (confirm('حذف التسجيل؟')) setEntries(entries.filter(e => e.id !== row.id)); },
          }}
          emptyMessage="لا توجد تسجيلات"
        />
      </motion.div>

      {/* Create Order Modal */}
      <AnimatePresence>
        {showOrderModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowOrderModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">أمر إنتاج جديد</h3>
                <button onClick={() => setShowOrderModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                  <input
                    type="text" placeholder="اسم المنتج"
                    value={orderForm.product}
                    onChange={(e) => setOrderForm({ ...orderForm, product: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الكمية (طن)</label>
                    <input
                      type="number" placeholder="0"
                      value={orderForm.quantity}
                      onChange={(e) => setOrderForm({ ...orderForm, quantity: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">خط الإنتاج</label>
                    <select
                      value={orderForm.line}
                      onChange={(e) => setOrderForm({ ...orderForm, line: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="خط الأعلاف 1">خط الأعلاف 1</option>
                      <option value="خط الأعلاف 2">خط الأعلاف 2</option>
                      <option value="خط البقوليات 1">خط البقوليات 1</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الأولوية</label>
                    <select
                      value={orderForm.priority}
                      onChange={(e) => setOrderForm({ ...orderForm, priority: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="عالية">عالية</option>
                      <option value="متوسطة">متوسطة</option>
                      <option value="منخفضة">منخفضة</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">تاريخ التنفيذ</label>
                    <input
                      type="date"
                      value={orderForm.plannedDate}
                      onChange={(e) => setOrderForm({ ...orderForm, plannedDate: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <button
                  onClick={handleCreateOrder}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  إنشاء أمر الإنتاج
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Daily Entry Modal */}
      <AnimatePresence>
        {showEntryModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEntryModal(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تسجيل إنتاج يومي</h3>
                <button onClick={() => setShowEntryModal(false)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">خط الإنتاج</label>
                    <select
                      value={entryForm.line}
                      onChange={(e) => setEntryForm({ ...entryForm, line: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="خط الأعلاف 1">خط الأعلاف 1</option>
                      <option value="خط الأعلاف 2">خط الأعلاف 2</option>
                      <option value="خط البقوليات 1">خط البقوليات 1</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                    <input
                      type="text" placeholder="اسم المنتج"
                      value={entryForm.product}
                      onChange={(e) => setEntryForm({ ...entryForm, product: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">المخطط</label>
                    <input
                      type="number" placeholder="0"
                      value={entryForm.planned}
                      onChange={(e) => setEntryForm({ ...entryForm, planned: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الفعلي</label>
                    <input
                      type="number" placeholder="0"
                      value={entryForm.actual}
                      onChange={(e) => setEntryForm({ ...entryForm, actual: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الهالك</label>
                    <input
                      type="number" placeholder="0"
                      value={entryForm.waste}
                      onChange={(e) => setEntryForm({ ...entryForm, waste: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">سبب التوقف</label>
                  <input
                    type="text" placeholder="وصف سبب التوقف إن وجد"
                    value={entryForm.downtime}
                    onChange={(e) => setEntryForm({ ...entryForm, downtime: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <button
                  onClick={handleAddEntry}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التسجيل
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Order Detail Modal */}
      <AnimatePresence>
        {showDetailModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowDetailModal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-md"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تفاصيل أمر الإنتاج</h3>
                <button onClick={() => setShowDetailModal(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                  <span className="text-textSecondary text-sm">رقم الأمر</span>
                  <span className="font-semibold text-textPrimary">{showDetailModal.orderNo}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                  <span className="text-textSecondary text-sm">المنتج</span>
                  <span className="font-semibold text-textPrimary">{showDetailModal.product}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                  <span className="text-textSecondary text-sm">الكمية</span>
                  <span className="font-semibold text-textPrimary">{showDetailModal.quantity} طن</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                  <span className="text-textSecondary text-sm">خط الإنتاج</span>
                  <span className="font-semibold text-textPrimary">{showDetailModal.line}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                  <span className="text-textSecondary text-sm">الأولوية</span>
                  <span className={priorityStyles[showDetailModal.priority]}>{showDetailModal.priority}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                  <span className="text-textSecondary text-sm">الحالة</span>
                  <StatusBadge status={showDetailModal.status} />
                </div>
                <div className="flex justify-between items-center py-2 border-b border-uiBorder/50 dark:border-darkBorder/30">
                  <span className="text-textSecondary text-sm">تاريخ التنفيذ</span>
                  <span className="font-semibold text-textPrimary">{showDetailModal.plannedDate}</span>
                </div>
                <div className="py-2">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-textSecondary">نسبة الإنجاز</span>
                    <span className="font-semibold">{showDetailModal.completion}%</span>
                  </div>
                  <div className="w-full h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${showDetailModal.completion}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                      className={`h-full rounded-full ${showDetailModal.completion === 100 ? 'bg-green-500' : showDetailModal.completion >= 50 ? 'bg-amber-500' : 'bg-blue-500'}`}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Order Modal */}
      <AnimatePresence>
        {showEditModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowEditModal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-darkSurface rounded-2xl border border-uiBorder dark:border-darkBorder shadow-xl w-full max-w-lg"
            >
              <div className="px-6 py-4 border-b border-uiBorder dark:border-darkBorder flex items-center justify-between">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">تعديل أمر الإنتاج</h3>
                <button onClick={() => setShowEditModal(null)} className="w-8 h-8 rounded-lg hover:bg-surface dark:hover:bg-darkCard flex items-center justify-center transition-colors">
                  <X size={18} className="text-textMuted" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-textSecondary mb-1.5">المنتج</label>
                  <input
                    type="text"
                    value={showEditModal.product}
                    onChange={(e) => setShowEditModal({ ...showEditModal, product: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الكمية (طن)</label>
                    <input
                      type="number"
                      value={showEditModal.quantity}
                      onChange={(e) => setShowEditModal({ ...showEditModal, quantity: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الحالة</label>
                    <select
                      value={showEditModal.status}
                      onChange={(e) => setShowEditModal({ ...showEditModal, status: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="مجدولة">مجدولة</option>
                      <option value="قيد التحضير">قيد التحضير</option>
                      <option value="قيد التشغيل">قيد التشغيل</option>
                      <option value="مكتملة">مكتملة</option>
                      <option value="ملغاة">ملغاة</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">نسبة الإنجاز</label>
                    <input
                      type="number" min="0" max="100"
                      value={showEditModal.completion}
                      onChange={(e) => setShowEditModal({ ...showEditModal, completion: Number(e.target.value) })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30 focus:border-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-textSecondary mb-1.5">الأولوية</label>
                    <select
                      value={showEditModal.priority}
                      onChange={(e) => setShowEditModal({ ...showEditModal, priority: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-textPrimary dark:text-darkText text-sm focus:outline-none focus:ring-2 focus:ring-green-500/30"
                    >
                      <option value="عالية">عالية</option>
                      <option value="متوسطة">متوسطة</option>
                      <option value="منخفضة">منخفضة</option>
                    </select>
                  </div>
                </div>
                <button
                  onClick={() => { setOrders(orders.map(o => o.id === showEditModal.id ? showEditModal : o)); setShowEditModal(null); }}
                  className="w-full h-11 bg-gradient-to-r from-[#0a4a30] to-[#0d6b43] text-white rounded-xl text-sm font-semibold hover:shadow-lg transition-all mt-2"
                >
                  حفظ التعديلات
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
