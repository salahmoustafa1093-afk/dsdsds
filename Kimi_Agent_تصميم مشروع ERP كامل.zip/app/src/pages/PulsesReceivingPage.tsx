// @ts-nocheck
import { useState, useMemo } from 'react';
import {
  Truck, ClipboardCheck, CheckCircle2, XCircle, Clock, Plus, Droplets, Filter,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import DataTable from '@/components/DataTable';
import KPICard from '@/components/KPICard';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

/* ─── Types ─────────────────────────────────────────── */
interface PulseBatch {
  id: number;
  batchNumber: string;
  supplier: string;
  product: string;
  quantity: number;
  truckNumber: string;
  arrivalTime: string;
  moisture: number;
  impurities: number;
  damaged: number;
  colorScore: number;
  status: 'arrived' | 'inspecting' | 'accepted' | 'rejected' | 'completed';
  grade: string;
}

/* ─── Mock Data ─────────────────────────────────────── */
const batchesData: PulseBatch[] = [
  { id: 1, batchNumber: 'FB-2025-001', supplier: 'مزارع الوادي', product: 'فول', quantity: 45, truckNumber: 'س ي ب ٣٤٢١', arrivalTime: '٠٨:٣٠', moisture: 12.5, impurities: 0.6, damaged: 1.8, colorScore: 9, status: 'completed', grade: 'ممتاز' },
  { id: 2, batchNumber: 'FB-2025-002', supplier: 'شركة الحبوب المصرية', product: 'عدس أصفر', quantity: 60, truckNumber: 'س ي ب ١٢٩٤', arrivalTime: '٠٩:١٥', moisture: 13.2, impurities: 0.8, damaged: 2.5, colorScore: 8, status: 'completed', grade: 'أولى' },
  { id: 3, batchNumber: 'FB-2025-003', supplier: 'مزارع الدلتا', product: 'حمص', quantity: 35, truckNumber: 'د ل ع ٥٥٣٢', arrivalTime: '١٠:٠٠', moisture: 11.8, impurities: 0.4, damaged: 1.2, colorScore: 9, status: 'inspecting', grade: '—' },
  { id: 4, batchNumber: 'FB-2025-004', supplier: 'تعاونية النوبارية', product: 'لوبيا', quantity: 25, truckNumber: 'س ي ب ٧٧٨٩', arrivalTime: '١٠:٤٥', moisture: 14.5, impurities: 1.2, damaged: 3.8, colorScore: 6, status: 'rejected', grade: '—' },
  { id: 5, batchNumber: 'FB-2025-005', supplier: 'مزارع الفيوم', product: 'فول', quantity: 50, truckNumber: 'ف ي م ٢٢١٠', arrivalTime: '١١:٣٠', moisture: 12.0, impurities: 0.5, damaged: 1.5, colorScore: 9, status: 'accepted', grade: 'ممتاز' },
  { id: 6, batchNumber: 'FB-2025-006', supplier: 'شركة الصعيد الزراعي', product: 'عدس أخضر', quantity: 40, truckNumber: 'س ي ب ٤٤٥٥', arrivalTime: '١٢:٠٠', moisture: 13.0, impurities: 0.9, damaged: 2.2, colorScore: 7, status: 'arrived', grade: '—' },
  { id: 7, batchNumber: 'FB-2025-007', supplier: 'مزارع بني سويف', product: 'حمص', quantity: 30, truckNumber: 'ب س و ٣٣٨٨', arrivalTime: '١٢:٣٠', moisture: 11.5, impurities: 0.3, damaged: 1.0, colorScore: 10, status: 'inspecting', grade: '—' },
  { id: 8, batchNumber: 'FB-2025-008', supplier: 'مزارع الوادي', product: 'فول', quantity: 55, truckNumber: 'س ي ب ٦٦٢٣', arrivalTime: '١٣:٠٠', moisture: 12.8, impurities: 0.7, damaged: 2.0, colorScore: 8, status: 'arrived', grade: '—' },
];

const statusConfig: Record<string, { label: string; color: string }> = {
  arrived: { label: 'واصل', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' },
  inspecting: { label: 'قيد الفحص', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' },
  accepted: { label: 'مقبول', color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' },
  rejected: { label: 'مرفوض', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' },
  completed: { label: 'مكتمل', color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' },
};

const gradeConfig: Record<string, string> = {
  'ممتاز': 'bg-green-100 text-green-700',
  'أولى': 'bg-blue-100 text-blue-700',
  'ثانية': 'bg-amber-100 text-amber-700',
  '—': 'bg-gray-100 text-gray-500',
};

/* ─── Page ──────────────────────────────────────────── */
export default function PulsesReceivingPage() {
  const [filterStatus, setFilterStatus] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState({ supplier: '', product: 'فول', quantity: '', truck: '', moisture: '', impurities: '', damaged: '' });

  const todayBatches = batchesData.length;
  const inspectingCount = batchesData.filter(b => b.status === 'inspecting').length;
  const completedCount = batchesData.filter(b => b.status === 'completed' || b.status === 'accepted').length;
  const rejectRate = ((batchesData.filter(b => b.status === 'rejected').length / batchesData.length) * 100).toFixed(1);

  const filteredData = useMemo(() => {
    if (filterStatus === 'all') return batchesData;
    return batchesData.filter(b => b.status === filterStatus);
  }, [filterStatus]);

  const columns = [
    { key: 'batchNumber', header: 'رقم الدفعة', sortable: true, width: '110px' },
    { key: 'supplier', header: 'المورد', sortable: true },
    { key: 'product', header: 'المنتج', sortable: true },
    { key: 'quantity', header: 'الكمية (طن)', sortable: true, width: '90px' },
    { key: 'truckNumber', header: 'رقم السيارة', width: '100px' },
    { key: 'arrivalTime', header: 'وصول', width: '70px' },
    {
      key: 'moisture',
      header: 'رطوبة %',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => <span className={`${(row.moisture as number) > 14 ? 'text-red-600 font-bold' : ''}`}>{row.moisture}%</span>,
    },
    {
      key: 'impurities',
      header: 'شوائب %',
      sortable: true,
      width: '80px',
      render: (row: Record<string, unknown>) => <span className={`${(row.impurities as number) > 1 ? 'text-red-600 font-bold' : ''}`}>{row.impurities}%</span>,
    },
    {
      key: 'status',
      header: 'الحالة',
      render: (row: Record<string, unknown>) => {
        const cfg = statusConfig[row.status as string];
        return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>{cfg.label}</span>;
      },
    },
    {
      key: 'grade',
      header: 'التصنيف',
      render: (row: Record<string, unknown>) => <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${gradeConfig[row.grade as string] || 'bg-gray-100'}`}>{row.grade as string}</span>,
    },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      <PageHeader title="استلام البقوليات" subtitle="استلام وفحص دفعات البقوليات الواردة" breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'البقوليات' }, { label: 'الاستلام' }]}>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild><Button className="bg-green-700 hover:bg-green-800 text-white gap-1"><Plus size={16} /> استلام جديد</Button></DialogTrigger>
          <DialogContent className="max-w-lg" dir="rtl">
            <DialogHeader><DialogTitle>استلام دفعة جديدة</DialogTitle></DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>المورد</Label><Input value={formData.supplier} onChange={e => setFormData({ ...formData, supplier: e.target.value })} placeholder="اسم المورد" /></div>
                <div className="space-y-1.5"><Label>المنتج</Label>
                  <select value={formData.product} onChange={e => setFormData({ ...formData, product: e.target.value })} className="w-full h-10 px-3 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                    <option>فول</option><option>عدس أصفر</option><option>عدس أخضر</option><option>حمص</option><option>لوبيا</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>الكمية (طن)</Label><Input type="number" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} placeholder="طن" /></div>
                <div className="space-y-1.5"><Label>رقم السيارة</Label><Input value={formData.truck} onChange={e => setFormData({ ...formData, truck: e.target.value })} placeholder="س ي ب ١٢٣٤" /></div>
              </div>
              <div className="border-t pt-3 mt-2"><p className="text-sm font-medium mb-2 flex items-center gap-1"><Droplets size={14} className="text-blue-500" /> نتائج الفحص</p></div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1.5"><Label>رطوبة %</Label><Input type="number" step="0.1" value={formData.moisture} onChange={e => setFormData({ ...formData, moisture: e.target.value })} placeholder="&lt; 14%" /></div>
                <div className="space-y-1.5"><Label>شوائب %</Label><Input type="number" step="0.1" value={formData.impurities} onChange={e => setFormData({ ...formData, impurities: e.target.value })} placeholder="&lt; 1%" /></div>
                <div className="space-y-1.5"><Label>تالف %</Label><Input type="number" step="0.1" value={formData.damaged} onChange={e => setFormData({ ...formData, damaged: e.target.value })} placeholder="&lt; 3%" /></div>
              </div>
              <div className="flex justify-end gap-2 pt-2"><Button variant="outline" onClick={() => setIsAddOpen(false)}>إلغاء</Button><Button className="bg-green-700 hover:bg-green-800 text-white">حفظ الاستلام</Button></div>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="دفعات اليوم" value={String(todayBatches)} icon={Truck} iconBg="bg-green-100 dark:bg-green-900/30" iconColor="text-green-700 dark:text-green-400" delay={0} />
        <KPICard title="قيد الاستلام" value={String(inspectingCount)} icon={Clock} iconBg="bg-amber-100 dark:bg-amber-900/30" iconColor="text-amber-700 dark:text-amber-400" delay={0.1} />
        <KPICard title="مكتملة" value={String(completedCount)} icon={CheckCircle2} iconBg="bg-emerald-100 dark:bg-emerald-900/30" iconColor="text-emerald-700 dark:text-emerald-400" delay={0.2} />
        <KPICard title="نسبة الرفض" value={`${rejectRate}%`} change={-1.2} icon={XCircle} iconBg="bg-red-100 dark:bg-red-900/30" iconColor="text-red-700 dark:text-red-400" delay={0.3} />
      </div>

      {/* Quality Standards */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4">
        <h3 className="text-sm font-semibold mb-3">معايير الجودة المعتمدة</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center"><span className="text-xs text-blue-600 block">الرطوبة</span><span className="font-bold text-sm">&lt; 14%</span></div>
          <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center"><span className="text-xs text-green-600 block">الشوائب</span><span className="font-bold text-sm">&lt; 1%</span></div>
          <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg text-center"><span className="text-xs text-amber-600 block">التالف</span><span className="font-bold text-sm">&lt; 3%</span></div>
          <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center"><span className="text-xs text-purple-600 block">لون</span><span className="font-bold text-sm">&gt; 7/10</span></div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-[#1a1d23] rounded-xl border border-gray-200 dark:border-gray-800 p-4">
        <Tabs value={filterStatus} onValueChange={setFilterStatus}>
          <TabsList className="h-9"><TabsTrigger value="all" className="text-xs">الكل</TabsTrigger><TabsTrigger value="arrived" className="text-xs">واصل</TabsTrigger><TabsTrigger value="inspecting" className="text-xs">قيد الفحص</TabsTrigger><TabsTrigger value="accepted" className="text-xs">مقبول</TabsTrigger><TabsTrigger value="rejected" className="text-xs">مرفوض</TabsTrigger><TabsTrigger value="completed" className="text-xs">مكتمل</TabsTrigger></TabsList>
        </Tabs>
      </div>

      {/* Table */}
      <DataTable columns={columns} data={filteredData as unknown as Record<string, unknown>[]} title="دفعات البقوليات" rowActions={{ onView: () => {}, onEdit: () => {}, onDelete: () => {} }} />
    </div>
  );
}
