// @ts-nocheck
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Landmark,
  TreePine,
  Coins,
  Banknote,
  Receipt,
  FileBarChart,
  Plus,
  X,
  ChevronDown,
  ChevronLeft,
  Search,
  CircleDollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  CheckCircle2,
  AlertCircle,
  Calendar,
  FileText,
  Printer,
  RotateCcw,
  Lock,
  Unlock,
} from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import KPICard from '@/components/KPICard';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
interface Account {
  id: number;
  code: string;
  name: string;
  type: 'أصول' | 'خصوم' | 'حقوق ملكية' | 'إيرادات' | 'مصروفات';
  parentId?: number;
  balance: number;
  children?: Account[];
}

interface TreasuryTx {
  id: number;
  date: string;
  type: 'قبض' | 'صرف';
  description: string;
  amount: number;
  reference: string;
  user: string;
}

interface BankAccount {
  id: number;
  name: string;
  accountNumber: string;
  branch: string;
  balance: number;
  currency: string;
  iban: string;
  transactions: { date: string; description: string; debit: number; credit: number }[];
}

interface JournalEntry {
  id: number;
  entryNumber: string;
  date: string;
  description: string;
  lines: { account: string; debit: number; credit: number }[];
  total: number;
  status: 'مرحلة' | 'مسودة';
  user: string;
}

/* ------------------------------------------------------------------ */
/*  MOCK DATA                                                          */
/* ------------------------------------------------------------------ */
const chartOfAccounts: Account[] = [
  {
    id: 1, code: '10', name: 'الأصول', type: 'أصول', balance: 12500000, children: [
      { id: 11, code: '11', name: 'الأصول الثابتة', type: 'أصول', balance: 8500000, children: [
        { id: 111, code: '1101', name: 'الأراضي', type: 'أصول', balance: 3000000 },
        { id: 112, code: '1102', name: 'المباني', type: 'أصول', balance: 3500000 },
        { id: 113, code: '1103', name: 'المعدات والآلات', type: 'أصول', balance: 1500000 },
        { id: 114, code: '1104', name: 'السيارات', type: 'أصول', balance: 500000 },
      ]},
      { id: 12, code: '12', name: 'الأصول المتداولة', type: 'أصول', balance: 4000000, children: [
        { id: 121, code: '1201', name: 'النقدية بالخزينة', type: 'أصول', balance: 450000 },
        { id: 122, code: '1202', name: 'البنوك', type: 'أصول', balance: 1850000 },
        { id: 123, code: '1203', name: 'العملاء', type: 'أصول', balance: 1200000 },
        { id: 124, code: '1204', name: 'مخزون البضاعة', type: 'أصول', balance: 500000 },
      ]},
    ],
  },
  {
    id: 2, code: '20', name: 'الخصوم', type: 'خصوم', balance: 3200000, children: [
      { id: 21, code: '21', name: 'الموردون', type: 'خصوم', balance: 1200000 },
      { id: 22, code: '22', name: 'قروض طويلة الأجل', type: 'خصوم', balance: 1500000 },
      { id: 23, code: '23', name: 'مصروفات مستحقة', type: 'خصوم', balance: 500000 },
    ],
  },
  {
    id: 3, code: '30', name: 'حقوق الملكية', type: 'حقوق ملكية', balance: 7800000, children: [
      { id: 31, code: '31', name: 'رأس المال', type: 'حقوق ملكية', balance: 5000000 },
      { id: 32, code: '32', name: 'الأرباح المحتجزة', type: 'حقوق ملكية', balance: 2800000 },
    ],
  },
  {
    id: 4, code: '40', name: 'الإيرادات', type: 'إيرادات', balance: 8500000, children: [
      { id: 41, code: '41', name: 'مبيعات البيض', type: 'إيرادات', balance: 5200000 },
      { id: 42, code: '42', name: 'مبيعات الفراخ', type: 'إيرادات', balance: 2300000 },
      { id: 43, code: '43', name: 'إيرادات أخرى', type: 'إيرادات', balance: 1000000 },
    ],
  },
  {
    id: 5, code: '50', name: 'المصروفات', type: 'مصروفات', balance: 4300000, children: [
      { id: 51, code: '51', name: 'تكلفة البضاعة المباعة', type: 'مصروفات', balance: 1800000 },
      { id: 52, code: '52', name: 'مصروفات رواتب', type: 'مصروفات', balance: 800000 },
      { id: 53, code: '53', name: 'مصروفات إيجارات', type: 'مصروفات', balance: 600000 },
      { id: 54, code: '54', name: 'مصروفات أخرى', type: 'مصروفات', balance: 1100000 },
    ],
  },
];

const treasuryTxs: TreasuryTx[] = [
  { id: 1, date: '2024-01-18', type: 'قبض', description: 'تحصيل من عميل مزرعة النيل', amount: 45000, reference: 'TRX-001', user: 'أحمد محمود' },
  { id: 2, date: '2024-01-17', type: 'صرف', description: 'شراء أعلاف نقدي', amount: 25000, reference: 'TRX-002', user: 'محمد علي' },
  { id: 3, date: '2024-01-16', type: 'قبض', description: 'تحصيل من عميل دواجن السلام', amount: 30000, reference: 'TRX-003', user: 'أحمد محمود' },
  { id: 4, date: '2024-01-15', type: 'صرف', description: 'صرف مرتبات شعبية', amount: 85000, reference: 'TRX-004', user: 'محمد علي' },
  { id: 5, date: '2024-01-14', type: 'قبض', description: 'مبيعات نقدية - فرع القاهرة', amount: 120000, reference: 'TRX-005', user: 'أحمد محمود' },
  { id: 6, date: '2024-01-13', type: 'صرف', description: 'دفع فاتورة كهرباء', amount: 15000, reference: 'TRX-006', user: 'محمد علي' },
  { id: 7, date: '2024-01-12', type: 'قبض', description: 'تحصيل من شركة مصر', amount: 75000, reference: 'TRX-007', user: 'أحمد محمود' },
  { id: 8, date: '2024-01-11', type: 'صرف', description: 'شرع أدوية بيطرية', amount: 22000, reference: 'TRX-008', user: 'محمد علي' },
];

const bankAccounts: BankAccount[] = [
  {
    id: 1, name: 'CIB - البنك التجاري الدولي', accountNumber: '1234567890', branch: 'فرع مدينة نصر', balance: 1850000, currency: 'EGP', iban: 'EG910010000000123456789012345',
    transactions: [
      { date: '2024-01-18', description: 'تحويل من عميل', debit: 50000, credit: 0 },
      { date: '2024-01-16', description: 'سحب - دفع مورد', debit: 0, credit: 120000 },
      { date: '2024-01-14', description: 'إيداع نقدي', debit: 200000, credit: 0 },
      { date: '2024-01-12', description: 'رسوم بنكية', debit: 0, credit: 350 },
    ],
  },
  {
    id: 2, name: 'QNB - بنك قطر الوطني', accountNumber: '9876543210', branch: 'فرع القاهرة الجديدة', balance: 620000, currency: 'EGP', iban: 'EG380019000500987654321012345',
    transactions: [
      { date: '2024-01-17', description: 'تحويل وارد', debit: 85000, credit: 0 },
      { date: '2024-01-15', description: 'دفع قسط قرض', debit: 0, credit: 45000 },
      { date: '2024-01-10', description: 'إيداع شيك', debit: 150000, credit: 0 },
    ],
  },
  {
    id: 3, name: 'AlexBank - بنك الإسكندرية', accountNumber: '5566778899', branch: 'فرع الإسكندرية', balance: 280000, currency: 'EGP', iban: 'EG520546001000556677889901234',
    transactions: [
      { date: '2024-01-18', description: 'تحصيل شيك عميل', debit: 35000, credit: 0 },
      { date: '2024-01-13', description: 'سحب نقدي', debit: 0, credit: 25000 },
    ],
  },
];

const journalEntries: JournalEntry[] = [
  { id: 1, entryNumber: 'JE-2024-001', date: '2024-01-18', description: 'قيد مبيعات نقدية', lines: [{ account: 'النقدية بالخزينة', debit: 120000, credit: 0 }, { account: 'مبيعات البيض', debit: 0, credit: 120000 }], total: 120000, status: 'مرحلة', user: 'أحمد محمود' },
  { id: 2, entryNumber: 'JE-2024-002', date: '2024-01-17', description: 'قيد مشتريات أعلاف آجلة', lines: [{ account: 'مخزون الأعلاف', debit: 250000, credit: 0 }, { account: 'الموردون', debit: 0, credit: 250000 }], total: 250000, status: 'مرحلة', user: 'محمد علي' },
  { id: 3, entryNumber: 'JE-2024-003', date: '2024-01-16', description: 'قيد دفع مرتبات', lines: [{ account: 'مصروفات رواتب', debit: 85000, credit: 0 }, { account: 'البنوك - CIB', debit: 0, credit: 85000 }], total: 85000, status: 'مرحلة', user: 'أحمد محمود' },
  { id: 4, entryNumber: 'JE-2024-004', date: '2024-01-15', description: 'قيد تحصيل من عميل', lines: [{ account: 'النقدية بالخزينة', debit: 45000, credit: 0 }, { account: 'العملاء', debit: 0, credit: 45000 }], total: 45000, status: 'مرحلة', user: 'محمد علي' },
  { id: 5, entryNumber: 'JE-2024-005', date: '2024-01-14', description: 'قيد إهلاك معدات', lines: [{ account: 'مصروف الإهلاك', debit: 12500, credit: 0 }, { account: 'مجمع الإهلاك', debit: 0, credit: 12500 }], total: 12500, status: 'مسودة', user: 'أحمد محمود' },
  { id: 6, entryNumber: 'JE-2024-006', date: '2024-01-13', description: 'قيد دفع إيجار', lines: [{ account: 'مصروفات إيجارات', debit: 50000, credit: 0 }, { account: 'النقدية بالخزينة', debit: 0, credit: 50000 }], total: 50000, status: 'مرحلة', user: 'محمد علي' },
  { id: 7, entryNumber: 'JE-2024-007', date: '2024-01-12', description: 'قيد مرتجع مبيعات', lines: [{ account: 'مبيعات البيض', debit: 8000, credit: 0 }, { account: 'العملاء', debit: 0, credit: 8000 }], total: 8000, status: 'مسودة', user: 'أحمد محمود' },
  { id: 8, entryNumber: 'JE-2024-008', date: '2024-01-11', description: 'قيد تحويل بين البنوك', lines: [{ account: 'البنوك - QNB', debit: 100000, credit: 0 }, { account: 'البنوك - CIB', debit: 0, credit: 100000 }], total: 100000, status: 'مرحلة', user: 'محمد علي' },
  { id: 9, entryNumber: 'JE-2024-009', date: '2024-01-10', description: 'قيد مصروفات كهرباء', lines: [{ account: 'مصروفات أخرى', debit: 15000, credit: 0 }, { account: 'النقدية بالخزينة', debit: 0, credit: 15000 }], total: 15000, status: 'مرحلة', user: 'أحمد محمود' },
  { id: 10, entryNumber: 'JE-2024-010', date: '2024-01-09', description: 'قيد إيراد فوائد بنكية', lines: [{ account: 'البنوك - CIB', debit: 2200, credit: 0 }, { account: 'إيرادات أخرى', debit: 0, credit: 2200 }], total: 2200, status: 'مرحلة', user: 'محمد علي' },
];

/* ------------------------------------------------------------------ */
/*  HELPER COMPONENTS                                                  */
/* ------------------------------------------------------------------ */
function AccountTree({ accounts, level = 0 }: { accounts: Account[]; level?: number }) {
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});

  const toggle = (id: number) => setExpanded((p) => ({ ...p, [id]: !p[id] }));

  return (
    <div className="space-y-1">
      {accounts.map((acc) => {
        const isExpanded = expanded[acc.id];
        const hasChildren = acc.children && acc.children.length > 0;
        const typeColors: Record<string, string> = {
          أصول: 'text-blue-600',
          خصوم: 'text-red-600',
          'حقوق ملكية': 'text-purple-600',
          إيرادات: 'text-green-600',
          مصروفات: 'text-orange-600',
        };

        return (
          <div key={acc.id}>
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2 }}
              className={`flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-surface dark:hover:bg-darkCard cursor-pointer transition-colors ${level > 0 ? 'mr-4' : ''}`}
              onClick={() => hasChildren && toggle(acc.id)}
            >
              {hasChildren ? (
                isExpanded ? <ChevronDown size={14} className="text-textMuted" /> : <ChevronLeft size={14} className="text-textMuted" />
              ) : (
                <div className="w-3.5" />
              )}
              <span className={`text-xs font-mono ${typeColors[acc.type] || 'text-textMuted'}`}>{acc.code}</span>
              <span className="text-sm font-medium text-textPrimary dark:text-darkText flex-1">{acc.name}</span>
              <span className={`text-sm font-semibold ${typeColors[acc.type] || 'text-textPrimary'}`}>{acc.balance.toLocaleString('ar-EG')}</span>
            </motion.div>
            <AnimatePresence>
              {hasChildren && isExpanded && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <AccountTree accounts={acc.children!} level={level + 1} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  return status === 'مرحلة' ? (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700 border border-green-300">
      <CheckCircle2 size={12} /> مرحلة
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 border border-amber-300">
      <AlertCircle size={12} /> مسودة
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function AccountingPage() {
  const [activeTab, setActiveTab] = useState('chart');
  const [searchQuery, setSearchQuery] = useState('');
  const [entryModalOpen, setEntryModalOpen] = useState(false);
  const [entries, setEntries] = useState<JournalEntry[]>(journalEntries);

  /* ── KPIs ── */
  const cashBalance = 450000;
  const receivables = 1200000;
  const payables = 1200000;
  const revenue = 8500000;
  const expenses = 4300000;

  /* ── Tabs ── */
  const tabs = [
    { key: 'chart', label: 'شجرة الحسابات', icon: TreePine },
    { key: 'treasury', label: 'الخزينة', icon: Banknote },
    { key: 'banks', label: 'البنوك', icon: Landmark },
    { key: 'entries', label: 'القيود', icon: Receipt },
    { key: 'reports', label: 'التقارير', icon: FileBarChart },
  ];

  /* ── Entry form ── */
  const [entryLines, setEntryLines] = useState([{ account: '', debit: 0, credit: 0 }]);
  const [entryDesc, setEntryDesc] = useState('');
  const [entryDate, setEntryDate] = useState(new Date().toISOString().split('T')[0]);

  const addEntryLine = () => setEntryLines([...entryLines, { account: '', debit: 0, credit: 0 }]);
  const updateEntryLine = (i: number, field: string, value: any) => {
    setEntryLines((prev) => {
      const next = [...prev];
      next[i] = { ...next[i], [field]: field === 'account' ? value : +value };
      return next;
    });
  };
  const totalDebit = entryLines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = entryLines.reduce((s, l) => s + l.credit, 0);
  const isBalanced = totalDebit === totalCredit && totalDebit > 0;

  const saveEntry = () => {
    if (!isBalanced || !entryDesc) return;
    const newId = Math.max(...entries.map((e) => e.id)) + 1;
    const newEntry: JournalEntry = {
      id: newId,
      entryNumber: `JE-2024-${String(newId).padStart(3, '0')}`,
      date: entryDate,
      description: entryDesc,
      lines: entryLines.filter((l) => l.account),
      total: totalDebit,
      status: 'مسودة',
      user: 'أحمد محمود',
    };
    setEntries((prev) => [newEntry, ...prev]);
    setEntryModalOpen(false);
    setEntryDesc('');
    setEntryLines([{ account: '', debit: 0, credit: 0 }]);
  };

  const filteredEntries = entries.filter((e) =>
    e.description.includes(searchQuery) || e.entryNumber.toLowerCase().includes(searchQuery)
  );

  return (
    <div className="gff-page-transition space-y-6">
      <PageHeader
        title="النظام المحاسبي"
        subtitle="إدارة الحسابات والخزينة والبنوك والقيود اليومية"
        breadcrumb={[{ label: 'الرئيسية', path: '/' }, { label: 'المحاسبة' }]}
      />

      {/* ── KPIs ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard title="الرصيد النقدي" value={`${cashBalance.toLocaleString('ar-EG')} ج.م`} icon={Coins} iconBg="bg-green-50" iconColor="text-green-600" delay={0} />
        <KPICard title="الذمم المدينة" value={`${receivables.toLocaleString('ar-EG')} ج.م`} icon={ArrowDownRight} iconBg="bg-blue-50" iconColor="text-blue-600" change={5} delay={0.05} />
        <KPICard title="الذمم الدائنة" value={`${payables.toLocaleString('ar-EG')} ج.م`} icon={ArrowUpRight} iconBg="bg-red-50" iconColor="text-red-600" change={-3} delay={0.1} />
        <KPICard title="إجمالي الإيرادات" value={`${revenue.toLocaleString('ar-EG')} ج.م`} icon={TrendingUp} iconBg="bg-purple-50" iconColor="text-purple-600" change={12} changeLabel="عن العام السابق" delay={0.15} />
        <KPICard title="إجمالي المصروفات" value={`${expenses.toLocaleString('ar-EG')} ج.م`} icon={TrendingDown} iconBg="bg-orange-50" iconColor="text-orange-600" change={8} changeLabel="عن العام السابق" delay={0.2} />
      </div>

      {/* ── Tabs ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.25 }}
        className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-card"
      >
        <div className="flex items-center border-b border-uiBorder dark:border-darkBorder overflow-x-auto">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === t.key
                  ? 'border-green-700 text-green-700'
                  : 'border-transparent text-textSecondary hover:text-textPrimary'
              }`}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>

        <div className="p-6">
          {/* ══════════ TAB 1: CHART OF ACCOUNTS ══════════ */}
          {activeTab === 'chart' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText">شجرة الحسابات</h3>
                <div className="flex items-center gap-3 text-xs">
                  {['أصول', 'خصوم', 'حقوق ملكية', 'إيرادات', 'مصروفات'].map((t) => (
                    <span key={t} className="flex items-center gap-1">
                      <span className={`w-2 h-2 rounded-full ${
                        t === 'أصول' ? 'bg-blue-500' : t === 'خصوم' ? 'bg-red-500' : t === 'حقوق ملكية' ? 'bg-purple-500' : t === 'إيرادات' ? 'bg-green-500' : 'bg-orange-500'
                      }`} />
                      {t}
                    </span>
                  ))}
                </div>
              </div>
              <div className="bg-surface dark:bg-darkBg rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                <AccountTree accounts={chartOfAccounts} />
              </div>
            </motion.div>
          )}

          {/* ══════════ TAB 2: TREASURY ══════════ */}
          {activeTab === 'treasury' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 dark:bg-green-950/20 rounded-xl p-4 border border-green-200 dark:border-green-800">
                  <p className="text-xs text-green-600 dark:text-green-400 mb-1">الرصيد النقدي</p>
                  <p className="text-2xl font-bold text-green-700 dark:text-green-300">{cashBalance.toLocaleString('ar-EG')} ج.م</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-950/20 rounded-xl p-4 border border-blue-200 dark:border-blue-800">
                  <p className="text-xs text-blue-600 dark:text-blue-400 mb-1">إجمالي القبض اليوم</p>
                  <p className="text-2xl font-bold text-blue-700 dark:text-blue-300">195,000 ج.م</p>
                </div>
                <div className="bg-red-50 dark:bg-red-950/20 rounded-xl p-4 border border-red-200 dark:border-red-800">
                  <p className="text-xs text-red-600 dark:text-red-400 mb-1">إجمالي الصرف اليوم</p>
                  <p className="text-2xl font-bold text-red-700 dark:text-red-300">147,000 ج.م</p>
                </div>
              </div>

              <div>
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-3">حركات الخزينة</h3>
                <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                        <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                        <th className="px-3 py-2 text-right text-xs text-textSecondary">النوع</th>
                        <th className="px-3 py-2 text-right text-xs text-textSecondary">الوصف</th>
                        <th className="px-3 py-2 text-right text-xs text-textSecondary">المبلغ</th>
                        <th className="px-3 py-2 text-right text-xs text-textSecondary">المستخدم</th>
                      </tr>
                    </thead>
                    <tbody>
                      {treasuryTxs.map((tx) => (
                        <tr key={tx.id} className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-surface dark:hover:bg-darkCard/50 transition-colors">
                          <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{tx.date}</td>
                          <td className="px-3 py-2.5">
                            <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${tx.type === 'قبض' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                              {tx.type}
                            </span>
                          </td>
                          <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{tx.description}</td>
                          <td className={`px-3 py-2.5 font-medium ${tx.type === 'قبض' ? 'text-green-600' : 'text-red-600'}`}>
                            {tx.type === 'قبض' ? '+' : '-'}{tx.amount.toLocaleString('ar-EG')}
                          </td>
                          <td className="px-3 py-2.5 text-textSecondary">{tx.user}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Daily Closing */}
              <div className="bg-amber-50 dark:bg-amber-950/20 rounded-xl p-4 border border-amber-200 dark:border-amber-800">
                <div className="flex items-center gap-2 mb-2">
                  <Lock size={16} className="text-amber-600" />
                  <h4 className="text-sm font-semibold text-amber-800 dark:text-amber-300">الإقفال اليومي</h4>
                </div>
                <p className="text-xs text-amber-700 dark:text-amber-400 mb-3">الإقفال اليومي ليوم 2024-01-18 - الرصيد: 450,000 ج.م</p>
                <button className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-medium transition-colors">
                  إقفال اليوم
                </button>
              </div>
            </motion.div>
          )}

          {/* ══════════ TAB 3: BANKS ══════════ */}
          {activeTab === 'banks' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {bankAccounts.map((bank) => (
                  <motion.div
                    key={bank.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white dark:bg-darkCard rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText">{bank.name}</h4>
                        <p className="text-xs text-textMuted">{bank.accountNumber} · {bank.branch}</p>
                      </div>
                      <Landmark size={20} className="text-green-600" />
                    </div>
                    <p className="text-2xl font-bold text-textPrimary dark:text-darkText mb-1">{bank.balance.toLocaleString('ar-EG')} <span className="text-sm font-normal text-textMuted">{bank.currency}</span></p>
                    <p className="text-[11px] text-textMuted">IBAN: {bank.iban}</p>
                  </motion.div>
                ))}
              </div>

              {/* Bank Transactions */}
              <div>
                <h3 className="text-base font-semibold text-textPrimary dark:text-darkText mb-3">حركات البنوك</h3>
                {bankAccounts.map((bank) => (
                  <div key={bank.id} className="mb-4">
                    <h4 className="text-sm font-medium text-textSecondary mb-2">{bank.name}</h4>
                    <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                            <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                            <th className="px-3 py-2 text-right text-xs text-textSecondary">الوصف</th>
                            <th className="px-3 py-2 text-right text-xs text-textSecondary">مدين</th>
                            <th className="px-3 py-2 text-right text-xs text-textSecondary">دائن</th>
                          </tr>
                        </thead>
                        <tbody>
                          {bank.transactions.map((tx, i) => (
                            <tr key={i} className="border-b border-uiBorder/50 dark:border-darkBorder/30">
                              <td className="px-3 py-2 text-textPrimary dark:text-darkText">{tx.date}</td>
                              <td className="px-3 py-2 text-textPrimary dark:text-darkText">{tx.description}</td>
                              <td className="px-3 py-2 text-green-600 font-medium">{tx.debit > 0 ? tx.debit.toLocaleString('ar-EG') : '-'}</td>
                              <td className="px-3 py-2 text-red-600 font-medium">{tx.credit > 0 ? tx.credit.toLocaleString('ar-EG') : '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>

              {/* Checks */}
              <div className="bg-surface dark:bg-darkCard rounded-xl border border-uiBorder dark:border-darkBorder p-4">
                <h4 className="text-sm font-semibold text-textPrimary dark:text-darkText mb-3">الشيكات</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="bg-white dark:bg-darkSurface rounded-lg p-3 border border-uiBorder">
                    <p className="text-xs text-textMuted">شيكات تحت التحصيل</p>
                    <p className="text-lg font-bold text-amber-600 mt-1">125,000 ج.م</p>
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-lg p-3 border border-uiBorder">
                    <p className="text-xs text-textMuted">شيكات مقدمة</p>
                    <p className="text-lg font-bold text-blue-600 mt-1">85,000 ج.م</p>
                  </div>
                  <div className="bg-white dark:bg-darkSurface rounded-lg p-3 border border-uiBorder">
                    <p className="text-xs text-textMuted">شيكات مرجعة</p>
                    <p className="text-lg font-bold text-red-600 mt-1">0 ج.م</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ══════════ TAB 4: JOURNAL ENTRIES ══════════ */}
          {activeTab === 'entries' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }} className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="relative w-64">
                  <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-textMuted" />
                  <input type="text" placeholder="بحث في القيود..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full h-10 pr-10 pl-4 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                </div>
                <button onClick={() => setEntryModalOpen(true)} className="inline-flex items-center gap-2 px-4 py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors">
                  <Plus size={16} /> قيد جديد
                </button>
              </div>

              <div className="border border-uiBorder dark:border-darkBorder rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-surface dark:bg-darkCard border-b border-uiBorder dark:border-darkBorder">
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">رقم القيد</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">التاريخ</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">الوصف</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">الإجمالي</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">الحالة</th>
                      <th className="px-3 py-2 text-right text-xs text-textSecondary">المستخدم</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredEntries.map((e) => (
                      <tr key={e.id} className="border-b border-uiBorder/50 dark:border-darkBorder/30 hover:bg-surface dark:hover:bg-darkCard/50 transition-colors">
                        <td className="px-3 py-2.5 font-medium text-textPrimary dark:text-darkText">{e.entryNumber}</td>
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{e.date}</td>
                        <td className="px-3 py-2.5 text-textPrimary dark:text-darkText">{e.description}</td>
                        <td className="px-3 py-2.5 font-medium text-textPrimary dark:text-darkText">{e.total.toLocaleString('ar-EG')}</td>
                        <td className="px-3 py-2.5"><StatusBadge status={e.status} /></td>
                        <td className="px-3 py-2.5 text-textSecondary">{e.user}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* ══════════ TAB 5: REPORTS ══════════ */}
          {activeTab === 'reports' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* P&L */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0 }}
                  className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-11 h-11 rounded-full bg-green-50 flex items-center justify-center">
                      <TrendingUp size={22} className="text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText">قائمة الدخل</h3>
                      <p className="text-xs text-textMuted">الفترة: يناير 2024</p>
                    </div>
                  </div>
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-textSecondary">الإيرادات</span>
                      <span className="font-medium text-green-600">+{revenue.toLocaleString('ar-EG')}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-textSecondary">المصروفات</span>
                      <span className="font-medium text-red-600">-{expenses.toLocaleString('ar-EG')}</span>
                    </div>
                    <div className="h-px bg-uiBorder" />
                    <div className="flex justify-between text-sm font-semibold">
                      <span className="text-textPrimary dark:text-darkText">صافي الربح</span>
                      <span className="text-green-700">{(revenue - expenses).toLocaleString('ar-EG')}</span>
                    </div>
                  </div>
                  <button className="w-full py-2 bg-green-700 hover:bg-green-800 text-white rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2">
                    <FileText size={14} /> إنشاء التقرير
                  </button>
                </motion.div>

                {/* Balance Sheet */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-11 h-11 rounded-full bg-blue-50 flex items-center justify-center">
                      <Landmark size={22} className="text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText">الميزانية العمومية</h3>
                      <p className="text-xs text-textMuted">تاريخ: 2024-01-18</p>
                    </div>
                  </div>
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-textSecondary">إجمالي الأصول</span>
                      <span className="font-medium text-blue-600">12,500,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-textSecondary">إجمالي الخصوم</span>
                      <span className="font-medium text-red-600">3,200,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-textSecondary">حقوق الملكية</span>
                      <span className="font-medium text-purple-600">7,800,000</span>
                    </div>
                  </div>
                  <button className="w-full py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2">
                    <FileText size={14} /> إنشاء التقرير
                  </button>
                </motion.div>

                {/* Cash Flow */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder p-5 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-11 h-11 rounded-full bg-amber-50 flex items-center justify-center">
                      <Wallet size={22} className="text-amber-600" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-textPrimary dark:text-darkText">التدفق النقدي</h3>
                      <p className="text-xs text-textMuted">الفترة: يناير 2024</p>
                    </div>
                  </div>
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-textSecondary">التشغيل</span>
                      <span className="font-medium text-green-600">+420,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-secondary">الاستثمار</span>
                      <span className="font-medium text-red-600">-150,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-textSecondary">التمويل</span>
                      <span className="font-medium text-blue-600">-45,000</span>
                    </div>
                  </div>
                  <button className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2">
                    <FileText size={14} /> إنشاء التقرير
                  </button>
                </motion.div>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>

      {/* ═══════════════════ CREATE ENTRY MODAL ═══════════════════ */}
      <AnimatePresence>
        {entryModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-darkSurface rounded-xl border border-uiBorder dark:border-darkBorder shadow-modal w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-uiBorder dark:border-darkBorder">
                <h3 className="text-lg font-semibold text-textPrimary dark:text-darkText">قيد محاسبي جديد</h3>
                <button onClick={() => setEntryModalOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center text-textMuted hover:bg-surface transition-colors">
                  <X size={18} />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-textSecondary mb-1.5">التاريخ</label>
                    <input type="date" value={entryDate} onChange={(e) => setEntryDate(e.target.value)} className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-textSecondary mb-1.5">الوصف</label>
                    <input value={entryDesc} onChange={(e) => setEntryDesc(e.target.value)} placeholder="وصف القيد" className="w-full h-10 px-3 rounded-lg border border-uiBorder dark:border-darkBorder bg-surface dark:bg-darkCard text-sm" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-medium text-textSecondary">بنود القيد</label>
                    <button onClick={addEntryLine} className="text-xs text-green-700 hover:text-green-800 font-medium flex items-center gap-1">
                      <Plus size={14} /> إضافة بند
                    </button>
                  </div>
                  <div className="space-y-2">
                    {entryLines.map((line, i) => (
                      <div key={i} className="grid grid-cols-12 gap-2 items-center bg-surface dark:bg-darkCard rounded-lg p-2">
                        <div className="col-span-5">
                          <input value={line.account} onChange={(e) => updateEntryLine(i, 'account', e.target.value)} placeholder="اسم الحساب" className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm" />
                        </div>
                        <div className="col-span-3">
                          <input type="number" value={line.debit || ''} onChange={(e) => updateEntryLine(i, 'debit', e.target.value)} placeholder="مدين" className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm" />
                        </div>
                        <div className="col-span-3">
                          <input type="number" value={line.credit || ''} onChange={(e) => updateEntryLine(i, 'credit', e.target.value)} placeholder="دائن" className="w-full h-9 px-3 rounded border border-uiBorder dark:border-darkBorder bg-white dark:bg-darkCard text-sm" />
                        </div>
                        <div className="col-span-1">
                          {entryLines.length > 1 && (
                            <button onClick={() => setEntryLines(entryLines.filter((_, idx) => idx !== i))} className="w-8 h-8 rounded flex items-center justify-center text-red-500 hover:bg-red-50">
                              <Trash2Icon />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Balance Check */}
                <div className={`rounded-lg p-4 border flex items-center justify-between ${isBalanced ? 'bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-800' : 'bg-red-50 border-red-200 dark:bg-red-950/20 dark:border-red-800'}`}>
                  <div className="flex items-center gap-2">
                    {isBalanced ? <CheckCircle2 size={18} className="text-green-600" /> : <AlertCircle size={18} className="text-red-600" />}
                    <span className={`text-sm font-medium ${isBalanced ? 'text-green-700' : 'text-red-700'}`}>
                      {isBalanced ? 'القيد متوازن' : 'القيد غير متوازن'}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-textSecondary">مدين: <span className="font-semibold text-textPrimary">{totalDebit.toLocaleString('ar-EG')}</span></span>
                    <span className="text-textSecondary">دائن: <span className="font-semibold text-textPrimary">{totalCredit.toLocaleString('ar-EG')}</span></span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-uiBorder dark:border-darkBorder">
                <button onClick={() => setEntryModalOpen(false)} className="px-4 py-2 rounded-lg border border-uiBorder text-textSecondary hover:bg-surface text-sm">إلغاء</button>
                <button onClick={saveEntry} disabled={!isBalanced} className="px-4 py-2 rounded-lg bg-green-700 hover:bg-green-800 disabled:opacity-50 text-white text-sm font-medium transition-colors">حفظ</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Trash2Icon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 6h18" /><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" /><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
    </svg>
  );
}
