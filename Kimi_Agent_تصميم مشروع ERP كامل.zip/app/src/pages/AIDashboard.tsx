import { useState } from "react";
import { motion } from "framer-motion";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Legend, ScatterChart, Scatter, ZAxis
} from "recharts";
import { Brain, TrendingUp, BarChart3, Lightbulb, Target } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import {
  demandForecast, commodityPrices, branchForecast, churnRiskData,
  creditRisk, abcAnalysis, seasonalHeatmap, reorderSuggestions,
  pricingOptimization, upsellOpportunities, expansionRecommendations, modelMetrics
} from "../data/aiMockData";

const fadeUp = { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 } };
const COLORS = ["#0a4a30", "#0d6b43", "#daa520", "#f0c040", "#b8860b"];

function Heatmap() {
  const months = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  const monthKeys = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"] as const;

  const getColor = (v: number) => {
    if (v >= 95) return "#062d1e";
    if (v >= 90) return "#0a4a30";
    if (v >= 85) return "#0d6b43";
    if (v >= 80) return "#daa520";
    if (v >= 75) return "#f0c040";
    return "#fef3c7";
  };

  return (
    <div className="overflow-auto">
      <table className="w-full text-[10px]">
        <thead>
          <tr>
            <th className="p-1">المنتج</th>
            {months.map(m => <th key={m} className="p-1 text-center">{m}</th>)}
          </tr>
        </thead>
        <tbody>
          {seasonalHeatmap.map(row => (
            <tr key={row.product}>
              <td className="p-1 font-medium text-xs">{row.product}</td>
              {monthKeys.map(k => (
                <td key={k} className="p-1 text-center text-white font-bold" style={{ background: getColor(row[k as keyof typeof row] as number) }}>
                  {row[k as keyof typeof row]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AIDashboard() {
  const [activeTab, setActiveTab] = useState("forecast");

  return (
    <div className="p-6 space-y-6 bg-surface min-h-screen">
      <motion.div {...fadeUp} className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
          <Brain className="w-6 h-6 text-gold" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-primary-dark">تحليلات الذكاء الاصطناعي</h1>
          <p className="text-sm text-muted">رؤى متقدمة ونماذج تنبؤية مدعومة بالذكاء الاصطناعي</p>
        </div>
      </motion.div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="forecast" className="flex items-center gap-1"><TrendingUp className="w-3 h-3"/> التنبؤات</TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-1"><BarChart3 className="w-3 h-3"/> التحليلات</TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-1"><Lightbulb className="w-3 h-3"/> التوصيات</TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-1"><Target className="w-3 h-3"/> الأداء</TabsTrigger>
        </TabsList>

        {/* Forecast Tab */}
        <TabsContent value="forecast" className="space-y-4 mt-4">
          <motion.div {...fadeUp}>
            <Card>
              <CardHeader><CardTitle className="text-base">تنبؤ الطلب - 90 يوم قادمة</CardTitle></CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={demandForecast}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                    <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="predicted" stroke="#0a4a30" strokeWidth={2} dot={false} name="التنبؤ" />
                    <Line type="monotone" dataKey="lower" stroke="#0d6b43" strokeDasharray="5 5" dot={false} name="الحد الأدنى" />
                    <Line type="monotone" dataKey="upper" stroke="#daa520" strokeDasharray="5 5" dot={false} name="الحد الأقصى" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <motion.div {...fadeUp} transition={{ delay: 0.1 }}>
              <Card>
                <CardHeader><CardTitle className="text-base">أسعار السلع الزراعية</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <LineChart data={commodityPrices}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                      <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="corn" stroke="#0a4a30" name="ذرة صفراء" />
                      <Line type="monotone" dataKey="soy" stroke="#daa520" name="فول صويا" />
                      <Line type="monotone" dataKey="wheat" stroke="#dc2626" name="قمح" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div {...fadeUp} transition={{ delay: 0.15 }}>
              <Card>
                <CardHeader><CardTitle className="text-base">تنبؤ الفروع</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={branchForecast}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                      <XAxis dataKey="branch" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="forecast" fill="#0a4a30" name="التنبؤ" />
                      <Bar dataKey="actual" fill="#daa520" name="الفعلي" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <motion.div {...fadeUp}>
              <Card>
                <CardHeader><CardTitle className="text-base">مخاطر فقدان العملاء</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <ScatterChart>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                      <XAxis dataKey="risk" name="مخاطر" tick={{ fontSize: 11 }} />
                      <YAxis dataKey="value" name="القيمة" tick={{ fontSize: 11 }} />
                      <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                      <Scatter data={churnRiskData} fill="#0a4a30">
                        {churnRiskData.map((entry, index) => (
                          <Cell key={index} fill={entry.risk > 0.5 ? "#dc2626" : entry.risk > 0.3 ? "#daa520" : "#0a4a30"} />
                        ))}
                      </Scatter>
                    </ScatterChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div {...fadeUp} transition={{ delay: 0.1 }}>
              <Card>
                <CardHeader><CardTitle className="text-base">تحليل ABC</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie data={abcAnalysis} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name }) => name}>
                        {abcAnalysis.map((_, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <motion.div {...fadeUp} transition={{ delay: 0.2 }}>
            <Card>
              <CardHeader><CardTitle className="text-base">مخاطر الائتمان</CardTitle></CardHeader>
              <CardContent>
                <div className="overflow-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="py-2 text-right">العميل</th>
                        <th className="py-2 text-right">الحد</th>
                        <th className="py-2 text-right">المستخدم</th>
                        <th className="py-2 text-right">النسبة</th>
                        <th className="py-2 text-right">النقاط</th>
                      </tr>
                    </thead>
                    <tbody>
                      {creditRisk.map(c => (
                        <tr key={c.customer} className="border-b border-border/50">
                          <td className="py-2 font-medium">{c.customer}</td>
                          <td className="py-2">{c.limit.toLocaleString()}</td>
                          <td className="py-2">{c.used.toLocaleString()}</td>
                          <td className="py-2 w-32"><Progress value={(c.used / c.limit) * 100} className="h-2" /></td>
                          <td className="py-2">
                            <Badge variant={c.score > 80 ? "success" : c.score > 60 ? "warning" : "destructive"}>{c.score}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeUp} transition={{ delay: 0.25 }}>
            <Card>
              <CardHeader><CardTitle className="text-base">الطلب الموسمي - خريطة حرارية</CardTitle></CardHeader>
              <CardContent><Heatmap /></CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Recommendations Tab */}
        <TabsContent value="recommendations" className="space-y-4 mt-4">
          <motion.div {...fadeUp}>
            <Card>
              <CardHeader><CardTitle className="text-base">اقتراحات إعادة الطلب</CardTitle></CardHeader>
              <CardContent>
                <div className="overflow-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border"><th className="py-2 text-right">الصنف</th><th className="py-2 text-right">الحالي</th><th className="py-2 text-right">المقترح</th><th className="py-2 text-right">نقطة إعادة الطلب</th><th className="py-2 text-right">المورد</th><th className="py-2 text-right">الوقت</th></tr>
                    </thead>
                    <tbody>
                      {reorderSuggestions.map(r => (
                        <tr key={r.item} className="border-b border-border/50">
                          <td className="py-2 font-medium">{r.item}</td>
                          <td className="py-2 text-red-600">{r.current}</td>
                          <td className="py-2 text-green-600">{r.suggested}</td>
                          <td className="py-2">{r.reorderPoint}</td>
                          <td className="py-2">{r.supplier}</td>
                          <td className="py-2">{r.leadTime}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {pricingOptimization.map(p => (
              <motion.div key={p.product} {...fadeUp} transition={{ delay: 0.1 }}>
                <Card className="h-full">
                  <CardHeader><CardTitle className="text-sm">{p.product}</CardTitle></CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-xs"><span>السعر الحالي</span><span>{p.currentPrice} جنيه</span></div>
                    <div className="flex justify-between text-xs"><span>السعر المقترح</span><span className="text-green-600 font-bold">{p.suggested} جنيه</span></div>
                    <div className="flex justify-between text-xs"><span>المرونة</span><span>{p.elasticity}</span></div>
                    <div className="flex justify-between text-xs"><span>الثقة</span><Badge variant="secondary">{p.confidence}%</Badge></div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <motion.div {...fadeUp} transition={{ delay: 0.2 }}>
              <Card>
                <CardHeader><CardTitle className="text-base">فرص Upsell</CardTitle></CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {upsellOpportunities.map(u => (
                      <div key={u.customer} className="p-2 rounded-lg border border-border bg-surface/50">
                        <div className="flex justify-between"><span className="text-sm font-medium">{u.customer}</span><Badge variant="success">+{u.value}K</Badge></div>
                        <p className="text-[10px] text-muted mt-1">الحالي: {u.current} → الفرصة: {u.opportunity}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div {...fadeUp} transition={{ delay: 0.25 }}>
              <Card>
                <CardHeader><CardTitle className="text-base">توصيات التوسع</CardTitle></CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {expansionRecommendations.map(e => (
                      <div key={e.city} className="p-2 rounded-lg border border-border bg-surface/50">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{e.city}</span>
                          <span className="text-xs text-muted">حجم السوق: {e.marketSize}M</span>
                        </div>
                        <div className="flex gap-3 mt-1 text-[10px]">
                          <span>المنافسة: {e.competition}</span>
                          <span className="text-green-600">ROI: {e.estimatedROI}%</span>
                          <span>التعادل: {e.breakeven}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-4 mt-4">
          <motion.div {...fadeUp}>
            <Card>
              <CardHeader><CardTitle className="text-base">مقاييس دقة النماذج</CardTitle></CardHeader>
              <CardContent>
                <div className="overflow-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="py-2 text-right">النموذج</th>
                        <th className="py-2 text-right">MAE</th>
                        <th className="py-2 text-right">RMSE</th>
                        <th className="py-2 text-right">الدقة %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {modelMetrics.map(m => (
                        <tr key={m.model} className="border-b border-border/50">
                          <td className="py-2 font-medium">{m.model}</td>
                          <td className="py-2">{m.mae}</td>
                          <td className="py-2">{m.rmse}</td>
                          <td className="py-2">
                            <div className="flex items-center gap-2">
                              <Progress value={m.accuracy} className="h-2 w-24" />
                              <span className="text-green-600 font-bold">{m.accuracy}%</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div {...fadeUp} transition={{ delay: 0.1 }}>
            <Card>
              <CardHeader><CardTitle className="text-base">التنبؤ vs الفعلي - الفروع</CardTitle></CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={branchForecast}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8e0" />
                    <XAxis dataKey="branch" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="actual" fill="#0a4a30" name="الفعلي" />
                    <Bar dataKey="forecast" fill="#daa520" name="التنبؤ" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
