# GFF ERP -- Enterprise Technical Architecture Document
## API Architecture | Database Schema | Security Architecture

---

**Document Control**

| Attribute           | Value                                          |
|---------------------|------------------------------------------------|
| Version             | 1.0.0                                          |
| Status              | Final                                          |
| Classification      | Confidential -- Internal Use Only              |
| Target Scale        | 1,000 branches | 1,000,000 customers | 10M txns/month |
| Reference Platforms | SAP S/4HANA 2023, Oracle Fusion ERP, D365 F&O  |
| Primary Market      | Egypt (Arab Republic of Egypt)                 |
| Compliance          | ETA E-Invoice, GAFI, CBE, Egyptian Tax Authority |

---

## Table of Contents

1. [Part I -- API Architecture](#part-i-api-architecture)
   - 1.1 API Design Principles & Standards
   - 1.2 Authentication API
   - 1.3 Users & Identity Management API
   - 1.4 Inventory Management API
   - 1.5 Sales Management API
   - 1.6 Purchase Management API
   - 1.7 Customer Relationship Management API
   - 1.8 Supplier Management API
   - 1.9 Accounting & Financial Management API
   - 1.10 Production Management API
   - 1.11 Feed Management API
   - 1.12 Livestock Management API
   - 1.13 Poultry Management API
   - 1.14 Egg Production & Distribution API
   - 1.15 Fleet Management API
   - 1.16 Delivery Management API
   - 1.17 Human Resources API
   - 1.18 Branch Management API
   - 1.19 Reports & Analytics API
   - 1.20 AI & Machine Learning API
   - 1.21 System Settings API
   - 1.22 WebSocket Real-Time API
   - 1.23 Webhook Integration API
   - 1.24 API Versioning Strategy
2. [Part II -- Database Schema](#part-ii-database-schema)
   - 2.1 Schema Design Principles
   - 2.2 Master Data Tables
   - 2.3 Transactional Tables
   - 2.4 Analytics Tables (Star Schema)
   - 2.5 Audit & Compliance Tables
   - 2.6 Indexing Strategy
   - 2.7 Partitioning Strategy
   - 2.8 Soft Delete & Versioning
3. [Part III -- Security Architecture](#part-iii-security-architecture)
   - 3.1 RBAC -- Role-Based Access Control
   - 3.2 ABAC -- Attribute-Based Access Control
   - 3.3 Multi-Factor Authentication (MFA)
   - 3.4 Single Sign-On (SSO)
   - 3.5 Encryption Architecture
   - 3.6 API Security
   - 3.7 Audit Logging & Non-Repudiation
   - 3.8 Fraud Detection & Prevention
   - 3.9 Data Privacy & Compliance

---

# Part I: API Architecture

## 1.1 API Design Principles & Standards

### RESTful Design Maturity
GFF ERP APIs conform to **Richardson Maturity Model Level 3** (HATEOAS-enabled where applicable), matching the API sophistication of SAP S/4HANA Cloud and Oracle REST API standards.

### Base Standards
| Standard        | Implementation                                          |
|-----------------|---------------------------------------------------------|
| Transport       | HTTPS only (TLS 1.3)                                    |
| Serialization   | JSON (RFC 8259), XML optional for legacy integrations   |
| Encoding        | UTF-8                                                   |
| Date/Time       | ISO 8601 (e.g., `2024-01-15T10:30:00+02:00`)            |
| Currency        | ISO 4217 (EGP, USD, EUR, SAR, AED)                      |
| Language        | `Accept-Language: ar-EG | en-US`                        |
| Pagination      | Cursor-based (primary) + Offset-based (legacy)          |
| Idempotency     | `Idempotency-Key` header for POST/PUT/PATCH              |
| Caching         | `ETag` + `If-None-Match`, `Cache-Control`               |

### HTTP Status Code Mapping
| Code | Meaning                  | Usage Pattern                              |
|------|--------------------------|--------------------------------------------|
| 200  | OK                       | Successful GET, PUT, PATCH                 |
| 201  | Created                  | Successful POST                            |
| 204  | No Content               | Successful DELETE                          |
| 400  | Bad Request              | Validation errors, malformed JSON          |
| 401  | Unauthorized             | Missing or invalid authentication          |
| 403  | Forbidden                | Valid auth but insufficient permissions    |
| 404  | Not Found                | Resource does not exist                    |
| 409  | Conflict                 | Business rule violation, duplicate data    |
| 422  | Unprocessable Entity     | Semantic validation failure                |
| 429  | Too Many Requests        | Rate limit exceeded                        |
| 500  | Internal Server Error    | Unhandled exception                        |
| 503  | Service Unavailable      | Maintenance mode, circuit breaker open     |

### Standard Error Response Schema
```json
{
  "error": {
    "code": "ERR_VALIDATION_001",
    "message": "One or more validation errors occurred",
    "target": "request_body",
    "details": [
      {
        "code": "FIELD_REQUIRED",
        "message": "Field 'branch_id' is required",
        "target": "branch_id"
      }
    ],
    "request_id": "req_8f3a2b1c4d5e",
    "timestamp": "2024-01-15T10:30:00+02:00",
    "documentation_url": "https://api.gff-erp.com/docs/errors/ERR_VALIDATION_001"
  }
}
```

### Pagination Response Schema
```json
{
  "data": [...],
  "pagination": {
    "cursor": "eyJpZCI6MTAwMCwiY3JlYXRlZF9hdCI6IjIwMjQtMDEtMTUifQ==",
    "next_cursor": "eyJpZCI6MTAyMCwiY3JlYXRlZF9hdCI6IjIwMjQtMDEtMTUifQ==",
    "prev_cursor": null,
    "limit": 20,
    "total_count": 15420,
    "has_more": true
  }
}
```

### Standard Headers
| Header                | Required | Description                              |
|-----------------------|----------|------------------------------------------|
| `Authorization`       | Yes*     | `Bearer <jwt_token>`                     |
| `X-API-Key`           | Yes*     | Client application API key               |
| `X-Request-ID`        | Yes      | Unique request identifier (UUID v4)      |
| `X-Tenant-ID`         | Yes      | Tenant/company identifier                |
| `X-Branch-ID`         | Conditional | Required for branch-scoped operations |
| `X-User-ID`           | Server   | Injected by gateway after auth           |
| `X-Client-Version`    | No       | Mobile/web client version                |
| `Accept-Language`     | No       | `ar-EG` (default) or `en-US`             |
| `Content-Type`        | Yes      | `application/json`                       |
| `Idempotency-Key`     | No       | UUID v4 for idempotent operations        |
| `If-Match`            | No       | ETag for optimistic concurrency          |

*One of `Authorization` or `X-API-Key` is required.

### Rate Limiting Tiers
| Tier       | Requests/Min | Requests/Hour | Burst | Scope         |
|------------|-------------|---------------|-------|---------------|
| Internal   | 10,000      | 500,000       | 1,000 | Service-to-service |
| Enterprise | 1,000       | 50,000        | 200   | ERP clients   |
| Partner    | 500         | 20,000        | 100   | Third-party integrations |
| Public     | 60          | 5,000         | 20    | Public APIs   |
| WebSocket  | 100 msg/s   | --            | 200   | Per connection |

---

## 1.2 Authentication API

### POST /api/v1/auth/login
User authentication with username/password.

**Request:**
```json
{
  "username": "string (3-50 chars)",
  "password": "string (min 8 chars)",
  "mfa_token": "string (6 digits, optional if MFA pending)",
  "device_info": {
    "device_id": "string (UUID)",
    "device_name": "string (e.g., 'iPhone 15 Pro')",
    "device_type": "string (enum: web | ios | android | desktop)",
    "os_version": "string",
    "app_version": "string",
    "ip_address": "string (auto-detected)"
  }
}
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "Bearer",
    "expires_in": 900,
    "expires_at": "2024-01-15T10:45:00+02:00",
    "user": {
      "id": "uuid",
      "username": "ahmed.hassan",
      "full_name_ar": "احمد حسن",
      "full_name_en": "Ahmed Hassan",
      "email": "ahmed.hassan@gff.com",
      "phone": "+201001234567",
      "branch_id": "uuid",
      "branch_name": "GFF Cairo HQ",
      "role": "branch_manager",
      "role_display": "مدير فرع",
      "permissions": ["inventory.read", "sales.write", "..."],
      "mfa_enabled": true,
      "mfa_required": false,
      "last_login": "2024-01-14T08:20:00+02:00",
      "password_expiry_days": 45
    },
    "requires_mfa": false,
    "requires_password_change": false
  }
}
```

**Response (202 - MFA Required):**
```json
{
  "success": false,
  "data": {
    "requires_mfa": true,
    "mfa_methods": ["totp", "sms"],
    "mfa_challenge_id": "uuid",
    "masked_phone": "+20*******567"
  }
}
```

**Error Codes:**
| Code | HTTP | Description |
|------|------|-------------|
| AUTH_001 | 401 | Invalid credentials |
| AUTH_002 | 401 | Account locked (5 failed attempts) |
| AUTH_003 | 401 | Account disabled |
| AUTH_004 | 401 | Password expired |
| AUTH_005 | 403 | IP not whitelisted |
| AUTH_006 | 429 | Too many login attempts |
| AUTH_007 | 400 | Invalid MFA token |
| AUTH_008 | 401 | Session expired |

**Permissions:** None (public endpoint)
**Rate Limit:** Public tier, 10 attempts/minute per IP

---

### POST /api/v1/auth/register
User registration (admin-invited or self-registration with approval).

**Request:**
```json
{
  "username": "string (3-50, alphanumeric_underscore)",
  "password": "string (min 8, requires uppercase+lowercase+digit+special)",
  "full_name_ar": "string (2-100 chars, Arabic)",
  "full_name_en": "string (2-100 chars, Latin)",
  "email": "string (valid email, unique)",
  "phone": "string (Egyptian format: +20XXXXXXXXXX)",
  "national_id": "string (14 digits, Egyptian National ID)",
  "branch_id": "uuid (optional, for branch-specific accounts)",
  "role_id": "uuid",
  "invite_token": "string (optional, for invited registrations)",
  "agreed_to_terms": true
}
```

**Response (201):**
```json
{
  "success": true,
  "data": {
    "user_id": "uuid",
    "status": "pending_approval",
    "message": "Registration submitted for approval"
  }
}
```

**Permissions:** None (public with invite) or `users.write` (admin-created)
**Rate Limit:** Public tier, 5 registrations/hour per IP

---

### POST /api/v1/auth/refresh
Refresh access token using refresh token.

**Request:**
```json
{
  "refresh_token": "string",
  "device_id": "string (UUID)"
}
```

**Response (200):**
```json
{
  "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "Bearer",
  "expires_in": 900
}
```

**Permissions:** Valid refresh token required
**Rate Limit:** Enterprise tier

---

### POST /api/v1/auth/logout
Invalidate current session/token.

**Request:**
```json
{
  "all_devices": false,
  "device_id": "string (UUID)"
}
```

**Response (204):** No content
**Headers:** `Authorization: Bearer <token>` required
**Rate Limit:** Enterprise tier

---

### POST /api/v1/auth/mfa/verify
Verify MFA token during login.

**Request:**
```json
{
  "challenge_id": "uuid",
  "mfa_code": "string (6 digits)",
  "method": "totp | sms | email | backup_code"
}
```

**Response (200):** Same as login success response

---

### POST /api/v1/auth/mfa/setup
Enable MFA for authenticated user.

**Request:**
```json
{
  "method": "totp | sms",
  "phone": "string (required if SMS)"
}
```

**Response (200):**
```json
{
  "secret": "JBSWY3DPEHPK3PXP",
  "qr_code_uri": "otpauth://totp/GFF:ahmed.hassan?secret=JBSWY3DPEHPK3PXP&issuer=GFF",
  "backup_codes": ["12345678", "87654321", "..."]
}
```

---

### POST /api/v1/auth/password-reset/request
Request password reset via email/SMS.

**Request:**
```json
{
  "identifier": "string (email or username)",
  "method": "email | sms"
}
```

**Response (200):**
```json
{
  "message": "Reset instructions sent",
  "masked_destination": "a***@gff.com"
}
```

---

### POST /api/v1/auth/password-reset/confirm
Confirm password reset with token.

**Request:**
```json
{
  "token": "string (UUID)",
  "new_password": "string (min 8)",
  "confirm_password": "string"
}
```

**Response (200):** Password reset confirmation

---

### POST /api/v1/auth/password-change
Change password for authenticated user.

**Request:**
```json
{
  "current_password": "string",
  "new_password": "string (min 8)",
  "confirm_password": "string"
}
```

**Headers:** `Authorization: Bearer <token>`
**Response (200):** Success confirmation

---

### GET /api/v1/auth/sessions
List active sessions for current user.

**Response (200):**
```json
{
  "data": [
    {
      "session_id": "uuid",
      "device_name": "Chrome on Windows",
      "ip_address": "156.204.XX.XX",
      "location": "Cairo, Egypt",
      "created_at": "2024-01-15T08:00:00+02:00",
      "last_active": "2024-01-15T10:30:00+02:00",
      "is_current": true
    }
  ]
}
```

---

### DELETE /api/v1/auth/sessions/{session_id}
Terminate a specific session.

**Response (204):** No content
**Permissions:** Own sessions, or `users.admin` for any session

---

## 1.3 Users & Identity Management API

### GET /api/v1/users
List all users with filtering and pagination.

**Query Parameters:**
| Parameter    | Type   | Description                              |
|--------------|--------|------------------------------------------|
| search       | string | Full-text search on name, email, phone   |
| branch_id    | uuid   | Filter by branch                         |
| role         | string | Filter by role slug                      |
| status       | enum   | `active`, `inactive`, `pending`, `locked` |
| is_online    | bool   | Filter by online status                  |
| created_from | date   | Registration date range start            |
| created_to   | date   | Registration date range end              |
| sort         | string | `created_at`, `full_name`, `last_login`   |
| order        | enum   | `asc`, `desc` (default: desc)            |
| cursor       | string | Pagination cursor                        |
| limit        | int    | 1-100 (default: 20)                      |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "username": "ahmed.hassan",
      "full_name_ar": "احمد حسن",
      "full_name_en": "Ahmed Hassan",
      "email": "ahmed.hassan@gff.com",
      "phone": "+201001234567",
      "national_id": "2850405010XXXXX",
      "avatar_url": "https://cdn.gff-erp.com/avatars/uuid.jpg",
      "branch_id": "uuid",
      "branch_name": "GFF Cairo HQ",
      "role_id": "uuid",
      "role_name": "Branch Manager",
      "role_slug": "branch_manager",
      "status": "active",
      "is_online": true,
      "mfa_enabled": true,
      "last_login": "2024-01-15T10:30:00+02:00",
      "login_count": 342,
      "created_at": "2023-06-01T09:00:00+02:00",
      "updated_at": "2024-01-15T10:30:00+02:00",
      "created_by": "uuid",
      "permissions_count": 47
    }
  ],
  "pagination": { ... }
}
```

**Permissions:** `users.read`
**Rate Limit:** Enterprise tier

---

### GET /api/v1/users/{id}
Get single user by ID.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "username": "ahmed.hassan",
    "full_name_ar": "احمد حسن",
    "full_name_en": "Ahmed Hassan",
    "email": "ahmed.hassan@gff.com",
    "phone": "+201001234567",
    "national_id": "2850405010XXXXX",
    "date_of_birth": "1985-04-05",
    "gender": "male",
    "address": "15 El-Tahrir St., Dokki, Giza",
    "emergency_contact": "+201098765432",
    "avatar_url": "https://cdn.gff-erp.com/avatars/uuid.jpg",
    "branch_id": "uuid",
    "branch_name": "GFF Cairo HQ",
    "department_id": "uuid",
    "department_name": "Operations",
    "role_id": "uuid",
    "role": {
      "id": "uuid",
      "name_ar": "مدير فرع",
      "name_en": "Branch Manager",
      "slug": "branch_manager",
      "level": 4,
      "permissions": ["inventory.read", "sales.write", "..."]
    },
    "custom_permissions": ["reports.executive"],
    "restricted_permissions": [],
    "status": "active",
    "mfa_enabled": true,
    "mfa_methods": ["totp"],
    "preferences": {
      "language": "ar-EG",
      "timezone": "Africa/Cairo",
      "date_format": "DD/MM/YYYY",
      "number_format": "ar-EG",
      "theme": "light",
      "notifications": {
        "email": true,
        "sms": false,
        "push": true,
        "desktop": true
      }
    },
    "last_login": "2024-01-15T10:30:00+02:00",
    "login_history": {
      "total_logins": 342,
      "failed_attempts_today": 0,
      "last_password_change": "2023-12-01T00:00:00+02:00",
      "password_expires_at": "2024-03-01T00:00:00+02:00"
    },
    "created_at": "2023-06-01T09:00:00+02:00",
    "updated_at": "2024-01-15T10:30:00+02:00",
    "created_by": { "id": "uuid", "name": "System Admin" },
    "updated_by": { "id": "uuid", "name": "HR Manager" }
  }
}
```

**Permissions:** `users.read` (own profile), `users.read.all` (any user)

---

### POST /api/v1/users
Create new user.

**Request:**
```json
{
  "username": "string",
  "password": "string",
  "full_name_ar": "string",
  "full_name_en": "string",
  "email": "string",
  "phone": "string",
  "national_id": "string",
  "date_of_birth": "date (optional)",
  "gender": "male | female (optional)",
  "address": "string (optional)",
  "branch_id": "uuid",
  "department_id": "uuid (optional)",
  "role_id": "uuid",
  "custom_permissions": ["string"] (optional),
  "restricted_permissions": ["string"] (optional),
  "send_welcome_email": true,
  "require_password_change_on_first_login": true
}
```

**Response (201):** Created user object
**Permissions:** `users.write`

---

### PUT /api/v1/users/{id}
Full update of user.

**Request:** Same as POST with all fields.
**Response (200):** Updated user object
**Permissions:** `users.write` (own profile), `users.write.all`

---

### PATCH /api/v1/users/{id}
Partial update of user.

**Request:** Any subset of user fields.
**Response (200):** Updated user object
**Permissions:** `users.write`

---

### DELETE /api/v1/users/{id}
Soft-delete user.

**Response (204):** No content
**Permissions:** `users.delete`

---

### PUT /api/v1/users/{id}/status
Change user status.

**Request:**
```json
{
  "status": "active | inactive | locked | pending",
  "reason": "string (required for lock/inactive)"
}
```

**Response (200):** Updated user
**Permissions:** `users.status.manage`

---

### GET /api/v1/users/{id}/permissions
Get effective permissions for user.

**Response (200):**
```json
{
  "data": {
    "user_id": "uuid",
    "role_permissions": ["inventory.read", "sales.write"],
    "custom_permissions": ["reports.executive"],
    "restricted_permissions": [],
    "effective_permissions": ["inventory.read", "sales.write", "reports.executive"],
    "branch_scope": ["branch_uuid_1", "branch_uuid_2"],
    "data_scope": "own | branch | region | all"
  }
}
```

**Permissions:** `permissions.read` or own permissions

---

### PUT /api/v1/users/{id}/permissions
Update custom permissions for user.

**Request:**
```json
{
  "add_permissions": ["reports.executive"],
  "remove_permissions": ["inventory.delete"],
  "data_scope": "own | branch | region | all"
}
```

**Permissions:** `permissions.write`

---

### GET /api/v1/roles
List all roles.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "name_ar": "مدير فرع",
      "name_en": "Branch Manager",
      "slug": "branch_manager",
      "description": "Full branch management authority",
      "level": 4,
      "is_system": true,
      "permissions_count": 47,
      "users_count": 156,
      "created_at": "2023-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `roles.read`

---

### GET /api/v1/roles/{id}
Get role details with permissions.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "name_ar": "مدير فرع",
    "name_en": "Branch Manager",
    "slug": "branch_manager",
    "description": "Full branch management authority",
    "level": 4,
    "is_system": true,
    "permissions": [
      {
        "id": "uuid",
        "module": "inventory",
        "action": "read",
        "resource": "all",
        "display_name": "View Inventory",
        "description": "Can view inventory across assigned branches"
      }
    ],
    "created_at": "2023-01-01T00:00:00+02:00",
    "updated_at": "2024-01-15T00:00:00+02:00"
  }
}
```

---

### POST /api/v1/roles
Create new role.

**Request:**
```json
{
  "name_ar": "string",
  "name_en": "string",
  "slug": "string",
  "description": "string",
  "level": 1-9,
  "permission_ids": ["uuid"],
  "copy_from_role_id": "uuid (optional)"
}
```

**Response (201):** Created role
**Permissions:** `roles.write`

---

### PUT /api/v1/roles/{id}
Update role.

**Response (200):** Updated role
**Permissions:** `roles.write`

---

### DELETE /api/v1/roles/{id}
Delete role (only if no users assigned).

**Response (204):** No content
**Permissions:** `roles.delete`

---

### GET /api/v1/permissions
List all available permissions.

**Query Parameters:**
| Parameter | Type   | Description              |
|-----------|--------|--------------------------|
| module    | string | Filter by module name    |
| action    | string | Filter by action type    |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "module": "inventory",
      "action": "read",
      "resource": "all",
      "slug": "inventory.read",
      "display_name_ar": "عرض المخزون",
      "display_name_en": "View Inventory",
      "description": "Can view inventory records",
      "module_display": "Inventory Management",
      "category": "operational"
    }
  ]
}
```

**Permissions:** `permissions.read`

---

## 1.4 Inventory Management API

### GET /api/v1/inventory/products
List products with filters.

**Query Parameters:**
| Parameter      | Type   | Description                                  |
|----------------|--------|----------------------------------------------|
| search         | string | Search by name, SKU, barcode                 |
| category_id    | uuid   | Filter by category                           |
| status         | enum   | `active`, `inactive`, `discontinued`         |
| stock_status   | enum   | `in_stock`, `low_stock`, `out_of_stock`      |
| branch_id      | uuid   | Filter by branch stock                       |
| warehouse_id   | uuid   | Filter by warehouse                          |
| supplier_id    | uuid   | Filter by supplier                           |
| min_price      | decimal| Minimum unit price                           |
| max_price      | decimal| Maximum unit price                           |
| has_batch      | bool   | Has batch tracking                           |
| sort           | string | `name`, `sku`, `created_at`, `current_stock`  |
| cursor/limit   | --     | Pagination                                   |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "sku": "FEED-BR-25KG",
      "barcode": "6223000123456",
      "name_ar": "علف بادي 25 كجم",
      "name_en": "Broiler Feed 25kg",
      "description": "Premium broiler starter feed",
      "category_id": "uuid",
      "category_name": "Broiler Feed",
      "subcategory_id": "uuid",
      "unit_of_measure_id": "uuid",
      "unit_name": "Bag",
      "secondary_unit": "kg",
      "conversion_factor": 25.0,
      "cost_method": "fifo | weighted_average | lifo",
      "current_cost": 285.50,
      "sale_price": 320.00,
      "min_sale_price": 300.00,
      "max_discount_pct": 10.0,
      "is_active": true,
      "is_sellable": true,
      "is_purchasable": true,
      "is_producible": false,
      "track_inventory": true,
      "reorder_point": 100,
      "reorder_quantity": 500,
      "has_batch_tracking": true,
      "has_expiry": true,
      "shelf_life_days": 90,
      "weight_kg": 25.0,
      "dimensions": {"length": 60, "width": 40, "height": 15},
      "tax_code_id": "uuid",
      "tax_rate": 14.0,
      "images": ["https://cdn.gff-erp.com/products/uuid1.jpg"],
      "stock_summary": {
        "total_quantity": 12500,
        "reserved_quantity": 800,
        "available_quantity": 11700,
        "branches": [
          {"branch_id": "uuid", "branch_name": "Cairo", "quantity": 5000}
        ]
      },
      "suppliers": [
        {"supplier_id": "uuid", "supplier_name": "Supplier Co.", "supplier_sku": "SUP-FEED-01"}
      ],
      "created_at": "2023-01-01T00:00:00+02:00",
      "updated_at": "2024-01-15T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `inventory.read`

---

### GET /api/v1/inventory/products/{id}
Get product detail.

**Response (200):** Full product object with stock history, suppliers, formulations.
**Permissions:** `inventory.read`

---

### POST /api/v1/inventory/products
Create product.

**Request:**
```json
{
  "sku": "string (unique, 3-50)",
  "barcode": "string (EAN-13, optional)",
  "name_ar": "string (required, Arabic)",
  "name_en": "string (required, English)",
  "description": "string (optional)",
  "category_id": "uuid",
  "unit_of_measure_id": "uuid",
  "cost_method": "fifo | weighted_average | lifo",
  "sale_price": "decimal (>= 0)",
  "min_sale_price": "decimal (optional)",
  "max_discount_pct": "decimal (0-100, default: 0)",
  "is_sellable": true,
  "is_purchasable": true,
  "is_producible": false,
  "track_inventory": true,
  "reorder_point": "integer (default: 0)",
  "reorder_quantity": "integer (default: 0)",
  "has_batch_tracking": false,
  "has_expiry": false,
  "shelf_life_days": "integer (optional)",
  "weight_kg": "decimal (optional)",
  "dimensions": {"length": 0, "width": 0, "height": 0},
  "tax_code_id": "uuid (optional)",
  "images": ["url"]
}
```

**Response (201):** Created product
**Permissions:** `inventory.write`

---

### PUT /api/v1/inventory/products/{id}
Full update product.
**Response (200):** Updated product
**Permissions:** `inventory.write`

---

### PATCH /api/v1/inventory/products/{id}
Partial update product.
**Response (200):** Updated product
**Permissions:** `inventory.write`

---

### DELETE /api/v1/inventory/products/{id}
Soft-delete product (only if no transactions).
**Response (204):** No content
**Permissions:** `inventory.delete`

---

### GET /api/v1/inventory/warehouses
List warehouses.

**Query Parameters:**
| Parameter  | Type | Description              |
|------------|------|--------------------------|
| branch_id  | uuid | Filter by branch         |
| status     | enum | `active`, `inactive`     |
| type       | enum | `main`, `secondary`, `cold`, `feed`, `livestock` |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "code": "WH-CAI-01",
      "name_ar": "مخزن القاهرة الرئيسي",
      "name_en": "Cairo Main Warehouse",
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "type": "main",
      "address": "15 Industrial Zone, Cairo",
      "manager_id": "uuid",
      "manager_name": "Mohamed Ali",
      "capacity_sqm": 5000,
      "is_active": true,
      "zones": [
        {
          "id": "uuid",
          "code": "A-01",
          "name": "Feed Storage A",
          "zone_type": "ambient"
        }
      ],
      "current_utilization_pct": 72.5,
      "created_at": "2023-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `inventory.read`

---

### POST /api/v1/inventory/warehouses
Create warehouse.

**Request:**
```json
{
  "code": "string (unique)",
  "name_ar": "string",
  "name_en": "string",
  "branch_id": "uuid",
  "type": "main | secondary | cold | feed | livestock",
  "address": "string",
  "manager_id": "uuid (optional)",
  "capacity_sqm": "integer (optional)",
  "zones": [
    {
      "code": "string",
      "name": "string",
      "zone_type": "ambient | cold | frozen | quarantine"
    }
  ]
}
```

**Response (201):** Created warehouse
**Permissions:** `inventory.warehouse.manage`

---

### GET /api/v1/inventory/stock
Get current stock levels.

**Query Parameters:**
| Parameter    | Type   | Description                       |
|--------------|--------|-----------------------------------|
| product_id   | uuid   | Filter by product                 |
| warehouse_id | uuid   | Filter by warehouse               |
| branch_id    | uuid   | Filter by branch                  |
| batch_number | string | Filter by batch                   |
| status       | enum   | `available`, `reserved`, `quarantine`, `expired` |
| low_stock    | bool   | Show only low stock items         |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "product_id": "uuid",
      "product_name": "Broiler Feed 25kg",
      "sku": "FEED-BR-25KG",
      "warehouse_id": "uuid",
      "warehouse_name": "Cairo Main",
      "zone_id": "uuid",
      "zone_code": "A-01",
      "batch_number": "LOT-2024-001",
      "expiry_date": "2024-04-15",
      "quantity_on_hand": 500,
      "quantity_reserved": 50,
      "quantity_available": 450,
      "quantity_on_order": 200,
      "unit_cost": 285.50,
      "total_value": 142750.00,
      "stock_age_days": 15,
      "status": "available",
      "last_movement_date": "2024-01-14T08:30:00+02:00"
    }
  ]
}
```

**Permissions:** `inventory.read`

---

### POST /api/v1/inventory/stock-movements
Record stock movement.

**Request:**
```json
{
  "movement_type": "receipt | issue | transfer | adjustment | return | production | waste",
  "reference_type": "purchase_order | sales_invoice | transfer_order | adjustment | production_order",
  "reference_id": "uuid (optional)",
  "reference_number": "string (optional)",
  "source_warehouse_id": "uuid (required for issue/transfer)",
  "destination_warehouse_id": "uuid (required for receipt/transfer)",
  "movement_date": "datetime (default: now)",
  "lines": [
    {
      "product_id": "uuid",
      "batch_number": "string (optional)",
      "expiry_date": "date (optional)",
      "quantity": "decimal (positive for receipt, negative for issue)",
      "unit_cost": "decimal (optional, for valuation)",
      "unit_of_measure_id": "uuid",
      "notes": "string (optional)"
    }
  ],
  "notes": "string (optional)",
  "attachments": ["url"]
}
```

**Response (201):**
```json
{
  "data": {
    "movement_id": "uuid",
    "movement_number": "SM-2024-0001542",
    "status": "posted",
    "lines_count": 5,
    "total_items": 150,
    "posted_at": "2024-01-15T10:30:00+02:00"
  }
}
```

**Permissions:** `inventory.stock.move`

---

### GET /api/v1/inventory/stock-movements
List stock movements.

**Query Parameters:**
| Parameter      | Type   | Description                          |
|----------------|--------|--------------------------------------|
| movement_type  | enum   | Filter by type                       |
| product_id     | uuid   | Filter by product                    |
| warehouse_id   | uuid   | Filter by warehouse                  |
| date_from      | date   | Date range                           |
| date_to        | date   | Date range                           |
| reference_type | string | Filter by reference                  |

**Response (200):** Paginated list of movements
**Permissions:** `inventory.read`

---

### POST /api/v1/inventory/transfers
Create stock transfer between warehouses.

**Request:**
```json
{
  "from_warehouse_id": "uuid",
  "to_warehouse_id": "uuid",
  "transfer_date": "datetime",
  "requested_by": "uuid",
  "lines": [
    {
      "product_id": "uuid",
      "quantity": "decimal",
      "batch_number": "string (optional)",
      "notes": "string"
    }
  ],
  "notes": "string",
  "priority": "normal | urgent | emergency"
}
```

**Response (201):**
```json
{
  "data": {
    "transfer_id": "uuid",
    "transfer_number": "ST-2024-000892",
    "status": "pending_approval",
    "from_warehouse": "Cairo Main",
    "to_warehouse": "Giza Branch",
    "lines_count": 3,
    "total_items": 150
  }
}
```

**Permissions:** `inventory.transfer.create`

---

### PUT /api/v1/inventory/transfers/{id}/approve
Approve transfer.
**Response (200):** Transfer with updated status
**Permissions:** `inventory.transfer.approve`

---

### PUT /api/v1/inventory/transfers/{id}/ship
Mark transfer as shipped.
**Response (200):** Updated transfer
**Permissions:** `inventory.transfer.execute`

---

### PUT /api/v1/inventory/transfers/{id}/receive
Receive transfer at destination.

**Request:**
```json
{
  "received_lines": [
    {
      "line_id": "uuid",
      "received_quantity": "decimal",
      "condition": "good | damaged | rejected",
      "notes": "string"
    }
  ]
}
```

**Response (200):** Updated transfer
**Permissions:** `inventory.transfer.receive`

---

### GET /api/v1/inventory/transfers
List transfers.
**Query Parameters:** from_warehouse_id, to_warehouse_id, status, date_from, date_to
**Response (200):** Paginated transfers
**Permissions:** `inventory.read`

---

### POST /api/v1/inventory/adjustments
Create stock adjustment.

**Request:**
```json
{
  "warehouse_id": "uuid",
  "adjustment_type": "count | damage | expiry | theft | system_correction | other",
  "adjustment_date": "datetime",
  "reference_number": "string (optional)",
  "lines": [
    {
      "product_id": "uuid",
      "batch_number": "string (optional)",
      "book_quantity": "decimal",
      "actual_quantity": "decimal",
      "difference": "decimal (computed: actual - book)",
      "unit_cost": "decimal",
      "reason": "string",
      "notes": "string"
    }
  ],
  "total_adjustment_value": "decimal",
  "notes": "string",
  "requires_approval": true
}
```

**Response (201):** Created adjustment
**Permissions:** `inventory.adjustment.create`

---

### POST /api/v1/inventory/audits
Create physical audit/stock count.

**Request:**
```json
{
  "warehouse_id": "uuid",
  "audit_type": "full | cycle | spot",
  "scheduled_date": "datetime",
  "auditor_ids": ["uuid"],
  "product_filter": {
    "category_ids": ["uuid"],
    "location_zone": "string"
  },
  "notes": "string"
}
```

**Response (201):** Created audit
**Permissions:** `inventory.audit.create`

---

### GET /api/v1/inventory/audits/{id}
Get audit details with count sheets.
**Response (200):** Full audit object
**Permissions:** `inventory.read`

---

### PUT /api/v1/inventory/audits/{id}/counts
Submit count results.

**Request:**
```json
{
  "counts": [
    {
      "audit_line_id": "uuid",
      "counted_quantity": "decimal",
      "counted_by": "uuid",
      "counted_at": "datetime",
      "notes": "string"
    }
  ]
}
```

**Permissions:** `inventory.audit.execute`

---

### PUT /api/v1/inventory/audits/{id}/complete
Complete audit and generate adjustments.
**Response (200):** Audit completion summary
**Permissions:** `inventory.audit.complete`

---

### GET /api/v1/inventory/categories
List product categories (tree structure).

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "name_ar": "أعلاف",
      "name_en": "Feed",
      "parent_id": null,
      "level": 0,
      "path": "/FEED",
      "children": [
        {
          "id": "uuid",
          "name_ar": "علف بادي",
          "name_en": "Broiler Feed",
          "parent_id": "uuid",
          "level": 1,
          "path": "/FEED/BROILER",
          "product_count": 12
        }
      ],
      "product_count": 45
    }
  ]
}
```

**Permissions:** `inventory.read`

---

### POST /api/v1/inventory/categories
Create category.

**Request:**
```json
{
  "name_ar": "string",
  "name_en": "string",
  "parent_id": "uuid (optional, for subcategories)",
  "description": "string",
  "sort_order": "integer"
}
```

**Response (201):** Created category
**Permissions:** `inventory.category.manage`

---

### GET /api/v1/inventory/units-of-measure
List units of measure.
**Permissions:** `inventory.read`

### POST /api/v1/inventory/units-of-measure
Create UOM.

**Request:**
```json
{
  "code": "string (unique)",
  "name_ar": "string",
  "name_en": "string",
  "type": "weight | volume | count | length | area | time | pack",
  "base_unit_id": "uuid (optional, for derived units)",
  "conversion_factor": "decimal (to base unit)",
  "is_base_unit": false
}
```

**Permissions:** `inventory.uom.manage`

---

## 1.5 Sales Management API

### GET /api/v1/sales/invoices
List sales invoices.

**Query Parameters:**
| Parameter      | Type   | Description                                 |
|----------------|--------|---------------------------------------------|
| search         | string | Invoice number, customer name               |
| customer_id    | uuid   | Filter by customer                          |
| branch_id      | uuid   | Filter by branch                            |
| status         | enum   | `draft`, `confirmed`, `shipped`, `delivered`, `paid`, `cancelled`, `returned` |
| payment_status | enum   | `unpaid`, `partial`, `paid`, `overpaid`     |
| date_from      | date   | Issue date range                            |
| date_to        | date   | Issue date range                            |
| min_amount     | decimal| Minimum total amount                        |
| max_amount     | decimal| Maximum total amount                        |
| sales_rep_id   | uuid   | Filter by sales representative              |
| channel        | enum   | `branch`, `phone`, `online`, `field`, `b2b` |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "invoice_number": "SI-CAI-2024-001542",
      "series": "CAI-A",
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "customer_id": "uuid",
      "customer_name": "Al-Amal Poultry Farm",
      "customer_code": "C-10456",
      "sales_rep_id": "uuid",
      "sales_rep_name": "Khaled Mahmoud",
      "issue_date": "2024-01-15",
      "due_date": "2024-02-14",
      "delivery_date": "2024-01-16",
      "channel": "branch",
      "status": "confirmed",
      "payment_status": "unpaid",
      "payment_terms": "net_30",
      "currency": "EGP",
      "exchange_rate": 1.0,
      "subtotal": 25000.00,
      "discount_amount": 500.00,
      "discount_pct": 2.0,
      "tax_amount": 3430.00,
      "tax_breakdown": [
        {"tax_code": "VAT-14", "rate": 14.0, "amount": 3430.00}
      ],
      "shipping_amount": 250.00,
      "total_amount": 28180.00,
      "paid_amount": 0.00,
      "balance_due": 28180.00,
      "notes": "Deliver to farm gate",
      "terms": "Payment due within 30 days",
      "is_e_invoiced": true,
      "e_invoice_uuid": "uuid",
      "e_invoice_status": "submitted",
      "created_by": "uuid",
      "created_at": "2024-01-15T09:00:00+02:00",
      "updated_at": "2024-01-15T09:00:00+02:00"
    }
  ]
}
```

**Permissions:** `sales.read` (own sales), `sales.read.all` (all invoices)

---

### GET /api/v1/sales/invoices/{id}
Get invoice with lines.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "invoice_number": "SI-CAI-2024-001542",
    ...,
    "lines": [
      {
        "id": "uuid",
        "line_number": 1,
        "product_id": "uuid",
        "product_name": "Broiler Feed 25kg",
        "product_sku": "FEED-BR-25KG",
        "description": "Broiler Feed 25kg - Batch LOT-2024-001",
        "quantity": 100,
        "unit_of_measure": "Bag",
        "unit_price": 250.00,
        "discount_pct": 2.0,
        "discount_amount": 500.00,
        "net_price": 245.00,
        "tax_code_id": "uuid",
        "tax_rate": 14.0,
        "tax_amount": 3430.00,
        "line_total": 27930.00,
        "cost_price": 220.00,
        "profit_amount": 2500.00,
        "profit_margin_pct": 10.0,
        "warehouse_id": "uuid",
        "batch_number": "LOT-2024-001",
        "notes": ""
      }
    ],
    "payments": [],
    "returns": [],
    "delivery": null
  }
}
```

**Permissions:** `sales.read`

---

### POST /api/v1/sales/invoices
Create sales invoice.

**Request:**
```json
{
  "branch_id": "uuid",
  "customer_id": "uuid",
  "sales_rep_id": "uuid (optional)",
  "issue_date": "date (default: today)",
  "due_date": "date",
  "delivery_date": "date (optional)",
  "channel": "branch | phone | online | field | b2b",
  "payment_terms": "cash | net_7 | net_15 | net_30 | net_60 | custom",
  "currency": "EGP (default)",
  "exchange_rate": "decimal (default: 1.0)",
  "discount_pct": "decimal (0-100, applied to subtotal)",
  "discount_amount": "decimal",
  "shipping_amount": "decimal",
  "notes": "string",
  "terms": "string",
  "lines": [
    {
      "product_id": "uuid",
      "description": "string (optional, overrides product name)",
      "quantity": "decimal (> 0)",
      "unit_of_measure_id": "uuid",
      "unit_price": "decimal (>= 0)",
      "discount_pct": "decimal (0-100)",
      "tax_code_id": "uuid",
      "warehouse_id": "uuid",
      "batch_number": "string (optional)",
      "notes": "string"
    }
  ]
}
```

**Response (201):** Created invoice with calculated totals
**Permissions:** `sales.write`

---

### PUT /api/v1/sales/invoices/{id}
Update draft invoice.
**Response (200):** Updated invoice
**Permissions:** `sales.write`

---

### PUT /api/v1/sales/invoices/{id}/confirm
Confirm invoice (changes status from draft).
**Response (200):** Confirmed invoice
**Permissions:** `sales.confirm`

---

### PUT /api/v1/sales/invoices/{id}/cancel
Cancel invoice.

**Request:**
```json
{
  "reason": "string (required)",
  "cancellation_type": "full | partial"
}
```

**Response (200):** Cancelled invoice
**Permissions:** `sales.cancel`

---

### POST /api/v1/sales/invoices/{id}/payments
Record payment against invoice.

**Request:**
```json
{
  "payment_method": "cash | bank_transfer | cheque | credit_card | wallet",
  "amount": "decimal (> 0)",
  "payment_date": "datetime",
  "reference_number": "string (cheque number, transfer ref)",
  "bank_account_id": "uuid (for bank payments)",
  "cash_account_id": "uuid (for cash payments)",
  "notes": "string",
  "attachments": ["url"]
}
```

**Response (201):** Payment record
**Permissions:** `payments.receive`

---

### GET /api/v1/sales/returns
List sales returns.
**Permissions:** `sales.read`

### POST /api/v1/sales/returns
Create sales return.

**Request:**
```json
{
  "original_invoice_id": "uuid",
  "branch_id": "uuid",
  "customer_id": "uuid",
  "return_date": "date",
  "return_reason": "damaged | wrong_item | quality_issue | expired | customer_request | other",
  "notes": "string",
  "lines": [
    {
      "original_line_id": "uuid",
      "product_id": "uuid",
      "quantity": "decimal (> 0)",
      "unit_price": "decimal",
      "condition": "good | damaged | expired | unopened",
      "restock": true,
      "restock_warehouse_id": "uuid",
      "notes": "string"
    }
  ]
}
```

**Response (201):** Created return
**Permissions:** `sales.returns.write`

---

### GET /api/v1/sales/quotes
List quotes.
**Query Parameters:** customer_id, branch_id, status, expiry_from, expiry_to
**Permissions:** `sales.read`

### POST /api/v1/sales/quotes
Create quote.

**Request:**
```json
{
  "branch_id": "uuid",
  "customer_id": "uuid",
  "sales_rep_id": "uuid",
  "quote_date": "date",
  "expiry_date": "date",
  "currency": "EGP",
  "lines": [
    {
      "product_id": "uuid",
      "quantity": "decimal",
      "unit_price": "decimal",
      "discount_pct": "decimal",
      "notes": "string"
    }
  ],
  "notes": "string",
  "terms": "string"
}
```

**Response (201):** Created quote
**Permissions:** `sales.quotes.write`

---

### PUT /api/v1/sales/quotes/{id}/convert
Convert quote to invoice.
**Response (201):** Created invoice from quote
**Permissions:** `sales.write`

---

### GET /api/v1/sales/orders
List sales orders.
**Permissions:** `sales.read`

### POST /api/v1/sales/orders
Create sales order.

**Request:**
```json
{
  "branch_id": "uuid",
  "customer_id": "uuid",
  "sales_rep_id": "uuid",
  "order_date": "date",
  "required_date": "date",
  "shipping_address": "string",
  "shipping_method": "pickup | delivery | third_party",
  "priority": "normal | high | urgent",
  "lines": [
    {
      "product_id": "uuid",
      "quantity": "decimal",
      "unit_price": "decimal",
      "discount_pct": "decimal",
      "notes": "string"
    }
  ],
  "notes": "string"
}
```

**Response (201):** Created order
**Permissions:** `sales.orders.write`

---

### PUT /api/v1/sales/orders/{id}/fulfill
Fulfill order (create invoice).
**Response (201):** Created invoice
**Permissions:** `sales.fulfill`

---

### GET /api/v1/sales/channels
List sales channels performance.
**Response (200):** Channel analytics
**Permissions:** `sales.read`

### GET /api/v1/sales/dashboard
Sales dashboard KPIs.
**Response (200):**
```json
{
  "data": {
    "period": "2024-01-01 to 2024-01-15",
    "total_sales": 2850000.00,
    "total_invoices": 1250,
    "average_invoice_value": 2280.00,
    "total_returns": 45000.00,
    "return_rate_pct": 1.58,
    "outstanding_receivables": 890000.00,
    "overdue_receivables": 125000.00,
    "sales_by_channel": [
      {"channel": "branch", "amount": 1800000},
      {"channel": "field", "amount": 750000},
      {"channel": "online", "amount": 300000}
    ],
    "top_products": [...],
    "top_customers": [...],
    "sales_trend": [
      {"date": "2024-01-01", "amount": 180000},
      {"date": "2024-01-02", "amount": 195000}
    ]
  }
}
```

**Permissions:** `sales.read` or `dashboard.view`

---

## 1.6 Purchase Management API

### GET /api/v1/purchases/orders
List purchase orders.

**Query Parameters:**
| Parameter    | Type   | Description                                  |
|--------------|--------|----------------------------------------------|
| search       | string | PO number, supplier name                     |
| supplier_id  | uuid   | Filter by supplier                           |
| branch_id    | uuid   | Filter by branch                             |
| status       | enum   | `draft`, `sent`, `partial`, `received`, `closed`, `cancelled` |
| date_from    | date   | Order date range                             |
| date_to      | date   | Order date range                             |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "po_number": "PO-CAI-2024-004521",
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "supplier_id": "uuid",
      "supplier_name": "Agricultural Inputs Co.",
      "supplier_code": "S-00123",
      "order_date": "2024-01-10",
      "expected_delivery": "2024-01-20",
      "status": "partial",
      "payment_terms": "net_30",
      "currency": "EGP",
      "subtotal": 500000.00,
      "tax_amount": 70000.00,
      "shipping_amount": 5000.00,
      "total_amount": 575000.00,
      "received_amount": 300000.00,
      "notes": "Urgent order for Q1",
      "created_by": "uuid",
      "created_at": "2024-01-10T08:00:00+02:00"
    }
  ]
}
```

**Permissions:** `purchases.read`

---

### GET /api/v1/purchases/orders/{id}
Get PO with lines and receipts.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "po_number": "PO-CAI-2024-004521",
    ...,
    "lines": [
      {
        "id": "uuid",
        "line_number": 1,
        "product_id": "uuid",
        "product_name": "Corn - Yellow #2",
        "description": "Yellow corn grade 2",
        "quantity_ordered": 5000,
        "quantity_received": 2500,
        "quantity_remaining": 2500,
        "unit_of_measure": "kg",
        "unit_price": 12.50,
        "discount_pct": 0,
        "tax_rate": 14.0,
        "line_total": 71250.00,
        "expected_delivery": "2024-01-20",
        "notes": ""
      }
    ],
    "grns": [
      {
        "grn_id": "uuid",
        "grn_number": "GRN-2024-002145",
        "received_date": "2024-01-15",
        "status": "posted",
        "total_amount": 300000.00
      }
    ]
  }
}
```

**Permissions:** `purchases.read`

---

### POST /api/v1/purchases/orders
Create purchase order.

**Request:**
```json
{
  "branch_id": "uuid",
  "supplier_id": "uuid",
  "order_date": "date (default: today)",
  "expected_delivery": "date",
  "payment_terms": "cash | net_7 | net_15 | net_30 | net_60 | custom",
  "currency": "EGP",
  "exchange_rate": 1.0,
  "shipping_amount": 0.00,
  "notes": "string",
  "lines": [
    {
      "product_id": "uuid",
      "description": "string (optional)",
      "quantity": "decimal (> 0)",
      "unit_of_measure_id": "uuid",
      "unit_price": "decimal (>= 0)",
      "discount_pct": "decimal",
      "tax_code_id": "uuid",
      "expected_delivery": "date (optional, per line)",
      "notes": "string"
    }
  ]
}
```

**Response (201):** Created PO
**Permissions:** `purchases.write`

---

### PUT /api/v1/purchases/orders/{id}
Update PO (only draft status).
**Permissions:** `purchases.write`

---

### PUT /api/v1/purchases/orders/{id}/send
Send PO to supplier.
**Response (200):** PO with sent status
**Permissions:** `purchases.send`

---

### PUT /api/v1/purchases/orders/{id}/cancel
Cancel PO.

**Request:**
```json
{
  "reason": "string (required)"
}
```

**Permissions:** `purchases.cancel`

---

### GET /api/v1/purchases/grns
List goods receipt notes.
**Permissions:** `purchases.read`

### POST /api/v1/purchases/grns
Create GRN.

**Request:**
```json
{
  "po_id": "uuid (optional)",
  "branch_id": "uuid",
  "supplier_id": "uuid",
  "warehouse_id": "uuid",
  "received_date": "datetime",
  "reference_number": "string (supplier delivery note)",
  "lines": [
    {
      "po_line_id": "uuid (optional, if from PO)",
      "product_id": "uuid",
      "description": "string",
      "quantity_received": "decimal (> 0)",
      "quantity_accepted": "decimal",
      "quantity_rejected": "decimal",
      "unit_of_measure_id": "uuid",
      "unit_price": "decimal",
      "batch_number": "string (optional)",
      "expiry_date": "date (optional)",
      "condition": "good | damaged | partial",
      "warehouse_zone_id": "uuid",
      "notes": "string"
    }
  ],
  "total_amount": "decimal",
  "notes": "string",
  "attachments": ["url"]
}
```

**Response (201):** Created GRN with updated PO status
**Permissions:** `purchases.receive`

---

### GET /api/v1/purchases/returns
List purchase returns.
**Permissions:** `purchases.read`

### POST /api/v1/purchases/returns
Create purchase return.

**Request:**
```json
{
  "grn_id": "uuid",
  "supplier_id": "uuid",
  "branch_id": "uuid",
  "return_date": "date",
  "return_reason": "damaged | wrong_item | quality_issue | expired | over_delivery | other",
  "credit_note_expected": true,
  "lines": [
    {
      "grn_line_id": "uuid",
      "product_id": "uuid",
      "quantity": "decimal",
      "unit_price": "decimal",
      "condition": "damaged | wrong | expired",
      "notes": "string"
    }
  ]
}
```

**Response (201):** Created return
**Permissions:** `purchases.returns.write`

---

### GET /api/v1/purchases/supplier-bills
List supplier bills/invoices.
**Permissions:** `purchases.read` or `accounting.read`

### POST /api/v1/purchases/supplier-bills
Create supplier bill.

**Request:**
```json
{
  "supplier_id": "uuid",
  "po_ids": ["uuid"],
  "grn_ids": ["uuid"],
  "bill_number": "string (supplier's invoice number)",
  "bill_date": "date",
  "due_date": "date",
  "currency": "EGP",
  "subtotal": "decimal",
  "tax_amount": "decimal",
  "total_amount": "decimal",
  "lines": [
    {
      "grn_line_id": "uuid",
      "product_id": "uuid",
      "quantity": "decimal",
      "unit_price": "decimal",
      "amount": "decimal"
    }
  ],
  "notes": "string",
  "attachments": ["url"]
}
```

**Response (201):** Created bill
**Permissions:** `purchases.bills.write`

---

### POST /api/v1/purchases/supplier-bills/{id}/payments
Record payment to supplier.

**Request:**
```json
{
  "payment_method": "bank_transfer | cheque | cash | credit",
  "amount": "decimal",
  "payment_date": "date",
  "reference_number": "string",
  "bank_account_id": "uuid",
  "notes": "string"
}
```

**Permissions:** `payments.send`

---

## 1.7 Customer Relationship Management API

### GET /api/v1/customers
List customers.

**Query Parameters:**
| Parameter       | Type   | Description                                |
|-----------------|--------|--------------------------------------------|
| search          | string | Name, phone, code, tax ID                  |
| category_id     | uuid   | Filter by category                         |
| classification  | enum   | `a`, `b`, `c`, `d` (ABC classification)    |
| branch_id       | uuid   | Filter by assigned branch                  |
| sales_rep_id    | uuid   | Filter by sales rep                        |
| status          | enum   | `active`, `inactive`, `suspended`, `blacklisted` |
| has_debt        | bool   | Has outstanding balance                    |
| min_balance     | decimal| Minimum balance                            |
| max_balance     | decimal| Maximum balance                            |
| created_from    | date   | Registration date range                    |
| sort            | string | `name`, `balance`, `last_purchase`, `created_at` |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "code": "C-10456",
      "name_ar": "مزرعة الأمل للدواجن",
      "name_en": "Al-Amal Poultry Farm",
      "trade_name": "Al-Amal Poultry",
      "category_id": "uuid",
      "category_name": "Commercial Farm",
      "classification": "a",
      "status": "active",
      "tax_id": "123456789",
      "tax_card_number": "987654321",
      "commercial_register": "56432",
      "contact_info": {
        "phone_primary": "+201001234567",
        "phone_secondary": "+201098765432",
        "email": "info@alamalpoultry.com",
        "website": "www.alamalpoultry.com"
      },
      "address": {
        "street": "El-Wahat Road, km 75",
        "city": "6th of October",
        "governorate": "Giza",
        "postal_code": "12566",
        "coordinates": {"lat": 29.976, "lng": 30.95}
      },
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "sales_rep_id": "uuid",
      "sales_rep_name": "Khaled Mahmoud",
      "credit_limit": 500000.00,
      "credit_days": 30,
      "current_balance": 125000.00,
      "total_sales_ytd": 2850000.00,
      "last_purchase_date": "2024-01-10",
      "payment_history": {
        "on_time_pct": 92.5,
        "average_payment_days": 25,
        "total_invoices": 145,
        "total_payments": 140
      },
      "custom_fields": {
        "farm_size": "50000 sqm",
        "bird_capacity": "100000",
        "feed_preference": "Broiler"
      },
      "created_at": "2022-03-15T10:00:00+02:00",
      "updated_at": "2024-01-15T08:00:00+02:00"
    }
  ]
}
```

**Permissions:** `customers.read`

---

### GET /api/v1/customers/{id}
Get customer detail.
**Response (200):** Full customer with contacts, interactions, sales history, debt aging.
**Permissions:** `customers.read`

---

### POST /api/v1/customers
Create customer.

**Request:**
```json
{
  "code": "string (auto-generated if omitted)",
  "name_ar": "string (required, Arabic)",
  "name_en": "string (required, English)",
  "trade_name": "string (optional)",
  "category_id": "uuid",
  "tax_id": "string (optional)",
  "tax_card_number": "string (optional)",
  "commercial_register": "string (optional)",
  "contact_info": {
    "phone_primary": "string (Egyptian format)",
    "phone_secondary": "string (optional)",
    "email": "string (optional)",
    "website": "string (optional)"
  },
  "address": {
    "street": "string",
    "city": "string",
    "governorate": "string",
    "postal_code": "string (optional)",
    "coordinates": {"lat": "decimal", "lng": "decimal"}
  },
  "branch_id": "uuid",
  "sales_rep_id": "uuid (optional)",
  "credit_limit": "decimal (default: 0)",
  "credit_days": "integer (default: 0)",
  "payment_terms": "cash | net_7 | net_15 | net_30 | net_60",
  "price_list_id": "uuid (optional)",
  "custom_fields": "object",
  "notes": "string"
}
```

**Response (201):** Created customer
**Permissions:** `customers.write`

---

### PUT /api/v1/customers/{id}
Update customer.
**Response (200):** Updated customer
**Permissions:** `customers.write`

---

### GET /api/v1/customers/{id}/interactions
List customer interactions.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "customer_id": "uuid",
      "interaction_type": "call | visit | email | meeting | complaint | follow_up | note",
      "direction": "outbound | inbound",
      "subject": "string",
      "content": "string",
      "outcome": "string",
      "follow_up_date": "date (optional)",
      "follow_up_completed": false,
      "performed_by_id": "uuid",
      "performed_by_name": "Khaled Mahmoud",
      "created_at": "2024-01-15T10:00:00+02:00"
    }
  ]
}
```

**Permissions:** `customers.read`

---

### POST /api/v1/customers/{id}/interactions
Add interaction.

**Request:**
```json
{
  "interaction_type": "call | visit | email | meeting | complaint | follow_up | note",
  "direction": "outbound | inbound",
  "subject": "string",
  "content": "string",
  "outcome": "string (optional)",
  "follow_up_date": "date (optional)",
  "attachments": ["url"]
}
```

**Response (201):** Created interaction
**Permissions:** `customers.interactions.write`

---

### GET /api/v1/customers/{id}/debt-aging
Get debt aging analysis.

**Response (200):**
```json
{
  "data": {
    "customer_id": "uuid",
    "total_outstanding": 125000.00,
    "not_yet_due": 80000.00,
    "days_1_30": 30000.00,
    "days_31_60": 10000.00,
    "days_61_90": 5000.00,
    "days_90_plus": 0.00,
    "invoices": [
      {
        "invoice_id": "uuid",
        "invoice_number": "SI-2024-001500",
        "amount": 50000.00,
        "due_date": "2024-02-14",
        "days_overdue": 0,
        "status": "current"
      }
    ]
  }
}
```

**Permissions:** `customers.read`, `accounting.read`

---

### GET /api/v1/customers/classifications
Get customer classification report.
**Response (200):** ABC analysis
**Permissions:** `customers.read`

---

### POST /api/v1/customers/{id}/classify
Manually classify customer.

**Request:**
```json
{
  "classification": "a | b | c | d",
  "reason": "string",
  "review_date": "date"
}
```

**Permissions:** `customers.classify`

---

### GET /api/v1/customers/categories
List customer categories.
**Permissions:** `customers.read`

### POST /api/v1/customers/categories
Create category.

**Request:**
```json
{
  "name_ar": "string",
  "name_en": "string",
  "description": "string",
  "parent_id": "uuid (optional)",
  "default_credit_limit": "decimal",
  "default_credit_days": "integer",
  "default_discount_pct": "decimal"
}
```

**Permissions:** `customers.category.manage`

---

## 1.8 Supplier Management API

### GET /api/v1/suppliers
List suppliers.

**Query Parameters:**
| Parameter       | Type   | Description                                |
|-----------------|--------|--------------------------------------------|
| search          | string | Name, phone, code                          |
| category_id     | uuid   | Filter by category                         |
| status          | enum   | `active`, `inactive`, `blacklisted`, `under_review` |
| rating_min      | int    | Minimum rating (1-5)                       |
| branch_id       | uuid   | Filter by branch                           |
| payment_terms   | string | Filter by terms                            |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "code": "S-00123",
      "name_ar": "شركة المدخلات الزراعية",
      "name_en": "Agricultural Inputs Co.",
      "trade_name": "AgrInputs",
      "category_id": "uuid",
      "category_name": "Feed Ingredients",
      "status": "active",
      "tax_id": "321654987",
      "commercial_register": "102345",
      "contact_info": {
        "phone_primary": "+201112223334",
        "phone_secondary": "+20233334444",
        "email": "sales@agrinputs.com",
        "fax": "+20233334445"
      },
      "address": {
        "street": "15 Industrial Zone",
        "city": "10th of Ramadan",
        "governorate": "Sharqia",
        "postal_code": "44629"
      },
      "payment_terms": "net_30",
      "currency": "EGP",
      "lead_time_days": 7,
      "minimum_order_amount": 50000.00,
      "credit_limit": 1000000.00,
      "current_balance": 350000.00,
      "rating": 4.5,
      "evaluation_score": 88,
      "is_preferred": true,
      "products_count": 25,
      "total_purchases_ytd": 3200000.00,
      "last_purchase_date": "2024-01-10",
      "bank_details": {
        "bank_name": "National Bank of Egypt",
        "account_number": "1234567890",
        "iban": "EG3800190005000000001234567890"
      },
      "created_at": "2022-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `suppliers.read`

---

### GET /api/v1/suppliers/{id}
Get supplier detail.
**Response (200):** Full supplier with products, purchase history, evaluations.
**Permissions:** `suppliers.read`

---

### POST /api/v1/suppliers
Create supplier.

**Request:**
```json
{
  "code": "string (auto if omitted)",
  "name_ar": "string (required)",
  "name_en": "string (required)",
  "trade_name": "string (optional)",
  "category_id": "uuid",
  "tax_id": "string",
  "commercial_register": "string",
  "contact_info": {
    "phone_primary": "string",
    "phone_secondary": "string (optional)",
    "email": "string",
    "fax": "string (optional)",
    "website": "string (optional)"
  },
  "address": {
    "street": "string",
    "city": "string",
    "governorate": "string",
    "postal_code": "string"
  },
  "payment_terms": "cash | net_7 | net_15 | net_30 | net_60",
  "currency": "EGP",
  "lead_time_days": "integer",
  "minimum_order_amount": "decimal",
  "credit_limit": "decimal",
  "bank_details": {
    "bank_name": "string",
    "account_number": "string",
    "iban": "string"
  },
  "notes": "string"
}
```

**Response (201):** Created supplier
**Permissions:** `suppliers.write`

---

### PUT /api/v1/suppliers/{id}
Update supplier.
**Response (200):** Updated supplier
**Permissions:** `suppliers.write`

---

### GET /api/v1/suppliers/{id}/evaluations
List supplier evaluations.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "supplier_id": "uuid",
      "evaluation_period": "Q4-2023",
      "evaluated_by_id": "uuid",
      "evaluated_by_name": "Ahmed Hassan",
      "evaluation_date": "2024-01-05",
      "criteria": {
        "quality": {"score": 4.5, "weight": 0.30},
        "delivery": {"score": 4.0, "weight": 0.25},
        "price": {"score": 3.5, "weight": 0.20},
        "service": {"score": 4.5, "weight": 0.15},
        "compliance": {"score": 5.0, "weight": 0.10}
      },
      "weighted_score": 4.15,
      "overall_rating": 4,
      "notes": "Good supplier, minor delivery delays in December",
      "created_at": "2024-01-05T10:00:00+02:00"
    }
  ]
}
```

**Permissions:** `suppliers.read`

---

### POST /api/v1/suppliers/{id}/evaluations
Add supplier evaluation.

**Request:**
```json
{
  "evaluation_period": "string",
  "criteria": {
    "quality": {"score": 1.0-5.0},
    "delivery": {"score": 1.0-5.0},
    "price": {"score": 1.0-5.0},
    "service": {"score": 1.0-5.0},
    "compliance": {"score": 1.0-5.0}
  },
  "notes": "string"
}
```

**Response (201):** Created evaluation
**Permissions:** `suppliers.evaluate`

---

### GET /api/v1/suppliers/{id}/contracts
List supplier contracts.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "contract_number": "SC-2024-00045",
      "supplier_id": "uuid",
      "start_date": "2024-01-01",
      "end_date": "2024-12-31",
      "contract_value": 5000000.00,
      "currency": "EGP",
      "terms": "Fixed price for corn deliveries",
      "products": [
        {"product_id": "uuid", "product_name": "Yellow Corn #2", "unit_price": 12.50, "minimum_quantity": 10000}
      ],
      "status": "active",
      "created_at": "2024-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `suppliers.read`

---

### POST /api/v1/suppliers/{id}/contracts
Create contract.

**Request:**
```json
{
  "contract_number": "string",
  "start_date": "date",
  "end_date": "date",
  "contract_value": "decimal",
  "currency": "EGP",
  "terms": "string",
  "products": [
    {
      "product_id": "uuid",
      "unit_price": "decimal",
      "minimum_quantity": "decimal",
      "maximum_quantity": "decimal"
    }
  ],
  "payment_schedule": [
    {"milestone": "Delivery", "percentage": 100}
  ],
  "attachments": ["url"]
}
```

**Response (201):** Created contract
**Permissions:** `suppliers.contracts.write`

---

## 1.9 Accounting & Financial Management API

### GET /api/v1/accounting/chart-of-accounts
List chart of accounts (hierarchical).

**Query Parameters:**
| Parameter  | Type   | Description                              |
|------------|--------|------------------------------------------|
| type       | enum   | `asset`, `liability`, `equity`, `revenue`, `expense` |
| level      | int    | Account level (1-5)                      |
| parent_id  | uuid   | Filter by parent account                 |
| is_active  | bool   | Active status                            |
| search     | string | Account name or code                     |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "code": "1100",
      "name_ar": "الأصول المتداولة",
      "name_en": "Current Assets",
      "account_type": "asset",
      "parent_id": null,
      "level": 1,
      "path": "/1100",
      "is_active": true,
      "is_bank_account": false,
      "is_cash_account": false,
      "currency": "EGP",
      "current_balance": 8500000.00,
      "opening_balance": 7200000.00,
      "children": [
        {
          "id": "uuid",
          "code": "1110",
          "name_ar": "النقدية",
          "name_en": "Cash",
          "account_type": "asset",
          "parent_id": "uuid",
          "level": 2,
          "path": "/1100/1110",
          "is_active": true,
          "is_bank_account": false,
          "is_cash_account": true,
          "current_balance": 1250000.00
        }
      ]
    }
  ]
}
```

**Permissions:** `accounting.read`

---

### POST /api/v1/accounting/chart-of-accounts
Create account.

**Request:**
```json
{
  "code": "string (unique, hierarchical)",
  "name_ar": "string",
  "name_en": "string",
  "account_type": "asset | liability | equity | revenue | expense",
  "parent_id": "uuid (optional)",
  "is_bank_account": false,
  "is_cash_account": false,
  "currency": "EGP",
  "opening_balance": 0.00,
  "opening_balance_date": "date",
  "is_active": true,
  "notes": "string"
}
```

**Response (201):** Created account
**Permissions:** `accounting.coa.manage`

---

### GET /api/v1/accounting/chart-of-accounts/{id}
Get account with transactions.
**Response (200):** Account with recent transactions
**Permissions:** `accounting.read`

---

### GET /api/v1/accounting/journal-entries
List journal entries.

**Query Parameters:**
| Parameter    | Type   | Description                          |
|--------------|--------|--------------------------------------|
| entry_number | string | Filter by number                     |
| date_from    | date   | Entry date range                     |
| date_to      | date   | Entry date range                     |
| status       | enum   | `draft`, `posted`, `reversed`        |
| branch_id    | uuid   | Filter by branch                     |
| account_id   | uuid   | Filter by account                    |
| reference    | string | Filter by reference                  |
| amount_min   | decimal| Minimum total amount                 |
| amount_max   | decimal| Maximum total amount                 |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "entry_number": "JE-2024-008924",
      "entry_date": "2024-01-15",
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "reference_type": "sales_invoice",
      "reference_id": "uuid",
      "reference_number": "SI-2024-001542",
      "description": "Sales invoice #SI-2024-001542",
      "status": "posted",
      "is_reversing_entry": false,
      "total_debit": 28180.00,
      "total_credit": 28180.00,
      "lines_count": 3,
      "posted_by": "uuid",
      "posted_at": "2024-01-15T09:05:00+02:00",
      "created_by": "uuid",
      "created_at": "2024-01-15T09:00:00+02:00"
    }
  ]
}
```

**Permissions:** `accounting.read`

---

### GET /api/v1/accounting/journal-entries/{id}
Get journal entry with lines.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "entry_number": "JE-2024-008924",
    ...,
    "lines": [
      {
        "id": "uuid",
        "line_number": 1,
        "account_id": "uuid",
        "account_code": "1110",
        "account_name": "Cash",
        "description": "Cash received from customer",
        "debit": 28180.00,
        "credit": 0.00,
        "branch_id": "uuid",
        "cost_center_id": "uuid (optional)",
        "project_id": "uuid (optional)",
        "reference": "string"
      },
      {
        "id": "uuid",
        "line_number": 2,
        "account_id": "uuid",
        "account_code": "4100",
        "account_name": "Sales Revenue",
        "description": "Sales revenue",
        "debit": 0.00,
        "credit": 24719.30,
        ...
      },
      {
        "id": "uuid",
        "line_number": 3,
        "account_id": "uuid",
        "account_code": "2200",
        "account_name": "VAT Payable",
        "description": "VAT 14%",
        "debit": 0.00,
        "credit": 3460.70,
        ...
      }
    ]
  }
}
```

**Permissions:** `accounting.read`

---

### POST /api/v1/accounting/journal-entries
Create journal entry.

**Request:**
```json
{
  "entry_date": "date",
  "branch_id": "uuid",
  "reference_type": "manual | sales_invoice | purchase | payment | adjustment | closing | opening",
  "reference_id": "uuid (optional)",
  "reference_number": "string (optional)",
  "description": "string",
  "is_reversing_entry": false,
  "lines": [
    {
      "account_id": "uuid",
      "description": "string (optional)",
      "debit": "decimal (>= 0)",
      "credit": "decimal (>= 0)",
      "branch_id": "uuid (optional, defaults to entry branch)",
      "cost_center_id": "uuid (optional)",
      "project_id": "uuid (optional)",
      "reference": "string (optional)"
    }
  ],
  "attachments": ["url"]
}
```

**Validation:** Sum of debits must equal sum of credits.
**Response (201):** Created journal entry
**Permissions:** `accounting.journal.write`

---

### PUT /api/v1/accounting/journal-entries/{id}/post
Post journal entry.
**Response (200):** Posted entry
**Permissions:** `accounting.journal.post`

---

### PUT /api/v1/accounting/journal-entries/{id}/reverse
Reverse journal entry.

**Request:**
```json
{
  "reversal_date": "date",
  "reason": "string (required)"
}
```

**Response (201):** Reversing entry
**Permissions:** `accounting.journal.reverse`

---

### GET /api/v1/accounting/cash-accounts
List cash accounts.
**Response (200):** List of cash accounts with balances
**Permissions:** `accounting.read`

### GET /api/v1/accounting/cash-accounts/{id}/transactions
List cash transactions.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "transaction_number": "CT-2024-004521",
      "cash_account_id": "uuid",
      "cash_account_name": "Main Cash - Cairo",
      "transaction_type": "receipt | payment | transfer_in | transfer_out",
      "transaction_date": "2024-01-15",
      "amount": 5000.00,
      "currency": "EGP",
      "exchange_rate": 1.0,
      "reference_type": "sales_invoice | purchase | salary | expense | transfer",
      "reference_id": "uuid",
      "reference_number": "SI-2024-001542",
      "description": "Cash collection from customer",
      "counterparty": "Al-Amal Poultry Farm",
      "branch_id": "uuid",
      "status": "posted",
      "created_by": "uuid",
      "created_at": "2024-01-15T10:00:00+02:00"
    }
  ]
}
```

**Permissions:** `accounting.read`

---

### POST /api/v1/accounting/cash-transactions
Record cash transaction.

**Request:**
```json
{
  "cash_account_id": "uuid",
  "transaction_type": "receipt | payment | transfer_in | transfer_out",
  "transaction_date": "date",
  "amount": "decimal (> 0)",
  "currency": "EGP",
  "reference_type": "string",
  "reference_id": "uuid (optional)",
  "reference_number": "string",
  "description": "string",
  "counterparty": "string",
  "branch_id": "uuid",
  "attachments": ["url"]
}
```

**Response (201):** Created transaction
**Permissions:** `accounting.cash.write`

---

### GET /api/v1/accounting/bank-accounts
List bank accounts.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "account_name": "NBE Main Account",
      "bank_name": "National Bank of Egypt",
      "branch_name": "Nasr City Branch",
      "account_number": "1234567890",
      "iban": "EG3800190005000000001234567890",
      "swift_code": "NBEGEGCX",
      "currency": "EGP",
      "account_type": "current | savings | fixed_deposit | foreign_currency",
      "current_balance": 5200000.00,
      "available_balance": 5100000.00,
      "hold_amount": 100000.00,
      "is_active": true,
      "chart_account_id": "uuid",
      "chart_account_code": "1120"
    }
  ]
}
```

**Permissions:** `accounting.read`

---

### GET /api/v1/accounting/bank-accounts/{id}/transactions
List bank transactions.

**Response (200):** Similar to cash transactions
**Permissions:** `accounting.read`

---

### POST /api/v1/accounting/bank-transactions
Record bank transaction.

**Request:**
```json
{
  "bank_account_id": "uuid",
  "transaction_type": "deposit | withdrawal | transfer_in | transfer_out | bank_charge | interest",
  "transaction_date": "date",
  "amount": "decimal",
  "currency": "EGP",
  "reference_number": "string",
  "description": "string",
  "counterparty": "string",
  "branch_id": "uuid",
  "is_reconciled": false
}
```

**Response (201):** Created transaction
**Permissions:** `accounting.bank.write`

---

### GET /api/v1/accounting/bank-accounts/{id}/reconciliation
Get reconciliation statement.

**Response (200):**
```json
{
  "data": {
    "bank_account_id": "uuid",
    "statement_date": "2024-01-15",
    "bank_statement_balance": 5200000.00,
    "book_balance": 5100000.00,
    "difference": 100000.00,
    "unreconciled_items": [
      {
        "id": "uuid",
        "transaction_date": "2024-01-14",
        "description": "Transfer pending",
        "amount": 100000.00,
        "type": "book | bank",
        "age_days": 1
      }
    ],
    "reconciled_transactions": 245,
    "unreconciled_count": 3
  }
}
```

**Permissions:** `accounting.reconciliation.read`

---

### POST /api/v1/accounting/bank-accounts/{id}/reconcile
Perform reconciliation.

**Request:**
```json
{
  "statement_date": "date",
  "bank_statement_balance": "decimal",
  "reconciled_transactions": ["uuid"],
  "adjustments": [
    {
      "description": "string",
      "amount": "decimal",
      "account_id": "uuid"
    }
  ]
}
```

**Response (200):** Reconciliation result
**Permissions:** `accounting.reconciliation.write`

---

### GET /api/v1/accounting/trial-balance
Get trial balance.

**Query Parameters:**
| Parameter | Type   | Description           |
|-----------|--------|-----------------------|
| date_from | date   | Period start          |
| date_to   | date   | Period end            |
| branch_id | uuid   | Filter by branch      |
| level     | int    | Account level depth   |

**Response (200):**
```json
{
  "data": {
    "period": "2024-01-01 to 2024-01-15",
    "accounts": [
      {
        "account_id": "uuid",
        "account_code": "1100",
        "account_name": "Current Assets",
        "opening_debit": 7200000.00,
        "opening_credit": 0.00,
        "period_debit": 8500000.00,
        "period_credit": 7200000.00,
        "closing_debit": 8500000.00,
        "closing_credit": 0.00
      }
    ],
    "total_debit": 45250000.00,
    "total_credit": 45250000.00
  }
}
```

**Permissions:** `accounting.reports.read`

---

### GET /api/v1/accounting/balance-sheet
Get balance sheet.

**Query Parameters:**
| Parameter | Type   | Description           |
|-----------|--------|-----------------------|
| as_of     | date   | Balance sheet date    |
| branch_id | uuid   | Filter by branch      |
| compare_to| date   | Comparison date       |

**Response (200):**
```json
{
  "data": {
    "as_of": "2024-01-15",
    "assets": {
      "current_assets": {"total": 8500000.00, "accounts": [...]},
      "fixed_assets": {"total": 15000000.00, "accounts": [...]},
      "total_assets": 23500000.00
    },
    "liabilities": {
      "current_liabilities": {"total": 5200000.00, "accounts": [...]},
      "long_term_liabilities": {"total": 3000000.00, "accounts": [...]},
      "total_liabilities": 8200000.00
    },
    "equity": {
      "share_capital": 10000000.00,
      "retained_earnings": 5300000.00,
      "total_equity": 15300000.00
    },
    "total_liabilities_equity": 23500000.00
  }
}
```

**Permissions:** `accounting.reports.read`

---

### GET /api/v1/accounting/income-statement
Get income statement (P&L).

**Query Parameters:**
| Parameter  | Type   | Description           |
|------------|--------|-----------------------|
| date_from  | date   | Period start          |
| date_to    | date   | Period end            |
| branch_id  | uuid   | Filter by branch      |
| comparison | enum   | `previous_period`, `previous_year`, `budget` |

**Response (200):**
```json
{
  "data": {
    "period": "2024-01-01 to 2024-01-15",
    "revenue": {
      "sales_revenue": 2850000.00,
      "other_revenue": 50000.00,
      "total_revenue": 2900000.00
    },
    "cost_of_goods_sold": -1850000.00,
    "gross_profit": 1050000.00,
    "gross_margin_pct": 36.2,
    "operating_expenses": {
      "salaries": -450000.00,
      "rent": -120000.00,
      "utilities": -80000.00,
      "marketing": -50000.00,
      "depreciation": -75000.00,
      "other": -125000.00,
      "total": -900000.00
    },
    "operating_profit": 150000.00,
    "operating_margin_pct": 5.2,
    "net_profit": 120000.00,
    "net_margin_pct": 4.1
  }
}
```

**Permissions:** `accounting.reports.read`

---

### GET /api/v1/accounting/tax-codes
List tax codes.
**Response (200):** Tax codes with rates
**Permissions:** `accounting.read`

### POST /api/v1/accounting/tax-codes
Create tax code.

**Request:**
```json
{
  "code": "VAT-14",
  "name_ar": "ضريبة القيمة المضافة 14%",
  "name_en": "VAT 14%",
  "tax_type": "vat | withholding | stamp | other",
  "rate": 14.0,
  "is_compound": false,
  "is_active": true,
  "effective_from": "date",
  "effective_to": "date (optional)"
}
```

**Permissions:** `accounting.tax.manage`

---

## 1.10 Production Management API

### GET /api/v1/production/orders
List production orders.

**Query Parameters:**
| Parameter     | Type   | Description                                |
|---------------|--------|--------------------------------------------|
| search        | string | PO number, product name                    |
| status        | enum   | `planned`, `approved`, `in_progress`, `completed`, `cancelled` |
| product_id    | uuid   | Filter by output product                   |
| line_id       | uuid   | Filter by production line                  |
| branch_id     | uuid   | Filter by branch                           |
| date_from     | date   | Scheduled date range                       |
| date_to       | date   | Scheduled date range                       |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "order_number": "PO-2024-001245",
      "branch_id": "uuid",
      "branch_name": "Cairo Factory",
      "production_line_id": "uuid",
      "line_name": "Feed Mill Line 1",
      "status": "in_progress",
      "product_id": "uuid",
      "product_name": "Broiler Feed 25kg",
      "product_sku": "FEED-BR-25KG",
      "planned_quantity": 5000,
      "actual_quantity": 3200,
      "remaining_quantity": 1800,
      "uom": "Bag",
      "recipe_id": "uuid",
      "recipe_name": "Broiler Standard",
      "scheduled_start": "2024-01-15T06:00:00+02:00",
      "scheduled_end": "2024-01-15T18:00:00+02:00",
      "actual_start": "2024-01-15T06:15:00+02:00",
      "actual_end": null,
      "estimated_cost": 1427500.00,
      "actual_cost": 915200.00,
      "yield_target_pct": 98.5,
      "actual_yield_pct": 98.2,
      "efficiency_pct": 92.0,
      "downtime_minutes": 45,
      "quality_status": "pass",
      "supervisor_id": "uuid",
      "supervisor_name": "Eng. Mahmoud Fathy",
      "notes": "Running on schedule",
      "created_at": "2024-01-10T08:00:00+02:00"
    }
  ]
}
```

**Permissions:** `production.read`

---

### GET /api/v1/production/orders/{id}
Get production order with materials and operations.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "order_number": "PO-2024-001245",
    ...,
    "materials": [
      {
        "id": "uuid",
        "product_id": "uuid",
        "product_name": "Yellow Corn",
        "planned_quantity": 2500,
        "actual_quantity": 2480,
        "uom": "kg",
        "unit_cost": 12.50,
        "total_cost": 31000.00,
        "issue_warehouse_id": "uuid",
        "status": "partially_issued"
      }
    ],
    "operations": [
      {
        "id": "uuid",
        "sequence": 1,
        "operation_name": "Grinding",
        "work_center": "Grinding Station",
        "planned_start": "datetime",
        "planned_end": "datetime",
        "actual_start": "datetime",
        "actual_end": null,
        "status": "in_progress",
        "labor_hours": 4.5,
        "machine_hours": 4.5
      }
    ],
    "quality_checks": [
      {
        "id": "uuid",
        "check_type": "moisture | protein | fat | particle_size | aflatoxin",
        "standard_min": 10.0,
        "standard_max": 12.0,
        "actual_value": 11.2,
        "result": "pass",
        "tested_by": "uuid",
        "tested_at": "datetime"
      }
    ]
  }
}
```

**Permissions:** `production.read`

---

### POST /api/v1/production/orders
Create production order.

**Request:**
```json
{
  "branch_id": "uuid",
  "production_line_id": "uuid",
  "product_id": "uuid",
  "recipe_id": "uuid (optional, defaults to default recipe)",
  "planned_quantity": "decimal (> 0)",
  "uom_id": "uuid",
  "scheduled_start": "datetime",
  "scheduled_end": "datetime",
  "priority": "normal | high | urgent",
  "supervisor_id": "uuid (optional)",
  "notes": "string"
}
```

**Response (201):** Created production order
**Permissions:** `production.write`

---

### PUT /api/v1/production/orders/{id}/start
Start production.

**Request:**
```json
{
  "actual_start": "datetime (default: now)",
  "operator_ids": ["uuid"],
  "notes": "string"
}
```

**Response (200):** Updated order
**Permissions:** `production.execute`

---

### PUT /api/v1/production/orders/{id}/complete
Complete production.

**Request:**
```json
{
  "actual_quantity": "decimal",
  "actual_end": "datetime (default: now)",
  "quality_status": "pass | fail | conditional",
  "waste_quantity": "decimal (default: 0)",
  "waste_reason": "string",
  "actual_cost": "decimal",
  "notes": "string"
}
```

**Response (200):** Completed order
**Permissions:** `production.execute`

---

### PUT /api/v1/production/orders/{id}/cancel
Cancel production order.

**Request:**
```json
{
  "reason": "string (required)"
}
```

**Permissions:** `production.cancel`

---

### GET /api/v1/production/lines
List production lines.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "code": "FL-01",
      "name": "Feed Mill Line 1",
      "branch_id": "uuid",
      "branch_name": "Cairo Factory",
      "line_type": "feed_mill | pellet | mash | extrusion",
      "capacity_kg_per_hour": 5000,
      "status": "active",
      "current_status": "running",
      "current_order_id": "uuid",
      "current_order_product": "Broiler Feed 25kg",
      "efficiency_ytd_pct": 94.5,
      "downtime_ytd_hours": 120,
      "operators_count": 8,
      "supervisor_id": "uuid",
      "shift_pattern": "3x8",
      "created_at": "2023-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `production.read`

---

### GET /api/v1/production/lines/{id}/schedule
Get production schedule for line.

**Response (200):**
```json
{
  "data": {
    "line_id": "uuid",
    "line_name": "Feed Mill Line 1",
    "schedule_date": "2024-01-15",
    "slots": [
      {
        "start_time": "06:00",
        "end_time": "18:00",
        "order_id": "uuid",
        "order_number": "PO-2024-001245",
        "product": "Broiler Feed 25kg",
        "quantity": 5000,
        "status": "in_progress",
        "color": "#4CAF50"
      },
      {
        "start_time": "18:30",
        "end_time": "06:00",
        "order_id": "uuid",
        "order_number": "PO-2024-001246",
        "product": "Layer Feed 25kg",
        "quantity": 3000,
        "status": "scheduled",
        "color": "#2196F3"
      }
    ]
  }
}
```

**Permissions:** `production.read`

---

### GET /api/v1/production/yield
Get production yield report.

**Query Parameters:** date_from, date_to, line_id, product_id, branch_id

**Response (200):**
```json
{
  "data": {
    "period": "2024-01-01 to 2024-01-15",
    "total_orders": 45,
    "total_planned_quantity": 225000,
    "total_actual_quantity": 218000,
    "average_yield_pct": 96.9,
    "average_efficiency_pct": 93.2,
    "total_downtime_hours": 36,
    "downtime_breakdown": [
      {"reason": "mechanical", "hours": 18},
      {"reason": "electrical", "hours": 8},
      {"reason": "cleaning", "hours": 6},
      {"reason": "material_shortage", "hours": 4}
    ],
    "by_product": [
      {"product_id": "uuid", "product_name": "Broiler Feed", "yield_pct": 97.2, "efficiency_pct": 94.0}
    ],
    "by_line": [
      {"line_id": "uuid", "line_name": "Feed Mill Line 1", "yield_pct": 97.0, "efficiency_pct": 93.5}
    ]
  }
}
```

**Permissions:** `production.reports.read`

---

### POST /api/v1/production/downtime
Record downtime event.

**Request:**
```json
{
  "production_line_id": "uuid",
  "production_order_id": "uuid (optional)",
  "start_time": "datetime",
  "end_time": "datetime (optional, if ongoing)",
  "downtime_type": "mechanical | electrical | material_shortage | quality_hold | cleaning | changeover | planned_maintenance | power_outage | other",
  "description": "string",
  "impact_quantity": "decimal (optional)",
  "resolved_by": "uuid (optional)",
  "resolution_notes": "string"
}
```

**Response (201):** Downtime record
**Permissions:** `production.downtime.write`

---

## 1.11 Feed Management API

### GET /api/v1/feed/formulations
List feed formulations (recipes).

**Query Parameters:**
| Parameter     | Type   | Description                              |
|---------------|--------|------------------------------------------|
| search        | string | Formulation name, product                |
| product_id    | uuid   | Filter by output product                 |
| status        | enum   | `active`, `draft`, `obsolete`            |
| feed_type     | enum   | `broiler_starter`, `broiler_grower`, `broiler_finisher`, `layer`, `breeder`, `pre_starter` |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "code": "FF-BR-STD-001",
      "name": "Broiler Starter Standard",
      "feed_type": "broiler_starter",
      "product_id": "uuid",
      "product_name": "Broiler Feed 25kg",
      "product_sku": "FEED-BR-25KG",
      "status": "active",
      "version": 3,
      "is_default": true,
      "batch_size_kg": 5000,
      "target_protein_pct": 22.0,
      "target_energy_kcal": 3200,
      "target_fat_pct": 5.0,
      "target_fiber_pct_max": 4.0,
      "standard_cost_per_kg": 11.42,
      "ingredients_count": 12,
      "total_formula_pct": 100.0,
      "created_by": "uuid",
      "created_at": "2023-06-01T00:00:00+02:00",
      "updated_at": "2024-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `feed.read`

---

### GET /api/v1/feed/formulations/{id}
Get formulation with ingredients and nutrients.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "code": "FF-BR-STD-001",
    ...,
    "ingredients": [
      {
        "id": "uuid",
        "sequence": 1,
        "ingredient_id": "uuid",
        "ingredient_name": "Yellow Corn #2",
        "ingredient_code": "COR-YL-2",
        "inclusion_pct": 55.0,
        "quantity_kg": 2750,
        "unit_cost": 12.50,
        "cost_contribution": 34375.00,
        "cost_pct": 60.2,
        "nutrients_contribution": {
          "protein": 5.225,
          "energy": 1760.0,
          "fat": 1.925,
          "fiber": 0.825
        },
        "min_inclusion_pct": 50.0,
        "max_inclusion_pct": 60.0,
        "is_variable": true,
        "alternative_ingredients": [
          {"ingredient_id": "uuid", "ingredient_name": "Sorghum", "price_difference_pct": -5.0}
        ]
      }
    ],
    "nutrient_summary": {
      "protein": {"formulated": 22.1, "target": 22.0, "min": 21.5, "max": 22.5, "status": "within_range"},
      "energy": {"formulated": 3210, "target": 3200, "min": 3150, "max": 3250, "status": "within_range"},
      "fat": {"formulated": 4.8, "target": 5.0, "min": 4.5, "max": 5.5, "status": "within_range"},
      "fiber": {"formulated": 3.8, "target": 4.0, "max": 4.0, "status": "within_range"}
    },
    "total_cost": 57100.00,
    "cost_per_kg": 11.42
  }
}
```

**Permissions:** `feed.read`

---

### POST /api/v1/feed/formulations
Create formulation.

**Request:**
```json
{
  "code": "string (unique)",
  "name": "string",
  "feed_type": "broiler_starter | broiler_grower | broiler_finisher | layer | breeder | pre_starter | custom",
  "product_id": "uuid",
  "batch_size_kg": "decimal",
  "target_protein_pct": "decimal",
  "target_energy_kcal": "decimal",
  "target_fat_pct": "decimal",
  "target_fiber_pct_max": "decimal",
  "ingredients": [
    {
      "ingredient_id": "uuid",
      "inclusion_pct": "decimal",
      "min_inclusion_pct": "decimal (optional)",
      "max_inclusion_pct": "decimal (optional)",
      "is_variable": false
    }
  ],
  "is_default": false,
  "notes": "string"
}
```

**Response (201):** Created formulation
**Permissions:** `feed.formulation.write`

---

### PUT /api/v1/feed/formulations/{id}
Update formulation.
**Permissions:** `feed.formulation.write`

---

### POST /api/v1/feed/formulations/{id}/clone
Clone formulation (creates new version).

**Request:**
```json
{
  "new_code": "string",
  "new_name": "string",
  "version_notes": "string"
}
```

**Response (201):** Cloned formulation
**Permissions:** `feed.formulation.write`

---

### GET /api/v1/feed/ingredients
List feed ingredients.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "code": "COR-YL-2",
      "name_ar": "ذرة صفراء درجة 2",
      "name_en": "Yellow Corn #2",
      "category": "grain | protein_source | mineral | vitamin | additive | binder | oil",
      "nutritional_profile": {
        "protein_pct": 9.5,
        "energy_kcal_kg": 3200,
        "fat_pct": 3.5,
        "fiber_pct": 1.5,
        "lysine_pct": 0.25,
        "methionine_pct": 0.18,
        "calcium_pct": 0.02,
        "phosphorus_pct": 0.27
      },
      "current_price_per_kg": 12.50,
      "price_trend": "stable | rising | falling",
      "supplier_id": "uuid",
      "supplier_name": "Agricultural Inputs Co.",
      "is_active": true,
      "formulations_using": 8
    }
  ]
}
```

**Permissions:** `feed.read`

---

### POST /api/v1/feed/ingredients
Create ingredient.

**Request:**
```json
{
  "code": "string (unique)",
  "name_ar": "string",
  "name_en": "string",
  "category": "grain | protein_source | mineral | vitamin | additive | binder | oil | other",
  "nutritional_profile": {
    "protein_pct": "decimal",
    "energy_kcal_kg": "decimal",
    "fat_pct": "decimal",
    "fiber_pct": "decimal",
    "lysine_pct": "decimal",
    "methionine_pct": "decimal",
    "calcium_pct": "decimal",
    "phosphorus_pct": "decimal"
  },
  "supplier_id": "uuid (optional)",
  "is_active": true
}
```

**Response (201):** Created ingredient
**Permissions:** `feed.ingredient.write`

---

### POST /api/v1/feed/optimize
Run cost optimization on formulation.

**Request:**
```json
{
  "formulation_id": "uuid",
  "objective": "minimize_cost | maximize_quality | balanced",
  "constraints": {
    "max_cost_per_kg": "decimal (optional)",
    "min_protein_pct": "decimal (optional)",
    "min_energy_kcal": "decimal (optional)",
    "locked_ingredients": ["ingredient_id"],
    "excluded_ingredients": ["ingredient_id"],
    "alternative_ingredients_allowed": true
  },
  "ingredient_prices": {
    "ingredient_id": "decimal (override current price)"
  }
}
```

**Response (200):**
```json
{
  "data": {
    "formulation_id": "uuid",
    "original_cost_per_kg": 11.42,
    "optimized_cost_per_kg": 10.85,
    "savings_pct": 5.0,
    "savings_per_ton": 570.00,
    "status": "optimal",
    "optimized_ingredients": [
      {
        "ingredient_id": "uuid",
        "ingredient_name": "Yellow Corn #2",
        "original_inclusion_pct": 55.0,
        "optimized_inclusion_pct": 52.0,
        "change": -3.0
      }
    ],
    "nutrient_check": {
      "all_within_spec": true,
      "violations": []
    },
    "recommendation": "Replace 3% corn with sorghum to reduce cost while maintaining nutritional targets."
  }
}
```

**Permissions:** `feed.optimize`

---

### GET /api/v1/feed/cost-analysis
Get feed cost analysis.

**Query Parameters:** date_from, date_to, formulation_id, ingredient_id

**Response (200):**
```json
{
  "data": {
    "period": "2024-01-01 to 2024-01-15",
    "total_feed_produced_kg": 1250000,
    "total_feed_cost": 14287500.00,
    "average_cost_per_kg": 11.43,
    "cost_trend": [
      {"date": "2024-01-01", "cost_per_kg": 11.20},
      {"date": "2024-01-15", "cost_per_kg": 11.50}
    ],
    "cost_by_ingredient": [
      {"ingredient": "Yellow Corn", "cost": 8572500, "pct": 60.0},
      {"ingredient": "Soybean Meal", "cost": 2857500, "pct": 20.0}
    ],
    "cost_by_formulation": [
      {"formulation": "Broiler Starter", "cost": 5715000, "pct": 40.0}
    ]
  }
}
```

**Permissions:** `feed.reports.read`

---

## 1.12 Livestock Management API

### GET /api/v1/livestock/animals
List livestock animals.

**Query Parameters:**
| Parameter    | Type   | Description                                |
|--------------|--------|--------------------------------------------|
| search       | string | Tag number, breed name                     |
| species      | enum   | `cattle`, `sheep`, `goats`, `buffalo`, `camel` |
| breed_id     | uuid   | Filter by breed                            |
| gender       | enum   | `male`, `female`                           |
| status       | enum   | `active`, `sold`, `slaughtered`, `died`, `transferred` |
| location_id  | uuid   | Filter by location/farm                    |
| birth_from   | date   | Birth date range                           |
| birth_to     | date   | Birth date range                           |
| age_min_days | int    | Minimum age in days                        |
| age_max_days | int    | Maximum age in days                        |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "tag_number": "LV-CAI-2024-004521",
      "rfid_tag": "E200341502001080",
      "species": "cattle",
      "breed_id": "uuid",
      "breed_name": "Baladi",
      "breed_name_ar": "بلدي",
      "gender": "female",
      "birth_date": "2022-03-15",
      "age_months": 22,
      "acquisition_date": "2022-04-01",
      "acquisition_type": "born_on_farm | purchased | transferred | donated",
      "acquisition_cost": 3500.00,
      "mother_id": "uuid (optional)",
      "father_id": "uuid (optional)",
      "status": "active",
      "current_location_id": "uuid",
      "current_location_name": "Cairo Farm - Barn A",
      "current_weight_kg": 420.0,
      "birth_weight_kg": 28.0,
      "average_daily_gain_g": 650.0,
      "body_condition_score": 3.5,
      "health_status": "healthy | sick | under_treatment | quarantine",
      "reproductive_status": "lactating | pregnant | open | dry",
      "lactation_number": 2,
      "current_lactation_start": "2024-01-01",
      "last_breeding_date": "2023-10-15",
      "expected_calving": "2024-07-15",
      "notes": "Good producer",
      "custom_fields": {
        "ear_tag_color": "blue",
        "pen_number": "A-12"
      },
      "created_at": "2022-04-01T10:00:00+02:00",
      "updated_at": "2024-01-15T06:00:00+02:00"
    }
  ]
}
```

**Permissions:** `livestock.read`

---

### GET /api/v1/livestock/animals/{id}
Get animal with full history.

**Response (200):** Animal with weights, feed consumption, vaccinations, breeding, offspring.
**Permissions:** `livestock.read`

---

### POST /api/v1/livestock/animals
Register new animal.

**Request:**
```json
{
  "tag_number": "string (unique)",
  "rfid_tag": "string (optional)",
  "species": "cattle | sheep | goats | buffalo | camel",
  "breed_id": "uuid",
  "gender": "male | female",
  "birth_date": "date",
  "birth_weight_kg": "decimal (optional)",
  "acquisition_date": "date",
  "acquisition_type": "born_on_farm | purchased | transferred | donated",
  "acquisition_cost": "decimal (optional)",
  "mother_id": "uuid (optional)",
  "father_id": "uuid (optional)",
  "current_location_id": "uuid",
  "initial_weight_kg": "decimal",
  "health_status": "healthy | sick | under_treatment | quarantine (default: healthy)",
  "reproductive_status": "lactating | pregnant | open | dry | na (default based on gender)",
  "notes": "string",
  "custom_fields": "object"
}
```

**Response (201):** Created animal
**Permissions:** `livestock.write`

---

### PUT /api/v1/livestock/animals/{id}
Update animal.
**Permissions:** `livestock.write`

---

### PUT /api/v1/livestock/animals/{id}/status
Update animal status.

**Request:**
```json
{
  "status": "active | sold | slaughtered | died | transferred",
  "status_date": "date",
  "reason": "string",
  "destination": "string (for sold/transferred)",
  "price": "decimal (for sold)"
}
```

**Permissions:** `livestock.status.manage`

---

### POST /api/v1/livestock/weights
Record weight measurement.

**Request:**
```json
{
  "animal_id": "uuid",
  "weight_date": "date",
  "weight_kg": "decimal (> 0)",
  "measurement_method": "scale | visual_estimate | girth_formula",
  "body_condition_score": "decimal (1-5, optional)",
  "measured_by": "uuid",
  "notes": "string"
}
```

**Response (201):** Weight record with ADG calculation
**Permissions:** `livestock.weights.write`

---

### GET /api/v1/livestock/weights
List weight records.

**Query Parameters:** animal_id, date_from, date_to, location_id

**Response (200):** Paginated weight records with ADG trends
**Permissions:** `livestock.read`

---

### POST /api/v1/livestock/feed-consumption
Record feed consumption.

**Request:**
```json
{
  "location_id": "uuid",
  "feed_date": "date",
  "feed_product_id": "uuid",
  "quantity_kg": "decimal (> 0)",
  "animal_count": "integer",
  "average_weight_kg": "decimal (optional)",
  "feed_conversion_ratio": "decimal (optional, calculated if not provided)",
  "cost_per_kg": "decimal",
  "total_cost": "decimal",
  "wastage_kg": "decimal (default: 0)",
  "notes": "string",
  "recorded_by": "uuid"
}
```

**Response (201):** Feed consumption record
**Permissions:** `livestock.feed.write`

---

### GET /api/v1/livestock/feed-consumption
List feed consumption records.

**Query Parameters:** location_id, feed_product_id, date_from, date_to

**Response (200):** Paginated records with FCR trends
**Permissions:** `livestock.read`

---

### POST /api/v1/livestock/vaccinations
Record vaccination.

**Request:**
```json
{
  "animal_ids": ["uuid"],
  "vaccination_date": "date",
  "vaccine_id": "uuid",
  "vaccine_name": "string",
  "vaccine_batch": "string",
  "vaccination_type": "routine | emergency | booster",
  "dose_ml": "decimal",
  "route": "subcutaneous | intramuscular | oral | nasal | spray",
  "administered_by": "uuid",
  "next_due_date": "date (optional, for multi-dose vaccines)",
  "location_id": "uuid",
  "notes": "string",
  "attachments": ["url"]
}
```

**Response (201):** Vaccination record
**Permissions:** `livestock.vaccination.write`

---

### GET /api/v1/livestock/vaccinations
List vaccination records.

**Query Parameters:** animal_id, vaccine_id, date_from, date_to, location_id, status (due|overdue|completed)

**Response (200):** Paginated vaccination records
**Permissions:** `livestock.read`

---

### GET /api/v1/livestock/vaccinations/due
Get upcoming and overdue vaccinations.

**Response (200):**
```json
{
  "data": {
    "due_within_7_days": [...],
    "due_within_30_days": [...],
    "overdue": [...],
    "total_due": 45,
    "total_overdue": 12
  }
}
```

**Permissions:** `livestock.read`

---

### POST /api/v1/livestock/breeding
Record breeding event.

**Request:**
```json
{
  "female_id": "uuid",
  "male_id": "uuid (optional, for natural service)",
  "semen_id": "uuid (optional, for AI)",
  "breeding_date": "date",
  "breeding_type": "natural | artificial_insemination | embryo_transfer",
  "technician_id": "uuid (optional, for AI)",
  "location_id": "uuid",
  "expected_due_date": "date (auto-calculated)",
  "notes": "string"
}
```

**Response (201):** Breeding record
**Permissions:** `livestock.breeding.write`

---

### GET /api/v1/livestock/breeding
List breeding records.

**Query Parameters:** female_id, status (pregnant|confirmed|open), expected_from, expected_to

**Response (200):** Paginated breeding records
**Permissions:** `livestock.read`

---

### PUT /api/v1/livestock/breeding/{id}/confirm
Confirm pregnancy.

**Request:**
```json
{
  "confirmation_date": "date",
  "method": "ultrasound | rectal | blood_test | visual",
  "confirmed_by": "uuid",
  "expected_calving_date": "date"
}
```

**Permissions:** `livestock.breeding.write`

---

### POST /api/v1/livestock/calving
Record calving/birth.

**Request:**
```json
{
  "breeding_id": "uuid",
  "female_id": "uuid",
  "calving_date": "date",
  "calving_type": "normal | assisted | cesarean",
  "difficulty": "none | mild | moderate | severe",
  "calf_count": "integer",
  "calves": [
    {
      "tag_number": "string",
      "gender": "male | female",
      "birth_weight_kg": "decimal",
      "health_status": "healthy | weak | stillborn",
      "notes": "string"
    }
  ],
  "attended_by": "uuid",
  "notes": "string"
}
```

**Response (201):** Calving record + auto-created calf records
**Permissions:** `livestock.breeding.write`

---

### GET /api/v1/livestock/performance
Get livestock performance dashboard.

**Response (200):**
```json
{
  "data": {
    "total_animals": 12500,
    "by_species": {"cattle": 5000, "sheep": 5000, "goats": 2500},
    "by_status": {"active": 12000, "sold": 300, "died": 200},
    "by_health": {"healthy": 11800, "sick": 150, "treatment": 50},
    "average_daily_gain_g": 680,
    "feed_conversion_ratio": 6.2,
    "mortality_rate_pct": 1.6,
    "births_this_month": 450,
    "pregnant_count": 3200,
    "average_milk_production_l": 18.5,
    "performance_trend": [
      {"month": "2023-12", "adg": 670, "fcr": 6.3, "mortality": 1.5},
      {"month": "2024-01", "adg": 680, "fcr": 6.2, "mortality": 1.6}
    ]
  }
}
```

**Permissions:** `livestock.read` or `dashboard.view`

---

## 1.13 Poultry Management API

### GET /api/v1/poultry/chicks
List chick batches.

**Query Parameters:**
| Parameter    | Type   | Description                                |
|--------------|--------|--------------------------------------------|
| search       | string | Batch number, breed name, supplier         |
| breed_id     | uuid   | Filter by breed                            |
| supplier_id  | uuid   | Filter by supplier                         |
| status       | enum   | `reserved`, `active`, `growing`, `sold`, `mortality_complete` |
| house_id     | uuid   | Filter by house                            |
| date_from    | date   | Arrival date range                         |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "batch_number": "CH-CAI-2024-001245",
      "breed_id": "uuid",
      "breed_name": "Ross 308",
      "breed_type": "broiler",
      "supplier_id": "uuid",
      "supplier_name": "Cairo Poultry Co.",
      "hatchery": "Cairo Hatchery",
      "arrival_date": "2024-01-10",
      "age_at_arrival_days": 1,
      "initial_count": 50000,
      "current_count": 48750,
      "mortality_count": 1250,
      "mortality_pct": 2.5,
      "current_age_days": 5,
      "current_day": 5,
      "house_id": "uuid",
      "house_name": "Broiler House 1",
      "farm_id": "uuid",
      "farm_name": "Cairo Poultry Farm",
      "status": "active",
      "target_weight_kg": 2.5,
      "target_days": 35,
      "current_avg_weight_g": 180,
      "fcr_current": 1.05,
      "feed_consumed_kg": 10237.5,
      "vaccination_status": "on_schedule",
      "next_vaccination": {"vaccine": "IBD", "due_date": "2024-01-17"},
      "estimated_ready_date": "2024-02-14",
      "reservation_id": "uuid (optional)",
      "notes": "Good start, low mortality",
      "created_at": "2024-01-10T06:00:00+02:00"
    }
  ]
}
```

**Permissions:** `poultry.read`

---

### GET /api/v1/poultry/chicks/{id}
Get chick batch detail.

**Response (200):** Full batch with daily records, vaccinations, mortality log, weight history.
**Permissions:** `poultry.read`

---

### POST /api/v1/poultry/chicks
Register new chick batch.

**Request:**
```json
{
  "breed_id": "uuid",
  "supplier_id": "uuid",
  "hatchery": "string",
  "arrival_date": "date (default: today)",
  "age_at_arrival_days": "integer (default: 1)",
  "initial_count": "integer (> 0)",
  "house_id": "uuid",
  "initial_avg_weight_g": "decimal (optional)",
  "target_weight_kg": "decimal",
  "target_days": "integer",
  "source": "hatchery | imported | transferred",
  "vaccination_at_source": ["IBD", "ND"],
  "quality_grade": "a | b | c",
  "cost_per_chick": "decimal",
  "transport_cost": "decimal",
  "notes": "string"
}
```

**Response (201):** Created batch
**Permissions:** `poultry.write`

---

### POST /api/v1/poultry/chicks/{id}/daily-record
Submit daily record for batch.

**Request:**
```json
{
  "record_date": "date",
  "day_number": "integer",
  "mortality_count": "integer (default: 0)",
  "mortality_cause": "string (optional)",
  "culling_count": "integer (default: 0)",
  "feed_consumed_kg": "decimal",
  "feed_type_id": "uuid",
  "water_consumed_liters": "decimal",
  "avg_weight_g": "decimal (optional, measured on weigh days)",
  "sample_size": "integer (optional)",
  "min_weight_g": "decimal (optional)",
  "max_weight_g": "decimal (optional)",
  "uniformity_pct": "decimal (optional)",
  "temperature_c": "decimal",
  "humidity_pct": "decimal",
  "light_hours": "decimal (optional)",
  "medications": [
    {
      "product_id": "uuid",
      "dosage": "string",
      "administration_method": "string"
    }
  ],
  "observations": "string",
  "recorded_by": "uuid"
}
```

**Response (201):** Daily record with calculated KPIs
**Permissions:** `poultry.daily.write`

---

### GET /api/v1/poultry/mortality
List mortality records.

**Query Parameters:** batch_id, house_id, date_from, date_to, cause

**Response (200):** Paginated mortality records
**Permissions:** `poultry.read`

---

### POST /api/v1/poultry/mortality
Record mortality event.

**Request:**
```json
{
  "batch_id": "uuid",
  "house_id": "uuid",
  "mortality_date": "date",
  "count": "integer (> 0)",
  "cause": "disease | heat_stress | suffocation | dehydration | predation | unknown | culling",
  "disease_id": "uuid (optional)",
  "symptoms": "string (optional)",
  "post_mortem_findings": "string (optional)",
  "action_taken": "string",
  "veterinarian_id": "uuid (optional)",
  "attachments": ["url"]
}
```

**Response (201):** Mortality record
**Permissions:** `poultry.mortality.write`

---

### GET /api/v1/poultry/vaccinations
List poultry vaccinations.

**Query Parameters:** batch_id, house_id, vaccine_id, status (due|completed|overdue)

**Response (200):** Paginated vaccination records
**Permissions:** `poultry.read`

---

### POST /api/v1/poultry/vaccinations
Schedule/record poultry vaccination.

**Request:**
```json
{
  "batch_ids": ["uuid"],
  "house_ids": ["uuid (optional)"],
  "vaccine_id": "uuid",
  "vaccination_date": "date",
  "day_age": "integer (vaccination day)",
  "route": "drinking_water | spray | eye_drop | injection | wing_web",
  "dose_per_bird": "string",
  "administered_by": "uuid",
  "notes": "string"
}
```

**Response (201):** Vaccination record
**Permissions:** `poultry.vaccination.write`

---

### GET /api/v1/poultry/reservations
List chick reservations.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "reservation_number": "RES-2024-000892",
      "customer_id": "uuid",
      "customer_name": "Al-Amal Farm",
      "breed_id": "uuid",
      "breed_name": "Ross 308",
      "requested_count": 50000,
      "requested_delivery_date": "2024-03-01",
      "status": "confirmed",
      "priority": "normal",
      "deposit_amount": 25000.00,
      "deposit_paid": true,
      "unit_price": "0.50",
      "total_value": 25000.00,
      "allocated_batch_id": "uuid (optional)",
      "actual_delivery_date": null,
      "delivery_location": "Al-Amal Farm, October City",
      "notes": "Customer prefers day-old chicks",
      "created_at": "2024-01-05T10:00:00+02:00"
    }
  ]
}
```

**Permissions:** `poultry.read`

---

### POST /api/v1/poultry/reservations
Create reservation.

**Request:**
```json
{
  "customer_id": "uuid",
  "breed_id": "uuid",
  "requested_count": "integer",
  "requested_delivery_date": "date",
  "priority": "normal | high | urgent",
  "deposit_amount": "decimal",
  "unit_price": "decimal",
  "delivery_location": "string",
  "special_requirements": "string",
  "notes": "string"
}
```

**Response (201):** Created reservation
**Permissions:** `poultry.reservations.write`

---

### PUT /api/v1/poultry/reservations/{id}/confirm
Confirm reservation.
**Permissions:** `poultry.reservations.manage`

### PUT /api/v1/poultry/reservations/{id}/allocate
Allocate batch to reservation.

**Request:**
```json
{
  "batch_id": "uuid",
  "allocated_count": "integer",
  "delivery_date": "date"
}
```

**Permissions:** `poultry.reservations.manage`

---

### PUT /api/v1/poultry/reservations/{id}/fulfill
Mark reservation as fulfilled.
**Permissions:** `poultry.reservations.manage`

---

### GET /api/v1/poultry/sales
List poultry sales (live birds).

**Query Parameters:** customer_id, batch_id, date_from, date_to, status

**Response (200):** Paginated poultry sales
**Permissions:** `poultry.read` or `sales.read`

---

### POST /api/v1/poultry/sales
Create poultry sale.

**Request:**
```json
{
  "customer_id": "uuid",
  "batch_id": "uuid",
  "sale_date": "date",
  "bird_count": "integer",
  "avg_weight_kg": "decimal",
  "total_weight_kg": "decimal",
  "price_per_kg": "decimal",
  "total_amount": "decimal",
  "grade": "a | b | c",
  "vehicle_id": "uuid (optional, for delivery)",
  "notes": "string"
}
```

**Response (201):** Created sale
**Permissions:** `poultry.sales.write`

---

### GET /api/v1/poultry/performance
Get poultry performance dashboard.

**Response (200):**
```json
{
  "data": {
    "active_batches": 24,
    "total_birds": 1200000,
    "avg_mortality_pct": 3.8,
    "avg_fcr": 1.72,
    "avg_live_weight_kg": 2.45,
    "avg_growth_rate_g_per_day": 65.2,
    "houses_in_use": 24,
    "houses_available": 6,
    "production_capacity_pct": 80.0,
    "batches_ready_this_week": 3,
    "upcoming_vaccinations": 8,
    "overdue_vaccinations": 0,
    "performance_by_house": [
      {"house_id": "uuid", "house_name": "BH-01", "bird_count": 50000, "mortality_pct": 2.8, "fcr": 1.68, "avg_weight_g": 1850}
    ]
  }
}
```

**Permissions:** `poultry.read` or `dashboard.view`

---

### GET /api/v1/poultry/breeds
List poultry breeds.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "name": "Ross 308",
      "type": "broiler",
      "origin": "Aviagen",
      "description": "High-performance broiler breed",
      "standard_performance": {
        "target_weight_kg": 2.5,
        "target_days": 35,
        "expected_fcr": 1.65,
        "expected_mortality_pct": 4.0,
        "expected_uniformity_pct": 85
      },
      "is_active": true
    }
  ]
}
```

**Permissions:** `poultry.read`

---

## 1.14 Egg Production & Distribution API

### GET /api/v1/eggs/production
List egg production records.

**Query Parameters:**
| Parameter     | Type   | Description                              |
|---------------|--------|------------------------------------------|
| house_id      | uuid   | Filter by house                          |
| flock_id      | uuid   | Filter by flock                          |
| date_from     | date   | Production date range                    |
| date_to       | date   | Production date range                    |
| branch_id     | uuid   | Filter by branch                         |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "production_date": "2024-01-15",
      "flock_id": "uuid",
      "flock_code": "FL-CAI-2023-0045",
      "breed": "Lohmann Brown",
      "house_id": "uuid",
      "house_name": "Layer House 3",
      "branch_id": "uuid",
      "branch_name": "Cairo Farm",
      "bird_count": 25000,
      "bird_age_weeks": 35,
      "production_stage": "peak",
      "total_eggs": 23750,
      "production_pct": 95.0,
      "grade_breakdown": {
        "jumbo": {"count": 2375, "pct": 10.0, "price": 2.50},
        "extra_large": {"count": 7125, "pct": 30.0, "price": 2.20},
        "large": {"count": 9500, "pct": 40.0, "price": 2.00},
        "medium": {"count": 3563, "pct": 15.0, "price": 1.70},
        "small": {"count": 1188, "pct": 5.0, "price": 1.40}
      },
      "defective_eggs": {
        "cracked": 100,
        "dirty": 50,
        "misshapen": 25,
        "soft_shell": 10,
        "total_defective_pct": 0.78
      },
      "feed_consumed_kg": 3750,
      "feed_cost": 42862.50,
      "revenue": 48837.50,
      "feed_cost_per_egg": 1.81,
      "margin_per_egg": 0.25,
      "recorded_by": "uuid",
      "recorded_at": "2024-01-15T20:00:00+02:00"
    }
  ]
}
```

**Permissions:** `eggs.read`

---

### POST /api/v1/eggs/production
Record daily egg production.

**Request:**
```json
{
  "production_date": "date (default: today)",
  "flock_id": "uuid",
  "house_id": "uuid",
  "bird_count": "integer",
  "total_eggs": "integer",
  "grade_jumbo": "integer (default: 0)",
  "grade_extra_large": "integer (default: 0)",
  "grade_large": "integer (default: 0)",
  "grade_medium": "integer (default: 0)",
  "grade_small": "integer (default: 0)",
  "defective_cracked": "integer (default: 0)",
  "defective_dirty": "integer (default: 0)",
  "defective_misshapen": "integer (default: 0)",
  "defective_soft_shell": "integer (default: 0)",
  "feed_consumed_kg": "decimal",
  "feed_cost": "decimal",
  "recorded_by": "uuid"
}
```

**Validation:** Sum of grades + defective must equal total_eggs.
**Response (201):** Production record with calculated KPIs
**Permissions:** `eggs.production.write`

---

### GET /api/v1/eggs/inventory
Get egg inventory.

**Query Parameters:** warehouse_id, grade, date

**Response (200):**
```json
{
  "data": {
    "as_of": "2024-01-15T20:00:00+02:00",
    "warehouses": [
      {
        "warehouse_id": "uuid",
        "warehouse_name": "Cairo Cold Store",
        "grades": [
          {"grade": "jumbo", "quantity_trays": 500, "quantity_pcs": 15000, "avg_price": 2.50},
          {"grade": "extra_large", "quantity_trays": 1200, "quantity_pcs": 36000, "avg_price": 2.20},
          {"grade": "large", "quantity_trays": 2000, "quantity_pcs": 60000, "avg_price": 2.00}
        ],
        "total_trays": 3700,
        "total_pcs": 111000,
        "total_value": 232500.00
      }
    ],
    "grand_total_trays": 3700,
    "grand_total_pcs": 111000,
    "grand_total_value": 232500.00
  }
}
```

**Permissions:** `eggs.read`

---

### GET /api/v1/eggs/grades
List egg grade definitions.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "grade_code": "J",
      "grade_name": "Jumbo",
      "min_weight_g": 70,
      "max_weight_g": 999,
      "min_diameter_mm": 55,
      "shell_quality_standard": "clean_unbroken",
      "standard_price": 2.50,
      "sort_order": 1
    },
    {
      "id": "uuid",
      "grade_code": "XL",
      "grade_name": "Extra Large",
      "min_weight_g": 63,
      "max_weight_g": 69,
      "standard_price": 2.20,
      "sort_order": 2
    }
  ]
}
```

**Permissions:** `eggs.read`

---

### GET /api/v1/eggs/packaging
List egg packaging records.

**Query Parameters:** date_from, date_to, warehouse_id, grade

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "packaging_date": "2024-01-15",
      "warehouse_id": "uuid",
      "grade": "extra_large",
      "cartons_packed": 500,
      "trays_per_carton": 6,
      "eggs_per_tray": 30,
      "total_eggs": 90000,
      "damaged_during_packing": 45,
      "packing_material_cost": 2500.00,
      "labor_cost": 1500.00,
      "packed_by": "uuid",
      "quality_check": "passed"
    }
  ]
}
```

**Permissions:** `eggs.read`

---

### POST /api/v1/eggs/packaging
Record egg packaging.

**Request:**
```json
{
  "packaging_date": "date",
  "warehouse_id": "uuid",
  "grade": "jumbo | extra_large | large | medium | small",
  "cartons_packed": "integer",
  "trays_per_carton": "integer",
  "eggs_per_tray": "integer",
  "damaged_during_packing": "integer (default: 0)",
  "packing_material_cost": "decimal",
  "labor_cost": "decimal",
  "quality_notes": "string",
  "packed_by": "uuid"
}
```

**Response (201):** Packaging record
**Permissions:** `eggs.packaging.write`

---

### GET /api/v1/eggs/distribution
List egg distribution (sales).

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "distribution_number": "ED-2024-001245",
      "distribution_date": "2024-01-15",
      "customer_id": "uuid",
      "customer_name": "Metro Market",
      "grade": "extra_large",
      "cartons": 200,
      "total_eggs": 36000,
      "unit_price": 2.20,
      "total_amount": 79200.00,
      "discount_pct": 5.0,
      "net_amount": 75240.00,
      "vehicle_id": "uuid",
      "delivery_status": "delivered",
      "payment_status": "unpaid",
      "invoice_id": "uuid"
    }
  ]
}
```

**Permissions:** `eggs.read` or `sales.read`

---

### POST /api/v1/eggs/distribution
Create egg distribution.

**Request:**
```json
{
  "distribution_date": "date",
  "customer_id": "uuid",
  "warehouse_id": "uuid",
  "lines": [
    {
      "grade": "jumbo | extra_large | large | medium | small",
      "cartons": "integer",
      "unit_price": "decimal",
      "discount_pct": "decimal (default: 0)"
    }
  ],
  "vehicle_id": "uuid (optional)",
  "delivery_date": "date (optional)",
  "payment_terms": "string",
  "notes": "string"
}
```

**Response (201):** Distribution record + auto-generated invoice
**Permissions:** `eggs.distribution.write`

---

### GET /api/v1/eggs/margins
Get egg margin analysis.

**Query Parameters:** date_from, date_to, grade, customer_id

**Response (200):**
```json
{
  "data": {
    "period": "2024-01-01 to 2024-01-15",
    "by_grade": [
      {
        "grade": "extra_large",
        "revenue": 356400.00,
        "feed_cost": 245000.00,
        "packaging_cost": 15000.00,
        "labor_cost": 25000.00,
        "overhead": 18000.00,
        "total_cost": 303000.00,
        "gross_margin": 53400.00,
        "margin_pct": 15.0,
        "margin_per_egg": 0.33
      }
    ],
    "by_customer": [
      {"customer": "Metro Market", "revenue": 200000, "margin_pct": 14.2}
    ],
    "trend": [
      {"date": "2024-01-01", "margin_pct": 14.5},
      {"date": "2024-01-15", "margin_pct": 15.0}
    ]
  }
}
```

**Permissions:** `eggs.reports.read`

---

### GET /api/v1/eggs/forecast
Get egg production forecast.

**Query Parameters:** flock_id, weeks_ahead (default: 4)

**Response (200):**
```json
{
  "data": {
    "flock_id": "uuid",
    "current_age_weeks": 35,
    "forecast": [
      {
        "week": 36,
        "predicted_production_pct": 94.0,
        "predicted_eggs": 23500,
        "confidence_low": 23000,
        "confidence_high": 24000
      }
    ],
    "model": "seasonal_arima",
    "accuracy_historical_pct": 96.5
  }
}
```

**Permissions:** `eggs.read` or `ai.forecast.read`

---

## 1.15 Fleet Management API

### GET /api/v1/fleet/vehicles
List vehicles.

**Query Parameters:**
| Parameter    | Type   | Description                                |
|--------------|--------|--------------------------------------------|
| search       | string | Plate number, model, driver                |
| type         | enum   | `truck`, `van`, `pickup`, `car`, `forklift`, `trailer` |
| status       | enum   | `active`, `maintenance`, `retired`, `sold` |
| branch_id    | uuid   | Filter by branch                           |
| capacity_min | decimal| Minimum capacity                           |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "vehicle_code": "VH-CAI-00125",
      "plate_number": "&#1587; &#1610; &#1575; 1234",
      "plate_number_raw": "SYA 1234",
      "make": "Mercedes-Benz",
      "model": "Actros",
      "year": 2022,
      "vehicle_type": "truck",
      "body_type": "refrigerated_box | flatbed | tanker | curtain_side | dry_box",
      "capacity_kg": 15000,
      "capacity_cbm": 45,
      "fuel_type": "diesel",
      "fuel_consumption_avg_l_per_100km": 32.5,
      "current_odometer_km": 45200,
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "assigned_driver_id": "uuid",
      "assigned_driver_name": "Mohamed Ahmed",
      "gps_device_id": "string",
      "insurance_expiry": "2024-12-31",
      "license_expiry": "2024-06-30",
      "next_service_due_km": 50000,
      "next_service_due_date": "2024-03-15",
      "status": "active",
      "current_location": {"lat": 30.0444, "lng": 31.2357, "updated_at": "2024-01-15T10:30:00+02:00"},
      "is_gps_active": true,
      "current_trip_id": "uuid (optional)",
      "total_trips_ytd": 452,
      "total_km_ytd": 45200,
      "fuel_cost_ytd": 285000.00,
      "maintenance_cost_ytd": 45000.00,
      "created_at": "2022-01-15T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `fleet.read`

---

### GET /api/v1/fleet/vehicles/{id}
Get vehicle detail.

**Response (200):** Full vehicle with maintenance history, trip history, fuel log.
**Permissions:** `fleet.read`

---

### POST /api/v1/fleet/vehicles
Register vehicle.

**Request:**
```json
{
  "vehicle_code": "string (unique)",
  "plate_number": "string",
  "make": "string",
  "model": "string",
  "year": "integer",
  "vehicle_type": "truck | van | pickup | car | forklift | trailer",
  "body_type": "refrigerated_box | flatbed | tanker | curtain_side | dry_box",
  "capacity_kg": "decimal",
  "capacity_cbm": "decimal (optional)",
  "fuel_type": "diesel | gasoline | cng | electric | hybrid",
  "branch_id": "uuid",
  "gps_device_id": "string (optional)",
  "purchase_date": "date (optional)",
  "purchase_cost": "decimal (optional)",
  "insurance_expiry": "date",
  "license_expiry": "date",
  "notes": "string"
}
```

**Response (201):** Created vehicle
**Permissions:** `fleet.write`

---

### GET /api/v1/fleet/drivers
List drivers.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "employee_id": "uuid",
      "name": "Mohamed Ahmed",
      "license_number": "1234567890",
      "license_type": "heavy_truck | light_truck | commercial | private",
      "license_expiry": "2024-12-31",
      "certifications": ["hazmat", "cold_chain"],
      "assigned_vehicle_id": "uuid",
      "assigned_vehicle_plate": "SYA 1234",
      "status": "active | on_leave | suspended | retired",
      "trips_today": 4,
      "trips_this_month": 85,
      "safety_score": 98.5,
      "accidents_count": 0,
      "phone": "+201001234567"
    }
  ]
}
```

**Permissions:** `fleet.read`

---

### GET /api/v1/fleet/trips
List trips.

**Query Parameters:**
| Parameter  | Type   | Description                              |
|------------|--------|------------------------------------------|
| vehicle_id | uuid   | Filter by vehicle                        |
| driver_id  | uuid   | Filter by driver                         |
| status     | enum   | `planned`, `in_progress`, `completed`, `cancelled` |
| date_from  | date   | Trip date range                          |
| date_to    | date   | Trip date range                          |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "trip_number": "TR-2024-008924",
      "vehicle_id": "uuid",
      "vehicle_plate": "SYA 1234",
      "driver_id": "uuid",
      "driver_name": "Mohamed Ahmed",
      "route_id": "uuid",
      "route_name": "Cairo - Giza Loop",
      "trip_date": "2024-01-15",
      "planned_start": "06:00",
      "planned_end": "14:00",
      "actual_start": "06:05",
      "actual_end": "14:30",
      "status": "completed",
      "stops_count": 8,
      "completed_stops": 8,
      "distance_planned_km": 120,
      "distance_actual_km": 128,
      "fuel_consumed_l": 42,
      "fuel_cost": 1260.00,
      "deliveries_count": 8,
      "cargo_weight_kg": 12500,
      "delivery_success_pct": 100,
      "gps_tracking_url": "https://fleet.gff-erp.com/trips/uuid/track",
      "weather_conditions": "clear",
      "notes": "Traffic delay in Dokki",
      "created_at": "2024-01-14T16:00:00+02:00"
    }
  ]
}
```

**Permissions:** `fleet.read`

---

### POST /api/v1/fleet/trips
Create trip.

**Request:**
```json
{
  "vehicle_id": "uuid",
  "driver_id": "uuid",
  "route_id": "uuid (optional)",
  "trip_date": "date",
  "planned_start": "datetime",
  "planned_end": "datetime",
  "stops": [
    {
      "sequence": 1,
      "customer_id": "uuid",
      "address": "string",
      "coordinates": {"lat": "decimal", "lng": "decimal"},
      "estimated_arrival": "datetime",
      "delivery_items": [
        {"product_id": "uuid", "quantity": "decimal"}
      ],
      "special_instructions": "string"
    }
  ],
  "notes": "string"
}
```

**Response (201):** Created trip with optimized route
**Permissions:** `fleet.trips.write`

---

### PUT /api/v1/fleet/trips/{id}/start
Start trip.

**Request:**
```json
{
  "actual_start": "datetime",
  "starting_odometer": "decimal",
  "starting_fuel_level": "decimal (0-100)"
}
```

**Response (200):** Updated trip
**Permissions:** `fleet.trips.execute`

---

### PUT /api/v1/fleet/trips/{id}/complete
Complete trip.

**Request:**
```json
{
  "actual_end": "datetime",
  "ending_odometer": "decimal",
  "ending_fuel_level": "decimal",
  "fuel_consumed_l": "decimal",
  "notes": "string"
}
```

**Response (200):** Completed trip
**Permissions:** `fleet.trips.execute`

---

### GET /api/v1/fleet/fuel
List fuel records.

**Query Parameters:** vehicle_id, driver_id, date_from, date_to, station_id

**Response (200):** Paginated fuel records
**Permissions:** `fleet.read`

---

### POST /api/v1/fleet/fuel
Record fuel transaction.

**Request:**
```json
{
  "vehicle_id": "uuid",
  "driver_id": "uuid",
  "fuel_date": "date",
  "fuel_type": "diesel | gasoline | cng",
  "quantity_liters": "decimal",
  "price_per_liter": "decimal",
  "total_cost": "decimal",
  "odometer_km": "decimal",
  "station_name": "string (optional)",
  "payment_method": "fleet_card | cash | credit",
  "receipt_number": "string",
  "attachments": ["url"]
}
```

**Response (201):** Fuel record
**Permissions:** `fleet.fuel.write`

---

### GET /api/v1/fleet/maintenance
List maintenance records.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "vehicle_id": "uuid",
      "vehicle_plate": "SYA 1234",
      "maintenance_type": "preventive | corrective | breakdown | inspection",
      "service_category": "oil_change | tire | brake | engine | transmission | electrical | body | ac | other",
      "description": "Regular 50,000 km service",
      "scheduled_date": "2024-03-15",
      "completed_date": null,
      "odometer_km": 50000,
      "cost": 8500.00,
      "parts_cost": 5000.00,
      "labor_cost": 3500.00,
      "service_provider": "Authorized Service Center",
      "status": "scheduled",
      "next_due_km": 60000,
      "next_due_date": "2024-06-15",
      "downtime_hours": 8,
      "notes": "",
      "attachments": ["url"]
    }
  ]
}
```

**Permissions:** `fleet.read`

---

### POST /api/v1/fleet/maintenance
Schedule maintenance.

**Request:**
```json
{
  "vehicle_id": "uuid",
  "maintenance_type": "preventive | corrective | breakdown | inspection",
  "service_category": "oil_change | tire | brake | engine | transmission | electrical | body | ac | other",
  "description": "string",
  "scheduled_date": "date",
  "odometer_km": "decimal",
  "estimated_cost": "decimal",
  "service_provider": "string",
  "downtime_hours": "integer",
  "notes": "string"
}
```

**Response (201):** Maintenance record
**Permissions:** `fleet.maintenance.write`

---

### GET /api/v1/fleet/gps/tracking/{vehicle_id}
Get real-time GPS tracking for vehicle.

**Response (200):**
```json
{
  "data": {
    "vehicle_id": "uuid",
    "plate_number": "SYA 1234",
    "timestamp": "2024-01-15T10:30:00+02:00",
    "latitude": 30.0444,
    "longitude": 31.2357,
    "speed_kmh": 65,
    "heading": 180,
    "altitude_m": 23,
    "accuracy_m": 5,
    "engine_status": "running",
    "ignition_status": "on",
    "address": "26th of July Corridor, Zamalek, Cairo",
    "geofence_status": "inside_route",
    "trip_id": "uuid",
    "next_stop": "Al-Amal Farm",
    "estimated_arrival": "2024-01-15T11:15:00+02:00"
  }
}
```

**Permissions:** `fleet.gps.read`

---

### GET /api/v1/fleet/gps/history/{vehicle_id}
Get GPS history.

**Query Parameters:** date_from, date_to, interval (min)

**Response (200):** Array of GPS points
**Permissions:** `fleet.gps.read`

---

### GET /api/v1/fleet/routes
List routes.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "route_code": "RT-CAI-GIZ-01",
      "route_name": "Cairo - Giza Distribution",
      "branch_id": "uuid",
      "branch_name": "Cairo",
      "stops_count": 12,
      "total_distance_km": 85,
      "estimated_duration_hours": 8,
      "average_fuel_l": 28,
      "vehicle_type_required": "truck",
      "active": true,
      "frequency": "daily | weekly | on_demand",
      "customers": [
        {"customer_id": "uuid", "customer_name": "Al-Amal Farm", "sequence": 1, "coordinates": {"lat": 30.0, "lng": 31.1}}
      ]
    }
  ]
}
```

**Permissions:** `fleet.read`

---

### POST /api/v1/fleet/routes
Create route.

**Request:**
```json
{
  "route_code": "string (unique)",
  "route_name": "string",
  "branch_id": "uuid",
  "frequency": "daily | weekly | on_demand",
  "stops": [
    {
      "sequence": 1,
      "customer_id": "uuid",
      "address": "string",
      "coordinates": {"lat": "decimal", "lng": "decimal"},
      "estimated_service_minutes": 30,
      "special_instructions": "string"
    }
  ],
  "is_optimized": true
}
```

**Response (201):** Created route with optimized stop order
**Permissions:** `fleet.routes.write`

---

## 1.16 Delivery Management API

### GET /api/v1/deliveries/assignments
List delivery assignments.

**Query Parameters:**
| Parameter    | Type   | Description                              |
|--------------|--------|------------------------------------------|
| trip_id      | uuid   | Filter by trip                           |
| vehicle_id   | uuid   | Filter by vehicle                        |
| driver_id    | uuid   | Filter by driver                         |
| status       | enum   | `assigned`, `in_transit`, `delivered`, `failed`, `returned` |
| date_from    | date   | Delivery date range                      |
| customer_id  | uuid   | Filter by customer                       |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "assignment_number": "DA-2024-004521",
      "trip_id": "uuid",
      "trip_number": "TR-2024-008924",
      "stop_sequence": 3,
      "invoice_id": "uuid",
      "invoice_number": "SI-2024-001542",
      "customer_id": "uuid",
      "customer_name": "Al-Amal Poultry Farm",
      "customer_address": "El-Wahat Road, km 75, October City",
      "customer_coordinates": {"lat": 29.976, "lng": 30.95},
      "vehicle_id": "uuid",
      "vehicle_plate": "SYA 1234",
      "driver_id": "uuid",
      "driver_name": "Mohamed Ahmed",
      "driver_phone": "+201001234567",
      "items": [
        {"product": "Broiler Feed 25kg", "quantity": 100, "uom": "Bag"}
      ],
      "planned_delivery_time": "2024-01-15T10:00:00+02:00",
      "actual_delivery_time": "2024-01-15T10:15:00+02:00",
      "status": "delivered",
      "pod_status": "signed",
      "recipient_name": "Ahmed Ibrahim",
      "recipient_phone": "+201001234568",
      "delivery_notes": "Delivered to farm warehouse",
      "failure_reason": null,
      "return_items": [],
      "customer_rating": 5,
      "customer_feedback": "On time, good service",
      "gps_delivered_at": {"lat": 29.9761, "lng": 30.9501}
    }
  ]
}
```

**Permissions:** `delivery.read`

---

### GET /api/v1/deliveries/assignments/{id}
Get delivery detail.
**Response (200):** Full delivery with tracking, POD, photos.
**Permissions:** `delivery.read`

---

### POST /api/v1/deliveries/assignments
Create delivery assignment.

**Request:**
```json
{
  "trip_id": "uuid",
  "invoice_ids": ["uuid"],
  "stop_sequence": "integer",
  "planned_delivery_time": "datetime",
  "special_instructions": "string"
}
```

**Response (201):** Created assignment
**Permissions:** `delivery.write`

---

### GET /api/v1/deliveries/tracking/{assignment_id}
Get delivery tracking.

**Response (200):**
```json
{
  "data": {
    "assignment_id": "uuid",
    "status": "in_transit",
    "current_location": {"lat": 29.98, "lng": 30.96},
    "distance_to_destination_km": 5.2,
    "estimated_arrival": "2024-01-15T10:45:00+02:00",
    "milestones": [
      {"status": "assigned", "timestamp": "2024-01-15T08:00:00+02:00"},
      {"status": "picked_up", "timestamp": "2024-01-15T08:30:00+02:00"},
      {"status": "in_transit", "timestamp": "2024-01-15T09:00:00+02:00"}
    ]
  }
}
```

**Permissions:** `delivery.read`

---

### POST /api/v1/deliveries/{id}/pod
Submit proof of delivery.

**Request:**
```json
{
  "delivery_time": "datetime",
  "recipient_name": "string",
  "recipient_phone": "string",
  "recipient_national_id": "string (optional)",
  "signature_image": "string (base64 or URL)",
  "photos": ["url"],
  "notes": "string",
  "gps_location": {"lat": "decimal", "lng": "decimal"},
  "customer_rating": "integer (1-5, optional)",
  "customer_feedback": "string (optional)"
}
```

**Response (201):** POD record
**Permissions:** `delivery.pod.write`

---

### POST /api/v1/deliveries/{id}/return
Record delivery return.

**Request:**
```json
{
  "return_reason": "damaged | wrong_item | refused | not_ordered | customer_closed",
  "return_items": [
    {
      "product_id": "uuid",
      "quantity": "decimal",
      "condition": "good | damaged | opened",
      "reason": "string"
    }
  ],
  "photos": ["url"],
  "notes": "string"
}
```

**Response (201):** Return record
**Permissions:** `delivery.returns.write`

---

### GET /api/v1/deliveries/analytics
Get delivery analytics.

**Response (200):**
```json
{
  "data": {
    "period": "2024-01-01 to 2024-01-15",
    "total_deliveries": 4520,
    "on_time_deliveries": 4280,
    "on_time_pct": 94.7,
    "failed_deliveries": 85,
    "failed_pct": 1.9,
    "returned_deliveries": 155,
    "returned_pct": 3.4,
    "average_delivery_time_minutes": 45,
    "customer_satisfaction_avg": 4.7,
    "by_driver": [
      {"driver_id": "uuid", "driver_name": "Mohamed Ahmed", "deliveries": 180, "on_time_pct": 96.0}
    ],
    "by_route": [
      {"route_id": "uuid", "route_name": "Cairo-Giza", "deliveries": 1200, "on_time_pct": 93.0}
    ]
  }
}
```

**Permissions:** `delivery.reports.read` or `dashboard.view`

---

## 1.17 Human Resources API

### GET /api/v1/hr/employees
List employees.

**Query Parameters:**
| Parameter      | Type   | Description                                |
|----------------|--------|--------------------------------------------|
| search         | string | Name, code, national ID                    |
| branch_id      | uuid   | Filter by branch                           |
| department_id  | uuid   | Filter by department                       |
| position_id    | uuid   | Filter by position                         |
| status         | enum   | `active`, `on_leave`, `suspended`, `terminated`, `resigned` |
| employment_type| enum   | `full_time`, `part_time`, `contract`, `seasonal` |
| hire_date_from | date   | Hire date range                            |
| hire_date_to   | date   | Hire date range                            |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "employee_code": "EMP-2024-004521",
      "full_name_ar": "محمد أحمد إبراهيم",
      "full_name_en": "Mohamed Ahmed Ibrahim",
      "national_id": "2850405010XXXXX",
      "date_of_birth": "1985-04-05",
      "gender": "male",
      "marital_status": "married",
      "photo_url": "https://cdn.gff-erp.com/employees/uuid.jpg",
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "department_id": "uuid",
      "department_name": "Sales",
      "position_id": "uuid",
      "position_name": "Senior Sales Representative",
      "job_level": 4,
      "employment_type": "full_time",
      "hire_date": "2020-01-15",
      "probation_end_date": "2020-04-15",
      "contract_end_date": null,
      "reporting_to_id": "uuid",
      "reporting_to_name": "Khaled Mahmoud",
      "basic_salary": 8500.00,
      "total_allowances": 3500.00,
      "gross_salary": 12000.00,
      "social_insurance_number": "1234567890",
      "social_insurance_salary": 8500.00,
      "medical_insurance": true,
      "medical_insurance_provider": "Misr Insurance",
      "phone": "+201001234567",
      "email": "mohamed.ibrahim@gff.com",
      "emergency_contact": {"name": "Fatma Ibrahim", "phone": "+201098765432", "relation": "spouse"},
      "address": {"street": "15 El-Tahrir St.", "city": "Dokki", "governorate": "Giza"},
      "status": "active",
      "last_attendance": "2024-01-15",
      "annual_leave_balance": 15,
      "sick_leave_balance": 10,
      "created_at": "2020-01-10T10:00:00+02:00"
    }
  ]
}
```

**Permissions:** `hr.read`

---

### GET /api/v1/hr/employees/{id}
Get employee detail.

**Response (200):** Full employee with salary history, attendance, leaves, documents.
**Permissions:** `hr.read`

---

### POST /api/v1/hr/employees
Create employee.

**Request:**
```json
{
  "employee_code": "string (auto if omitted)",
  "full_name_ar": "string",
  "full_name_en": "string",
  "national_id": "string (14 digits)",
  "date_of_birth": "date",
  "gender": "male | female",
  "marital_status": "single | married | divorced | widowed",
  "branch_id": "uuid",
  "department_id": "uuid",
  "position_id": "uuid",
  "employment_type": "full_time | part_time | contract | seasonal",
  "hire_date": "date",
  "probation_months": "integer (default: 3)",
  "contract_end_date": "date (optional)",
  "reporting_to_id": "uuid",
  "basic_salary": "decimal",
  "allowances": [
    {"allowance_type": "housing | transportation | meals | phone | other", "amount": "decimal"}
  ],
  "social_insurance_salary": "decimal",
  "phone": "string",
  "email": "string",
  "emergency_contact": {"name": "string", "phone": "string", "relation": "string"},
  "address": {"street": "string", "city": "string", "governorate": "string", "postal_code": "string"},
  "documents": ["url"],
  "notes": "string"
}
```

**Response (201):** Created employee
**Permissions:** `hr.write`

---

### PUT /api/v1/hr/employees/{id}
Update employee.
**Permissions:** `hr.write`

---

### PUT /api/v1/hr/employees/{id}/status
Change employee status.

**Request:**
```json
{
  "status": "active | on_leave | suspended | terminated | resigned",
  "effective_date": "date",
  "reason": "string",
  "termination_type": "voluntary | involuntary | retirement | end_of_contract (if applicable)"
}
```

**Permissions:** `hr.status.manage`

---

### GET /api/v1/hr/attendance
List attendance records.

**Query Parameters:** employee_id, branch_id, department_id, date_from, date_to, status

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "employee_id": "uuid",
      "employee_name": "Mohamed Ahmed",
      "employee_code": "EMP-2024-004521",
      "branch_id": "uuid",
      "date": "2024-01-15",
      "check_in": "08:05:00",
      "check_out": "17:00:00",
      "check_in_location": {"lat": 30.0444, "lng": 31.2357},
      "check_out_location": {"lat": 30.0444, "lng": 31.2357},
      "work_hours": 8.92,
      "overtime_hours": 0.92,
      "late_minutes": 5,
      "early_departure_minutes": 0,
      "status": "present | absent | late | early_departure | on_leave | holiday",
      "shift_id": "uuid",
      "shift_name": "Morning Shift",
      "notes": "",
      "device_id": "string",
      "biometric_verified": true
    }
  ]
}
```

**Permissions:** `hr.attendance.read`

---

### POST /api/v1/hr/attendance/check-in
Record check-in.

**Request:**
```json
{
  "employee_id": "uuid",
  "timestamp": "datetime (default: now)",
  "location": {"lat": "decimal", "lng": "decimal"},
  "device_id": "string",
  "biometric_data": "string (optional, hashed)",
  "notes": "string"
}
```

**Response (201):** Check-in record
**Permissions:** `hr.attendance.write` (self) or `hr.attendance.manage`

---

### POST /api/v1/hr/attendance/check-out
Record check-out.

**Request:**
```json
{
  "employee_id": "uuid",
  "timestamp": "datetime",
  "location": {"lat": "decimal", "lng": "decimal"},
  "notes": "string"
}
```

**Response (200):** Check-out record with hours calculated
**Permissions:** `hr.attendance.write` or `hr.attendance.manage`

---

### GET /api/v1/hr/payroll
List payroll records.

**Query Parameters:** month, year, branch_id, department_id, status

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "payroll_number": "PR-2024-01",
      "month": 1,
      "year": 2024,
      "branch_id": "uuid",
      "branch_name": "Cairo HQ",
      "employee_count": 250,
      "total_basic_salary": 2125000.00,
      "total_allowances": 875000.00,
      "total_overtime": 125000.00,
      "total_gross": 3125000.00,
      "total_deductions": 625000.00,
      "total_social_insurance": 312500.00,
      "total_taxes": 156250.00,
      "total_net": 2343750.00,
      "status": "draft | calculated | approved | paid",
      "processed_by": "uuid",
      "processed_at": "2024-01-25T10:00:00+02:00"
    }
  ]
}
```

**Permissions:** `hr.payroll.read`

---

### GET /api/v1/hr/payroll/{id}/lines
Get payroll lines.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "payroll_id": "uuid",
      "employee_id": "uuid",
      "employee_name": "Mohamed Ahmed",
      "employee_code": "EMP-2024-004521",
      "basic_salary": 8500.00,
      "allowances": {
        "housing": 2000.00,
        "transportation": 1000.00,
        "meals": 500.00
      },
      "overtime_hours": 8,
      "overtime_amount": 850.00,
      "commissions": 2500.00,
      "bonuses": 0.00,
      "gross_salary": 15350.00,
      "deductions": {
        "absence": 0.00,
        "late": 50.00,
        "loan": 500.00,
        "other": 0.00
      },
      "social_insurance_employee": 850.00,
      "social_insurance_employer": 1700.00,
      "taxable_income": 13700.00,
      "tax_amount": 685.00,
      "net_salary": 13015.00,
      "payment_method": "bank_transfer",
      "bank_account": "1234567890",
      "payment_status": "pending"
    }
  ]
}
```

**Permissions:** `hr.payroll.read`

---

### POST /api/v1/hr/payroll
Create payroll run.

**Request:**
```json
{
  "month": "integer (1-12)",
  "year": "integer",
  "branch_id": "uuid (optional, for branch-specific payroll)",
  "pay_date": "date",
  "notes": "string"
}
```

**Response (201):** Created payroll (auto-calculates all lines)
**Permissions:** `hr.payroll.write`

---

### PUT /api/v1/hr/payroll/{id}/calculate
Calculate payroll.
**Response (200):** Calculated payroll with summary
**Permissions:** `hr.payroll.write`

---

### PUT /api/v1/hr/payroll/{id}/approve
Approve payroll.
**Permissions:** `hr.payroll.approve`

---

### PUT /api/v1/hr/payroll/{id}/pay
Process payments.
**Permissions:** `hr.payroll.pay`

---

### GET /api/v1/hr/leaves
List leave records.

**Query Parameters:** employee_id, branch_id, type, status, date_from, date_to

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "leave_number": "LV-2024-001245",
      "employee_id": "uuid",
      "employee_name": "Mohamed Ahmed",
      "leave_type": "annual | sick | emergency | maternity | paternity | unpaid | pilgrimage | bereavement",
      "start_date": "2024-02-01",
      "end_date": "2024-02-07",
      "days": 7,
      "reason": "Family vacation",
      "status": "approved",
      "approved_by_id": "uuid",
      "approved_by_name": "Khaled Mahmoud",
      "approved_at": "2024-01-15T10:00:00+02:00",
      "is_paid": true,
      "balance_before": 21,
      "balance_after": 14,
      "attachments": ["url"],
      "created_at": "2024-01-10T09:00:00+02:00"
    }
  ]
}
```

**Permissions:** `hr.leaves.read`

---

### POST /api/v1/hr/leaves
Submit leave request.

**Request:**
```json
{
  "employee_id": "uuid",
  "leave_type": "annual | sick | emergency | maternity | paternity | unpaid | pilgrimage | bereavement",
  "start_date": "date",
  "end_date": "date",
  "reason": "string",
  "attachments": ["url"]
}
```

**Response (201):** Leave request (status: pending)
**Permissions:** `hr.leaves.write` (self) or `hr.leaves.manage`

---

### PUT /api/v1/hr/leaves/{id}/approve
Approve leave.

**Request:**
```json
{
  "approved": true,
  "notes": "string (optional)"
}
```

**Permissions:** `hr.leaves.approve`

---

### PUT /api/v1/hr/leaves/{id}/reject
Reject leave.

**Request:**
```json
{
  "reason": "string (required)"
}
```

**Permissions:** `hr.leaves.approve`

---

### GET /api/v1/hr/commissions
List commission records.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "employee_id": "uuid",
      "employee_name": "Khaled Mahmoud",
      "commission_period": "2024-01",
      "commission_type": "sales | collection | target_bonus | referral",
      "base_amount": 285000.00,
      "commission_rate": 1.5,
      "commission_amount": 4275.00,
      "tier": "gold",
      "targets_achieved": 3,
      "status": "calculated | approved | paid",
      "paid_at": null
    }
  ]
}
```

**Permissions:** `hr.commissions.read`

---

### POST /api/v1/hr/commissions/calculate
Calculate commissions for period.

**Request:**
```json
{
  "month": "integer",
  "year": "integer",
  "employee_ids": ["uuid (optional, all if omitted)"],
  "commission_type": "sales | collection | all"
}
```

**Response (200):** Calculated commissions summary
**Permissions:** `hr.commissions.calculate`

---

### GET /api/v1/hr/org-chart
Get organizational chart.

**Response (200):**
```json
{
  "data": {
    "company": "GFF Group",
    "ceo": {"id": "uuid", "name": "CEO Name", "title": "Chief Executive Officer"},
    "departments": [
      {
        "id": "uuid",
        "name": "Operations",
        "head": {"id": "uuid", "name": "COO Name", "title": "Chief Operations Officer"},
        "employees": 450,
        "children": [
          {
            "id": "uuid",
            "name": "Production",
            "head": {"id": "uuid", "name": "Production Manager", "title": "Production Director"},
            "employees": 200
          }
        ]
      }
    ]
  }
}
```

**Permissions:** `hr.read` or `org.chart.view`

---

### GET /api/v1/hr/departments
List departments.
**Permissions:** `hr.read`

### POST /api/v1/hr/departments
Create department.

**Request:**
```json
{
  "name_ar": "string",
  "name_en": "string",
  "parent_id": "uuid (optional)",
  "manager_id": "uuid (optional)",
  "branch_id": "uuid",
  "cost_center_id": "uuid (optional)",
  "budget": "decimal (optional)"
}
```

**Permissions:** `hr.departments.manage`

---

### GET /api/v1/hr/positions
List positions.
**Permissions:** `hr.read`

### POST /api/v1/hr/positions
Create position.

**Request:**
```json
{
  "title_ar": "string",
  "title_en": "string",
  "department_id": "uuid",
  "level": "integer (1-10)",
  "min_salary": "decimal",
  "max_salary": "decimal",
  "job_description": "string",
  "required_qualifications": ["string"]
}
```

**Permissions:** `hr.positions.manage`

---

## 1.18 Branch Management API

### GET /api/v1/branches
List branches.

**Query Parameters:**
| Parameter   | Type   | Description                              |
|-------------|--------|------------------------------------------|
| search      | string | Branch name, code, city                  |
| status      | enum   | `active`, `inactive`, `under_construction` |
| region      | string | Filter by region                         |
| governorat  | string | Filter by governorate                    |
| has_warehouse| bool  | Has warehouse                            |

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "branch_code": "BR-CAI-001",
      "name_ar": "القاهرة - المركز الرئيسي",
      "name_en": "Cairo - Headquarters",
      "branch_type": "headquarters | regional | city | rural | factory | farm",
      "status": "active",
      "region": "Greater Cairo",
      "governorate": "Cairo",
      "city": "Nasr City",
      "address": "15 El-Tahrir St., Nasr City",
      "coordinates": {"lat": 30.0444, "lng": 31.2357},
      "phone": "+20226700000",
      "fax": "+20226700001",
      "email": "cairo.hq@gff.com",
      "manager_id": "uuid",
      "manager_name": "Ahmed Hassan",
      "opening_date": "2010-01-01",
      "employee_count": 350,
      "warehouse_count": 3,
      "sales_target_monthly": 5000000.00,
      "sales_actual_monthly": 4850000.00,
      "target_achievement_pct": 97.0,
      "operating_hours": "08:00-17:00",
      "working_days": "saturday-thursday",
      "is_active": true,
      "created_at": "2010-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `branches.read`

---

### GET /api/v1/branches/{id}
Get branch detail with KPIs.

**Response (200):** Full branch with targets, performance, employees.
**Permissions:** `branches.read`

---

### POST /api/v1/branches
Create branch.

**Request:**
```json
{
  "branch_code": "string (unique)",
  "name_ar": "string",
  "name_en": "string",
  "branch_type": "headquarters | regional | city | rural | factory | farm",
  "region": "string",
  "governorate": "string",
  "city": "string",
  "address": "string",
  "coordinates": {"lat": "decimal", "lng": "decimal"},
  "phone": "string",
  "email": "string",
  "manager_id": "uuid (optional)",
  "opening_date": "date",
  "operating_hours": "string",
  "working_days": "string",
  "sales_target_monthly": "decimal",
  "notes": "string"
}
```

**Response (201):** Created branch
**Permissions:** `branches.write`

---

### PUT /api/v1/branches/{id}/targets
Set branch targets.

**Request:**
```json
{
  "year": 2024,
  "monthly_targets": [
    {"month": 1, "sales_target": 5000000, "customer_target": 50, "collection_target": 4500000},
    {"month": 2, "sales_target": 4800000, "customer_target": 45, "collection_target": 4300000}
  ],
  "annual_targets": {
    "revenue": 60000000,
    "new_customers": 600,
    "market_share_pct": 15.0
  }
}
```

**Response (200):** Updated targets
**Permissions:** `branches.targets.manage`

---

### GET /api/v1/branches/{id}/performance
Get branch performance.

**Response (200):**
```json
{
  "data": {
    "branch_id": "uuid",
    "period": "2024-01-01 to 2024-01-15",
    "sales": {
      "target": 5000000.00,
      "actual": 4850000.00,
      "achievement_pct": 97.0,
      "vs_last_month_pct": 5.2,
      "vs_last_year_pct": 12.8
    },
    "customers": {
      "new": 28,
      "active": 450,
      "target": 50
    },
    "collections": {
      "target": 4500000.00,
      "actual": 4200000.00,
      "achievement_pct": 93.3
    },
    "inventory": {
      "stock_value": 8500000.00,
      "turnover_days": 12.5
    },
    "employees": {
      "count": 350,
      "attendance_pct": 96.5,
      "turnover_pct": 2.1
    }
  }
}
```

**Permissions:** `branches.read` or `dashboard.view`

---

### GET /api/v1/branches/comparison
Compare branches.

**Query Parameters:** branch_ids[], metric (sales|profit|customers|growth), period

**Response (200):**
```json
{
  "data": {
    "branches": [
      {"branch_id": "uuid", "branch_name": "Cairo", "sales": 4850000, "rank": 1},
      {"branch_id": "uuid", "branch_name": "Alexandria", "sales": 3200000, "rank": 2}
    ],
    "top_performer": "Cairo",
    "most_improved": "Tanta",
    "needs_attention": ["Aswan"]
  }
}
```

**Permissions:** `branches.comparison.read` or `executive.reports`

---

### GET /api/v1/branches/{id}/transfers
List inter-branch transfers.
**Permissions:** `branches.read`

---

## 1.19 Reports & Analytics API

### GET /api/v1/reports/sales
Sales report with filters.

**Query Parameters:**
| Parameter     | Type   | Description                              |
|---------------|--------|------------------------------------------|
| date_from     | date   | Period start                             |
| date_to       | date   | Period end                               |
| branch_id     | uuid   | Filter by branch                         |
| customer_id   | uuid   | Filter by customer                       |
| product_id    | uuid   | Filter by product                        |
| sales_rep_id  | uuid   | Filter by sales rep                      |
| channel       | enum   | Sales channel                            |
| group_by      | enum   | `day`, `week`, `month`, `quarter`, `year`, `product`, `customer`, `branch`, `sales_rep` |

**Response (200):**
```json
{
  "data": {
    "summary": {
      "total_revenue": 28500000.00,
      "total_invoices": 12500,
      "total_quantity": 1250000,
      "avg_invoice_value": 2280.00,
      "total_discounts": 285000.00,
      "total_tax": 3990000.00,
      "total_cost": 18500000.00,
      "gross_profit": 10000000.00,
      "gross_margin_pct": 35.1
    },
    "breakdown": [
      {"period": "2024-01-01", "revenue": 1800000, "invoices": 800, "quantity": 85000},
      {"period": "2024-01-02", "revenue": 1950000, "invoices": 850, "quantity": 92000}
    ]
  }
}
```

**Permissions:** `reports.sales.read`

---

### GET /api/v1/reports/inventory
Inventory report.

**Query Parameters:** warehouse_id, branch_id, category_id, date, include_valuation

**Response (200):**
```json
{
  "data": {
    "as_of": "2024-01-15",
    "total_stock_value": 28500000.00,
    "total_items": 450,
    "categories": [
      {"category": "Broiler Feed", "value": 12000000, "pct": 42.1},
      {"category": "Layer Feed", "value": 8500000, "pct": 29.8}
    ],
    "warehouses": [
      {"warehouse": "Cairo Main", "value": 15000000, "items": 280}
    ],
    "slow_moving": [...],
    "expiring_soon": [...],
    "stock_out_risk": [...]
  }
}
```

**Permissions:** `reports.inventory.read`

---

### GET /api/v1/reports/financial
Financial reports.

**Query Parameters:**
| Parameter     | Type   | Description                              |
|---------------|--------|------------------------------------------|
| report_type   | enum   | `income_statement`, `balance_sheet`, `cash_flow`, `trial_balance` |
| date_from     | date   | Period start                             |
| date_to       | date   | Period end                               |
| branch_id     | uuid   | Filter by branch                         |
| as_of         | date   | For balance sheet                        |
| compare_to    | date   | Comparison period                        |

**Response (200):** Report data based on type
**Permissions:** `reports.financial.read`

---

### GET /api/v1/reports/production
Production report.

**Query Parameters:** date_from, date_to, line_id, product_id, branch_id, group_by

**Response (200):** Production summary with efficiency metrics
**Permissions:** `reports.production.read`

---

### GET /api/v1/reports/customers
Customer report.

**Query Parameters:** date_from, date_to, branch_id, classification, group_by, top_n

**Response (200):**
```json
{
  "data": {
    "total_customers": 450,
    "new_customers": 28,
    "active_customers": 380,
    "dormant_customers": 42,
    "total_sales": 28500000.00,
    "total_receivables": 4200000.00,
    "average_payment_days": 22,
    "top_customers": [
      {"customer_id": "uuid", "name": "Al-Amal Farm", "sales": 850000, "pct": 29.8}
    ]
  }
}
```

**Permissions:** `reports.customers.read`

---

### GET /api/v1/reports/employees
Employee report.

**Query Parameters:** branch_id, department_id, status, date_from, date_to

**Response (200):** Employee statistics and analytics
**Permissions:** `reports.hr.read`

---

### GET /api/v1/reports/executive
Executive dashboard report.

**Response (200):**
```json
{
  "data": {
    "date": "2024-01-15",
    "company_kpis": {
      "revenue_ytd": 28500000.00,
      "revenue_target": 60000000.00,
      "revenue_achievement_pct": 47.5,
      "net_profit_ytd": 2850000.00,
      "net_margin_pct": 10.0,
      "cash_balance": 12500000.00,
      "total_receivables": 8500000.00,
      "total_payables": 6200000.00,
      "working_capital": 6300000.00,
      "inventory_value": 28500000.00,
      "debt_equity_ratio": 0.35
    },
    "operational_kpis": {
      "active_branches": 850,
      "total_employees": 8500,
      "production_tons_ytd": 12500,
      "delivery_on_time_pct": 94.5,
      "customer_satisfaction": 4.7,
      "employee_turnover_pct": 8.5
    },
    "trend_comparison": {
      "revenue_vs_last_year_pct": 15.2,
      "profit_vs_last_year_pct": 12.8,
      "customers_vs_last_year_pct": 18.5
    }
  }
}
```

**Permissions:** `reports.executive.read`

---

### POST /api/v1/reports/custom
Generate custom report.

**Request:**
```json
{
  "report_name": "string",
  "data_source": "sales | inventory | financial | production | customers | employees",
  "filters": {
    "date_from": "date",
    "date_to": "date",
    "branch_id": "uuid",
    "group_by": "string"
  },
  "columns": [
    {"field": "revenue", "aggregation": "sum", "alias": "Total Revenue"},
    {"field": "quantity", "aggregation": "sum", "alias": "Total Quantity"}
  ],
  "sort": [{"field": "revenue", "direction": "desc"}],
  "format": "json | csv | xlsx | pdf"
}
```

**Response (200):** Report data in requested format
**Permissions:** `reports.custom.read`

---

### POST /api/v1/reports/schedule
Schedule report generation.

**Request:**
```json
{
  "report_template_id": "uuid",
  "frequency": "daily | weekly | monthly | quarterly",
  "recipients": ["email@example.com"],
  "format": "pdf | xlsx | csv",
  "delivery_method": "email | download",
  "active": true
}
```

**Response (201):** Scheduled report
**Permissions:** `reports.schedule.manage`

---

## 1.20 AI & Machine Learning API

### POST /api/v1/ai/forecast/sales
Sales forecast.

**Request:**
```json
{
  "product_ids": ["uuid (optional, all if omitted)"],
  "branch_ids": ["uuid (optional)"],
  "customer_ids": ["uuid (optional)"],
  "forecast_periods": 30,
  "period_unit": "day | week | month",
  "model": "auto | arima | prophet | lstm | ensemble",
  "include_confidence_intervals": true,
  "external_factors": {
    "include_weather": true,
    "include_seasonality": true,
    "include_holidays": true,
    "include_economic_indicators": false
  }
}
```

**Response (200):**
```json
{
  "data": {
    "model_used": "ensemble",
    "model_accuracy_mape": 4.2,
    "forecast": [
      {
        "period": "2024-01-16",
        "predicted_value": 1850000.00,
        "confidence_low": 1750000.00,
        "confidence_high": 1950000.00,
        "contributing_factors": [
          {"factor": "day_of_week", "impact": "positive", "weight": 0.15},
          {"factor": "temperature", "impact": "negative", "weight": -0.08}
        ]
      }
    ],
    "recommendation": "Increase broiler feed stock by 10% for expected demand surge next week."
  }
}
```

**Permissions:** `ai.forecast.read`
**Rate Limit:** Enterprise tier, 100 requests/day

---

### POST /api/v1/ai/predict/demand
Demand prediction for inventory planning.

**Request:**
```json
{
  "product_ids": ["uuid"],
  "warehouse_ids": ["uuid"],
  "lead_time_days": 7,
  "safety_stock_pct": 10,
  "service_level_target": 95.0
}
```

**Response (200):**
```json
{
  "data": [
    {
      "product_id": "uuid",
      "product_name": "Broiler Feed 25kg",
      "current_stock": 5000,
      "predicted_demand_next_7d": 3200,
      "predicted_demand_next_30d": 12800,
      "recommended_order_quantity": 3000,
      "stockout_risk_pct": 8.5,
      "confidence": 92.0
    }
  ]
}
```

**Permissions:** `ai.predict.read`

---

### POST /api/v1/ai/recommend/pricing
Dynamic pricing recommendation.

**Request:**
```json
{
  "product_ids": ["uuid (optional)"],
  "customer_segment": "a | b | c | d",
  "branch_ids": ["uuid (optional)"],
  "objective": "maximize_revenue | maximize_margin | clear_inventory | market_share",
  "constraints": {
    "min_margin_pct": 10.0,
    "max_discount_pct": 15.0,
    "price_change_limit_pct": 5.0
  }
}
```

**Response (200):**
```json
{
  "data": [
    {
      "product_id": "uuid",
      "product_name": "Broiler Feed 25kg",
      "current_price": 320.00,
      "recommended_price": 325.00,
      "price_change_pct": 1.56,
      "expected_demand_change_pct": -0.8,
      "expected_revenue_change_pct": 0.75,
      "expected_margin_change_pct": 1.2,
      "reasoning": "Low price elasticity detected. Competitor prices are 2-5% higher.",
      "confidence": 78.0
    }
  ]
}
```

**Permissions:** `ai.pricing.read`

---

### POST /api/v1/ai/nlp/query
Natural language query interface.

**Request:**
```json
{
  "query": "ما هي مبيعات فرع القاهرة لشهر يناير؟",
  "language": "ar-EG | en-US",
  "context": {
    "user_branch_id": "uuid",
    "user_role": "branch_manager"
  },
  "response_format": "json | text | chart_data"
}
```

**Response (200):**
```json
{
  "data": {
    "query_understood": true,
    "intent": "sales_report",
    "parameters": {
      "branch": "Cairo",
      "period": "2024-01",
      "metric": "sales"
    },
    "result": {
      "text": "مبيعات فرع القاهرة لشهر يناير 2024 بلغت 4,850,000 جنيه مصري من خلال 2,150 فاتورة.",
      "value": 4850000.00,
      "comparison": {"last_month": 4600000, "change_pct": 5.4},
      "chart_data": [...]
    },
    "suggested_queries": [
      "Compare Cairo with Alexandria sales",
      "Show Cairo sales by product",
      "What is Cairo's profit margin?"
    ]
  }
}
```

**Permissions:** `ai.nlp.query`
**Rate Limit:** Enterprise tier, 500 requests/day

---

### POST /api/v1/ai/recommend/feed-formulation
Recommend optimal feed formulation.

**Request:**
```json
{
  "target_product_id": "uuid",
  "optimization_goal": "minimize_cost | maximize_quality | balanced",
  "current_ingredient_prices": {
    "ingredient_id": "price_per_kg"
  },
  "constraints": {
    "max_cost_per_ton": "decimal (optional)",
    "min_nutrients": {"protein_pct": 22.0},
    "locked_ingredients": ["ingredient_id"]
  }
}
```

**Response (200):**
```json
{
  "data": {
    "formulation_id": "uuid",
    "predicted_cost_per_ton": 10850.00,
    "savings_vs_current_pct": 3.2,
    "nutritional_compliance": "all_met",
    "ingredient_mix": [
      {"ingredient_id": "uuid", "name": "Yellow Corn", "pct": 52.0}
    ],
    "confidence": 88.5
  }
}
```

**Permissions:** `ai.feed.read`

---

### GET /api/v1/ai/models/status
Get AI model status and performance.

**Response (200):**
```json
{
  "data": {
    "models": [
      {
        "model_id": "sales_forecast_v3",
        "model_type": "ensemble",
        "status": "active",
        "last_trained": "2024-01-10T00:00:00+02:00",
        "training_data_rows": 2500000,
        "accuracy_mape": 4.2,
        "latency_ms": 150,
        "prediction_count_today": 1250
      }
    ],
    "system_status": "healthy",
    "queue_depth": 5,
    "gpu_utilization_pct": 45.0
  }
}
```

**Permissions:** `ai.admin.read`

---

## 1.21 System Settings API

### GET /api/v1/settings/company
Get company settings.

**Response (200):**
```json
{
  "data": {
    "company_name_ar": "مجموعة الشرق الأوسط للأعلاف والدواجن",
    "company_name_en": "Middle East Feed & Poultry Group (GFF)",
    "trade_name": "GFF",
    "legal_form": "joint_stock",
    "tax_id": "123456789",
    "commercial_register": "56432",
    "establishment_date": "2005-06-01",
    "headquarters_address": {
      "street": "15 El-Tahrir St.",
      "city": "Nasr City",
      "governorate": "Cairo",
      "postal_code": "11765"
    },
    "contact": {
      "phone": "+20226700000",
      "fax": "+20226700001",
      "email": "info@gff.com",
      "website": "www.gff.com"
    },
    "logo_url": "https://cdn.gff-erp.com/logo.png",
    "default_currency": "EGP",
    "default_language": "ar-EG",
    "default_timezone": "Africa/Cairo",
    "fiscal_year_start_month": 7,
    "base_currency": "EGP",
    "supported_currencies": ["EGP", "USD", "EUR", "SAR", "AED"]
  }
}
```

**Permissions:** `settings.read`

---

### PUT /api/v1/settings/company
Update company settings.
**Permissions:** `settings.company.write`

---

### GET /api/v1/settings/system
Get system settings.

**Response (200):**
```json
{
  "data": {
    "maintenance_mode": false,
    "maintenance_message": "",
    "scheduled_maintenance": {
      "start": null,
      "end": null
    },
    "features_enabled": {
      "e_invoicing": true,
      "multi_branch": true,
      "advanced_analytics": true,
      "ai_predictions": true,
      "live_gps_tracking": true,
      "biometric_attendance": true,
      "webhooks": true
    },
    "email_settings": {
      "smtp_host": "smtp.gff.com",
      "smtp_port": 587,
      "sender_email": "noreply@gff.com",
      "sender_name": "GFF ERP"
    },
    "sms_settings": {
      "provider": "vodafone_egypt",
      "sender_id": "GFF-ERP"
    },
    "notification_settings": {
      "low_stock_alert": true,
      "low_stock_threshold_pct": 10,
      "payment_due_alert": true,
      "payment_due_days_before": 3,
      "maintenance_due_alert": true,
      "birth_due_alert": true,
      "vaccination_due_alert": true
    },
    "backup_settings": {
      "automatic_backup": true,
      "backup_frequency": "daily",
      "backup_time": "02:00",
      "retention_days": 90,
      "last_backup": "2024-01-15T02:00:00+02:00"
    }
  }
}
```

**Permissions:** `settings.system.read`

---

### PUT /api/v1/settings/system
Update system settings.
**Permissions:** `settings.system.write` (Admin only)

---

### GET /api/v1/settings/financial
Get financial settings.

**Response (200):**
```json
{
  "data": {
    "default_payment_terms": "net_30",
    "default_tax_code_id": "uuid",
    "default_currency": "EGP",
    "decimal_places": 2,
    "inventory_valuation_method": "weighted_average",
    "costing_method": "standard",
    "depreciation_method": "straight_line",
    "allow_negative_inventory": false,
    "automatic_journal_entries": true,
    "approval_workflows": {
      "purchase_orders_above": 50000.00,
      "sales_discounts_above_pct": 10.0,
      "payments_above": 100000.00,
      "journal_entries_manual": true
    }
  }
}
```

**Permissions:** `settings.financial.read`

---

### PUT /api/v1/settings/financial
Update financial settings.
**Permissions:** `settings.financial.write`

---

### GET /api/v1/settings/inventory
Get inventory settings.

**Response (200):**
```json
{
  "data": {
    "default_warehouse_id": "uuid",
    "valuation_method": "weighted_average",
    "track_batch_by_default": true,
    "track_expiry_by_default": true,
    "auto_reorder_enabled": true,
    "reorder_approval_required_above": 100000.00,
    "stock_count_frequency_days": 30,
    "negative_stock_allowed": false,
    "default_uom_id": "uuid",
    "barcode_format": "EAN-13"
  }
}
```

**Permissions:** `settings.inventory.read`

---

### POST /api/v1/settings/backup/trigger
Trigger manual backup.
**Response (202):** Backup started
**Permissions:** `settings.backup.manage`

---

### GET /api/v1/settings/backup/history
Get backup history.
**Response (200):** List of backups
**Permissions:** `settings.backup.read`

---

### POST /api/v1/settings/backup/restore
Restore from backup.

**Request:**
```json
{
  "backup_id": "uuid",
  "restore_point": "datetime (optional)",
  "restore_type": "full | partial",
  "partial_modules": ["sales", "inventory"]
}
```

**Response (202):** Restore initiated
**Permissions:** `settings.backup.restore` (Admin only)

---

## 1.22 WebSocket Real-Time API

### Connection Endpoint
```
wss://api.gff-erp.com/ws/v1?token=<jwt_token>&tenant_id=<tenant_id>
```

### Connection Parameters (Query String)
| Parameter  | Required | Description                              |
|------------|----------|------------------------------------------|
| token      | Yes      | JWT access token                         |
| tenant_id  | Yes      | Tenant identifier                        |
| device_id  | Yes      | Device UUID                              |
| channels   | No       | Comma-separated channel names to subscribe |

### WebSocket Message Protocol
All messages use JSON format:
```json
{
  "type": "subscribe | unsubscribe | event | heartbeat | ack | error",
  "channel": "gps.vehicles | notifications.user | dashboard.live | inventory.alerts | production.live",
  "payload": {},
  "timestamp": "2024-01-15T10:30:00+02:00",
  "message_id": "uuid"
}
```

### Subscribe Message
```json
{
  "type": "subscribe",
  "channel": "gps.vehicles",
  "filters": {
    "vehicle_ids": ["uuid"],
    "branch_id": "uuid"
  },
  "message_id": "uuid"
}
```

### Available Channels

| Channel | Direction | Description | Payload Schema |
|---------|-----------|-------------|----------------|
| `gps.vehicles` | Server->Client | Real-time vehicle GPS updates | `{vehicle_id, lat, lng, speed, timestamp}` |
| `gps.vehicle.{id}` | Server->Client | Single vehicle GPS stream | `{lat, lng, speed, heading, engine_status}` |
| `notifications.user.{user_id}` | Server->Client | User notifications | `{notification_id, type, title, message, data}` |
| `notifications.branch.{branch_id}` | Server->Client | Branch-wide notifications | Same as above |
| `dashboard.live.sales` | Server->Client | Live sales updates | `{period, total_sales, invoice_count, vs_yesterday}` |
| `dashboard.live.production` | Server->Client | Live production data | `{line_id, current_output, efficiency, status}` |
| `inventory.alerts` | Server->Client | Inventory alerts | `{alert_type, product_id, current_stock, threshold}` |
| `production.live` | Server->Client | Production line status | `{line_id, status, current_order, progress_pct}` |
| `delivery.tracking.{trip_id}` | Server->Client | Delivery progress | `{assignment_id, status, location, estimated_arrival}` |
| `chat.support` | Bidirectional | Support chat messages | `{message_id, sender, content, timestamp}` |
| `presence` | Server->Client | User presence updates | `{user_id, status: online\|away\|offline}` |

### Heartbeat
Client must send heartbeat every 30 seconds:
```json
{"type": "heartbeat", "timestamp": "2024-01-15T10:30:00+02:00"}
```

Server responds:
```json
{"type": "heartbeat_ack", "timestamp": "2024-01-15T10:30:00+02:00"}
```

### Rate Limits
- Maximum 1 connection per user per device
- Maximum 100 messages/second inbound per connection
- Maximum 1,000 messages/second outbound per connection
- Idle timeout: 120 seconds without heartbeat

---

## 1.23 Webhook Integration API

### Webhook Event Types

| Event Category | Event Name | Description | Payload Size |
|----------------|------------|-------------|--------------|
| **Sales** | `sales.invoice.created` | New invoice created | ~2KB |
| **Sales** | `sales.invoice.paid` | Invoice fully paid | ~1KB |
| **Sales** | `sales.invoice.cancelled` | Invoice cancelled | ~1KB |
| **Purchase** | `purchase.order.created` | New PO created | ~2KB |
| **Purchase** | `purchase.grn.received` | GRN received | ~2KB |
| **Inventory** | `inventory.stock.low` | Low stock alert | ~1KB |
| **Inventory** | `inventory.movement.created` | Stock movement | ~2KB |
| **Production** | `production.order.completed` | Production complete | ~2KB |
| **Financial** | `payment.received` | Payment received | ~1KB |
| **Financial** | `payment.sent` | Payment sent | ~1KB |
| **Customer** | `customer.created` | New customer | ~1KB |
| **Delivery** | `delivery.completed` | Delivery completed | ~2KB |
| **HR** | `employee.status.changed` | Employee status change | ~1KB |
| **System** | `backup.completed` | Backup completed | ~500B |
| **E-Invoice** | `einvoice.submitted` | E-invoice submitted to ETA | ~1KB |
| **E-Invoice** | `einvoice.approved` | E-invoice approved by ETA | ~1KB |
| **E-Invoice** | `einvoice.rejected` | E-invoice rejected by ETA | ~1KB |

### Webhook Payload Schema (Example: sales.invoice.created)
```json
{
  "event_id": "evt_8f3a2b1c4d5e6f7g",
  "event_type": "sales.invoice.created",
  "event_version": "1.0",
  "timestamp": "2024-01-15T10:30:00+02:00",
  "webhook_id": "wh_1234567890",
  "delivery_attempt": 1,
  "data": {
    "invoice_id": "uuid",
    "invoice_number": "SI-CAI-2024-001542",
    "branch_id": "uuid",
    "customer_id": "uuid",
    "customer_name": "Al-Amal Poultry Farm",
    "total_amount": 28180.00,
    "currency": "EGP",
    "issue_date": "2024-01-15",
    "status": "confirmed",
    "created_by": "uuid",
    "created_at": "2024-01-15T10:30:00+02:00"
  }
}
```

### Webhook Signature Verification
```
X-Webhook-Signature: sha256=<hmac_sha256_hex>
X-Webhook-Timestamp: 1705313400
X-Webhook-Id: evt_8f3a2b1c4d5e6f7g
```

Signature is computed as:
```python
import hmac, hashlib
signature = hmac.new(
    webhook_secret.encode(),
    f"{timestamp}.{json_payload}".encode(),
    hashlib.sha256
).hexdigest()
```

### Webhook Endpoints (Internal Management)

### GET /api/v1/webhooks
List configured webhooks.

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "name": "ETA E-Invoice Integration",
      "url": "https://api.eta.gov.eg/invoice-submission",
      "events": ["sales.invoice.created", "sales.invoice.cancelled"],
      "is_active": true,
      "secret": "whsec_*** (masked)",
      "headers": {"Authorization": "Bearer ***"},
      "retry_policy": {
        "max_retries": 5,
        "retry_interval_seconds": 60,
        "exponential_backoff": true
      },
      "delivery_stats": {
        "total_delivered": 45200,
        "total_failed": 12,
        "success_rate_pct": 99.97,
        "last_delivery": "2024-01-15T10:30:00+02:00",
        "last_status": "success"
      },
      "created_at": "2023-01-01T00:00:00+02:00"
    }
  ]
}
```

**Permissions:** `webhooks.read`

---

### POST /api/v1/webhooks
Create webhook.

**Request:**
```json
{
  "name": "string",
  "url": "string (HTTPS URL)",
  "events": ["sales.invoice.created", "inventory.stock.low"],
  "secret": "string (auto-generated if omitted)",
  "headers": {"Authorization": "Bearer token"},
  "is_active": true,
  "retry_policy": {
    "max_retries": 5,
    "retry_interval_seconds": 60,
    "exponential_backoff": true
  },
  "filter_conditions": {
    "branch_id": "uuid (optional)",
    "min_amount": "decimal (optional)"
  }
}
```

**Response (201):** Created webhook with secret
**Permissions:** `webhooks.write`

---

### PUT /api/v1/webhooks/{id}
Update webhook.
**Permissions:** `webhooks.write`

---

### DELETE /api/v1/webhooks/{id}
Delete webhook.
**Permissions:** `webhooks.delete`

---

### POST /api/v1/webhooks/{id}/test
Send test payload.
**Response (200):** Delivery test result
**Permissions:** `webhooks.write`

---

### GET /api/v1/webhooks/{id}/deliveries
Get delivery history.

**Response (200):**
```json
{
  "data": [
    {
      "delivery_id": "uuid",
      "event_id": "evt_xxx",
      "event_type": "sales.invoice.created",
      "status": "delivered | failed | retrying",
      "http_status": 200,
      "response_body": "OK",
      "duration_ms": 150,
      "attempt": 1,
      "delivered_at": "2024-01-15T10:30:00+02:00"
    }
  ]
}
```

**Permissions:** `webhooks.read`

---

### ETA E-Invoice Webhook Integration
Pre-configured webhook for Egyptian Tax Authority E-Invoice integration.

**Endpoint:** `POST https://api.eta.gov.eg/api/v1/documentsubmissions`

**Events:** `sales.invoice.created`, `sales.invoice.cancelled`

**Transformation:** Invoice data transformed to ETA JSON format (UBL 2.1).

**Authentication:** OAuth 2.0 client credentials with ETA.

---

### Payment Gateway Webhooks
Pre-configured webhooks for payment gateway integrations.

**Supported Gateways:**
- Fawry
- Vodafone Cash
- Etisalat Cash
- Orange Cash
- CIB Smart Wallet
- Paymob

**Events:** `payment.received`, `payment.failed`, `payment.refunded`

---

### SMS Gateway Webhooks
Pre-configured for SMS notifications.

**Events:** All event types with user notification preferences.

**Supported Providers:**
- Vodafone Egypt SMS API
- Infobip
- Twilio

---

## 1.24 API Versioning Strategy

### Versioning Approaches

GFF ERP supports dual versioning strategy, matching Oracle REST API standards:

| Approach | Format | Example | Priority |
|----------|--------|---------|----------|
| **URL Path** | `/api/v{N}/` | `/api/v1/users` | Primary |
| **Header** | `X-API-Version: v{N}` | `X-API-Version: v1` | Secondary |
| **Accept Header** | `application/vnd.gff.v{N}+json` | `application/vnd.gff.v1+json` | Legacy |

### Current Versions
| Version | Status | Base URL | Sunset Date |
|---------|--------|----------|-------------|
| v1 | **Current** | `/api/v1/` | -- |
| v2 | **Beta** | `/api/v2/` | -- |
| v0 | **Deprecated** | `/api/v0/` | 2024-12-31 |

### Version Lifecycle
```
Beta -> Current -> Deprecated -> Sunset -> Retired
  |       |           |            |          |
 30d    Active    180d notice   90d grace   Removed
```

### Deprecation Policy
1. **Announcement**: 180 days before deprecation (API changelog, email, dashboard notice)
2. **Deprecation Header**: `Deprecation: true`, `Sunset: Sat, 31 Dec 2024 00:00:00 GMT`
3. **Migration Guide**: Published at `https://docs.gff-erp.com/api/migration/v0-to-v1`
4. **Grace Period**: 90 days after sunset date with elevated rate limits for migrating clients
5. **Retirement**: Complete removal, returning `410 Gone`

### Breaking Changes Definition
The following constitute a breaking change requiring a new major version:
- Removing an endpoint
- Removing a request/response field
- Changing field data types
- Changing authentication requirements
- Changing URL patterns
- Changing error response structure

Non-breaking changes (backward compatible, no version bump):
- Adding new endpoints
- Adding new optional fields
- Adding new query parameters
- Adding new error codes

### Version Response Headers
All responses include:
```
X-API-Version: v1
X-API-Deprecation: false
X-API-Sunset: null
X-API-Documentation: https://docs.gff-erp.com/api/v1
```

### API Changelog
Available at: `GET /api/v1/changelog`

```json
{
  "versions": [
    {
      "version": "v1.2.0",
      "date": "2024-01-15",
      "changes": [
        {"type": "added", "description": "New AI forecast endpoint", "endpoint": "POST /api/v1/ai/forecast/sales"},
        {"type": "enhanced", "description": "Added confidence intervals to forecast response"},
        {"type": "fixed", "description": "Fixed pagination cursor issue in large datasets"}
      ]
    }
  ]
}
```

---

# Part II: Database Schema

## 2.1 Schema Design Principles

### Design Philosophy
The GFF ERP database schema follows the **SAP S/4HANA data model** principles combined with **Oracle Fusion** normalization standards, designed for:
- **1,000 branches** concurrently active
- **1,000,000+ customers** in the master data
- **10,000,000+ monthly transactions** across all modules
- **99.99% uptime** SLA
- **Sub-100ms** query response for operational queries
- **Sub-5s** response for analytical reports

### Database Platform
| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Primary OLTP** | PostgreSQL 16 (Patroni cluster) | Transactional data, master data |
| **Read Replicas** | PostgreSQL 16 (5 replicas) | Read-heavy operations, reporting |
| **Analytics** | ClickHouse / Apache Druid | OLAP, dashboards, large aggregations |
| **Cache** | Redis Cluster (7 nodes) | Session cache, hot data, rate limiting |
| **Search** | Elasticsearch (3-node cluster) | Full-text search across all entities |
| **Time-Series** | TimescaleDB | GPS tracking, sensor data, metrics |
| **Document** | MongoDB (optional) | Unstructured attachments, logs |

### Naming Conventions
| Element | Convention | Example |
|---------|-----------|---------|
| Tables | `snake_case`, plural | `sales_invoices` |
| Views | `vw_` prefix | `vw_customer_balances` |
| Functions | `fn_` prefix | `fn_calculate_adg` |
| Triggers | `trg_` prefix | `trg_sales_invoice_post` |
| Indexes | `idx_{table}_{columns}` | `idx_sales_invoices_branch_date` |
| Primary Keys | `{table}_id` or `id` | `sales_invoice_id` |
| Foreign Keys | `{referenced_table}_id` | `branch_id` |
| Timestamps | `created_at`, `updated_at`, `deleted_at` | -- |

### Data Types
| Domain | Type | Notes |
|--------|------|-------|
| Primary Keys | `UUID (v7)` | Time-sortable UUIDs for performance |
| Monetary | `DECIMAL(19,4)` | 15 digits + 4 decimal places |
| Quantities | `DECIMAL(15,3)` | Supports fractional units |
| Percentages | `DECIMAL(5,2)` | 0.00 to 100.00 |
| Dates | `DATE` | For date-only fields |
| Timestamps | `TIMESTAMPTZ` | With timezone (Africa/Cairo) |
| Enums | `VARCHAR` with CHECK constraints | Flexible, no DDL change for new values |
| JSON | `JSONB` | For flexible/custom data |
| Text Search | `TSVECTOR` | For full-text search |
| Geographic | `GEOGRAPHY(POINT)` | PostGIS for coordinates |

### Referential Integrity
- All foreign keys use `ON DELETE RESTRICT` to prevent accidental data loss
- Soft deletes implemented via `deleted_at` timestamp (no physical deletion)
- All transactional tables require `branch_id` for data isolation
- All tables have `tenant_id` for multi-tenancy support

---

## 2.2 Master Data Tables

### companies
```sql
CREATE TABLE companies (
    company_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    company_code            VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    trade_name              VARCHAR(100),
    legal_form              VARCHAR(50) CHECK (legal_form IN ('sole_proprietorship','partnership','llc','joint_stock','holding','branch_foreign')),
    tax_id                  VARCHAR(20),
    tax_card_number         VARCHAR(20),
    commercial_register     VARCHAR(20),
    establishment_date      DATE,
    logo_url                VARCHAR(500),
    website                 VARCHAR(200),
    email                   VARCHAR(200),
    phone                   VARCHAR(20),
    fax                     VARCHAR(20),
    address_street          VARCHAR(300),
    address_city            VARCHAR(100),
    address_governorate     VARCHAR(100),
    address_postal_code     VARCHAR(20),
    address_country         VARCHAR(2) DEFAULT 'EG',
    coordinates             GEOGRAPHY(POINT,4326),
    default_currency        VARCHAR(3) DEFAULT 'EGP',
    default_language        VARCHAR(10) DEFAULT 'ar-EG',
    default_timezone        VARCHAR(50) DEFAULT 'Africa/Cairo',
    fiscal_year_start_month INTEGER DEFAULT 7 CHECK (fiscal_year_start_month BETWEEN 1 AND 12),
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_companies_code UNIQUE (tenant_id, company_code),
    CONSTRAINT uq_companies_tax_id UNIQUE (tenant_id, tax_id)
);

CREATE INDEX idx_companies_tenant ON companies(tenant_id);
CREATE INDEX idx_companies_active ON companies(is_active) WHERE deleted_at IS NULL;
```

### branches
```sql
CREATE TABLE branches (
    branch_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    company_id              UUID NOT NULL REFERENCES companies(company_id),
    branch_code             VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    branch_type             VARCHAR(30) CHECK (branch_type IN ('headquarters','regional','city','rural','factory','farm','warehouse','logistics')),
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','inactive','under_construction')),
    region                  VARCHAR(100),
    governorate             VARCHAR(100) NOT NULL,
    city                    VARCHAR(100) NOT NULL,
    address_street          VARCHAR(300),
    address_postal_code     VARCHAR(20),
    coordinates             GEOGRAPHY(POINT,4326),
    phone                   VARCHAR(20),
    fax                     VARCHAR(20),
    email                   VARCHAR(200),
    manager_id              UUID,
    opening_date            DATE,
    operating_hours         VARCHAR(50),
    working_days            VARCHAR(50),
    employee_count          INTEGER DEFAULT 0,
    sales_target_monthly    DECIMAL(19,4) DEFAULT 0,
    sales_target_yearly     DECIMAL(19,4) DEFAULT 0,
    area_sqm                DECIMAL(10,2),
    license_number          VARCHAR(50),
    license_expiry          DATE,
    custom_fields           JSONB,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_branches_code UNIQUE (tenant_id, branch_code),
    CONSTRAINT uq_branches_name UNIQUE (tenant_id, name_en)
);

CREATE INDEX idx_branches_tenant ON branches(tenant_id);
CREATE INDEX idx_branches_company ON branches(company_id);
CREATE INDEX idx_branches_governorate ON branches(governorate);
CREATE INDEX idx_branches_active ON branches(is_active, status) WHERE deleted_at IS NULL;
CREATE INDEX idx_branches_location ON branches USING GIST(coordinates);
```

### warehouses
```sql
CREATE TABLE warehouses (
    warehouse_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    warehouse_code          VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    warehouse_type          VARCHAR(30) CHECK (warehouse_type IN ('main','secondary','cold','frozen','feed','livestock','quarantine','hazardous')),
    address                 VARCHAR(300),
    manager_id              UUID,
    capacity_sqm            DECIMAL(10,2),
    capacity_kg             DECIMAL(15,2),
    current_utilization_pct DECIMAL(5,2) DEFAULT 0,
    temperature_controlled  BOOLEAN DEFAULT FALSE,
    temperature_min_c       DECIMAL(5,2),
    temperature_max_c       DECIMAL(5,2),
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_warehouses_code UNIQUE (tenant_id, warehouse_code)
);

CREATE INDEX idx_warehouses_branch ON warehouses(branch_id);
CREATE INDEX idx_warehouses_type ON warehouses(warehouse_type);
CREATE INDEX idx_warehouses_active ON warehouses(is_active) WHERE deleted_at IS NULL;
```

### warehouse_zones
```sql
CREATE TABLE warehouse_zones (
    zone_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    warehouse_id            UUID NOT NULL REFERENCES warehouses(warehouse_id),
    zone_code               VARCHAR(20) NOT NULL,
    zone_name               VARCHAR(100) NOT NULL,
    zone_type               VARCHAR(30) CHECK (zone_type IN ('ambient','cold','frozen','quarantine','hazardous','bulk','rack')),
    capacity_sqm            DECIMAL(10,2),
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_warehouse_zones UNIQUE (warehouse_id, zone_code)
);

CREATE INDEX idx_warehouse_zones_warehouse ON warehouse_zones(warehouse_id);
```

### currencies
```sql
CREATE TABLE currencies (
    currency_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    currency_code           VARCHAR(3) NOT NULL,
    currency_name_ar        VARCHAR(50) NOT NULL,
    currency_name_en        VARCHAR(50) NOT NULL,
    symbol                  VARCHAR(5),
    decimal_places          INTEGER DEFAULT 2,
    is_base_currency        BOOLEAN DEFAULT FALSE,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_currencies_code UNIQUE (tenant_id, currency_code)
);

CREATE INDEX idx_currencies_tenant ON currencies(tenant_id);
```

### currency_exchange_rates
```sql
CREATE TABLE currency_exchange_rates (
    rate_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    from_currency           VARCHAR(3) NOT NULL,
    to_currency             VARCHAR(3) NOT NULL,
    rate                    DECIMAL(19,8) NOT NULL,
    rate_date               DATE NOT NULL,
    rate_type               VARCHAR(20) DEFAULT 'daily' CHECK (rate_type IN ('daily','monthly','yearly','custom')),
    source                  VARCHAR(50),
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    CONSTRAINT uq_exchange_rates UNIQUE (tenant_id, from_currency, to_currency, rate_date, rate_type)
);

CREATE INDEX idx_exchange_rates_lookup ON currency_exchange_rates(tenant_id, from_currency, to_currency, rate_date);
```

### users
```sql
CREATE TABLE users (
    user_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    username                VARCHAR(50) NOT NULL,
    password_hash           VARCHAR(255) NOT NULL,
    password_changed_at     TIMESTAMPTZ,
    password_expires_at     TIMESTAMPTZ,
    full_name_ar            VARCHAR(100) NOT NULL,
    full_name_en            VARCHAR(100) NOT NULL,
    email                   VARCHAR(200),
    phone                   VARCHAR(20),
    national_id             VARCHAR(14),
    date_of_birth           DATE,
    gender                  VARCHAR(10) CHECK (gender IN ('male','female')),
    address                 VARCHAR(300),
    avatar_url              VARCHAR(500),
    branch_id               UUID REFERENCES branches(branch_id),
    department_id           UUID,
    role_id                 UUID NOT NULL,
    custom_permissions      JSONB DEFAULT '[]',
    restricted_permissions  JSONB DEFAULT '[]',
    data_scope              VARCHAR(20) DEFAULT 'own' CHECK (data_scope IN ('own','branch','region','all')),
    accessible_branches     UUID[] DEFAULT '{}',
    status                  VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('active','inactive','pending','locked','suspended')),
    status_reason           VARCHAR(255),
    mfa_enabled             BOOLEAN DEFAULT FALSE,
    mfa_method              VARCHAR(20) CHECK (mfa_method IN ('totp','sms','email','backup_codes')),
    mfa_secret_encrypted    VARCHAR(255),
    mfa_backup_codes        JSONB,
    last_login_at           TIMESTAMPTZ,
    last_login_ip           INET,
    login_count             INTEGER DEFAULT 0,
    failed_login_attempts   INTEGER DEFAULT 0,
    locked_until            TIMESTAMPTZ,
    preferences             JSONB DEFAULT '{"language":"ar-EG","timezone":"Africa/Cairo","date_format":"DD/MM/YYYY","theme":"light","notifications":{"email":true,"sms":false,"push":true}}',
    email_verified          BOOLEAN DEFAULT FALSE,
    phone_verified          BOOLEAN DEFAULT FALSE,
    invite_token            VARCHAR(255),
    invite_expires_at       TIMESTAMPTZ,
    is_system_user          BOOLEAN DEFAULT FALSE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_users_username UNIQUE (tenant_id, username),
    CONSTRAINT uq_users_email UNIQUE (tenant_id, email),
    CONSTRAINT uq_users_phone UNIQUE (tenant_id, phone)
);

CREATE INDEX idx_users_tenant ON users(tenant_id);
CREATE INDEX idx_users_branch ON users(branch_id);
CREATE INDEX idx_users_role ON users(role_id);
CREATE INDEX idx_users_status ON users(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_name ON users USING gin(to_tsvector('simple', full_name_en));
CREATE INDEX idx_users_login ON users(last_login_at);
```

### roles
```sql
CREATE TABLE roles (
    role_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    name_ar                 VARCHAR(100) NOT NULL,
    name_en                 VARCHAR(100) NOT NULL,
    slug                    VARCHAR(50) NOT NULL,
    description             TEXT,
    level                   INTEGER CHECK (level BETWEEN 1 AND 10),
    is_system               BOOLEAN DEFAULT FALSE,
    is_active               BOOLEAN DEFAULT TRUE,
    permissions             JSONB NOT NULL DEFAULT '[]',
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_roles_slug UNIQUE (tenant_id, slug)
);

CREATE INDEX idx_roles_tenant ON roles(tenant_id);
CREATE INDEX idx_roles_level ON roles(level);
```

### permissions
```sql
CREATE TABLE permissions (
    permission_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    permission_slug         VARCHAR(100) NOT NULL UNIQUE,
    module                  VARCHAR(50) NOT NULL,
    action                  VARCHAR(30) NOT NULL,
    resource                VARCHAR(50) DEFAULT 'all',
    display_name_ar         VARCHAR(100) NOT NULL,
    display_name_en         VARCHAR(100) NOT NULL,
    description             TEXT,
    category                VARCHAR(30) CHECK (category IN ('operational','financial','administrative','executive','system')),
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_permissions_module ON permissions(module);
CREATE INDEX idx_permissions_category ON permissions(category);
```

### products
```sql
CREATE TABLE products (
    product_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    sku                     VARCHAR(50) NOT NULL,
    barcode                 VARCHAR(50),
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    description             TEXT,
    category_id             UUID NOT NULL REFERENCES product_categories(category_id),
    subcategory_id          UUID REFERENCES product_categories(category_id),
    unit_of_measure_id      UUID NOT NULL REFERENCES units_of_measure(uom_id),
    secondary_uom_id        UUID REFERENCES units_of_measure(uom_id),
    conversion_factor       DECIMAL(10,4) DEFAULT 1,
    cost_method             VARCHAR(20) DEFAULT 'weighted_average' CHECK (cost_method IN ('fifo','weighted_average','lifo','standard')),
    standard_cost           DECIMAL(19,4),
    current_cost            DECIMAL(19,4),
    sale_price              DECIMAL(19,4),
    min_sale_price          DECIMAL(19,4),
    max_discount_pct        DECIMAL(5,2) DEFAULT 0,
    is_active               BOOLEAN DEFAULT TRUE,
    is_sellable             BOOLEAN DEFAULT TRUE,
    is_purchasable          BOOLEAN DEFAULT TRUE,
    is_producible           BOOLEAN DEFAULT FALSE,
    track_inventory         BOOLEAN DEFAULT TRUE,
    reorder_point           DECIMAL(15,3) DEFAULT 0,
    reorder_quantity        DECIMAL(15,3) DEFAULT 0,
    has_batch_tracking      BOOLEAN DEFAULT FALSE,
    has_expiry              BOOLEAN DEFAULT FALSE,
    shelf_life_days         INTEGER,
    weight_kg               DECIMAL(10,4),
    length_cm               DECIMAL(10,2),
    width_cm                DECIMAL(10,2),
    height_cm               DECIMAL(10,2),
    volume_cbm              DECIMAL(10,4),
    tax_code_id             UUID,
    images                  JSONB DEFAULT '[]',
    specifications          JSONB DEFAULT '{}',
    custom_fields           JSONB DEFAULT '{}',
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_products_sku UNIQUE (tenant_id, sku),
    CONSTRAINT uq_products_barcode UNIQUE (tenant_id, barcode)
);

CREATE INDEX idx_products_tenant ON products(tenant_id);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_active ON products(is_active) WHERE deleted_at IS NULL;
CREATE INDEX idx_products_search ON products USING gin(to_tsvector('simple', COALESCE(name_en,'') || ' ' || COALESCE(name_ar,'') || ' ' || COALESCE(sku,'')));
CREATE INDEX idx_products_barcode ON products(barcode) WHERE barcode IS NOT NULL;
```

### product_categories
```sql
CREATE TABLE product_categories (
    category_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    parent_id               UUID REFERENCES product_categories(category_id),
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    description             TEXT,
    level                   INTEGER DEFAULT 0,
    path                    VARCHAR(500),
    sort_order              INTEGER DEFAULT 0,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_categories_name UNIQUE (tenant_id, name_en)
);

CREATE INDEX idx_categories_tenant ON product_categories(tenant_id);
CREATE INDEX idx_categories_parent ON product_categories(parent_id);
CREATE INDEX idx_categories_path ON product_categories(path);
```

### units_of_measure
```sql
CREATE TABLE units_of_measure (
    uom_id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    uom_code                VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(50) NOT NULL,
    name_en                 VARCHAR(50) NOT NULL,
    uom_type                VARCHAR(20) CHECK (uom_type IN ('weight','volume','count','length','area','time','pack','ratio')),
    base_uom_id             UUID REFERENCES units_of_measure(uom_id),
    conversion_factor       DECIMAL(15,6) DEFAULT 1,
    is_base_unit            BOOLEAN DEFAULT FALSE,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_uom_code UNIQUE (tenant_id, uom_code)
);

CREATE INDEX idx_uom_tenant ON units_of_measure(tenant_id);
```

### customers
```sql
CREATE TABLE customers (
    customer_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    customer_code           VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    trade_name              VARCHAR(200),
    category_id             UUID REFERENCES customer_categories(category_id),
    classification          VARCHAR(5) DEFAULT 'c' CHECK (classification IN ('a','b','c','d')),
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','inactive','suspended','blacklisted')),
    tax_id                  VARCHAR(20),
    tax_card_number         VARCHAR(20),
    commercial_register     VARCHAR(20),
    phone_primary           VARCHAR(20) NOT NULL,
    phone_secondary         VARCHAR(20),
    email                   VARCHAR(200),
    website                 VARCHAR(200),
    fax                     VARCHAR(20),
    address_street          VARCHAR(300),
    address_city            VARCHAR(100),
    address_governorate     VARCHAR(100),
    address_postal_code     VARCHAR(20),
    coordinates             GEOGRAPHY(POINT,4326),
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    sales_rep_id            UUID REFERENCES users(user_id),
    credit_limit            DECIMAL(19,4) DEFAULT 0,
    credit_days             INTEGER DEFAULT 0,
    payment_terms           VARCHAR(20) DEFAULT 'cash' CHECK (payment_terms IN ('cash','net_7','net_15','net_30','net_60','custom')),
    price_list_id           UUID,
    current_balance         DECIMAL(19,4) DEFAULT 0,
    total_sales_ytd         DECIMAL(19,4) DEFAULT 0,
    total_sales_last_year   DECIMAL(19,4) DEFAULT 0,
    last_purchase_date      DATE,
    on_time_payment_pct     DECIMAL(5,2) DEFAULT 100,
    average_payment_days    INTEGER DEFAULT 0,
    custom_fields           JSONB DEFAULT '{}',
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_customers_code UNIQUE (tenant_id, customer_code)
);

CREATE INDEX idx_customers_tenant ON customers(tenant_id);
CREATE INDEX idx_customers_branch ON customers(branch_id);
CREATE INDEX idx_customers_sales_rep ON customers(sales_rep_id);
CREATE INDEX idx_customers_classification ON customers(classification);
CREATE INDEX idx_customers_status ON customers(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_customers_search ON customers USING gin(to_tsvector('simple', COALESCE(name_en,'') || ' ' || COALESCE(name_ar,'') || ' ' || COALESCE(phone_primary,'')));
CREATE INDEX idx_customers_balance ON customers(current_balance) WHERE current_balance != 0;
```

### customer_categories
```sql
CREATE TABLE customer_categories (
    category_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    name_ar                 VARCHAR(100) NOT NULL,
    name_en                 VARCHAR(100) NOT NULL,
    description             TEXT,
    parent_id               UUID REFERENCES customer_categories(category_id),
    default_credit_limit    DECIMAL(19,4) DEFAULT 0,
    default_credit_days     INTEGER DEFAULT 0,
    default_discount_pct    DECIMAL(5,2) DEFAULT 0,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ
);

CREATE INDEX idx_customer_categories_tenant ON customer_categories(tenant_id);
```

### suppliers
```sql
CREATE TABLE suppliers (
    supplier_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    supplier_code           VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    trade_name              VARCHAR(200),
    category_id             UUID REFERENCES supplier_categories(category_id),
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','inactive','blacklisted','under_review')),
    tax_id                  VARCHAR(20),
    commercial_register     VARCHAR(20),
    phone_primary           VARCHAR(20) NOT NULL,
    phone_secondary         VARCHAR(20),
    email                   VARCHAR(200),
    fax                     VARCHAR(20),
    website                 VARCHAR(200),
    address_street          VARCHAR(300),
    address_city            VARCHAR(100),
    address_governorate     VARCHAR(100),
    address_postal_code     VARCHAR(20),
    payment_terms           VARCHAR(20) DEFAULT 'net_30',
    currency                VARCHAR(3) DEFAULT 'EGP',
    lead_time_days          INTEGER DEFAULT 7,
    minimum_order_amount    DECIMAL(19,4) DEFAULT 0,
    credit_limit            DECIMAL(19,4) DEFAULT 0,
    current_balance         DECIMAL(19,4) DEFAULT 0,
    rating                  DECIMAL(3,2) CHECK (rating BETWEEN 1 AND 5),
    evaluation_score        DECIMAL(5,2),
    is_preferred            BOOLEAN DEFAULT FALSE,
    bank_name               VARCHAR(100),
    bank_account_number     VARCHAR(50),
    bank_iban               VARCHAR(34),
    bank_swift              VARCHAR(20),
    total_purchases_ytd     DECIMAL(19,4) DEFAULT 0,
    last_purchase_date      DATE,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_suppliers_code UNIQUE (tenant_id, supplier_code)
);

CREATE INDEX idx_suppliers_tenant ON suppliers(tenant_id);
CREATE INDEX idx_suppliers_status ON suppliers(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_suppliers_search ON suppliers USING gin(to_tsvector('simple', COALESCE(name_en,'') || ' ' || COALESCE(name_ar,'')));
```

### supplier_categories
```sql
CREATE TABLE supplier_categories (
    category_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    name_ar                 VARCHAR(100) NOT NULL,
    name_en                 VARCHAR(100) NOT NULL,
    description             TEXT,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ
);

CREATE INDEX idx_supplier_categories_tenant ON supplier_categories(tenant_id);
```

### vehicles
```sql
CREATE TABLE vehicles (
    vehicle_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    vehicle_code            VARCHAR(20) NOT NULL,
    plate_number            VARCHAR(30) NOT NULL,
    make                    VARCHAR(50),
    model                   VARCHAR(50),
    year                    INTEGER,
    vehicle_type            VARCHAR(20) CHECK (vehicle_type IN ('truck','van','pickup','car','forklift','trailer','bus')),
    body_type               VARCHAR(30) CHECK (body_type IN ('refrigerated_box','flatbed','tanker','curtain_side','dry_box','open','container')),
    capacity_kg             DECIMAL(10,2),
    capacity_cbm            DECIMAL(10,2),
    fuel_type               VARCHAR(20) CHECK (fuel_type IN ('diesel','gasoline','cng','electric','hybrid')),
    fuel_consumption_avg    DECIMAL(6,2),
    current_odometer_km     DECIMAL(12,2) DEFAULT 0,
    gps_device_id           VARCHAR(100),
    assigned_driver_id      UUID,
    purchase_date           DATE,
    purchase_cost           DECIMAL(19,4),
    insurance_expiry        DATE,
    license_expiry          DATE,
    next_service_due_km     DECIMAL(12,2),
    next_service_due_date   DATE,
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','maintenance','retired','sold')),
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_vehicles_code UNIQUE (tenant_id, vehicle_code),
    CONSTRAINT uq_vehicles_plate UNIQUE (tenant_id, plate_number)
);

CREATE INDEX idx_vehicles_branch ON vehicles(branch_id);
CREATE INDEX idx_vehicles_driver ON vehicles(assigned_driver_id);
CREATE INDEX idx_vehicles_status ON vehicles(status) WHERE deleted_at IS NULL;
```

### drivers
```sql
CREATE TABLE drivers (
    driver_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    employee_id             UUID,
    name                    VARCHAR(100) NOT NULL,
    phone                   VARCHAR(20),
    license_number          VARCHAR(50) NOT NULL,
    license_type            VARCHAR(30) CHECK (license_type IN ('heavy_truck','light_truck','commercial','private','motorcycle')),
    license_expiry          DATE,
    certifications          JSONB DEFAULT '[]',
    safety_score            DECIMAL(5,2) DEFAULT 100,
    accidents_count         INTEGER DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','on_leave','suspended','retired')),
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ
);

CREATE INDEX idx_drivers_tenant ON drivers(tenant_id);
```

### employees
```sql
CREATE TABLE employees (
    employee_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    employee_code           VARCHAR(20) NOT NULL,
    full_name_ar            VARCHAR(200) NOT NULL,
    full_name_en            VARCHAR(200) NOT NULL,
    national_id             VARCHAR(14),
    date_of_birth           DATE,
    gender                  VARCHAR(10) CHECK (gender IN ('male','female')),
    marital_status          VARCHAR(15) CHECK (marital_status IN ('single','married','divorced','widowed')),
    photo_url               VARCHAR(500),
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    department_id           UUID REFERENCES departments(department_id),
    position_id             UUID REFERENCES positions(position_id),
    job_level               INTEGER,
    employment_type         VARCHAR(20) CHECK (employment_type IN ('full_time','part_time','contract','seasonal','intern')),
    hire_date               DATE NOT NULL,
    probation_end_date      DATE,
    contract_end_date       DATE,
    reporting_to_id         UUID REFERENCES employees(employee_id),
    basic_salary            DECIMAL(19,4) NOT NULL,
    gross_salary            DECIMAL(19,4),
    social_insurance_number VARCHAR(20),
    social_insurance_salary DECIMAL(19,4),
    medical_insurance       BOOLEAN DEFAULT FALSE,
    medical_insurance_provider VARCHAR(100),
    phone                   VARCHAR(20),
    email                   VARCHAR(200),
    emergency_contact_name  VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    emergency_contact_relation VARCHAR(30),
    address_street          VARCHAR(300),
    address_city            VARCHAR(100),
    address_governorate     VARCHAR(100),
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','on_leave','suspended','terminated','resigned')),
    status_effective_date   DATE,
    status_reason           VARCHAR(255),
    documents               JSONB DEFAULT '[]',
    custom_fields           JSONB DEFAULT '{}',
    user_id                 UUID REFERENCES users(user_id),
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID,
    updated_by              UUID,
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_employees_code UNIQUE (tenant_id, employee_code)
);

CREATE INDEX idx_employees_tenant ON employees(tenant_id);
CREATE INDEX idx_employees_branch ON employees(branch_id);
CREATE INDEX idx_employees_department ON employees(department_id);
CREATE INDEX idx_employees_position ON employees(position_id);
CREATE INDEX idx_employees_status ON employees(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_employees_reporting ON employees(reporting_to_id);
```

### departments
```sql
CREATE TABLE departments (
    department_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    name_ar                 VARCHAR(100) NOT NULL,
    name_en                 VARCHAR(100) NOT NULL,
    parent_id               UUID REFERENCES departments(department_id),
    manager_id              UUID REFERENCES employees(employee_id),
    branch_id               UUID REFERENCES branches(branch_id),
    cost_center_id          UUID,
    budget                  DECIMAL(19,4),
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ
);

CREATE INDEX idx_departments_tenant ON departments(tenant_id);
CREATE INDEX idx_departments_branch ON departments(branch_id);
```

### positions
```sql
CREATE TABLE positions (
    position_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    title_ar                VARCHAR(100) NOT NULL,
    title_en                VARCHAR(100) NOT NULL,
    department_id           UUID REFERENCES departments(department_id),
    level                   INTEGER CHECK (level BETWEEN 1 AND 10),
    min_salary              DECIMAL(19,4),
    max_salary              DECIMAL(19,4),
    job_description         TEXT,
    required_qualifications JSONB DEFAULT '[]',
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ
);

CREATE INDEX idx_positions_tenant ON positions(tenant_id);
CREATE INDEX idx_positions_department ON positions(department_id);
```

### chart_of_accounts
```sql
CREATE TABLE chart_of_accounts (
    account_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    company_id              UUID NOT NULL REFERENCES companies(company_id),
    account_code            VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    account_type            VARCHAR(20) NOT NULL CHECK (account_type IN ('asset','liability','equity','revenue','expense')),
    parent_id               UUID REFERENCES chart_of_accounts(account_id),
    level                   INTEGER CHECK (level BETWEEN 1 AND 5),
    path                    VARCHAR(500),
    is_bank_account         BOOLEAN DEFAULT FALSE,
    is_cash_account         BOOLEAN DEFAULT FALSE,
    currency                VARCHAR(3) DEFAULT 'EGP',
    opening_balance         DECIMAL(19,4) DEFAULT 0,
    opening_balance_date    DATE,
    current_balance         DECIMAL(19,4) DEFAULT 0,
    is_active               BOOLEAN DEFAULT TRUE,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_coa_code UNIQUE (tenant_id, company_id, account_code)
);

CREATE INDEX idx_coa_tenant ON chart_of_accounts(tenant_id);
CREATE INDEX idx_coa_company ON chart_of_accounts(company_id);
CREATE INDEX idx_coa_type ON chart_of_accounts(account_type);
CREATE INDEX idx_coa_parent ON chart_of_accounts(parent_id);
CREATE INDEX idx_coa_path ON chart_of_accounts(path);
```

### tax_codes
```sql
CREATE TABLE tax_codes (
    tax_code_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    tax_code                VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(100) NOT NULL,
    name_en                 VARCHAR(100) NOT NULL,
    tax_type                VARCHAR(20) CHECK (tax_type IN ('vat','withholding','stamp','customs','other')),
    rate                    DECIMAL(5,2) NOT NULL,
    is_compound             BOOLEAN DEFAULT FALSE,
    is_active               BOOLEAN DEFAULT TRUE,
    effective_from          DATE NOT NULL,
    effective_to            DATE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_tax_codes UNIQUE (tenant_id, tax_code)
);

CREATE INDEX idx_tax_codes_tenant ON tax_codes(tenant_id);
CREATE INDEX idx_tax_codes_active ON tax_codes(is_active, effective_from, effective_to);
```

### payment_methods
```sql
CREATE TABLE payment_methods (
    payment_method_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    method_code             VARCHAR(20) NOT NULL,
    method_name_ar          VARCHAR(50) NOT NULL,
    method_name_en          VARCHAR(50) NOT NULL,
    method_type             VARCHAR(20) CHECK (method_type IN ('cash','bank_transfer','cheque','credit_card','debit_card','wallet','credit','other')),
    bank_account_id         UUID,
    cash_account_id         UUID,
    requires_reference      BOOLEAN DEFAULT FALSE,
    processing_fee_pct      DECIMAL(5,2) DEFAULT 0,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_payment_methods UNIQUE (tenant_id, method_code)
);

CREATE INDEX idx_payment_methods_tenant ON payment_methods(tenant_id);
```

---

## 2.3 Transactional Tables

### sales_invoices
```sql
CREATE TABLE sales_invoices (
    invoice_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    invoice_number          VARCHAR(30) NOT NULL,
    series                  VARCHAR(10) DEFAULT 'A',
    customer_id             UUID NOT NULL REFERENCES customers(customer_id),
    sales_rep_id            UUID REFERENCES users(user_id),
    issue_date              DATE NOT NULL,
    due_date                DATE NOT NULL,
    delivery_date           DATE,
    channel                 VARCHAR(20) CHECK (channel IN ('branch','phone','online','field','b2b','mobile_app')),
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','confirmed','shipped','delivered','paid','partially_paid','cancelled','returned')),
    payment_status          VARCHAR(20) DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','partial','paid','overpaid')),
    payment_terms           VARCHAR(20) DEFAULT 'cash',
    currency                VARCHAR(3) DEFAULT 'EGP',
    exchange_rate           DECIMAL(19,8) DEFAULT 1,
    subtotal                DECIMAL(19,4) NOT NULL DEFAULT 0,
    discount_amount         DECIMAL(19,4) DEFAULT 0,
    discount_pct            DECIMAL(5,2) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    tax_breakdown           JSONB DEFAULT '[]',
    shipping_amount         DECIMAL(19,4) DEFAULT 0,
    total_amount            DECIMAL(19,4) NOT NULL DEFAULT 0,
    paid_amount             DECIMAL(19,4) DEFAULT 0,
    balance_due             DECIMAL(19,4) DEFAULT 0,
    cost_of_goods_sold      DECIMAL(19,4) DEFAULT 0,
    profit_amount           DECIMAL(19,4) DEFAULT 0,
    notes                   TEXT,
    terms                   TEXT,
    delivery_address        VARCHAR(300),
    delivery_coordinates    GEOGRAPHY(POINT,4326),
    is_e_invoiced           BOOLEAN DEFAULT FALSE,
    e_invoice_uuid          VARCHAR(100),
    e_invoice_status        VARCHAR(20),
    e_invoice_submission_id UUID,
    source_type             VARCHAR(20),
    source_id               UUID,
    version                 INTEGER DEFAULT 1,
    created_by              UUID NOT NULL,
    updated_by              UUID,
    deleted_by              UUID,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    posted_at               TIMESTAMPTZ,
    CONSTRAINT uq_sales_invoices_number UNIQUE (tenant_id, branch_id, invoice_number)
) PARTITION BY RANGE (issue_date);

-- Monthly partitions
CREATE TABLE sales_invoices_2024_01 PARTITION OF sales_invoices
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
CREATE TABLE sales_invoices_2024_02 PARTITION OF sales_invoices
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');
-- ... continue for all months

CREATE INDEX idx_sales_invoices_tenant ON sales_invoices(tenant_id);
CREATE INDEX idx_sales_invoices_branch_date ON sales_invoices(branch_id, issue_date);
CREATE INDEX idx_sales_invoices_customer ON sales_invoices(customer_id);
CREATE INDEX idx_sales_invoices_status ON sales_invoices(status);
CREATE INDEX idx_sales_invoices_payment ON sales_invoices(payment_status);
CREATE INDEX idx_sales_invoices_due_date ON sales_invoices(due_date);
CREATE INDEX idx_sales_invoices_sales_rep ON sales_invoices(sales_rep_id);
CREATE INDEX idx_sales_invoices_einvoice ON sales_invoices(e_invoice_uuid) WHERE is_e_invoiced = TRUE;
```

### sales_invoice_lines
```sql
CREATE TABLE sales_invoice_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id              UUID NOT NULL REFERENCES sales_invoices(invoice_id),
    line_number             INTEGER NOT NULL,
    product_id              UUID NOT NULL REFERENCES products(product_id),
    description             VARCHAR(300),
    quantity                DECIMAL(15,3) NOT NULL,
    unit_of_measure_id      UUID NOT NULL,
    unit_price              DECIMAL(19,4) NOT NULL,
    discount_pct            DECIMAL(5,2) DEFAULT 0,
    discount_amount         DECIMAL(19,4) DEFAULT 0,
    net_price               DECIMAL(19,4) NOT NULL,
    tax_code_id             UUID REFERENCES tax_codes(tax_code_id),
    tax_rate                DECIMAL(5,2) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    line_total              DECIMAL(19,4) NOT NULL,
    cost_price              DECIMAL(19,4),
    profit_amount           DECIMAL(19,4),
    warehouse_id            UUID REFERENCES warehouses(warehouse_id),
    batch_number            VARCHAR(50),
    expiry_date             DATE,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_invoice_lines_number UNIQUE (invoice_id, line_number)
);

CREATE INDEX idx_invoice_lines_invoice ON sales_invoice_lines(invoice_id);
CREATE INDEX idx_invoice_lines_product ON sales_invoice_lines(product_id);
CREATE INDEX idx_invoice_lines_warehouse ON sales_invoice_lines(warehouse_id);
```

### sales_returns
```sql
CREATE TABLE sales_returns (
    return_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    return_number           VARCHAR(30) NOT NULL,
    original_invoice_id     UUID REFERENCES sales_invoices(invoice_id),
    customer_id             UUID NOT NULL REFERENCES customers(customer_id),
    return_date             DATE NOT NULL,
    return_reason           VARCHAR(30) CHECK (return_reason IN ('damaged','wrong_item','quality_issue','expired','customer_request','other')),
    total_quantity          DECIMAL(15,3) DEFAULT 0,
    total_amount            DECIMAL(19,4) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    refund_amount           DECIMAL(19,4) DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','approved','processed','refunded','rejected')),
    restock_warehouse_id    UUID REFERENCES warehouses(warehouse_id),
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_sales_returns_number UNIQUE (tenant_id, branch_id, return_number)
) PARTITION BY RANGE (return_date);

CREATE INDEX idx_sales_returns_tenant ON sales_returns(tenant_id);
CREATE INDEX idx_sales_returns_branch ON sales_returns(branch_id);
CREATE INDEX idx_sales_returns_invoice ON sales_returns(original_invoice_id);
CREATE INDEX idx_sales_returns_customer ON sales_returns(customer_id);
```

### sales_return_lines
```sql
CREATE TABLE sales_return_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    return_id               UUID NOT NULL REFERENCES sales_returns(return_id),
    original_line_id        UUID REFERENCES sales_invoice_lines(line_id),
    product_id              UUID NOT NULL REFERENCES products(product_id),
    quantity                DECIMAL(15,3) NOT NULL,
    unit_price              DECIMAL(19,4) NOT NULL,
    condition               VARCHAR(20) CHECK (condition IN ('good','damaged','expired','unopened')),
    restock                 BOOLEAN DEFAULT TRUE,
    line_total              DECIMAL(19,4) NOT NULL,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_return_lines_return ON sales_return_lines(return_id);
CREATE INDEX idx_return_lines_product ON sales_return_lines(product_id);
```

### purchase_orders
```sql
CREATE TABLE purchase_orders (
    po_id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    po_number               VARCHAR(30) NOT NULL,
    supplier_id             UUID NOT NULL REFERENCES suppliers(supplier_id),
    order_date              DATE NOT NULL,
    expected_delivery       DATE,
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','sent','partial','received','closed','cancelled')),
    payment_terms           VARCHAR(20) DEFAULT 'net_30',
    currency                VARCHAR(3) DEFAULT 'EGP',
    exchange_rate           DECIMAL(19,8) DEFAULT 1,
    subtotal                DECIMAL(19,4) DEFAULT 0,
    discount_amount         DECIMAL(19,4) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    shipping_amount         DECIMAL(19,4) DEFAULT 0,
    total_amount            DECIMAL(19,4) DEFAULT 0,
    received_amount         DECIMAL(19,4) DEFAULT 0,
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_purchase_orders_number UNIQUE (tenant_id, branch_id, po_number)
) PARTITION BY RANGE (order_date);

CREATE INDEX idx_purchase_orders_tenant ON purchase_orders(tenant_id);
CREATE INDEX idx_purchase_orders_branch ON purchase_orders(branch_id);
CREATE INDEX idx_purchase_orders_supplier ON purchase_orders(supplier_id);
CREATE INDEX idx_purchase_orders_status ON purchase_orders(status);
```

### purchase_order_lines
```sql
CREATE TABLE purchase_order_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    po_id                   UUID NOT NULL REFERENCES purchase_orders(po_id),
    line_number             INTEGER NOT NULL,
    product_id              UUID NOT NULL REFERENCES products(product_id),
    description             VARCHAR(300),
    quantity_ordered        DECIMAL(15,3) NOT NULL,
    quantity_received       DECIMAL(15,3) DEFAULT 0,
    quantity_remaining      DECIMAL(15,3) DEFAULT 0,
    unit_of_measure_id      UUID NOT NULL,
    unit_price              DECIMAL(19,4) NOT NULL,
    discount_pct            DECIMAL(5,2) DEFAULT 0,
    tax_rate                DECIMAL(5,2) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    line_total              DECIMAL(19,4) NOT NULL,
    expected_delivery       DATE,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_po_lines_number UNIQUE (po_id, line_number)
);

CREATE INDEX idx_po_lines_po ON purchase_order_lines(po_id);
CREATE INDEX idx_po_lines_product ON purchase_order_lines(product_id);
```

### grn (Goods Receipt Notes)
```sql
CREATE TABLE grn (
    grn_id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    grn_number              VARCHAR(30) NOT NULL,
    po_id                   UUID REFERENCES purchase_orders(po_id),
    supplier_id             UUID NOT NULL REFERENCES suppliers(supplier_id),
    warehouse_id            UUID NOT NULL REFERENCES warehouses(warehouse_id),
    received_date           TIMESTAMPTZ NOT NULL,
    reference_number        VARCHAR(50),
    subtotal                DECIMAL(19,4) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    total_amount            DECIMAL(19,4) DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','posted','reversed')),
    notes                   TEXT,
    attachments             JSONB DEFAULT '[]',
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    posted_at               TIMESTAMPTZ,
    CONSTRAINT uq_grn_number UNIQUE (tenant_id, branch_id, grn_number)
) PARTITION BY RANGE (received_date);

CREATE INDEX idx_grn_tenant ON grn(tenant_id);
CREATE INDEX idx_grn_branch ON grn(branch_id);
CREATE INDEX idx_grn_po ON grn(po_id);
CREATE INDEX idx_grn_supplier ON grn(supplier_id);
```

### grn_lines
```sql
CREATE TABLE grn_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    grn_id                  UUID NOT NULL REFERENCES grn(grn_id),
    po_line_id              UUID REFERENCES purchase_order_lines(line_id),
    product_id              UUID NOT NULL REFERENCES products(product_id),
    description             VARCHAR(300),
    quantity_received       DECIMAL(15,3) NOT NULL,
    quantity_accepted       DECIMAL(15,3) NOT NULL,
    quantity_rejected       DECIMAL(15,3) DEFAULT 0,
    unit_of_measure_id      UUID NOT NULL,
    unit_price              DECIMAL(19,4) NOT NULL,
    line_total              DECIMAL(19,4) NOT NULL,
    batch_number            VARCHAR(50),
    expiry_date             DATE,
    condition               VARCHAR(20) CHECK (condition IN ('good','damaged','partial')),
    warehouse_zone_id       UUID,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_grn_lines_grn ON grn_lines(grn_id);
CREATE INDEX idx_grn_lines_product ON grn_lines(product_id);
```

### stock_movements
```sql
CREATE TABLE stock_movements (
    movement_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    movement_number         VARCHAR(30) NOT NULL,
    movement_type           VARCHAR(30) NOT NULL CHECK (movement_type IN ('receipt','issue','transfer','adjustment','return','production','waste','conversion')),
    reference_type          VARCHAR(30) CHECK (reference_type IN ('purchase_order','sales_invoice','transfer_order','adjustment','production_order','return','opening_balance')),
    reference_id            UUID,
    reference_number        VARCHAR(50),
    source_warehouse_id     UUID REFERENCES warehouses(warehouse_id),
    destination_warehouse_id UUID REFERENCES warehouses(warehouse_id),
    movement_date           TIMESTAMPTZ NOT NULL,
    total_items             INTEGER DEFAULT 0,
    total_quantity          DECIMAL(15,3) DEFAULT 0,
    total_value             DECIMAL(19,4) DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','posted','reversed')),
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    posted_at               TIMESTAMPTZ,
    CONSTRAINT uq_stock_movements_number UNIQUE (tenant_id, branch_id, movement_number)
) PARTITION BY RANGE (movement_date);

CREATE INDEX idx_stock_movements_tenant ON stock_movements(tenant_id);
CREATE INDEX idx_stock_movements_branch ON stock_movements(branch_id);
CREATE INDEX idx_stock_movements_type ON stock_movements(movement_type);
CREATE INDEX idx_stock_movements_date ON stock_movements(movement_date);
CREATE INDEX idx_stock_movements_reference ON stock_movements(reference_type, reference_id);
```

### stock_movement_lines
```sql
CREATE TABLE stock_movement_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    movement_id             UUID NOT NULL REFERENCES stock_movements(movement_id),
    product_id              UUID NOT NULL REFERENCES products(product_id),
    batch_number            VARCHAR(50),
    expiry_date             DATE,
    quantity                DECIMAL(15,3) NOT NULL,
    unit_cost               DECIMAL(19,4),
    total_cost              DECIMAL(19,4),
    unit_of_measure_id      UUID NOT NULL,
    source_zone_id          UUID,
    destination_zone_id     UUID,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sm_lines_movement ON stock_movement_lines(movement_id);
CREATE INDEX idx_sm_lines_product ON stock_movement_lines(product_id);
CREATE INDEX idx_sm_lines_batch ON stock_movement_lines(batch_number);
```

### stock_adjustments
```sql
CREATE TABLE stock_adjustments (
    adjustment_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    adjustment_number       VARCHAR(30) NOT NULL,
    warehouse_id            UUID NOT NULL REFERENCES warehouses(warehouse_id),
    adjustment_type         VARCHAR(30) CHECK (adjustment_type IN ('count','damage','expiry','theft','system_correction','other')),
    adjustment_date         TIMESTAMPTZ NOT NULL,
    total_adjustment_value  DECIMAL(19,4) DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','pending_approval','approved','posted','rejected')),
    approved_by             UUID,
    approved_at             TIMESTAMPTZ,
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_stock_adjustments UNIQUE (tenant_id, branch_id, adjustment_number)
);

CREATE INDEX idx_stock_adjustments_branch ON stock_adjustments(branch_id);
CREATE INDEX idx_stock_adjustments_warehouse ON stock_adjustments(warehouse_id);
CREATE INDEX idx_stock_adjustments_status ON stock_adjustments(status);
```

### stock_audits
```sql
CREATE TABLE stock_audits (
    audit_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    warehouse_id            UUID NOT NULL REFERENCES warehouses(warehouse_id),
    audit_number            VARCHAR(30) NOT NULL,
    audit_type              VARCHAR(20) CHECK (audit_type IN ('full','cycle','spot')),
    scheduled_date          DATE NOT NULL,
    started_date            TIMESTAMPTZ,
    completed_date          TIMESTAMPTZ,
    status                  VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_progress','counting','reviewing','completed','cancelled')),
    auditor_ids             UUID[] DEFAULT '{}',
    total_items             INTEGER DEFAULT 0,
    items_counted           INTEGER DEFAULT 0,
    variance_items          INTEGER DEFAULT 0,
    variance_value          DECIMAL(19,4) DEFAULT 0,
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_stock_audits UNIQUE (tenant_id, branch_id, audit_number)
);

CREATE INDEX idx_stock_audits_branch ON stock_audits(branch_id);
CREATE INDEX idx_stock_audits_warehouse ON stock_audits(warehouse_id);
CREATE INDEX idx_stock_audits_status ON stock_audits(status);
```

### journal_entries
```sql
CREATE TABLE journal_entries (
    entry_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    entry_number            VARCHAR(30) NOT NULL,
    entry_date              DATE NOT NULL,
    reference_type          VARCHAR(30),
    reference_id            UUID,
    reference_number        VARCHAR(50),
    description             TEXT NOT NULL,
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','posted','reversed')),
    is_reversing_entry      BOOLEAN DEFAULT FALSE,
    reversed_entry_id       UUID,
    total_debit             DECIMAL(19,4) NOT NULL DEFAULT 0,
    total_credit            DECIMAL(19,4) NOT NULL DEFAULT 0,
    is_balanced             BOOLEAN GENERATED ALWAYS AS (total_debit = total_credit) STORED,
    period_year             INTEGER GENERATED ALWAYS AS (EXTRACT(YEAR FROM entry_date)) STORED,
    period_month            INTEGER GENERATED ALWAYS AS (EXTRACT(MONTH FROM entry_date)) STORED,
    notes                   TEXT,
    posted_by               UUID,
    posted_at               TIMESTAMPTZ,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_journal_entries_number UNIQUE (tenant_id, branch_id, entry_number),
    CONSTRAINT chk_journal_balanced CHECK (status != 'posted' OR is_balanced = TRUE)
) PARTITION BY RANGE (entry_date);

CREATE INDEX idx_journal_entries_tenant ON journal_entries(tenant_id);
CREATE INDEX idx_journal_entries_branch ON journal_entries(branch_id);
CREATE INDEX idx_journal_entries_date ON journal_entries(entry_date);
CREATE INDEX idx_journal_entries_status ON journal_entries(status);
CREATE INDEX idx_journal_entries_period ON journal_entries(period_year, period_month);
CREATE INDEX idx_journal_entries_reference ON journal_entries(reference_type, reference_id);
```

### journal_entry_lines
```sql
CREATE TABLE journal_entry_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entry_id                UUID NOT NULL REFERENCES journal_entries(entry_id),
    line_number             INTEGER NOT NULL,
    account_id              UUID NOT NULL REFERENCES chart_of_accounts(account_id),
    description             TEXT,
    debit                   DECIMAL(19,4) DEFAULT 0,
    credit                  DECIMAL(19,4) DEFAULT 0,
    branch_id               UUID,
    cost_center_id          UUID,
    project_id              UUID,
    reference               VARCHAR(100),
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_je_lines_number UNIQUE (entry_id, line_number),
    CONSTRAINT chk_debit_credit CHECK (debit >= 0 AND credit >= 0)
);

CREATE INDEX idx_je_lines_entry ON journal_entry_lines(entry_id);
CREATE INDEX idx_je_lines_account ON journal_entry_lines(account_id);
CREATE INDEX idx_je_lines_branch ON journal_entry_lines(branch_id);
```

### cash_transactions
```sql
CREATE TABLE cash_transactions (
    transaction_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    transaction_number      VARCHAR(30) NOT NULL,
    cash_account_id         UUID NOT NULL REFERENCES chart_of_accounts(account_id),
    transaction_type        VARCHAR(20) CHECK (transaction_type IN ('receipt','payment','transfer_in','transfer_out')),
    transaction_date        TIMESTAMPTZ NOT NULL,
    amount                  DECIMAL(19,4) NOT NULL,
    currency                VARCHAR(3) DEFAULT 'EGP',
    exchange_rate           DECIMAL(19,8) DEFAULT 1,
    reference_type          VARCHAR(30),
    reference_id            UUID,
    reference_number        VARCHAR(50),
    description             TEXT NOT NULL,
    counterparty            VARCHAR(200),
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','posted','reversed')),
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_cash_transactions UNIQUE (tenant_id, branch_id, transaction_number)
) PARTITION BY RANGE (transaction_date);

CREATE INDEX idx_cash_transactions_branch ON cash_transactions(branch_id);
CREATE INDEX idx_cash_transactions_account ON cash_transactions(cash_account_id);
CREATE INDEX idx_cash_transactions_date ON cash_transactions(transaction_date);
```

### bank_transactions
```sql
CREATE TABLE bank_transactions (
    transaction_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    transaction_number      VARCHAR(30) NOT NULL,
    bank_account_id         UUID NOT NULL,
    transaction_type        VARCHAR(30) CHECK (transaction_type IN ('deposit','withdrawal','transfer_in','transfer_out','bank_charge','interest','cheque_deposit','cheque_clearance')),
    transaction_date        TIMESTAMPTZ NOT NULL,
    amount                  DECIMAL(19,4) NOT NULL,
    currency                VARCHAR(3) DEFAULT 'EGP',
    reference_number        VARCHAR(100),
    description             TEXT,
    counterparty            VARCHAR(200),
    is_reconciled           BOOLEAN DEFAULT FALSE,
    reconciliation_id       UUID,
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','posted','reversed')),
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_bank_transactions UNIQUE (tenant_id, branch_id, transaction_number)
) PARTITION BY RANGE (transaction_date);

CREATE INDEX idx_bank_transactions_branch ON bank_transactions(branch_id);
CREATE INDEX idx_bank_transactions_account ON bank_transactions(bank_account_id);
CREATE INDEX idx_bank_transactions_date ON bank_transactions(transaction_date);
CREATE INDEX idx_bank_transactions_reconciled ON bank_transactions(is_reconciled);
```

### production_orders
```sql
CREATE TABLE production_orders (
    order_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    order_number            VARCHAR(30) NOT NULL,
    production_line_id      UUID NOT NULL,
    status                  VARCHAR(20) DEFAULT 'planned' CHECK (status IN ('planned','approved','in_progress','completed','cancelled')),
    product_id              UUID NOT NULL REFERENCES products(product_id),
    recipe_id               UUID,
    planned_quantity        DECIMAL(15,3) NOT NULL,
    actual_quantity         DECIMAL(15,3),
    remaining_quantity      DECIMAL(15,3),
    uom_id                  UUID NOT NULL,
    scheduled_start         TIMESTAMPTZ NOT NULL,
    scheduled_end           TIMESTAMPTZ NOT NULL,
    actual_start            TIMESTAMPTZ,
    actual_end              TIMESTAMPTZ,
    estimated_cost          DECIMAL(19,4),
    actual_cost             DECIMAL(19,4),
    yield_target_pct        DECIMAL(5,2) DEFAULT 100,
    actual_yield_pct        DECIMAL(5,2),
    efficiency_pct          DECIMAL(5,2),
    downtime_minutes        INTEGER DEFAULT 0,
    quality_status          VARCHAR(20) CHECK (quality_status IN ('pending','pass','fail','conditional')),
    supervisor_id           UUID,
    priority                VARCHAR(10) DEFAULT 'normal' CHECK (priority IN ('normal','high','urgent')),
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_production_orders UNIQUE (tenant_id, branch_id, order_number)
);

CREATE INDEX idx_production_orders_branch ON production_orders(branch_id);
CREATE INDEX idx_production_orders_line ON production_orders(production_line_id);
CREATE INDEX idx_production_orders_status ON production_orders(status);
CREATE INDEX idx_production_orders_product ON production_orders(product_id);
CREATE INDEX idx_production_orders_schedule ON production_orders(scheduled_start, scheduled_end);
```

### production_lines
```sql
CREATE TABLE production_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    line_code               VARCHAR(20) NOT NULL,
    line_name               VARCHAR(100) NOT NULL,
    line_type               VARCHAR(20) CHECK (line_type IN ('feed_mill','pellet','mash','extrusion','packaging','mixing')),
    capacity_kg_per_hour    DECIMAL(10,2),
    capacity_bags_per_hour  INTEGER,
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','maintenance','inactive')),
    current_status          VARCHAR(20) DEFAULT 'idle' CHECK (current_status IN ('idle','running','maintenance','changeover','down')),
    current_order_id        UUID,
    efficiency_ytd_pct      DECIMAL(5,2),
    downtime_ytd_hours      DECIMAL(8,2) DEFAULT 0,
    operators_count         INTEGER DEFAULT 0,
    supervisor_id           UUID,
    shift_pattern           VARCHAR(10),
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_production_lines UNIQUE (tenant_id, branch_id, line_code)
);

CREATE INDEX idx_production_lines_branch ON production_lines(branch_id);
CREATE INDEX idx_production_lines_status ON production_lines(status);
```

### feed_formulations
```sql
CREATE TABLE feed_formulations (
    formulation_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    code                    VARCHAR(30) NOT NULL,
    name                    VARCHAR(200) NOT NULL,
    feed_type               VARCHAR(30) CHECK (feed_type IN ('broiler_starter','broiler_grower','broiler_finisher','layer','breeder','pre_starter','custom')),
    product_id              UUID REFERENCES products(product_id),
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','active','obsolete')),
    version                 INTEGER DEFAULT 1,
    is_default              BOOLEAN DEFAULT FALSE,
    batch_size_kg           DECIMAL(15,3) NOT NULL,
    target_protein_pct      DECIMAL(5,2),
    target_energy_kcal      DECIMAL(8,2),
    target_fat_pct          DECIMAL(5,2),
    target_fiber_pct_max    DECIMAL(5,2),
    standard_cost_per_kg    DECIMAL(19,4),
    total_formula_pct       DECIMAL(5,2) DEFAULT 100,
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_feed_formulations UNIQUE (tenant_id, code)
);

CREATE INDEX idx_feed_formulations_tenant ON feed_formulations(tenant_id);
CREATE INDEX idx_feed_formulations_product ON feed_formulations(product_id);
CREATE INDEX idx_feed_formulations_type ON feed_formulations(feed_type);
```

### feed_formulation_lines
```sql
CREATE TABLE feed_formulation_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    formulation_id          UUID NOT NULL REFERENCES feed_formulations(formulation_id),
    sequence                INTEGER NOT NULL,
    ingredient_id           UUID NOT NULL,
    inclusion_pct           DECIMAL(8,4) NOT NULL,
    quantity_kg             DECIMAL(15,3),
    unit_cost               DECIMAL(19,4),
    cost_contribution       DECIMAL(19,4),
    min_inclusion_pct       DECIMAL(8,4),
    max_inclusion_pct       DECIMAL(8,4),
    is_variable             BOOLEAN DEFAULT TRUE,
    nutrients_contribution  JSONB DEFAULT '{}',
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_formulation_lines UNIQUE (formulation_id, sequence)
);

CREATE INDEX idx_formulation_lines_formulation ON feed_formulation_lines(formulation_id);
CREATE INDEX idx_formulation_lines_ingredient ON feed_formulation_lines(ingredient_id);
```

### feed_ingredients
```sql
CREATE TABLE feed_ingredients (
    ingredient_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    code                    VARCHAR(30) NOT NULL,
    name_ar                 VARCHAR(200) NOT NULL,
    name_en                 VARCHAR(200) NOT NULL,
    category                VARCHAR(30) CHECK (category IN ('grain','protein_source','mineral','vitamin','additive','binder','oil','other')),
    nutritional_profile     JSONB NOT NULL DEFAULT '{}',
    current_price_per_kg    DECIMAL(19,4),
    price_updated_at        TIMESTAMPTZ,
    supplier_id             UUID REFERENCES suppliers(supplier_id),
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_feed_ingredients UNIQUE (tenant_id, code)
);

CREATE INDEX idx_feed_ingredients_tenant ON feed_ingredients(tenant_id);
CREATE INDEX idx_feed_ingredients_category ON feed_ingredients(category);
```

### livestock_animals
```sql
CREATE TABLE livestock_animals (
    animal_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    tag_number              VARCHAR(50) NOT NULL,
    rfid_tag                VARCHAR(100),
    species                 VARCHAR(20) CHECK (species IN ('cattle','sheep','goats','buffalo','camel')),
    breed_id                UUID,
    gender                  VARCHAR(10) CHECK (gender IN ('male','female')),
    birth_date              DATE NOT NULL,
    age_months              INTEGER GENERATED ALWAYS AS (
                                EXTRACT(YEAR FROM AGE(CURRENT_DATE, birth_date)) * 12 +
                                EXTRACT(MONTH FROM AGE(CURRENT_DATE, birth_date))
                            ) STORED,
    acquisition_date        DATE,
    acquisition_type        VARCHAR(20) CHECK (acquisition_type IN ('born_on_farm','purchased','transferred','donated')),
    acquisition_cost        DECIMAL(19,4),
    mother_id               UUID REFERENCES livestock_animals(animal_id),
    father_id               UUID REFERENCES livestock_animals(animal_id),
    status                  VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','sold','slaughtered','died','transferred')),
    current_location_id     UUID,
    current_weight_kg       DECIMAL(10,2),
    birth_weight_kg         DECIMAL(10,2),
    average_daily_gain_g    DECIMAL(8,2),
    body_condition_score    DECIMAL(3,1) CHECK (body_condition_score BETWEEN 1 AND 5),
    health_status           VARCHAR(20) DEFAULT 'healthy' CHECK (health_status IN ('healthy','sick','under_treatment','quarantine')),
    reproductive_status     VARCHAR(20) CHECK (reproductive_status IN ('lactating','pregnant','open','dry','na')),
    lactation_number        INTEGER DEFAULT 0,
    current_lactation_start DATE,
    last_breeding_date      DATE,
    expected_calving        DATE,
    notes                   TEXT,
    custom_fields           JSONB DEFAULT '{}',
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_livestock_animals_tag UNIQUE (tenant_id, tag_number)
);

CREATE INDEX idx_livestock_animals_tenant ON livestock_animals(tenant_id);
CREATE INDEX idx_livestock_animals_branch ON livestock_animals(branch_id);
CREATE INDEX idx_livestock_animals_species ON livestock_animals(species);
CREATE INDEX idx_livestock_animals_status ON livestock_animals(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_livestock_animals_location ON livestock_animals(current_location_id);
CREATE INDEX idx_livestock_animals_birth ON livestock_animals(birth_date);
```

### livestock_weights
```sql
CREATE TABLE livestock_weights (
    weight_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    animal_id               UUID NOT NULL REFERENCES livestock_animals(animal_id),
    weight_date             DATE NOT NULL,
    weight_kg               DECIMAL(10,2) NOT NULL,
    measurement_method      VARCHAR(20) CHECK (measurement_method IN ('scale','visual_estimate','girth_formula')),
    body_condition_score    DECIMAL(3,1),
    weight_gain_kg          DECIMAL(10,2),
    days_since_last_weight  INTEGER,
    adg_g                   DECIMAL(8,2),
    measured_by             UUID,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_livestock_weights_animal ON livestock_weights(animal_id);
CREATE INDEX idx_livestock_weights_date ON livestock_weights(weight_date);
```

### livestock_vaccinations
```sql
CREATE TABLE livestock_vaccinations (
    vaccination_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    animal_ids              UUID[] NOT NULL,
    vaccination_date        DATE NOT NULL,
    vaccine_id              UUID,
    vaccine_name            VARCHAR(200) NOT NULL,
    vaccine_batch           VARCHAR(50),
    vaccination_type        VARCHAR(20) CHECK (vaccination_type IN ('routine','emergency','booster')),
    dose_ml                 DECIMAL(8,2),
    route                   VARCHAR(20) CHECK (route IN ('subcutaneous','intramuscular','oral','nasal','spray')),
    administered_by         UUID,
    next_due_date           DATE,
    location_id             UUID,
    notes                   TEXT,
    attachments             JSONB DEFAULT '[]',
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    created_by              UUID
);

CREATE INDEX idx_livestock_vaccinations_tenant ON livestock_vaccinations(tenant_id);
CREATE INDEX idx_livestock_vaccinations_date ON livestock_vaccinations(vaccination_date);
CREATE INDEX idx_livestock_vaccinations_next ON livestock_vaccinations(next_due_date);
CREATE INDEX idx_livestock_vaccinations_vaccine ON livestock_vaccinations(vaccine_id);
```

### poultry_chicks
```sql
CREATE TABLE poultry_chicks (
    chick_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    batch_number            VARCHAR(30) NOT NULL,
    breed_id                UUID NOT NULL,
    supplier_id             UUID REFERENCES suppliers(supplier_id),
    hatchery                VARCHAR(200),
    arrival_date            DATE NOT NULL,
    age_at_arrival_days     INTEGER DEFAULT 1,
    initial_count           INTEGER NOT NULL,
    current_count           INTEGER NOT NULL,
    mortality_count         INTEGER DEFAULT 0,
    mortality_pct           DECIMAL(5,2) DEFAULT 0,
    culling_count           INTEGER DEFAULT 0,
    current_age_days        INTEGER DEFAULT 0,
    current_day             INTEGER DEFAULT 0,
    house_id                UUID NOT NULL,
    farm_id                 UUID,
    status                  VARCHAR(30) DEFAULT 'active' CHECK (status IN ('reserved','active','growing','ready','sold','mortality_complete')),
    target_weight_kg        DECIMAL(6,2),
    target_days             INTEGER,
    current_avg_weight_g    DECIMAL(8,2),
    fcr_current             DECIMAL(5,3),
    feed_consumed_kg        DECIMAL(15,3) DEFAULT 0,
    vaccination_status      VARCHAR(20) DEFAULT 'on_schedule',
    next_vaccination        JSONB,
    estimated_ready_date    DATE,
    reservation_id          UUID,
    source                  VARCHAR(20) CHECK (source IN ('hatchery','imported','transferred')),
    vaccination_at_source   VARCHAR[] DEFAULT '{}',
    quality_grade           VARCHAR(5) CHECK (quality_grade IN ('a','b','c')),
    cost_per_chick          DECIMAL(19,4),
    transport_cost          DECIMAL(19,4),
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_poultry_chicks UNIQUE (tenant_id, batch_number)
);

CREATE INDEX idx_poultry_chicks_tenant ON poultry_chicks(tenant_id);
CREATE INDEX idx_poultry_chicks_branch ON poultry_chicks(branch_id);
CREATE INDEX idx_poultry_chicks_breed ON poultry_chicks(breed_id);
CREATE INDEX idx_poultry_chicks_status ON poultry_chicks(status) WHERE deleted_at IS NULL;
CREATE INDEX idx_poultry_chicks_house ON poultry_chicks(house_id);
```

### poultry_mortality
```sql
CREATE TABLE poultry_mortality (
    mortality_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    chick_id                UUID NOT NULL REFERENCES poultry_chicks(chick_id),
    house_id                UUID NOT NULL,
    mortality_date          DATE NOT NULL,
    count                   INTEGER NOT NULL,
    cause                   VARCHAR(30) CHECK (cause IN ('disease','heat_stress','suffocation','dehydration','predation','unknown','culling','other')),
    disease_id              UUID,
    symptoms                TEXT,
    post_mortem_findings    TEXT,
    action_taken            TEXT,
    veterinarian_id         UUID,
    attachments             JSONB DEFAULT '[]',
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_poultry_mortality_chick ON poultry_mortality(chick_id);
CREATE INDEX idx_poultry_mortality_date ON poultry_mortality(mortality_date);
CREATE INDEX idx_poultry_mortality_cause ON poultry_mortality(cause);
```

### poultry_vaccinations
```sql
CREATE TABLE poultry_vaccinations (
    vaccination_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    chick_ids               UUID[] NOT NULL,
    house_ids               UUID[] NOT NULL,
    vaccine_id              UUID,
    vaccine_name            VARCHAR(200) NOT NULL,
    vaccination_date        DATE NOT NULL,
    day_age                 INTEGER NOT NULL,
    route                   VARCHAR(20) CHECK (route IN ('drinking_water','spray','eye_drop','injection','wing_web')),
    dose_per_bird           VARCHAR(50),
    administered_by         UUID,
    status                  VARCHAR(20) DEFAULT 'completed' CHECK (status IN ('scheduled','completed','overdue')),
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_poultry_vaccinations_tenant ON poultry_vaccinations(tenant_id);
CREATE INDEX idx_poultry_vaccinations_date ON poultry_vaccinations(vaccination_date);
```

### egg_daily_production
```sql
CREATE TABLE egg_daily_production (
    production_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    production_date         DATE NOT NULL,
    flock_id                UUID NOT NULL,
    house_id                UUID NOT NULL,
    bird_count              INTEGER NOT NULL,
    bird_age_weeks          INTEGER,
    production_stage        VARCHAR(20) CHECK (production_stage IN ('pre_peak','peak','post_peak','declining','molt')),
    total_eggs              INTEGER NOT NULL,
    production_pct          DECIMAL(5,2),
    grade_jumbo             INTEGER DEFAULT 0,
    grade_extra_large       INTEGER DEFAULT 0,
    grade_large             INTEGER DEFAULT 0,
    grade_medium            INTEGER DEFAULT 0,
    grade_small             INTEGER DEFAULT 0,
    defective_cracked       INTEGER DEFAULT 0,
    defective_dirty         INTEGER DEFAULT 0,
    defective_misshapen     INTEGER DEFAULT 0,
    defective_soft_shell    INTEGER DEFAULT 0,
    feed_consumed_kg        DECIMAL(15,3),
    feed_cost               DECIMAL(19,4),
    revenue                 DECIMAL(19,4),
    feed_cost_per_egg       DECIMAL(10,4),
    margin_per_egg          DECIMAL(10,4),
    recorded_by             UUID NOT NULL,
    recorded_at             TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_egg_production UNIQUE (tenant_id, flock_id, production_date)
) PARTITION BY RANGE (production_date);

CREATE INDEX idx_egg_production_tenant ON egg_daily_production(tenant_id);
CREATE INDEX idx_egg_production_branch ON egg_daily_production(branch_id);
CREATE INDEX idx_egg_production_flock ON egg_daily_production(flock_id);
CREATE INDEX idx_egg_production_date ON egg_daily_production(production_date);
```

### egg_grades
```sql
CREATE TABLE egg_grades (
    grade_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    grade_code              VARCHAR(5) NOT NULL,
    grade_name              VARCHAR(20) NOT NULL,
    min_weight_g            DECIMAL(5,2) NOT NULL,
    max_weight_g            DECIMAL(5,2),
    min_diameter_mm         DECIMAL(5,2),
    shell_quality_standard  VARCHAR(50),
    standard_price          DECIMAL(10,4),
    sort_order              INTEGER NOT NULL,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_egg_grades UNIQUE (tenant_id, grade_code)
);
```

### fleet_trips
```sql
CREATE TABLE fleet_trips (
    trip_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    trip_number             VARCHAR(30) NOT NULL,
    vehicle_id              UUID NOT NULL REFERENCES vehicles(vehicle_id),
    driver_id               UUID NOT NULL REFERENCES drivers(driver_id),
    route_id                UUID,
    trip_date               DATE NOT NULL,
    planned_start           TIMESTAMPTZ,
    planned_end             TIMESTAMPTZ,
    actual_start            TIMESTAMPTZ,
    actual_end              TIMESTAMPTZ,
    status                  VARCHAR(20) DEFAULT 'planned' CHECK (status IN ('planned','in_progress','completed','cancelled')),
    stops_count             INTEGER DEFAULT 0,
    completed_stops         INTEGER DEFAULT 0,
    distance_planned_km     DECIMAL(10,2),
    distance_actual_km      DECIMAL(10,2),
    fuel_consumed_l         DECIMAL(10,2),
    fuel_cost               DECIMAL(19,4),
    deliveries_count        INTEGER DEFAULT 0,
    cargo_weight_kg         DECIMAL(10,2),
    delivery_success_pct    DECIMAL(5,2),
    weather_conditions      VARCHAR(50),
    notes                   TEXT,
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    deleted_at              TIMESTAMPTZ,
    CONSTRAINT uq_fleet_trips UNIQUE (tenant_id, branch_id, trip_number)
);

CREATE INDEX idx_fleet_trips_branch ON fleet_trips(branch_id);
CREATE INDEX idx_fleet_trips_vehicle ON fleet_trips(vehicle_id);
CREATE INDEX idx_fleet_trips_driver ON fleet_trips(driver_id);
CREATE INDEX idx_fleet_trips_status ON fleet_trips(status);
CREATE INDEX idx_fleet_trips_date ON fleet_trips(trip_date);
```

### fleet_fuel
```sql
CREATE TABLE fleet_fuel (
    fuel_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    vehicle_id              UUID NOT NULL REFERENCES vehicles(vehicle_id),
    driver_id               UUID NOT NULL REFERENCES drivers(driver_id),
    fuel_date               DATE NOT NULL,
    fuel_type               VARCHAR(20),
    quantity_liters         DECIMAL(10,2) NOT NULL,
    price_per_liter         DECIMAL(10,4) NOT NULL,
    total_cost              DECIMAL(19,4) NOT NULL,
    odometer_km             DECIMAL(12,2),
    station_name            VARCHAR(100),
    payment_method          VARCHAR(20),
    receipt_number          VARCHAR(50),
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_fleet_fuel_vehicle ON fleet_fuel(vehicle_id);
CREATE INDEX idx_fleet_fuel_date ON fleet_fuel(fuel_date);
```

### fleet_maintenance
```sql
CREATE TABLE fleet_maintenance (
    maintenance_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    vehicle_id              UUID NOT NULL REFERENCES vehicles(vehicle_id),
    maintenance_type        VARCHAR(20) CHECK (maintenance_type IN ('preventive','corrective','breakdown','inspection')),
    service_category        VARCHAR(20) CHECK (service_category IN ('oil_change','tire','brake','engine','transmission','electrical','body','ac','other')),
    description             TEXT NOT NULL,
    scheduled_date          DATE,
    completed_date          DATE,
    odometer_km             DECIMAL(12,2),
    cost                    DECIMAL(19,4),
    parts_cost              DECIMAL(19,4),
    labor_cost              DECIMAL(19,4),
    service_provider        VARCHAR(200),
    status                  VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled','in_progress','completed','overdue')),
    next_due_km             DECIMAL(12,2),
    next_due_date           DATE,
    downtime_hours          DECIMAL(5,1),
    notes                   TEXT,
    attachments             JSONB DEFAULT '[]',
    created_by              UUID NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_fleet_maintenance_vehicle ON fleet_maintenance(vehicle_id);
CREATE INDEX idx_fleet_maintenance_status ON fleet_maintenance(status);
CREATE INDEX idx_fleet_maintenance_date ON fleet_maintenance(scheduled_date);
```

### delivery_assignments
```sql
CREATE TABLE delivery_assignments (
    assignment_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    trip_id                 UUID NOT NULL REFERENCES fleet_trips(trip_id),
    stop_sequence           INTEGER NOT NULL,
    invoice_id              UUID REFERENCES sales_invoices(invoice_id),
    customer_id             UUID NOT NULL REFERENCES customers(customer_id),
    customer_address        VARCHAR(300),
    customer_coordinates    GEOGRAPHY(POINT,4326),
    items_summary           JSONB NOT NULL,
    planned_delivery_time   TIMESTAMPTZ,
    actual_delivery_time    TIMESTAMPTZ,
    status                  VARCHAR(20) DEFAULT 'assigned' CHECK (status IN ('assigned','picked_up','in_transit','delivered','failed','returned')),
    pod_status              VARCHAR(20) CHECK (pod_status IN ('pending','signed','photo','code_verified')),
    recipient_name          VARCHAR(100),
    recipient_phone         VARCHAR(20),
    recipient_national_id   VARCHAR(14),
    delivery_notes          TEXT,
    failure_reason          VARCHAR(50),
    return_items            JSONB DEFAULT '[]',
    customer_rating         INTEGER CHECK (customer_rating BETWEEN 1 AND 5),
    customer_feedback       TEXT,
    gps_delivered_at        GEOGRAPHY(POINT,4326),
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_delivery_assignments_trip ON delivery_assignments(trip_id);
CREATE INDEX idx_delivery_assignments_invoice ON delivery_assignments(invoice_id);
CREATE INDEX idx_delivery_assignments_customer ON delivery_assignments(customer_id);
CREATE INDEX idx_delivery_assignments_status ON delivery_assignments(status);
```

### hr_attendance
```sql
CREATE TABLE hr_attendance (
    attendance_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    employee_id             UUID NOT NULL REFERENCES employees(employee_id),
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    date                    DATE NOT NULL,
    check_in                TIME,
    check_out               TIME,
    check_in_location       GEOGRAPHY(POINT,4326),
    check_out_location      GEOGRAPHY(POINT,4326),
    work_hours              DECIMAL(5,2),
    overtime_hours          DECIMAL(5,2) DEFAULT 0,
    late_minutes            INTEGER DEFAULT 0,
    early_departure_minutes INTEGER DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'absent' CHECK (status IN ('present','absent','late','early_departure','on_leave','holiday','weekend')),
    shift_id                UUID,
    device_id               VARCHAR(50),
    biometric_verified      BOOLEAN DEFAULT FALSE,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_hr_attendance UNIQUE (tenant_id, employee_id, date)
);

CREATE INDEX idx_hr_attendance_employee ON hr_attendance(employee_id);
CREATE INDEX idx_hr_attendance_date ON hr_attendance(date);
CREATE INDEX idx_hr_attendance_branch ON hr_attendance(branch_id);
CREATE INDEX idx_hr_attendance_status ON hr_attendance(status);
```

### hr_payroll
```sql
CREATE TABLE hr_payroll (
    payroll_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    branch_id               UUID REFERENCES branches(branch_id),
    month                   INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
    year                    INTEGER NOT NULL,
    pay_date                DATE,
    employee_count          INTEGER DEFAULT 0,
    total_basic_salary      DECIMAL(19,4) DEFAULT 0,
    total_allowances        DECIMAL(19,4) DEFAULT 0,
    total_overtime          DECIMAL(19,4) DEFAULT 0,
    total_commissions       DECIMAL(19,4) DEFAULT 0,
    total_bonuses           DECIMAL(19,4) DEFAULT 0,
    total_gross             DECIMAL(19,4) DEFAULT 0,
    total_deductions        DECIMAL(19,4) DEFAULT 0,
    total_social_insurance  DECIMAL(19,4) DEFAULT 0,
    total_taxes             DECIMAL(19,4) DEFAULT 0,
    total_net               DECIMAL(19,4) DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft','calculated','approved','paid')),
    processed_by            UUID,
    processed_at            TIMESTAMPTZ,
    notes                   TEXT,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_hr_payroll UNIQUE (tenant_id, branch_id, month, year)
);

CREATE INDEX idx_hr_payroll_tenant ON hr_payroll(tenant_id);
CREATE INDEX idx_hr_payroll_period ON hr_payroll(year, month);
CREATE INDEX idx_hr_payroll_status ON hr_payroll(status);
```

### hr_payroll_lines
```sql
CREATE TABLE hr_payroll_lines (
    line_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payroll_id              UUID NOT NULL REFERENCES hr_payroll(payroll_id),
    employee_id             UUID NOT NULL REFERENCES employees(employee_id),
    basic_salary            DECIMAL(19,4) NOT NULL,
    allowances              JSONB DEFAULT '{}',
    overtime_hours          DECIMAL(5,2) DEFAULT 0,
    overtime_amount         DECIMAL(19,4) DEFAULT 0,
    commissions             DECIMAL(19,4) DEFAULT 0,
    bonuses                 DECIMAL(19,4) DEFAULT 0,
    gross_salary            DECIMAL(19,4) DEFAULT 0,
    deductions              JSONB DEFAULT '{}',
    social_insurance_employee DECIMAL(19,4) DEFAULT 0,
    social_insurance_employer DECIMAL(19,4) DEFAULT 0,
    taxable_income          DECIMAL(19,4) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    net_salary              DECIMAL(19,4) DEFAULT 0,
    payment_method          VARCHAR(20) DEFAULT 'bank_transfer',
    bank_account            VARCHAR(50),
    payment_status          VARCHAR(20) DEFAULT 'pending' CHECK (payment_status IN ('pending','processing','paid','failed')),
    paid_at                 TIMESTAMPTZ,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_payroll_lines UNIQUE (payroll_id, employee_id)
);

CREATE INDEX idx_payroll_lines_payroll ON hr_payroll_lines(payroll_id);
CREATE INDEX idx_payroll_lines_employee ON hr_payroll_lines(employee_id);
```

### hr_leaves
```sql
CREATE TABLE hr_leaves (
    leave_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    leave_number            VARCHAR(30) NOT NULL,
    employee_id             UUID NOT NULL REFERENCES employees(employee_id),
    leave_type              VARCHAR(20) CHECK (leave_type IN ('annual','sick','emergency','maternity','paternity','unpaid','pilgrimage','bereavement')),
    start_date              DATE NOT NULL,
    end_date                DATE NOT NULL,
    days                    INTEGER NOT NULL,
    reason                  TEXT,
    status                  VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
    approved_by             UUID,
    approved_at             TIMESTAMPTZ,
    is_paid                 BOOLEAN DEFAULT TRUE,
    balance_before          DECIMAL(5,1),
    balance_after           DECIMAL(5,1),
    attachments             JSONB DEFAULT '[]',
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_hr_leaves UNIQUE (tenant_id, leave_number)
);

CREATE INDEX idx_hr_leaves_employee ON hr_leaves(employee_id);
CREATE INDEX idx_hr_leaves_status ON hr_leaves(status);
CREATE INDEX idx_hr_leaves_dates ON hr_leaves(start_date, end_date);
```

### hr_commissions
```sql
CREATE TABLE hr_commissions (
    commission_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    employee_id             UUID NOT NULL REFERENCES employees(employee_id),
    commission_period       VARCHAR(10) NOT NULL,
    commission_type         VARCHAR(20) CHECK (commission_type IN ('sales','collection','target_bonus','referral')),
    base_amount             DECIMAL(19,4) NOT NULL,
    commission_rate         DECIMAL(8,4) NOT NULL,
    commission_amount       DECIMAL(19,4) NOT NULL,
    tier                    VARCHAR(20),
    targets_achieved        INTEGER DEFAULT 0,
    status                  VARCHAR(20) DEFAULT 'calculated' CHECK (status IN ('calculated','approved','paid')),
    approved_by             UUID,
    approved_at             TIMESTAMPTZ,
    paid_at                 TIMESTAMPTZ,
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_hr_commissions_employee ON hr_commissions(employee_id);
CREATE INDEX idx_hr_commissions_period ON hr_commissions(commission_period);
```

---

## 2.4 Analytics Tables (Star Schema)

### dim_date
```sql
CREATE TABLE dim_date (
    date_key                INTEGER PRIMARY KEY,
    full_date               DATE NOT NULL UNIQUE,
    day_of_week             INTEGER NOT NULL,
    day_name_ar             VARCHAR(20) NOT NULL,
    day_name_en             VARCHAR(20) NOT NULL,
    day_of_month            INTEGER NOT NULL,
    day_of_year             INTEGER NOT NULL,
    week_of_year            INTEGER NOT NULL,
    month_number            INTEGER NOT NULL,
    month_name_ar           VARCHAR(20) NOT NULL,
    month_name_en           VARCHAR(20) NOT NULL,
    quarter                 INTEGER NOT NULL,
    year_number             INTEGER NOT NULL,
    fiscal_quarter          INTEGER NOT NULL,
    fiscal_year             INTEGER NOT NULL,
    is_weekend              BOOLEAN NOT NULL,
    is_holiday              BOOLEAN DEFAULT FALSE,
    holiday_name_ar         VARCHAR(100),
    holiday_name_en         VARCHAR(100),
    is_ramadan              BOOLEAN DEFAULT FALSE,
    season                  VARCHAR(20),
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dim_date_year ON dim_date(year_number);
CREATE INDEX idx_dim_date_fiscal ON dim_date(fiscal_year, fiscal_quarter);
CREATE INDEX idx_dim_date_month ON dim_date(year_number, month_number);
```

### dim_customer
```sql
CREATE TABLE dim_customer (
    customer_key            UUID PRIMARY KEY,
    customer_id             UUID NOT NULL,
    tenant_id               UUID NOT NULL,
    customer_code           VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200),
    name_en                 VARCHAR(200),
    category                VARCHAR(100),
    classification          VARCHAR(5),
    branch_id               UUID,
    governorate             VARCHAR(100),
    sales_rep_id            UUID,
    credit_limit            DECIMAL(19,4),
    status                  VARCHAR(20),
    valid_from              DATE NOT NULL,
    valid_to                DATE DEFAULT '9999-12-31',
    is_current              BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dim_customer_tenant ON dim_customer(tenant_id);
CREATE INDEX idx_dim_customer_current ON dim_customer(is_current);
```

### dim_product
```sql
CREATE TABLE dim_product (
    product_key             UUID PRIMARY KEY,
    product_id              UUID NOT NULL,
    tenant_id               UUID NOT NULL,
    sku                     VARCHAR(50) NOT NULL,
    name_ar                 VARCHAR(200),
    name_en                 VARCHAR(200),
    category                VARCHAR(200),
    subcategory             VARCHAR(200),
    unit_of_measure         VARCHAR(50),
    cost_method             VARCHAR(20),
    is_active               BOOLEAN,
    valid_from              DATE NOT NULL,
    valid_to                DATE DEFAULT '9999-12-31',
    is_current              BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dim_product_tenant ON dim_product(tenant_id);
CREATE INDEX idx_dim_product_current ON dim_product(is_current);
```

### dim_branch
```sql
CREATE TABLE dim_branch (
    branch_key              UUID PRIMARY KEY,
    branch_id               UUID NOT NULL,
    tenant_id               UUID NOT NULL,
    branch_code             VARCHAR(20) NOT NULL,
    name_ar                 VARCHAR(200),
    name_en                 VARCHAR(200),
    branch_type             VARCHAR(30),
    region                  VARCHAR(100),
    governorate             VARCHAR(100),
    manager_id              UUID,
    status                  VARCHAR(20),
    valid_from              DATE NOT NULL,
    valid_to                DATE DEFAULT '9999-12-31',
    is_current              BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dim_branch_tenant ON dim_branch(tenant_id);
```

### dim_employee
```sql
CREATE TABLE dim_employee (
    employee_key            UUID PRIMARY KEY,
    employee_id             UUID NOT NULL,
    tenant_id               UUID NOT NULL,
    employee_code           VARCHAR(20) NOT NULL,
    full_name_ar            VARCHAR(200),
    full_name_en            VARCHAR(200),
    department              VARCHAR(100),
    position                VARCHAR(100),
    job_level               INTEGER,
    branch_id               UUID,
    employment_type         VARCHAR(20),
    status                  VARCHAR(20),
    valid_from              DATE NOT NULL,
    valid_to                DATE DEFAULT '9999-12-31',
    is_current              BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_dim_employee_tenant ON dim_employee(tenant_id);
CREATE INDEX idx_dim_employee_current ON dim_employee(is_current);
```

### fact_sales
```sql
CREATE TABLE fact_sales (
    sale_key                BIGSERIAL,
    date_key                INTEGER NOT NULL REFERENCES dim_date(date_key),
    customer_key            UUID NOT NULL REFERENCES dim_customer(customer_key),
    product_key             UUID NOT NULL REFERENCES dim_product(product_key),
    branch_key              UUID NOT NULL REFERENCES dim_branch(branch_key),
    employee_key            UUID REFERENCES dim_employee(employee_key),
    invoice_id              UUID,
    line_id                 UUID,
    quantity                DECIMAL(15,3) NOT NULL DEFAULT 0,
    unit_price              DECIMAL(19,4) NOT NULL DEFAULT 0,
    discount_amount         DECIMAL(19,4) DEFAULT 0,
    tax_amount              DECIMAL(19,4) DEFAULT 0,
    revenue                 DECIMAL(19,4) NOT NULL DEFAULT 0,
    cost_of_goods_sold      DECIMAL(19,4) DEFAULT 0,
    gross_profit            DECIMAL(19,4) DEFAULT 0,
    channel                 VARCHAR(20),
    payment_terms           VARCHAR(20),
    is_returned             BOOLEAN DEFAULT FALSE,
    return_amount           DECIMAL(19,4) DEFAULT 0,
    created_at              TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (date_key);

-- Partition by year
CREATE TABLE fact_sales_2024 PARTITION OF fact_sales
    FOR VALUES FROM (20240101) TO (20250101);

CREATE INDEX idx_fact_sales_date ON fact_sales(date_key);
CREATE INDEX idx_fact_sales_customer ON fact_sales(customer_key);
CREATE INDEX idx_fact_sales_product ON fact_sales(product_key);
CREATE INDEX idx_fact_sales_branch ON fact_sales(branch_key);
CREATE INDEX idx_fact_sales_composite ON fact_sales(date_key, branch_key, product_key);
```

### fact_inventory
```sql
CREATE TABLE fact_inventory (
    inventory_key           BIGSERIAL,
    date_key                INTEGER NOT NULL REFERENCES dim_date(date_key),
    product_key             UUID NOT NULL REFERENCES dim_product(product_key),
    branch_key              UUID NOT NULL REFERENCES dim_branch(branch_key),
    warehouse_id            UUID,
    quantity_opening        DECIMAL(15,3) DEFAULT 0,
    quantity_received       DECIMAL(15,3) DEFAULT 0,
    quantity_issued         DECIMAL(15,3) DEFAULT 0,
    quantity_adjusted       DECIMAL(15,3) DEFAULT 0,
    quantity_closing        DECIMAL(15,3) DEFAULT 0,
    value_opening           DECIMAL(19,4) DEFAULT 0,
    value_received          DECIMAL(19,4) DEFAULT 0,
    value_issued            DECIMAL(19,4) DEFAULT 0,
    value_closing           DECIMAL(19,4) DEFAULT 0,
    stock_turnover_days     DECIMAL(5,1),
    created_at              TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (date_key);

CREATE INDEX idx_fact_inventory_date ON fact_inventory(date_key);
CREATE INDEX idx_fact_inventory_product ON fact_inventory(product_key);
CREATE INDEX idx_fact_inventory_branch ON fact_inventory(branch_key);
```

### fact_production
```sql
CREATE TABLE fact_production (
    production_key          BIGSERIAL,
    date_key                INTEGER NOT NULL REFERENCES dim_date(date_key),
    product_key             UUID NOT NULL REFERENCES dim_product(product_key),
    branch_key              UUID NOT NULL REFERENCES dim_branch(branch_key),
    line_id                 UUID,
    planned_quantity        DECIMAL(15,3) DEFAULT 0,
    actual_quantity         DECIMAL(15,3) DEFAULT 0,
    planned_cost            DECIMAL(19,4) DEFAULT 0,
    actual_cost             DECIMAL(19,4) DEFAULT 0,
    yield_pct               DECIMAL(5,2),
    efficiency_pct          DECIMAL(5,2),
    downtime_minutes        INTEGER DEFAULT 0,
    waste_quantity          DECIMAL(15,3) DEFAULT 0,
    created_at              TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (date_key);

CREATE INDEX idx_fact_production_date ON fact_production(date_key);
CREATE INDEX idx_fact_production_product ON fact_production(product_key);
```

### fact_financial
```sql
CREATE TABLE fact_financial (
    financial_key           BIGSERIAL,
    date_key                INTEGER NOT NULL REFERENCES dim_date(date_key),
    branch_key              UUID NOT NULL REFERENCES dim_branch(branch_key),
    account_id              UUID,
    account_type            VARCHAR(20),
    debit_amount            DECIMAL(19,4) DEFAULT 0,
    credit_amount           DECIMAL(19,4) DEFAULT 0,
    balance                 DECIMAL(19,4) DEFAULT 0,
    transaction_count       INTEGER DEFAULT 0,
    period_type             VARCHAR(10) CHECK (period_type IN ('daily','monthly','quarterly','yearly')),
    created_at              TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (date_key);

CREATE INDEX idx_fact_financial_date ON fact_financial(date_key);
CREATE INDEX idx_fact_financial_branch ON fact_financial(branch_key);
CREATE INDEX idx_fact_financial_account ON fact_financial(account_id);
```

---

## 2.5 Audit & Compliance Tables

### audit_logs
```sql
CREATE TABLE audit_logs (
    log_id                  BIGSERIAL PRIMARY KEY,
    tenant_id               UUID NOT NULL,
    table_name              VARCHAR(100) NOT NULL,
    record_id               UUID NOT NULL,
    action                  VARCHAR(10) NOT NULL CHECK (action IN ('INSERT','UPDATE','DELETE')),
    old_values              JSONB,
    new_values              JSONB,
    changed_columns         VARCHAR[] DEFAULT '{}',
    changed_by              UUID NOT NULL,
    changed_by_username     VARCHAR(50),
    changed_by_ip           INET,
    changed_at              TIMESTAMPTZ DEFAULT NOW(),
    session_id              VARCHAR(100),
    request_id              VARCHAR(100),
    application_version     VARCHAR(20)
) PARTITION BY RANGE (changed_at);

-- Monthly partitions
CREATE TABLE audit_logs_2024_01 PARTITION OF audit_logs
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

CREATE INDEX idx_audit_logs_tenant ON audit_logs(tenant_id);
CREATE INDEX idx_audit_logs_table ON audit_logs(table_name, record_id);
CREATE INDEX idx_audit_logs_user ON audit_logs(changed_by);
CREATE INDEX idx_audit_logs_time ON audit_logs(changed_at);
```

### activity_logs
```sql
CREATE TABLE activity_logs (
    log_id                  BIGSERIAL PRIMARY KEY,
    tenant_id               UUID NOT NULL,
    user_id                 UUID,
    username                VARCHAR(50),
    action                  VARCHAR(50) NOT NULL,
    entity_type             VARCHAR(50),
    entity_id               UUID,
    description             TEXT,
    metadata                JSONB DEFAULT '{}',
    ip_address              INET,
    user_agent              VARCHAR(500),
    device_info             JSONB,
    severity                VARCHAR(10) DEFAULT 'info' CHECK (severity IN ('debug','info','warning','error','critical')),
    created_at              TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);

CREATE INDEX idx_activity_logs_tenant ON activity_logs(tenant_id);
CREATE INDEX idx_activity_logs_user ON activity_logs(user_id);
CREATE INDEX idx_activity_logs_action ON activity_logs(action);
CREATE INDEX idx_activity_logs_time ON activity_logs(created_at);
CREATE INDEX idx_activity_logs_severity ON activity_logs(severity);
```

### change_history
```sql
CREATE TABLE change_history (
    history_id              BIGSERIAL PRIMARY KEY,
    tenant_id               UUID NOT NULL,
    entity_type             VARCHAR(50) NOT NULL,
    entity_id               UUID NOT NULL,
    version                 INTEGER NOT NULL DEFAULT 1,
    changed_by              UUID NOT NULL,
    changed_at              TIMESTAMPTZ DEFAULT NOW(),
    change_reason           VARCHAR(255),
    snapshot                JSONB NOT NULL,
    CONSTRAINT uq_change_history UNIQUE (tenant_id, entity_type, entity_id, version)
);

CREATE INDEX idx_change_history_entity ON change_history(entity_type, entity_id);
CREATE INDEX idx_change_history_version ON change_history(version);
```

### login_history
```sql
CREATE TABLE login_history (
    login_id                BIGSERIAL PRIMARY KEY,
    tenant_id               UUID NOT NULL,
    user_id                 UUID NOT NULL,
    username                VARCHAR(50),
    login_time              TIMESTAMPTZ DEFAULT NOW(),
    logout_time             TIMESTAMPTZ,
    ip_address              INET,
    user_agent              VARCHAR(500),
    device_type             VARCHAR(20),
    device_id               VARCHAR(100),
    location_city           VARCHAR(100),
    location_country        VARCHAR(2),
    login_status            VARCHAR(20) CHECK (login_status IN ('success','failed','locked_out','session_expired')),
    failure_reason          VARCHAR(100),
    mfa_used                BOOLEAN DEFAULT FALSE,
    mfa_method              VARCHAR(20),
    session_token_hash      VARCHAR(64),
    is_active_session       BOOLEAN DEFAULT TRUE,
    CONSTRAINT uq_login_history UNIQUE (user_id, session_token_hash)
);

CREATE INDEX idx_login_history_user ON login_history(user_id);
CREATE INDEX idx_login_history_time ON login_history(login_time);
CREATE INDEX idx_login_history_status ON login_history(login_status);
CREATE INDEX idx_login_history_active ON login_history(is_active_session) WHERE is_active_session = TRUE;
```

### api_request_logs
```sql
CREATE TABLE api_request_logs (
    log_id                  BIGSERIAL PRIMARY KEY,
    tenant_id               UUID,
    request_id              VARCHAR(100) NOT NULL,
    user_id                 UUID,
    api_key_id              VARCHAR(100),
    method                  VARCHAR(10) NOT NULL,
    path                    VARCHAR(500) NOT NULL,
    query_params            JSONB,
    request_body_hash       VARCHAR(64),
    response_status         INTEGER,
    response_body_hash      VARCHAR(64),
    duration_ms             INTEGER,
    ip_address              INET,
    user_agent              VARCHAR(500),
    rate_limit_hit          BOOLEAN DEFAULT FALSE,
    error_code              VARCHAR(50),
    error_message           TEXT,
    request_at              TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (request_at);

CREATE INDEX idx_api_logs_request_id ON api_request_logs(request_id);
CREATE INDEX idx_api_logs_user ON api_request_logs(user_id);
CREATE INDEX idx_api_logs_path ON api_request_logs(path);
CREATE INDEX idx_api_logs_time ON api_request_logs(request_at);
CREATE INDEX idx_api_logs_status ON api_request_logs(response_status);
CREATE INDEX idx_api_logs_duration ON api_request_logs(duration_ms) WHERE duration_ms > 1000;
```

---

## 2.6 Indexing Strategy

### Primary Index Types
| Index Type | Use Case | Coverage |
|------------|----------|----------|
| **B-Tree (default)** | Equality/range queries on PK, FK, timestamps | All transactional tables |
| **GIN** | Full-text search, JSONB containment, array operations | products, customers, suppliers |
| **GIST** | Geographic/spatial queries | branches, vehicles, delivery coordinates |
| **BRIN** | Very large time-series data | audit_logs, api_request_logs, GPS data |
| **Partial** | Soft-delete filtering | All tables with `deleted_at` |
| **Composite** | Multi-column filtering | Common query patterns |
| **Covering** | Index-only scans | High-read, low-write tables |

### Critical Composite Indexes
```sql
-- Sales analysis by branch, date, customer
CREATE INDEX idx_sales_branch_date_customer ON sales_invoices(branch_id, issue_date, customer_id);

-- Inventory lookup by product + warehouse + batch
CREATE INDEX idx_stock_product_warehouse_batch ON stock_movement_lines(product_id, source_zone_id, batch_number);

-- Financial period queries
CREATE INDEX idx_journal_period_account ON journal_entries(period_year, period_month, branch_id);
CREATE INDEX idx_je_lines_account_period ON journal_entry_lines(account_id) 
    INCLUDE (debit, credit) 
    WHERE entry_id IN (SELECT entry_id FROM journal_entries WHERE status = 'posted');

-- HR attendance lookup
CREATE INDEX idx_attendance_employee_date ON hr_attendance(employee_id, date) 
    INCLUDE (check_in, check_out, status);

-- Fleet operations
CREATE INDEX idx_trips_vehicle_date ON fleet_trips(vehicle_id, trip_date) 
    WHERE status = 'completed';
```

### Index Maintenance
- **Auto-analyze**: Enabled with `autovacuum_analyze_scale_factor = 0.05`
- **REINDEX**: Monthly during maintenance window for high-churn tables
- **Monitoring**: `pg_stat_user_indexes` reviewed weekly for unused indexes

---

## 2.7 Partitioning Strategy

### Partitioning Overview
| Table | Strategy | Partition Key | Granularity | Retention |
|-------|----------|---------------|-------------|-----------|
| `sales_invoices` | RANGE | `issue_date` | Monthly | 7 years |
| `purchase_orders` | RANGE | `order_date` | Monthly | 7 years |
| `stock_movements` | RANGE | `movement_date` | Monthly | 5 years |
| `journal_entries` | RANGE | `entry_date` | Monthly | 10 years |
| `cash_transactions` | RANGE | `transaction_date` | Monthly | 7 years |
| `bank_transactions` | RANGE | `transaction_date` | Monthly | 7 years |
| `hr_attendance` | RANGE | `date` | Monthly | 3 years |
| `egg_daily_production` | RANGE | `production_date` | Monthly | 5 years |
| `audit_logs` | RANGE | `changed_at` | Monthly | 3 years |
| `activity_logs` | RANGE | `created_at` | Monthly | 1 year |
| `api_request_logs` | RANGE | `request_at` | Daily | 90 days |
| `fact_sales` | RANGE | `date_key` | Yearly | 5 years |
| `fact_inventory` | RANGE | `date_key` | Monthly | 2 years |
| `fact_production` | RANGE | `date_key` | Monthly | 3 years |
| `fact_financial` | RANGE | `date_key` | Monthly | 5 years |

### Partition Management
```sql
-- Automated partition creation (cron job)
CREATE OR REPLACE FUNCTION create_monthly_partitions()
RETURNS void AS $$
DECLARE
    next_month DATE := DATE_TRUNC('month', CURRENT_DATE + INTERVAL '1 month');
    partition_name TEXT;
    start_date DATE;
    end_date DATE;
BEGIN
    start_date := next_month;
    end_date := next_month + INTERVAL '1 month';
    
    -- sales_invoices
    partition_name := 'sales_invoices_' || TO_CHAR(start_date, 'YYYY_MM');
    EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF sales_invoices 
                    FOR VALUES FROM (%L) TO (%L)', 
                    partition_name, start_date, end_date);
    
    -- Create indexes on new partition
    EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON %I (branch_id, issue_date)',
                    partition_name || '_idx', partition_name);
END;
$$ LANGUAGE plpgsql;
```

### Data Archival
- Hot data: Primary PostgreSQL cluster
- Warm data (1-2 years): Read replicas
- Cold data (> retention period): S3-compatible object storage (Parquet format)
- Archive retrieval: Automated via `pg_dump` + `aws s3 cp` with 4-hour SLA

---

## 2.8 Soft Delete & Versioning

### Soft Delete Pattern
All tables implement soft delete via `deleted_at` TIMESTAMP field:

```sql
-- Standard soft delete trigger
CREATE OR REPLACE FUNCTION soft_delete()
RETURNS TRIGGER AS $$
BEGIN
    NEW.deleted_at := NOW();
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Row Level Security for soft delete
ALTER TABLE sales_invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY sales_invoices_active_only ON sales_invoices
    FOR ALL
    TO application_user
    USING (deleted_at IS NULL);
```

### Optimistic Locking
```sql
-- Version column for conflict detection
ALTER TABLE sales_invoices ADD COLUMN version INTEGER DEFAULT 1;

-- Check version before update
UPDATE sales_invoices 
SET status = 'confirmed', version = version + 1
WHERE invoice_id = 'uuid' AND version = :expected_version;

-- If no rows updated, return 409 Conflict
```

### Data Versioning (Change History)
The `change_history` table stores point-in-time snapshots:

```sql
-- Trigger to capture version on every UPDATE
CREATE OR REPLACE FUNCTION capture_version()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO change_history (
        tenant_id, entity_type, entity_id, version,
        changed_by, changed_at, change_reason, snapshot
    ) VALUES (
        NEW.tenant_id,
        TG_TABLE_NAME,
        NEW.invoice_id,
        NEW.version,
        NEW.updated_by,
        NOW(),
        NULL,
        row_to_json(OLD)
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
```

### Immutable Audit Trail
```sql
-- Audit trigger for all transactional tables
CREATE OR REPLACE FUNCTION audit_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs (tenant_id, table_name, record_id, action, 
            old_values, new_values, changed_by, changed_at)
        VALUES (NEW.tenant_id, TG_TABLE_NAME, NEW.invoice_id, 'INSERT',
            NULL, row_to_json(NEW), NEW.created_by, NOW());
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs (tenant_id, table_name, record_id, action,
            old_values, new_values, changed_columns, changed_by, changed_at)
        VALUES (NEW.tenant_id, TG_TABLE_NAME, NEW.invoice_id, 'UPDATE',
            row_to_json(OLD), row_to_json(NEW),
            (SELECT array_agg(key) FROM jsonb_each_text(to_jsonb(OLD)) AS old_data 
             JOIN jsonb_each_text(to_jsonb(NEW)) AS new_data USING (key)
             WHERE old_data.value IS DISTINCT FROM new_data.value),
            NEW.updated_by, NOW());
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO audit_logs (tenant_id, table_name, record_id, action,
            old_values, new_values, changed_by, changed_at)
        VALUES (OLD.tenant_id, TG_TABLE_NAME, OLD.invoice_id, 'DELETE',
            row_to_json(OLD), NULL, OLD.updated_by, NOW());
        RETURN OLD;
    END IF;
END;
$$ LANGUAGE plpgsql;
```

---

# Part III: Security Architecture

## 3.1 RBAC -- Role-Based Access Control

### Role Hierarchy
GFF ERP implements a 9-role hierarchy with **role inheritance**, comparable to SAP's PFCG and Oracle's Role-Based Access Control:

```
                    +------------------+
                    | System Admin     |  Level 10
                    | (&#1605;&#1588;&#1585;&#1601; &#1575;&#1604;&#1606;&#1592;&#1575;&#1605;)       |
                    +--------+---------+
                             |
              +--------------+--------------+
              |              |              |
     +--------v------+ +-----v------+ +----v--------+
     | CEO           | | CFO        | | COO         |
     | (&#1575;&#1604;&#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1578;&#1606;&#1601;&#1610;&#1584;&#1610;)  | | (&#1575;&#1604;&#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1605;&#1575;&#1604;&#1610;)   | | (&#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1578;&#1588;&#1594;&#1610;&#1604;)    |
     | Level 9       | | Level 9    | | Level 9     |
     +--------+------+ +-----+------+ +----+--------+
              |              |              |
     +--------v------+ +-----v------+ +----v--------+
     | Branch Manager| | Accountant | | Production  |
     | (&#1605;&#1583;&#1610;&#1585; &#1601;&#1585;&#1593;)     | | (&#1575;&#1604;&#1605;&#1581;&#1575;&#1587;&#1576;)      | | Manager     |
     | Level 7       | | Level 6    | | (&#1605;&#1583;&#1610;&#1585; &#1575;&#1606;&#1578;&#1575;&#1580;)   |
     +--------+------+ |            | | Level 7     |
              |        +-----+------+ +----+--------+
     +--------v------+       |              |
     | Sales Rep     |       |       +------v--------+
     | (&#1605;&#1606;&#1583;&#1608;&#1576; &#1605;&#1576;&#1610;&#1593;&#1575;&#1578;)    |       |       | Warehouse   |
     | Level 4       |       |       | Manager     |
     +---------------+       |       | (&#1605;&#1583;&#1610;&#1585; &#1605;&#1582;&#1586;&#1606;)    |
                             |       | Level 6     |
                             |       +-------------+
                             |
                      +------v--------+
                      | HR Manager    |
                      | (&#1605;&#1583;&#1610;&#1585; &#1605;&#1608;&#1585;&#1583;    |
                      |  &#1605;&#1608;&#1585;&#1583; &#1576;&#1588;&#1585;&#1610;&#1577;)   |
                      | Level 7       |
                      +---------------+
```

### Role Definitions

#### 1. System Administrator (&#1605;&#1588;&#1585;&#1601; &#1575;&#1604;&#1606;&#1592;&#1575;&#1605;)
| Attribute | Value |
|-----------|-------|
| **Level** | 10 |
| **Scope** | All tenants, all branches, all data |
| **Permissions** | `*` (full system access) |
| **Special Rights** | User management, role creation, system configuration, backup/restore, API key management, security policy configuration |
| **Data Access** | All records across all tenants |
| **Approval Authority** | All approval workflows |
| **Concurrent Users** | Max 5 per tenant |

**Permission Slugs:**
- `system.*` - Full system administration
- `users.*` - User CRUD, role assignment
- `settings.*` - All system settings
- `backup.*` - Backup and restore operations
- `audit.*` - Read all audit logs
- `webhooks.*` - Manage webhook integrations
- `ai.models.*` - AI model management

---

#### 2. CEO (&#1575;&#1604;&#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1578;&#1606;&#1601;&#1610;&#1584;&#1610;)
| Attribute | Value |
|-----------|-------|
| **Level** | 9 |
| **Scope** | All branches, all data |
| **Permissions** | Read all modules, executive reports, dashboard, branch comparison |
| **Special Rights** | Branch target setting, strategic planning, executive decisions |
| **Data Access** | All records, aggregated views |
| **Write Access** | Settings, targets, approvals above threshold |

**Permission Slugs:**
- `dashboard.executive`
- `reports.executive.read`
- `reports.custom.read`
- `branches.targets.manage`
- `branches.comparison.read`
- `sales.read.all`
- `accounting.read.all`
- `production.read.all`
- `hr.read.all`
- `fleet.read.all`
- `ai.forecast.read`
- `settings.company.read`

---

#### 3. CFO (&#1575;&#1604;&#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1605;&#1575;&#1604;&#1610;)
| Attribute | Value |
|-----------|-------|
| **Level** | 9 |
| **Scope** | All branches, financial data |
| **Permissions** | Full financial module, accounting, reporting, treasury |
| **Special Rights** | Chart of accounts management, tax configuration, financial period close, payment approvals |
| **Approval Thresholds** | Payments > EGP 100,000, journal entries, payroll |

**Permission Slugs:**
- `accounting.*`
- `payments.*`
- `reports.financial.*`
- `settings.financial.*`
- `tax.*`
- `bank.*`
- `cash.*`
- `reconciliation.*`
- `budget.*`
- `payroll.approve`

---

#### 4. COO (&#1605;&#1583;&#1610;&#1585; &#1575;&#1604;&#1578;&#1588;&#1594;&#1610;&#1604;)
| Attribute | Value |
|-----------|-------|
| **Level** | 9 |
| **Scope** | All branches, operational data |
| **Permissions** | Inventory, production, sales operations, delivery, fleet |
| **Special Rights** | Production scheduling, inventory transfers, operational KPIs |

**Permission Slugs:**
- `inventory.*`
- `production.*`
- `feed.*`
- `sales.read.all`
- `purchases.read.all`
- `delivery.*`
- `fleet.*`
- `production.schedule.manage`
- `inventory.transfer.approve`

---

#### 5. Branch Manager (&#1605;&#1583;&#1610;&#1585; &#1601;&#1585;&#1593;)
| Attribute | Value |
|-----------|-------|
| **Level** | 7 |
| **Scope** | Own branch only |
| **Permissions** | Full operational control of assigned branch |
| **Special Rights** | Employee management (branch), sales target tracking, local inventory decisions |
| **Data Access** | All data within assigned branch |
| **Approval Authority** | Discounts up to 10%, credits up to branch limit, leave approvals |

**Permission Slugs:**
- `inventory.read`, `inventory.write`, `inventory.transfer.create`
- `sales.read`, `sales.write`, `sales.confirm`, `sales.cancel`
- `sales.discount.up_to_10`
- `customers.read`, `customers.write`
- `purchases.read`, `purchases.write`
- `accounting.read`
- `hr.attendance.read`, `hr.attendance.manage`
- `hr.leaves.approve`
- `reports.sales.read`, `reports.inventory.read`
- `delivery.read`, `delivery.write`

---

#### 6. Accountant (&#1575;&#1604;&#1605;&#1581;&#1575;&#1587;&#1576;)
| Attribute | Value |
|-----------|-------|
| **Level** | 6 |
| **Scope** | Assigned branch(es) |
| **Permissions** | Financial transactions, journal entries, reconciliation, reporting |
| **Special Rights** | Journal entry posting, bank reconciliation, financial report generation |
| **Restrictions** | Cannot modify chart of accounts (CFO approval required), cannot reverse posted entries without approval |

**Permission Slugs:**
- `accounting.journal.write`, `accounting.journal.post`
- `accounting.cash.write`, `accounting.bank.write`
- `accounting.reconciliation.write`
- `accounting.read`
- `payments.receive`, `payments.send`
- `sales.read`
- `purchases.read`
- `reports.financial.read`
- `e_invoice.manage`

---

#### 7. Sales Representative (&#1605;&#1606;&#1583;&#1608;&#1576; &#1605;&#1576;&#1610;&#1593;&#1575;&#1578;)
| Attribute | Value |
|-----------|-------|
| **Level** | 4 |
| **Scope** | Own customers, own sales |
| **Permissions** | Create invoices, manage own customers, record visits, view own performance |
| **Special Rights** | Quote creation, customer interaction logging, discount up to 5% |
| **Restrictions** | Cannot view other reps' sales, cannot modify confirmed invoices, cannot view costs |

**Permission Slugs:**
- `sales.write` (own data)
- `sales.read` (own data)
- `sales.quotes.write`
- `sales.discount.up_to_5`
- `customers.write` (assigned customers)
- `customers.read` (assigned customers)
- `customers.interactions.write`
- `delivery.read` (own deliveries)
- `reports.sales.read` (own performance)

---

#### 8. Warehouse Manager (&#1605;&#1583;&#1610;&#1585; &#1605;&#1582;&#1586;&#1606;)
| Attribute | Value |
|-----------|-------|
| **Level** | 6 |
| **Scope** | Assigned warehouse(s) |
| **Permissions** | Stock management, receipts, issues, transfers, stock counts |
| **Special Rights** | Stock adjustment creation (up to EGP 10,000), GRN posting, cycle count scheduling |
| **Restrictions** | Cannot view costs without approval, cannot adjust stock above threshold |

**Permission Slugs:**
- `inventory.*` (warehouse scope)
- `inventory.stock.move`
- `inventory.transfer.create`
- `inventory.adjustment.create`
- `inventory.audit.*`
- `purchases.receive`
- `production.materials.issue`
- `reports.inventory.read`
- `fleet.trips.read` (delivery-related)

---

#### 9. Production Manager (&#1605;&#1583;&#1610;&#1585; &#1575;&#1606;&#1578;&#1575;&#1580;)
| Attribute | Value |
|-----------|-------|
| **Level** | 7 |
| **Scope** | Assigned production lines |
| **Permissions** | Production orders, feed formulations, quality control, line scheduling |
| **Special Rights** | Production order approval, formulation modification, quality parameter setting |
| **Restrictions** | Cannot modify standard costs, cannot approve capital expenditures |

**Permission Slugs:**
- `production.*`
- `production.schedule.manage`
- `production.orders.approve`
- `feed.formulation.write`
- `feed.optimize`
- `feed.ingredient.write`
- `inventory.read` (materials)
- `inventory.stock.move` (materials)
- `quality.*`
- `reports.production.read`

---

### Permission Matrix Summary

| Permission Module | Admin | CEO | CFO | COO | Branch Mgr | Accountant | Sales Rep | WH Mgr | Prod Mgr |
|-------------------|:-----:|:---:|:---:|:---:|:----------:|:----------:|:---------:|:------:|:--------:|
| `users.manage` | CRUD | R | - | - | - | - | - | - | - |
| `roles.manage` | CRUD | - | - | - | - | - | - | - | - |
| `settings.system` | CRUD | R | - | - | - | - | - | - | - |
| `settings.company` | CRUD | R | - | - | - | - | - | - | - |
| `settings.financial` | CRUD | R | CRUD | R | - | - | - | - | - |
| `dashboard.executive` | R | R | R | R | R(own) | - | - | - | - |
| `branches.read` | R | R | R | R | R(own) | R(own) | R(own) | R(own) | R(own) |
| `branches.write` | CRUD | - | - | - | - | - | - | - | - |
| `inventory.read` | R | R | R | R | R(own) | R | - | R(own) | R(mtrl) |
| `inventory.write` | CRUD | - | - | R | R(own) | - | - | R(own) | R(mtrl) |
| `sales.read` | R | R | R | R | R(own) | R(own) | R(own) | - | - |
| `sales.write` | CRUD | - | - | - | R(own) | - | CRUD(own) | - | - |
| `sales.discount` | - | - | - | - | 10% | - | 5% | - | - |
| `purchases.read` | R | R | R | R | R(own) | R(own) | - | R | - |
| `purchases.write` | CRUD | - | - | - | R(own) | - | - | R | - |
| `customers.read` | R | R | R | R | R(own) | R(own) | R(own) | - | - |
| `customers.write` | CRUD | - | - | - | R(own) | - | R(own) | - | - |
| `accounting.read` | R | R | R | R | R(own) | R(own) | - | - | - |
| `accounting.write` | CRUD | - | CRUD | - | - | R(own) | - | - | - |
| `payments.send` | CRUD | - | R(>100k) | - | - | R(<100k) | - | - | - |
| `hr.read` | R | R | - | - | R(own) | - | - | - | - |
| `hr.write` | CRUD | - | - | - | R(own) | - | - | - | - |
| `payroll.approve` | R | - | R | - | - | - | - | - | - |
| `production.read` | R | R | - | R | - | - | - | - | R(own) |
| `production.write` | CRUD | - | - | - | - | - | - | - | R(own) |
| `feed.formulation` | R | - | - | - | - | - | - | - | CRUD |
| `feed.optimize` | R | - | - | - | - | - | - | - | R |
| `fleet.read` | R | R | R | R | R(own) | - | - | R | - |
| `fleet.write` | CRUD | - | - | - | - | - | - | - | - |
| `delivery.read` | R | R | - | R | R(own) | - | R(own) | R | - |
| `ai.forecast.read` | R | R | - | R | R(own) | - | - | R | R |
| `reports.executive` | R | R | R | R | - | - | - | - | - |
| `backup.manage` | CRUD | - | - | - | - | - | - | - | - |
| `webhooks.manage` | CRUD | - | - | - | - | - | - | - | - |
| `audit.read` | R | R | R | R | R(own) | - | - | R(own) | R(own) |

*Legend: CRUD = Create/Read/Update/Delete, R = Read only, R(own) = Read own data only, R(own) = Branch scope, - = No access*

---

## 3.2 ABAC -- Attribute-Based Access Control

### ABAC Policy Engine
GFF ERP extends RBAC with ABAC policies for fine-grained, context-aware access control, comparable to Oracle's ABAC and SAP's User Attribute Management.

### Policy Structure
```json
{
  "policy_id": "pol_001",
  "name": "Branch Manager Data Isolation",
  "description": "Branch managers can only access data from their assigned branch",
  "effect": "allow",
  "subjects": ["role:branch_manager"],
  "resources": ["sales_invoices", "customers", "inventory"],
  "actions": ["read", "write", "update"],
  "conditions": {
    "branch_match": {
      "subject_attribute": "branch_id",
      "resource_attribute": "branch_id",
      "operator": "equals"
    }
  },
  "priority": 100
}
```

### Contextual Attributes
| Attribute Type | Examples | Source |
|----------------|----------|--------|
| **User** | role, branch_id, department, clearance_level, employment_status | JWT token, user profile |
| **Resource** | branch_id, classification, amount, status, owner_id | Database record |
| **Environment** | time_of_day, day_of_week, ip_address, geo_location, device_type | Request context |
| **Action** | read, write, delete, approve, export | HTTP method + endpoint |

### Pre-Defined ABAC Policies

#### Policy 1: Temporal Access Restriction
```json
{
  "name": "No Financial Transactions After Hours",
  "effect": "deny",
  "subjects": ["role:accountant", "role:branch_manager"],
  "resources": ["journal_entries", "payments"],
  "actions": ["write", "post"],
  "conditions": {
    "time_based": {
      "current_time": { "before": "08:00" },
      "current_time": { "after": "18:00" }
    }
  }
}
```

#### Policy 2: Geographic Access Control
```json
{
  "name": "Login from Egypt Only",
  "effect": "deny",
  "subjects": ["*"],
  "resources": ["auth.login"],
  "actions": ["execute"],
  "conditions": {
    "geo_location": {
      "country": { "not_in": ["EG", "SA", "AE", "QA"] }
    },
    "role_exclusion": {
      "not_in": ["system_admin", "ceo"]
    }
  }
}
```

#### Policy 3: Amount-Based Approval
```json
{
  "name": "High Value Invoice Approval",
  "effect": "deny",
  "subjects": ["role:sales_rep"],
  "resources": ["sales_invoices"],
  "actions": ["confirm"],
  "conditions": {
    "amount": {
      "resource_attribute": "total_amount",
      "operator": ">",
      "value": 50000
    }
  }
}
```

#### Policy 4: Device-Based Restriction
```json
{
  "name": "Sensitive Data Desktop Only",
  "effect": "deny",
  "subjects": ["*"],
  "resources": ["reports.executive", "settings.financial"],
  "actions": ["read", "write"],
  "conditions": {
    "device_type": {
      "in": ["mobile_app", "tablet"]
    }
  }
}
```

#### Policy 5: Data Classification
```json
{
  "name": "Customer A-List Data Protection",
  "effect": "deny",
  "subjects": ["role:sales_rep"],
  "resources": ["customers"],
  "actions": ["read"],
  "conditions": {
    "customer_classification": {
      "resource_attribute": "classification",
      "operator": "=",
      "value": "a"
    },
    "not_assigned": {
      "resource_attribute": "sales_rep_id",
      "operator": "!=",
      "subject_attribute": "user_id"
    }
  }
}
```

### Dynamic Data Filtering
ABAC policies dynamically modify SQL queries:

```sql
-- Before ABAC: SELECT * FROM sales_invoices WHERE branch_id = ?
-- After ABAC (Sales Rep):
SELECT * FROM sales_invoices 
WHERE branch_id = :user_branch_id
  AND sales_rep_id = :user_id
  AND total_amount < 50000  -- from amount-based policy
  AND status != 'cancelled'; -- from status policy

-- After ABAC (Branch Manager):
SELECT * FROM sales_invoices 
WHERE branch_id = :user_branch_id  -- branch isolation
  AND deleted_at IS NULL;

-- After ABAC (CEO):
SELECT * FROM sales_invoices 
WHERE deleted_at IS NULL;  -- no branch restriction
```

---

## 3.3 Multi-Factor Authentication (MFA)

### MFA Architecture

```
+--------+     +------------------+     +-------------------+     +--------+
| User   | --> | Authentication   | --> | MFA Challenge     | --> | Access |
| Login  |     | Service          |     | Engine            |     | Token  |
+--------+     +------------------+     +-------------------+     +--------+
                     |                           |
                     v                           v
              +------------+            +------------------+
              | Validate   |            | MFA Methods:     |
              | Password   |            | - TOTP (RFC 6238)|
              +------------+            | - SMS OTP        |
                                        | - Email OTP      |
                                        | - Backup Codes   |
                                        | - Push Notify    |
                                        +------------------+
```

### MFA Methods

| Method | Priority | Use Case | Security Level |
|--------|----------|----------|----------------|
| **TOTP (Time-based OTP)** | Primary | Standard users, mobile apps | High |
| **SMS OTP** | Secondary | Users without smartphones | Medium |
| **Email OTP** | Tertiary | Backup method | Medium |
| **Backup Codes** | Recovery | Account recovery | High (single-use) |
| **Push Notification** | Primary (mobile) | Mobile app users | High |

### TOTP Implementation
```json
{
  "mfa_config": {
    "totp": {
      "issuer": "GFF ERP",
      "algorithm": "SHA256",
      "digits": 6,
      "period": 30,
      "skew": 1,
      "secret_length": 32,
      "qr_code_format": "otpauth://totp/{issuer}:{username}?secret={secret}&issuer={issuer}&algorithm={algorithm}&digits={digits}&period={period}"
    },
    "sms": {
      "code_length": 6,
      "validity_seconds": 300,
      "max_attempts": 3,
      "provider": "vodafone_egypt_sms"
    },
    "email": {
      "code_length": 6,
      "validity_seconds": 600,
      "template": "mfa_verification_email"
    },
    "backup_codes": {
      "count": 10,
      "length": 8,
      "format": "alphanumeric",
      "single_use": true,
      "hashed_storage": "bcrypt"
    }
  }
}
```

### MFA Enrollment Flow
```
1. User navigates to Settings > Security > Enable MFA
2. System generates TOTP secret: base32 encoded, 256-bit
3. Secret encrypted with AES-256-GCM before storage
4. QR code displayed for scanning (Authenticator app)
5. User enters 6-digit code to verify setup
6. 10 backup codes generated and displayed (one-time view)
7. Backup codes hashed with bcrypt, stored individually
8. MFA status: enabled
```

### MFA Enforcement Policies
| User Role | MFA Required | Methods Allowed | Grace Period |
|-----------|-------------|-----------------|--------------|
| System Admin | **Mandatory** | TOTP + Backup Codes | 0 days |
| CEO, CFO, COO | **Mandatory** | TOTP + Backup Codes | 3 days |
| Branch Manager | Required | TOTP or SMS + Backup | 7 days |
| Accountant | Required | TOTP or SMS + Backup | 7 days |
| Sales Rep | Optional (recommended) | Any | 14 days |
| Warehouse Manager | Required | TOTP or SMS | 7 days |
| Production Manager | Optional | Any | 14 days |

### MFA API Endpoints
- `POST /api/v1/auth/mfa/setup` - Enable MFA
- `POST /api/v1/auth/mfa/verify` - Verify MFA code
- `POST /api/v1/auth/mfa/disable` - Disable MFA (admin approval required)
- `POST /api/v1/auth/mfa/backup-codes` - Regenerate backup codes
- `GET /api/v1/auth/mfa/status` - Check MFA status

---

## 3.4 Single Sign-On (SSO)

### SSO Architecture

```
+-------------+     +------------------+     +------------------+
| GFF ERP     | <-> | Identity Provider| <-> | External IdPs    |
| (SP)        |     | (Keycloak/       |     | - Microsoft AD   |
|             |     |  FusionAuth)     |     | - Google Workspace|
|             |     |                  |     | - Okta           |
+-------------+     +------------------+     | - SAML 2.0       |
                                             | - OIDC/OAuth2    |
                                             +------------------+
```

### SAML 2.0 Configuration
```xml
<!-- Service Provider Metadata -->
<EntityDescriptor xmlns="urn:oasis:names:tc:SAML:2.0:metadata"
                  entityID="https://erp.gff.com/saml/metadata">
  <SPSSODescriptor protocolSupportEnumeration="urn:oasis:names:tc:SAML:2.0:protocol">
    <NameIDFormat>urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress</NameIDFormat>
    <AssertionConsumerService 
      Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
      Location="https://erp.gff.com/saml/acs"
      index="1"/>
    <SingleLogoutService
      Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"
      Location="https://erp.gff.com/saml/slo"/>
    <KeyDescriptor use="signing">
      <KeyInfo xmlns="http://www.w3.org/2000/09/xmldsig#">
        <X509Data><X509Certificate>...</X509Certificate></X509Data>
      </KeyInfo>
    </KeyDescriptor>
  </SPSSODescriptor>
</EntityDescriptor>
```

### OIDC Configuration
```json
{
  "oidc": {
    "issuer": "https://idp.gff.com/realms/gff-erp",
    "authorization_endpoint": "https://idp.gff.com/realms/gff-erp/protocol/openid-connect/auth",
    "token_endpoint": "https://idp.gff.com/realms/gff-erp/protocol/openid-connect/token",
    "userinfo_endpoint": "https://idp.gff.com/realms/gff-erp/protocol/openid-connect/userinfo",
    "end_session_endpoint": "https://idp.gff.com/realms/gff-erp/protocol/openid-connect/logout",
    "jwks_uri": "https://idp.gff.com/realms/gff-erp/protocol/openid-connect/certs",
    "scopes_supported": ["openid", "profile", "email", "groups"],
    "claims_supported": ["sub", "email", "name", "preferred_username", "groups"],
    "response_types_supported": ["code", "id_token", "token id_token"]
  }
}
```

### Attribute Mapping
| SAML Attribute | OIDC Claim | GFF ERP Field | Description |
|----------------|-----------|---------------|-------------|
| `urn:oid:1.2.840.113549.1.9.1` | `email` | `users.email` | User email |
| `urn:oid:2.5.4.3` | `name` | `users.full_name_en` | Display name |
| `urn:oid:2.5.4.4` | `family_name` | -- | Last name |
| `urn:oid:2.5.4.42` | `given_name` | -- | First name |
| `groups` | `groups` | `users.role_id` | Group/Role mapping |
| `branch` | `department` | `users.branch_id` | Branch assignment |
| `employeeID` | `sub` | `employees.employee_code` | Employee ID |

### Just-In-Time (JIT) Provisioning
```json
{
  "jit_provisioning": {
    "enabled": true,
    "create_user_if_not_exists": true,
    "default_role": "sales_rep",
    "default_branch": "auto_detect",
    "attribute_mapping": {
      "role_from_group": {
        "ERP-Admins": "system_admin",
        "ERP-Executives": "ceo",
        "ERP-Finance": "accountant",
        "ERP-Sales": "sales_rep"
      }
    },
    "mfa_enforcement": "inherit_from_role"
  }
}
```

### Session Management
| Parameter | Value |
|-----------|-------|
| SAML Assertion Lifetime | 5 minutes |
| Access Token Lifetime | 15 minutes |
| Refresh Token Lifetime | 30 days |
| Maximum Session Duration | 12 hours (idle timeout: 2 hours) |
| Concurrent Sessions | Max 3 per user |
| Session Binding | IP + Device fingerprint |
| SSO Cookie | Secure, HttpOnly, SameSite=Strict |

---

## 3.5 Encryption Architecture

### Encryption at Rest

#### Database Encryption (TDE-equivalent)
```
+----------------------------------------------------------+
| PostgreSQL Cluster                                       |
|  +----------------+  +----------------+                  |
|  | Table Data     |  | WAL Files      |                  |
|  | (AES-256-XTS)  |  | (AES-256-CBC)  |                  |
|  +----------------+  +----------------+                  |
|  +----------------+  +----------------+                  |
|  | Index Data     |  | Backups        |                  |
|  | (AES-256-XTS)  |  | (AES-256-GCM)  |                  |
|  +----------------+  +----------------+                  |
|                                                          |
| Key Management: AWS KMS / HashiCorp Vault               |
| Key Rotation: Automatic, 90-day cycle                   |
+----------------------------------------------------------+
```

#### Column-Level Encryption
| Table | Column | Encryption | Key Type |
|-------|--------|-----------|----------|
| `users` | `password_hash` | bcrypt (cost=12) | Per-tenant salt |
| `users` | `mfa_secret_encrypted` | AES-256-GCM | User-specific key |
| `users` | `mfa_backup_codes` | bcrypt hashes | Individual per code |
| `employees` | `national_id` | AES-256-GCM | Column-specific key |
| `employees` | `bank_account` | AES-256-GCM | Column-specific key |
| `suppliers` | `bank_iban` | AES-256-GCM | Column-specific key |
| `customers` | `tax_id` | AES-256-GCM | Column-specific key |
| `chart_of_accounts` | -- | No encryption (metadata) | -- |

```sql
-- Column encryption using pgcrypto
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Encrypt sensitive column
UPDATE employees 
SET national_id = pgp_sym_encrypt(national_id, current_setting('app.encryption_key'))
WHERE national_id IS NOT NULL;

-- Decrypt for authorized queries
SELECT 
    employee_id,
    full_name_en,
    pgp_sym_decrypt(national_id, current_setting('app.encryption_key')) AS national_id
FROM employees
WHERE employee_id = 'uuid';
```

#### Backup Encryption
```json
{
  "backup_encryption": {
    "algorithm": "AES-256-GCM",
    "key_management": "HashiCorp Vault Transit",
    "key_rotation": "90_days",
    "compression": "zstd",
    "encrypted_filename": "gff-backup-2024-01-15-020000.sql.gz.enc",
    "verification": "sha256_checksum_after_restore"
  }
}
```

### Encryption in Transit

#### TLS Configuration
| Parameter | Value | Standard |
|-----------|-------|----------|
| Protocol | TLS 1.3 | RFC 8446 |
| Minimum Version | TLS 1.2 | Backward compatibility for legacy |
| Certificate | ECDSA P-256 | Let's Encrypt / Internal CA |
| Cipher Suites | TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256 | Modern only |
| HSTS | max-age=63072000; includeSubDomains; preload | OWASP |
| OCSP Stapling | Enabled | Performance + privacy |

#### Internal Service Communication
```
External Client --> [TLS 1.3] --> API Gateway (Nginx/Traefik)
                                        |
                    +-------------------+-------------------+
                    |                   |                   |
              [mTLS]              [mTLS]              [mTLS]
                    |                   |                   |
              Auth Service       App Services      Database
              (JWT signing)      (Business logic)  (TLS + cert auth)
```

#### mTLS (Service-to-Service)
```json
{
  "mtls": {
    "enabled": true,
    "ca_type": "internal_ca",
    "certificate_validity_days": 365,
    "auto_rotation": true,
    "rotation_window_days": 30,
    "services": [
      "api-gateway",
      "auth-service",
      "inventory-service",
      "sales-service",
      "accounting-service",
      "ai-service"
    ]
  }
}
```

### Key Management
| Key Type | Storage | Rotation | Access Control |
|----------|---------|----------|----------------|
| Database encryption key | HashiCorp Vault | Auto 90 days | Vault admin only |
| JWT signing key (RS256) | Vault + HSM backup | Auto 180 days | Auth service only |
| API keys | Vault KV v2 | Manual on compromise | Admin only |
| Column encryption keys | Vault Transit | Auto 90 days | Application role |
| Backup encryption keys | Vault Transit + offline HSM | Auto 90 days | Backup service only |
| mTLS CA private key | Vault PKI + offline HSM | Auto 365 days | Infrastructure only |

---

## 3.6 API Security

### JWT Token Architecture

#### Token Structure (RS256)
```json
// Header
{
  "alg": "RS256",
  "typ": "JWT",
  "kid": "key-2024-01"
}

// Payload (Access Token)
{
  "sub": "uuid-user-id",
  "iss": "gff-erp-auth",
  "aud": "gff-erp-api",
  "iat": 1705313400,
  "exp": 1705314300,
  "nbf": 1705313400,
  "jti": "unique-token-id",
  "tenant_id": "uuid-tenant",
  "branch_id": "uuid-branch",
  "role": "branch_manager",
  "permissions": ["inventory.read", "sales.write"],
  "data_scope": "branch",
  "accessible_branches": ["uuid-branch-1", "uuid-branch-2"],
  "mfa_verified": true,
  "session_id": "uuid-session"
}

// Signature: RS256(private_key, base64url(header) + "." + base64url(payload))
```

#### Token Lifecycle
| Token Type | Lifetime | Storage | Transport |
|------------|----------|---------|-----------|
| Access Token | 15 minutes | Memory only | Authorization header |
| Refresh Token | 30 days | HttpOnly cookie + secure | Cookie |
| ID Token | 15 minutes | N/A | Authorization header |

#### Token Validation
```python
def validate_jwt(token: str) -> TokenPayload:
    """JWT validation with multiple security checks"""
    
    # 1. Signature verification
    try:
        payload = jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            audience="gff-erp-api",
            issuer="gff-erp-auth"
        )
    except jwt.InvalidSignatureError:
        raise AuthError("INVALID_SIGNATURE")
    
    # 2. Token blacklist check (Redis)
    if redis.sismember("token:blacklist", payload["jti"]):
        raise AuthError("TOKEN_REVOKED")
    
    # 3. Session validity check
    session = get_session(payload["session_id"])
    if not session or session.status != "active":
        raise AuthError("SESSION_INVALID")
    
    # 4. Tenant context validation
    if payload["tenant_id"] != request.headers.get("X-Tenant-ID"):
        raise AuthError("TENANT_MISMATCH")
    
    # 5. IP binding (optional)
    if session.ip_address != request.client_ip:
        # Allow if within same ASN/geo
        if not same_network(session.ip_address, request.client_ip):
            log_security_event("IP_MISMATCH", payload)
    
    return TokenPayload(**payload)
```

### Rate Limiting

#### Rate Limit Tiers (Detailed)
| Tier | Requests/Min | Burst | Quota/Day | Scope |
|------|-------------|-------|-----------|-------|
| **Internal** | 10,000 | 1,000 | Unlimited | Microservices |
| **Enterprise** | 1,000 | 200 | 50,000 | ERP web/mobile |
| **Partner** | 500 | 100 | 20,000 | Third-party integrations |
| **Public** | 60 | 20 | 5,000 | Public APIs |
| **Auth** | 10 | 5 | 500 | Login endpoints |
| **AI** | 30 | 10 | 500 | AI/ML endpoints |

#### Rate Limit Implementation
```json
{
  "rate_limiting": {
    "algorithm": "sliding_window",
    "storage": "redis_cluster",
    "headers": {
      "X-RateLimit-Limit": "1000",
      "X-RateLimit-Remaining": "999",
      "X-RateLimit-Reset": "1705314000",
      "X-RateLimit-Policy": "1000;w=60"
    },
    "response_429": {
      "error": {
        "code": "RATE_LIMIT_EXCEEDED",
        "message": "Rate limit exceeded. Retry after 30 seconds.",
        "retry_after": 30
      }
    }
  }
}
```

### CORS Configuration
```json
{
  "cors": {
    "enabled": true,
    "allowed_origins": [
      "https://erp.gff.com",
      "https://admin.gff.com",
      "https://mobile.gff.com",
      "https://*.gff-erp.com"
    ],
    "allowed_methods": ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    "allowed_headers": [
      "Authorization",
      "X-API-Key",
      "X-Request-ID",
      "X-Tenant-ID",
      "X-Branch-ID",
      "Content-Type",
      "Accept-Language",
      "Idempotency-Key",
      "If-Match"
    ],
    "exposed_headers": [
      "X-RateLimit-Limit",
      "X-RateLimit-Remaining",
      "X-API-Version",
      "X-Request-ID"
    ],
    "allow_credentials": true,
    "max_age": 86400,
    "preflight_continue": false
  }
}
```

### Input Validation & Sanitization
| Layer | Technology | Coverage |
|-------|-----------|----------|
| API Gateway | JSON Schema (Draft 2020-12) | Request body validation |
| Application | Joi / Pydantic | Business rule validation |
| Database | CHECK constraints | Referential + domain integrity |
| ORM | SQL injection prevention | Parameterized queries only |
| Output | HTML encoding | XSS prevention |

---

## 3.7 Audit Logging & Non-Repudiation

### Audit Log Categories
| Category | Events Captured | Retention | Storage |
|----------|----------------|-----------|---------|
| **Security** | Logins, logouts, MFA, password changes | 7 years | Immutable (WORM) |
| **Data Access** | CRUD operations on all entities | 5 years | Partitioned tables |
| **Financial** | Journal entries, payments, approvals | 10 years | Immutable (WORM) |
| **System** | Config changes, deployments, backups | 3 years | Standard storage |
| **API** | All API requests/responses | 90 days | Compressed logs |
| **File** | Document uploads, downloads | 3 years | Standard storage |

### Non-Repudiation Implementation
```
Every critical transaction is digitally signed:

1. User performs action (e.g., approve invoice)
2. System generates transaction hash: SHA-256(action_data)
3. System timestamps with certified timestamp (RFC 3161)
4. Hash + timestamp stored in audit log
5. Hash chain: previous_hash = SHA-256(prev_record)
6. Merkle tree for batch verification
7. Regular integrity verification runs
```

```json
{
  "non_repudiation": {
    "hash_algorithm": "SHA-256",
    "timestamp_authority": "Egyptian ITIDA TSA",
    "signature_format": "PKCS#7 / CMS",
    "verification_frequency": "daily",
    "alert_on_tamper": true,
    "blockchain_anchor": {
      "enabled": true,
      "blockchain": "Hyperledger Fabric",
      "anchor_frequency": "hourly"
    }
  }
}
```

### Audit Log Schema (Normalized)
```sql
-- Security-critical: Append-only, no UPDATE/DELETE allowed
CREATE TABLE security_audit (
    event_id                BIGSERIAL PRIMARY KEY,
    event_timestamp         TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    event_hash              VARCHAR(64) NOT NULL,  -- SHA-256 of full record
    previous_hash           VARCHAR(64),           -- Chain link
    event_type              VARCHAR(50) NOT NULL,  -- LOGIN, LOGOUT, MFA, DATA_ACCESS
    severity                VARCHAR(10) DEFAULT 'info',
    user_id                 UUID,
    username                VARCHAR(50),
    session_id              VARCHAR(100),
    ip_address              INET,
    user_agent              VARCHAR(500),
    device_fingerprint      VARCHAR(64),
    geo_country             VARCHAR(2),
    geo_city                VARCHAR(100),
    resource_type           VARCHAR(50),           -- sales_invoice, customer, etc.
    resource_id             UUID,
    action                  VARCHAR(20),           -- CREATE, READ, UPDATE, DELETE
    action_details          JSONB,
    result                  VARCHAR(20),           -- success, failure, denied
    failure_reason          VARCHAR(200),
    risk_score              INTEGER,               -- 0-100
    requires_review         BOOLEAN DEFAULT FALSE,
    reviewed_by             UUID,
    reviewed_at             TIMESTAMPTZ,
    review_notes            TEXT
) WITH (fillfactor=100, autovacuum_enabled=false);

-- Prevent any modification
CREATE RULE security_audit_no_update AS ON UPDATE TO security_audit
    DO INSTEAD NOTHING;
CREATE RULE security_audit_no_delete AS ON DELETE TO security_audit
    DO INSTEAD NOTHING;
```

---

## 3.8 Fraud Detection & Prevention

### Fraud Detection Engine

#### Detection Methods
| Method | Description | Accuracy | Latency |
|--------|-------------|----------|---------|
| **Rule-Based** | Hard-coded business rules | High (known patterns) | Real-time |
| **Statistical** | Z-score, moving averages | Medium | Near real-time |
| **ML Classification** | Supervised anomaly detection | High | Batch (hourly) |
| **Graph Analysis** | Relationship mapping | High | Daily |
| **Behavioral Biometrics** | Typing rhythm, mouse patterns | Medium | Real-time |

#### Pre-Defined Fraud Rules
```json
{
  "fraud_rules": [
    {
      "rule_id": "FRD-001",
      "name": "Unusual Discount",
      "condition": "sales_invoice.discount_pct > 15",
      "severity": "high",
      "action": "block_and_notify",
      "description": "Invoices with discount > 15% require CFO approval"
    },
    {
      "rule_id": "FRD-002",
      "name": "After-Hours Transaction",
      "condition": "transaction.time NOT BETWEEN '06:00' AND '22:00' AND user.role != 'system_admin'",
      "severity": "medium",
      "action": "flag_for_review"
    },
    {
      "rule_id": "FRD-003",
      "name": "Velocity Check - Invoices",
      "condition": "COUNT(invoices) per user per hour > 50",
      "severity": "medium",
      "action": "throttle_and_notify"
    },
    {
      "rule_id": "FRD-004",
      "name": "Duplicate Payment",
      "condition": "payment.amount = previous_payment.amount AND payment.counterparty = previous_payment.counterparty AND time_diff < 1 hour",
      "severity": "high",
      "action": "block_pending_review"
    },
    {
      "rule_id": "FRD-005",
      "name": "Customer Credit Limit Breach",
      "condition": "customer.current_balance > customer.credit_limit * 1.1",
      "severity": "high",
      "action": "block_new_sales"
    },
    {
      "rule_id": "FRD-006",
      "name": "Round-Number Transaction",
      "condition": "payment.amount % 100000 == 0 AND payment.amount > 500000",
      "severity": "low",
      "action": "flag_for_review"
    },
    {
      "rule_id": "FRD-007",
      "name": "IP Geolocation Mismatch",
      "condition": "login.ip_country != user.typical_country AND login.ip_country NOT IN allowed_countries",
      "severity": "medium",
      "action": "require_mfa"
    },
    {
      "rule_id": "FRD-008",
      "name": "Suspicious Stock Adjustment",
      "condition": "ABS(stock_adjustment.total_value) > 50000 AND stock_adjustment.reason = 'other'",
      "severity": "high",
      "action": "require_approval"
    },
    {
      "rule_id": "FRD-009",
      "name": "Negative Inventory",
      "condition": "inventory.available_quantity < 0",
      "severity": "critical",
      "action": "alert_and_block"
    },
    {
      "rule_id": "FRD-010",
      "name": "Journal Entry Imbalance",
      "condition": "journal_entry.total_debit != journal_entry.total_credit AND status = 'posted'",
      "severity": "critical",
      "action": "block_and_alert"
    }
  ]
}
```

### Risk Scoring
```json
{
  "risk_scoring": {
    "transaction_risk": {
      "factors": [
        {"factor": "amount_deviation_from_average", "weight": 0.25},
        {"factor": "time_of_day", "weight": 0.15},
        {"factor": "user_historical_behavior", "weight": 0.20},
        {"factor": "device_trust_score", "weight": 0.15},
        {"factor": "location_risk", "weight": 0.15},
        {"factor": "velocity", "weight": 0.10}
      ],
      "thresholds": {
        "low": 0,
        "medium": 40,
        "high": 70,
        "critical": 90
      }
    },
    "actions_by_risk": {
      "low": "allow",
      "medium": "allow_log",
      "high": "require_approval",
      "critical": "block_notify"
    }
  }
}
```

### ML-Based Anomaly Detection
```python
# Anomaly detection pipeline for financial transactions
class FraudDetectionPipeline:
    def __init__(self):
        self.isolation_forest = IsolationForest(contamination=0.01)
        self.autoencoder = build_autoencoder(input_dim=50)
        
    def score_transaction(self, transaction_features: dict) -> float:
        """Returns anomaly score 0-100"""
        # Feature engineering
        features = self.extract_features(transaction_features)
        
        # Isolation Forest score
        if_score = self.isolation_forest.decision_function([features])[0]
        
        # Autoencoder reconstruction error
        ae_score = self.autoencoder.reconstruction_error(features)
        
        # Combine scores
        combined = 0.6 * normalize(if_score) + 0.4 * normalize(ae_score)
        return combined * 100
    
    def extract_features(self, tx: dict) -> np.ndarray:
        return np.array([
            tx['amount'],
            tx['amount_vs_avg_ratio'],
            tx['hour_of_day'],
            tx['day_of_week'],
            tx['user_daily_tx_count'],
            tx['user_avg_tx_amount'],
            tx['device_trust_score'],
            tx['ip_reputation_score'],
            tx['time_since_last_tx'],
            tx['weekend_flag'],
            # ... additional features
        ])
```

---

## 3.9 Data Privacy & Compliance

### Regulatory Compliance Framework

| Regulation | Scope | Requirements | Implementation |
|------------|-------|--------------|----------------|
| **Egyptian Personal Data Protection Law (PDPL)** | All personal data | Consent, minimization, retention limits | Data classification, consent tracking |
| **ETA E-Invoice Regulation** | All invoices | Digital signature, UUID, XML format | Integrated e-invoice API |
| **CBE Cybersecurity Framework** | Financial data | Encryption, access controls, incident response | Full encryption, RBAC, SOC |
| **GAFI Corporate Governance** | Corporate data | Board oversight, audit trail | Executive reporting, audit logs |
| **Egyptian Tax Law** | Tax records | 5-year retention, immutable | WORM storage, hash chains |
| **Labor Law** | Employee data | Privacy, consent for processing | HR data encryption, access controls |

### Data Classification
```json
{
  "data_classification": {
    "levels": [
      {
        "level": "public",
        "label": "Public",
        "color": "green",
        "description": "Information intended for public disclosure",
        "examples": ["product_catalog", "company_name", "public_price_lists"],
        "encryption": "none",
        "access": "unauthenticated"
      },
      {
        "level": "internal",
        "label": "Internal Use",
        "color": "blue",
        "description": "Internal business information",
        "examples": ["branch_performance", "production_schedules", "internal_reports"],
        "encryption": "TLS in transit",
        "access": "authenticated employees"
      },
      {
        "level": "confidential",
        "label": "Confidential",
        "color": "orange",
        "description": "Sensitive business information",
        "examples": ["customer_data", "supplier_contracts", "financial_statements", "payroll_data"],
        "encryption": "AES-256 at rest + TLS",
        "access": "role-based, need-to-know"
      },
      {
        "level": "restricted",
        "label": "Restricted",
        "color": "red",
        "description": "Highly sensitive information",
        "examples": ["authentication_credentials", "encryption_keys", "board_decisions", "merger_plans"],
        "encryption": "AES-256 + HSM + column-level",
        "access": "minimal, logged, approved"
      }
    ]
  }
}
```

### Consent Management
```sql
CREATE TABLE data_subject_consents (
    consent_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id               UUID NOT NULL,
    data_subject_type       VARCHAR(20) CHECK (data_subject_type IN ('customer','employee','supplier')),
    data_subject_id         UUID NOT NULL,
    consent_type            VARCHAR(50) NOT NULL,
    consent_given           BOOLEAN NOT NULL,
    consent_method          VARCHAR(20) CHECK (consent_method IN ('explicit','implicit','verbal','written')),
    consent_date            TIMESTAMPTZ DEFAULT NOW(),
    consent_expiry          DATE,
    ip_address              INET,
    user_agent              VARCHAR(500),
    withdrawal_date         TIMESTAMPTZ,
    withdrawal_method       VARCHAR(20),
    legal_basis             VARCHAR(50) CHECK (legal_basis IN ('consent','contract','legal_obligation','legitimate_interest','vital_interests')),
    purpose                 TEXT NOT NULL,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_consents_subject ON data_subject_consents(data_subject_type, data_subject_id);
CREATE INDEX idx_consents_type ON data_subject_consents(consent_type, consent_given);
```

### Data Retention & Deletion
```json
{
  "retention_policy": {
    "customer_data": {
      "active": "duration_of_relationship",
      "inactive": "5_years_after_last_transaction",
      "anonymize": true,
      "deletion_procedure": "soft_delete -> 90_days -> purge"
    },
    "employee_data": {
      "active": "duration_of_employment",
      "terminated": "10_years_after_termination",
      "financial_records": "permanent_anonymized"
    },
    "financial_records": {
      "retention": "10_years",
      "format": "immutable_archival"
    },
    "audit_logs": {
      "retention": "7_years",
      "format": "immutable_WORM"
    },
    "api_logs": {
      "retention": "90_days",
      "format": "compressed_archival"
    },
    "gps_tracking": {
      "retention": "1_year",
      "anonymize_after": "6_months"
    }
  }
}
```

### Right to be Forgotten (RTBF) Implementation
```python
async def execute_right_to_be_forgotten(subject_id: UUID, subject_type: str):
    """
    PDPL-compliant data deletion workflow
    """
    # 1. Verify identity and legal basis
    verify_identity(subject_id)
    check_legal_retention_requirements(subject_id)
    
    # 2. Export data (right to portability)
    data_export = await export_personal_data(subject_id, subject_type)
    
    # 3. Revoke all consents
    await revoke_all_consents(subject_id)
    
    # 4. Anonymize transactional data (keep aggregates)
    await anonymize_transactions(subject_id, subject_type)
    
    # 5. Delete or pseudonymize master data
    await delete_master_data(subject_id, subject_type)
    
    # 6. Propagate to third parties
    await notify_data_processors(subject_id, 'DELETION_REQUEST')
    
    # 7. Generate compliance report
    return DeletionReport(
        subject_id=subject_id,
        deletion_date=datetime.now(),
        records_affected=count,
        third_parties_notified=parties,
        legal_basis_for_retention=retained_items,
        completion_certificate=generate_certificate()
    )
```

### Breach Notification Procedure
```
1. DETECTION (automated monitoring)
   |
2. CONTAINMENT (immediate access revocation)
   |
3. ASSESSMENT (within 24 hours)
   |-- Severity classification
   |-- Affected subjects count
   |-- Data types involved
   |
4. NOTIFICATION (within 72 hours of discovery)
   |-- ITIDA (Egyptian authority)
   |-- Affected data subjects
   |-- Board of Directors
   |
5. REMEDIATION
   |-- Root cause analysis
   |-- Security measures implementation
   |-- Verification testing
   |
6. DOCUMENTATION
   |-- Incident report
   |-- Lessons learned
   |-- Policy updates
```

---

## Appendix A: API Endpoint Summary

### Endpoint Count by Module
| Module | Endpoints | Description |
|--------|-----------|-------------|
| Authentication | 14 | Login, MFA, password, sessions |
| Users & Identity | 22 | Users, roles, permissions |
| Inventory | 28 | Products, warehouses, stock, transfers, audits |
| Sales | 24 | Invoices, returns, quotes, orders, channels |
| Purchases | 18 | POs, GRNs, returns, supplier bills |
| Customers | 16 | Profiles, interactions, debt, classifications |
| Suppliers | 14 | Profiles, evaluations, contracts |
| Accounting | 26 | GL, cash, banks, reconciliation, COA, taxes |
| Production | 20 | Orders, lines, scheduling, yield, downtime |
| Feed | 14 | Formulations, ingredients, optimization |
| Livestock | 22 | Animals, weights, feed, vaccinations, breeding |
| Poultry | 24 | Chicks, mortality, vaccinations, reservations |
| Eggs | 16 | Production, inventory, grades, packaging, margins |
| Fleet | 22 | Vehicles, drivers, fuel, maintenance, GPS, routes |
| Delivery | 14 | Assignments, tracking, POD, returns, analytics |
| HR | 28 | Employees, attendance, payroll, leaves, commissions |
| Branches | 12 | Profiles, targets, performance, comparison |
| Reports | 16 | Sales, inventory, financial, production, custom |
| AI & ML | 10 | Forecast, predict, recommend, NLP, models |
| Settings | 16 | Company, system, financial, inventory, backup |
| WebSocket | 12 | Real-time channels |
| Webhooks | 10 | Management, ETA, payments, SMS |
| **TOTAL** | **418** | |

## Appendix B: Database Object Summary

### Object Counts
| Category | Count |
|----------|-------|
| Master Data Tables | 28 |
| Transactional Tables | 42 |
| Analytics Dimension Tables | 5 |
| Analytics Fact Tables | 4 |
| Audit/Compliance Tables | 5 |
| Views | 25 (estimated) |
| Functions/Procedures | 40 (estimated) |
| Triggers | 20 (estimated) |
| Indexes | 200+ |

### Storage Estimates
| Data Type | Rows (Year 1) | Avg Row Size | Total Size |
|-----------|--------------|--------------|------------|
| Master data | 5M | 2KB | ~10GB |
| Transactional | 120M | 1.5KB | ~180GB |
| Analytics (facts) | 500M | 200B | ~100GB |
| Audit logs | 2B | 500B | ~1TB |
| Indexes | -- | -- | ~300GB |
| **Total** | | | **~1.6TB** |

## Appendix C: Security Controls Summary

| Control Category | Implementation | Standard |
|------------------|----------------|----------|
| Authentication | JWT (RS256) + MFA + SSO | OWASP ASVS L3 |
| Authorization | RBAC + ABAC | NIST SP 800-178 |
| Encryption at Rest | AES-256-GCM (column-level + database) | FIPS 140-2 |
| Encryption in Transit | TLS 1.3 + mTLS | RFC 8446 |
| Key Management | HashiCorp Vault + HSM | NIST SP 800-57 |
| Audit Logging | Immutable append-only + hash chain | ISO 27001 |
| Fraud Detection | Rules + ML + behavioral | PCI DSS |
| Data Privacy | PDPL-compliant + consent management | GDPR-aligned |
| API Security | Rate limiting + input validation + CORS | OWASP API Security |
| Network Security | WAF + DDoS protection + micro-segmentation | NIST CSF |

---

*Document Classification: Confidential -- Internal Use Only*
*GFF ERP Enterprise Technical Architecture v1.0.0*
*Copyright (c) 2024 GFF Group. All rights reserved.*
