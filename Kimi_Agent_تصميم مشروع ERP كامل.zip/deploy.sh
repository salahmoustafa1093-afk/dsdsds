#!/bin/bash
# =============================================================================
# GFF ERP - Server Deployment Script
# Run on: Ubuntu 24.04 (173.249.54.81)
# =============================================================================
set -e

GFF_DIR="/opt/gff-erp"
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log()  { echo -e "${GREEN}[GFF]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERR]${NC} $1"; }

# =============================================================================
# 0. Root check
# =============================================================================
if [ "$EUID" -ne 0 ]; then
  err "Run as root: sudo bash deploy.sh"
  exit 1
fi

log "========================================"
log "  GFF ERP Deployment Starting..."
log "  $(date)"
log "========================================"

# =============================================================================
# 1. Install Docker & Docker Compose if missing
# =============================================================================
if ! command -v docker &> /dev/null; then
  log "Installing Docker..."
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl gnupg lsb-release
  mkdir -p /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
  systemctl enable docker
  systemctl start docker
  log "Docker installed"
else
  log "Docker already installed: $(docker --version)"
fi

if ! docker compose version &> /dev/null; then
  err "Docker Compose plugin missing"
  exit 1
fi

# =============================================================================
# 2. Create project directory
# =============================================================================
mkdir -p "$GFF_DIR"
cd "$GFF_DIR"

# =============================================================================
# 3. Generate secrets
# =============================================================================
DB_PASS=$(openssl rand -hex 16)
REDIS_PASS=$(openssl rand -hex 16)
JWT_SECRET=$(openssl rand -hex 32)
JWT_REFRESH=$(openssl rand -hex 32)
API_KEY=$(openssl rand -hex 16)

# =============================================================================
# 4. Write .env
# =============================================================================
cat > "$GFF_DIR/.env" << 'ENVEOF'
# GFF ERP - Production
NODE_ENV=production
PORT=3000
TZ=Africa/Cairo
LOG_LEVEL=info

# Database
DB_USER=gff_user
DB_NAME=gff_erp

# Redis
REDIS_URL=redis://:REDIS_PASS@redis:6379/0

# JWT
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d

# CORS
CORS_ORIGIN=*

# Rate Limiting
API_RATE_LIMIT=1000
API_RATE_LIMIT_WINDOW=60000

# File Upload
MAX_FILE_SIZE=10485760
UPLOAD_DIR=/app/uploads

# Pagination
DEFAULT_PAGE_SIZE=20
MAX_PAGE_SIZE=100

# Feature Flags
FEATURE_SEED_DATA=true
FEATURE_API_DOCUMENTATION=true

# Version
VERSION=latest
ENVEOF

# Fill in generated secrets
sed -i "s|REDIS_PASS|$REDIS_PASS|g" "$GFF_DIR/.env"
echo "DB_PASSWORD=$DB_PASS" >> "$GFF_DIR/.env"
echo "DATABASE_URL=postgresql://gff_user:$DB_PASS@postgres:5432/gff_erp?schema=public&connection_limit=50" >> "$GFF_DIR/.env"
echo "REDIS_PASSWORD=$REDIS_PASS" >> "$GFF_DIR/.env"
echo "JWT_SECRET=$JWT_SECRET" >> "$GFF_DIR/.env"
echo "JWT_REFRESH_SECRET=$JWT_REFRESH" >> "$GFF_DIR/.env"
echo "API_KEY_INTERNAL=$API_KEY" >> "$GFF_DIR/.env"

log ".env created with auto-generated secrets"

# =============================================================================
# 5. Write docker-compose.yml (minimal: Postgres + Redis + Backend + Nginx)
# =============================================================================
cat > "$GFF_DIR/docker-compose.yml" << 'COMPOSEOF'
version: "3.9"

services:
  postgres:
    image: postgres:16-alpine
    container_name: gff-postgres
    restart: unless-stopped
    environment:
      POSTGRES_USER: ${DB_USER:-gff_user}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: ${DB_NAME:-gff_erp}
    volumes:
      - postgres-data:/var/lib/postgresql/data
      - ./init-scripts:/docker-entrypoint-initdb.d:ro
    ports:
      - "127.0.0.1:5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER:-gff_user} -d ${DB_NAME:-gff_erp}"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 30s
    networks:
      - gff-network
    deploy:
      resources:
        limits:
          cpus: "2"
          memory: 2G

  redis:
    image: redis:7-alpine
    container_name: gff-redis
    restart: unless-stopped
    command: redis-server --requirepass ${REDIS_PASSWORD} --appendonly yes
    volumes:
      - redis-data:/data
    ports:
      - "127.0.0.1:6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "${REDIS_PASSWORD}", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - gff-network
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: 512M

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
      target: production
    container_name: gff-backend
    restart: unless-stopped
    env_file:
      - .env
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
    ports:
      - "127.0.0.1:4000:3000"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:3000/api/v1/health", "||", "exit", "1"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    networks:
      - gff-network
    deploy:
      resources:
        limits:
          cpus: "2"
          memory: 2G

  nginx:
    image: nginx:alpine
    container_name: gff-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./frontend/dist:/usr/share/nginx/html:ro
    depends_on:
      backend:
        condition: service_started
    networks:
      - gff-network

volumes:
  postgres-data:
  redis-data:

networks:
  gff-network:
    driver: bridge
COMPOSEOF

log "docker-compose.yml created"

# =============================================================================
# 6. Create directory structure
# =============================================================================
mkdir -p "$GFF_DIR/backend"
mkdir -p "$GFF_DIR/frontend/dist"
mkdir -p "$GFF_DIR/nginx"
mkdir -p "$GFF_DIR/init-scripts"

# =============================================================================
# 7. Write nginx.conf
# =============================================================================
cat > "$GFF_DIR/nginx/nginx.conf" << 'NGINCONF'
events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;
    sendfile      on;
    tcp_nopush    on;
    tcp_nodelay   on;
    keepalive_timeout 65;
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml;

    # Backend API
    server {
        listen 80;
        server_name _;

        location /api/ {
            proxy_pass http://backend:3000;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        location / {
            root /usr/share/nginx/html;
            try_files $uri $uri/ /index.html;
        }
    }
}
NGINCONF

log "nginx.conf created"

# =============================================================================
# 8. Write init script for database
# =============================================================================
cat > "$GFF_DIR/init-scripts/01-init.sql" << 'SQLEOF'
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create initial schema if Prisma migration is not yet run
-- (Prisma will handle actual schema creation)
SQLEOF

# =============================================================================
# 9. Write backend Dockerfile inside backend/
# =============================================================================
cat > "$GFF_DIR/backend/Dockerfile" << 'DOCKEREOF'
# =============================================================================
# GFF Backend - Multi-stage Docker Build
# =============================================================================

# -------- Stage 1: Dependencies --------
FROM node:20-alpine AS deps
RUN apk add --no-cache libc6-compat openssl
WORKDIR /app
COPY package*.json ./
COPY prisma ./prisma/
RUN npm ci --only=production && npm cache clean --force
RUN npx prisma generate

# -------- Stage 2: Builder --------
FROM node:20-alpine AS builder
RUN apk add --no-cache libc6-compat openssl
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY --from=deps /app/node_modules/.prisma ./node_modules/.prisma
COPY . .
RUN npm run build 2>/dev/null || npx tsc --noEmit 2>/dev/null || echo "Build check done"

# -------- Stage 3: Production --------
FROM node:20-alpine AS production
RUN apk add --no-cache openssl wget
WORKDIR /app
ENV NODE_ENV=production

COPY --from=deps /app/node_modules ./node_modules
COPY --from=deps /app/node_modules/.prisma ./node_modules/.prisma
COPY --from=builder /app/dist ./dist
COPY prisma ./prisma/
COPY package.json ./

EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \
  CMD wget --quiet --tries=1 --spider http://localhost:3000/api/v1/health || exit 1

CMD ["sh", "-c", "npx prisma migrate deploy && node dist/main"]
DOCKEREOF

log "Backend Dockerfile created"

# =============================================================================
# 10. Print summary & next steps
# =============================================================================
echo ""
log "========================================"
log "  Deployment Setup COMPLETE"
log "========================================"
echo ""
echo -e "${YELLOW}NEXT STEPS:${NC}"
echo ""
echo -e "1. ${GREEN}Copy backend source${NC} to:"
echo "   $GFF_DIR/backend/"
echo "   (copy: src/, prisma/, package.json, tsconfig*.json, nest-cli.json)"
echo ""
echo -e "2. ${GREEN}Copy frontend dist${NC} to:"
echo "   $GFF_DIR/frontend/dist/"
echo "   (copy: index.html + assets/ folder)"
echo ""
echo -e "3. ${GREEN}Start the stack:${NC}"
echo "   cd $GFF_DIR && docker compose up -d --build"
echo ""
echo -e "4. ${GREEN}Check logs:${NC}"
echo "   cd $GFF_DIR && docker compose logs -f backend"
echo ""
echo -e "5. ${GREEN}Database (Prisma) migration:${NC}"
echo "   cd $GFF_DIR && docker compose exec backend npx prisma migrate deploy"
echo ""
echo -e "${YELLOW}Database Password:${NC}  $DB_PASS"
echo -e "${YELLOW}Redis Password:${NC}     $REDIS_PASS"
echo -e "${YELLOW}JWT Secret:${NC}         $JWT_SECRET"
echo -e "${YELLOW}API Key:${NC}            $API_KEY"
echo ""
echo -e "${RED}SAVE THESE SECRETS!${NC} They are stored in: $GFF_DIR/.env"
echo ""
log "Done!"
