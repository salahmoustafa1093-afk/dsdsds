/**
 * Artillery Load Test Hooks
 *
 * Custom functions for the Artillery load test.
 * Import in load-test.yml via: processor: "./load-test-hooks.js"
 */

/**
 * Generate a random string of specified length
 */
function randomString(length = 8) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Artillery hook: Set authorization header from captured token
 */
function setAuthHeader(requestParams, context, _ee, next) {
  if (context.vars.authToken) {
    requestParams.headers = requestParams.headers || {};
    requestParams.headers.Authorization = `Bearer ${context.vars.authToken}`;
  }
  return next();
}

/**
 * Artillery hook: Log response time for custom metrics
 */
function logResponse(requestParams, response, context, _ee, next) {
  if (response && response.timings) {
    const responseTime = response.timings.response;
    context.vars.lastResponseTime = responseTime;

    // Log slow responses for analysis
    if (responseTime > 500) {
      console.warn(`[SLOW] ${requestParams.url} — ${responseTime}ms (status: ${response.statusCode})`);
    }
  }
  return next();
}

/**
 * Artillery hook: Validate JSON response structure
 */
function validateJsonResponse(requestParams, response, context, _ee, next) {
  if (response && response.body) {
    try {
      const body = JSON.parse(response.body);
      context.vars.responseBody = body;

      // Check for error responses that might not be HTTP errors
      if (body.error || body.errors) {
        console.warn(`[API ERROR] ${requestParams.url} — ${JSON.stringify(body.error || body.errors).substring(0, 200)}`);
      }
    } catch {
      // Not JSON — might be HTML error page
      if (response.body.includes('<html') || response.body.includes('<!DOCTYPE')) {
        console.warn(`[HTML RESPONSE] ${requestParams.url} — returned HTML instead of JSON (status: ${response.statusCode})`);
      }
    }
  }
  return next();
}

/**
 * Artillery hook: Check rate limiting responses
 */
function checkRateLimit(requestParams, response, _context, _ee, next) {
  if (response && response.statusCode === 429) {
    console.warn(`[RATE LIMITED] ${requestParams.url} — Received 429 Too Many Requests`);
  }
  return next();
}

module.exports = {
  setAuthHeader,
  logResponse,
  validateJsonResponse,
  checkRateLimit,
  randomString,
};
