-- =============================================================================
-- GFF Backend — PostgreSQL Load Testing Queries
-- =============================================================================
-- This script contains heavy queries that simulate production load patterns
-- and help identify missing indexes, slow queries, and concurrency bottlenecks.
--
-- Usage:
--   psql -h localhost -U gff_user -d gff_db -f performance/db-load-test.sql
--
-- Or run individual queries with EXPLAIN ANALYZE:
--   EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) <query>;
--
-- Metrics to watch:
--   - Execution time (should be < 500ms for OLTP)
--   - Buffer hits vs reads (high reads = missing index or cold cache)
--   - Rows scanned vs rows returned (high ratio = inefficient query)
-- =============================================================================

-- ─── Configuration ───────────────────────────────────────────────────────────
\set ON_ERROR_STOP off
\timing on

-- ─── Helper: Generate test data if not exists ───────────────────────────────
DO $$
BEGIN
  -- Create test data generation function
  CREATE OR REPLACE FUNCTION generate_load_test_data(target_rows INT DEFAULT 100000)
  RETURNS VOID AS $func$
  DECLARE
    i INT;
    batch_size INT := 1000;
  BEGIN
    -- Check if we already have enough data
    IF (SELECT COUNT(*) FROM invoices) >= target_rows THEN
      RAISE NOTICE 'Sufficient test data already exists (%)', (SELECT COUNT(*) FROM invoices);
      RETURN;
    END IF;

    RAISE NOTICE 'Generating % test rows...', target_rows;

    FOR i IN 1..(target_rows / batch_size) LOOP
      INSERT INTO invoices (
        id, company_id, customer_id, invoice_number, issue_date,
        due_date, total_amount, tax_amount, status, created_at, updated_at
      )
      SELECT
        gen_random_uuid(),
        (SELECT id FROM companies ORDER BY random() LIMIT 1),
        (SELECT id FROM customers ORDER BY random() LIMIT 1),
        'INV-' || LPAD((100000 + (i * batch_size) + s)::TEXT, 6, '0'),
        CURRENT_DATE - (random() * 365)::INT,
        CURRENT_DATE - (random() * 365)::INT + 30,
        round((random() * 10000 + 100)::numeric, 2),
        round((random() * 1600 + 16)::numeric, 2),
        (ARRAY['draft', 'sent', 'paid', 'overdue', 'cancelled'])[1 + (random() * 4)::INT],
        NOW() - (random() * INTERVAL '365 days'),
        NOW() - (random() * INTERVAL '30 days')
      FROM generate_series(1, batch_size) s;

      IF i % 10 = 0 THEN
        RAISE NOTICE 'Inserted % of % rows', i * batch_size, target_rows;
        COMMIT;
      END IF;
    END LOOP;

    RAISE NOTICE 'Test data generation complete.';
  END;
  $func$ LANGUAGE plpgsql;
END $$;

-- ─── TEST SUITE 1: Heavy Aggregation Queries (Report Generation) ────────────

-- Test 1.1: Sales summary by month (simulates sales report)
-- Expected: Uses index on invoices(issue_date, company_id)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT
  DATE_TRUNC('month', issue_date) AS month,
  COUNT(*) AS invoice_count,
  SUM(total_amount) AS total_revenue,
  SUM(tax_amount) AS total_tax,
  AVG(total_amount) AS avg_invoice_value,
  status,
  COUNT(DISTINCT customer_id) AS unique_customers
FROM invoices
WHERE company_id = (SELECT id FROM companies LIMIT 1)
  AND issue_date >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', issue_date), status
ORDER BY month DESC, status;

-- Test 1.2: Product sales ranking (simulates inventory report)
-- Expected: Uses index on invoice_items(product_id, created_at)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT
  p.id,
  p.name,
  p.sku,
  SUM(ii.quantity) AS total_quantity_sold,
  SUM(ii.quantity * ii.unit_price) AS total_revenue,
  AVG(ii.unit_price) AS avg_selling_price,
  COUNT(DISTINCT ii.invoice_id) AS num_invoices
FROM products p
JOIN invoice_items ii ON ii.product_id = p.id
JOIN invoices i ON i.id = ii.invoice_id
WHERE i.company_id = (SELECT id FROM companies LIMIT 1)
  AND i.issue_date >= CURRENT_DATE - INTERVAL '6 months'
  AND i.status IN ('sent', 'paid')
GROUP BY p.id, p.name, p.sku
ORDER BY total_revenue DESC
LIMIT 100;

-- Test 1.3: Aging report (AR aging)
-- Expected: Uses index on invoices(due_date, status)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT
  c.name AS customer_name,
  c.id AS customer_id,
  SUM(CASE WHEN i.due_date >= CURRENT_DATE THEN i.total_amount ELSE 0 END) AS current,
  SUM(CASE WHEN i.due_date BETWEEN CURRENT_DATE - INTERVAL '30 days' AND CURRENT_DATE - INTERVAL '1 day'
    THEN i.total_amount ELSE 0 END) AS days_1_30,
  SUM(CASE WHEN i.due_date BETWEEN CURRENT_DATE - INTERVAL '60 days' AND CURRENT_DATE - INTERVAL '31 days'
    THEN i.total_amount ELSE 0 END) AS days_31_60,
  SUM(CASE WHEN i.due_date BETWEEN CURRENT_DATE - INTERVAL '90 days' AND CURRENT_DATE - INTERVAL '61 days'
    THEN i.total_amount ELSE 0 END) AS days_61_90,
  SUM(CASE WHEN i.due_date < CURRENT_DATE - INTERVAL '90 days'
    THEN i.total_amount ELSE 0 END) AS days_90_plus,
  SUM(i.total_amount) AS total_outstanding
FROM customers c
JOIN invoices i ON i.customer_id = c.id
WHERE i.company_id = (SELECT id FROM companies LIMIT 1)
  AND i.status IN ('sent', 'overdue')
GROUP BY c.id, c.name
ORDER BY total_outstanding DESC;

-- Test 1.4: Financial statement (P&L summary)
-- Expected: Uses index on transactions(company_id, date, type)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT
  DATE_TRUNC('month', t.date) AS period,
  SUM(CASE WHEN t.type = 'revenue' THEN t.amount ELSE 0 END) AS total_revenue,
  SUM(CASE WHEN t.type = 'expense' THEN t.amount ELSE 0 END) AS total_expenses,
  SUM(CASE WHEN t.type = 'revenue' THEN t.amount ELSE -t.amount END) AS net_income,
  COUNT(*) FILTER (WHERE t.type = 'revenue') AS revenue_transactions,
  COUNT(*) FILTER (WHERE t.type = 'expense') AS expense_transactions
FROM transactions t
WHERE t.company_id = (SELECT id FROM companies LIMIT 1)
  AND t.date >= CURRENT_DATE - INTERVAL '12 months'
GROUP BY DATE_TRUNC('month', t.date)
ORDER BY period DESC;

-- ─── TEST SUITE 2: Missing Index Detection ──────────────────────────────────

-- Test 2.1: Full table scan on invoices (deliberately missing WHERE clause)
-- This will scan ALL invoices — use to test table scan performance
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT *
FROM invoices
WHERE notes LIKE '%special%'
ORDER BY created_at DESC
LIMIT 100;

-- Test 2.2: No index on customer phone number search
-- Will likely do seq scan if no index on customers(phone)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT id, name, email, phone, address
FROM customers
WHERE phone LIKE '+1-555%'
  AND company_id = (SELECT id FROM companies LIMIT 1)
ORDER BY name
LIMIT 50;

-- Test 2.3: Product search by description (text search without index)
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT id, name, sku, description, price, stock_quantity
FROM products
WHERE (
  name ILIKE '%cable%' OR
  description ILIKE '%cable%' OR
  sku ILIKE '%CABLE%'
)
  AND company_id = (SELECT id FROM companies LIMIT 1)
ORDER BY name
LIMIT 50;

-- Test 2.4: Date range scan without proper index
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT i.*, c.name AS customer_name
FROM invoices i
JOIN customers c ON c.id = i.customer_id
WHERE i.created_at BETWEEN '2023-01-01' AND '2023-12-31'
  AND i.total_amount > 5000
ORDER BY i.total_amount DESC;

-- ─── TEST SUITE 3: Concurrent Transaction Tests ─────────────────────────────

-- Test 3.1: Simultaneous invoice status updates
-- Run this from multiple sessions concurrently
DO $$
DECLARE
  v_invoice_id UUID;
  v_new_status TEXT;
  statuses TEXT[] := ARRAY['sent', 'paid', 'overdue'];
BEGIN
  FOR i IN 1..100 LOOP
    SELECT id INTO v_invoice_id
    FROM invoices
    WHERE status = 'draft'
    ORDER BY random()
    LIMIT 1
    FOR UPDATE SKIP LOCKED;

    IF v_invoice_id IS NOT NULL THEN
      v_new_status := statuses[1 + (random() * 2)::INT];

      UPDATE invoices
      SET status = v_new_status, updated_at = NOW()
      WHERE id = v_invoice_id;

      INSERT INTO audit_log (entity_type, entity_id, action, changes, performed_at)
      VALUES ('invoice', v_invoice_id, 'status_change',
        jsonb_build_object('new_status', v_new_status), NOW());
    END IF;

    COMMIT;
    PERFORM pg_sleep(0.01); -- 10ms between operations
  END LOOP;
END $$;

-- Test 3.2: Concurrent inventory updates (race condition test)
-- Simulates multiple users updating inventory simultaneously
DO $$
DECLARE
  v_product_id UUID;
  v_delta INT;
BEGIN
  FOR i IN 1..100 LOOP
    SELECT id INTO v_product_id
    FROM products
    WHERE stock_quantity > 10
    ORDER BY random()
    LIMIT 1
    FOR UPDATE SKIP LOCKED;

    IF v_product_id IS NOT NULL THEN
      v_delta := (random() * 10 - 5)::INT;

      UPDATE products
      SET stock_quantity = stock_quantity + v_delta,
          updated_at = NOW()
      WHERE id = v_product_id;
    END IF;

    COMMIT;
  END LOOP;
END $$;

-- Test 3.3: Deadlock simulation — circular dependency
-- Run simultaneously in two sessions with different table order
DO $$
DECLARE
  v_cust_id UUID;
  v_inv_id UUID;
BEGIN
  -- Session A order: customers → invoices
  SELECT id INTO v_cust_id FROM customers ORDER BY random() LIMIT 1;
  SELECT id INTO v_inv_id FROM invoices ORDER BY random() LIMIT 1;

  UPDATE customers SET updated_at = NOW() WHERE id = v_cust_id;
  PERFORM pg_sleep(0.1);
  UPDATE invoices SET updated_at = NOW() WHERE id = v_inv_id;

  COMMIT;
END $$;

-- ─── TEST SUITE 4: Lock Contention Detection ────────────────────────────────

-- Test 4.1: Identify queries holding locks for too long
SELECT
  pid,
  now() - query_start AS duration,
  state,
  wait_event_type,
  wait_event,
  LEFT(query, 100) AS query_snippet
FROM pg_stat_activity
WHERE state != 'idle'
  AND query_start < NOW() - INTERVAL '5 seconds'
ORDER BY query_start;

-- Test 4.2: Check for blocked queries
SELECT
  blocked_locks.pid AS blocked_pid,
  blocked_activity.usename AS blocked_user,
  blocking_locks.pid AS blocking_pid,
  blocking_activity.usename AS blocking_user,
  blocked_activity.query AS blocked_query,
  blocking_activity.query AS blocking_query
FROM pg_catalog.pg_locks blocked_locks
JOIN pg_catalog.pg_stat_activity blocked_activity ON blocked_activity.pid = blocked_locks.pid
JOIN pg_catalog.pg_locks blocking_locks
  ON blocking_locks.locktype = blocked_locks.locktype
  AND blocking_locks.relation = blocked_locks.relation
  AND blocking_locks.pid != blocked_locks.pid
JOIN pg_catalog.pg_stat_activity blocking_activity ON blocking_activity.pid = blocking_locks.pid
WHERE NOT blocked_locks.granted;

-- ─── TEST SUITE 5: Index Usage Statistics ───────────────────────────────────

-- Check which indexes are being used (run after load test)
SELECT
  schemaname,
  tablename,
  indexname,
  idx_scan AS index_scans,
  idx_tup_read AS tuples_read,
  idx_tup_fetch AS tuples_fetched,
  pg_size_pretty(pg_relation_size(indexrelid)) AS index_size
FROM pg_stat_user_indexes
WHERE schemaname = 'public'
ORDER BY idx_scan DESC;

-- Check for sequential scans on large tables (indicates missing indexes)
SELECT
  schemaname,
  relname AS table_name,
  seq_scan AS sequential_scans,
  seq_tup_read AS seq_tuples_read,
  idx_scan AS index_scans,
  n_live_tup AS live_tuples,
  pg_size_pretty(pg_total_relation_size(relid)) AS total_size
FROM pg_stat_user_tables
WHERE schemaname = 'public'
  AND n_live_tup > 1000
ORDER BY seq_scan DESC;

-- ─── TEST SUITE 6: Cache Performance ────────────────────────────────────────

-- Check buffer cache hit ratio (should be > 95%)
SELECT
  schemaname,
  relname,
  heap_blks_read AS disk_reads,
  heap_blks_hit AS cache_hits,
  CASE WHEN (heap_blks_hit + heap_blks_read) > 0
    THEN round(100.0 * heap_blks_hit / (heap_blks_hit + heap_blks_read), 2)
    ELSE 0
  END AS cache_hit_ratio
FROM pg_statio_user_tables
WHERE schemaname = 'public'
ORDER BY heap_blks_read DESC;

-- Overall cache hit ratio
SELECT
  sum(heap_blks_read) AS total_disk_reads,
  sum(heap_blks_hit) AS total_cache_hits,
  round(100.0 * sum(heap_blks_hit) / nullif(sum(heap_blks_hit) + sum(heap_blks_read), 0), 2) AS overall_hit_ratio
FROM pg_statio_user_tables;

-- ─── TEST SUITE 7: Long-Running Query Detection ─────────────────────────────

-- Find queries running longer than threshold
SELECT
  pid,
  usename,
  application_name,
  client_addr,
  state,
  now() - query_start AS query_duration,
  now() - state_change AS state_duration,
  LEFT(query, 200) AS query_text
FROM pg_stat_activity
WHERE state = 'active'
  AND query_start < NOW() - INTERVAL '1 second'
  AND query NOT LIKE '%pg_stat_activity%'
ORDER BY query_duration DESC;

-- ─── Cleanup ────────────────────────────────────────────────────────────────
-- Remove test data if needed (uncomment to use)
-- DELETE FROM invoices WHERE invoice_number LIKE 'INV-LOADTEST-%';
-- VACUUM ANALYZE invoices;
