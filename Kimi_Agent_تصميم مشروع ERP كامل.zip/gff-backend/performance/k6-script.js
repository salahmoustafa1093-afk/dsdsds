#!/usr/bin/env node
// =============================================================================
// GFF Backend — k6 Load Testing Script
// =============================================================================
// Runs load tests using k6 with scenarios:
//   - loginScenario
//   - invoiceCreateScenario
//   - dashboardScenario
//   - searchScenario
//   - reportScenario
//
// Usage:
//   k6 run performance/k6-script.js
//
// Environment Variables:
//   API_BASE_URL    - Target API base URL (default: http://localhost:3000)
//   TEST_EMAIL      - Test user email
//   TEST_PASSWORD   - Test user password
//   JWT_TOKEN       - Pre-generated JWT token (optional, skips login)
//
// Output:
//   k6 outputs metrics to stdout and can export to:
//   --out json=results.json
//   --out influxdb=http://localhost:8086/k6
//   --out prometheus
// =============================================================================

import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend, Counter, Gauge } from 'k6/metrics';
import { randomIntBetween } from 'https://jslib.k6.io/k6-utils/1.2.0/index.js';

// ─── Custom Metrics ─────────────────────────────────────────────────────────
const errorRate = new Rate('errors');
const loginResponseTime = new Trend('login_response_time');
const invoiceCreateTime = new Trend('invoice_create_time');
const dashboardLoadTime = new Trend('dashboard_load_time');
const searchResponseTime = new Trend('search_response_time');
const reportGenTime = new Trend('report_generation_time');
const successCounter = new Counter('successful_requests');
const failureCounter = new Counter('failed_requests');
const activeVUs = new Gauge('active_virtual_users');

// ─── Configuration ──────────────────────────────────────────────────────────
const BASE_URL = __ENV.API_BASE_URL || 'http://localhost:3000';
const TEST_EMAIL = __ENV.TEST_EMAIL || 'test@example.com';
const TEST_PASSWORD = __ENV.TEST_PASSWORD || 'Test123!';

// ─── k6 Options ─────────────────────────────────────────────────────────────
export const options = {
  // Thresholds
  thresholds: {
    // p95 response time < 500ms
    http_req_duration: ['p(95)<500'],
    http_req_duration: ['p(99)<1000'],
    // Error rate < 1%
    http_req_failed: ['rate<0.01'],
    errors: ['rate<0.01'],
    // Custom metric thresholds
    login_response_time: ['p(95)<300'],
    invoice_create_time: ['p(95)<800'],
    dashboard_load_time: ['p(95)<400'],
    search_response_time: ['p(95)<300'],
    report_generation_time: ['p(95)<2000'],
  },

  // Load phases — ramping VUs
  stages: [
    // Warm-up: 10 VUs for 2 minutes
    { duration: '2m', target: 10 },
    // Ramp-up: 10 → 100 VUs over 3 minutes
    { duration: '3m', target: 100 },
    // Sustained: 100 VUs for 3 minutes
    { duration: '3m', target: 100 },
    // Spike: 100 → 200 VUs over 1 minute
    { duration: '1m', target: 200 },
    // Peak sustained: 200 VUs for 2 minutes
    { duration: '2m', target: 200 },
    // Ramp-down: 200 → 50 VUs over 2 minutes
    { duration: '2m', target: 50 },
    // Cool-down: 50 → 0 VUs over 1 minute
    { duration: '1m', target: 0 },
  ],

  // Alternative: scenarios-based configuration (uncomment to use)
  // scenarios: {
  //   login_flow: {
  //     executor: 'ramping-vus',
  //     startVUs: 10,
  //     stages: [
  //       { duration: '2m', target: 50 },
  //       { duration: '5m', target: 50 },
  //       { duration: '1m', target: 0 },
  //     ],
  //     exec: 'loginScenario',
  //   },
  //   invoice_flow: {
  //     executor: 'ramping-vus',
  //     startVUs: 5,
  //     stages: [
  //       { duration: '2m', target: 30 },
  //       { duration: '5m', target: 30 },
  //       { duration: '1m', target: 0 },
  //     ],
  //     exec: 'invoiceCreateScenario',
  //   },
  // },
};

// ─── Shared State ───────────────────────────────────────────────────────────
let authToken = __ENV.JWT_TOKEN || null;
let userId = null;
let companyId = null;

// ─── Helper Functions ───────────────────────────────────────────────────────

/**
 * Make an HTTP request with common headers and error handling.
 */
function makeRequest(method, url, body = null, headers = {}) {
  const defaultHeaders = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    ...headers,
  };

  const response = body
    ? http.request(method, url, JSON.stringify(body), { headers: defaultHeaders })
    : http.request(method, url, null, { headers: defaultHeaders });

  // Update custom metrics
  const isError = response.status >= 400 || response.error;
  errorRate.add(isError ? 1 : 0);

  if (isError) {
    failureCounter.add(1);
  } else {
    successCounter.add(1);
  }

  // Log slow requests
  if (response.timings.duration > 500) {
    console.warn(`[SLOW] ${method} ${url} — ${response.timings.duration}ms (status: ${response.status})`);
  }

  return response;
}

/**
 * Extract and cache JWT token from login response.
 */
function authenticate() {
  if (authToken) return authToken;

  const loginRes = makeRequest('POST', `${BASE_URL}/api/auth/login`, {
    email: TEST_EMAIL,
    password: TEST_PASSWORD,
  });

  const passed = check(loginRes, {
    'login status is 200': (r) => r.status === 200,
    'login returns token': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.access_token && typeof body.access_token === 'string';
      } catch {
        return false;
      }
    },
  });

  if (passed) {
    const body = JSON.parse(loginRes.body);
    authToken = body.access_token;
    userId = body.user?.id;
    companyId = body.user?.companyId;
    loginResponseTime.add(loginRes.timings.duration);
  } else {
    console.error(`[LOGIN FAILED] Status: ${loginRes.status}, Body: ${loginRes.body?.substring(0, 200)}`);
  }

  return authToken;
}

// ─── Test Scenarios ─────────────────────────────────────────────────────────

/**
 * Scenario 1: Login Flow
 * Tests authentication endpoint under load.
 */
export function loginScenario() {
  group('Login Flow', () => {
    const start = Date.now();

    const res = makeRequest('POST', `${BASE_URL}/api/auth/login`, {
      email: TEST_EMAIL,
      password: TEST_PASSWORD,
    });

    const passed = check(res, {
      'login: status is 200': (r) => r.status === 200,
      'login: response time < 300ms': (r) => r.timings.duration < 300,
      'login: returns JSON': (r) => r.headers['Content-Type']?.includes('application/json'),
    });

    loginResponseTime.add(Date.now() - start);

    if (passed) {
      sleep(randomIntBetween(1, 3));
    } else {
      sleep(5); // Back off on failure
    }
  });
}

/**
 * Scenario 2: Invoice Create
 * Full invoice creation flow: login → create customer → create invoice → verify.
 */
export function invoiceCreateScenario() {
  group('Invoice Create', () => {
    const start = Date.now();
    const token = authenticate();
    if (!token) {
      sleep(5);
      return;
    }

    const authHeader = { Authorization: `Bearer ${token}` };

    // Step 1: Create customer
    const customerRes = makeRequest(
      'POST',
      `${BASE_URL}/api/customers`,
      {
        name: `LoadTest Customer ${Date.now()}`,
        email: `customer-${randomIntBetween(10000, 99999)}@test.com`,
        phone: `+1-555-${randomIntBetween(1000, 9999)}`,
        address: `${randomIntBetween(1, 9999)} Test Avenue`,
        taxId: `TAX-${randomIntBetween(100000, 999999)}`,
      },
      authHeader,
    );

    check(customerRes, {
      'invoice: customer created (201)': (r) => r.status === 201,
      'invoice: customer create < 500ms': (r) => r.timings.duration < 500,
    });

    let customerId = null;
    try {
      customerId = JSON.parse(customerRes.body).id;
    } catch {
      // Continue without customer
    }

    // Step 2: Create invoice
    const invoiceRes = makeRequest(
      'POST',
      `${BASE_URL}/api/invoices`,
      {
        customerId: customerId || '00000000-0000-0000-0000-000000000000',
        invoiceNumber: `INV-${randomIntBetween(100000, 999999)}`,
        issueDate: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
        items: [
          { description: 'Product A', quantity: 2, unitPrice: 99.99, taxRate: 16 },
          { description: 'Product B', quantity: 5, unitPrice: 49.99, taxRate: 16 },
          { description: 'Service C', quantity: 1, unitPrice: 250.0, taxRate: 16 },
        ],
        notes: 'Load test invoice',
        paymentTerms: 'Net 30',
      },
      authHeader,
    );

    check(invoiceRes, {
      'invoice: created (201 or 202)': (r) => r.status === 201 || r.status === 202,
      'invoice: create < 800ms': (r) => r.timings.duration < 800,
      'invoice: returns id': (r) => {
        try {
          return !!JSON.parse(r.body).id;
        } catch {
          return false;
        }
      },
    });

    invoiceCreateTime.add(Date.now() - start);
    sleep(randomIntBetween(2, 4));
  });
}

/**
 * Scenario 3: Dashboard Load
 * Tests dashboard endpoints that aggregate data.
 */
export function dashboardScenario() {
  group('Dashboard Load', () => {
    const start = Date.now();
    const token = authenticate();
    if (!token) {
      sleep(5);
      return;
    }

    const authHeader = { Authorization: `Bearer ${token}` };

    // Dashboard summary
    const summaryRes = makeRequest('GET', `${BASE_URL}/api/dashboard/summary`, null, authHeader);
    check(summaryRes, {
      'dashboard: summary 200': (r) => r.status === 200,
      'dashboard: summary < 400ms': (r) => r.timings.duration < 400,
    });

    // Sales chart data
    const chartRes = makeRequest('GET', `${BASE_URL}/api/dashboard/sales-chart?period=month&months=6`, null, authHeader);
    check(chartRes, {
      'dashboard: chart 200': (r) => r.status === 200,
      'dashboard: chart < 400ms': (r) => r.timings.duration < 400,
    });

    // Recent invoices
    const invoicesRes = makeRequest('GET', `${BASE_URL}/api/invoices?limit=10&orderBy=createdAt&order=desc`, null, authHeader);
    check(invoicesRes, {
      'dashboard: recent invoices 200': (r) => r.status === 200,
      'dashboard: invoices < 400ms': (r) => r.timings.duration < 400,
    });

    // KPI metrics
    const kpiRes = makeRequest('GET', `${BASE_URL}/api/dashboard/kpi`, null, authHeader);
    check(kpiRes, {
      'dashboard: KPI 200': (r) => r.status === 200,
      'dashboard: KPI < 400ms': (r) => r.timings.duration < 400,
    });

    dashboardLoadTime.add(Date.now() - start);
    sleep(randomIntBetween(1, 3));
  });
}

/**
 * Scenario 4: Search Products
 * Tests search functionality with various query patterns.
 */
export function searchScenario() {
  group('Search Products', () => {
    const start = Date.now();
    const token = authenticate();
    if (!token) {
      sleep(5);
      return;
    }

    const authHeader = { Authorization: `Bearer ${token}` };

    const searchQueries = [
      { search: 'laptop', limit: 20 },
      { category: 'electronics', minPrice: 100, maxPrice: 1000, sort: 'price_asc' },
      { search: 'printer', limit: 10 },
      { search: 'cable', page: 1, limit: 50 },
      { search: `item-${randomIntBetween(1, 9999)}`, limit: 10 },
    ];

    const query = searchQueries[randomIntBetween(0, searchQueries.length - 1)];
    const params = new URLSearchParams(query).toString();

    const res = makeRequest('GET', `${BASE_URL}/api/products?${params}`, null, authHeader);

    check(res, {
      'search: status 200': (r) => r.status === 200,
      'search: response < 300ms': (r) => r.timings.duration < 300,
      'search: returns array or object': (r) => {
        try {
          const body = JSON.parse(r.body);
          return Array.isArray(body) || typeof body === 'object';
        } catch {
          return false;
        }
      },
    });

    searchResponseTime.add(Date.now() - start);
    sleep(randomIntBetween(1, 2));
  });
}

/**
 * Scenario 5: Generate Report
 * Tests async report generation endpoint.
 */
export function reportScenario() {
  group('Generate Report', () => {
    const start = Date.now();
    const token = authenticate();
    if (!token) {
      sleep(5);
      return;
    }

    const authHeader = { Authorization: `Bearer ${token}` };

    const reportTypes = ['sales-summary', 'inventory-valuation', 'financial-statement'];
    const reportType = reportTypes[randomIntBetween(0, reportTypes.length - 1)];

    // Submit report request
    const reportRes = makeRequest(
      'POST',
      `${BASE_URL}/api/reports`,
      {
        reportType,
        dateRange: {
          startDate: new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0],
          endDate: new Date().toISOString().split('T')[0],
        },
        format: 'json',
      },
      authHeader,
    );

    check(reportRes, {
      'report: accepted (202)': (r) => r.status === 202,
      'report: submit < 500ms': (r) => r.timings.duration < 500,
      'report: returns id': (r) => {
        try {
          return !!JSON.parse(r.body).id;
        } catch {
          return false;
        }
      },
    });

    let reportId = null;
    try {
      reportId = JSON.parse(reportRes.body).id;
    } catch {
      // Continue
    }

    // Poll for status (max 3 attempts)
    if (reportId) {
      for (let i = 0; i < 3; i++) {
        sleep(3);
        const statusRes = makeRequest('GET', `${BASE_URL}/api/reports/${reportId}/status`, null, authHeader);
        check(statusRes, {
          'report: status poll 200': (r) => r.status === 200,
        });

        try {
          const status = JSON.parse(statusRes.body).status;
          if (status === 'completed' || status === 'failed') break;
        } catch {
          break;
        }
      }
    }

    reportGenTime.add(Date.now() - start);
    sleep(randomIntBetween(2, 5));
  });
}

// ─── Default Export (runs all scenarios in mixed mode) ──────────────────────
export default function () {
  activeVUs.add(__VU);

  // Weighted random scenario selection
  const rand = Math.random() * 100;
  if (rand < 20) {
    loginScenario();
  } else if (rand < 45) {
    invoiceCreateScenario();
  } else if (rand < 75) {
    dashboardScenario();
  } else if (rand < 90) {
    searchScenario();
  } else {
    reportScenario();
  }
}

// ─── Lifecycle Hooks ────────────────────────────────────────────────────────
export function setup() {
  console.log(`Starting k6 load test against ${BASE_URL}`);
  console.log(`Test configuration: ${JSON.stringify(options.stages)}`);

  // Validate target is reachable
  const healthCheck = http.get(`${BASE_URL}/health`);
  if (healthCheck.status !== 200) {
    console.warn(`WARNING: Health check returned ${healthCheck.status}. Server may not be fully ready.`);
  } else {
    console.log('Health check passed — target is reachable');
  }

  return { baseUrl: BASE_URL, startTime: new Date().toISOString() };
}

export function teardown(data) {
  console.log(`Load test completed. Started at: ${data.startTime}`);
  console.log(`Target: ${data.baseUrl}`);
}
