#!/usr/bin/env bash
# =============================================================================
# GFF Backend — Security Audit Script
# =============================================================================
# Scans the codebase for security vulnerabilities:
#   1. Hardcoded secrets (API keys, passwords, tokens)
#   2. SQL injection patterns (string concatenation in queries)
#   3. Exposed .env files
#   4. CORS misconfiguration (wildcard origins)
#   5. Missing rate limiting on endpoints
#   6. Weak password policies
#   7. Missing input validation
#   8. Exposed error messages (stack traces)
#
# Usage:   bash security/audit.sh [project_root]
# Output:  security/audit-report.md
# Exit:    0 = no critical issues, 1 = critical issues found
# =============================================================================

set -euo pipefail

PROJECT_ROOT="${1:-$(pwd)}"
REPORT_DIR="${PROJECT_ROOT}/security"
REPORT_FILE="${REPORT_DIR}/audit-report.md"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
GIT_SHA=$(git -C "${PROJECT_ROOT}" rev-parse --short HEAD 2>/dev/null || echo "unknown")
GIT_BRANCH=$(git -C "${PROJECT_ROOT}" rev-parse --abbrev-ref HEAD 2>/dev/null || echo "unknown")

# Severity counters
CRITICAL=0
HIGH=0
MEDIUM=0
LOW=0
INFO=0

# Store findings
FINDINGS=()

add_finding() {
  local severity="$1"
  local category="$2"
  local file="$3"
  local line="$4"
  local description="$5"
  local recommendation="$6"
  local evidence="${7:-}"

  FINDINGS+=("${severity}|||${category}|||${file}|||${line}|||${description}|||${recommendation}|||${evidence}")

  case "${severity}" in
    CRITICAL) ((CRITICAL++)) ;;
    HIGH) ((HIGH++)) ;;
    MEDIUM) ((MEDIUM++)) ;;
    LOW) ((LOW++)) ;;
    INFO) ((INFO++)) ;;
  esac
}

# ─── Check 1: Hardcoded Secrets ────────────────────────────────────────────
check_hardcoded_secrets() {
  echo "[1/8] Checking for hardcoded secrets..."

  local patterns=(
    'api[_-]?key\s*[:=]\s*["\047][a-zA-Z0-9_\-]{16,}["\047]'
    'password\s*[:=]\s*["\047][^"\047]{4,}["\047]'
    'secret\s*[:=]\s*["\047][a-zA-Z0-9_\-]{8,}["\047]'
    'token\s*[:=]\s*["\047][a-zA-Z0-9_\-\.]{20,}["\047]'
    'AWS_ACCESS_KEY_ID\s*[:=]\s*["\047]?[A-Z0-9]{20}["\047]?'
    'AWS_SECRET_ACCESS_KEY\s*[:=]\s*["\047][^"\047]{10,}["\047]'
    'PRIVATE_KEY\s*[:=]\s*[`"\047]-----BEGIN'
    'sk-[a-zA-Z0-9]{20,}'
    'ghp_[a-zA-Z0-9]{36,}'
    'xox[baprs]-[a-zA-Z0-9]{10,}'
    'SG\.[a-zA-Z0-9]{10,}\.[a-zA-Z0-9]{10,}'
  )

  local exclude_dirs="--exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist --exclude-dir=coverage --exclude-dir=.cache"

  for pattern in "${patterns[@]}"; do
    while IFS=: read -r file line match; do
      # Skip test files and fixture data
      if [[ "${file}" =~ \.(spec|test)\.(ts|js)$ ]] || [[ "${file}" =~ fixtures?/ ]]; then
        continue
      fi
      # Skip the audit script itself
      if [[ "${file}" =~ audit\.(sh|js|ts)$ ]]; then
        continue
      fi

      add_finding \
        "HIGH" \
        "Hardcoded Secret" \
        "${file}" \
        "${line}" \
        "Possible hardcoded secret detected: ${match:0:80}" \
        "Move secret to environment variables or a secrets manager (AWS SM, HashiCorp Vault)." \
        "${match:0:120}"
    done < <(grep -rnEi --include="*.ts" --include="*.js" --include="*.json" --include="*.yaml" --include="*.yml" --include="*.env*" ${exclude_dirs} -P "${pattern}" "${PROJECT_ROOT}/src" 2>/dev/null || true)
  done

  # Check specifically for .env files committed to repo
  local env_files
  env_files=$(find "${PROJECT_ROOT}" -maxdepth 3 -name ".env*" -not -name ".env.example" -not -name ".env.template" -not -path "*/node_modules/*" 2>/dev/null || true)
  if [[ -n "${env_files}" ]]; then
    while IFS= read -r f; do
      if git -C "${PROJECT_ROOT}" ls-files --error-unmatch "${f}" &>/dev/null; then
        add_finding \
          "CRITICAL" \
          "Exposed .env File" \
          "${f}" \
          "N/A" \
          ".env file is tracked in git — credentials may be exposed in commit history." \
          "Remove file from git: git rm --cached '${f}', add to .gitignore, rotate any exposed credentials." \
          "$(head -n 5 "${f}" 2>/dev/null | head -c 200 || echo 'Unable to read')"
      fi
    done <<< "${env_files}"
  fi
}

# ─── Check 2: SQL Injection Patterns ───────────────────────────────────────
check_sql_injection() {
  echo "[2/8] Checking for SQL injection vulnerabilities..."

  local patterns=(
    '\+\s*["\047].*SELECT.*FROM'
    '\+\s*["\047].*INSERT\s+INTO'
    '\+\s*["\047].*UPDATE\s+\w+\s+SET'
    '\+\s*["\047].*DELETE\s+FROM'
    'query\s*\(.*\+.*\)'
    'execute\s*\(.*\+.*\)'
    '\$\{.*\}.*\bFROM\b'
    '`.*\$\{.*\}.*`'
    'raw\s*\(.*\+'
  )

  local exclude_dirs="--exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist --exclude-dir=coverage"

  for pattern in "${patterns[@]}"; do
    while IFS=: read -r file line match; do
      if [[ "${file}" =~ \.(spec|test)\.(ts|js)$ ]]; then
        continue
      fi

      add_finding \
        "CRITICAL" \
        "SQL Injection Risk" \
        "${file}" \
        "${line}" \
        "Possible SQL injection via string concatenation or template literal." \
        "Use parameterized queries OR a query builder (TypeORM, Knex, Prisma). Never concatenate user input into SQL." \
        "${match:0:120}"
    done < <(grep -rnE --include="*.ts" --include="*.js" ${exclude_dirs} "${pattern}" "${PROJECT_ROOT}/src" 2>/dev/null || true)
  done
}

# ─── Check 3: CORS Misconfiguration ────────────────────────────────────────
check_cors_misconfiguration() {
  echo "[3/8] Checking for CORS misconfiguration..."

  # Check for wildcard CORS origin
  while IFS=: read -r file line match; do
    if [[ "${file}" =~ \.(spec|test)\.(ts|js)$ ]]; then
      continue
    fi

    # Check if it's actually a restrictive config
    if [[ "${match}" =~ (allowedHeaders|credentials) ]]; then
      continue
    fi

    add_finding \
      "HIGH" \
      "CORS Misconfiguration" \
      "${file}" \
      "${line}" \
      "CORS origin set to wildcard (*) allows any domain to access the API." \
      "Specify explicit origins: origin: ['https://app.yourdomain.com']. Enable credentials only with specific origins." \
      "${match:0:120}"
  done < <(grep -rnE --include="*.ts" --include="*.js" --exclude-dir=node_modules --exclude-dir=dist 'origin.*\*' "${PROJECT_ROOT}/src" 2>/dev/null || true)

  # Check NestJS CORS config
  while IFS=: read -r file line match; do
    if [[ "${match}" =~ (enableCors|CorsOptions) ]]; then
      add_finding \
        "MEDIUM" \
        "CORS Configuration Review" \
        "${file}" \
        "${line}" \
        "Review CORS configuration to ensure it doesn't allow unauthorized origins." \
        "Audit CORS settings: ensure origin is not '*', credentials are false when origin is wildcard." \
        "${match:0:120}"
    fi
  done < <(grep -rnE --include="*.ts" --exclude-dir=node_modules --exclude-dir=dist 'enableCors|CorsOptions' "${PROJECT_ROOT}/src" 2>/dev/null || true)
}

# ─── Check 4: Missing Rate Limiting ────────────────────────────────────────
check_rate_limiting() {
  echo "[4/8] Checking for missing rate limiting..."

  # Count controllers
  local controller_count
  controller_count=$(find "${PROJECT_ROOT}/src" -name "*.controller.ts" 2>/dev/null | wc -l)

  # Check for rate limiting decorators/usage
  local rate_limit_count
  rate_limit_count=$(grep -rl --include="*.ts" -E "@UseGuards.*Throttler|Throttle|rateLimit|RateLimit" "${PROJECT_ROOT}/src" 2>/dev/null | wc -l)

  if [[ "${controller_count}" -gt 0 && "${rate_limit_count}" -eq 0 ]]; then
    add_finding \
      "HIGH" \
      "Missing Rate Limiting" \
      "src/**/*.controller.ts" \
      "N/A" \
      "No rate limiting found on any controller. API is vulnerable to brute-force and DDoS attacks." \
      "Install @nestjs/throttler and apply @UseGuards(ThrottlerGuard) globally or per-controller." \
      "Found ${controller_count} controllers, 0 with rate limiting"
  fi

  # Check for rate limit on auth endpoints specifically
  local auth_with_rate_limit
  auth_with_rate_limit=$(grep -rl --include="*.ts" -E "@UseGuards.*Throttler|Throttle" "${PROJECT_ROOT}/src" 2>/dev/null | xargs grep -l "auth\|login\|password\|reset" 2>/dev/null | wc -l)

  if [[ "${auth_with_rate_limit}" -eq 0 ]]; then
    add_finding \
      "HIGH" \
      "Auth Endpoint Rate Limiting" \
      "src/**/auth*.ts" \
      "N/A" \
      "Auth endpoints (login, password reset) lack dedicated rate limiting." \
      "Apply strict rate limits to auth endpoints: 5 attempts per 15 minutes per IP." \
      "No Throttler guard found on auth endpoints"
  fi
}

# ─── Check 5: Weak Password Policies ───────────────────────────────────────
check_password_policies() {
  echo "[5/8] Checking password policies..."

  # Check for password validation patterns
  local min_length_pattern='minLength.*[^0-9].{0,3}[0-5][^0-9]|length.*<\s*8'
  local has_password_validation
  has_password_validation=$(grep -rl --include="*.ts" -E "IsStrongPassword|password.*regex|minLength.*8|minlength.*8|z\.string.*min.*8" "${PROJECT_ROOT}/src" 2>/dev/null | wc -l)

  if [[ "${has_password_validation}" -eq 0 ]]; then
    add_finding \
      "MEDIUM" \
      "Weak Password Policy" \
      "src/**/*.dto.ts, src/**/*.validator.ts" \
      "N/A" \
      "No strong password validation found. Passwords may be weak." \
      "Implement password validation: min 8 chars, uppercase, lowercase, number, special char. Use @IsStrongPassword() from class-validator." \
      "No IsStrongPassword or equivalent validator found"
  fi

  # Check for bcrypt/jargon/argon2 usage
  local has_password_hashing
  has_password_hashing=$(grep -rl --include="*.ts" -E "bcrypt|argon2|scrypt|pbkdf2" "${PROJECT_ROOT}/src" 2>/dev/null | wc -l)

  if [[ "${has_password_hashing}" -eq 0 ]]; then
    add_finding \
      "CRITICAL" \
      "Missing Password Hashing" \
      "src/**/*.service.ts" \
      "N/A" \
      "No password hashing library found (bcrypt, argon2, scrypt). Passwords may be stored in plaintext." \
      "Use bcrypt with cost factor 12+ or argon2id for password hashing. NEVER store plaintext passwords." \
      "No bcrypt, argon2, scrypt, or pbkdf2 references found"
  fi

  # Check for bcrypt cost factor
  grep -rnE --include="*.ts" 'bcrypt.*hash.*\d+' "${PROJECT_ROOT}/src" 2>/dev/null | while IFS=: read -r file line match; do
    if [[ "${match}" =~ (hash.*\([0-9]|rounds.*=.*[0-9]) ]]; then
      local cost
      cost=$(echo "${match}" | grep -oP '\d+' | head -1)
      if [[ -n "${cost}" && "${cost}" -lt 10 ]]; then
        add_finding \
          "MEDIUM" \
          "Weak bcrypt Cost Factor" \
          "${file}" \
          "${line}" \
          "bcrypt cost factor ${cost} is below recommended minimum of 10." \
          "Increase bcrypt rounds to 12+ for production: bcrypt.hash(password, 12)." \
          "${match:0:120}"
      fi
    fi
  done || true
}

# ─── Check 6: Missing Input Validation ─────────────────────────────────────
check_input_validation() {
  echo "[6/8] Checking for input validation..."

  # Check DTOs for validation decorators
  local dto_files
  dto_files=$(find "${PROJECT_ROOT}/src" -name "*.dto.ts" 2>/dev/null | wc -l)

  local validated_dtos
  validated_dtos=$(grep -rl --include="*.dto.ts" -E "@IsString|@IsNumber|@IsEmail|@IsOptional|@IsEnum|@ValidateNested|@IsUUID|@IsInt|@IsBoolean" "${PROJECT_ROOT}/src" 2>/dev/null | wc -l)

  if [[ "${dto_files}" -gt 0 && "${validated_dtos}" -lt $((dto_files / 2)) ]]; then
    add_finding \
      "HIGH" \
      "Missing Input Validation" \
      "src/**/*.dto.ts" \
      "N/A" \
      "Many DTOs lack validation decorators. Invalid/malicious input may reach the database." \
      "Add class-validator decorators to all DTO fields. Apply ValidationPipe globally." \
      "${validated_dtos}/${dto_files} DTOs have validation decorators"
  fi

  # Check for ValidationPipe global usage
  local has_validation_pipe
  has_validation_pipe=$(grep -rl --include="*.ts" -E "ValidationPipe|app\.useGlobalPipes" "${PROJECT_ROOT}/src" 2>/dev/null | wc -l)

  if [[ "${has_validation_pipe}" -eq 0 ]]; then
    add_finding \
      "HIGH" \
      "Missing Global ValidationPipe" \
      "src/main.ts" \
      "N/A" \
      "No global ValidationPipe configured. All incoming requests bypass DTO validation." \
      "Add: app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }))" \
      "No ValidationPipe or useGlobalPipes found"
  fi

  # Check for @Body without DTO type
  while IFS=: read -r file line match; do
    if [[ ! "${match}" =~ @Body\(.*\) ]]; then
      add_finding \
        "MEDIUM" \
        "Untyped Request Body" \
        "${file}" \
        "${line}" \
        "@Body() used without a DTO type — request body is untyped and unvalidated." \
        "Use @Body(CreateUserDto) with a properly validated DTO class." \
        "${match:0:120}"
    fi
  done < <(grep -rnE --include="*.ts" --exclude-dir=node_modules --exclude-dir=dist '@Body\(\)' "${PROJECT_ROOT}/src" 2>/dev/null || true)
}

# ─── Check 7: Exposed Error Messages ───────────────────────────────────────
check_error_messages() {
  echo "[7/8] Checking for exposed error messages..."

  # Check for stack traces in responses
  while IFS=: read -r file line match; do
    add_finding \
      "MEDIUM" \
      "Stack Trace Exposure" \
      "${file}" \
      "${line}" \
      "Error stack trace may be returned to clients, leaking implementation details." \
      "Set exception filter to return generic error messages in production. Log stack traces server-side only." \
      "${match:0:120}"
  done < <(grep -rnE --include="*.ts" --exclude-dir=node_modules --exclude-dir=dist 'stack.*\?' "${PROJECT_ROOT}/src" 2>/dev/null || true)

  # Check for detailed error in exception filters
  while IFS=: read -r file line match; do
    if [[ "${match}" =~ (message|stack) ]]; then
      add_finding \
        "MEDIUM" \
        "Detailed Error in Response" \
        "${file}" \
        "${line}" \
        "Exception filter may return detailed error information to clients." \
        "Sanitize error responses: return { statusCode, message: 'Internal Server Error' }. Log details internally." \
        "${match:0:120}"
    fi
  done < <(grep -rnE --include="*.ts" --exclude-dir=node_modules --exclude-dir=dist 'catch.*Exception|HttpException|RpcException' "${PROJECT_ROOT}/src" 2>/dev/null || true)
}

# ─── Check 8: Exposed .env Files in Code ───────────────────────────────────
check_exposed_env() {
  echo "[8/8] Checking for exposed .env files and config..."

  # Check docker-compose for env exposure
  if [[ -f "${PROJECT_ROOT}/docker-compose.yml" ]] || [[ -f "${PROJECT_ROOT}/docker-compose.yaml" ]]; then
    local compose_file
    compose_file=$(find "${PROJECT_ROOT}" -maxdepth 1 -name "docker-compose.y*ml" | head -1)
    if grep -nE 'env_file.*\.env' "${compose_file}" &>/dev/null; then
      add_finding \
        "MEDIUM" \
        "Docker Compose .env Exposure" \
        "${compose_file}" \
        "N/A" \
        "docker-compose references .env file — ensure .env is not committed and credentials are rotated." \
        "Use Docker secrets or environment-specific compose files. Add .env to .gitignore." \
        "env_file directive found in docker-compose"
    fi
  fi

  # Check for console.log of sensitive data
  while IFS=: read -r file line match; do
    if [[ "${match}" =~ (password|secret|token|key) ]]; then
      add_finding \
        "MEDIUM" \
        "Sensitive Data in Logs" \
        "${file}" \
        "${line}" \
        "console.log may output sensitive data in production logs." \
        "Remove console.log statements. Use structured logging with Pino/Winston and redact sensitive fields." \
        "${match:0:120}"
    fi
  done < <(grep -rnE --include="*.ts" --exclude-dir=node_modules --exclude-dir=dist 'console\.(log|warn|error)' "${PROJECT_ROOT}/src" 2>/dev/null || true)
}

# ─── Generate Report ───────────────────────────────────────────────────────
generate_report() {
  mkdir -p "${REPORT_DIR}"

  cat > "${REPORT_FILE}" << 'HEADER'
# GFF Backend — Security Audit Report

HEADER

  cat >> "${REPORT_FILE}" << EOF
| Property          | Value                                    |
|-------------------|------------------------------------------|
| Timestamp         | ${TIMESTAMP}                             |
| Git SHA           | ${GIT_SHA}                               |
| Branch            | ${GIT_BRANCH}                            |
| Project Root      | ${PROJECT_ROOT}                          |
| Auditor           | Automated Security Scanner               |

## Summary

| Severity | Count |
|----------|-------|
| CRITICAL | ${CRITICAL} |
| HIGH     | ${HIGH} |
| MEDIUM   | ${MEDIUM} |
| LOW      | ${LOW} |
| INFO     | ${INFO} |
| **Total**  | **$((CRITICAL + HIGH + MEDIUM + LOW + INFO))** |

EOF

  if [[ "${CRITICAL}" -gt 0 ]]; then
    echo "> ⚠️ **${CRITICAL} CRITICAL issue(s) require immediate attention.**" >> "${REPORT_FILE}"
  fi

  echo "" >> "${REPORT_FILE}"
  echo "---" >> "${REPORT_FILE}"
  echo "" >> "${REPORT_FILE}"

  # Sort findings: CRITICAL first, then HIGH, MEDIUM, LOW, INFO
  IFS=$'\n' sorted_findings=($(printf '%s\n' "${FINDINGS[@]}" | sort -t'|' -k1,1 -r 2>/dev/null || true)); unset IFS

  local current_severity=""
  for finding in "${sorted_findings[@]}"; do
    IFS='|||' read -r sev cat file line desc rec evidence <<< "${finding}"

    if [[ "${sev}" != "${current_severity}" ]]; then
      current_severity="${sev}"
      echo "## ${sev} Findings" >> "${REPORT_FILE}"
      echo "" >> "${REPORT_FILE}"
    fi

    cat >> "${REPORT_FILE}" << EOF
### ${cat}

- **File:** \`${file}\`${line:+ (line: ${line})}
- **Severity:** ${sev}
- **Description:** ${desc}
- **Recommendation:** ${rec}
${evidence:+- **Evidence:** \`${evidence}\`}

EOF
  done

  # Add remediation checklist
  cat >> "${REPORT_FILE}" << 'CHECKLIST'

---

## Remediation Checklist

- [ ] **Hardcoded Secrets**: Move all secrets to environment variables or secrets manager
- [ ] **SQL Injection**: Use parameterized queries / ORM for all database access
- [ ] **CORS**: Configure explicit allowed origins, disable credentials with wildcard
- [ ] **Rate Limiting**: Apply @nestjs/throttler globally and on auth endpoints
- [ ] **Password Policy**: Implement @IsStrongPassword, use bcrypt with cost >= 12
- [ ] **Input Validation**: Enable ValidationPipe globally, validate all DTOs
- [ ] **Error Handling**: Return generic errors to clients, log details server-side
- [ ] **.env Files**: Verify .env* files are in .gitignore and not in commit history

## CI/CD Integration

Add this script to your pipeline:

```yaml
# .github/workflows/security-audit.yml
security-audit:
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4
    - name: Run Security Audit
      run: bash security/audit.sh
    - name: Upload Report
      if: always()
      uses: actions/upload-artifact@v4
      with:
        name: security-audit-report
        path: security/audit-report.md
    - name: Fail on Critical
      run: |
        CRITICAL=$(grep -c "^## CRITICAL" security/audit-report.md || true)
        if [ "$CRITICAL" -gt 0 ]; then exit 1; fi
```

---
*Report generated by GFF Security Audit Scanner*
CHECKLIST

  echo ""
  echo "================================================================="
  echo "  Security Audit Complete"
  echo "================================================================="
  echo "  Report: ${REPORT_FILE}"
  echo "  CRITICAL: ${CRITICAL}  |  HIGH: ${HIGH}  |  MEDIUM: ${MEDIUM}  |  LOW: ${LOW}  |  INFO: ${INFO}"
  echo "================================================================="
}

# ─── Main ──────────────────────────────────────────────────────────────────
main() {
  echo "================================================================="
  echo "  GFF Backend — Security Audit"
  echo "  Project: ${PROJECT_ROOT}"
  echo "  Time:    ${TIMESTAMP}"
  echo "================================================================="
  echo ""

  if [[ ! -d "${PROJECT_ROOT}/src" ]]; then
    echo "ERROR: No 'src' directory found at ${PROJECT_ROOT}"
    echo "Usage: bash security/audit.sh [project_root]"
    exit 1
  fi

  check_hardcoded_secrets
  check_sql_injection
  check_cors_misconfiguration
  check_rate_limiting
  check_password_policies
  check_input_validation
  check_error_messages
  check_exposed_env

  generate_report

  # Exit with error if critical findings exist
  if [[ "${CRITICAL}" -gt 0 ]]; then
    exit 1
  fi
  exit 0
}

main "$@"
