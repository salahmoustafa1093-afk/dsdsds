import { Controller, Get, Logger } from '@nestjs/common';
import {
  HealthCheck,
  HealthCheckService,
  PrismaHealthIndicator,
  MemoryHealthIndicator,
  DiskHealthIndicator,
  HttpHealthIndicator,
  HealthCheckResult,
} from '@nestjs/terminus';
import { PrismaClient } from '@prisma/client';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Public } from '../common/decorators/public.decorator';

// Extend the PrismaHealthIndicator to support custom PrismaClient
class CustomPrismaHealthIndicator extends PrismaHealthIndicator {
  async pingCheck(
    key: string,
    prismaClient: PrismaClient,
    timeout?: number,
  ): Promise<any> {
    return super.pingCheck(key, prismaClient as any, timeout);
  }
}

@ApiTags('Health')
@Controller('health')
@Public()
export class HealthController {
  private readonly logger = new Logger(HealthController.name);
  private readonly prisma: PrismaClient;

  constructor(
    private readonly health: HealthCheckService,
    private readonly prismaHealth: PrismaHealthIndicator,
    private readonly memory: MemoryHealthIndicator,
    private readonly disk: DiskHealthIndicator,
    private readonly http: HttpHealthIndicator,
  ) {
    this.prisma = new PrismaClient();
  }

  /**
   * Overall health check endpoint.
   * Returns 200 if all services are healthy, 503 otherwise.
   */
  @Get()
  @HealthCheck()
  @ApiOperation({
    summary: 'Overall health check',
    description:
      'Checks all critical services: database, memory, and disk space. Returns comprehensive health status.',
  })
  @ApiResponse({
    status: 200,
    description: 'All services are healthy',
    schema: {
      type: 'object',
      properties: {
        status: { type: 'string', example: 'ok' },
        info: { type: 'object' },
        error: { type: 'object' },
        details: { type: 'object' },
      },
    },
  })
  @ApiResponse({
    status: 503,
    description: 'One or more services are unhealthy',
  })
  async check(): Promise<HealthCheckResult> {
    this.logger.debug('Running overall health check');
    return this.health.check([
      () =>
        this.prismaHealth.pingCheck(
          'database',
          this.prisma as any,
          5000,
        ),
      () =>
        this.memory.checkHeap('memory_heap', 512 * 1024 * 1024),
      () =>
        this.memory.checkRSS('memory_rss', 512 * 1024 * 1024),
      () =>
        this.disk.checkStorage('disk_storage', {
          thresholdPercent: 0.9,
          path: '/',
        }),
    ]);
  }

  /**
   * Database connectivity check.
   * Verifies PostgreSQL connection via Prisma ORM.
   */
  @Get('db')
  @HealthCheck()
  @ApiOperation({
    summary: 'Database connectivity check',
    description:
      'Performs a ping check against the PostgreSQL database using Prisma ORM.',
  })
  @ApiResponse({
    status: 200,
    description: 'Database connection is healthy',
    schema: {
      type: 'object',
      properties: {
        status: { type: 'string', example: 'ok' },
        database: {
          type: 'object',
          properties: {
            status: { type: 'string', example: 'up' },
          },
        },
      },
    },
  })
  @ApiResponse({
    status: 503,
    description: 'Database connection failed',
  })
  async checkDatabase(): Promise<HealthCheckResult> {
    this.logger.debug('Running database health check');
    return this.health.check([
      () =>
        this.prismaHealth.pingCheck(
          'database',
          this.prisma as any,
          5000,
        ),
    ]);
  }

  /**
   * Redis connectivity check.
   * Verifies Redis cache/session store connectivity.
   */
  @Get('redis')
  @HealthCheck()
  @ApiOperation({
    summary: 'Redis connectivity check',
    description:
      'Verifies connectivity to the Redis cache and session store via HTTP health probe.',
  })
  @ApiResponse({
    status: 200,
    description: 'Redis connection is healthy',
    schema: {
      type: 'object',
      properties: {
        status: { type: 'string', example: 'ok' },
        redis: {
          type: 'object',
          properties: {
            status: { type: 'string', example: 'up' },
          },
        },
      },
    },
  })
  @ApiResponse({
    status: 503,
    description: 'Redis connection failed',
  })
  async checkRedis(): Promise<HealthCheckResult> {
    this.logger.debug('Running Redis health check');
    const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';
    return this.health.check([
      () =>
        this.http.pingCheck(
          'redis',
          `${redisUrl.replace('redis://', 'http://')}/health`,
          { timeout: 5000 },
        ),
    ]);
  }

  /**
   * Disk space check.
   * Verifies available storage on the root partition.
   */
  @Get('disk')
  @HealthCheck()
  @ApiOperation({
    summary: 'Disk space check',
    description:
      'Checks available disk space on the root partition. Fails if usage exceeds 90%.',
  })
  @ApiResponse({
    status: 200,
    description: 'Disk space is sufficient',
    schema: {
      type: 'object',
      properties: {
        status: { type: 'string', example: 'ok' },
        disk_storage: {
          type: 'object',
          properties: {
            status: { type: 'string', example: 'up' },
            message: { type: 'string' },
          },
        },
      },
    },
  })
  @ApiResponse({
    status: 503,
    description: 'Disk space is critically low',
  })
  async checkDisk(): Promise<HealthCheckResult> {
    this.logger.debug('Running disk health check');
    return this.health.check([
      () =>
        this.disk.checkStorage('disk_storage', {
          thresholdPercent: 0.9,
          path: '/',
        }),
    ]);
  }
}
