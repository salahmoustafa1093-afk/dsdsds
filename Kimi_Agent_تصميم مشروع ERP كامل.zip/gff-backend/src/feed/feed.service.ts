import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  AnimalType,
  FeedType,
  FeedFormulaStatus,
  Prisma,
} from '@prisma/client';
import type { FeedFormula, FeedFormulaIngredient, FeedCost } from '@prisma/client';
import {
  CreateFeedFormulaDto,
  UpdateFeedFormulaDto,
  CreateFeedCostDto,
  OptimizeFormulaDto,
  RecommendFormulaDto,
  QueryFeedFormulaDto,
} from './dto';

// ─────────────────────────────────────────────
// NRC Standards Database
// ─────────────────────────────────────────────
const NRC_STANDARDS = {
  BROILER_STARTER: {
    protein: 23, me: 3200, fiber: 5, fat: 5,
    calcium: 1.0, phosphorus: 0.45, lysine: 1.1, methionine: 0.5,
  },
  BROILER_GROWER: {
    protein: 20, me: 3200, fiber: 6, fat: 5,
    calcium: 0.9, phosphorus: 0.4, lysine: 1.0, methionine: 0.45,
  },
  BROILER_FINISHER: {
    protein: 18, me: 3200, fiber: 7, fat: 5,
    calcium: 0.8, phosphorus: 0.35, lysine: 0.9, methionine: 0.4,
  },
  LAYER: {
    protein: 16, me: 2800, fiber: 8, fat: 4,
    calcium: 3.5, phosphorus: 0.35, lysine: 0.75, methionine: 0.35,
  },
  CATTLE_GROWING: {
    protein: 14, me: 2600, fiber: 18, fat: 4,
    calcium: 0.5, phosphorus: 0.3, lysine: 0.6, methionine: 0.2,
  },
  SHEEP: {
    protein: 12, me: 2400, fiber: 20, fat: 4,
    calcium: 0.4, phosphorus: 0.25, lysine: 0.5, methionine: 0.2,
  },
} as const;

type NrcStandardKey = keyof typeof NRC_STANDARDS;
type NrcNutrients = keyof typeof NRC_STANDARDS[NrcStandardKey];

// ─────────────────────────────────────────────
// Ingredient Nutritional Database
// ─────────────────────────────────────────────
interface IngredientNutrition {
  protein: number;
  me: number;
  fiber: number;
  fat: number;
  calcium: number;
  phosphorus: number;
  lysine: number;
  methionine: number;
  costPerKg: number;
}

const INGREDIENT_DB: Record<string, IngredientNutrition> = {
  CORN_YELLOW: {
    protein: 8.5, me: 3350, fiber: 2.7, fat: 3.8, calcium: 0.02,
    phosphorus: 0.27, lysine: 0.26, methionine: 0.18, costPerKg: 12.5,
  },
  SOYBEAN_MEAL: {
    protein: 44, me: 2400, fiber: 6.5, fat: 1.5, calcium: 0.3,
    phosphorus: 0.65, lysine: 2.8, methionine: 0.65, costPerKg: 22.0,
  },
  WHEAT_BRAN: {
    protein: 15.5, me: 1750, fiber: 10.5, fat: 3.5, calcium: 0.1,
    phosphorus: 1.15, lysine: 0.55, methionine: 0.2, costPerKg: 8.0,
  },
  SUNFLOWER_MEAL: {
    protein: 28, me: 1850, fiber: 25, fat: 1.5, calcium: 0.4,
    phosphorus: 1.0, lysine: 1.2, methionine: 0.7, costPerKg: 10.5,
  },
  COTTONSEED_MEAL: {
    protein: 41, me: 2100, fiber: 14, fat: 2.0, calcium: 0.2,
    phosphorus: 1.1, lysine: 1.8, methionine: 0.55, costPerKg: 14.0,
  },
  SALT: {
    protein: 0, me: 0, fiber: 0, fat: 0, calcium: 0,
    phosphorus: 0, lysine: 0, methionine: 0, costPerKg: 3.0,
  },
  CALCIUM_CARBONATE: {
    protein: 0, me: 0, fiber: 0, fat: 0, calcium: 38,
    phosphorus: 0, lysine: 0, methionine: 0, costPerKg: 2.5,
  },
  DICALCIUM_PHOSPHATE: {
    protein: 0, me: 0, fiber: 0, fat: 0, calcium: 23,
    phosphorus: 18, lysine: 0, methionine: 0, costPerKg: 18.0,
  },
  VITAMIN_PREMIX: {
    protein: 0, me: 0, fiber: 0, fat: 0, calcium: 12,
    phosphorus: 8, lysine: 0, methionine: 0, costPerKg: 85.0,
  },
  METHIONINE: {
    protein: 58, me: 2200, fiber: 0, fat: 0, calcium: 0,
    phosphorus: 0, lysine: 0, methionine: 99, costPerKg: 120.0,
  },
  LYSINE: {
    protein: 95, me: 3800, fiber: 0, fat: 0, calcium: 0,
    phosphorus: 0, lysine: 99, methionine: 0, costPerKg: 95.0,
  },
};

// Processing & overhead constants (EGP per ton)
const PROCESSING_COST_PER_TON = 200;
const OVERHEAD_COST_PER_TON = 150;

// ─────────────────────────────────────────────
// Helper: linear interpolate nutrient value
// ─────────────────────────────────────────────
function interpolateNutrient(
  value: number,
  target: number,
): { status: 'deficient' | 'adequate' | 'excess'; deviationPct: number; color: 'red' | 'yellow' | 'green' } {
  const ratio = target > 0 ? (value / target) * 100 : 0;
  if (ratio < 90) {
    return { status: 'deficient', deviationPct: ratio - 100, color: 'red' };
  }
  if (ratio <= 110) {
    return { status: 'adequate', deviationPct: ratio - 100, color: 'yellow' };
  }
  return { status: 'excess', deviationPct: ratio - 100, color: 'green' };
}

// ─────────────────────────────────────────────
// Helper: round to 4 decimals
// ─────────────────────────────────────────────
const R = (v: number) => Math.round(v * 10000) / 10000;

// ─────────────────────────────────────────────
// Helper: convert Prisma Decimal to number
// ─────────────────────────────────────────────
const D = (v: Prisma.Decimal | number | null | undefined): number => {
  if (v === null || v === undefined) return 0;
  if (typeof v === 'number') return v;
  return v.toNumber();
};

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────
interface NutrientProfile {
  protein: number;
  me: number;
  fiber: number;
  fat: number;
  calcium: number;
  phosphorus: number;
  lysine: number;
  methionine: number;
}

interface ExtendedNutrientProfile extends NutrientProfile {
  costPerKg: number;
  costPerTon: number;
}

interface FormulaIngredientInput {
  ingredientName: string;
  percentage: number;
  proteinPercent?: number | null;
  energyValue?: number | null;
  costPerKg?: number | null;
  order?: number;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

interface OptimizedIngredient {
  key: string;
  name: string;
  costPerKg: number;
  costPerUnitProtein: number;
  nutrition: IngredientNutrition;
  minPct: number;
  maxPct: number;
  currentPct: number;
}

interface OptimizerMixItem {
  ingredient: string;
  percentage: number;
  costPerTon: number;
}

interface OptimizerResult {
  mix: OptimizerMixItem[];
  totalCostPerTon: number;
  nutrientTotals: Partial<NutrientProfile>;
  constraintsSatisfied: boolean;
  iterations: number;
}

@Injectable()
export class FeedService {
  private readonly logger = new Logger(FeedService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════
  //  CRUD: findAllFormulas
  // ═══════════════════════════════════════════
  async findAllFormulas(query: QueryFeedFormulaDto = {}) {
    const {
      page = 1,
      limit = 10,
      targetAnimal,
      feedType,
      status,
      search,
    } = query;
    const skip = (page - 1) * limit;

    const where: Prisma.FeedFormulaWhereInput = {};
    if (targetAnimal) where.targetAnimal = targetAnimal;
    if (feedType) where.feedType = feedType;
    if (status) where.status = status;
    if (search) {
      where.name = { contains: search, mode: 'insensitive' };
    }

    const [data, total] = await Promise.all([
      this.prisma.feedFormula.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { ingredients: { orderBy: { order: 'asc' } } },
      }),
      this.prisma.feedFormula.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  // ═══════════════════════════════════════════
  //  CRUD: findOneFormula
  // ═══════════════════════════════════════════
  async findOneFormula(id: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const nutrients = this.calculateFormulaNutrientsInternal(formula.ingredients);
    return { data: { ...formula, nutrientTotals: nutrients } };
  }

  // ═══════════════════════════════════════════
  //  CRUD: createFormula (with auto-validation)
  // ═══════════════════════════════════════════
  async createFormula(userId: string, dto: CreateFeedFormulaDto) {
    // Validate ingredients if provided
    if (dto.ingredients && dto.ingredients.length > 0) {
      const validation = this.validateIngredientsInternal(dto.ingredients);
      if (!validation.isValid) {
        throw new BadRequestException({
          message: 'Formula validation failed',
          errors: validation.errors,
          warnings: validation.warnings,
        });
      }
    }

    const formula = await this.prisma.feedFormula.create({
      data: {
        name: dto.name,
        targetAnimal: dto.targetAnimal,
        feedType: dto.feedType,
        status: dto.status ?? FeedFormulaStatus.DRAFT,
        createdBy: userId,
        ingredients: {
          create: dto.ingredients.map((ing, index) => ({
            ingredientName: ing.ingredientName,
            percentage: new Prisma.Decimal(ing.percentage),
            proteinPercent: ing.proteinPercent != null
              ? new Prisma.Decimal(ing.proteinPercent)
              : null,
            energyValue: ing.energyValue != null
              ? new Prisma.Decimal(ing.energyValue)
              : null,
            costPerKg: ing.costPerKg != null
              ? new Prisma.Decimal(ing.costPerKg)
              : null,
            order: ing.order ?? index,
          })),
        },
      },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });

    this.logger.log(`Feed formula created: ${formula.name} by ${userId}`);
    return { data: formula };
  }

  // ═══════════════════════════════════════════
  //  CRUD: updateFormula (with re-validation)
  // ═══════════════════════════════════════════
  async updateFormula(id: string, dto: UpdateFeedFormulaDto) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id },
      include: { ingredients: true },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    // If ingredients are being replaced, validate them
    if (dto.ingredients && dto.ingredients.length > 0) {
      const validation = this.validateIngredientsInternal(dto.ingredients);
      if (!validation.isValid) {
        throw new BadRequestException({
          message: 'Formula validation failed',
          errors: validation.errors,
          warnings: validation.warnings,
        });
      }
    }

    const data: Prisma.FeedFormulaUpdateInput = {};
    if (dto.name !== undefined) data.name = dto.name;
    if (dto.targetAnimal !== undefined) data.targetAnimal = dto.targetAnimal;
    if (dto.feedType !== undefined) data.feedType = dto.feedType;
    if (dto.status !== undefined) data.status = dto.status;

    // Handle ingredient replacement
    if (dto.ingredients !== undefined) {
      // Delete old ingredients and create new ones
      await this.prisma.feedFormulaIngredient.deleteMany({
        where: { formulaId: id },
      });
      data.ingredients = {
        create: dto.ingredients.map((ing, index) => ({
          ingredientName: ing.ingredientName,
          percentage: new Prisma.Decimal(ing.percentage),
          proteinPercent: ing.proteinPercent != null
            ? new Prisma.Decimal(ing.proteinPercent)
            : null,
          energyValue: ing.energyValue != null
            ? new Prisma.Decimal(ing.energyValue)
            : null,
          costPerKg: ing.costPerKg != null
            ? new Prisma.Decimal(ing.costPerKg)
            : null,
          order: ing.order ?? index,
        })),
      };
    }

    const updated = await this.prisma.feedFormula.update({
      where: { id },
      data,
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });

    this.logger.log(`Feed formula updated: ${updated.name}`);
    return { data: updated };
  }

  // ═══════════════════════════════════════════
  //  CRUD: archiveFormula (soft archive via status)
  // ═══════════════════════════════════════════
  async archiveFormula(id: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const updated = await this.prisma.feedFormula.update({
      where: { id },
      data: { status: FeedFormulaStatus.ARCHIVED },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });

    this.logger.log(`Feed formula archived: ${updated.name}`);
    return { data: updated };
  }

  // ═══════════════════════════════════════════
  //  CRUD: approveFormula
  // ═══════════════════════════════════════════
  async approveFormula(id: string, approverId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');
    if (formula.status === FeedFormulaStatus.ARCHIVED) {
      throw new ConflictException('Cannot approve an archived formula');
    }

    const updated = await this.prisma.feedFormula.update({
      where: { id },
      data: {
        status: FeedFormulaStatus.ACTIVE,
        approvedBy: approverId,
      },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });

    this.logger.log(`Feed formula approved: ${updated.name} by ${approverId}`);
    return { data: updated };
  }

  // ═══════════════════════════════════════════
  //  CRUD: removeFormula
  // ═══════════════════════════════════════════
  async removeFormula(id: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    await this.prisma.feedFormula.delete({ where: { id } });
    return { data: { message: 'Feed formula deleted' } };
  }

  // ═══════════════════════════════════════════
  // 1. NUTRIENT CALCULATION ENGINE
  // ═══════════════════════════════════════════
  async calculateFormulaNutrients(formulaId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const totals = this.calculateFormulaNutrientsInternal(formula.ingredients);

    // Compare with NRC if target animal and feedType are set
    let nrcComparison: ReturnType<typeof this.compareWithNRCInternal> | null = null;
    const nrcKey = this.resolveNrcKey(formula.targetAnimal, formula.feedType);
    if (nrcKey) {
      nrcComparison = this.compareWithNRCInternal(totals, nrcKey);
    }

    return {
      data: {
        formulaName: formula.name,
        totals,
        nrcComparison,
      },
    };
  }

  private calculateFormulaNutrientsInternal(
    ingredients: FeedFormulaIngredient[],
  ): ExtendedNutrientProfile {
    const totals: ExtendedNutrientProfile = {
      protein: 0, me: 0, fiber: 0, fat: 0,
      calcium: 0, phosphorus: 0, lysine: 0, methionine: 0,
      costPerKg: 0, costPerTon: 0,
    };

    let totalPercentage = 0;

    for (const ing of ingredients) {
      const pct = D(ing.percentage) / 100;
      totalPercentage += D(ing.percentage);

      const dbIng = INGREDIENT_DB[ing.ingredientName];
      if (dbIng) {
        totals.protein += dbIng.protein * pct;
        totals.me += dbIng.me * pct;
        totals.fiber += dbIng.fiber * pct;
        totals.fat += dbIng.fat * pct;
        totals.calcium += dbIng.calcium * pct;
        totals.phosphorus += dbIng.phosphorus * pct;
        totals.lysine += dbIng.lysine * pct;
        totals.methionine += dbIng.methionine * pct;
        totals.costPerKg += dbIng.costPerKg * pct;
      }
    }

    totals.protein = R(totals.protein);
    totals.me = R(totals.me);
    totals.fiber = R(totals.fiber);
    totals.fat = R(totals.fat);
    totals.calcium = R(totals.calcium);
    totals.phosphorus = R(totals.phosphorus);
    totals.lysine = R(totals.lysine);
    totals.methionine = R(totals.methionine);
    totals.costPerKg = R(totals.costPerKg);
    totals.costPerTon = R(totals.costPerKg * 1000);

    return totals;
  }

  // ═══════════════════════════════════════════
  // 2. LINEAR PROGRAMMING COST OPTIMIZER
  // ═══════════════════════════════════════════
  async optimizeFormula(formulaId: string, constraints?: OptimizeFormulaDto) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    // Build available ingredients list from formula ingredients
    const availableIngredients: OptimizedIngredient[] = formula.ingredients.map((ing) => {
      const dbKey = ing.ingredientName;
      const db = INGREDIENT_DB[dbKey];
      const costPerUnitProtein = db && db.protein > 0
        ? db.costPerKg / db.protein
        : db
          ? db.costPerKg
          : Infinity;
      return {
        key: dbKey,
        name: dbKey,
        costPerKg: db?.costPerKg ?? 0,
        costPerUnitProtein,
        nutrition: db ?? INGREDIENT_DB.CORN_YELLOW,
        minPct: 0,
        maxPct: 100,
        currentPct: D(ing.percentage),
      };
    });

    // Resolve NRC key for nutrient targets
    const nrcKey = this.resolveNrcKey(formula.targetAnimal, formula.feedType);
    const nrcTarget = nrcKey ? NRC_STANDARDS[nrcKey] : null;

    // Override with user constraints
    const nutrientConstraints: Record<string, { min: number; max: number }> = {};
    if (nrcTarget) {
      nutrientConstraints.protein = {
        min: (constraints?.minProtein ?? nrcTarget.protein),
        max: (constraints?.minProtein ?? nrcTarget.protein) * 1.5,
      };
      nutrientConstraints.me = {
        min: (constraints?.minEnergy ?? nrcTarget.me),
        max: (constraints?.minEnergy ?? nrcTarget.me) * 1.3,
      };
      nutrientConstraints.fiber = {
        min: 0,
        max: constraints?.maxFiber ?? nrcTarget.fiber,
      };
      nutrientConstraints.calcium = {
        min: nrcTarget.calcium * 0.9,
        max: nrcTarget.calcium * 1.5,
      };
      nutrientConstraints.phosphorus = {
        min: nrcTarget.phosphorus * 0.9,
        max: nrcTarget.phosphorus * 1.5,
      };
      nutrientConstraints.lysine = {
        min: nrcTarget.lysine * 0.9,
        max: nrcTarget.lysine * 1.5,
      };
      nutrientConstraints.methionine = {
        min: nrcTarget.methionine * 0.9,
        max: nrcTarget.methionine * 1.5,
      };
    }

    // Greedy LP-like optimizer
    const optimized = this.greedyOptimizer(availableIngredients, nutrientConstraints);

    // Calculate current cost
    const currentCostPerTon = availableIngredients.reduce(
      (sum, ing) => sum + ing.currentPct / 100 * ing.costPerKg * 1000,
      0,
    );

    const savings = currentCostPerTon - optimized.totalCostPerTon;
    const savingsPct = currentCostPerTon > 0
      ? R((savings / currentCostPerTon) * 100)
      : 0;

    return {
      data: {
        formulaName: formula.name,
        currentCostPerTon: R(currentCostPerTon),
        optimizedCostPerTon: R(optimized.totalCostPerTon),
        savingsPerTon: R(savings),
        savingsPercent: savingsPct,
        optimizedMix: optimized.mix,
        nutrientTotals: optimized.nutrientTotals,
        constraintsSatisfied: optimized.constraintsSatisfied,
        iterations: optimized.iterations,
      },
    };
  }

  private greedyOptimizer(
    ingredients: OptimizedIngredient[],
    constraints: Record<string, { min: number; max: number }>,
  ): OptimizerResult {
    // Step A: Sort by cost-per-unit-protein (cheapest first)
    const sorted = [...ingredients].sort(
      (a, b) => a.costPerUnitProtein - b.costPerUnitProtein,
    );

    // Initialize mix with minimum percentages
    const mix: Record<string, number> = {};
    let remainingPct = 100;

    // Step B: Apply minimum bounds
    for (const ing of sorted) {
      const minPct = Math.max(0, ing.minPct);
      mix[ing.key] = minPct;
      remainingPct -= minPct;
    }

    // Step C: Greedy fill remaining percentage
    for (const ing of sorted) {
      if (remainingPct <= 0) break;
      const maxPct = Math.min(ing.maxPct, 100);
      const current = mix[ing.key] ?? 0;
      const canAdd = maxPct - current;
      const toAdd = Math.min(canAdd, remainingPct);
      mix[ing.key] = R(current + toAdd);
      remainingPct = R(remainingPct - toAdd);
    }

    // Step D: Evaluate and refine to meet nutrient constraints
    let iterations = 0;
    const maxIterations = 200;
    let constraintsSatisfied = true;

    while (iterations < maxIterations) {
      iterations++;
      const totals = this.calculateMixNutrients(mix);

      // Check all constraints
      let worstViolation: { nutrient: string; deficit: number; ingKey: string | null } | null = null;

      for (const [nutrient, bound] of Object.entries(constraints)) {
        const val = totals[nutrient as keyof NutrientProfile] ?? 0;
        if (val < bound.min) {
          const deficit = bound.min - val;
          if (!worstViolation || deficit > worstViolation.deficit) {
            // Find best ingredient to boost this nutrient
            const bestIng = this.findBestIngredientForNutrient(
              nutrient,
              sorted,
              mix,
            );
            worstViolation = { nutrient, deficit, ingKey: bestIng };
          }
        }
        if (val > bound.max) {
          const excess = val - bound.max;
          // Find ingredient contributing most to excess and reduce
          const worstIng = this.findWorstIngredientForNutrient(
            nutrient,
            sorted,
            mix,
          );
          if (worstIng && (!worstViolation || excess > worstViolation.deficit)) {
            worstViolation = { nutrient, deficit: -excess, ingKey: worstIng };
          }
        }
      }

      if (!worstViolation) break; // All constraints satisfied

      // Apply adjustment
      if (worstViolation.deficit > 0 && worstViolation.ingKey) {
        // Need more of this nutrient - increase best ingredient
        const key = worstViolation.ingKey;
        const ingDef = ingredients.find((i) => i.key === key);
        const current = mix[key] ?? 0;
        const maxAllowed = ingDef?.maxPct ?? 100;
        const step = Math.min(0.5, maxAllowed - current);
        if (step <= 0.01) {
          constraintsSatisfied = false;
          break;
        }
        mix[key] = R(current + step);
        // Reduce cheapest other ingredient
        this.reduceCheapestOther(mix, key, step, sorted);
      } else if (worstViolation.deficit < 0 && worstViolation.ingKey) {
        // Need less of this nutrient - reduce worst ingredient
        const key = worstViolation.ingKey;
        const ingDef = ingredients.find((i) => i.key === key);
        const current = mix[key] ?? 0;
        const minAllowed = ingDef?.minPct ?? 0;
        const step = Math.min(0.5, current - minAllowed);
        if (step <= 0.01) {
          constraintsSatisfied = false;
          break;
        }
        mix[key] = R(current - step);
        // Increase cheapest other ingredient
        this.increaseCheapestOther(mix, key, step, sorted);
      } else {
        constraintsSatisfied = false;
        break;
      }
    }

    // Final totals
    const nutrientTotals = this.calculateMixNutrients(mix);

    // Calculate cost
    let totalCostPerTon = 0;
    for (const [key, pct] of Object.entries(mix)) {
      const ingDef = ingredients.find((i) => i.key === key);
      if (ingDef) {
        totalCostPerTon += (pct / 100) * ingDef.costPerKg * 1000;
      }
    }

    // Normalize percentages to ensure exactly 100%
    const totalPct = Object.values(mix).reduce((s, v) => s + v, 0);
    if (Math.abs(totalPct - 100) > 0.01) {
      for (const key of Object.keys(mix)) {
        mix[key] = R((mix[key] / totalPct) * 100);
      }
    }

    return {
      mix: Object.entries(mix)
        .filter(([, v]) => v > 0)
        .map(([key, percentage]) => {
          const ingDef = ingredients.find((i) => i.key === key);
          return {
            ingredient: key,
            percentage: R(percentage),
            costPerTon: R((percentage / 100) * (ingDef?.costPerKg ?? 0) * 1000),
          };
        })
        .sort((a, b) => b.percentage - a.percentage),
      totalCostPerTon: R(totalCostPerTon),
      nutrientTotals,
      constraintsSatisfied,
      iterations,
    };
  }

  private calculateMixNutrients(mix: Record<string, number>): Partial<NutrientProfile> {
    const totals: Partial<NutrientProfile> = {
      protein: 0, me: 0, fiber: 0, fat: 0,
      calcium: 0, phosphorus: 0, lysine: 0, methionine: 0,
    };

    for (const [key, pct] of Object.entries(mix)) {
      const db = INGREDIENT_DB[key];
      if (db && pct > 0) {
        const p = pct / 100;
        totals.protein! += db.protein * p;
        totals.me! += db.me * p;
        totals.fiber! += db.fiber * p;
        totals.fat! += db.fat * p;
        totals.calcium! += db.calcium * p;
        totals.phosphorus! += db.phosphorus * p;
        totals.lysine! += db.lysine * p;
        totals.methionine! += db.methionine * p;
      }
    }

    for (const k of Object.keys(totals)) {
      (totals as Record<string, number>)[k] = R((totals as Record<string, number>)[k]);
    }
    return totals;
  }

  private findBestIngredientForNutrient(
    nutrient: string,
    ingredients: OptimizedIngredient[],
    mix: Record<string, number>,
  ): string | null {
    let bestKey: string | null = null;
    let bestRatio = -1;

    for (const ing of ingredients) {
      const db = INGREDIENT_DB[ing.key];
      if (!db) continue;
      const val = (db as Record<string, number>)[nutrient] ?? 0;
      if (val <= 0) continue;
      const current = mix[ing.key] ?? 0;
      if (current >= ing.maxPct) continue;
      const ratio = val / ing.costPerKg;
      if (ratio > bestRatio) {
        bestRatio = ratio;
        bestKey = ing.key;
      }
    }

    return bestKey;
  }

  private findWorstIngredientForNutrient(
    nutrient: string,
    ingredients: OptimizedIngredient[],
    mix: Record<string, number>,
  ): string | null {
    let worstKey: string | null = null;
    let worstVal = -1;

    for (const ing of ingredients) {
      const db = INGREDIENT_DB[ing.key];
      if (!db) continue;
      const val = (db as Record<string, number>)[nutrient] ?? 0;
      const current = mix[ing.key] ?? 0;
      if (current <= ing.minPct) continue;
      if (val > worstVal) {
        worstVal = val;
        worstKey = ing.key;
      }
    }

    return worstKey;
  }

  private reduceCheapestOther(
    mix: Record<string, number>,
    excludeKey: string,
    amount: number,
    sorted: OptimizedIngredient[],
  ) {
    for (const ing of sorted) {
      if (ing.key === excludeKey) continue;
      const current = mix[ing.key] ?? 0;
      if (current <= ing.minPct) continue;
      const reducible = current - ing.minPct;
      const reduction = Math.min(reducible, amount);
      mix[ing.key] = R(current - reduction);
      amount = R(amount - reduction);
      if (amount <= 0.001) break;
    }
  }

  private increaseCheapestOther(
    mix: Record<string, number>,
    excludeKey: string,
    amount: number,
    sorted: OptimizedIngredient[],
  ) {
    for (const ing of sorted) {
      if (ing.key === excludeKey) continue;
      const current = mix[ing.key] ?? 0;
      if (current >= ing.maxPct) continue;
      const increasable = ing.maxPct - current;
      const increase = Math.min(increasable, amount);
      mix[ing.key] = R(current + increase);
      amount = R(amount - increase);
      if (amount <= 0.001) break;
    }
  }

  // ═══════════════════════════════════════════
  // 3. FORMULA VALIDATION
  // ═══════════════════════════════════════════
  async validateFormula(formulaId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const result = this.validateIngredientsInternal(formula.ingredients);

    // Also check nutrient targets if animal/feedType are specified
    const nrcKey = this.resolveNrcKey(formula.targetAnimal, formula.feedType);
    if (nrcKey) {
      const totals = this.calculateFormulaNutrientsInternal(formula.ingredients);
      const target = NRC_STANDARDS[nrcKey];
      const checks: Array<{
        name: string;
        actual: number;
        target: number;
        isMax?: boolean;
      }> = [
        { name: 'protein', actual: totals.protein, target: target.protein },
        { name: 'ME (kcal/kg)', actual: totals.me, target: target.me },
        { name: 'fiber', actual: totals.fiber, target: target.fiber, isMax: true },
        { name: 'calcium', actual: totals.calcium, target: target.calcium },
        { name: 'phosphorus', actual: totals.phosphorus, target: target.phosphorus },
        { name: 'lysine', actual: totals.lysine, target: target.lysine },
        { name: 'methionine', actual: totals.methionine, target: target.methionine },
      ];
      for (const check of checks) {
        if (check.isMax) {
          if (check.actual > check.target * 1.2) {
            result.warnings.push(
              `${check.name} (${check.actual}) exceeds maximum target (${check.target})`,
            );
          }
        } else {
          const ratio = check.target > 0 ? (check.actual / check.target) * 100 : 0;
          if (ratio < 90) {
            result.errors.push(
              `${check.name} is ${R(ratio)}% of target (${check.actual} vs ${check.target} required)`,
            );
            result.isValid = false;
          } else if (ratio < 95) {
            result.warnings.push(
              `${check.name} is low at ${R(ratio)}% of target (${check.actual} vs ${check.target})`,
            );
          }
        }
      }
    }

    return { data: result };
  }

  private validateIngredientsInternal(
    ingredients: Array<Pick<FeedFormulaIngredient, 'ingredientName' | 'percentage'>>,
  ): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];
    let isValid = true;

    if (!ingredients || ingredients.length === 0) {
      errors.push('Formula must contain at least one ingredient');
      return { isValid: false, errors, warnings };
    }

    // Check percentages sum to 100%
    const totalPct = ingredients.reduce((sum, ing) => sum + D(ing.percentage), 0);
    if (Math.abs(totalPct - 100) > 0.1) {
      errors.push(`Ingredient percentages sum to ${R(totalPct)}%, must equal 100%`);
      isValid = false;
    }

    // Check each ingredient
    const seenNames = new Set<string>();
    for (const ing of ingredients) {
      if (seenNames.has(ing.ingredientName)) {
        errors.push(`Duplicate ingredient: ${ing.ingredientName}`);
        isValid = false;
      }
      seenNames.add(ing.ingredientName);

      if (D(ing.percentage) < 0) {
        errors.push(`${ing.ingredientName}: percentage cannot be negative`);
        isValid = false;
      }

      if (D(ing.percentage) > 100) {
        errors.push(`${ing.ingredientName}: percentage cannot exceed 100%`);
        isValid = false;
      }

      if (!INGREDIENT_DB[ing.ingredientName]) {
        warnings.push(
          `${ing.ingredientName}: no nutritional data found in database`,
        );
      }
    }

    return { isValid, errors, warnings };
  }

  // ═══════════════════════════════════════════
  // 4. NRC STANDARDS COMPARISON
  // ═══════════════════════════════════════════
  async compareWithNRC(
    formulaId: string,
    targetAnimal: AnimalType,
    feedType: FeedType,
  ) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const totals = this.calculateFormulaNutrientsInternal(formula.ingredients);
    const nrcKey = this.resolveNrcKey(targetAnimal, feedType);

    if (!nrcKey) {
      throw new BadRequestException(
        `No NRC standard found for ${targetAnimal} - ${feedType}. ` +
        `Available: ${Object.keys(NRC_STANDARDS).join(', ')}`,
      );
    }

    const comparison = this.compareWithNRCInternal(totals, nrcKey);

    return {
      data: {
        formulaName: formula.name,
        targetAnimal,
        feedType,
        nrcStandard: NRC_STANDARDS[nrcKey],
        comparison,
      },
    };
  }

  private compareWithNRCInternal(
    totals: NutrientProfile,
    nrcKey: NrcStandardKey,
  ) {
    const target = NRC_STANDARDS[nrcKey];
    const nutrients: Array<{
      nutrient: string;
      actual: number;
      target: number;
      unit: string;
      status: 'met' | 'below' | 'above';
      deviationPct: number;
      color: 'red' | 'yellow' | 'green';
    }> = [
      {
        nutrient: 'Protein',
        actual: totals.protein,
        target: target.protein,
        unit: '%',
        ...interpolateNutrient(totals.protein, target.protein),
      },
      {
        nutrient: 'ME (Metabolizable Energy)',
        actual: totals.me,
        target: target.me,
        unit: 'kcal/kg',
        ...interpolateNutrient(totals.me, target.me),
      },
      {
        nutrient: 'Fiber',
        actual: totals.fiber,
        target: target.fiber,
        unit: '%',
        ...this.evaluateMaxNutrient(totals.fiber, target.fiber),
      },
      {
        nutrient: 'Fat',
        actual: totals.fat,
        target: target.fat,
        unit: '%',
        ...interpolateNutrient(totals.fat, target.fat),
      },
      {
        nutrient: 'Calcium',
        actual: totals.calcium,
        target: target.calcium,
        unit: '%',
        ...interpolateNutrient(totals.calcium, target.calcium),
      },
      {
        nutrient: 'Phosphorus',
        actual: totals.phosphorus,
        target: target.phosphorus,
        unit: '%',
        ...interpolateNutrient(totals.phosphorus, target.phosphorus),
      },
      {
        nutrient: 'Lysine',
        actual: totals.lysine,
        target: target.lysine,
        unit: '%',
        ...interpolateNutrient(totals.lysine, target.lysine),
      },
      {
        nutrient: 'Methionine',
        actual: totals.methionine,
        target: target.methionine,
        unit: '%',
        ...interpolateNutrient(totals.methionine, target.methionine),
      },
    ];

    return nutrients;
  }

  private evaluateMaxNutrient(
    value: number,
    target: number,
  ): { status: 'met' | 'below' | 'above'; deviationPct: number; color: 'red' | 'yellow' | 'green' } {
    // For max nutrients like fiber, lower is better
    const ratio = target > 0 ? (value / target) * 100 : 0;
    if (value > target * 1.2) {
      return { status: 'above', deviationPct: ratio - 100, color: 'red' };
    }
    if (value > target) {
      return { status: 'above', deviationPct: ratio - 100, color: 'yellow' };
    }
    return { status: 'met', deviationPct: ratio - 100, color: 'green' };
  }

  // ─────────────────────────────────────────────
  // NRC Key Resolver: maps (AnimalType, FeedType) -> NrcStandardKey
  // ─────────────────────────────────────────────
  private resolveNrcKey(targetAnimal: AnimalType, feedType: FeedType): NrcStandardKey | null {
    // Map based on feed type (primary) and animal type (context)
    if (feedType === FeedType.BROILER_FEED) {
      if (feedType === FeedType.STARTER) return 'BROILER_STARTER';
      if (feedType === FeedType.GROWER) return 'BROILER_GROWER';
      if (feedType === FeedType.FINISHER) return 'BROILER_FINISHER';
      // Default for BROILER_FEED without specific stage
      return 'BROILER_GROWER';
    }

    if (feedType === FeedType.LAYER) {
      return 'LAYER';
    }

    if (feedType === FeedType.CATTLE_FEED || targetAnimal === AnimalType.CATTLE) {
      return 'CATTLE_GROWING';
    }

    if (feedType === FeedType.SHEEP_FEED || targetAnimal === AnimalType.SHEEP) {
      return 'SHEEP';
    }

    // For other animals (BUFFALO, GOAT, CAMEL), no NRC standards available
    return null;
  }

  // ═══════════════════════════════════════════
  // 5. COST ANALYSIS
  // ═══════════════════════════════════════════
  async analyzeFormulaCost(formulaId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    let rawMaterialCostPerTon = 0;
    const ingredientBreakdown: Array<{
      ingredient: string;
      percentage: number;
      kgPerTon: number;
      costPerKg: number;
      costPerTon: number;
    }> = [];

    for (const ing of formula.ingredients) {
      const db = INGREDIENT_DB[ing.ingredientName];
      const costPerKg = db?.costPerKg ?? 0;
      const kgPerTon = D(ing.percentage) * 10; // % -> kg per 1000kg
      const costPerTon = kgPerTon * costPerKg;
      rawMaterialCostPerTon += costPerTon;

      ingredientBreakdown.push({
        ingredient: ing.ingredientName,
        percentage: D(ing.percentage),
        kgPerTon: R(kgPerTon),
        costPerKg,
        costPerTon: R(costPerTon),
      });
    }

    const processingCostPerTon = PROCESSING_COST_PER_TON;
    const overheadCostPerTon = OVERHEAD_COST_PER_TON;
    const totalCostPerTon = rawMaterialCostPerTon + processingCostPerTon + overheadCostPerTon;

    // Estimate market price (benchmark against similar products)
    const estimatedMarketPricePerTon = this.estimateMarketPrice(formula.targetAnimal, formula.feedType);
    const marginPerTon = estimatedMarketPricePerTon - totalCostPerTon;
    const marginPct = estimatedMarketPricePerTon > 0
      ? R((marginPerTon / estimatedMarketPricePerTon) * 100)
      : 0;

    return {
      data: {
        formulaName: formula.name,
        rawMaterialCostPerTon: R(rawMaterialCostPerTon),
        processingCostPerTon,
        overheadCostPerTon,
        totalCostPerTon: R(totalCostPerTon),
        estimatedMarketPricePerTon: R(estimatedMarketPricePerTon),
        marginPerTon: R(marginPerTon),
        marginPercent: marginPct,
        costBreakdown: {
          rawMaterials: {
            amount: R(rawMaterialCostPerTon),
            percentOfTotal: totalCostPerTon > 0
              ? R((rawMaterialCostPerTon / totalCostPerTon) * 100)
              : 0,
            ingredients: ingredientBreakdown.sort((a, b) => b.costPerTon - a.costPerTon),
          },
          processing: {
            amount: processingCostPerTon,
            percentOfTotal: totalCostPerTon > 0
              ? R((processingCostPerTon / totalCostPerTon) * 100)
              : 0,
          },
          overhead: {
            amount: overheadCostPerTon,
            percentOfTotal: totalCostPerTon > 0
              ? R((overheadCostPerTon / totalCostPerTon) * 100)
              : 0,
          },
        },
      },
    };
  }

  private estimateMarketPrice(targetAnimal: AnimalType, feedType: FeedType): number {
    // Base prices by feed type
    const basePrices: Record<string, number> = {
      BROILER_FEED: 14500,
      LAYER: 13800,
      CATTLE_FEED: 8500,
      SHEEP_FEED: 8000,
      STARTER: 15000,
      GROWER: 12000,
      FINISHER: 11000,
    };

    // Determine base from feedType
    let base = basePrices[feedType] ?? 12000;

    // Fallback to animal type if no feedType match
    if (base === 12000) {
      const animalBasePrices: Record<string, number> = {
        CATTLE: 8500,
        BUFFALO: 8500,
        SHEEP: 8000,
        GOAT: 8000,
        CAMEL: 9000,
      };
      base = animalBasePrices[targetAnimal] ?? 12000;
    }

    // Adjust for stage (starter feeds cost more)
    const stageMultipliers: Record<string, number> = {
      STARTER: 1.08,
      GROWER: 1.0,
      FINISHER: 0.95,
      LAYER: 1.02,
      BROILER_FEED: 1.0,
      CATTLE_FEED: 1.0,
      SHEEP_FEED: 1.0,
    };
    const multiplier = stageMultipliers[feedType] ?? 1.0;

    return base * multiplier;
  }

  // ═══════════════════════════════════════════
  // 6. FEED RECOMMENDATION ENGINE
  // ═══════════════════════════════════════════
  async recommendFormula(dto: RecommendFormulaDto) {
    const { targetAnimal, feedType, budget } = dto;

    const nrcKey = this.resolveNrcKey(targetAnimal, feedType);
    if (!nrcKey) {
      throw new BadRequestException(
        `Cannot resolve NRC standard for ${targetAnimal} - ${feedType}`,
      );
    }

    // Get all active formulas from the database matching criteria
    const formulas = await this.prisma.feedFormula.findMany({
      where: {
        targetAnimal,
        feedType,
        status: FeedFormulaStatus.ACTIVE,
      },
      include: { ingredients: { orderBy: { order: 'asc' } } },
      take: 50,
    });

    if (formulas.length === 0) {
      // Fallback: return generic recommendation based on NRC + ingredient DB
      return {
        data: {
          recommendations: [this.buildGenericRecommendation(nrcKey)],
          note: `No stored formulas found for ${targetAnimal} - ${feedType}. Showing generic NRC-based recommendation.`,
        },
      };
    }

    const target = NRC_STANDARDS[nrcKey];
    const scored = await Promise.all(
      formulas.map(async (formula) => {
        const totals = this.calculateFormulaNutrientsInternal(formula.ingredients);
        const costAnalysis = await this.analyzeFormulaCost(formula.id);

        // Score 1: Nutrient adequacy (0-40 points)
        let nutrientScore = 0;
        const nutrients = [
          { a: totals.protein, t: target.protein },
          { a: totals.me, t: target.me },
          { a: totals.lysine, t: target.lysine },
          { a: totals.methionine, t: target.methionine },
          { a: totals.calcium, t: target.calcium },
          { a: totals.phosphorus, t: target.phosphorus },
        ];
        for (const n of nutrients) {
          const ratio = n.t > 0 ? n.a / n.t : 0;
          if (ratio >= 1.0) nutrientScore += 40 / nutrients.length;
          else if (ratio >= 0.9) nutrientScore += (40 / nutrients.length) * 0.75;
          else if (ratio >= 0.8) nutrientScore += (40 / nutrients.length) * 0.4;
          else nutrientScore += (40 / nutrients.length) * ratio;
        }

        // Score 2: Cost efficiency (0-30 points)
        const costPerTon = costAnalysis.data.totalCostPerTon;
        let costScore = 0;
        if (budget && budget > 0) {
          if (costPerTon <= budget) costScore = 30;
          else {
            const overage = (costPerTon - budget) / budget;
            costScore = Math.max(0, 30 * (1 - overage));
          }
        } else {
          // Score relative to estimated market price
          const marketPrice = costAnalysis.data.estimatedMarketPricePerTon;
          if (marketPrice > 0) {
            const ratio = costPerTon / marketPrice;
            costScore = ratio <= 0.85 ? 30 : ratio <= 1.0 ? 22 : ratio <= 1.15 ? 12 : 5;
          }
        }

        // Score 3: Formula balance (0-20 points)
        const totalPct = formula.ingredients.reduce(
          (s, i) => s + D(i.percentage), 0,
        );
        const balanceScore = Math.abs(totalPct - 100) < 0.1 ? 20 : 10;

        // Score 4: Ingredient diversity (0-10 points)
        const diversityScore = Math.min(10, formula.ingredients.length * 1.5);

        const totalScore = R(nutrientScore + costScore + balanceScore + diversityScore);

        return {
          formula,
          score: totalScore,
          nutrientScore: R(nutrientScore),
          costScore: R(costScore),
          balanceScore: R(balanceScore),
          diversityScore: R(diversityScore),
          costPerTon,
          nutrientTotals: totals,
        };
      }),
    );

    // Sort by score descending
    scored.sort((a, b) => b.score - a.score);

    // Apply budget filter if provided
    const filtered = budget
      ? scored.filter((s) => s.costPerTon <= budget * 1.2)
      : scored;

    const top3 = (filtered.length > 0 ? filtered : scored)
      .slice(0, 3)
      .map((s) => ({
        formulaId: s.formula.id,
        formulaName: s.formula.name,
        score: s.score,
        scoreBreakdown: {
          nutrientAdequacy: s.nutrientScore,
          costEfficiency: s.costScore,
          balance: s.balanceScore,
          ingredientDiversity: s.diversityScore,
        },
        costPerTon: R(s.costPerTon),
        withinBudget: budget ? s.costPerTon <= budget : true,
        nutrientTotals: s.nutrientTotals,
      }));

    return {
      data: {
        targetAnimal,
        feedType,
        budget: budget ?? null,
        recommendations: top3,
        totalCandidates: formulas.length,
      },
    };
  }

  private buildGenericRecommendation(nrcKey: NrcStandardKey) {
    const target = NRC_STANDARDS[nrcKey];

    // Build a simple least-cost formula that meets NRC
    const mix = this.buildLeastCostMix(target);

    return {
      formulaId: null,
      formulaName: `Generic ${nrcKey.replace('_', ' ')} Formula`,
      score: 75,
      scoreBreakdown: {
        nutrientAdequacy: 35,
        costEfficiency: 20,
        balance: 20,
        ingredientDiversity: 0,
      },
      costPerTon: R(mix.costPerTon),
      withinBudget: true,
      recommendedMix: mix.ingredients,
      nutrientTotals: mix.nutrients,
    };
  }

  private buildLeastCostMix(target: typeof NRC_STANDARDS[NrcStandardKey]) {
    // Simple least-cost: use corn + soybean meal + supplements
    const ingredients: Array<{
      key: string;
    } & IngredientNutrition & {
      minPct: number;
      maxPct: number;
    }> = [
      { key: 'CORN_YELLOW', ...INGREDIENT_DB.CORN_YELLOW, minPct: 40, maxPct: 70 },
      { key: 'SOYBEAN_MEAL', ...INGREDIENT_DB.SOYBEAN_MEAL, minPct: 15, maxPct: 40 },
      { key: 'WHEAT_BRAN', ...INGREDIENT_DB.WHEAT_BRAN, minPct: 0, maxPct: 15 },
      { key: 'CALCIUM_CARBONATE', ...INGREDIENT_DB.CALCIUM_CARBONATE, minPct: 0.5, maxPct: 3 },
      { key: 'DICALCIUM_PHOSPHATE', ...INGREDIENT_DB.DICALCIUM_PHOSPHATE, minPct: 0.5, maxPct: 3 },
      { key: 'SALT', ...INGREDIENT_DB.SALT, minPct: 0.25, maxPct: 0.5 },
      { key: 'VITAMIN_PREMIX', ...INGREDIENT_DB.VITAMIN_PREMIX, minPct: 0.1, maxPct: 0.5 },
    ];

    const result = this.greedyOptimizer(ingredients, {
      protein: { min: target.protein, max: target.protein * 1.3 },
      me: { min: target.me, max: target.me * 1.2 },
      fiber: { min: 0, max: target.fiber * 1.5 },
      calcium: { min: target.calcium * 0.9, max: target.calcium * 2 },
      phosphorus: { min: target.phosphorus * 0.9, max: target.phosphorus * 2 },
      lysine: { min: target.lysine * 0.9, max: target.lysine * 2 },
      methionine: { min: target.methionine * 0.9, max: target.methionine * 2 },
    });

    return {
      ingredients: result.mix,
      nutrients: result.nutrientTotals,
      costPerTon: result.totalCostPerTon,
    };
  }

  // ═══════════════════════════════════════════
  // 7. FEED COST CRUD
  // ═══════════════════════════════════════════
  async createFeedCost(userId: string, dto: CreateFeedCostDto) {
    // Verify formula exists
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: dto.formulaId },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const feedCost = await this.prisma.feedCost.create({
      data: {
        formulaId: dto.formulaId,
        rawMaterialCost: new Prisma.Decimal(dto.rawMaterialCost),
        laborCost: new Prisma.Decimal(dto.laborCost),
        overheadCost: new Prisma.Decimal(dto.overheadCost),
        totalCost: new Prisma.Decimal(dto.totalCost),
        costPerTon: new Prisma.Decimal(dto.costPerTon),
        margin: dto.margin != null ? new Prisma.Decimal(dto.margin) : null,
        effectiveDate: new Date(dto.effectiveDate),
      },
    });

    this.logger.log(
      `Feed cost record created for formula ${dto.formulaId} by ${userId}`,
    );
    return { data: feedCost };
  }

  async findAllFeedCosts(formulaId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const costs = await this.prisma.feedCost.findMany({
      where: { formulaId },
      orderBy: { effectiveDate: 'desc' },
    });

    return { data: costs };
  }

  async findLatestFeedCost(formulaId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const cost = await this.prisma.feedCost.findFirst({
      where: { formulaId },
      orderBy: { effectiveDate: 'desc' },
    });

    if (!cost) throw new NotFoundException('No cost records found for this formula');

    return { data: cost };
  }

  async removeFeedCost(id: string) {
    const cost = await this.prisma.feedCost.findUnique({
      where: { id },
    });
    if (!cost) throw new NotFoundException('Feed cost record not found');

    await this.prisma.feedCost.delete({ where: { id } });
    return { data: { message: 'Feed cost record deleted' } };
  }

  // ═══════════════════════════════════════════
  // 8. COST REPORTING & MARGIN ANALYSIS
  // ═══════════════════════════════════════════
  async getCostReport(formulaId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: {
        ingredients: { orderBy: { order: 'asc' } },
        feedCosts: { orderBy: { effectiveDate: 'desc' }, take: 10 },
      },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    // Current ingredient-based cost analysis
    const currentAnalysis = (await this.analyzeFormulaCost(formulaId)).data;

    // Cost history for trend analysis
    const costHistory = formula.feedCosts.map((cost) => ({
      effectiveDate: cost.effectiveDate,
      rawMaterialCost: D(cost.rawMaterialCost),
      laborCost: D(cost.laborCost),
      overheadCost: D(cost.overheadCost),
      totalCost: D(cost.totalCost),
      costPerTon: D(cost.costPerTon),
      margin: cost.margin != null ? D(cost.margin) : null,
    }));

    // Calculate trends
    let costTrend: 'rising' | 'falling' | 'stable' = 'stable';
    if (costHistory.length >= 2) {
      const recent = costHistory[0].totalCost;
      const older = costHistory[costHistory.length - 1].totalCost;
      const change = recent - older;
      if (Math.abs(change) < older * 0.05) costTrend = 'stable';
      else if (change > 0) costTrend = 'rising';
      else costTrend = 'falling';
    }

    // Margin analysis
    const latestCost = costHistory.length > 0 ? costHistory[0] : null;
    const marginAnalysis = latestCost && latestCost.margin != null
      ? {
          currentMargin: latestCost.margin,
          marginPerTon: latestCost.costPerTon * (latestCost.margin / 100),
          sellingPricePerTon: latestCost.costPerTon * (1 + latestCost.margin / 100),
        }
      : null;

    return {
      data: {
        formulaId,
        formulaName: formula.name,
        targetAnimal: formula.targetAnimal,
        feedType: formula.feedType,
        status: formula.status,
        currentAnalysis,
        costHistory,
        costTrend,
        marginAnalysis,
        recordCount: costHistory.length,
      },
    };
  }

  // ═══════════════════════════════════════════
  // 9. INGREDIENT MANAGEMENT
  // ═══════════════════════════════════════════
  async addIngredient(formulaId: string, ingredient: FeedFormulaIngredientDto) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: true },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const existingNames = formula.ingredients.map((i) => i.ingredientName);
    if (existingNames.includes(ingredient.ingredientName)) {
      throw new ConflictException(
        `Ingredient "${ingredient.ingredientName}" already exists in formula`,
      );
    }

    const maxOrder = formula.ingredients.reduce(
      (max, i) => Math.max(max, i.order), 0,
    );

    const newIngredient = await this.prisma.feedFormulaIngredient.create({
      data: {
        formulaId,
        ingredientName: ingredient.ingredientName,
        percentage: new Prisma.Decimal(ingredient.percentage),
        proteinPercent: ingredient.proteinPercent != null
          ? new Prisma.Decimal(ingredient.proteinPercent)
          : null,
        energyValue: ingredient.energyValue != null
          ? new Prisma.Decimal(ingredient.energyValue)
          : null,
        costPerKg: ingredient.costPerKg != null
          ? new Prisma.Decimal(ingredient.costPerKg)
          : null,
        order: ingredient.order ?? maxOrder + 1,
      },
    });

    // Re-validate the formula after adding ingredient
    const updatedFormula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });

    if (updatedFormula) {
      const validation = this.validateIngredientsInternal(updatedFormula.ingredients);
      return {
        data: {
          ingredient: newIngredient,
          formulaValidation: validation,
        },
      };
    }

    return { data: { ingredient: newIngredient } };
  }

  async removeIngredient(formulaId: string, ingredientId: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: true },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const ingredient = formula.ingredients.find((i) => i.id === ingredientId);
    if (!ingredient) throw new NotFoundException('Ingredient not found in formula');

    await this.prisma.feedFormulaIngredient.delete({
      where: { id: ingredientId },
    });

    return {
      data: {
        message: `Ingredient "${ingredient.ingredientName}" removed from formula`,
      },
    };
  }

  async updateIngredient(
    formulaId: string,
    ingredientId: string,
    updates: FeedFormulaIngredientDto,
  ) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: true },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const ingredient = formula.ingredients.find((i) => i.id === ingredientId);
    if (!ingredient) throw new NotFoundException('Ingredient not found in formula');

    // Check for name conflicts if renaming
    if (
      updates.ingredientName !== ingredient.ingredientName &&
      formula.ingredients.some(
        (i) => i.id !== ingredientId && i.ingredientName === updates.ingredientName,
      )
    ) {
      throw new ConflictException(
        `Ingredient "${updates.ingredientName}" already exists in formula`,
      );
    }

    const updateData: Prisma.FeedFormulaIngredientUpdateInput = {};
    if (updates.ingredientName !== undefined) updateData.ingredientName = updates.ingredientName;
    if (updates.percentage !== undefined) {
      updateData.percentage = new Prisma.Decimal(updates.percentage);
    }
    if (updates.proteinPercent !== undefined) {
      updateData.proteinPercent = updates.proteinPercent != null
        ? new Prisma.Decimal(updates.proteinPercent)
        : null;
    }
    if (updates.energyValue !== undefined) {
      updateData.energyValue = updates.energyValue != null
        ? new Prisma.Decimal(updates.energyValue)
        : null;
    }
    if (updates.costPerKg !== undefined) {
      updateData.costPerKg = updates.costPerKg != null
        ? new Prisma.Decimal(updates.costPerKg)
        : null;
    }
    if (updates.order !== undefined) updateData.order = updates.order;

    const updatedIngredient = await this.prisma.feedFormulaIngredient.update({
      where: { id: ingredientId },
      data: updateData,
    });

    // Re-validate the formula after updating
    const updatedFormula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });

    if (updatedFormula) {
      const validation = this.validateIngredientsInternal(updatedFormula.ingredients);
      return {
        data: {
          ingredient: updatedIngredient,
          formulaValidation: validation,
        },
      };
    }

    return { data: { ingredient: updatedIngredient } };
  }

  // ═══════════════════════════════════════════
  // 10. FEED BATCH QUALITY CONTROL
  // ═══════════════════════════════════════════
  async qualityControlCheck(formulaId: string, actualNutrients: NutrientProfile) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: formulaId },
      include: { ingredients: { orderBy: { order: 'asc' } } },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const expected = this.calculateFormulaNutrientsInternal(formula.ingredients);
    const nrcKey = this.resolveNrcKey(formula.targetAnimal, formula.feedType);
    const nrcTarget = nrcKey ? NRC_STANDARDS[nrcKey] : null;

    const checks: Array<{
      nutrient: string;
      expected: number;
      actual: number;
      deviation: number;
      withinTolerance: boolean;
      nrcTarget?: number;
    }> = [
      { nutrient: 'protein', expected: expected.protein, actual: actualNutrients.protein },
      { nutrient: 'me', expected: expected.me, actual: actualNutrients.me },
      { nutrient: 'fiber', expected: expected.fiber, actual: actualNutrients.fiber },
      { nutrient: 'fat', expected: expected.fat, actual: actualNutrients.fat },
      { nutrient: 'calcium', expected: expected.calcium, actual: actualNutrients.calcium },
      { nutrient: 'phosphorus', expected: expected.phosphorus, actual: actualNutrients.phosphorus },
      { nutrient: 'lysine', expected: expected.lysine, actual: actualNutrients.lysine },
      { nutrient: 'methionine', expected: expected.methionine, actual: actualNutrients.methionine },
    ];

    const tolerance = 0.1; // 10% tolerance
    const results = checks.map((check) => {
      const deviation = check.expected > 0
        ? R(((check.actual - check.expected) / check.expected) * 100)
        : 0;
      const withinTolerance = Math.abs(deviation) <= tolerance * 100;

      return {
        nutrient: check.nutrient,
        expected: check.expected,
        actual: check.actual,
        deviation,
        withinTolerance,
        nrcTarget: nrcTarget
          ? (nrcTarget as Record<string, number>)[check.nutrient]
          : undefined,
      };
    });

    const passed = results.every((r) => r.withinTolerance);

    return {
      data: {
        formulaId,
        formulaName: formula.name,
        passed,
        tolerancePercent: tolerance * 100,
        results,
        summary: {
          passed: results.filter((r) => r.withinTolerance).length,
          failed: results.filter((r) => !r.withinTolerance).length,
          total: results.length,
        },
      },
    };
  }

  // ═══════════════════════════════════════════
  // 11. LIST AVAILABLE INGREDIENTS FROM DB
  // ═══════════════════════════════════════════
  getAvailableIngredients() {
    const ingredients = Object.entries(INGREDIENT_DB).map(([key, nutrition]) => ({
      key,
      name: key,
      ...nutrition,
    }));

    return { data: ingredients };
  }
}
