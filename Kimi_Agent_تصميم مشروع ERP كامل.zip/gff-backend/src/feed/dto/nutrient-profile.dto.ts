import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, Min } from 'class-validator';
import { Type } from 'class-transformer';

export class NutrientProfileDto {
  @ApiProperty({ description: 'Protein percentage', example: 20.5 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  protein: number;

  @ApiProperty({ description: 'Metabolizable Energy (kcal/kg)', example: 3200 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  me: number;

  @ApiProperty({ description: 'Fiber percentage', example: 6.0 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  fiber: number;

  @ApiProperty({ description: 'Fat percentage', example: 4.5 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  fat: number;

  @ApiProperty({ description: 'Calcium percentage', example: 0.9 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  calcium: number;

  @ApiProperty({ description: 'Phosphorus percentage', example: 0.4 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  phosphorus: number;

  @ApiProperty({ description: 'Lysine percentage', example: 1.0 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  lysine: number;

  @ApiProperty({ description: 'Methionine percentage', example: 0.45 })
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  methionine: number;
}
