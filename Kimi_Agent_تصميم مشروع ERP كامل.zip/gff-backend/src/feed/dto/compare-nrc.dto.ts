import { ApiProperty } from '@nestjs/swagger';
import { IsEnum } from 'class-validator';
import { AnimalType, FeedType } from '@prisma/client';

export class CompareNrcDto {
  @ApiProperty({
    description: 'Target animal type',
    enum: AnimalType,
    example: AnimalType.CATTLE,
  })
  @IsEnum(AnimalType)
  targetAnimal: AnimalType;

  @ApiProperty({
    description: 'Feed type / production stage',
    enum: FeedType,
    example: FeedType.STARTER,
  })
  @IsEnum(FeedType)
  feedType: FeedType;
}
