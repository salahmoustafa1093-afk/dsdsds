import { ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsOptional,
  IsEnum,
  IsInt,
  IsString,
  Min,
} from 'class-validator';
import { Type } from 'class-transformer';
import { AnimalType, FeedType, FeedFormulaStatus } from '@prisma/client';

export class QueryFeedFormulaDto {
  @ApiPropertyOptional({
    description: 'Page number',
    example: 1,
    default: 1,
  })
  @IsOptional()
  @IsInt()
  @Min(1)
  @Type(() => Number)
  page?: number;

  @ApiPropertyOptional({
    description: 'Items per page',
    example: 10,
    default: 10,
  })
  @IsOptional()
  @IsInt()
  @Min(1)
  @Type(() => Number)
  limit?: number;

  @ApiPropertyOptional({
    description: 'Filter by target animal',
    enum: AnimalType,
  })
  @IsOptional()
  @IsEnum(AnimalType)
  targetAnimal?: AnimalType;

  @ApiPropertyOptional({
    description: 'Filter by feed type',
    enum: FeedType,
  })
  @IsOptional()
  @IsEnum(FeedType)
  feedType?: FeedType;

  @ApiPropertyOptional({
    description: 'Filter by status',
    enum: FeedFormulaStatus,
  })
  @IsOptional()
  @IsEnum(FeedFormulaStatus)
  status?: FeedFormulaStatus;

  @ApiPropertyOptional({
    description: 'Search by formula name',
    example: 'Broiler',
  })
  @IsOptional()
  @IsString()
  search?: string;
}
