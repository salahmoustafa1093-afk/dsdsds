import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsNumber, Min } from 'class-validator';
import { Type } from 'class-transformer';

export class OptimizeFormulaDto {
  @ApiPropertyOptional({
    description: 'Minimum protein constraint (%)',
    example: 20,
  })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  minProtein?: number;

  @ApiPropertyOptional({
    description: 'Minimum metabolizable energy constraint (kcal/kg)',
    example: 3000,
  })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  minEnergy?: number;

  @ApiPropertyOptional({
    description: 'Maximum fiber constraint (%)',
    example: 8,
  })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  maxFiber?: number;
}
