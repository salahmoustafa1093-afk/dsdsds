import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsEnum,
  IsOptional,
  ValidateNested,
  ArrayMinSize,
} from 'class-validator';
import { Type } from 'class-transformer';
import { AnimalType, FeedType, FeedFormulaStatus } from '@prisma/client';
import { FeedFormulaIngredientDto } from './feed-formula-ingredient.dto';

export class CreateFeedFormulaDto {
  @ApiProperty({
    description: 'Formula name',
    example: 'Broiler Starter Formula - Farm 1',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    description: 'Target animal type',
    enum: AnimalType,
    example: AnimalType.CATTLE,
  })
  @IsEnum(AnimalType)
  targetAnimal: AnimalType;

  @ApiProperty({
    description: 'Feed type / production stage',
    enum: FeedType,
    example: FeedType.STARTER,
  })
  @IsEnum(FeedType)
  feedType: FeedType;

  @ApiPropertyOptional({
    description: 'Formula status',
    enum: FeedFormulaStatus,
    default: FeedFormulaStatus.DRAFT,
  })
  @IsOptional()
  @IsEnum(FeedFormulaStatus)
  status?: FeedFormulaStatus;

  @ApiProperty({
    description: 'Formula ingredients',
    type: [FeedFormulaIngredientDto],
  })
  @ValidateNested({ each: true })
  @Type(() => FeedFormulaIngredientDto)
  @ArrayMinSize(1)
  ingredients: FeedFormulaIngredientDto[];
}
