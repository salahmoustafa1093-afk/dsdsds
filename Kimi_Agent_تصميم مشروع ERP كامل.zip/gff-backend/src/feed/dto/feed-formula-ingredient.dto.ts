import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  Min,
  Max,
} from 'class-validator';
import { Type } from 'class-transformer';

export class FeedFormulaIngredientDto {
  @ApiProperty({
    description: 'Name of the ingredient (e.g. CORN_YELLOW, SOYBEAN_MEAL)',
    example: 'CORN_YELLOW',
  })
  @IsString()
  @IsNotEmpty()
  ingredientName: string;

  @ApiProperty({
    description: 'Percentage of this ingredient in the formula (0-100)',
    example: 45.5,
  })
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Max(100)
  @Type(() => Number)
  percentage: number;

  @ApiPropertyOptional({
    description: 'Protein percentage of this ingredient',
    example: 8.5,
  })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Max(100)
  @Type(() => Number)
  proteinPercent?: number;

  @ApiPropertyOptional({
    description: 'Energy value (ME kcal/kg) of this ingredient',
    example: 3350,
  })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  energyValue?: number;

  @ApiPropertyOptional({
    description: 'Cost per kg of this ingredient in EGP',
    example: 12.5,
  })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  @Type(() => Number)
  costPerKg?: number;

  @ApiPropertyOptional({
    description: 'Display order for this ingredient',
    example: 1,
    default: 0,
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  order?: number;
}
