import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsNumber, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { AnimalType, FeedType } from '@prisma/client';

export class RecommendFormulaDto {
  @ApiProperty({
    description: 'Target animal type',
    enum: AnimalType,
    example: AnimalType.CATTLE,
  })
  @IsEnum(AnimalType)
  targetAnimal: AnimalType;

  @ApiProperty({
    description: 'Feed type / production stage',
    enum: FeedType,
    example: FeedType.STARTER,
  })
  @IsEnum(FeedType)
  feedType: FeedType;

  @ApiPropertyOptional({
    description: 'Animal weight in kg (for future use)',
    example: 350,
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  weight?: number;

  @ApiPropertyOptional({
    description: 'Maximum budget per ton in EGP',
    example: 10000,
  })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  budget?: number;
}
