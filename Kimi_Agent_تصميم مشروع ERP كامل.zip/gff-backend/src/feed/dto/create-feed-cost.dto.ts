import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsDateString,
  Min,
} from 'class-validator';
import { Type } from 'class-transformer';

export class CreateFeedCostDto {
  @ApiProperty({
    description: 'Feed formula ID',
    example: '550e8400-e29b-41d4-a716-446655440000',
  })
  @IsString()
  @IsNotEmpty()
  formulaId: string;

  @ApiProperty({
    description: 'Raw material cost',
    example: 8500.0,
  })
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  rawMaterialCost: number;

  @ApiProperty({
    description: 'Labor cost',
    example: 500.0,
  })
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  laborCost: number;

  @ApiProperty({
    description: 'Overhead cost',
    example: 350.0,
  })
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  overheadCost: number;

  @ApiProperty({
    description: 'Total cost (raw + labor + overhead)',
    example: 9350.0,
  })
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  totalCost: number;

  @ApiProperty({
    description: 'Cost per metric ton',
    example: 9350.0,
  })
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  costPerTon: number;

  @ApiPropertyOptional({
    description: 'Profit margin percentage',
    example: 15.5,
  })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  margin?: number;

  @ApiProperty({
    description: 'Effective date for this cost record',
    example: '2025-01-15',
  })
  @IsDateString()
  effectiveDate: string;
}
