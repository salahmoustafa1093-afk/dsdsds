import { ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsEnum,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';
import { AnimalType, FeedType, FeedFormulaStatus } from '@prisma/client';
import { FeedFormulaIngredientDto } from './feed-formula-ingredient.dto';

export class UpdateFeedFormulaDto {
  @ApiPropertyOptional({
    description: 'Formula name',
    example: 'Updated Broiler Starter Formula',
  })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional({
    description: 'Target animal type',
    enum: AnimalType,
    example: AnimalType.CATTLE,
  })
  @IsOptional()
  @IsEnum(AnimalType)
  targetAnimal?: AnimalType;

  @ApiPropertyOptional({
    description: 'Feed type / production stage',
    enum: FeedType,
    example: FeedType.STARTER,
  })
  @IsOptional()
  @IsEnum(FeedType)
  feedType?: FeedType;

  @ApiPropertyOptional({
    description: 'Formula status',
    enum: FeedFormulaStatus,
    example: FeedFormulaStatus.ACTIVE,
  })
  @IsOptional()
  @IsEnum(FeedFormulaStatus)
  status?: FeedFormulaStatus;

  @ApiPropertyOptional({
    description: 'Replace all ingredients (if provided, existing ingredients are deleted and replaced)',
    type: [FeedFormulaIngredientDto],
  })
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => FeedFormulaIngredientDto)
  ingredients?: FeedFormulaIngredientDto[];
}
