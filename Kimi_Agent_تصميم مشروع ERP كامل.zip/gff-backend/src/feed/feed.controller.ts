import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { FeedService } from './feed.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateFeedFormulaDto,
  UpdateFeedFormulaDto,
  CreateFeedCostDto,
  OptimizeFormulaDto,
  RecommendFormulaDto,
  CompareNrcDto,
  QueryFeedFormulaDto,
  FeedFormulaIngredientDto,
  NutrientProfileDto,
} from './dto';

@ApiTags('Feed')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('feed')
export class FeedController {
  constructor(private readonly feedService: FeedService) {}

  // ─── Formula CRUD ───

  @Get('formulas')
  @Permissions('production:view')
  @ApiOperation({ summary: 'List feed formulas' })
  @ApiResponse({ status: 200, description: 'Feed formulas retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllFormulas(@Query() query: QueryFeedFormulaDto) {
    return this.feedService.findAllFormulas(query);
  }

  @Get('formulas/:id')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get feed formula by ID' })
  @ApiResponse({ status: 200, description: 'Feed formula retrieved' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOneFormula(@Param('id', ParseUUIDPipe) id: string) {
    return this.feedService.findOneFormula(id);
  }

  @Post('formulas')
  @Permissions('production:create')
  @ApiOperation({ summary: 'Create feed formula' })
  @ApiResponse({ status: 201, description: 'Feed formula created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createFormula(
    @CurrentUser('id') userId: string,
    @Body() dto: CreateFeedFormulaDto,
  ) {
    return this.feedService.createFormula(userId, dto);
  }

  @Put('formulas/:id')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Update feed formula' })
  @ApiResponse({ status: 200, description: 'Feed formula updated' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateFormula(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateFeedFormulaDto,
  ) {
    return this.feedService.updateFormula(id, dto);
  }

  @Delete('formulas/:id')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Delete feed formula' })
  @ApiResponse({ status: 200, description: 'Feed formula deleted' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async removeFormula(@Param('id', ParseUUIDPipe) id: string) {
    return this.feedService.removeFormula(id);
  }

  @Put('formulas/:id/archive')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Archive feed formula (soft delete via status)' })
  @ApiResponse({ status: 200, description: 'Feed formula archived' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async archiveFormula(@Param('id', ParseUUIDPipe) id: string) {
    return this.feedService.archiveFormula(id);
  }

  @Put('formulas/:id/approve')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Approve feed formula' })
  @ApiResponse({ status: 200, description: 'Feed formula approved' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  @ApiResponse({ status: 409, description: 'Cannot approve archived formula' })
  async approveFormula(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('id') userId: string,
  ) {
    return this.feedService.approveFormula(id, userId);
  }

  // ─── Nutrient & NRC ───

  @Get('formulas/:id/nutrients')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Calculate formula nutrients + NRC comparison' })
  @ApiResponse({ status: 200, description: 'Nutrients calculated' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async calculateFormulaNutrients(
    @Param('id', ParseUUIDPipe) formulaId: string,
  ) {
    return this.feedService.calculateFormulaNutrients(formulaId);
  }

  @Post('formulas/:id/nrc-compare')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Compare formula against NRC standards' })
  @ApiResponse({ status: 200, description: 'NRC comparison done' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  @ApiResponse({ status: 400, description: 'No NRC standard found' })
  async compareWithNRC(
    @Param('id', ParseUUIDPipe) formulaId: string,
    @Body() dto: CompareNrcDto,
  ) {
    return this.feedService.compareWithNRC(
      formulaId,
      dto.targetAnimal,
      dto.feedType,
    );
  }

  // ─── Validation ───

  @Post('formulas/:id/validate')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Validate feed formula' })
  @ApiResponse({ status: 200, description: 'Validation completed' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async validateFormula(@Param('id', ParseUUIDPipe) formulaId: string) {
    return this.feedService.validateFormula(formulaId);
  }

  // ─── Optimization ───

  @Post('formulas/:id/optimize')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Optimize feed formula costs (LP-like)' })
  @ApiResponse({ status: 200, description: 'Optimization completed' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async optimizeFormula(
    @Param('id', ParseUUIDPipe) formulaId: string,
    @Body() dto: OptimizeFormulaDto,
  ) {
    return this.feedService.optimizeFormula(formulaId, dto);
  }

  // ─── Cost Analysis ───

  @Get('formulas/:id/cost-analysis')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Analyze formula cost breakdown' })
  @ApiResponse({ status: 200, description: 'Cost analysis retrieved' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async analyzeFormulaCost(
    @Param('id', ParseUUIDPipe) formulaId: string,
  ) {
    return this.feedService.analyzeFormulaCost(formulaId);
  }

  // ─── Recommendations ───

  @Post('recommend')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get feed formula recommendations' })
  @ApiResponse({ status: 200, description: 'Recommendations retrieved' })
  @ApiResponse({ status: 400, description: 'Cannot resolve NRC standard' })
  async recommendFormula(@Body() dto: RecommendFormulaDto) {
    return this.feedService.recommendFormula(dto);
  }

  // ─── Feed Cost CRUD ───

  @Post('costs')
  @Permissions('production:create')
  @ApiOperation({ summary: 'Create feed cost record' })
  @ApiResponse({ status: 201, description: 'Feed cost record created' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async createFeedCost(
    @CurrentUser('id') userId: string,
    @Body() dto: CreateFeedCostDto,
  ) {
    return this.feedService.createFeedCost(userId, dto);
  }

  @Get('formulas/:id/costs')
  @Permissions('production:view')
  @ApiOperation({ summary: 'List all cost records for a formula' })
  @ApiResponse({ status: 200, description: 'Cost records retrieved' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async findAllFeedCosts(
    @Param('id', ParseUUIDPipe) formulaId: string,
  ) {
    return this.feedService.findAllFeedCosts(formulaId);
  }

  @Get('formulas/:id/costs/latest')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get latest cost record for a formula' })
  @ApiResponse({ status: 200, description: 'Latest cost record retrieved' })
  @ApiResponse({ status: 404, description: 'No cost records found' })
  async findLatestFeedCost(
    @Param('id', ParseUUIDPipe) formulaId: string,
  ) {
    return this.feedService.findLatestFeedCost(formulaId);
  }

  @Delete('costs/:id')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Delete feed cost record' })
  @ApiResponse({ status: 200, description: 'Feed cost record deleted' })
  @ApiResponse({ status: 404, description: 'Feed cost record not found' })
  async removeFeedCost(@Param('id', ParseUUIDPipe) id: string) {
    return this.feedService.removeFeedCost(id);
  }

  // ─── Cost Reporting ───

  @Get('formulas/:id/cost-report')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get full cost report with trends and margin analysis' })
  @ApiResponse({ status: 200, description: 'Cost report retrieved' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async getCostReport(@Param('id', ParseUUIDPipe) formulaId: string) {
    return this.feedService.getCostReport(formulaId);
  }

  // ─── Ingredient Management ───

  @Post('formulas/:id/ingredients')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Add ingredient to formula' })
  @ApiResponse({ status: 201, description: 'Ingredient added' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  @ApiResponse({ status: 409, description: 'Ingredient already exists' })
  async addIngredient(
    @Param('id', ParseUUIDPipe) formulaId: string,
    @Body() dto: FeedFormulaIngredientDto,
  ) {
    return this.feedService.addIngredient(formulaId, dto);
  }

  @Put('formulas/:formulaId/ingredients/:ingredientId')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Update formula ingredient' })
  @ApiResponse({ status: 200, description: 'Ingredient updated' })
  @ApiResponse({ status: 404, description: 'Formula or ingredient not found' })
  @ApiResponse({ status: 409, description: 'Ingredient name conflict' })
  async updateIngredient(
    @Param('formulaId', ParseUUIDPipe) formulaId: string,
    @Param('ingredientId', ParseUUIDPipe) ingredientId: string,
    @Body() dto: FeedFormulaIngredientDto,
  ) {
    return this.feedService.updateIngredient(formulaId, ingredientId, dto);
  }

  @Delete('formulas/:formulaId/ingredients/:ingredientId')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Remove ingredient from formula' })
  @ApiResponse({ status: 200, description: 'Ingredient removed' })
  @ApiResponse({ status: 404, description: 'Formula or ingredient not found' })
  async removeIngredient(
    @Param('formulaId', ParseUUIDPipe) formulaId: string,
    @Param('ingredientId', ParseUUIDPipe) ingredientId: string,
  ) {
    return this.feedService.removeIngredient(formulaId, ingredientId);
  }

  // ─── Quality Control ───

  @Post('formulas/:id/quality-check')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Run quality control check against formula' })
  @ApiResponse({ status: 200, description: 'Quality check completed' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async qualityControlCheck(
    @Param('id', ParseUUIDPipe) formulaId: string,
    @Body() dto: NutrientProfileDto,
  ) {
    return this.feedService.qualityControlCheck(formulaId, dto);
  }

  // ─── Ingredient Database ───

  @Get('ingredients/available')
  @Permissions('production:view')
  @ApiOperation({ summary: 'List available ingredients from nutritional database' })
  @ApiResponse({ status: 200, description: 'Available ingredients retrieved' })
  getAvailableIngredients() {
    return this.feedService.getAvailableIngredients();
  }
}
