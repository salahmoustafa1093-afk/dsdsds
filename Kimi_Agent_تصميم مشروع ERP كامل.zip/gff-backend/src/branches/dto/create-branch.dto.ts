import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsBoolean,
  IsNumber,
  IsUUID,
  IsObject,
} from 'class-validator';

export class CreateBranchDto {
  @ApiProperty({ example: 'Amman Main Branch' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(150)
  name: string;

  @ApiProperty({ example: 'AMM-01' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(20)
  code: string;

  @ApiProperty({ example: 'King Hussein Business Park', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(250)
  address?: string;

  @ApiProperty({ example: 'Amman', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  city?: string;

  @ApiProperty({ example: '+96265551234', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  phone?: string;

  @ApiProperty({ example: 'amman@company.com', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(150)
  email?: string;

  @ApiProperty({ example: 'Ahmad Khalil', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  managerName?: string;

  @ApiProperty({ example: true, required: false })
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @ApiProperty({ example: 31.9454, required: false })
  @IsOptional()
  @IsNumber()
  latitude?: number;

  @ApiProperty({ example: 35.9284, required: false })
  @IsOptional()
  @IsNumber()
  longitude?: number;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  parentId?: string;
}

export class UpdateBranchDto {
  @ApiProperty({ example: 'Amman Main Branch', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(150)
  name?: string;

  @ApiProperty({ example: 'King Hussein Business Park', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(250)
  address?: string;

  @ApiProperty({ example: 'Amman', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  city?: string;

  @ApiProperty({ example: '+96265551234', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  phone?: string;

  @ApiProperty({ example: 'amman@company.com', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(150)
  email?: string;

  @ApiProperty({ example: 'Ahmad Khalil', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  managerName?: string;

  @ApiProperty({ example: true, required: false })
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @ApiProperty({ example: 31.9454, required: false })
  @IsOptional()
  @IsNumber()
  latitude?: number;

  @ApiProperty({ example: 35.9284, required: false })
  @IsOptional()
  @IsNumber()
  longitude?: number;
}

export class BranchTargetsDto {
  @ApiProperty({ example: { salesTarget: 100000, customerTarget: 500 } })
  @IsObject()
  targets: Record<string, any>;
}
