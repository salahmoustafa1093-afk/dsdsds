import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { BranchesService } from './branches.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import { CreateBranchDto, UpdateBranchDto, BranchTargetsDto } from './dto';

@ApiTags('Branches')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('branches')
export class BranchesController {
  constructor(private readonly branchesService: BranchesService) {}

  @Get()
  @Permissions('branches:view')
  @ApiOperation({ summary: 'List all branches' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'search', required: false, type: String })
  @ApiResponse({ status: 200, description: 'Branches retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAll(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
  ) {
    return this.branchesService.findAll(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      search,
    });
  }

  @Get('hierarchy')
  @Permissions('branches:view')
  @ApiOperation({ summary: 'Get branch hierarchy' })
  @ApiResponse({ status: 200, description: 'Hierarchy retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getHierarchy(@CurrentUser('companyId') companyId: string) {
    return this.branchesService.getHierarchy(companyId);
  }

  @Get('stats')
  @Permissions('branches:view')
  @ApiOperation({ summary: 'Get branch statistics' })
  @ApiResponse({ status: 200, description: 'Stats retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getStats(@CurrentUser('companyId') companyId: string) {
    return this.branchesService.getStats(companyId);
  }

  @Get(':id')
  @Permissions('branches:view')
  @ApiOperation({ summary: 'Get branch by ID' })
  @ApiResponse({ status: 200, description: 'Branch retrieved' })
  @ApiResponse({ status: 404, description: 'Branch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.branchesService.findOne(id, companyId);
  }

  @Post()
  @Permissions('branches:create')
  @ApiOperation({ summary: 'Create new branch' })
  @ApiResponse({ status: 201, description: 'Branch created' })
  @ApiResponse({ status: 409, description: 'Branch code already exists' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async create(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateBranchDto,
  ) {
    return this.branchesService.create(companyId, dto);
  }

  @Put(':id')
  @Permissions('branches:view')
  @ApiOperation({ summary: 'Update branch' })
  @ApiResponse({ status: 200, description: 'Branch updated' })
  @ApiResponse({ status: 404, description: 'Branch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateBranchDto,
  ) {
    return this.branchesService.update(id, companyId, dto);
  }

  @Delete(':id')
  @Permissions('branches:create')
  @ApiOperation({ summary: 'Soft delete branch' })
  @ApiResponse({ status: 200, description: 'Branch deleted' })
  @ApiResponse({ status: 404, description: 'Branch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.branchesService.remove(id, companyId);
  }

  @Get(':id/targets')
  @Permissions('branches:view')
  @ApiOperation({ summary: 'Get branch targets' })
  @ApiResponse({ status: 200, description: 'Targets retrieved' })
  @ApiResponse({ status: 404, description: 'Branch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getTargets(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.branchesService.getTargets(id, companyId);
  }

  @Put(':id/targets')
  @Permissions('branches:create')
  @ApiOperation({ summary: 'Update branch targets' })
  @ApiResponse({ status: 200, description: 'Targets updated' })
  @ApiResponse({ status: 404, description: 'Branch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateTargets(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: BranchTargetsDto,
  ) {
    return this.branchesService.updateTargets(id, companyId, dto.targets);
  }
}
