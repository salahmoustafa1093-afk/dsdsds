import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { UserStatus } from '@prisma/client';
import { PrismaService } from '@/prisma/prisma.service';
import { CreateBranchDto, UpdateBranchDto } from './dto';

@Injectable()
export class BranchesService {
  private readonly logger = new Logger(BranchesService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findAll(companyId: string, options: { page?: number; limit?: number; search?: string }) {
    const { page = 1, limit = 10, search } = options;
    const skip = (page - 1) * limit;

    const where: any = { companyId, deletedAt: null };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.branch.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          parent: { select: { id: true, name: true } },
          children: { select: { id: true, name: true } },
          _count: { select: { users: true, employees: true, warehouses: true } },
        },
      }),
      this.prisma.branch.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOne(id: string, companyId: string) {
    const branch = await this.prisma.branch.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        parent: { select: { id: true, name: true, code: true } },
        children: { select: { id: true, name: true, code: true } },
        warehouses: { select: { id: true, name: true, code: true, type: true } },
        _count: { select: { users: true, employees: true } },
      },
    });

    if (!branch) throw new NotFoundException(`Branch with ID ${id} not found`);

    return { data: branch };
  }

  async create(companyId: string, dto: CreateBranchDto) {
    const existing = await this.prisma.branch.findFirst({
      where: { code: dto.code, companyId },
    });
    if (existing) throw new ConflictException('Branch code already exists');

    const branch = await this.prisma.branch.create({
      data: { ...dto, companyId },
      include: {
        parent: { select: { id: true, name: true } },
      },
    });

    this.logger.log(`Branch created: ${branch.code} in company ${companyId}`);
    return { data: branch };
  }

  async update(id: string, companyId: string, dto: UpdateBranchDto) {
    const branch = await this.prisma.branch.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!branch) throw new NotFoundException(`Branch with ID ${id} not found`);

    const updated = await this.prisma.branch.update({
      where: { id },
      data: dto,
      include: { parent: { select: { id: true, name: true } } },
    });

    return { data: updated };
  }

  async remove(id: string, companyId: string) {
    const branch = await this.prisma.branch.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!branch) throw new NotFoundException(`Branch with ID ${id} not found`);

    await this.prisma.branch.update({
      where: { id },
      data: { deletedAt: new Date(), status: UserStatus.INACTIVE },
    });

    return { data: { message: 'Branch deleted successfully' } };
  }

  async getHierarchy(companyId: string) {
    const branches = await this.prisma.branch.findMany({
      where: { companyId, deletedAt: null },
      select: {
        id: true,
        name: true,
        code: true,
        parentId: true,
        children: { select: { id: true, name: true, code: true } },
      },
    });

    return { data: branches };
  }

  async getTargets(id: string, companyId: string) {
    const branch = await this.prisma.branch.findFirst({
      where: { id, companyId, deletedAt: null },
      select: { id: true, name: true, targetRevenue: true, actualRevenue: true },
    });
    if (!branch) throw new NotFoundException(`Branch with ID ${id} not found`);

    return { data: branch };
  }

  async updateTargets(id: string, companyId: string, targets: Record<string, any>) {
    const branch = await this.prisma.branch.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!branch) throw new NotFoundException(`Branch with ID ${id} not found`);

    const updated = await this.prisma.branch.update({
      where: { id },
      data: { targets },
    });

    return { data: updated };
  }

  async getStats(companyId: string) {
    const total = await this.prisma.branch.count({
      where: { companyId, deletedAt: null },
    });
    const active = await this.prisma.branch.count({
      where: { companyId, deletedAt: null, status: UserStatus.ACTIVE },
    });

    return { data: { total, active, inactive: total - active } };
  }
}
