import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  ParseIntPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { HrService } from './hr.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateEmployeeDto,
  UpdateEmployeeDto,
  RecordAttendanceDto,
  GeneratePayrollDto,
  UpdatePayrollStatusDto,
  CreateLeaveRequestDto,
  UpdateLeaveStatusDto,
  CreateCommissionDto,
  UpdateCommissionStatusDto,
} from './dto';

@ApiTags('HR')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('hr')
export class HrController {
  constructor(private readonly hrService: HrService) {}

  // ============================================================
  // EMPLOYEES
  // ============================================================

  @Get('employees')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'List employees' })
  @ApiResponse({ status: 200, description: 'Employees retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllEmployees(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
    @Query('department') department?: string,
    @Query('status') status?: string,
  ) {
    return this.hrService.findAllEmployees(companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
      search,
      department,
      status,
    });
  }

  @Get('employees/:id')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'Get employee by ID' })
  @ApiResponse({ status: 200, description: 'Employee retrieved' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOneEmployee(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.hrService.findOneEmployee(id, companyId);
  }

  @Post('employees')
  @Permissions('hr:create')
  @ApiOperation({ summary: 'Create employee' })
  @ApiResponse({ status: 201, description: 'Employee created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createEmployee(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateEmployeeDto,
  ) {
    return this.hrService.createEmployee(companyId, dto);
  }

  @Put('employees/:id')
  @Permissions('hr:update')
  @ApiOperation({ summary: 'Update employee' })
  @ApiResponse({ status: 200, description: 'Employee updated' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateEmployee(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateEmployeeDto,
  ) {
    return this.hrService.updateEmployee(id, companyId, dto);
  }

  @Delete('employees/:id')
  @Permissions('hr:delete')
  @ApiOperation({ summary: 'Delete employee' })
  @ApiResponse({ status: 200, description: 'Employee deleted' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async removeEmployee(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.hrService.removeEmployee(id, companyId);
  }

  // ============================================================
  // ATTENDANCE
  // ============================================================

  @Get('employees/:id/attendance')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'Get employee attendance records' })
  @ApiResponse({ status: 200, description: 'Attendance retrieved' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getAttendance(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.hrService.getAttendance(employeeId, companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
    });
  }

  @Post('employees/:id/attendance')
  @Permissions('hr:create')
  @ApiOperation({ summary: 'Record attendance' })
  @ApiResponse({ status: 201, description: 'Attendance recorded' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async recordAttendance(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: RecordAttendanceDto,
  ) {
    return this.hrService.recordAttendance(employeeId, companyId, dto);
  }

  @Get('attendance-summary')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'Get attendance summary for a month' })
  @ApiResponse({ status: 200, description: 'Attendance summary retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getAttendanceSummary(
    @CurrentUser('companyId') companyId: string,
    @Query('month', ParseIntPipe) month: number,
    @Query('year', ParseIntPipe) year: number,
  ) {
    return this.hrService.getAttendanceSummary(companyId, month, year);
  }

  // ============================================================
  // PAYROLL
  // ============================================================

  @Get('employees/:id/payrolls')
  @Permissions('hr:payroll')
  @ApiOperation({ summary: 'Get employee payroll records' })
  @ApiResponse({ status: 200, description: 'Payrolls retrieved' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getPayrolls(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.hrService.getPayrolls(employeeId, companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
    });
  }

  @Post('employees/:id/payrolls')
  @Permissions('hr:payroll')
  @ApiOperation({ summary: 'Generate payroll' })
  @ApiResponse({ status: 201, description: 'Payroll generated' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async generatePayroll(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: GeneratePayrollDto,
  ) {
    return this.hrService.generatePayroll(employeeId, companyId, dto);
  }

  @Put('payrolls/:id/status')
  @Permissions('hr:payroll')
  @ApiOperation({ summary: 'Update payroll status' })
  @ApiResponse({ status: 200, description: 'Payroll status updated' })
  @ApiResponse({ status: 404, description: 'Payroll not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updatePayrollStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdatePayrollStatusDto,
  ) {
    return this.hrService.updatePayrollStatus(id, companyId, dto.status);
  }

  @Get('payroll-summary')
  @Permissions('hr:payroll')
  @ApiOperation({ summary: 'Get payroll summary for a month' })
  @ApiResponse({ status: 200, description: 'Payroll summary retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getPayrollSummary(
    @CurrentUser('companyId') companyId: string,
    @Query('month', ParseIntPipe) month: number,
    @Query('year', ParseIntPipe) year: number,
  ) {
    return this.hrService.getPayrollSummary(companyId, month, year);
  }

  // ============================================================
  // COMMISSIONS
  // ============================================================

  @Get('employees/:id/commissions')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'Get employee commissions' })
  @ApiResponse({ status: 200, description: 'Commissions retrieved' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getCommissions(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.hrService.getCommissions(employeeId, companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
    });
  }

  @Post('employees/:id/commissions')
  @Permissions('hr:create')
  @ApiOperation({ summary: 'Create commission record' })
  @ApiResponse({ status: 201, description: 'Commission created' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createCommission(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateCommissionDto,
  ) {
    return this.hrService.createCommission(employeeId, companyId, dto);
  }

  @Put('commissions/:id/status')
  @Permissions('hr:update')
  @ApiOperation({ summary: 'Update commission status' })
  @ApiResponse({ status: 200, description: 'Commission status updated' })
  @ApiResponse({ status: 404, description: 'Commission not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateCommissionStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateCommissionStatusDto,
  ) {
    return this.hrService.updateCommissionStatus(
      id,
      companyId,
      dto.status,
      dto.approvedBy,
    );
  }

  // ============================================================
  // LEAVE REQUESTS
  // ============================================================

  @Get('employees/:id/leaves')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'Get employee leave requests' })
  @ApiResponse({ status: 200, description: 'Leave requests retrieved' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getLeaves(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.hrService.getLeaves(employeeId, companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
    });
  }

  @Post('employees/:id/leaves')
  @Permissions('hr:create')
  @ApiOperation({ summary: 'Create leave request' })
  @ApiResponse({ status: 201, description: 'Leave request created' })
  @ApiResponse({ status: 404, description: 'Employee not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createLeaveRequest(
    @Param('id', ParseUUIDPipe) employeeId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateLeaveRequestDto,
  ) {
    return this.hrService.createLeaveRequest(employeeId, companyId, dto);
  }

  @Put('leaves/:id/status')
  @Permissions('hr:update')
  @ApiOperation({ summary: 'Update leave request status' })
  @ApiResponse({ status: 200, description: 'Leave status updated' })
  @ApiResponse({ status: 404, description: 'Leave request not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateLeaveStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
    @Body() dto: UpdateLeaveStatusDto,
  ) {
    return this.hrService.updateLeaveStatus(
      id,
      companyId,
      dto.status,
      dto.approverId ?? userId,
    );
  }

  // ============================================================
  // REPORTS & DASHBOARD
  // ============================================================

  @Get('stats')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'Get HR statistics' })
  @ApiResponse({ status: 200, description: 'HR stats retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getHrStats(@CurrentUser('companyId') companyId: string) {
    return this.hrService.getHrStats(companyId);
  }

  @Get('org-chart')
  @Permissions('hr:view')
  @ApiOperation({ summary: 'Get organization chart' })
  @ApiResponse({ status: 200, description: 'Organization chart retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getOrgChart(@CurrentUser('companyId') companyId: string) {
    return this.hrService.getOrgChart(companyId);
  }
}
