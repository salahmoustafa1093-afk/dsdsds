import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
  IsUUID,
  IsEnum,
  IsDateString,
  Min,
} from 'class-validator';
import { UserStatus } from '@prisma/client';

export class CreateEmployeeDto {
  @ApiProperty({ example: 'EMP-001' })
  @IsString()
  @IsNotEmpty()
  employeeNumber: string;

  @ApiProperty({ example: 'Sales Department', required: false })
  @IsOptional()
  @IsString()
  department?: string;

  @ApiProperty({ example: 'Sales Representative', required: false })
  @IsOptional()
  @IsString()
  position?: string;

  @ApiProperty({ example: '2023-01-15', required: false })
  @IsOptional()
  @IsDateString()
  hireDate?: string;

  @ApiProperty({ example: 5000, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  salary?: number;

  @ApiProperty({ example: 500, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  housingAllowance?: number;

  @ApiProperty({ example: 300, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  transportAllowance?: number;

  @ApiProperty({ example: 200, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  foodAllowance?: number;

  @ApiProperty({ example: 'INS-123456789', required: false })
  @IsOptional()
  @IsString()
  insuranceNumber?: string;

  @ApiProperty({ example: 'ACTIVE', enum: UserStatus, required: false })
  @IsOptional()
  @IsEnum(UserStatus)
  status?: UserStatus;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  userId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  @IsNotEmpty()
  branchId: string;
}

export class UpdateEmployeeDto {
  @ApiProperty({ example: 'EMP-001', required: false })
  @IsOptional()
  @IsString()
  employeeNumber?: string;

  @ApiProperty({ example: 'Marketing Department', required: false })
  @IsOptional()
  @IsString()
  department?: string;

  @ApiProperty({ example: 'Senior Sales Rep', required: false })
  @IsOptional()
  @IsString()
  position?: string;

  @ApiProperty({ example: '2024-12-31', required: false })
  @IsOptional()
  @IsDateString()
  terminationDate?: string;

  @ApiProperty({ example: 5500, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  salary?: number;

  @ApiProperty({ example: 600, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  housingAllowance?: number;

  @ApiProperty({ example: 350, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  transportAllowance?: number;

  @ApiProperty({ example: 250, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  foodAllowance?: number;

  @ApiProperty({ example: 'INS-987654321', required: false })
  @IsOptional()
  @IsString()
  insuranceNumber?: string;

  @ApiProperty({ example: 'ACTIVE', enum: UserStatus, required: false })
  @IsOptional()
  @IsEnum(UserStatus)
  status?: UserStatus;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  userId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  branchId?: string;
}
