import { ApiProperty } from '@nestjs/swagger';
import {
  IsOptional,
  IsNotEmpty,
  IsNumber,
  IsUUID,
  IsEnum,
  Min,
  Max,
} from 'class-validator';
import { CommissionStatus } from '@prisma/client';

export class CreateCommissionDto {
  @ApiProperty({ example: 1 })
  @IsNumber()
  @IsNotEmpty()
  @Min(1)
  @Max(12)
  month: number;

  @ApiProperty({ example: 2024 })
  @IsNumber()
  @IsNotEmpty()
  year: number;

  @ApiProperty({ example: 100000 })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  targetAmount: number;

  @ApiProperty({ example: 95000 })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  achievedAmount: number;

  @ApiProperty({ example: 0.05 })
  @IsNumber()
  @IsNotEmpty()
  @Min(0)
  commissionRate: number;

  @ApiProperty({ example: 500 })
  @IsNumber()
  @IsNotEmpty()
  commissionAmount: number;

  @ApiProperty({ example: 100, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  bonusAmount?: number;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  @IsNotEmpty()
  userId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  @IsNotEmpty()
  branchId: string;
}

export class UpdateCommissionStatusDto {
  @ApiProperty({ example: 'APPROVED', enum: CommissionStatus })
  @IsEnum(CommissionStatus)
  @IsNotEmpty()
  status: CommissionStatus;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  approvedBy?: string;
}
