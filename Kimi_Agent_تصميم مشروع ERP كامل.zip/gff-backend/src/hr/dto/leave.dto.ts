import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
  IsUUID,
  IsEnum,
  IsDateString,
  Min,
} from 'class-validator';
import { LeaveType, LeaveRequestStatus } from '@prisma/client';

export class CreateLeaveRequestDto {
  @ApiProperty({ example: 'ANNUAL', enum: LeaveType })
  @IsEnum(LeaveType)
  @IsNotEmpty()
  type: LeaveType;

  @ApiProperty({ example: '2024-03-01' })
  @IsDateString()
  @IsNotEmpty()
  startDate: string;

  @ApiProperty({ example: '2024-03-05' })
  @IsDateString()
  @IsNotEmpty()
  endDate: string;

  @ApiProperty({ example: 5 })
  @IsNumber()
  @IsNotEmpty()
  @Min(1)
  days: number;

  @ApiProperty({ example: 'Family vacation', required: false })
  @IsOptional()
  @IsString()
  reason?: string;
}

export class UpdateLeaveStatusDto {
  @ApiProperty({ example: 'APPROVED', enum: LeaveRequestStatus })
  @IsEnum(LeaveRequestStatus)
  @IsNotEmpty()
  status: LeaveRequestStatus;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  approverId?: string;
}
