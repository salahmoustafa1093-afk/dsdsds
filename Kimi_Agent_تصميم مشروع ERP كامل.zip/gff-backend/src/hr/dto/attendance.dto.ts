import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
  IsDateString,
  IsEnum,
  Min,
} from 'class-validator';
import { AttendanceStatus } from '@prisma/client';

export class RecordAttendanceDto {
  @ApiProperty({ example: '2024-01-15' })
  @IsDateString()
  @IsNotEmpty()
  date: string;

  @ApiProperty({ example: '08:00:00', required: false })
  @IsOptional()
  @IsString()
  checkIn?: string;

  @ApiProperty({ example: '17:00:00', required: false })
  @IsOptional()
  @IsString()
  checkOut?: string;

  @ApiProperty({ example: 'PRESENT', enum: AttendanceStatus, required: false })
  @IsOptional()
  @IsEnum(AttendanceStatus)
  status?: AttendanceStatus;

  @ApiProperty({ example: 15, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  lateMinutes?: number;

  @ApiProperty({ example: 60, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  overtimeMinutes?: number;

  @ApiProperty({ example: 'Working on-site', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class AttendanceQueryDto {
  @ApiProperty({ example: '1', required: false })
  @IsOptional()
  page?: number;

  @ApiProperty({ example: '10', required: false })
  @IsOptional()
  limit?: number;

  @ApiProperty({ example: '2024-01', required: false })
  @IsOptional()
  @IsString()
  month?: string;
}
