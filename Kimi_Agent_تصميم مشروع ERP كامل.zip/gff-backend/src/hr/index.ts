export { HrModule } from './hr.module';
export { HrService } from './hr.service';
