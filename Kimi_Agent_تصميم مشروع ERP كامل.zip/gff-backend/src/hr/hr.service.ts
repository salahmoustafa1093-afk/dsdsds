import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import type { Prisma } from '@prisma/client';
import {
  UserStatus,
  AttendanceStatus,
  PayrollStatus,
  CommissionStatus,
  LeaveRequestStatus,
} from '@prisma/client';
import {
  CreateEmployeeDto,
  UpdateEmployeeDto,
  RecordAttendanceDto,
  GeneratePayrollDto,
  CreateLeaveRequestDto,
  CreateCommissionDto,
} from './dto';
import { startOfMonth, endOfMonth } from '@/common/utils/date.util';

interface PaginationOptions {
  page?: number;
  limit?: number;
}

interface EmployeeQueryOptions extends PaginationOptions {
  search?: string;
  department?: string;
  status?: string;
}

@Injectable()
export class HrService {
  private readonly logger = new Logger(HrService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ============================================================
  // EMPLOYEES
  // ============================================================

  async findAllEmployees(
    companyId: string,
    options: EmployeeQueryOptions,
  ) {
    const { page = 1, limit = 10, search, department, status } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.EmployeeWhereInput = {
      companyId,
      deletedAt: null,
    };

    if (department) where.department = department;
    if (status) where.status = status as UserStatus;
    if (search) {
      where.OR = [
        { employeeNumber: { contains: search, mode: 'insensitive' as Prisma.QueryMode } },
        { department: { contains: search, mode: 'insensitive' as Prisma.QueryMode } },
        { position: { contains: search, mode: 'insensitive' as Prisma.QueryMode } },
        {
          user: {
            fullName: { contains: search, mode: 'insensitive' as Prisma.QueryMode },
          },
        },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.employee.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          branch: { select: { id: true, name: true } },
          user: { select: { id: true, fullName: true, email: true } },
          _count: {
            select: {
              attendanceRecords: true,
              payrollRecords: true,
              commissionRecords: true,
              leaveRequests: true,
            },
          },
        },
      }),
      this.prisma.employee.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOneEmployee(id: string, companyId: string) {
    const employee = await this.prisma.employee.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        branch: { select: { id: true, name: true } },
        user: { select: { id: true, fullName: true, email: true, phone: true } },
        attendanceRecords: { orderBy: { date: 'desc' }, take: 10 },
        payrollRecords: { orderBy: { createdAt: 'desc' }, take: 10 },
        commissionRecords: { orderBy: { createdAt: 'desc' }, take: 10 },
        leaveRequests: { orderBy: { createdAt: 'desc' }, take: 10 },
      },
    });

    if (!employee)
      throw new NotFoundException(`Employee with ID ${id} not found`);
    return { data: employee };
  }

  async createEmployee(companyId: string, dto: CreateEmployeeDto) {
    const existing = await this.prisma.employee.findUnique({
      where: { employeeNumber: dto.employeeNumber },
    });
    if (existing)
      throw new ConflictException(
        `Employee number ${dto.employeeNumber} already exists`,
      );

    // Validate user link if provided
    if (dto.userId) {
      const user = await this.prisma.user.findFirst({
        where: { id: dto.userId, companyId, deletedAt: null },
      });
      if (!user)
        throw new BadRequestException(
          `User with ID ${dto.userId} not found in this company`,
        );

      const existingLink = await this.prisma.employee.findUnique({
        where: { userId: dto.userId },
      });
      if (existingLink)
        throw new ConflictException(
          `User ${dto.userId} is already linked to employee ${existingLink.employeeNumber}`,
        );
    }

    const data: Prisma.EmployeeCreateInput = {
      employeeNumber: dto.employeeNumber,
      department: dto.department,
      position: dto.position,
      hireDate: dto.hireDate ? new Date(dto.hireDate) : null,
      salary: dto.salary ?? 0,
      housingAllowance: dto.housingAllowance ?? 0,
      transportAllowance: dto.transportAllowance ?? 0,
      foodAllowance: dto.foodAllowance ?? 0,
      insuranceNumber: dto.insuranceNumber,
      status: dto.status ?? UserStatus.ACTIVE,
      branch: { connect: { id: dto.branchId } },
      company: { connect: { id: companyId } },
    };

    if (dto.userId) {
      data.user = { connect: { id: dto.userId } };
    }

    const employee = await this.prisma.employee.create({
      data,
      include: {
        branch: { select: { id: true, name: true } },
        user: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Employee created: ${employee.employeeNumber}`);
    return { data: employee };
  }

  async updateEmployee(
    id: string,
    companyId: string,
    dto: UpdateEmployeeDto,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!employee)
      throw new NotFoundException(`Employee with ID ${id} not found`);

    // Validate userId change
    if (dto.userId && dto.userId !== employee.userId) {
      const user = await this.prisma.user.findFirst({
        where: { id: dto.userId, companyId, deletedAt: null },
      });
      if (!user)
        throw new BadRequestException(
          `User with ID ${dto.userId} not found in this company`,
        );

      const existingLink = await this.prisma.employee.findUnique({
        where: { userId: dto.userId },
      });
      if (existingLink && existingLink.id !== id)
        throw new ConflictException(
          `User ${dto.userId} is already linked to another employee`,
        );
    }

    // Validate employeeNumber change
    if (dto.employeeNumber && dto.employeeNumber !== employee.employeeNumber) {
      const existing = await this.prisma.employee.findUnique({
        where: { employeeNumber: dto.employeeNumber },
      });
      if (existing)
        throw new ConflictException(
          `Employee number ${dto.employeeNumber} already exists`,
        );
    }

    const data: Prisma.EmployeeUpdateInput = {};

    if (dto.employeeNumber !== undefined)
      data.employeeNumber = dto.employeeNumber;
    if (dto.department !== undefined) data.department = dto.department;
    if (dto.position !== undefined) data.position = dto.position;
    if (dto.terminationDate !== undefined)
      data.terminationDate = new Date(dto.terminationDate);
    if (dto.salary !== undefined) data.salary = dto.salary;
    if (dto.housingAllowance !== undefined)
      data.housingAllowance = dto.housingAllowance;
    if (dto.transportAllowance !== undefined)
      data.transportAllowance = dto.transportAllowance;
    if (dto.foodAllowance !== undefined) data.foodAllowance = dto.foodAllowance;
    if (dto.insuranceNumber !== undefined)
      data.insuranceNumber = dto.insuranceNumber;
    if (dto.status !== undefined) data.status = dto.status;
    if (dto.userId !== undefined) {
      data.user = dto.userId
        ? { connect: { id: dto.userId } }
        : { disconnect: true };
    }
    if (dto.branchId !== undefined)
      data.branch = { connect: { id: dto.branchId } };

    const updated = await this.prisma.employee.update({
      where: { id },
      data,
      include: {
        branch: { select: { id: true, name: true } },
        user: { select: { id: true, fullName: true } },
      },
    });

    return { data: updated };
  }

  async removeEmployee(id: string, companyId: string) {
    const employee = await this.prisma.employee.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!employee)
      throw new NotFoundException(`Employee with ID ${id} not found`);

    await this.prisma.employee.update({
      where: { id },
      data: { deletedAt: new Date(), status: UserStatus.INACTIVE },
    });

    return { data: { message: 'Employee deleted successfully' } };
  }

  // ============================================================
  // ATTENDANCE
  // ============================================================

  async getAttendance(
    employeeId: string,
    companyId: string,
    options: PaginationOptions,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.AttendanceRecordWhereInput = { employeeId };

    const [data, total] = await Promise.all([
      this.prisma.attendanceRecord.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' },
      }),
      this.prisma.attendanceRecord.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async recordAttendance(
    employeeId: string,
    companyId: string,
    dto: RecordAttendanceDto,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const date = new Date(dto.date);
    const checkIn = dto.checkIn
      ? new Date(`${dto.date}T${dto.checkIn}`)
      : null;
    const checkOut = dto.checkOut
      ? new Date(`${dto.date}T${dto.checkOut}`)
      : null;

    // Calculate late minutes (assuming 09:00 is the standard start time)
    let lateMinutes = dto.lateMinutes ?? 0;
    if (checkIn && !dto.lateMinutes) {
      const standardStart = new Date(`${dto.date}T09:00:00`);
      if (checkIn > standardStart) {
        lateMinutes = Math.floor(
          (checkIn.getTime() - standardStart.getTime()) / (1000 * 60),
        );
      }
    }

    // Calculate overtime minutes
    let overtimeMinutes = dto.overtimeMinutes ?? 0;
    if (checkOut && !dto.overtimeMinutes) {
      const standardEnd = new Date(`${dto.date}T17:00:00`);
      if (checkOut > standardEnd) {
        overtimeMinutes = Math.floor(
          (checkOut.getTime() - standardEnd.getTime()) / (1000 * 60),
        );
      }
    }

    // Determine status
    const status = dto.status ?? AttendanceStatus.PRESENT;
    if (status === AttendanceStatus.PRESENT && lateMinutes > 0) {
      // Auto-mark as LATE if check-in is after standard time
    }

    // Check for existing record on same date
    const existing = await this.prisma.attendanceRecord.findFirst({
      where: { employeeId, date },
    });

    const data: Prisma.AttendanceRecordUncheckedCreateInput = {
      employeeId,
      date,
      checkIn,
      checkOut,
      status,
      lateMinutes,
      overtimeMinutes,
      notes: dto.notes,
    };

    let record;
    if (existing) {
      record = await this.prisma.attendanceRecord.update({
        where: { id: existing.id },
        data: {
          checkIn: data.checkIn,
          checkOut: data.checkOut,
          status: data.status,
          lateMinutes: data.lateMinutes,
          overtimeMinutes: data.overtimeMinutes,
          notes: data.notes,
        },
      });
    } else {
      record = await this.prisma.attendanceRecord.create({ data });
    }

    return { data: record };
  }

  // ============================================================
  // PAYROLL
  // ============================================================

  async getPayrolls(
    employeeId: string,
    companyId: string,
    options: PaginationOptions,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.PayrollRecordWhereInput = { employeeId };

    const [data, total] = await Promise.all([
      this.prisma.payrollRecord.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.payrollRecord.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async generatePayroll(
    employeeId: string,
    companyId: string,
    dto: GeneratePayrollDto,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    // Check for duplicate payroll record
    const existing = await this.prisma.payrollRecord.findFirst({
      where: { employeeId, month: dto.month, year: dto.year },
    });
    if (existing) {
      throw new ConflictException(
        `Payroll for ${dto.month}/${dto.year} already exists`,
      );
    }

    // Calculate date range for the month
    const periodStart = new Date(dto.year, dto.month - 1, 1);
    const periodEnd = endOfMonth(periodStart);

    // Calculate attendance for period
    const attendance = await this.prisma.attendanceRecord.findMany({
      where: {
        employeeId,
        date: { gte: periodStart, lte: periodEnd },
      },
    });

    // Count attendance days by status
    const presentDays = attendance.filter(
      (a) => a.status === AttendanceStatus.PRESENT,
    ).length;
    const lateDays = attendance.filter(
      (a) => a.status === AttendanceStatus.LATE,
    ).length;
    const absentDays = attendance.filter(
      (a) => a.status === AttendanceStatus.ABSENT,
    ).length;
    const leaveDays = attendance.filter(
      (a) => a.status === AttendanceStatus.LEAVE,
    ).length;
    const halfDays = attendance.filter(
      (a) => a.status === AttendanceStatus.HALF_DAY,
    ).length;

    const totalOvertimeMinutes = attendance.reduce(
      (sum, a) => sum + (a.overtimeMinutes || 0),
      0,
    );
    const totalLateMinutes = attendance.reduce(
      (sum, a) => sum + (a.lateMinutes || 0),
      0,
    );

    // Salary components
    const basicSalary = Number(employee.salary ?? 0);
    const housingAllowance = Number(employee.housingAllowance ?? 0);
    const transportAllowance = Number(employee.transportAllowance ?? 0);
    const foodAllowance = Number(employee.foodAllowance ?? 0);

    // Overtime pay: overtime minutes converted to hours, paid at 1.5x hourly rate
    const overtimeHours = totalOvertimeMinutes / 60;
    const hourlyRate = basicSalary / 30 / 8;
    const calculatedOvertime = overtimeHours * hourlyRate * 1.5;
    const overtime = dto.overtime ?? Math.round(calculatedOvertime * 100) / 100;

    const bonus = dto.bonus ?? 0;
    const deductions = dto.deductions ?? 0;
    const insurance = dto.insurance ?? 0;
    const taxRate = 0.05; // 5% flat tax
    const tax = dto.tax ?? Math.round((basicSalary + overtime + bonus) * taxRate * 100) / 100;
    const loans = dto.loans ?? 0;

    // Net salary = basic + allowances + overtime + bonus - deductions - insurance - tax - loans
    const grossEarnings =
      basicSalary + housingAllowance + transportAllowance + foodAllowance + overtime + bonus;
    const totalDeductions = deductions + insurance + tax + loans;
    const netSalary = Math.round((grossEarnings - totalDeductions) * 100) / 100;

    const payroll = await this.prisma.payrollRecord.create({
      data: {
        employeeId,
        month: dto.month,
        year: dto.year,
        basicSalary,
        housingAllowance,
        transportAllowance,
        foodAllowance,
        overtime,
        bonus,
        deductions,
        insurance,
        tax,
        loans,
        netSalary,
        status: PayrollStatus.DRAFT,
      },
    });

    return {
      data: {
        ...payroll,
        attendanceSummary: {
          presentDays,
          lateDays,
          absentDays,
          leaveDays,
          halfDays,
          totalOvertimeMinutes,
          totalLateMinutes,
        },
      },
    };
  }

  async updatePayrollStatus(
    id: string,
    companyId: string,
    status: PayrollStatus,
  ) {
    const payroll = await this.prisma.payrollRecord.findFirst({
      where: { id, employee: { companyId } },
    });
    if (!payroll) throw new NotFoundException('Payroll not found');

    const updated = await this.prisma.payrollRecord.update({
      where: { id },
      data: { status },
    });

    return { data: updated };
  }

  // ============================================================
  // COMMISSIONS
  // ============================================================

  async getCommissions(
    employeeId: string,
    companyId: string,
    options: PaginationOptions,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.CommissionRecordWhereInput = { employeeId };

    const [data, total] = await Promise.all([
      this.prisma.commissionRecord.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { id: true, fullName: true } },
          approver: { select: { id: true, fullName: true } },
        },
      }),
      this.prisma.commissionRecord.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async createCommission(
    employeeId: string,
    companyId: string,
    dto: CreateCommissionDto,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    // Validate user exists in the same company
    const user = await this.prisma.user.findFirst({
      where: { id: dto.userId, companyId, deletedAt: null },
    });
    if (!user)
      throw new BadRequestException(
        `User with ID ${dto.userId} not found in this company`,
      );

    // Validate branch exists
    const branch = await this.prisma.branch.findFirst({
      where: { id: dto.branchId, companyId },
    });
    if (!branch)
      throw new BadRequestException(
        `Branch with ID ${dto.branchId} not found in this company`,
      );

    // Calculate commission amount from rate if not provided directly
    const commissionRate = dto.commissionRate;
    const commissionAmount = dto.commissionAmount;
    const bonusAmount = dto.bonusAmount ?? 0;

    const commission = await this.prisma.commissionRecord.create({
      data: {
        employeeId,
        userId: dto.userId,
        month: dto.month,
        year: dto.year,
        targetAmount: dto.targetAmount,
        achievedAmount: dto.achievedAmount,
        commissionRate,
        commissionAmount,
        bonusAmount,
        status: CommissionStatus.PENDING,
        branchId: dto.branchId,
      },
      include: {
        user: { select: { id: true, fullName: true } },
        employee: { select: { id: true, employeeNumber: true } },
      },
    });

    return { data: commission };
  }

  async updateCommissionStatus(
    id: string,
    companyId: string,
    status: CommissionStatus,
    approvedBy?: string,
  ) {
    const commission = await this.prisma.commissionRecord.findFirst({
      where: { id, employee: { companyId } },
    });
    if (!commission) throw new NotFoundException('Commission not found');

    const data: Prisma.CommissionRecordUpdateInput = { status };
    if (status === CommissionStatus.APPROVED && approvedBy) {
      data.approver = { connect: { id: approvedBy } };
    }
    if (status === CommissionStatus.PENDING) {
      data.approver = { disconnect: true };
    }

    const updated = await this.prisma.commissionRecord.update({
      where: { id },
      data,
      include: {
        user: { select: { id: true, fullName: true } },
        approver: { select: { id: true, fullName: true } },
      },
    });

    return { data: updated };
  }

  // ============================================================
  // LEAVE REQUESTS
  // ============================================================

  async getLeaves(
    employeeId: string,
    companyId: string,
    options: PaginationOptions,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.LeaveRequestWhereInput = { employeeId };

    const [data, total] = await Promise.all([
      this.prisma.leaveRequest.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          approver: { select: { id: true, fullName: true } },
        },
      }),
      this.prisma.leaveRequest.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async createLeaveRequest(
    employeeId: string,
    companyId: string,
    dto: CreateLeaveRequestDto,
  ) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, companyId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const leave = await this.prisma.leaveRequest.create({
      data: {
        employeeId,
        type: dto.type,
        startDate: new Date(dto.startDate),
        endDate: new Date(dto.endDate),
        days: dto.days,
        reason: dto.reason,
        status: LeaveRequestStatus.PENDING,
      },
      include: {
        employee: {
          select: { id: true, employeeNumber: true },
        },
      },
    });

    return { data: leave };
  }

  async updateLeaveStatus(
    id: string,
    companyId: string,
    status: LeaveRequestStatus,
    approverId?: string,
  ) {
    const leave = await this.prisma.leaveRequest.findFirst({
      where: { id, employee: { companyId } },
    });
    if (!leave) throw new NotFoundException('Leave request not found');

    const data: Prisma.LeaveRequestUpdateInput = { status };
    if (status === LeaveRequestStatus.APPROVED && approverId) {
      data.approver = { connect: { id: approverId } };
    }
    if (status === LeaveRequestStatus.PENDING) {
      data.approver = { disconnect: true };
    }

    const updated = await this.prisma.leaveRequest.update({
      where: { id },
      data,
      include: {
        approver: { select: { id: true, fullName: true } },
        employee: { select: { id: true, employeeNumber: true } },
      },
    });

    return { data: updated };
  }

  // ============================================================
  // HR REPORTS & DASHBOARD
  // ============================================================

  async getHrStats(companyId: string) {
    const now = new Date();
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();

    const [
      totalEmployees,
      activeEmployees,
      inactiveEmployees,
      departmentBreakdown,
      positionBreakdown,
      monthlyAttendance,
      monthlyPayrolls,
      pendingLeaveRequests,
      pendingCommissionRecords,
    ] = await Promise.all([
      this.prisma.employee.count({
        where: { companyId, deletedAt: null },
      }),
      this.prisma.employee.count({
        where: { companyId, deletedAt: null, status: UserStatus.ACTIVE },
      }),
      this.prisma.employee.count({
        where: { companyId, deletedAt: null, status: UserStatus.INACTIVE },
      }),
      this.prisma.employee.groupBy({
        by: ['department'],
        where: { companyId, deletedAt: null },
        _count: { id: true },
      }),
      this.prisma.employee.groupBy({
        by: ['position'],
        where: { companyId, deletedAt: null },
        _count: { id: true },
      }),
      this.prisma.attendanceRecord.count({
        where: {
          employee: { companyId },
          date: { gte: monthStart, lte: monthEnd },
        },
      }),
      this.prisma.payrollRecord.aggregate({
        where: {
          employee: { companyId },
          month: currentMonth,
          year: currentYear,
        },
        _sum: { netSalary: true },
        _count: { id: true },
      }),
      this.prisma.leaveRequest.count({
        where: {
          employee: { companyId },
          status: LeaveRequestStatus.PENDING,
        },
      }),
      this.prisma.commissionRecord.count({
        where: {
          employee: { companyId },
          status: CommissionStatus.PENDING,
        },
      }),
    ]);

    return {
      data: {
        headcount: {
          total: totalEmployees,
          active: activeEmployees,
          inactive: inactiveEmployees,
        },
        departmentBreakdown,
        positionBreakdown,
        monthlyAttendance,
        monthlyPayrolls: {
          count: monthlyPayrolls._count.id,
          totalNetSalary: monthlyPayrolls._sum.netSalary ?? 0,
        },
        pendingActions: {
          leaveRequests: pendingLeaveRequests,
          commissions: pendingCommissionRecords,
        },
      },
    };
  }

  async getAttendanceSummary(
    companyId: string,
    month: number,
    year: number,
  ) {
    const start = new Date(year, month - 1, 1);
    const end = endOfMonth(start);

    const [statusBreakdown, topLateEmployees, totalRecords] =
      await Promise.all([
        this.prisma.attendanceRecord.groupBy({
          by: ['status'],
          where: {
            employee: { companyId },
            date: { gte: start, lte: end },
          },
          _count: { id: true },
        }),
        this.prisma.attendanceRecord.groupBy({
          by: ['employeeId'],
          where: {
            employee: { companyId },
            date: { gte: start, lte: end },
          },
          _sum: { lateMinutes: true },
          orderBy: { _sum: { lateMinutes: 'desc' } },
          take: 10,
        }),
        this.prisma.attendanceRecord.count({
          where: {
            employee: { companyId },
            date: { gte: start, lte: end },
          },
        }),
      ]);

    // Enrich late employees with employee details
    const lateEmployeeDetails = await Promise.all(
      topLateEmployees.map(async (item) => {
        const employee = await this.prisma.employee.findUnique({
          where: { id: item.employeeId },
          select: {
            employeeNumber: true,
            department: true,
            user: { select: { fullName: true } },
          },
        });
        return {
          employeeId: item.employeeId,
          employeeNumber: employee?.employeeNumber ?? '',
          fullName: employee?.user?.fullName ?? '',
          department: employee?.department ?? '',
          totalLateMinutes: item._sum.lateMinutes ?? 0,
        };
      }),
    );

    return {
      data: {
        period: { month, year },
        totalRecords,
        statusBreakdown,
        topLateEmployees: lateEmployeeDetails,
      },
    };
  }

  async getPayrollSummary(companyId: string, month: number, year: number) {
    const payrolls = await this.prisma.payrollRecord.findMany({
      where: {
        employee: { companyId },
        month,
        year,
      },
      include: {
        employee: {
          select: {
            employeeNumber: true,
            department: true,
            user: { select: { fullName: true } },
          },
        },
      },
      orderBy: { netSalary: 'desc' },
    });

    const summary = payrolls.reduce(
      (acc, p) => {
        acc.totalBasicSalary += Number(p.basicSalary);
        acc.totalHousingAllowance += Number(p.housingAllowance);
        acc.totalTransportAllowance += Number(p.transportAllowance);
        acc.totalFoodAllowance += Number(p.foodAllowance);
        acc.totalOvertime += Number(p.overtime);
        acc.totalBonus += Number(p.bonus);
        acc.totalDeductions += Number(p.deductions);
        acc.totalInsurance += Number(p.insurance);
        acc.totalTax += Number(p.tax);
        acc.totalLoans += Number(p.loans);
        acc.totalNetSalary += Number(p.netSalary);
        return acc;
      },
      {
        totalBasicSalary: 0,
        totalHousingAllowance: 0,
        totalTransportAllowance: 0,
        totalFoodAllowance: 0,
        totalOvertime: 0,
        totalBonus: 0,
        totalDeductions: 0,
        totalInsurance: 0,
        totalTax: 0,
        totalLoans: 0,
        totalNetSalary: 0,
      },
    );

    return {
      data: {
        period: { month, year },
        employeeCount: payrolls.length,
        summary,
        payrolls,
      },
    };
  }

  async getOrgChart(companyId: string) {
    const employees = await this.prisma.employee.findMany({
      where: { companyId, deletedAt: null, status: UserStatus.ACTIVE },
      select: {
        id: true,
        employeeNumber: true,
        department: true,
        position: true,
        hireDate: true,
        user: { select: { fullName: true } },
        branch: { select: { id: true, name: true } },
      },
      orderBy: [{ department: 'asc' }, { position: 'asc' }],
    });

    // Group by department
    const departments = employees.reduce<
      Record<string, typeof employees>
    >((acc, emp) => {
      const dept = emp.department ?? 'Unassigned';
      if (!acc[dept]) acc[dept] = [];
      acc[dept].push(emp);
      return acc;
    }, {});

    return {
      data: {
        totalEmployees: employees.length,
        departmentCount: Object.keys(departments).length,
        departments: Object.entries(departments).map(([name, members]) => ({
          name,
          memberCount: members.length,
          members,
        })),
      },
    };
  }
}
