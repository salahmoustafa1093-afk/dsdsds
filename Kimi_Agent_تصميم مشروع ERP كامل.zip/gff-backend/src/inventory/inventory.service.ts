import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  CreateStockMovementDto,
  CreateStockAdjustmentDto,
  CreateTransferDto,
  StockFilterDto,
  MovementFilterDto,
} from './dto';
import {
  MovementType,
  DeliveryStatus,
  InvoiceStatus,
  Prisma,
} from '@prisma/client';

interface StockLevel {
  productId: string;
  warehouseId: string;
  locationId: string | null;
  currentStock: number;
}

interface TransferWithWarehouses {
  id: string;
  transferNumber: string;
  fromWarehouseId: string;
  toWarehouseId: string;
  productId: string;
  quantity: Prisma.Decimal;
  status: DeliveryStatus;
  requestedBy: string;
  approvedBy: string | null;
  fromBranchId: string | null;
  toBranchId: string | null;
  createdAt: Date;
  completedAt: Date | null;
}

@Injectable()
export class InventoryService {
  private readonly logger = new Logger(InventoryService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════
  //  PRIVATE HELPERS
  // ═══════════════════════════════════════════

  /**
   * Compute the current stock level for a product at a warehouse (and optionally location)
   * by aggregating all stock movements.
   */
  private async computeStockLevel(
    productId: string,
    warehouseId: string,
    locationId?: string | null,
  ): Promise<number> {
    const movements = await this.prisma.stockMovement.findMany({
      where: {
        productId,
        warehouseId,
        ...(locationId ? { locationId } : {}),
      },
      select: { type: true, quantity: true },
    });

    let total = 0;
    for (const m of movements) {
      switch (m.type) {
        case MovementType.RECEIPT:
        case MovementType.RETURN:
          total += Number(m.quantity);
          break;
        case MovementType.ISSUE:
        case MovementType.WASTE:
        case MovementType.CONVERSION:
          total -= Number(m.quantity);
          break;
        case MovementType.TRANSFER:
          // TRANSFER at destination warehouse is treated as inbound
          total += Number(m.quantity);
          break;
        case MovementType.ADJUSTMENT:
          // ADJUSTMENT is now tracked via StockAdjustment model, not movements
          // But if present, treat positive as add, negative as subtract
          total += Number(m.quantity);
          break;
      }
    }
    return total;
  }

  /**
   * Compute stock levels for all products across all (filtered) warehouses.
   * Returns a map keyed by "productId:warehouseId:locationId" for fast lookup.
   */
  private async computeBulkStockLevels(
    companyId: string,
    warehouseId?: string,
    productId?: string,
  ): Promise<Map<string, StockLevel>> {
    const stockMap = new Map<string, StockLevel>();

    const movements = await this.prisma.stockMovement.findMany({
      where: {
        warehouse: { branch: { companyId } },
        ...(warehouseId ? { warehouseId } : {}),
        ...(productId ? { productId } : {}),
      },
      select: {
        productId: true,
        warehouseId: true,
        locationId: true,
        type: true,
        quantity: true,
      },
    });

    for (const m of movements) {
      const key = `${m.productId}:${m.warehouseId}:${m.locationId ?? 'null'}`;
      const existing = stockMap.get(key);
      let delta = 0;

      switch (m.type) {
        case MovementType.RECEIPT:
        case MovementType.RETURN:
          delta = Number(m.quantity);
          break;
        case MovementType.ISSUE:
        case MovementType.WASTE:
        case MovementType.CONVERSION:
          delta = -Number(m.quantity);
          break;
        case MovementType.TRANSFER:
        case MovementType.ADJUSTMENT:
          delta = Number(m.quantity);
          break;
      }

      if (existing) {
        existing.currentStock += delta;
      } else {
        stockMap.set(key, {
          productId: m.productId,
          warehouseId: m.warehouseId,
          locationId: m.locationId,
          currentStock: delta,
        });
      }
    }

    return stockMap;
  }

  /**
   * Verify a warehouse belongs to the given company by checking its branch.
   */
  private async verifyWarehouseCompany(
    warehouseId: string,
    companyId: string,
  ) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: {
        id: warehouseId,
        branch: { companyId },
      },
      include: { branch: { select: { companyId: true } } },
    });
    if (!warehouse)
      throw new NotFoundException(
        `Warehouse ${warehouseId} not found in company`,
      );
    return warehouse;
  }

  /**
   * Verify a product belongs to the given company.
   */
  private async verifyProductCompany(productId: string, companyId: string) {
    const product = await this.prisma.product.findFirst({
      where: { id: productId, companyId },
    });
    if (!product)
      throw new NotFoundException(
        `Product ${productId} not found in company`,
      );
    return product;
  }

  // ═══════════════════════════════════════════
  //  WAREHOUSE CRUD
  // ═══════════════════════════════════════════

  async createWarehouse(
    companyId: string,
    data: Prisma.WarehouseCreateInput,
  ) {
    // Verify branch belongs to company
    if (data.branch?.connect?.id) {
      const branch = await this.prisma.branch.findFirst({
        where: { id: data.branch.connect.id, companyId },
      });
      if (!branch)
        throw new NotFoundException('Branch not found in company');
    }

    const warehouse = await this.prisma.warehouse.create({
      data,
      include: {
        branch: { select: { id: true, name: true } },
        manager: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Warehouse created: ${warehouse.code} - ${warehouse.name}`);
    return { data: warehouse };
  }

  async findAllWarehouses(
    companyId: string,
    options: { page?: number; limit?: number; branchId?: string },
  ) {
    const { page = 1, limit = 10, branchId } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.WarehouseWhereInput = {
      branch: { companyId },
      deletedAt: null,
      ...(branchId ? { branchId } : {}),
    };

    const [data, total] = await Promise.all([
      this.prisma.warehouse.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          branch: { select: { id: true, name: true } },
          manager: { select: { id: true, fullName: true } },
          _count: { select: { locations: true } },
        },
      }),
      this.prisma.warehouse.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findWarehouseById(id: string, companyId: string) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: { id, branch: { companyId }, deletedAt: null },
      include: {
        branch: { select: { id: true, name: true } },
        manager: { select: { id: true, fullName: true } },
        locations: {
          where: { status: 'ACTIVE' },
          select: { id: true, zone: true, aisle: true, rack: true, shelf: true, bin: true, barcode: true },
        },
      },
    });

    if (!warehouse)
      throw new NotFoundException(`Warehouse ${id} not found`);
    return { data: warehouse };
  }

  async updateWarehouse(
    id: string,
    companyId: string,
    data: Prisma.WarehouseUpdateInput,
  ) {
    await this.findWarehouseById(id, companyId);

    const updated = await this.prisma.warehouse.update({
      where: { id },
      data,
      include: {
        branch: { select: { id: true, name: true } },
        manager: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Warehouse updated: ${id}`);
    return { data: updated };
  }

  async deleteWarehouse(id: string, companyId: string) {
    await this.findWarehouseById(id, companyId);

    const deleted = await this.prisma.warehouse.update({
      where: { id },
      data: { deletedAt: new Date(), status: 'INACTIVE' },
    });

    this.logger.log(`Warehouse soft-deleted: ${id}`);
    return { data: deleted };
  }

  // ═══════════════════════════════════════════
  //  STOCK LEVELS
  // ═══════════════════════════════════════════

  async getStock(companyId: string, filters: StockFilterDto) {
    // If warehouseId provided, verify ownership
    if (filters.warehouseId) {
      await this.verifyWarehouseCompany(filters.warehouseId, companyId);
    }
    if (filters.productId) {
      await this.verifyProductCompany(filters.productId, companyId);
    }

    // Compute all stock levels
    const stockMap = await this.computeBulkStockLevels(
      companyId,
      filters.warehouseId,
      filters.productId,
    );

    // Get product and warehouse details for the entries
    const entries = Array.from(stockMap.values());

    const productIds = [...new Set(entries.map((e) => e.productId))];
    const warehouseIds = [...new Set(entries.map((e) => e.warehouseId))];

    const [products, warehouses] = await Promise.all([
      this.prisma.product.findMany({
        where: { id: { in: productIds } },
        select: {
          id: true,
          code: true,
          name: true,
          minStockLevel: true,
          maxStockLevel: true,
          reorderPoint: true,
          unit: { select: { id: true, name: true, code: true } },
        },
      }),
      this.prisma.warehouse.findMany({
        where: { id: { in: warehouseIds } },
        select: { id: true, code: true, name: true, type: true },
      }),
    ]);

    const productMap = new Map(products.map((p) => [p.id, p]));
    const warehouseMap = new Map(warehouses.map((w) => [w.id, w]));

    const stocks = entries.map((entry) => ({
      ...entry,
      product: productMap.get(entry.productId) ?? null,
      warehouse: warehouseMap.get(entry.warehouseId) ?? null,
    }));

    // Low stock filtering
    let result = stocks;
    if (filters.lowStock) {
      result = stocks.filter((s) => {
        const minLevel = Number(s.product?.minStockLevel ?? 0);
        return s.currentStock <= minLevel && minLevel > 0;
      });
    }

    const lowStockItems = stocks.filter((s) => {
      const minLevel = Number(s.product?.minStockLevel ?? 0);
      return s.currentStock <= minLevel && minLevel > 0;
    });

    return { data: { stocks: result, lowStockItems: lowStockItems.length } };
  }

  async getStockById(productId: string, companyId: string) {
    // Verify product
    const product = await this.verifyProductCompany(productId, companyId);

    // Get stock levels for this product across all company warehouses
    const stockMap = await this.computeBulkStockLevels(companyId, undefined, productId);
    const entries = Array.from(stockMap.values());

    // Get warehouse details
    const warehouseIds = [...new Set(entries.map((e) => e.warehouseId))];
    const warehouses = await this.prisma.warehouse.findMany({
      where: { id: { in: warehouseIds } },
      select: { id: true, code: true, name: true, type: true },
    });
    const warehouseMap = new Map(warehouses.map((w) => [w.id, w]));

    // Get recent movements
    const recentMovements = await this.prisma.stockMovement.findMany({
      where: { productId },
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: {
        warehouse: { select: { id: true, name: true } },
        location: { select: { id: true, zone: true, aisle: true, rack: true, shelf: true, bin: true } },
      },
    });

    return {
      data: {
        product,
        stockByLocation: entries.map((e) => ({
          ...e,
          warehouse: warehouseMap.get(e.warehouseId) ?? null,
        })),
        recentMovements,
      },
    };
  }

  // ═══════════════════════════════════════════
  //  STOCK MOVEMENTS
  // ═══════════════════════════════════════════

  async createMovement(
    companyId: string,
    dto: CreateStockMovementDto,
    createdBy?: string,
  ) {
    // Verify warehouse and product belong to company
    const [warehouse, product] = await Promise.all([
      this.verifyWarehouseCompany(dto.warehouseId, companyId),
      this.verifyProductCompany(dto.productId, companyId),
    ]);

    // If locationId provided, verify it belongs to the warehouse
    if (dto.locationId) {
      const location = await this.prisma.warehouseLocation.findFirst({
        where: { id: dto.locationId, warehouseId: dto.warehouseId },
      });
      if (!location)
        throw new NotFoundException(
          `Location ${dto.locationId} not found in warehouse ${dto.warehouseId}`,
        );
    }

    // For ISSUE, WASTE, CONVERSION: check sufficient stock
    const outgoingTypes: MovementType[] = [
      MovementType.ISSUE,
      MovementType.WASTE,
      MovementType.CONVERSION,
    ];
    if (outgoingTypes.includes(dto.type)) {
      const currentStock = await this.computeStockLevel(
        dto.productId,
        dto.warehouseId,
        dto.locationId,
      );
      if (currentStock < dto.quantity) {
        throw new BadRequestException(
          `Insufficient stock for product ${product.name}. Available: ${currentStock}, Requested: ${dto.quantity}`,
        );
      }
    }

    // Generate movement number
    const movementNumber = `MOV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    const movement = await this.prisma.stockMovement.create({
      data: {
        movementNumber,
        type: dto.type,
        productId: dto.productId,
        warehouseId: dto.warehouseId,
        locationId: dto.locationId ?? null,
        quantity: dto.quantity,
        unitCost: dto.unitCost ?? null,
        totalCost: dto.totalCost ?? null,
        referenceType: dto.referenceType ?? null,
        referenceId: dto.referenceId ?? null,
        batchNumber: dto.batchNumber ?? null,
        expiryDate: dto.expiryDate ? new Date(dto.expiryDate) : null,
        notes: dto.notes ?? null,
        createdBy: createdBy ?? 'system',
      },
      include: {
        product: { select: { id: true, code: true, name: true } },
        warehouse: { select: { id: true, code: true, name: true } },
        location: { select: { id: true, zone: true, aisle: true, rack: true, shelf: true, bin: true } },
      },
    });

    this.logger.log(
      `Stock movement: ${dto.type} - ${dto.quantity} units of product ${product.name} at warehouse ${warehouse.name}`,
    );

    return { data: movement };
  }

  async getMovements(companyId: string, options: MovementFilterDto) {
    const page = options.page ?? 1;
    const limit = options.limit ?? 10;
    const skip = (page - 1) * limit;

    const where: Prisma.StockMovementWhereInput = {
      warehouse: { branch: { companyId } },
      ...(options.warehouseId ? { warehouseId: options.warehouseId } : {}),
      ...(options.productId ? { productId: options.productId } : {}),
      ...(options.type ? { type: options.type } : {}),
    };

    const [data, total] = await Promise.all([
      this.prisma.stockMovement.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          product: { select: { id: true, code: true, name: true } },
          warehouse: { select: { id: true, code: true, name: true } },
          location: { select: { id: true, zone: true, aisle: true, rack: true, shelf: true, bin: true } },
        },
      }),
      this.prisma.stockMovement.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  // ═══════════════════════════════════════════
  //  STOCK ADJUSTMENTS
  // ═══════════════════════════════════════════

  async createAdjustment(
    companyId: string,
    dto: CreateStockAdjustmentDto,
    createdBy?: string,
  ) {
    // Verify warehouse and product
    await Promise.all([
      this.verifyWarehouseCompany(dto.warehouseId, companyId),
      this.verifyProductCompany(dto.productId, companyId),
    ]);

    const variance = dto.actualQty - dto.expectedQty;

    const adjustment = await this.prisma.stockAdjustment.create({
      data: {
        productId: dto.productId,
        warehouseId: dto.warehouseId,
        expectedQty: dto.expectedQty,
        actualQty: dto.actualQty,
        variance,
        reason: dto.reason ?? null,
        status: InvoiceStatus.DRAFT,
        approvedBy: null,
      },
      include: {
        product: { select: { id: true, code: true, name: true } },
        warehouse: { select: { id: true, code: true, name: true } },
      },
    });

    this.logger.log(
      `Stock adjustment created: product ${dto.productId}, expected ${dto.expectedQty}, actual ${dto.actualQty}, variance ${variance}`,
    );

    return { data: adjustment };
  }

  async approveAdjustment(
    id: string,
    companyId: string,
    approvedBy: string,
  ) {
    const adjustment = await this.prisma.stockAdjustment.findFirst({
      where: {
        id,
        warehouse: { branch: { companyId } },
      },
      include: {
        product: { select: { id: true, code: true, name: true } },
        warehouse: { select: { id: true, code: true, name: true } },
      },
    });

    if (!adjustment)
      throw new NotFoundException(`Stock adjustment ${id} not found`);
    if (adjustment.status !== InvoiceStatus.DRAFT) {
      throw new BadRequestException(
        `Adjustment already ${adjustment.status.toLowerCase()}`,
      );
    }

    const movementNumber = `MOV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    // Approve and create a movement record
    const [updated] = await this.prisma.$transaction([
      this.prisma.stockAdjustment.update({
        where: { id },
        data: { status: InvoiceStatus.CONFIRMED, approvedBy },
        include: {
          product: { select: { id: true, code: true, name: true } },
          warehouse: { select: { id: true, code: true, name: true } },
        },
      }),
      this.prisma.stockMovement.create({
        data: {
          movementNumber,
          type: MovementType.ADJUSTMENT,
          productId: adjustment.productId,
          warehouseId: adjustment.warehouseId,
          quantity: Math.abs(Number(adjustment.variance)),
          referenceType: 'STOCK_ADJUSTMENT',
          referenceId: adjustment.id,
          notes: adjustment.reason ?? `Stock adjustment: variance ${adjustment.variance}`,
          createdBy: approvedBy,
        },
      }),
    ]);

    this.logger.log(`Stock adjustment ${id} approved by ${approvedBy}`);
    return { data: updated };
  }

  async findAllAdjustments(
    companyId: string,
    options: { page?: number; limit?: number; status?: InvoiceStatus },
  ) {
    const { page = 1, limit = 10, status } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.StockAdjustmentWhereInput = {
      warehouse: { branch: { companyId } },
      ...(status ? { status } : {}),
    };

    const [data, total] = await Promise.all([
      this.prisma.stockAdjustment.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          product: { select: { id: true, code: true, name: true } },
          warehouse: { select: { id: true, code: true, name: true } },
          approver: { select: { id: true, fullName: true } },
        },
      }),
      this.prisma.stockAdjustment.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  // ═══════════════════════════════════════════
  //  STOCK TRANSFERS
  // ═══════════════════════════════════════════

  async createTransfer(
    companyId: string,
    dto: CreateTransferDto,
    requestedBy?: string,
  ) {
    // Verify both warehouses belong to company
    const [fromWarehouse, toWarehouse] = await Promise.all([
      this.verifyWarehouseCompany(dto.fromWarehouseId, companyId),
      this.verifyWarehouseCompany(dto.toWarehouseId, companyId),
    ]);

    // Verify product
    const product = await this.verifyProductCompany(dto.productId, companyId);

    // Check stock availability at source
    const sourceStock = await this.computeStockLevel(
      dto.productId,
      dto.fromWarehouseId,
    );
    if (sourceStock < dto.quantity) {
      throw new BadRequestException(
        `Insufficient stock for product ${product.name} at source warehouse. Available: ${sourceStock}, Requested: ${dto.quantity}`,
      );
    }

    const transferNumber = `TRF-${Date.now().toString(36).toUpperCase()}`;

    const transfer = await this.prisma.stockTransfer.create({
      data: {
        transferNumber,
        fromWarehouseId: dto.fromWarehouseId,
        toWarehouseId: dto.toWarehouseId,
        productId: dto.productId,
        quantity: dto.quantity,
        status: DeliveryStatus.PENDING,
        requestedBy: requestedBy ?? 'system',
        fromBranchId: dto.fromBranchId ?? fromWarehouse.branchId ?? null,
        toBranchId: dto.toBranchId ?? toWarehouse.branchId ?? null,
      },
      include: {
        fromWarehouse: { select: { id: true, code: true, name: true } },
        toWarehouse: { select: { id: true, code: true, name: true } },
        product: { select: { id: true, code: true, name: true } },
        requester: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(
      `Transfer ${transferNumber} created: ${dto.quantity} units of ${product.name} from ${fromWarehouse.name} to ${toWarehouse.name}`,
    );

    return { data: transfer };
  }

  async findAllTransfers(
    companyId: string,
    options: { page?: number; limit?: number; status?: DeliveryStatus },
  ) {
    const { page = 1, limit = 10, status } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.StockTransferWhereInput = {
      OR: [
        { fromWarehouse: { branch: { companyId } } },
        { toWarehouse: { branch: { companyId } } },
      ],
      ...(status ? { status } : {}),
    };

    const [data, total] = await Promise.all([
      this.prisma.stockTransfer.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          fromWarehouse: { select: { id: true, code: true, name: true } },
          toWarehouse: { select: { id: true, code: true, name: true } },
          product: { select: { id: true, code: true, name: true } },
          requester: { select: { id: true, fullName: true } },
          approver: { select: { id: true, fullName: true } },
        },
      }),
      this.prisma.stockTransfer.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async updateTransferStatus(
    id: string,
    companyId: string,
    status: DeliveryStatus,
    userId?: string,
  ) {
    const transfer = (await this.prisma.stockTransfer.findFirst({
      where: {
        id,
        OR: [
          { fromWarehouse: { branch: { companyId } } },
          { toWarehouse: { branch: { companyId } } },
        ],
      },
      include: {
        fromWarehouse: { select: { id: true, name: true, branchId: true } },
        toWarehouse: { select: { id: true, name: true, branchId: true } },
        product: { select: { id: true, code: true, name: true } },
      },
    })) as (TransferWithWarehouses & {
      fromWarehouse: { id: string; name: string; branchId: string };
      toWarehouse: { id: string; name: string; branchId: string };
      product: { id: string; code: true; name: string };
    }) | null;

    if (!transfer) throw new NotFoundException('Transfer not found');

    const statusFlow: Record<DeliveryStatus, DeliveryStatus[]> = {
      [DeliveryStatus.PENDING]: [DeliveryStatus.CONFIRMED, DeliveryStatus.CANCELLED],
      [DeliveryStatus.CONFIRMED]: [DeliveryStatus.APPROVED, DeliveryStatus.CANCELLED],
      [DeliveryStatus.APPROVED]: [DeliveryStatus.PICKING, DeliveryStatus.CANCELLED],
      [DeliveryStatus.PICKING]: [DeliveryStatus.PICKED_LOADED],
      [DeliveryStatus.PICKED_LOADED]: [DeliveryStatus.DRIVER_ASSIGNED],
      [DeliveryStatus.DRIVER_ASSIGNED]: [DeliveryStatus.IN_TRANSIT],
      [DeliveryStatus.IN_TRANSIT]: [DeliveryStatus.AT_CUSTOMER, DeliveryStatus.FAILED_CLOSED],
      [DeliveryStatus.AT_CUSTOMER]: [DeliveryStatus.DELIVERED],
      [DeliveryStatus.DELIVERED]: [DeliveryStatus.PAYMENT_COLLECTED, DeliveryStatus.CLOSED],
      [DeliveryStatus.PAYMENT_COLLECTED]: [DeliveryStatus.CLOSED],
      [DeliveryStatus.CLOSED]: [],
      [DeliveryStatus.FAILED_CLOSED]: [],
    };

    const allowedNext = statusFlow[transfer.status] ?? [];
    if (!allowedNext.includes(status) && transfer.status !== status) {
      throw new BadRequestException(
        `Invalid status transition from ${transfer.status} to ${status}`,
      );
    }

    // When transitioning to IN_TRANSIT: deduct from source warehouse
    if (status === DeliveryStatus.IN_TRANSIT && transfer.status !== DeliveryStatus.IN_TRANSIT) {
      const sourceStock = await this.computeStockLevel(
        transfer.productId,
        transfer.fromWarehouseId,
      );
      if (sourceStock < Number(transfer.quantity)) {
        throw new BadRequestException(
          `Insufficient stock at source warehouse. Available: ${sourceStock}, Required: ${transfer.quantity}`,
        );
      }

      const movementNumber = `MOV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      await this.prisma.stockMovement.create({
        data: {
          movementNumber,
          type: MovementType.TRANSFER,
          productId: transfer.productId,
          warehouseId: transfer.fromWarehouseId,
          quantity: Number(transfer.quantity),
          referenceType: 'STOCK_TRANSFER',
          referenceId: transfer.id,
          notes: `Transfer out to warehouse ${transfer.toWarehouse.name}`,
          createdBy: userId ?? 'system',
        },
      });
    }

    // When transitioning to DELIVERED or CLOSED: add to destination warehouse
    if (
      (status === DeliveryStatus.DELIVERED || status === DeliveryStatus.CLOSED) &&
      transfer.status !== DeliveryStatus.DELIVERED &&
      transfer.status !== DeliveryStatus.CLOSED
    ) {
      const movementNumber = `MOV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      await this.prisma.stockMovement.create({
        data: {
          movementNumber,
          type: MovementType.TRANSFER,
          productId: transfer.productId,
          warehouseId: transfer.toWarehouseId,
          quantity: Number(transfer.quantity),
          referenceType: 'STOCK_TRANSFER',
          referenceId: transfer.id,
          notes: `Transfer in from warehouse ${transfer.fromWarehouse.name}`,
          createdBy: userId ?? 'system',
        },
      });
    }

    const updated = await this.prisma.stockTransfer.update({
      where: { id },
      data: {
        status,
        completedAt:
          status === DeliveryStatus.DELIVERED || status === DeliveryStatus.CLOSED
            ? new Date()
            : transfer.completedAt,
      },
      include: {
        fromWarehouse: { select: { id: true, code: true, name: true } },
        toWarehouse: { select: { id: true, code: true, name: true } },
        product: { select: { id: true, code: true, name: true } },
        requester: { select: { id: true, fullName: true } },
        approver: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Transfer ${id} status updated to ${status}`);
    return { data: updated };
  }

  // ═══════════════════════════════════════════
  //  LOW STOCK ALERTS
  // ═══════════════════════════════════════════

  async getLowStock(companyId: string) {
    // Get all products for the company
    const products = await this.prisma.product.findMany({
      where: { companyId, status: 'ACTIVE' },
      select: {
        id: true,
        code: true,
        name: true,
        minStockLevel: true,
        maxStockLevel: true,
        reorderPoint: true,
        unit: { select: { id: true, name: true, code: true } },
      },
    });

    // Get stock levels for all products
    const stockMap = await this.computeBulkStockLevels(companyId);

    // Get warehouse details
    const warehouseIds = [
      ...new Set(Array.from(stockMap.values()).map((e) => e.warehouseId)),
    ];
    const warehouses = await this.prisma.warehouse.findMany({
      where: { id: { in: warehouseIds } },
      select: { id: true, code: true, name: true },
    });
    const warehouseMap = new Map(warehouses.map((w) => [w.id, w]));

    // Filter to only low-stock items
    const lowStockItems = [];
    for (const product of products) {
      const minLevel = Number(product.minStockLevel ?? 0);
      if (minLevel <= 0) continue;

      // Find all warehouse entries for this product
      const entries = Array.from(stockMap.values()).filter(
        (e) => e.productId === product.id,
      );

      if (entries.length === 0) {
        // Product has no stock at all — definitely low stock
        lowStockItems.push({
          product,
          currentStock: 0,
          minStockLevel: minLevel,
          warehouse: null,
          locationId: null,
        });
        continue;
      }

      for (const entry of entries) {
        if (entry.currentStock <= minLevel) {
          lowStockItems.push({
            product,
            currentStock: entry.currentStock,
            minStockLevel: minLevel,
            warehouse: warehouseMap.get(entry.warehouseId) ?? null,
            locationId: entry.locationId,
          });
        }
      }
    }

    return { data: lowStockItems };
  }

  // ═══════════════════════════════════════════
  //  STOCK AUDIT
  // ═══════════════════════════════════════════

  async createAudit(
    companyId: string,
    warehouseId: string,
    notes?: string,
  ) {
    const warehouse = await this.verifyWarehouseCompany(
      warehouseId,
      companyId,
    );

    // Get all products that have movements in this warehouse
    const stockMap = await this.computeBulkStockLevels(
      companyId,
      warehouseId,
    );
    const entries = Array.from(stockMap.values());

    // Get product details
    const productIds = [...new Set(entries.map((e) => e.productId))];
    const products = await this.prisma.product.findMany({
      where: { id: { in: productIds } },
      select: {
        id: true,
        code: true,
        name: true,
        minStockLevel: true,
        maxStockLevel: true,
        unit: { select: { name: true, code: true } },
      },
    });
    const productMap = new Map(products.map((p) => [p.id, p]));

    const auditItems = entries.map((entry) => ({
      ...entry,
      product: productMap.get(entry.productId) ?? null,
    }));

    const totalItems = auditItems.length;
    const totalQuantity = auditItems.reduce((sum, s) => sum + s.currentStock, 0);

    this.logger.log(
      `Audit created for warehouse ${warehouse.name} — ${totalItems} items, ${totalQuantity} total quantity`,
    );

    return {
      data: {
        warehouseId,
        warehouseName: warehouse.name,
        auditDate: new Date(),
        totalItems,
        totalQuantity,
        items: auditItems,
        notes,
      },
    };
  }

  // ═══════════════════════════════════════════
  //  INVENTORY REPORTS
  // ═══════════════════════════════════════════

  async getMovementHistory(
    companyId: string,
    options: {
      page?: number;
      limit?: number;
      productId?: string;
      warehouseId?: string;
      startDate?: string;
      endDate?: string;
    },
  ) {
    const { page = 1, limit = 10, productId, warehouseId, startDate, endDate } =
      options;
    const skip = (page - 1) * limit;

    const dateFilter: Prisma.DateTimeFilter = {};
    if (startDate) dateFilter.gte = new Date(startDate);
    if (endDate) dateFilter.lte = new Date(endDate);

    const where: Prisma.StockMovementWhereInput = {
      warehouse: { branch: { companyId } },
      ...(productId ? { productId } : {}),
      ...(warehouseId ? { warehouseId } : {}),
      ...(startDate || endDate ? { createdAt: dateFilter } : {}),
    };

    const [data, total] = await Promise.all([
      this.prisma.stockMovement.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          product: { select: { id: true, code: true, name: true } },
          warehouse: { select: { id: true, code: true, name: true } },
          location: { select: { id: true, zone: true, aisle: true, rack: true, shelf: true, bin: true } },
        },
      }),
      this.prisma.stockMovement.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async getStockSummary(companyId: string) {
    // Compute all stock levels
    const stockMap = await this.computeBulkStockLevels(companyId);
    const entries = Array.from(stockMap.values());

    // Get product details
    const productIds = [...new Set(entries.map((e) => e.productId))];
    const products = await this.prisma.product.findMany({
      where: { id: { in: productIds } },
      select: {
        id: true,
        code: true,
        name: true,
        minStockLevel: true,
        maxStockLevel: true,
        reorderPoint: true,
        unit: { select: { name: true, code: true } },
      },
    });
    const productMap = new Map(products.map((p) => [p.id, p]));

    // Summaries
    const totalProducts = productIds.length;
    const totalQuantity = entries.reduce((sum, e) => sum + e.currentStock, 0);
    const lowStockCount = entries.filter((e) => {
      const p = productMap.get(e.productId);
      if (!p) return false;
      const minLevel = Number(p.minStockLevel ?? 0);
      return minLevel > 0 && e.currentStock <= minLevel;
    }).length;

    return {
      data: {
        totalProducts,
        totalQuantity,
        lowStockCount,
        stockByProduct: entries.map((e) => ({
          productId: e.productId,
          warehouseId: e.warehouseId,
          currentStock: e.currentStock,
          product: productMap.get(e.productId) ?? null,
        })),
      },
    };
  }
}
