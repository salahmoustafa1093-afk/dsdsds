import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
  IsUUID,
  IsEnum,
  IsDateString,
} from 'class-validator';
import { MovementType, DeliveryStatus } from '@prisma/client';

// ─── Create Stock Movement ───

export class CreateStockMovementDto {
  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  productId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001' })
  @IsUUID()
  warehouseId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440002', required: false })
  @IsOptional()
  @IsUUID()
  locationId?: string;

  @ApiProperty({ example: 'RECEIPT', enum: MovementType })
  @IsEnum(MovementType)
  type: MovementType;

  @ApiProperty({ example: 100 })
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: 10.5, required: false })
  @IsOptional()
  @IsNumber()
  unitCost?: number;

  @ApiProperty({ example: 1050.0, required: false })
  @IsOptional()
  @IsNumber()
  totalCost?: number;

  @ApiProperty({ example: 'PURCHASE_ORDER', required: false })
  @IsOptional()
  @IsString()
  referenceType?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440003', required: false })
  @IsOptional()
  @IsUUID()
  referenceId?: string;

  @ApiProperty({ example: 'BATCH-001', required: false })
  @IsOptional()
  @IsString()
  batchNumber?: string;

  @ApiProperty({ example: '2025-12-31', required: false })
  @IsOptional()
  @IsDateString()
  expiryDate?: string;

  @ApiProperty({ example: 'Initial stock entry', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}

// ─── Stock Adjustment ───

export class CreateStockAdjustmentDto {
  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  productId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001' })
  @IsUUID()
  warehouseId: string;

  @ApiProperty({ example: 150 })
  @IsNumber()
  expectedQty: number;

  @ApiProperty({ example: 148 })
  @IsNumber()
  actualQty: number;

  @ApiProperty({ example: 'Physical count variance', required: false })
  @IsOptional()
  @IsString()
  reason?: string;
}

export class ApproveStockAdjustmentDto {
  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  @IsNotEmpty()
  approvedBy: string;
}

// ─── Stock Transfer ───

export class CreateTransferDto {
  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001' })
  @IsUUID()
  fromWarehouseId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440002' })
  @IsUUID()
  toWarehouseId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  productId: string;

  @ApiProperty({ example: 50 })
  @IsNumber()
  quantity: number;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440003', required: false })
  @IsOptional()
  @IsUUID()
  fromBranchId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440004', required: false })
  @IsOptional()
  @IsUUID()
  toBranchId?: string;
}

export class UpdateTransferStatusDto {
  @ApiProperty({ example: 'CONFIRMED', enum: DeliveryStatus })
  @IsEnum(DeliveryStatus)
  @IsNotEmpty()
  status: DeliveryStatus;
}

// ─── Stock Audit ───

export class StockAuditDto {
  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001' })
  @IsUUID()
  warehouseId: string;

  @ApiProperty({ example: 'Annual stock audit 2024', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}

// ─── Filters ───

export class StockFilterDto {
  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  productId?: string;

  @ApiProperty({ example: true, required: false })
  @IsOptional()
  lowStock?: boolean;
}

export class MovementFilterDto {
  @ApiProperty({ example: 1, required: false })
  @IsOptional()
  page?: number;

  @ApiProperty({ example: 10, required: false })
  @IsOptional()
  limit?: number;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  productId?: string;

  @ApiProperty({ example: 'RECEIPT', required: false, enum: MovementType })
  @IsOptional()
  @IsEnum(MovementType)
  type?: MovementType;
}
