import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
  IsUUID,
  IsEnum,
} from 'class-validator';
import { WarehouseType, UserStatus } from '@prisma/client';

export class CreateWarehouseDto {
  @ApiProperty({ example: 'WH-001' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ example: 'Main Warehouse' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'MAIN', enum: WarehouseType, required: false })
  @IsOptional()
  @IsEnum(WarehouseType)
  type?: WarehouseType;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  branchId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  managerId?: string;

  @ApiProperty({ example: '1000.50', required: false })
  @IsOptional()
  @IsNumber()
  capacity?: number;

  @ApiProperty({ example: '123 Industrial Zone, Cairo', required: false })
  @IsOptional()
  @IsString()
  address?: string;
}

export class UpdateWarehouseDto {
  @ApiProperty({ example: 'Updated Warehouse Name', required: false })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiProperty({ example: 'MAIN', enum: WarehouseType, required: false })
  @IsOptional()
  @IsEnum(WarehouseType)
  type?: WarehouseType;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  managerId?: string;

  @ApiProperty({ example: '2000.00', required: false })
  @IsOptional()
  @IsNumber()
  capacity?: number;

  @ApiProperty({ example: '456 New Address, Giza', required: false })
  @IsOptional()
  @IsString()
  address?: string;

  @ApiProperty({ example: 'ACTIVE', enum: UserStatus, required: false })
  @IsOptional()
  @IsEnum(UserStatus)
  status?: UserStatus;
}
