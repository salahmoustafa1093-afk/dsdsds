import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { InventoryService } from './inventory.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateStockMovementDto,
  CreateStockAdjustmentDto,
  CreateTransferDto,
  UpdateTransferStatusDto,
  StockFilterDto,
  StockAuditDto,
  MovementFilterDto,
  CreateWarehouseDto,
  UpdateWarehouseDto,
} from './dto';

@ApiTags('Inventory')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('inventory')
export class InventoryController {
  constructor(private readonly inventoryService: InventoryService) {}

  // ========== STOCK ==========
  @Get('stock')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get stock with filters' })
  @ApiResponse({ status: 200, description: 'Stock retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getStock(
    @CurrentUser('companyId') companyId: string,
    @Query() filters: StockFilterDto,
  ) {
    return this.inventoryService.getStock(companyId, filters);
  }

  @Get('stock/:id')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get stock levels for a product by product ID' })
  @ApiResponse({ status: 200, description: 'Stock retrieved' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getStockById(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.inventoryService.getStockById(id, companyId);
  }

  // ========== MOVEMENTS ==========
  @Get('movements')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List stock movements' })
  @ApiResponse({ status: 200, description: 'Movements retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getMovements(
    @CurrentUser('companyId') companyId: string,
    @Query() filters: MovementFilterDto,
  ) {
    return this.inventoryService.getMovements(companyId, filters);
  }

  @Post('movements')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create stock movement' })
  @ApiResponse({ status: 201, description: 'Movement recorded' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createMovement(
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
    @Body() dto: CreateStockMovementDto,
  ) {
    return this.inventoryService.createMovement(companyId, dto, userId);
  }

  // ========== ADJUSTMENTS ==========
  @Post('adjustments')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Create stock adjustment' })
  @ApiResponse({ status: 201, description: 'Stock adjustment created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createAdjustment(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateStockAdjustmentDto,
  ) {
    return this.inventoryService.createAdjustment(companyId, dto);
  }

  @Post('adjustments/:id/approve')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Approve stock adjustment' })
  @ApiResponse({ status: 200, description: 'Adjustment approved' })
  @ApiResponse({ status: 404, description: 'Adjustment not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async approveAdjustment(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
  ) {
    return this.inventoryService.approveAdjustment(id, companyId, userId);
  }

  @Get('adjustments')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List stock adjustments' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiResponse({ status: 200, description: 'Adjustments retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllAdjustments(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
  ) {
    return this.inventoryService.findAllAdjustments(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      status: status as never,
    });
  }

  // ========== TRANSFERS ==========
  @Get('transfers')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List stock transfers' })
  @ApiResponse({ status: 200, description: 'Transfers retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllTransfers(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
  ) {
    return this.inventoryService.findAllTransfers(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      status: status as never,
    });
  }

  @Post('transfers')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create stock transfer' })
  @ApiResponse({ status: 201, description: 'Transfer created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createTransfer(
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
    @Body() dto: CreateTransferDto,
  ) {
    return this.inventoryService.createTransfer(companyId, dto, userId);
  }

  @Put('transfers/:id/status')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update transfer status' })
  @ApiResponse({ status: 200, description: 'Transfer status updated' })
  @ApiResponse({ status: 404, description: 'Transfer not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateTransferStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
    @Body() dto: UpdateTransferStatusDto,
  ) {
    return this.inventoryService.updateTransferStatus(
      id,
      companyId,
      dto.status,
      userId,
    );
  }

  // ========== LOW STOCK ==========
  @Get('alerts/low-stock')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get low stock alerts' })
  @ApiResponse({ status: 200, description: 'Low stock alerts retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getLowStock(@CurrentUser('companyId') companyId: string) {
    return this.inventoryService.getLowStock(companyId);
  }

  // ========== AUDIT ==========
  @Post('audits')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create stock audit' })
  @ApiResponse({ status: 201, description: 'Audit created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createAudit(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: StockAuditDto,
  ) {
    return this.inventoryService.createAudit(
      companyId,
      dto.warehouseId,
      dto.notes,
    );
  }

  // ========== REPORTS ==========
  @Get('reports/movement-history')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get movement history report' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'productId', required: false })
  @ApiQuery({ name: 'warehouseId', required: false })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiResponse({ status: 200, description: 'Report retrieved' })
  async getMovementHistory(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('productId') productId?: string,
    @Query('warehouseId') warehouseId?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    return this.inventoryService.getMovementHistory(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      productId,
      warehouseId,
      startDate,
      endDate,
    });
  }

  @Get('reports/stock-summary')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get stock summary report' })
  @ApiResponse({ status: 200, description: 'Stock summary retrieved' })
  async getStockSummary(
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.inventoryService.getStockSummary(companyId);
  }

  // ========== WAREHOUSE CRUD ==========
  @Post('warehouses')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create warehouse' })
  @ApiResponse({ status: 201, description: 'Warehouse created' })
  async createWarehouse(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateWarehouseDto,
  ) {
    return this.inventoryService.createWarehouse(companyId, {
      code: dto.code,
      name: dto.name,
      branch: { connect: { id: dto.branchId } },
      type: dto.type,
      capacity: dto.capacity,
      address: dto.address,
      manager: dto.managerId ? { connect: { id: dto.managerId } } : undefined,
    });
  }

  @Get('warehouses')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List warehouses' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'branchId', required: false })
  @ApiResponse({ status: 200, description: 'Warehouses retrieved' })
  async findAllWarehouses(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('branchId') branchId?: string,
  ) {
    return this.inventoryService.findAllWarehouses(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      branchId,
    });
  }

  @Get('warehouses/:id')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get warehouse by ID' })
  @ApiResponse({ status: 200, description: 'Warehouse retrieved' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  async findWarehouseById(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.inventoryService.findWarehouseById(id, companyId);
  }

  @Put('warehouses/:id')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update warehouse' })
  @ApiResponse({ status: 200, description: 'Warehouse updated' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  async updateWarehouse(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateWarehouseDto,
  ) {
    return this.inventoryService.updateWarehouse(id, companyId, {
      name: dto.name,
      capacity: dto.capacity,
      address: dto.address,
      manager: dto.managerId ? { connect: { id: dto.managerId } } : undefined,
      status: dto.status,
    });
  }

  @Put('warehouses/:id/delete')
  @Permissions('inventory:delete')
  @ApiOperation({ summary: 'Soft-delete warehouse' })
  @ApiResponse({ status: 200, description: 'Warehouse deleted' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  async deleteWarehouse(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.inventoryService.deleteWarehouse(id, companyId);
  }
}
