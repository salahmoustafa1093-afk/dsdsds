import { Injectable, Logger } from '@nestjs/common';
import { RedisService } from '../redis/redis.service';

export interface CacheTagSet {
  /** Tags associated with cached keys */
  tags: string[];
  /** The cache key */
  key: string;
}

/**
 * Cache Service
 *
 * High-level caching layer built on Redis with features:
 * - Standard get/set/del with TTL
 * - Pattern-based deletion (wildcard key removal)
 * - remember(): Cache-aside pattern (get or compute)
 * - Cache tagging: Tag keys for bulk invalidation
 * - Module invalidation: Invalidate all cache for a module
 *
 * Key naming convention: gff:{module}:{resource}:{identifier}
 * Tag convention: tag:{tagName}
 */
@Injectable()
export class CacheService {
  private readonly logger = new Logger(CacheService.name);
  private readonly defaultTtl: number;
  private readonly keyPrefix: string;
  private readonly tagPrefix: string;

  constructor(private readonly redis: RedisService) {
    this.defaultTtl = parseInt(process.env.CACHE_DEFAULT_TTL || '300', 10); // 5 minutes
    this.keyPrefix = process.env.CACHE_KEY_PREFIX || 'cache';
    this.tagPrefix = 'tag';
  }

  /**
   * Build a fully-qualified cache key.
   * Format: {prefix}:{module}:{resource}:{key}
   */
  buildKey(module: string, resource: string, key: string): string {
    return `${this.keyPrefix}:${module}:${resource}:${key}`;
  }

  /**
   * Get a value from cache.
   * Returns null if key doesn't exist or has expired.
   */
  async get<T = unknown>(key: string): Promise<T | null> {
    try {
      const value = await this.redis.get<T>(key);
      if (value !== null) {
        this.logger.debug(`CACHE HIT: ${key}`);
      } else {
        this.logger.debug(`CACHE MISS: ${key}`);
      }
      return value;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`Cache GET error for ${key}: ${message}`);
      return null;
    }
  }

  /**
   * Store a value in cache with optional TTL.
   * TTL is in seconds. If not provided, uses default TTL.
   */
  async set<T = unknown>(
    key: string,
    value: T,
    ttlSeconds?: number,
  ): Promise<void> {
    const effectiveTtl = ttlSeconds ?? this.defaultTtl;
    try {
      await this.redis.set(key, value, effectiveTtl);
      this.logger.debug(`CACHE SET: ${key} (TTL: ${effectiveTtl}s)`);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`Cache SET error for ${key}: ${message}`);
    }
  }

  /**
   * Delete a specific key from cache.
   */
  async del(key: string): Promise<void> {
    try {
      await this.redis.del(key);
      this.logger.debug(`CACHE DEL: ${key}`);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`Cache DEL error for ${key}: ${message}`);
    }
  }

  /**
   * Delete all keys matching a pattern.
   * WARNING: Uses SCAN in production to avoid blocking Redis.
   */
  async delPattern(pattern: string): Promise<number> {
    let deleted = 0;
    let cursor = '0';

    try {
      do {
        const result = await this.redis.scan(pattern, 100);
        cursor = result.cursor;

        if (result.keys.length > 0) {
          await this.redis.del(result.keys);
          deleted += result.keys.length;
        }
      } while (cursor !== '0');

      this.logger.log(`CACHE DELPATTERN: ${pattern} — ${deleted} keys deleted`);
      return deleted;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`Cache DELPATTERN error for ${pattern}: ${message}`);
      return deleted;
    }
  }

  /**
   * Cache-aside pattern: Get from cache, or execute callback and cache result.
   *
   * @param key      — Cache key
   * @param ttl      — TTL in seconds (optional)
   * @param callback — Function to compute value if not in cache
   * @returns Cached or computed value
   */
  async remember<T = unknown>(
    key: string,
    ttl: number | (() => Promise<T>),
    callback?: () => Promise<T>,
  ): Promise<T | null> {
    // Handle overload: remember(key, callback) or remember(key, ttl, callback)
    let ttlSeconds: number;
    let fn: () => Promise<T>;

    if (typeof ttl === 'function') {
      ttlSeconds = this.defaultTtl;
      fn = ttl;
    } else {
      ttlSeconds = ttl;
      fn = callback!;
    }

    // Try cache first
    const cached = await this.get<T>(key);
    if (cached !== null) {
      return cached;
    }

    // Cache miss: execute callback
    this.logger.debug(`CACHE COMPUTE: ${key}`);
    const startTime = Date.now();
    try {
      const value = await fn();
      const duration = Date.now() - startTime;
      this.logger.debug(`CACHE COMPUTE DONE: ${key} in ${duration}ms`);

      // Store in cache (don't await — fire and forget)
      if (value !== null && value !== undefined) {
        this.set(key, value, ttlSeconds).catch((err: Error) =>
          this.logger.error(`Failed to cache ${key}: ${err.message}`),
        );
      }

      return value;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`Cache COMPUTE error for ${key}: ${message}`);
      throw err;
    }
  }

  /**
   * Tag a cache key with one or more tags for bulk invalidation.
   *
   * Usage:
   *   await cache.tags('inventory', 'products').set('cache:inventory:product:123', data, 300);
   *   await cache.tags('inventory').invalidate(); // Deletes all keys tagged 'inventory'
   */
  tags(...tagNames: string[]): CacheTagBuilder {
    return new CacheTagBuilder(this, tagNames);
  }

  /**
   * Invalidate all cache keys associated with a module.
   * This deletes all keys matching the module prefix.
   *
   * @param module — Module name, e.g., 'inventory', 'sales', 'customers'
   * @returns Number of keys deleted
   */
  async invalidateModule(module: string): Promise<number> {
    const pattern = `${this.keyPrefix}:${module}:*`;
    const deleted = await this.delPattern(pattern);
    this.logger.log(`CACHE INVALIDATE MODULE: ${module} — ${deleted} keys deleted`);
    return deleted;
  }

  /**
   * Invalidate cache by tag(s).
   * Deletes all keys that were tagged with any of the given tags.
   */
  async invalidateTags(...tagNames: string[]): Promise<number> {
    let totalDeleted = 0;

    for (const tag of tagNames) {
      const tagKey = `${this.tagPrefix}:${tag}`;
      const taggedKeys = await this.redis.get<string[]>(tagKey);

      if (taggedKeys && taggedKeys.length > 0) {
        // Delete all tagged keys
        const batchSize = 100;
        for (let i = 0; i < taggedKeys.length; i += batchSize) {
          const batch = taggedKeys.slice(i, i + batchSize);
          await this.redis.del(batch);
          totalDeleted += batch.length;
        }

        // Delete the tag index itself
        await this.redis.del(tagKey);
      }

      this.logger.log(`CACHE INVALIDATE TAG: ${tag} — ${taggedKeys?.length || 0} keys deleted`);
    }

    return totalDeleted;
  }

  /**
   * Associate a cache key with tags for later bulk invalidation.
   */
  async tagKey(key: string, tagNames: string[]): Promise<void> {
    for (const tag of tagNames) {
      const tagKey = `${this.tagPrefix}:${tag}`;
      const existing = (await this.redis.get<string[]>(tagKey)) || [];
      if (!existing.includes(key)) {
        existing.push(key);
        await this.redis.set(tagKey, existing, this.defaultTtl * 10); // Tags live longer
      }
    }
  }

  /**
   * Get the remaining TTL for a key.
   */
  async getTtl(key: string): Promise<number> {
    return this.redis.ttl(key);
  }

  /**
   * Check if a key exists in cache.
   */
  async has(key: string): Promise<boolean> {
    const count = await this.redis.exists(key);
    return count > 0;
  }

  /**
   * Increment a numeric cache value.
   */
  async increment(key: string, amount = 1): Promise<number> {
    return this.redis.increment(key, amount);
  }

  /**
   * Decrement a numeric cache value.
   */
  async decrement(key: string, amount = 1): Promise<number> {
    return this.redis.decrement(key, amount);
  }

  /**
   * Get cache statistics for monitoring.
   */
  async getStats(): Promise<{
    module: string;
    keyCount: number;
    totalMemoryBytes: number;
  }[]> {
    const modules = ['inventory', 'sales', 'customers', 'users', 'reports', 'settings'];
    const stats: Array<{ module: string; keyCount: number; totalMemoryBytes: number }> = [];

    for (const module of modules) {
      const pattern = `${this.keyPrefix}:${module}:*`;
      const keys = await this.redis.keys(pattern);
      let totalMemory = 0;

      for (const key of keys) {
        try {
          const mem = await this.redis.memoryUsage(key);
          totalMemory += mem || 0;
        } catch {
          // Key may have expired between keys() and memoryUsage()
        }
      }

      stats.push({
        module,
        keyCount: keys.length,
        totalMemoryBytes: totalMemory,
      });
    }

    return stats;
  }

  /**
   * Flush all cache entries — USE WITH CAUTION.
   */
  async flushAll(): Promise<void> {
    const pattern = `${this.keyPrefix}:*`;
    const deleted = await this.delPattern(pattern);
    this.logger.warn(`CACHE FLUSH: ${deleted} keys deleted`);
  }

  /**
   * Warm the cache by pre-computing and storing values.
   */
  async warmCache<T>(
    entries: Array<{ key: string; callback: () => Promise<T>; ttl?: number }>,
  ): Promise<void> {
    this.logger.log(`Warming cache with ${entries.length} entries`);
    const results = await Promise.allSettled(
      entries.map(async (e) => {
        const value = await e.callback();
        await this.set(e.key, value, e.ttl);
        return e.key;
      }),
    );

    const succeeded = results.filter((r) => r.status === 'fulfilled').length;
    const failed = results.filter((r) => r.status === 'rejected').length;
    this.logger.log(`Cache warming complete: ${succeeded} succeeded, ${failed} failed`);
  }
}

/**
 * Cache Tag Builder
 *
 * Fluent API for tagging cache keys.
 *
 * Usage:
 *   await cache.tags('inventory', 'products').set(key, value, ttl);
 *   await cache.tags('inventory').invalidate();
 */
export class CacheTagBuilder {
  constructor(
    private readonly cache: CacheService,
    private readonly tagNames: string[],
  ) {}

  /** Set a tagged cache value */
  async set<T = unknown>(
    key: string,
    value: T,
    ttlSeconds?: number,
  ): Promise<void> {
    await this.cache.set(key, value, ttlSeconds);
    await this.cache.tagKey(key, this.tagNames);
  }

  /** Invalidate all keys with these tags */
  async invalidate(): Promise<number> {
    return this.cache.invalidateTags(...this.tagNames);
  }

  /** Get all tags being managed */
  getTags(): string[] {
    return this.tagNames;
  }
}
