import { Module, Global } from '@nestjs/common';
import { RedisModule } from '../redis/redis.module';
import { CacheService } from './cache.service';

/**
 * Global Cache Module
 *
 * Provides a high-level caching layer on top of Redis.
 * Supports TTL, cache tagging, module-based invalidation, and remember pattern.
 */
@Global()
@Module({
  imports: [RedisModule],
  providers: [CacheService],
  exports: [CacheService],
})
export class CacheModule {}
