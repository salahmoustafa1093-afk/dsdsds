import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  InvoiceStatus,
  MovementType,
  JournalStatus,
  UserStatus,
  Prisma,
} from '@prisma/client';

import { CreatePurchaseOrderDto } from './dto/create-purchase-order.dto';
import { UpdatePurchaseOrderDto } from './dto/update-purchase-order.dto';
import { CreateSupplierDto } from './dto/create-supplier.dto';
import { UpdateSupplierDto } from './dto/update-supplier.dto';
import { CreateSupplierEvaluationDto } from './dto/create-supplier-evaluation.dto';
import { ReceiveGoodsDto } from './dto/receive-goods.dto';
import { CreateReturnDto } from './dto/create-return.dto';

// ─────────────────────────────────────────────────────────────
// Status transition rules mapped to InvoiceStatus
// Workflow: DRAFT → CONFIRMED → PENDING → DELIVERED → PAID
// ─────────────────────────────────────────────────────────────

const STATUS_TRANSITIONS: Record<InvoiceStatus, InvoiceStatus[]> = {
  DRAFT: [InvoiceStatus.CONFIRMED, InvoiceStatus.CANCELLED],
  CONFIRMED: [InvoiceStatus.PENDING, InvoiceStatus.CANCELLED],
  PENDING: [InvoiceStatus.DELIVERED, InvoiceStatus.CANCELLED],
  DELIVERED: [InvoiceStatus.PAID, InvoiceStatus.PARTIALLY_PAID],
  PARTIALLY_PAID: [InvoiceStatus.PAID, InvoiceStatus.OVERDUE],
  PAID: [],
  OVERDUE: [InvoiceStatus.PAID, InvoiceStatus.CANCELLED],
  CANCELLED: [],
  RETURNED: [],
};

const TOLERANCE_PERCENT = 2; // ±2% tolerance for 3-way matching

// ─────────────────────────────────────────────────────────────
// Result interfaces
// ─────────────────────────────────────────────────────────────

interface GRNResult {
  poId: string;
  orderNumber: string;
  receivedItems: Array<{
    lineId: string;
    productName: string;
    orderedQty: number;
    receivedQty: number;
    acceptedQty: number;
    rejectedQty: number;
    rejectionReason?: string;
  }>;
  newStatus: InvoiceStatus;
  inventoryMovementsCreated: number;
  journalEntryId?: string;
}

interface ThreeWayMatchResult {
  poId: string;
  orderNumber: string;
  status: 'MATCHED' | 'DISCREPANCY' | 'PARTIAL';
  tolerance: number;
  discrepancies: Array<{
    lineId: string;
    productName: string;
    poQty: number;
    receivedQty: number;
    difference: number;
    differencePercent: number;
    severity: 'INFO' | 'WARNING' | 'CRITICAL';
  }>;
  summary: {
    totalLines: number;
    matchedLines: number;
    discrepancyLines: number;
  };
}

interface PurchaseReturnResult {
  poId: string;
  orderNumber: string;
  supplierId: string;
  totalReturnValue: number;
  inventoryDeducted: boolean;
  journalEntryId?: string;
}

interface SupplierPerformance {
  supplierId: string;
  supplierName: string;
  onTimeDeliveryRate: number;
  qualityAcceptanceRate: number;
  avgPriceVariance: number;
  returnRate: number;
  overallScore: number;
  orderCount: number;
  totalPurchaseValue: number;
}

interface PurchaseAnalytics {
  period: { start: Date; end: Date };
  totalPurchaseValue: number;
  totalOrders: number;
  totalItems: number;
  avgOrderValue: number;
  topSuppliers: Array<{
    supplierId: string;
    supplierName: string;
    totalValue: number;
    orderCount: number;
    avgOrderValue: number;
  }>;
  categoryBreakdown: Array<{
    category: string;
    totalValue: number;
    itemCount: number;
  }>;
  priceTrends: Array<{
    productId: string;
    productName: string;
    avgPrice: number;
    minPrice: number;
    maxPrice: number;
    priceChange: number;
  }>;
  returnRate: number;
  avgLeadTimeDays: number;
}

// ─────────────────────────────────────────────────────────────

@Injectable()
export class PurchasesService {
  private readonly logger = new Logger(PurchasesService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════════════════════
  // PURCHASE ORDER CRUD
  // ═══════════════════════════════════════════════════════════

  async findAll(
    companyId: string,
    options: {
      page?: number;
      limit?: number;
      status?: string;
      supplierId?: string;
      branchId?: string;
      startDate?: string;
      endDate?: string;
    },
  ) {
    const {
      page = 1,
      limit = 10,
      status,
      supplierId,
      branchId,
      startDate,
      endDate,
    } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.PurchaseOrderWhereInput = {
      branch: { companyId },
      deletedAt: null,
    };
    if (status) where.status = status as InvoiceStatus;
    if (supplierId) where.supplierId = supplierId;
    if (branchId) where.branchId = branchId;
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate);
      if (endDate) where.createdAt.lte = new Date(endDate);
    }

    const [data, total] = await Promise.all([
      this.prisma.purchaseOrder.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          supplier: { select: { id: true, name: true, code: true } },
          branch: { select: { id: true, name: true, code: true } },
          lines: {
            include: {
              product: {
                select: {
                  id: true,
                  name: true,
                  code: true,
                  category: { select: { name: true } },
                },
              },
            },
          },
        },
      }),
      this.prisma.purchaseOrder.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOne(id: string, companyId: string) {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id, branch: { companyId }, deletedAt: null },
      include: {
        supplier: {
          select: { id: true, name: true, code: true, phone: true, email: true },
        },
        branch: { select: { id: true, name: true, code: true } },
        lines: {
          include: {
            product: {
              select: {
                id: true,
                name: true,
                code: true,
                unitId: true,
              },
            },
          },
        },
      },
    });
    if (!order) throw new NotFoundException('Purchase order not found');

    // Fetch related stock movements (goods receipts) for this PO
    const stockMovements = await this.prisma.stockMovement.findMany({
      where: {
        referenceType: 'PURCHASE_ORDER',
        referenceId: id,
        type: MovementType.RECEIPT,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Calculate fulfillment percentage
    const totalOrdered = order.lines.reduce((s, l) => s + Number(l.quantity), 0);
    const totalReceived = order.lines.reduce(
      (s, l) => s + Number(l.receivedQuantity || 0),
      0,
    );
    const fulfillmentPercent =
      totalOrdered > 0 ? (totalReceived / totalOrdered) * 100 : 0;

    return {
      data: {
        ...order,
        fulfillmentPercent: Math.round(fulfillmentPercent * 100) / 100,
        stockMovements,
      },
    };
  }

  async create(companyId: string, dto: CreatePurchaseOrderDto) {
    const count = await this.prisma.purchaseOrder.count({
      where: { branch: { companyId } },
    });
    const orderNumber = `PO-${Date.now().toString(36).toUpperCase()}-${(count + 1).toString().padStart(4, '0')}`;

    // Validate supplier belongs to company
    const supplier = await this.prisma.supplier.findFirst({
      where: { id: dto.supplierId, companyId },
    });
    if (!supplier) throw new NotFoundException('Supplier not found');

    // Validate branch belongs to company
    const branch = await this.prisma.branch.findFirst({
      where: { id: dto.branchId, companyId },
    });
    if (!branch) throw new NotFoundException('Branch not found');

    let subtotal = 0;
    const linesData: Prisma.PurchaseOrderLineCreateManyOrderInput[] = [];
    for (const item of dto.items || []) {
      // Validate product
      const product = await this.prisma.product.findFirst({
        where: { id: item.productId, companyId, deletedAt: null },
        select: { id: true, name: true, avgCost: true },
      });
      if (!product) {
        throw new BadRequestException(`Product not found: ${item.productId}`);
      }

      const lineTotal = item.quantity * item.unitPrice;
      subtotal += lineTotal;
      linesData.push({
        productId: item.productId,
        quantity: new Prisma.Decimal(item.quantity),
        unitPrice: new Prisma.Decimal(item.unitPrice),
        totalPrice: new Prisma.Decimal(lineTotal),
        receivedQuantity: new Prisma.Decimal(0),
      });
    }

    if (linesData.length === 0) {
      throw new BadRequestException(
        'Purchase order must have at least one line item',
      );
    }

    const order = await this.prisma.purchaseOrder.create({
      data: {
        orderNumber,
        branchId: dto.branchId,
        supplierId: dto.supplierId,
        totalAmount: new Prisma.Decimal(subtotal),
        status: InvoiceStatus.DRAFT,
        expectedDate: dto.expectedDate ? new Date(dto.expectedDate) : null,
        notes: dto.notes,
        lines: { create: linesData },
      },
      include: {
        lines: {
          include: {
            product: { select: { id: true, name: true, code: true } },
          },
        },
        supplier: { select: { id: true, name: true } },
      },
    });

    this.logger.log(
      `Purchase order created: ${order.orderNumber} (${linesData.length} lines, ${subtotal.toFixed(2)} EGP)`,
    );
    return { data: order };
  }

  async update(id: string, companyId: string, dto: UpdatePurchaseOrderDto) {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id, branch: { companyId }, deletedAt: null },
      include: { lines: true },
    });
    if (!order) throw new NotFoundException('Purchase order not found');
    if (order.status !== InvoiceStatus.DRAFT) {
      throw new ConflictException(
        `Cannot edit PO in ${order.status} status. Only DRAFT orders can be modified.`,
      );
    }

    const updateData: Prisma.PurchaseOrderUpdateInput = {};
    if (dto.supplierId) {
      const supplier = await this.prisma.supplier.findFirst({
        where: { id: dto.supplierId, companyId },
      });
      if (!supplier) throw new NotFoundException('Supplier not found');
      updateData.supplier = { connect: { id: dto.supplierId } };
    }
    if (dto.expectedDate !== undefined) {
      updateData.expectedDate = dto.expectedDate
        ? new Date(dto.expectedDate)
        : null;
    }
    if (dto.notes !== undefined) updateData.notes = dto.notes;

    // Recalculate totals if items changed
    if (dto.items && dto.items.length > 0) {
      // Delete existing lines and recreate
      await this.prisma.purchaseOrderLine.deleteMany({ where: { orderId: id } });

      let subtotal = 0;
      const newLines: Prisma.PurchaseOrderLineCreateManyOrderInput[] = [];
      for (const item of dto.items) {
        const product = await this.prisma.product.findFirst({
          where: { id: item.productId, companyId, deletedAt: null },
          select: { id: true },
        });
        if (!product) {
          throw new BadRequestException(`Product not found: ${item.productId}`);
        }

        const lineTotal = item.quantity * item.unitPrice;
        subtotal += lineTotal;
        newLines.push({
          productId: item.productId,
          quantity: new Prisma.Decimal(item.quantity),
          unitPrice: new Prisma.Decimal(item.unitPrice),
          totalPrice: new Prisma.Decimal(lineTotal),
          receivedQuantity: new Prisma.Decimal(0),
        });
      }
      updateData.totalAmount = new Prisma.Decimal(subtotal);
      updateData.lines = { create: newLines };
    }

    const updated = await this.prisma.purchaseOrder.update({
      where: { id },
      data: updateData,
      include: {
        lines: {
          include: {
            product: { select: { id: true, name: true, code: true } },
          },
        },
        supplier: { select: { id: true, name: true } },
      },
    });

    this.logger.log(`Purchase order updated: ${updated.orderNumber}`);
    return { data: updated };
  }

  async remove(id: string, companyId: string) {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id, branch: { companyId }, deletedAt: null },
    });
    if (!order) throw new NotFoundException('Purchase order not found');
    if (order.status !== InvoiceStatus.DRAFT) {
      throw new ConflictException(
        `Cannot delete PO in ${order.status} status. Only DRAFT orders can be deleted.`,
      );
    }

    await this.prisma.purchaseOrder.update({
      where: { id },
      data: { deletedAt: new Date() },
    });

    this.logger.log(`Purchase order soft-deleted: ${order.orderNumber}`);
    return { message: 'Purchase order deleted successfully' };
  }

  // ═══════════════════════════════════════════════════════════
  // STATUS WORKFLOW
  // ═══════════════════════════════════════════════════════════

  async updateStatus(
    id: string,
    companyId: string,
    newStatus: InvoiceStatus,
    notes?: string,
  ) {
    return this.transitionStatus(id, companyId, newStatus, notes);
  }

  /**
   * Confirm a DRAFT purchase order.
   * Status: DRAFT → CONFIRMED
   */
  async confirmOrder(poId: string, companyId: string) {
    return this.transitionStatus(poId, companyId, InvoiceStatus.CONFIRMED);
  }

  /**
   * Mark PO as sent to supplier.
   * Status: CONFIRMED → PENDING
   */
  async markAsSent(poId: string, companyId: string) {
    return this.transitionStatus(poId, companyId, InvoiceStatus.PENDING);
  }

  /**
   * Close a fully received PO.
   * Status: DELIVERED → PAID
   */
  async closeOrder(poId: string, companyId: string) {
    return this.transitionStatus(poId, companyId, InvoiceStatus.PAID);
  }

  /**
   * Cancel a purchase order (if allowed by current status).
   */
  async cancelOrder(
    poId: string,
    companyId: string,
    reason?: string,
  ) {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id: poId, branch: { companyId }, deletedAt: null },
    });
    if (!order) throw new NotFoundException('Purchase order not found');

    // Cannot cancel if already delivered or paid
    if (
      [InvoiceStatus.PAID, InvoiceStatus.DELIVERED].includes(
        order.status as InvoiceStatus,
      )
    ) {
      throw new ConflictException(
        `Cannot cancel order in ${order.status} status. Create a return instead.`,
      );
    }

    const result = await this.transitionStatus(
      poId,
      companyId,
      InvoiceStatus.CANCELLED,
      reason,
    );

    this.logger.log(
      `PO ${poId} cancelled: ${reason || 'No reason given'}`,
    );
    return result;
  }

  // ═══════════════════════════════════════════════════════════
  // GOODS RECEIPT (GRN)
  // ═══════════════════════════════════════════════════════════

  async receiveGoods(
    poId: string,
    companyId: string,
    dto: ReceiveGoodsDto,
    receivedById: string,
  ): Promise<GRNResult> {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id: poId, branch: { companyId }, deletedAt: null },
      include: {
        lines: {
          include: {
            product: { select: { id: true, name: true, avgCost: true } },
          },
        },
        supplier: { select: { id: true, name: true } },
        branch: { select: { id: true, name: true } },
      },
    });
    if (!order) throw new NotFoundException('Purchase order not found');

    // Only allow receipt from PENDING, DELIVERED, or CONFIRMED status
    if (
      ![InvoiceStatus.PENDING, InvoiceStatus.DELIVERED, InvoiceStatus.CONFIRMED].includes(
        order.status as InvoiceStatus,
      )
    ) {
      throw new ConflictException(
        `Cannot receive goods for PO in ${order.status} status. Must be CONFIRMED, PENDING, or DELIVERED.`,
      );
    }

    if (!dto.items || dto.items.length === 0) {
      throw new BadRequestException('At least one received item is required');
    }

    // Find or validate warehouse
    let targetWarehouseId = dto.warehouseId;
    if (!targetWarehouseId) {
      const warehouse = await this.prisma.warehouse.findFirst({
        where: { branchId: order.branchId },
      });
      if (!warehouse) {
        throw new BadRequestException(
          'No warehouse found for this branch. Please specify a warehouse.',
        );
      }
      targetWarehouseId = warehouse.id;
    }

    // Validate all line items belong to this PO
    const poLineIds = new Set(order.lines.map((l) => l.id));
    for (const item of dto.items) {
      if (!poLineIds.has(item.lineId)) {
        throw new BadRequestException(
          `Line ${item.lineId} does not belong to PO ${poId}`,
        );
      }
      if (item.receivedQty < 0) {
        throw new BadRequestException('Received quantity cannot be negative');
      }
      if (item.acceptedQty + item.rejectedQty !== item.receivedQty) {
        throw new BadRequestException(
          `For line ${item.lineId}: acceptedQty (${item.acceptedQty}) + rejectedQty (${item.rejectedQty}) must equal receivedQty (${item.receivedQty})`,
        );
      }
    }

    // Process each received item
    const grnItemsResult: GRNResult['receivedItems'] = [];
    let inventoryMovementsCreated = 0;
    let totalAcceptedValue = 0;

    for (const item of dto.items) {
      const poLine = order.lines.find((l) => l.id === item.lineId)!;
      const newReceivedQty =
        Number(poLine.receivedQuantity || 0) + item.receivedQty;

      // Update PO line received quantity
      await this.prisma.purchaseOrderLine.update({
        where: { id: item.lineId },
        data: { receivedQuantity: new Prisma.Decimal(newReceivedQty) },
      });

      grnItemsResult.push({
        lineId: item.lineId,
        productName: poLine.product.name,
        orderedQty: Number(poLine.quantity),
        receivedQty: item.receivedQty,
        acceptedQty: item.acceptedQty,
        rejectedQty: item.rejectedQty,
        rejectionReason: item.rejectionReason,
      });

      // Create inventory receipt movement for accepted quantity
      if (item.acceptedQty > 0) {
        const movementCount = await this.prisma.stockMovement.count({
          where: { warehouseId: targetWarehouseId },
        });
        await this.prisma.stockMovement.create({
          data: {
            movementNumber: `SM-GRN-${Date.now().toString(36).toUpperCase()}-${(movementCount + 1).toString().padStart(4, '0')}`,
            type: MovementType.RECEIPT,
            productId: poLine.productId,
            warehouseId: targetWarehouseId,
            quantity: new Prisma.Decimal(item.acceptedQty),
            unitCost: poLine.unitPrice,
            totalCost: new Prisma.Decimal(
              item.acceptedQty * Number(poLine.unitPrice),
            ),
            referenceType: 'PURCHASE_ORDER',
            referenceId: poId,
            batchNumber: item.batchNumber,
            expiryDate: item.expiryDate ? new Date(item.expiryDate) : null,
            notes: `Goods receipt for PO ${order.orderNumber}`,
            createdBy: receivedById,
          },
        });
        inventoryMovementsCreated++;
        totalAcceptedValue += item.acceptedQty * Number(poLine.unitPrice);
      }
    }

    // Determine new PO status
    const refreshedLines = await this.prisma.purchaseOrderLine.findMany({
      where: { orderId: poId },
    });

    const allLinesFullyReceived = refreshedLines.every(
      (line) => Number(line.receivedQuantity) >= Number(line.quantity),
    );
    const anyLinePartiallyReceived = refreshedLines.some(
      (line) =>
        Number(line.receivedQuantity) > 0 &&
        Number(line.receivedQuantity) < Number(line.quantity),
    );

    let newStatus: InvoiceStatus = order.status as InvoiceStatus;
    if (allLinesFullyReceived) {
      newStatus = InvoiceStatus.DELIVERED;
    } else if (anyLinePartiallyReceived) {
      newStatus = InvoiceStatus.DELIVERED; // Still DELIVERED even if partial
    }

    await this.prisma.purchaseOrder.update({
      where: { id: poId },
      data: { status: newStatus },
    });

    // Auto-post journal entry if accounting accounts are found
    let journalEntryId: string | undefined;
    const inventoryAccount = await this.prisma.chartOfAccount.findFirst({
      where: {
        companyId,
        type: 'ASSET',
        nameEn: { contains: 'Inventory', mode: 'insensitive' },
      },
    });
    const apAccount = await this.prisma.chartOfAccount.findFirst({
      where: {
        companyId,
        type: 'LIABILITY',
        nameEn: { contains: 'Payable', mode: 'insensitive' },
      },
    });

    if (inventoryAccount && apAccount && totalAcceptedValue > 0) {
      const jeCount = await this.prisma.journalEntry.count({
        where: { companyId },
      });
      const entryNumber = `JE-${Date.now().toString(36).toUpperCase()}-${(jeCount + 1).toString().padStart(4, '0')}`;
      const je = await this.prisma.journalEntry.create({
        data: {
          entryNumber,
          date: new Date(),
          description: `Goods receipt — Inventory receipt from ${order.supplier.name} (PO ${order.orderNumber})`,
          totalDebit: new Prisma.Decimal(totalAcceptedValue),
          totalCredit: new Prisma.Decimal(totalAcceptedValue),
          status: JournalStatus.POSTED,
          postedBy: receivedById,
          postedAt: new Date(),
          companyId,
          lines: {
            create: [
              {
                accountId: inventoryAccount.id,
                debit: new Prisma.Decimal(totalAcceptedValue),
                credit: new Prisma.Decimal(0),
                description: `Inventory receipt — PO ${order.orderNumber}`,
              },
              {
                accountId: apAccount.id,
                debit: new Prisma.Decimal(0),
                credit: new Prisma.Decimal(totalAcceptedValue),
                description: `Accounts payable — ${order.supplier.name}`,
              },
            ],
          },
        },
      });
      journalEntryId = je.id;
    }

    this.logger.log(
      `Goods received for PO ${order.orderNumber}: ${dto.items.length} items, ${inventoryMovementsCreated} inventory movements`,
    );

    return {
      poId,
      orderNumber: order.orderNumber,
      receivedItems: grnItemsResult,
      newStatus,
      inventoryMovementsCreated,
      journalEntryId,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // THREE-WAY MATCHING (computed on the fly)
  // ═══════════════════════════════════════════════════════════

  async performThreeWayMatch(
    poId: string,
    companyId: string,
  ): Promise<ThreeWayMatchResult> {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id: poId, branch: { companyId }, deletedAt: null },
      include: {
        lines: {
          include: { product: { select: { id: true, name: true } } },
        },
      },
    });
    if (!order) throw new NotFoundException('Purchase order not found');

    // Get all stock movements (receipts) for this PO
    const stockMovements = await this.prisma.stockMovement.findMany({
      where: {
        referenceType: 'PURCHASE_ORDER',
        referenceId: poId,
        type: MovementType.RECEIPT,
      },
    });

    if (stockMovements.length === 0) {
      throw new BadRequestException(
        'No goods receipts found for this PO. Cannot perform 3-way match.',
      );
    }

    const discrepancies: ThreeWayMatchResult['discrepancies'] = [];
    let matchedLines = 0;

    for (const poLine of order.lines) {
      const poQty = Number(poLine.quantity);

      // Sum all stock movement quantities for this product under this PO
      const receivedQty = stockMovements
        .filter((sm) => sm.productId === poLine.productId)
        .reduce((sum, sm) => sum + Number(sm.quantity), 0);

      // Calculate difference against PO
      const difference = receivedQty - poQty;
      const differencePercent = poQty > 0 ? (difference / poQty) * 100 : 0;

      // Check against tolerance (±2%)
      const withinTolerance =
        Math.abs(differencePercent) <= TOLERANCE_PERCENT;

      if (!withinTolerance) {
        let severity: 'INFO' | 'WARNING' | 'CRITICAL' = 'INFO';
        if (Math.abs(differencePercent) > 10) severity = 'CRITICAL';
        else if (Math.abs(differencePercent) > 5) severity = 'WARNING';

        discrepancies.push({
          lineId: poLine.id,
          productName: poLine.product.name,
          poQty,
          receivedQty,
          difference: Math.round(difference * 1000) / 1000,
          differencePercent: Math.round(differencePercent * 100) / 100,
          severity,
        });
      } else {
        matchedLines++;
      }
    }

    const status: ThreeWayMatchResult['status'] =
      discrepancies.length === 0
        ? 'MATCHED'
        : discrepancies.some((d) => d.severity === 'CRITICAL')
          ? 'DISCREPANCY'
          : 'PARTIAL';

    this.logger.log(
      `3-way match for PO ${order.orderNumber}: ${status} (${matchedLines}/${order.lines.length} matched, ${discrepancies.length} discrepancies)`,
    );

    return {
      poId,
      orderNumber: order.orderNumber,
      status,
      tolerance: TOLERANCE_PERCENT,
      discrepancies,
      summary: {
        totalLines: order.lines.length,
        matchedLines,
        discrepancyLines: discrepancies.length,
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // PURCHASE RETURNS
  // ═══════════════════════════════════════════════════════════

  async createReturn(
    poId: string,
    companyId: string,
    dto: CreateReturnDto,
    createdById: string,
  ): Promise<PurchaseReturnResult> {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id: poId, branch: { companyId }, deletedAt: null },
      include: {
        lines: {
          include: {
            product: { select: { id: true, name: true, avgCost: true } },
          },
        },
        supplier: { select: { id: true, name: true } },
      },
    });
    if (!order) throw new NotFoundException('Purchase order not found');

    if (
      ![InvoiceStatus.DELIVERED, InvoiceStatus.PAID].includes(
        order.status as InvoiceStatus,
      )
    ) {
      throw new ConflictException(
        `Cannot create return for PO in ${order.status} status. Must be at least partially received.`,
      );
    }

    if (!dto.items || dto.items.length === 0) {
      throw new BadRequestException('At least one return item is required');
    }

    if (!dto.reason || dto.reason.trim().length < 3) {
      throw new BadRequestException(
        'Return reason is required (min 3 characters)',
      );
    }

    // Validate return items
    const poLineMap = new Map(order.lines.map((l) => [l.id, l]));
    let totalReturnValue = 0;
    const validatedItems: Array<{
      lineId: string;
      returnQty: number;
      reason: string;
      unitPrice: number;
      productId: string;
      productName: string;
    }> = [];

    for (const item of dto.items) {
      const poLine = poLineMap.get(item.lineId);
      if (!poLine) {
        throw new BadRequestException(`Line ${item.lineId} not found in PO`);
      }
      if (item.returnQty <= 0) {
        throw new BadRequestException(
          `Return quantity must be positive for line ${item.lineId}`,
        );
      }
      if (item.returnQty > Number(poLine.receivedQuantity || 0)) {
        throw new BadRequestException(
          `Cannot return ${item.returnQty} of ${poLine.product.name}. Only ${poLine.receivedQuantity} was received.`,
        );
      }

      const lineValue = item.returnQty * item.unitPrice;
      totalReturnValue += lineValue;

      validatedItems.push({
        ...item,
        productId: poLine.productId,
        productName: poLine.product.name,
      });
    }

    // Deduct from inventory (create RETURN movement)
    let inventoryDeducted = false;
    const warehouse = await this.prisma.warehouse.findFirst({
      where: { branchId: order.branchId },
    });

    if (warehouse) {
      for (const item of validatedItems) {
        const movementCount = await this.prisma.stockMovement.count({
          where: { warehouseId: warehouse.id },
        });
        await this.prisma.stockMovement.create({
          data: {
            movementNumber: `SM-RET-${Date.now().toString(36).toUpperCase()}-${(movementCount + 1).toString().padStart(4, '0')}`,
            type: MovementType.RETURN,
            productId: item.productId,
            warehouseId: warehouse.id,
            quantity: new Prisma.Decimal(item.returnQty),
            unitCost: new Prisma.Decimal(item.unitPrice),
            totalCost: new Prisma.Decimal(
              item.returnQty * item.unitPrice,
            ),
            referenceType: 'PURCHASE_RETURN',
            referenceId: poId,
            notes: `Purchase return — ${dto.reason}`,
            createdBy: createdById,
          },
        });
      }
      inventoryDeducted = true;
    }

    // Reduce received quantity on PO lines
    for (const item of validatedItems) {
      await this.prisma.purchaseOrderLine.update({
        where: { id: item.lineId },
        data: {
          receivedQuantity: {
            decrement: item.returnQty,
          },
        },
      });
    }

    // Create journal entry (reverse the AP/Inventory entry)
    let journalEntryId: string | undefined;
    const apAccount = await this.prisma.chartOfAccount.findFirst({
      where: {
        companyId,
        type: 'LIABILITY',
        nameEn: { contains: 'Payable', mode: 'insensitive' },
      },
    });
    const inventoryAccount = await this.prisma.chartOfAccount.findFirst({
      where: {
        companyId,
        type: 'ASSET',
        nameEn: { contains: 'Inventory', mode: 'insensitive' },
      },
    });

    if (apAccount && inventoryAccount && totalReturnValue > 0) {
      const jeCount = await this.prisma.journalEntry.count({
        where: { companyId },
      });
      const entryNumber = `JE-RET-${Date.now().toString(36).toUpperCase()}-${(jeCount + 1).toString().padStart(4, '0')}`;
      const je = await this.prisma.journalEntry.create({
        data: {
          entryNumber,
          date: new Date(),
          description: `Purchase return — ${order.supplier.name} (PO ${order.orderNumber})`,
          totalDebit: new Prisma.Decimal(totalReturnValue),
          totalCredit: new Prisma.Decimal(totalReturnValue),
          status: JournalStatus.POSTED,
          postedBy: createdById,
          postedAt: new Date(),
          companyId,
          lines: {
            create: [
              {
                accountId: apAccount.id,
                debit: new Prisma.Decimal(totalReturnValue),
                credit: new Prisma.Decimal(0),
                description: `AP reduction — purchase return PO ${order.orderNumber}`,
              },
              {
                accountId: inventoryAccount.id,
                debit: new Prisma.Decimal(0),
                credit: new Prisma.Decimal(totalReturnValue),
                description: `Inventory reduction — purchase return`,
              },
            ],
          },
        },
      });
      journalEntryId = je.id;
    }

    this.logger.log(
      `Purchase return created for PO ${order.orderNumber}: ${dto.items.length} items, ${totalReturnValue.toFixed(2)} EGP`,
    );

    return {
      poId,
      orderNumber: order.orderNumber,
      supplierId: order.supplierId,
      totalReturnValue: Math.round(totalReturnValue * 100) / 100,
      inventoryDeducted,
      journalEntryId,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPLIER CRUD
  // ═══════════════════════════════════════════════════════════

  async findAllSuppliers(
    companyId: string,
    options: {
      page?: number;
      limit?: number;
      status?: string;
      search?: string;
    },
  ) {
    const { page = 1, limit = 10, status, search } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.SupplierWhereInput = { companyId, deletedAt: null };
    if (status) where.status = status as UserStatus;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.supplier.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { purchaseOrders: true, supplierEvaluations: true } },
        },
      }),
      this.prisma.supplier.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOneSupplier(id: string, companyId: string) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        purchaseOrders: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: {
            id: true,
            orderNumber: true,
            totalAmount: true,
            status: true,
            expectedDate: true,
            createdAt: true,
          },
        },
        supplierEvaluations: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
        _count: {
          select: { purchaseOrders: true, supplierEvaluations: true },
        },
      },
    });
    if (!supplier) throw new NotFoundException('Supplier not found');

    return { data: supplier };
  }

  async createSupplier(dto: CreateSupplierDto) {
    // Validate company exists
    const company = await this.prisma.company.findUnique({
      where: { id: dto.companyId },
    });
    if (!company) throw new NotFoundException('Company not found');

    // Check for duplicate code
    const existing = await this.prisma.supplier.findUnique({
      where: { code: dto.code },
    });
    if (existing) {
      throw new ConflictException(
        `Supplier with code "${dto.code}" already exists`,
      );
    }

    const supplier = await this.prisma.supplier.create({
      data: {
        code: dto.code,
        name: dto.name,
        type: dto.type || 'LOCAL',
        phone: dto.phone,
        email: dto.email,
        address: dto.address,
        city: dto.city,
        taxNumber: dto.taxNumber,
        companyId: dto.companyId,
      },
    });

    this.logger.log(`Supplier created: ${supplier.code} — ${supplier.name}`);
    return { data: supplier };
  }

  async updateSupplier(
    id: string,
    companyId: string,
    dto: UpdateSupplierDto,
  ) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException('Supplier not found');

    // Check code uniqueness if changing
    if (dto.code && dto.code !== supplier.code) {
      const existing = await this.prisma.supplier.findUnique({
        where: { code: dto.code },
      });
      if (existing) {
        throw new ConflictException(
          `Supplier with code "${dto.code}" already exists`,
        );
      }
    }

    const updated = await this.prisma.supplier.update({
      where: { id },
      data: {
        code: dto.code,
        name: dto.name,
        type: dto.type,
        phone: dto.phone,
        email: dto.email,
        address: dto.address,
        city: dto.city,
        taxNumber: dto.taxNumber,
        status: dto.status,
      },
    });

    this.logger.log(`Supplier updated: ${updated.code} — ${updated.name}`);
    return { data: updated };
  }

  async deleteSupplier(id: string, companyId: string) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException('Supplier not found');

    // Check if supplier has active purchase orders
    const activePOs = await this.prisma.purchaseOrder.count({
      where: {
        supplierId: id,
        status: { notIn: [InvoiceStatus.CANCELLED, InvoiceStatus.PAID] },
        deletedAt: null,
      },
    });
    if (activePOs > 0) {
      throw new ConflictException(
        'Cannot delete supplier with active purchase orders. Cancel or complete them first.',
      );
    }

    await this.prisma.supplier.update({
      where: { id },
      data: { deletedAt: new Date() },
    });

    this.logger.log(`Supplier soft-deleted: ${supplier.code}`);
    return { message: 'Supplier deleted successfully' };
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPLIER EVALUATION
  // ═══════════════════════════════════════════════════════════

  async createEvaluation(
    dto: CreateSupplierEvaluationDto,
    evaluatedBy: string,
  ) {
    const supplier = await this.prisma.supplier.findUnique({
      where: { id: dto.supplierId },
    });
    if (!supplier) throw new NotFoundException('Supplier not found');

    const evaluation = await this.prisma.supplierEvaluation.create({
      data: {
        supplierId: dto.supplierId,
        qualityScore: dto.qualityScore,
        priceScore: dto.priceScore,
        deliveryScore: dto.deliveryScore,
        serviceScore: dto.serviceScore,
        reliabilityScore: dto.reliabilityScore,
        overallScore: dto.overallScore,
        evaluatedBy,
        notes: dto.notes,
      },
      include: {
        supplier: { select: { id: true, name: true, code: true } },
        evaluator: { select: { id: true, fullName: true } },
      },
    });

    // Update supplier rating with latest overall score
    await this.prisma.supplier.update({
      where: { id: dto.supplierId },
      data: { rating: dto.overallScore },
    });

    this.logger.log(
      `Evaluation created for supplier ${supplier.name}: score ${dto.overallScore}/100`,
    );
    return { data: evaluation };
  }

  async findSupplierEvaluations(
    supplierId: string,
    companyId: string,
    options: { page?: number; limit?: number },
  ) {
    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    // Verify supplier belongs to company
    const supplier = await this.prisma.supplier.findFirst({
      where: { id: supplierId, companyId },
    });
    if (!supplier) throw new NotFoundException('Supplier not found');

    const [data, total] = await Promise.all([
      this.prisma.supplierEvaluation.findMany({
        where: { supplierId },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          evaluator: { select: { id: true, fullName: true } },
        },
      }),
      this.prisma.supplierEvaluation.count({ where: { supplierId } }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPLIER PERFORMANCE TRACKING
  // ═══════════════════════════════════════════════════════════

  async trackSupplierPerformance(
    supplierId: string,
    companyId: string,
  ): Promise<SupplierPerformance> {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id: supplierId, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException('Supplier not found');

    // Get all completed orders for this supplier
    const orders = await this.prisma.purchaseOrder.findMany({
      where: {
        supplierId,
        branch: { companyId },
        status: { in: [InvoiceStatus.DELIVERED, InvoiceStatus.PAID] },
        deletedAt: null,
      },
    });

    if (orders.length === 0) {
      return {
        supplierId,
        supplierName: supplier.name,
        onTimeDeliveryRate: 0,
        qualityAcceptanceRate: 0,
        avgPriceVariance: 0,
        returnRate: 0,
        overallScore: 0,
        orderCount: 0,
        totalPurchaseValue: 0,
      };
    }

    // On-time delivery rate
    let onTimeCount = 0;
    for (const order of orders) {
      if (order.expectedDate) {
        // Get first receipt date from stock movements
        const firstReceipt = await this.prisma.stockMovement.findFirst({
          where: {
            referenceType: 'PURCHASE_ORDER',
            referenceId: order.id,
            type: MovementType.RECEIPT,
          },
          orderBy: { createdAt: 'asc' },
          select: { createdAt: true },
        });
        if (
          firstReceipt &&
          new Date(firstReceipt.createdAt) <= new Date(order.expectedDate)
        ) {
          onTimeCount++;
        }
      }
    }
    const onTimeDeliveryRate =
      orders.length > 0 ? (onTimeCount / orders.length) * 100 : 0;

    // Quality acceptance rate from stock movements
    const movements = await this.prisma.stockMovement.findMany({
      where: {
        referenceType: 'PURCHASE_ORDER',
        referenceId: { in: orders.map((o) => o.id) },
        type: MovementType.RECEIPT,
      },
    });
    const totalAccepted = movements.reduce(
      (s, m) => s + Number(m.quantity),
      0,
    );
    // Assume all stock movements represent accepted goods
    // (rejected goods don't create stock movements)
    const qualityAcceptanceRate = 100; // Simplified — all stock receipts are accepted

    // Return rate: count return movements
    const returnMovements = await this.prisma.stockMovement.findMany({
      where: {
        referenceType: 'PURCHASE_RETURN',
        productId: {
          in: movements.map((m) => m.productId),
        },
        type: MovementType.RETURN,
      },
    });
    const totalReturnedValue = returnMovements.reduce(
      (s, m) => s + Number(m.totalCost || 0),
      0,
    );
    const totalPurchaseValue = orders.reduce(
      (s, o) => s + Number(o.totalAmount),
      0,
    );
    const returnRate =
      totalPurchaseValue > 0
        ? (totalReturnedValue / totalPurchaseValue) * 100
        : 0;

    // Price variance (compare to average market price from other suppliers)
    const allLines = await this.prisma.purchaseOrderLine.findMany({
      where: {
        order: {
          branch: { companyId },
          status: { in: [InvoiceStatus.DELIVERED, InvoiceStatus.PAID] },
          deletedAt: null,
        },
      },
      include: { product: { select: { id: true, name: true } } },
    });
    const productPrices = new Map<string, number[]>();
    for (const line of allLines) {
      const prices = productPrices.get(line.productId) || [];
      prices.push(Number(line.unitPrice));
      productPrices.set(line.productId, prices);
    }
    const supplierLines = allLines.filter((l) =>
      orders.map((o) => o.id).includes(l.orderId),
    );
    let totalVariance = 0;
    let varianceCount = 0;
    for (const line of supplierLines) {
      const marketPrices = productPrices.get(line.productId) || [];
      const avgPrice =
        marketPrices.reduce((s, p) => s + p, 0) / marketPrices.length;
      if (avgPrice > 0) {
        const variance = ((Number(line.unitPrice) - avgPrice) / avgPrice) * 100;
        totalVariance += Math.abs(variance);
        varianceCount++;
      }
    }
    const avgPriceVariance =
      varianceCount > 0 ? totalVariance / varianceCount : 0;

    // Overall score (weighted average)
    const overallScore = Math.round(
      onTimeDeliveryRate * 0.3 +
        qualityAcceptanceRate * 0.3 +
        Math.max(0, 100 - avgPriceVariance) * 0.2 +
        Math.max(0, 100 - returnRate) * 0.2,
    );

    // Update supplier rating
    await this.prisma.supplier.update({
      where: { id: supplierId },
      data: { rating: overallScore },
    });

    return {
      supplierId,
      supplierName: supplier.name,
      onTimeDeliveryRate: Math.round(onTimeDeliveryRate * 100) / 100,
      qualityAcceptanceRate: Math.round(qualityAcceptanceRate * 100) / 100,
      avgPriceVariance: Math.round(avgPriceVariance * 100) / 100,
      returnRate: Math.round(returnRate * 100) / 100,
      overallScore,
      orderCount: orders.length,
      totalPurchaseValue: Math.round(totalPurchaseValue * 100) / 100,
    };
  }

  /**
   * Get performance summary for all suppliers of a company.
   */
  async getAllSupplierPerformance(companyId: string) {
    const suppliers = await this.prisma.supplier.findMany({
      where: { companyId, deletedAt: null },
      select: { id: true, name: true },
    });

    const results: SupplierPerformance[] = [];
    for (const supplier of suppliers) {
      try {
        const perf = await this.trackSupplierPerformance(
          supplier.id,
          companyId,
        );
        results.push(perf);
      } catch (e: unknown) {
        const message = e instanceof Error ? e.message : String(e);
        this.logger.warn(
          `Failed to calculate performance for supplier ${supplier.id}: ${message}`,
        );
      }
    }

    return { data: results.sort((a, b) => b.overallScore - a.overallScore) };
  }

  // ═══════════════════════════════════════════════════════════
  // PURCHASE ANALYTICS
  // ═══════════════════════════════════════════════════════════

  async getPurchaseAnalytics(
    companyId: string,
    startDate: Date,
    endDate: Date,
  ): Promise<PurchaseAnalytics> {
    if (startDate > endDate) {
      throw new BadRequestException('Start date must be before end date');
    }

    const where: Prisma.PurchaseOrderWhereInput = {
      branch: { companyId },
      createdAt: { gte: startDate, lte: endDate },
      deletedAt: null,
      status: { notIn: [InvoiceStatus.CANCELLED] },
    };

    // Total purchase value and order count
    const orders = await this.prisma.purchaseOrder.findMany({
      where,
      include: {
        supplier: { select: { id: true, name: true } },
        lines: {
          include: {
            product: {
              select: {
                id: true,
                name: true,
                category: { select: { name: true } },
              },
            },
          },
        },
      },
    });

    const totalPurchaseValue = orders.reduce(
      (s, o) => s + Number(o.totalAmount),
      0,
    );
    const totalOrders = orders.length;
    const totalItems = orders.reduce((s, o) => s + o.lines.length, 0);
    const avgOrderValue = totalOrders > 0 ? totalPurchaseValue / totalOrders : 0;

    // Top suppliers by value
    const supplierMap = new Map<
      string,
      {
        supplierId: string;
        supplierName: string;
        totalValue: number;
        orderCount: number;
      }
    >();
    for (const order of orders) {
      const existing = supplierMap.get(order.supplierId) || {
        supplierId: order.supplierId,
        supplierName: order.supplier.name,
        totalValue: 0,
        orderCount: 0,
      };
      existing.totalValue += Number(order.totalAmount);
      existing.orderCount++;
      supplierMap.set(order.supplierId, existing);
    }
    const topSuppliers = Array.from(supplierMap.values())
      .map((s) => ({
        ...s,
        avgOrderValue: s.orderCount > 0 ? s.totalValue / s.orderCount : 0,
      }))
      .sort((a, b) => b.totalValue - a.totalValue)
      .slice(0, 10);

    // Category breakdown
    const categoryMap = new Map<
      string,
      { category: string; totalValue: number; itemCount: number }
    >();
    for (const order of orders) {
      for (const line of order.lines) {
        const categoryName = line.product?.category?.name || 'Uncategorized';
        const existing = categoryMap.get(categoryName) || {
          category: categoryName,
          totalValue: 0,
          itemCount: 0,
        };
        existing.totalValue += Number(line.totalPrice);
        existing.itemCount++;
        categoryMap.set(categoryName, existing);
      }
    }
    const categoryBreakdown = Array.from(categoryMap.values()).sort(
      (a, b) => b.totalValue - a.totalValue,
    );

    // Price trends for key materials (products with most purchases)
    const productPurchaseMap = new Map<
      string,
      { productId: string; productName: string; prices: number[] }
    >();
    for (const order of orders) {
      for (const line of order.lines) {
        const existing = productPurchaseMap.get(line.productId) || {
          productId: line.productId,
          productName: line.product.name,
          prices: [],
        };
        existing.prices.push(Number(line.unitPrice));
        productPurchaseMap.set(line.productId, existing);
      }
    }
    const priceTrends = Array.from(productPurchaseMap.values())
      .filter((p) => p.prices.length >= 2)
      .map((p) => {
        const avgPrice =
          p.prices.reduce((s, price) => s + price, 0) / p.prices.length;
        const minPrice = Math.min(...p.prices);
        const maxPrice = Math.max(...p.prices);
        const firstPrice = p.prices[0];
        const lastPrice = p.prices[p.prices.length - 1];
        const priceChange =
          firstPrice > 0 ? ((lastPrice - firstPrice) / firstPrice) * 100 : 0;
        return {
          productId: p.productId,
          productName: p.productName,
          avgPrice: Math.round(avgPrice * 10000) / 10000,
          minPrice: Math.round(minPrice * 10000) / 10000,
          maxPrice: Math.round(maxPrice * 10000) / 10000,
          priceChange: Math.round(priceChange * 100) / 100,
        };
      })
      .sort((a, b) => Math.abs(b.priceChange) - Math.abs(a.priceChange))
      .slice(0, 10);

    // Return rate (from RETURN stock movements)
    const returnMovements = await this.prisma.stockMovement.findMany({
      where: {
        type: MovementType.RETURN,
        referenceType: 'PURCHASE_RETURN',
        createdAt: { gte: startDate, lte: endDate },
        productId: {
          in: Array.from(productPurchaseMap.keys()),
        },
      },
    });
    const totalReturnedValue = returnMovements.reduce(
      (s, m) => s + Number(m.totalCost || 0),
      0,
    );
    const returnRate =
      totalPurchaseValue > 0
        ? (totalReturnedValue / totalPurchaseValue) * 100
        : 0;

    // Average lead time (days between PO creation and first stock movement)
    let totalLeadTimeDays = 0;
    let leadTimeCount = 0;
    for (const order of orders) {
      const firstReceipt = await this.prisma.stockMovement.findFirst({
        where: {
          referenceType: 'PURCHASE_ORDER',
          referenceId: order.id,
          type: MovementType.RECEIPT,
        },
        orderBy: { createdAt: 'asc' },
        select: { createdAt: true },
      });
      if (firstReceipt) {
        const leadTimeMs =
          new Date(firstReceipt.createdAt).getTime() -
          new Date(order.createdAt).getTime();
        const leadTimeDays = leadTimeMs / (1000 * 60 * 60 * 24);
        if (leadTimeDays > 0) {
          totalLeadTimeDays += leadTimeDays;
          leadTimeCount++;
        }
      }
    }
    const avgLeadTimeDays =
      leadTimeCount > 0 ? totalLeadTimeDays / leadTimeCount : 0;

    return {
      period: { start: startDate, end: endDate },
      totalPurchaseValue: Math.round(totalPurchaseValue * 100) / 100,
      totalOrders,
      totalItems,
      avgOrderValue: Math.round(avgOrderValue * 100) / 100,
      topSuppliers,
      categoryBreakdown,
      priceTrends,
      returnRate: Math.round(returnRate * 100) / 100,
      avgLeadTimeDays: Math.round(avgLeadTimeDays * 100) / 100,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════════

  private async transitionStatus(
    poId: string,
    companyId: string,
    newStatus: InvoiceStatus,
    notes?: string,
  ) {
    const order = await this.prisma.purchaseOrder.findFirst({
      where: { id: poId, branch: { companyId }, deletedAt: null },
    });
    if (!order) throw new NotFoundException('Purchase order not found');

    const currentStatus = order.status as InvoiceStatus;
    const allowedNext = STATUS_TRANSITIONS[currentStatus] || [];

    if (!allowedNext.includes(newStatus)) {
      throw new ConflictException(
        `Invalid status transition from "${currentStatus}" to "${newStatus}". Allowed: ${allowedNext.join(', ') || 'none'}`,
      );
    }

    const updated = await this.prisma.purchaseOrder.update({
      where: { id: poId },
      data: { status: newStatus },
      include: {
        supplier: { select: { name: true } },
        lines: { include: { product: { select: { name: true } } } },
      },
    });

    this.logger.log(
      `PO ${order.orderNumber}: ${currentStatus} → ${newStatus}${notes ? ` (${notes})` : ''}`,
    );

    return { data: updated, previousStatus: currentStatus };
  }
}
