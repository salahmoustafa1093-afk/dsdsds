import { IsString, IsArray, IsNotEmpty, IsNumber, ValidateNested, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class ReturnItemDto {
  @ApiProperty({ description: 'Purchase order line ID' })
  @IsString()
  @IsNotEmpty()
  lineId: string;

  @ApiProperty({ description: 'Quantity to return' })
  @IsNumber()
  @Min(0.001)
  returnQty: number;

  @ApiProperty({ description: 'Return reason' })
  @IsString()
  @IsNotEmpty()
  reason: string;

  @ApiProperty({ description: 'Unit price at time of purchase' })
  @IsNumber()
  @Min(0)
  unitPrice: number;
}

export class CreateReturnDto {
  @ApiProperty({ description: 'Return items', type: [ReturnItemDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ReturnItemDto)
  items: ReturnItemDto[];

  @ApiProperty({ description: 'Return reason summary' })
  @IsString()
  @IsNotEmpty()
  reason: string;
}
