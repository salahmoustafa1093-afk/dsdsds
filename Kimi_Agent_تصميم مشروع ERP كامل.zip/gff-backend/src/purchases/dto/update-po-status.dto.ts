import { IsString, IsOptional, IsNotEmpty, IsEnum } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { InvoiceStatus } from '@prisma/client';

export class UpdatePurchaseOrderStatusDto {
  @ApiProperty({ description: 'New status', enum: InvoiceStatus })
  @IsEnum(InvoiceStatus)
  @IsNotEmpty()
  status: InvoiceStatus;

  @ApiPropertyOptional({ description: 'Notes or reason for status change' })
  @IsString()
  @IsOptional()
  notes?: string;
}
