import { IsString, IsOptional, IsArray, IsNotEmpty, IsNumber, ValidateNested, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

class ReceivedItemDto {
  @ApiProperty({ description: 'Purchase order line ID' })
  @IsString()
  @IsNotEmpty()
  lineId: string;

  @ApiProperty({ description: 'Total received quantity' })
  @IsNumber()
  @Min(0)
  receivedQty: number;

  @ApiProperty({ description: 'Accepted quantity' })
  @IsNumber()
  @Min(0)
  acceptedQty: number;

  @ApiProperty({ description: 'Rejected quantity' })
  @IsNumber()
  @Min(0)
  rejectedQty: number;

  @ApiPropertyOptional({ description: 'Rejection reason' })
  @IsString()
  @IsOptional()
  rejectionReason?: string;

  @ApiPropertyOptional({ description: 'Batch number' })
  @IsString()
  @IsOptional()
  batchNumber?: string;

  @ApiPropertyOptional({ description: 'Expiry date (ISO string)' })
  @IsString()
  @IsOptional()
  expiryDate?: string;
}

export class ReceiveGoodsDto {
  @ApiProperty({ description: 'Received items', type: [ReceivedItemDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ReceivedItemDto)
  items: ReceivedItemDto[];

  @ApiPropertyOptional({ description: 'Target warehouse ID (defaults to branch main warehouse)' })
  @IsString()
  @IsOptional()
  warehouseId?: string;
}
