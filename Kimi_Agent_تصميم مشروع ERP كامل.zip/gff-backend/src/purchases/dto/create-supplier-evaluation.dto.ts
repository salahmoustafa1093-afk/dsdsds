import { IsString, IsOptional, IsInt, IsNotEmpty, Min, Max } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateSupplierEvaluationDto {
  @ApiProperty({ description: 'Supplier ID' })
  @IsString()
  @IsNotEmpty()
  supplierId: string;

  @ApiProperty({ description: 'Quality score (1-100)', minimum: 1, maximum: 100 })
  @IsInt()
  @Min(1)
  @Max(100)
  qualityScore: number;

  @ApiProperty({ description: 'Price score (1-100)', minimum: 1, maximum: 100 })
  @IsInt()
  @Min(1)
  @Max(100)
  priceScore: number;

  @ApiProperty({ description: 'Delivery score (1-100)', minimum: 1, maximum: 100 })
  @IsInt()
  @Min(1)
  @Max(100)
  deliveryScore: number;

  @ApiProperty({ description: 'Service score (1-100)', minimum: 1, maximum: 100 })
  @IsInt()
  @Min(1)
  @Max(100)
  serviceScore: number;

  @ApiProperty({ description: 'Reliability score (1-100)', minimum: 1, maximum: 100 })
  @IsInt()
  @Min(1)
  @Max(100)
  reliabilityScore: number;

  @ApiProperty({ description: 'Overall score (1-100)', minimum: 1, maximum: 100 })
  @IsInt()
  @Min(1)
  @Max(100)
  overallScore: number;

  @ApiPropertyOptional({ description: 'Evaluation notes' })
  @IsString()
  @IsOptional()
  notes?: string;
}
