import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
  BadRequestException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { InvoiceStatus } from '@prisma/client';
import { PurchasesService } from './purchases.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';

import {
  CreatePurchaseOrderDto,
  UpdatePurchaseOrderDto,
  CreateSupplierDto,
  UpdateSupplierDto,
  CreateSupplierEvaluationDto,
  ReceiveGoodsDto,
  CreateReturnDto,
  UpdatePurchaseOrderStatusDto,
} from './dto';

@ApiTags('Purchases')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('purchases')
export class PurchasesController {
  constructor(private readonly purchasesService: PurchasesService) {}

  // ═══════════════════════════════════════════════════════════
  // PURCHASE ORDERS
  // ═══════════════════════════════════════════════════════════

  @Get('orders')
  @Permissions('purchases:view')
  @ApiOperation({ summary: 'List purchase orders' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'status', required: false, enum: InvoiceStatus })
  @ApiQuery({ name: 'supplierId', required: false })
  @ApiQuery({ name: 'branchId', required: false })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiResponse({ status: 200, description: 'Purchase orders retrieved' })
  async findAllOrders(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
    @Query('supplierId') supplierId?: string,
    @Query('branchId') branchId?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    return this.purchasesService.findAll(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      status,
      supplierId,
      branchId,
      startDate,
      endDate,
    });
  }

  @Get('orders/:id')
  @Permissions('purchases:view')
  @ApiOperation({ summary: 'Get a single purchase order' })
  @ApiResponse({ status: 200, description: 'Purchase order retrieved' })
  @ApiResponse({ status: 404, description: 'Not found' })
  async findOneOrder(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.findOne(id, companyId);
  }

  @Post('orders')
  @Permissions('purchases:create')
  @ApiOperation({ summary: 'Create a purchase order' })
  @ApiResponse({ status: 201, description: 'Purchase order created' })
  @ApiResponse({ status: 400, description: 'Bad request' })
  async createOrder(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreatePurchaseOrderDto,
  ) {
    return this.purchasesService.create(companyId, dto);
  }

  @Put('orders/:id')
  @Permissions('purchases:update')
  @ApiOperation({ summary: 'Update a purchase order (DRAFT only)' })
  @ApiResponse({ status: 200, description: 'Purchase order updated' })
  @ApiResponse({ status: 400, description: 'Bad request' })
  @ApiResponse({ status: 404, description: 'Not found' })
  @ApiResponse({ status: 409, description: 'Conflict — PO not in DRAFT' })
  async updateOrder(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdatePurchaseOrderDto,
  ) {
    return this.purchasesService.update(id, companyId, dto);
  }

  @Delete('orders/:id')
  @Permissions('purchases:delete')
  @ApiOperation({ summary: 'Soft-delete a purchase order (DRAFT only)' })
  @ApiResponse({ status: 200, description: 'Purchase order deleted' })
  @ApiResponse({ status: 404, description: 'Not found' })
  @ApiResponse({ status: 409, description: 'Conflict — PO not in DRAFT' })
  async deleteOrder(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.remove(id, companyId);
  }

  // ═══════════════════════════════════════════════════════════
  // PURCHASE ORDER STATUS WORKFLOW
  // ═══════════════════════════════════════════════════════════

  @Put('orders/:id/status')
  @Permissions('purchases:update')
  @ApiOperation({ summary: 'Update purchase order status' })
  @ApiResponse({ status: 200, description: 'Status updated' })
  @ApiResponse({ status: 400, description: 'Invalid transition' })
  @ApiResponse({ status: 404, description: 'Not found' })
  async updateOrderStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdatePurchaseOrderStatusDto,
  ) {
    return this.purchasesService.updateStatus(id, companyId, dto.status, dto.notes);
  }

  @Post('orders/:id/confirm')
  @Permissions('purchases:approve')
  @ApiOperation({ summary: 'Confirm a DRAFT purchase order' })
  @ApiResponse({ status: 200, description: 'Order confirmed' })
  async confirmOrder(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.confirmOrder(id, companyId);
  }

  @Post('orders/:id/send')
  @Permissions('purchases:update')
  @ApiOperation({ summary: 'Mark purchase order as sent to supplier' })
  @ApiResponse({ status: 200, description: 'Order marked as sent' })
  async markAsSent(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.markAsSent(id, companyId);
  }

  @Post('orders/:id/close')
  @Permissions('purchases:update')
  @ApiOperation({ summary: 'Close a delivered purchase order (mark as PAID)' })
  @ApiResponse({ status: 200, description: 'Order closed' })
  async closeOrder(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.closeOrder(id, companyId);
  }

  @Post('orders/:id/cancel')
  @Permissions('purchases:update')
  @ApiOperation({ summary: 'Cancel a purchase order' })
  @ApiResponse({ status: 200, description: 'Order cancelled' })
  async cancelOrder(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body('reason') reason?: string,
  ) {
    return this.purchasesService.cancelOrder(id, companyId, reason);
  }

  // ═══════════════════════════════════════════════════════════
  // GOODS RECEIPT
  // ═══════════════════════════════════════════════════════════

  @Post('orders/:id/receive')
  @Permissions('purchases:receive')
  @ApiOperation({ summary: 'Receive goods against a purchase order' })
  @ApiResponse({ status: 200, description: 'Goods received' })
  @ApiResponse({ status: 400, description: 'Bad request' })
  @ApiResponse({ status: 404, description: 'PO not found' })
  @ApiResponse({ status: 409, description: 'PO not in receivable status' })
  async receiveGoods(
    @Param('id', ParseUUIDPipe) poId: string,
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('id') userId: string,
    @Body() dto: ReceiveGoodsDto,
  ) {
    return this.purchasesService.receiveGoods(poId, companyId, dto, userId);
  }

  // ═══════════════════════════════════════════════════════════
  // PURCHASE RETURNS
  // ═══════════════════════════════════════════════════════════

  @Post('orders/:id/returns')
  @Permissions('purchases:return')
  @ApiOperation({ summary: 'Create a purchase return' })
  @ApiResponse({ status: 200, description: 'Return processed' })
  @ApiResponse({ status: 400, description: 'Bad request' })
  @ApiResponse({ status: 404, description: 'PO not found' })
  async createReturn(
    @Param('id', ParseUUIDPipe) poId: string,
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('id') userId: string,
    @Body() dto: CreateReturnDto,
  ) {
    return this.purchasesService.createReturn(poId, companyId, dto, userId);
  }

  // ═══════════════════════════════════════════════════════════
  // THREE-WAY MATCHING
  // ═══════════════════════════════════════════════════════════

  @Post('orders/:id/three-way-match')
  @Permissions('purchases:view')
  @ApiOperation({ summary: 'Perform 3-way matching on a PO' })
  @ApiResponse({ status: 200, description: '3-way match completed' })
  @ApiResponse({ status: 400, description: 'No receipts found' })
  @ApiResponse({ status: 404, description: 'PO not found' })
  async performThreeWayMatch(
    @Param('id', ParseUUIDPipe) poId: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.performThreeWayMatch(poId, companyId);
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPLIERS
  // ═══════════════════════════════════════════════════════════

  @Get('suppliers')
  @Permissions('suppliers:view')
  @ApiOperation({ summary: 'List suppliers' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiResponse({ status: 200, description: 'Suppliers retrieved' })
  async findAllSuppliers(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
    @Query('search') search?: string,
  ) {
    return this.purchasesService.findAllSuppliers(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      status,
      search,
    });
  }

  @Get('suppliers/:id')
  @Permissions('suppliers:view')
  @ApiOperation({ summary: 'Get a single supplier' })
  @ApiResponse({ status: 200, description: 'Supplier retrieved' })
  @ApiResponse({ status: 404, description: 'Not found' })
  async findOneSupplier(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.findOneSupplier(id, companyId);
  }

  @Post('suppliers')
  @Permissions('suppliers:create')
  @ApiOperation({ summary: 'Create a supplier' })
  @ApiResponse({ status: 201, description: 'Supplier created' })
  @ApiResponse({ status: 409, description: 'Code already exists' })
  async createSupplier(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateSupplierDto,
  ) {
    // Override companyId from auth context for security
    return this.purchasesService.createSupplier({ ...dto, companyId });
  }

  @Put('suppliers/:id')
  @Permissions('suppliers:update')
  @ApiOperation({ summary: 'Update a supplier' })
  @ApiResponse({ status: 200, description: 'Supplier updated' })
  @ApiResponse({ status: 404, description: 'Not found' })
  @ApiResponse({ status: 409, description: 'Code already exists' })
  async updateSupplier(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateSupplierDto,
  ) {
    return this.purchasesService.updateSupplier(id, companyId, dto);
  }

  @Delete('suppliers/:id')
  @Permissions('suppliers:delete')
  @ApiOperation({ summary: 'Soft-delete a supplier' })
  @ApiResponse({ status: 200, description: 'Supplier deleted' })
  @ApiResponse({ status: 404, description: 'Not found' })
  @ApiResponse({ status: 409, description: 'Has active POs' })
  async deleteSupplier(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.deleteSupplier(id, companyId);
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPLIER EVALUATION
  // ═══════════════════════════════════════════════════════════

  @Get('suppliers/:id/evaluations')
  @Permissions('suppliers:view')
  @ApiOperation({ summary: 'Get supplier evaluations' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiResponse({ status: 200, description: 'Evaluations retrieved' })
  async findSupplierEvaluations(
    @Param('id', ParseUUIDPipe) supplierId: string,
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.purchasesService.findSupplierEvaluations(supplierId, companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
    });
  }

  @Post('suppliers/:id/evaluations')
  @Permissions('suppliers:evaluate')
  @ApiOperation({ summary: 'Evaluate a supplier' })
  @ApiResponse({ status: 201, description: 'Evaluation created' })
  @ApiResponse({ status: 404, description: 'Supplier not found' })
  async createEvaluation(
    @Param('id', ParseUUIDPipe) supplierId: string,
    @CurrentUser('id') userId: string,
    @Body() dto: CreateSupplierEvaluationDto,
  ) {
    // Enforce supplierId from path parameter for security
    return this.purchasesService.createEvaluation(
      { ...dto, supplierId },
      userId,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPLIER PERFORMANCE
  // ═══════════════════════════════════════════════════════════

  @Get('suppliers/:id/performance')
  @Permissions('suppliers:view')
  @ApiOperation({ summary: 'Get supplier performance metrics' })
  @ApiResponse({ status: 200, description: 'Performance data retrieved' })
  @ApiResponse({ status: 404, description: 'Supplier not found' })
  async getSupplierPerformance(
    @Param('id', ParseUUIDPipe) supplierId: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return {
      data: await this.purchasesService.trackSupplierPerformance(
        supplierId,
        companyId,
      ),
    };
  }

  @Get('suppliers/performance/all')
  @Permissions('suppliers:view')
  @ApiOperation({ summary: 'Get performance for all suppliers' })
  @ApiResponse({ status: 200, description: 'Performance data retrieved' })
  async getAllSupplierPerformance(
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.purchasesService.getAllSupplierPerformance(companyId);
  }

  // ═══════════════════════════════════════════════════════════
  // PURCHASE ANALYTICS
  // ═══════════════════════════════════════════════════════════

  @Get('analytics')
  @Permissions('purchases:view')
  @ApiOperation({ summary: 'Get purchase analytics' })
  @ApiQuery({ name: 'startDate', required: true })
  @ApiQuery({ name: 'endDate', required: true })
  @ApiResponse({ status: 200, description: 'Analytics retrieved' })
  @ApiResponse({ status: 400, description: 'Invalid date range' })
  async getPurchaseAnalytics(
    @CurrentUser('companyId') companyId: string,
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      throw new BadRequestException('Invalid date format');
    }
    return {
      data: await this.purchasesService.getPurchaseAnalytics(
        companyId,
        start,
        end,
      ),
    };
  }
}
