import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { UserStatus } from '@prisma/client';
import { PrismaService } from '@/prisma/prisma.service';
import {
  CreateSupplierDto,
  UpdateSupplierDto,
  CreateSupplierEvaluationDto,
} from './dto';

@Injectable()
export class SuppliersService {
  private readonly logger = new Logger(SuppliersService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findAll(companyId: string, options: { page?: number; limit?: number; search?: string; status?: UserStatus }) {
    const { page = 1, limit = 10, search, status } = options;
    const skip = (page - 1) * limit;

    const where: any = { companyId, deletedAt: null };
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.supplier.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { purchaseOrders: true, supplierEvaluations: true } },
        },
      }),
      this.prisma.supplier.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOne(id: string, companyId: string) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        supplierEvaluations: { orderBy: { createdAt: 'desc' }, take: 10 },
      },
    });

    if (!supplier) throw new NotFoundException(`Supplier with ID ${id} not found`);
    return { data: supplier };
  }

  async create(companyId: string, dto: CreateSupplierDto) {
    if (dto.email) {
      const existing = await this.prisma.supplier.findFirst({
        where: { email: dto.email, companyId },
      });
      if (existing) throw new ConflictException('Supplier email already exists');
    }

    const supplier = await this.prisma.supplier.create({
      data: { ...dto, companyId },
    });

    this.logger.log(`Supplier created: ${supplier.name}`);
    return { data: supplier };
  }

  async update(id: string, companyId: string, dto: UpdateSupplierDto) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException(`Supplier with ID ${id} not found`);

    const updated = await this.prisma.supplier.update({
      where: { id },
      data: dto,
    });

    return { data: updated };
  }

  async remove(id: string, companyId: string) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException(`Supplier with ID ${id} not found`);

    await this.prisma.supplier.update({
      where: { id },
      data: { deletedAt: new Date(), status: UserStatus.INACTIVE },
    });

    return { data: { message: 'Supplier deleted successfully' } };
  }

  // Evaluations
  async getEvaluations(id: string, companyId: string) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException(`Supplier with ID ${id} not found`);

    const evaluations = await this.prisma.supplierEvaluation.findMany({
      where: { supplierId: id },
      orderBy: { createdAt: 'desc' },
    });

    const avgOverall = evaluations.length > 0
      ? evaluations.reduce((sum, e) => sum + Number(e.overallScore), 0) / evaluations.length
      : 0;

    return { data: { evaluations, averageOverallScore: Number(avgOverall.toFixed(2)) } };
  }

  async createEvaluation(
    id: string,
    companyId: string,
    dto: CreateSupplierEvaluationDto,
    evaluatedBy?: string,
  ) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException(`Supplier with ID ${id} not found`);

    const evaluation = await this.prisma.supplierEvaluation.create({
      data: {
        supplierId: id,
        qualityScore: dto.qualityScore,
        priceScore: dto.priceScore,
        deliveryScore: dto.deliveryScore,
        serviceScore: dto.serviceScore,
        reliabilityScore: dto.reliabilityScore,
        overallScore: dto.overallScore,
        notes: dto.notes,
        evaluatedBy: evaluatedBy || 'system',
      },
    });

    // Update supplier rating
    const allEvals = await this.prisma.supplierEvaluation.findMany({
      where: { supplierId: id },
    });
    const avgOverall =
      allEvals.reduce((sum, e) => sum + Number(e.overallScore), 0) / allEvals.length;

    await this.prisma.supplier.update({
      where: { id },
      data: { rating: avgOverall },
    });

    return { data: evaluation };
  }

  // Products catalog — derived from purchase order lines (no supplierProduct table)
  async getProducts(id: string, companyId: string) {
    const supplier = await this.prisma.supplier.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!supplier) throw new NotFoundException(`Supplier with ID ${id} not found`);

    const poLines = await this.prisma.purchaseOrderLine.findMany({
      where: { order: { supplierId: id } },
      include: {
        product: { select: { id: true, name: true, code: true, type: true } },
      },
      distinct: ['productId'],
    });

    return { data: poLines.map((l) => ({ ...l, supplierId: id })) };
  }
}
