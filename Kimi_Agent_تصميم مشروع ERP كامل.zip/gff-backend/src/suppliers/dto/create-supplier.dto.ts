import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsNumber,
  IsEmail,
  IsEnum,
} from 'class-validator';
import { SupplierType, UserStatus } from '@prisma/client';

export class CreateSupplierDto {
  @ApiProperty({ example: 'Golden Feed Supplies Co.' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(150)
  name: string;

  @ApiProperty({ example: 'SUP-001', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  code?: string;

  @ApiProperty({ example: 'sales@goldenfeed.com', required: false })
  @IsOptional()
  @IsEmail()
  @MaxLength(150)
  email?: string;

  @ApiProperty({ example: '+96265551000', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  phone?: string;

  @ApiProperty({ example: 'Industrial Area, St. 20', required: false })
  @IsOptional()
  @IsString()
  address?: string;

  @ApiProperty({ example: 'Amman', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  city?: string;

  @ApiProperty({ example: '98765432', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  taxNumber?: string;

  @ApiProperty({ example: 'LOCAL', enum: SupplierType, required: false })
  @IsOptional()
  @IsEnum(SupplierType)
  type?: SupplierType;

  @ApiProperty({ example: 'Reliable supplier, fast delivery', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class UpdateSupplierDto {
  @ApiProperty({ example: 'Golden Feed Supplies Co.', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(150)
  name?: string;

  @ApiProperty({ example: 'sales@goldenfeed.com', required: false })
  @IsOptional()
  @IsEmail()
  email?: string;

  @ApiProperty({ example: '+96265551000', required: false })
  @IsOptional()
  @IsString()
  phone?: string;

  @ApiProperty({ example: 'Updated notes', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class CreateSupplierEvaluationDto {
  @ApiProperty({ example: 4.5, required: false })
  @IsOptional()
  @IsNumber()
  qualityScore?: number;

  @ApiProperty({ example: 4.0, required: false })
  @IsOptional()
  @IsNumber()
  priceScore?: number;

  @ApiProperty({ example: 4.5, required: false })
  @IsOptional()
  @IsNumber()
  deliveryScore?: number;

  @ApiProperty({ example: 4.0, required: false })
  @IsOptional()
  @IsNumber()
  serviceScore?: number;

  @ApiProperty({ example: 4.5, required: false })
  @IsOptional()
  @IsNumber()
  reliabilityScore?: number;

  @ApiProperty({ example: 4.3, required: false })
  @IsOptional()
  @IsNumber()
  overallScore?: number;

  @ApiProperty({ example: 'Excellent product quality', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}
