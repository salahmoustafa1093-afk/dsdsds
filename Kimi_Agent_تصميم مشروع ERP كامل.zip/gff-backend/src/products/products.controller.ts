import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateProductDto,
  UpdateProductDto,
  CreateCategoryDto,
  UpdateCategoryDto,
  CreateUnitDto,
  UpdateUnitDto,
  CreatePriceListDto,
  UpdatePriceListDto,
  UpdatePriceDto,
  FilterProductsDto,
  StockAlertQueryDto,
} from './dto';

@ApiTags('Products')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  // ═══════════════════════════════════════════
  // Products
  // ═══════════════════════════════════════════

  @Get()
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List products' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'categoryId', required: false })
  @ApiQuery({ name: 'categoryType', required: false })
  @ApiResponse({ status: 200, description: 'Products retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAll(
    @CurrentUser('companyId') companyId: string,
    @Query() filters: FilterProductsDto,
  ) {
    return this.productsService.findAll(companyId, filters);
  }

  @Get('barcode/:barcode')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get product by barcode' })
  @ApiResponse({ status: 200, description: 'Product retrieved' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findByBarcode(
    @Param('barcode') barcode: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productsService.findByBarcode(barcode, companyId);
  }

  @Get('alerts/low-stock')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get low stock products' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiResponse({ status: 200, description: 'Low stock alerts retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getLowStockProducts(
    @CurrentUser('companyId') companyId: string,
    @Query() query: StockAlertQueryDto,
  ) {
    return this.productsService.getLowStockProducts(companyId, query);
  }

  @Get('analytics/top-selling')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get top selling products' })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiResponse({ status: 200, description: 'Top selling products retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getTopSelling(
    @CurrentUser('companyId') companyId: string,
    @Query('limit') limit?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    return this.productsService.getTopSelling(companyId, {
      limit: limit ? parseInt(limit) : 10,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
    });
  }

  @Get('analytics/profitability')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get product profitability report' })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiResponse({ status: 200, description: 'Profitability report retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getProfitability(
    @CurrentUser('companyId') companyId: string,
    @Query('limit') limit?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    return this.productsService.getProfitability(companyId, {
      limit: limit ? parseInt(limit) : 10,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
    });
  }

  @Get('summary/inventory')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get inventory summary dashboard' })
  @ApiResponse({ status: 200, description: 'Inventory summary retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getInventorySummary(
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productsService.getInventorySummary(companyId);
  }

  @Get(':id')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get product by ID' })
  @ApiResponse({ status: 200, description: 'Product retrieved' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productsService.findOne(id, companyId);
  }

  @Post()
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create product' })
  @ApiResponse({ status: 201, description: 'Product created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async create(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateProductDto,
  ) {
    return this.productsService.create(companyId, dto);
  }

  @Put(':id')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update product' })
  @ApiResponse({ status: 200, description: 'Product updated' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateProductDto,
  ) {
    return this.productsService.update(id, companyId, dto);
  }

  @Delete(':id')
  @Permissions('inventory:delete')
  @ApiOperation({ summary: 'Soft delete product' })
  @ApiResponse({ status: 200, description: 'Product deleted' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productsService.remove(id, companyId);
  }

  // ═══════════════════════════════════════════
  // Categories
  // ═══════════════════════════════════════════

  @Get('categories/all')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List all categories' })
  @ApiResponse({ status: 200, description: 'Categories retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllCategories() {
    return this.productsService.findAllCategories();
  }

  @Post('categories')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create category' })
  @ApiResponse({ status: 201, description: 'Category created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createCategory(
    @Body() dto: CreateCategoryDto,
  ) {
    return this.productsService.createCategory(dto);
  }

  @Put('categories/:id')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update category' })
  @ApiResponse({ status: 200, description: 'Category updated' })
  @ApiResponse({ status: 404, description: 'Category not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateCategory(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateCategoryDto,
  ) {
    return this.productsService.updateCategory(id, dto);
  }

  @Delete('categories/:id')
  @Permissions('inventory:delete')
  @ApiOperation({ summary: 'Delete category' })
  @ApiResponse({ status: 200, description: 'Category deleted' })
  @ApiResponse({ status: 404, description: 'Category not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async removeCategory(
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return this.productsService.removeCategory(id);
  }

  // ═══════════════════════════════════════════
  // Units
  // ═══════════════════════════════════════════

  @Get('units/all')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List all units' })
  @ApiResponse({ status: 200, description: 'Units retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllUnits() {
    return this.productsService.findAllUnits();
  }

  @Post('units')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create unit' })
  @ApiResponse({ status: 201, description: 'Unit created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createUnit(
    @Body() dto: CreateUnitDto,
  ) {
    return this.productsService.createUnit(dto);
  }

  @Put('units/:id')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update unit' })
  @ApiResponse({ status: 200, description: 'Unit updated' })
  @ApiResponse({ status: 404, description: 'Unit not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateUnit(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateUnitDto,
  ) {
    return this.productsService.updateUnit(id, dto);
  }

  @Delete('units/:id')
  @Permissions('inventory:delete')
  @ApiOperation({ summary: 'Delete unit' })
  @ApiResponse({ status: 200, description: 'Unit deleted' })
  @ApiResponse({ status: 404, description: 'Unit not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async removeUnit(
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return this.productsService.removeUnit(id);
  }

  // ═══════════════════════════════════════════
  // Price Lists
  // ═══════════════════════════════════════════

  @Get(':id/price-lists')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get product price lists' })
  @ApiResponse({ status: 200, description: 'Price lists retrieved' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findPriceLists(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productsService.findPriceLists(id, companyId);
  }

  @Post('price-lists')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create price list entry' })
  @ApiResponse({ status: 201, description: 'Price list created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createPriceList(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreatePriceListDto,
  ) {
    return this.productsService.createPriceList(dto, companyId);
  }

  @Put('price-lists/:id')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update price list entry' })
  @ApiResponse({ status: 200, description: 'Price list updated' })
  @ApiResponse({ status: 404, description: 'Price list not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updatePriceList(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdatePriceListDto,
  ) {
    return this.productsService.updatePriceList(id, dto);
  }

  @Delete('price-lists/:id')
  @Permissions('inventory:delete')
  @ApiOperation({ summary: 'Delete price list entry' })
  @ApiResponse({ status: 200, description: 'Price list deleted' })
  @ApiResponse({ status: 404, description: 'Price list not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async removePriceList(
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return this.productsService.removePriceList(id);
  }

  // ═══════════════════════════════════════════
  // Price Update (direct product price)
  // ═══════════════════════════════════════════

  @Post(':id/update-price')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update product price directly' })
  @ApiResponse({ status: 200, description: 'Price updated' })
  @ApiResponse({ status: 404, description: 'Product not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updatePrice(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdatePriceDto,
  ) {
    return this.productsService.updatePrice(id, companyId, dto);
  }
}
