import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  Prisma,
  UserStatus,
  InvoiceStatus,
} from '@prisma/client';
import type {
  Product,
  ProductCategory,
  UnitOfMeasure,
  PriceList,
} from '@prisma/client';
import {
  CreateProductDto,
  UpdateProductDto,
  CreateCategoryDto,
  UpdateCategoryDto,
  CreateUnitDto,
  UpdateUnitDto,
  CreatePriceListDto,
  UpdatePriceListDto,
  UpdatePriceDto,
  FilterProductsDto,
  StockAlertQueryDto,
} from './dto';

// ─────────────────────────────────────────────
// Type definitions for return shapes
// ─────────────────────────────────────────────

interface ProductWithRelations extends Product {
  category: Pick<ProductCategory, 'id' | 'name' | 'code' | 'type'>;
  unit: Pick<UnitOfMeasure, 'id' | 'name' | 'code'>;
}

interface CategoryWithRelations extends ProductCategory {
  parent: Pick<ProductCategory, 'id' | 'name'> | null;
  children: Array<Pick<ProductCategory, 'id' | 'name'>>;
  _count: { products: number };
}

interface PriceListWithRelations extends PriceList {
  product: Pick<Product, 'id' | 'code' | 'name'>;
  customerCategory: { id: string; name: string } | null;
}

interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

interface PaginatedResult<T> {
  data: T[];
  meta: PaginationMeta;
}

@Injectable()
export class ProductsService {
  private readonly logger = new Logger(ProductsService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════
  // Helpers
  // ═══════════════════════════════════════════

  private buildProductWhere(
    companyId: string,
    filters: Pick<FilterProductsDto, 'search' | 'categoryId' | 'categoryType'>,
  ): Prisma.ProductWhereInput {
    const where: Prisma.ProductWhereInput = {
      companyId,
      deletedAt: null,
    };

    if (filters.categoryId) {
      where.categoryId = filters.categoryId;
    }

    if (filters.categoryType) {
      where.category = { type: filters.categoryType };
    }

    if (filters.search) {
      where.OR = [
        { name: { contains: filters.search, mode: 'insensitive' } },
        { code: { contains: filters.search, mode: 'insensitive' } },
        { barcode: { contains: filters.search } },
      ];
    }

    return where;
  }

  private computePaginationMeta(
    page: number,
    limit: number,
    total: number,
  ): PaginationMeta {
    return {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    };
  }

  /**
   * Calculate current stock level for a product by summing all stock movements.
   */
  async getCurrentStock(productId: string): Promise<number> {
    const result = await this.prisma.stockMovement.aggregate({
      where: { productId },
      _sum: { quantity: true },
    });

    return Number(result._sum.quantity ?? 0);
  }

  /**
   * Get stock levels for multiple products at once.
   */
  async getStockLevels(productIds: string[]): Promise<Map<string, number>> {
    if (productIds.length === 0) return new Map();

    const movements = await this.prisma.stockMovement.groupBy({
      by: ['productId'],
      where: { productId: { in: productIds } },
      _sum: { quantity: true },
    });

    const levels = new Map<string, number>();
    for (const m of movements) {
      levels.set(m.productId, Number(m._sum.quantity ?? 0));
    }
    return levels;
  }

  // ═══════════════════════════════════════════
  // Product CRUD
  // ═══════════════════════════════════════════

  async findAll(
    companyId: string,
    filters: FilterProductsDto,
  ): Promise<PaginatedResult<ProductWithRelations>> {
    const page = filters.page ?? 1;
    const limit = filters.limit ?? 10;
    const skip = (page - 1) * limit;

    const where = this.buildProductWhere(companyId, filters);

    const [data, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          category: { select: { id: true, name: true, code: true, type: true } },
          unit: { select: { id: true, name: true, code: true } },
        },
      }),
      this.prisma.product.count({ where }),
    ]);

    return { data: data as ProductWithRelations[], meta: this.computePaginationMeta(page, limit, total) };
  }

  async findOne(
    id: string,
    companyId: string,
  ): Promise<{ data: ProductWithRelations & { currentStock: number } }> {
    const product = await this.prisma.product.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        category: true,
        unit: true,
        priceLists: {
          where: {
            effectiveFrom: { lte: new Date() },
            OR: [{ effectiveTo: null }, { effectiveTo: { gte: new Date() } }],
          },
          orderBy: { unitPrice: 'asc' },
        },
        stockMovements: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: {
            warehouse: { select: { id: true, name: true } },
          },
        },
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    const currentStock = await this.getCurrentStock(id);

    return { data: { ...product, currentStock } };
  }

  async create(
    companyId: string,
    dto: CreateProductDto,
  ): Promise<{ data: ProductWithRelations }> {
    const existing = await this.prisma.product.findFirst({
      where: { code: dto.code, companyId },
    });
    if (existing) {
      throw new ConflictException('Product code already exists');
    }

    // Verify category exists
    const category = await this.prisma.productCategory.findUnique({
      where: { id: dto.categoryId },
    });
    if (!category) {
      throw new BadRequestException(
        `Category with ID ${dto.categoryId} not found`,
      );
    }

    // Verify unit exists
    const unit = await this.prisma.unitOfMeasure.findUnique({
      where: { id: dto.unitId },
    });
    if (!unit) {
      throw new BadRequestException(`Unit with ID ${dto.unitId} not found`);
    }

    // Check barcode uniqueness if provided
    if (dto.barcode) {
      const barcodeExists = await this.prisma.product.findFirst({
        where: { barcode: dto.barcode, companyId },
      });
      if (barcodeExists) {
        throw new ConflictException('Barcode already in use');
      }
    }

    const product = await this.prisma.product.create({
      data: {
        code: dto.code,
        name: dto.name,
        description: dto.description,
        barcode: dto.barcode,
        avgCost: dto.avgCost,
        salePrice: dto.salePrice,
        minStockLevel: dto.minStockLevel ?? 0,
        maxStockLevel: dto.maxStockLevel ?? 0,
        reorderPoint: dto.reorderPoint ?? 0,
        weight: dto.weight,
        status: dto.status ?? UserStatus.ACTIVE,
        categoryId: dto.categoryId,
        unitId: dto.unitId,
        companyId,
      },
      include: {
        category: { select: { id: true, name: true, code: true, type: true } },
        unit: { select: { id: true, name: true, code: true } },
      },
    });

    this.logger.log(`Product created: ${product.code} (${product.name})`);
    return { data: product as ProductWithRelations };
  }

  async update(
    id: string,
    companyId: string,
    dto: UpdateProductDto,
  ): Promise<{ data: ProductWithRelations }> {
    const product = await this.prisma.product.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    // Check code uniqueness if being changed
    if (dto.code && dto.code !== product.code) {
      const codeExists = await this.prisma.product.findFirst({
        where: { code: dto.code, companyId },
      });
      if (codeExists) {
        throw new ConflictException('Product code already exists');
      }
    }

    // Check barcode uniqueness if being changed
    if (dto.barcode && dto.barcode !== product.barcode) {
      const barcodeExists = await this.prisma.product.findFirst({
        where: { barcode: dto.barcode, companyId },
      });
      if (barcodeExists) {
        throw new ConflictException('Barcode already in use');
      }
    }

    // Verify new category if provided
    if (dto.categoryId) {
      const category = await this.prisma.productCategory.findUnique({
        where: { id: dto.categoryId },
      });
      if (!category) {
        throw new BadRequestException(
          `Category with ID ${dto.categoryId} not found`,
        );
      }
    }

    // Verify new unit if provided
    if (dto.unitId) {
      const unit = await this.prisma.unitOfMeasure.findUnique({
        where: { id: dto.unitId },
      });
      if (!unit) {
        throw new BadRequestException(`Unit with ID ${dto.unitId} not found`);
      }
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: {
        code: dto.code,
        name: dto.name,
        description: dto.description,
        barcode: dto.barcode,
        avgCost: dto.avgCost,
        salePrice: dto.salePrice,
        minStockLevel: dto.minStockLevel,
        maxStockLevel: dto.maxStockLevel,
        reorderPoint: dto.reorderPoint,
        weight: dto.weight,
        status: dto.status,
        categoryId: dto.categoryId,
        unitId: dto.unitId,
      },
      include: {
        category: { select: { id: true, name: true, code: true, type: true } },
        unit: { select: { id: true, name: true, code: true } },
      },
    });

    this.logger.log(`Product updated: ${updated.code} (${updated.name})`);
    return { data: updated as ProductWithRelations };
  }

  async remove(
    id: string,
    companyId: string,
  ): Promise<{ data: { message: string } }> {
    const product = await this.prisma.product.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    await this.prisma.product.update({
      where: { id },
      data: { deletedAt: new Date(), status: UserStatus.INACTIVE },
    });

    this.logger.log(`Product soft-deleted: ${product.code}`);
    return { data: { message: 'Product deleted successfully' } };
  }

  // ═══════════════════════════════════════════
  // Barcode
  // ═══════════════════════════════════════════

  async findByBarcode(
    barcode: string,
    companyId: string,
  ): Promise<{ data: ProductWithRelations & { currentStock: number } }> {
    const product = await this.prisma.product.findFirst({
      where: { barcode, companyId, deletedAt: null },
      include: {
        category: { select: { id: true, name: true, code: true, type: true } },
        unit: { select: { id: true, name: true, code: true } },
      },
    });

    if (!product) {
      throw new NotFoundException(`Product with barcode ${barcode} not found`);
    }

    const currentStock = await this.getCurrentStock(product.id);

    return { data: { ...product, currentStock } };
  }

  // ═══════════════════════════════════════════
  // Categories (hierarchical)
  // ═══════════════════════════════════════════

  async findAllCategories(): Promise<{ data: CategoryWithRelations[] }> {
    const categories = await this.prisma.productCategory.findMany({
      include: {
        parent: { select: { id: true, name: true } },
        children: { select: { id: true, name: true } },
        _count: { select: { products: true } },
      },
      orderBy: { name: 'asc' },
    });

    return { data: categories as CategoryWithRelations[] };
  }

  async createCategory(
    dto: CreateCategoryDto,
  ): Promise<{ data: ProductCategory }> {
    // Verify parent exists if provided
    if (dto.parentId) {
      const parent = await this.prisma.productCategory.findUnique({
        where: { id: dto.parentId },
      });
      if (!parent) {
        throw new BadRequestException(
          `Parent category with ID ${dto.parentId} not found`,
        );
      }
    }

    // Check code uniqueness
    const codeExists = await this.prisma.productCategory.findUnique({
      where: { code: dto.code },
    });
    if (codeExists) {
      throw new ConflictException('Category code already exists');
    }

    const category = await this.prisma.productCategory.create({
      data: {
        name: dto.name,
        code: dto.code,
        type: dto.type,
        parentId: dto.parentId,
      },
    });

    this.logger.log(`Category created: ${category.code} (${category.name})`);
    return { data: category };
  }

  async updateCategory(
    id: string,
    dto: UpdateCategoryDto,
  ): Promise<{ data: ProductCategory }> {
    const category = await this.prisma.productCategory.findUnique({
      where: { id },
    });
    if (!category) {
      throw new NotFoundException('Category not found');
    }

    // Verify parent exists if provided
    if (dto.parentId) {
      const parent = await this.prisma.productCategory.findUnique({
        where: { id: dto.parentId },
      });
      if (!parent) {
        throw new BadRequestException(
          `Parent category with ID ${dto.parentId} not found`,
        );
      }
      // Prevent circular reference
      if (dto.parentId === id) {
        throw new BadRequestException('Category cannot be its own parent');
      }
    }

    // Check code uniqueness if being changed
    if (dto.code && dto.code !== category.code) {
      const codeExists = await this.prisma.productCategory.findUnique({
        where: { code: dto.code },
      });
      if (codeExists) {
        throw new ConflictException('Category code already exists');
      }
    }

    const updated = await this.prisma.productCategory.update({
      where: { id },
      data: {
        name: dto.name,
        code: dto.code,
        type: dto.type,
        parentId: dto.parentId,
      },
    });

    this.logger.log(`Category updated: ${updated.code} (${updated.name})`);
    return { data: updated };
  }

  async removeCategory(
    id: string,
  ): Promise<{ data: { message: string } }> {
    const category = await this.prisma.productCategory.findUnique({
      where: { id },
      include: {
        _count: { select: { products: true, children: true } },
      },
    });
    if (!category) {
      throw new NotFoundException('Category not found');
    }

    if ((category._count?.products ?? 0) > 0) {
      throw new ConflictException('Cannot delete category with products');
    }

    if ((category._count?.children ?? 0) > 0) {
      throw new ConflictException(
        'Cannot delete category with sub-categories. Remove sub-categories first.',
      );
    }

    await this.prisma.productCategory.delete({ where: { id } });
    this.logger.log(`Category deleted: ${category.code}`);
    return { data: { message: 'Category deleted successfully' } };
  }

  // ═══════════════════════════════════════════
  // Units of Measure
  // ═══════════════════════════════════════════

  async findAllUnits(): Promise<{ data: UnitOfMeasure[] }> {
    const units = await this.prisma.unitOfMeasure.findMany({
      orderBy: { name: 'asc' },
    });
    return { data: units };
  }

  async createUnit(dto: CreateUnitDto): Promise<{ data: UnitOfMeasure }> {
    const existing = await this.prisma.unitOfMeasure.findUnique({
      where: { code: dto.code },
    });
    if (existing) {
      throw new ConflictException('Unit code already exists');
    }

    const unit = await this.prisma.unitOfMeasure.create({
      data: {
        name: dto.name,
        code: dto.code,
        conversionRate: dto.conversionRate ?? 1,
        baseUnit: dto.baseUnit,
      },
    });

    this.logger.log(`Unit created: ${unit.code} (${unit.name})`);
    return { data: unit };
  }

  async updateUnit(
    id: string,
    dto: UpdateUnitDto,
  ): Promise<{ data: UnitOfMeasure }> {
    const unit = await this.prisma.unitOfMeasure.findUnique({
      where: { id },
    });
    if (!unit) {
      throw new NotFoundException('Unit not found');
    }

    // Check code uniqueness if being changed
    if (dto.code && dto.code !== unit.code) {
      const codeExists = await this.prisma.unitOfMeasure.findUnique({
        where: { code: dto.code },
      });
      if (codeExists) {
        throw new ConflictException('Unit code already exists');
      }
    }

    const updated = await this.prisma.unitOfMeasure.update({
      where: { id },
      data: {
        name: dto.name,
        code: dto.code,
        conversionRate: dto.conversionRate,
        baseUnit: dto.baseUnit,
      },
    });

    this.logger.log(`Unit updated: ${updated.code} (${updated.name})`);
    return { data: updated };
  }

  async removeUnit(id: string): Promise<{ data: { message: string } }> {
    const unit = await this.prisma.unitOfMeasure.findUnique({
      where: { id },
      include: { _count: { select: { products: true } } },
    });
    if (!unit) {
      throw new NotFoundException('Unit not found');
    }

    if ((unit._count?.products ?? 0) > 0) {
      throw new ConflictException('Cannot delete unit with products');
    }

    await this.prisma.unitOfMeasure.delete({ where: { id } });
    this.logger.log(`Unit deleted: ${unit.code}`);
    return { data: { message: 'Unit deleted successfully' } };
  }

  // ═══════════════════════════════════════════
  // Price Lists
  // ═══════════════════════════════════════════

  async findPriceLists(
    productId: string,
    companyId: string,
  ): Promise<{ data: PriceListWithRelations[] }> {
    // Verify product exists and belongs to company
    const product = await this.prisma.product.findFirst({
      where: { id: productId, companyId, deletedAt: null },
    });
    if (!product) {
      throw new NotFoundException(`Product with ID ${productId} not found`);
    }

    const priceLists = await this.prisma.priceList.findMany({
      where: { productId },
      include: {
        product: { select: { id: true, code: true, name: true } },
        customerCategory: { select: { id: true, name: true } },
      },
      orderBy: { effectiveFrom: 'desc' },
    });

    return { data: priceLists as PriceListWithRelations[] };
  }

  async createPriceList(
    dto: CreatePriceListDto,
    companyId: string,
  ): Promise<{ data: PriceListWithRelations }> {
    // Verify product exists and belongs to company
    const product = await this.prisma.product.findFirst({
      where: { id: dto.productId, companyId, deletedAt: null },
    });
    if (!product) {
      throw new NotFoundException(
        `Product with ID ${dto.productId} not found`,
      );
    }

    // Verify customer category if provided
    if (dto.customerCategoryId) {
      const customerCategory =
        await this.prisma.customerCategory.findUnique({
          where: { id: dto.customerCategoryId },
        });
      if (!customerCategory) {
        throw new BadRequestException(
          `Customer category with ID ${dto.customerCategoryId} not found`,
        );
      }
    }

    const priceList = await this.prisma.priceList.create({
      data: {
        name: dto.name,
        productId: dto.productId,
        customerCategoryId: dto.customerCategoryId,
        minQty: dto.minQty ?? 1,
        maxQty: dto.maxQty,
        unitPrice: dto.unitPrice,
        effectiveFrom: dto.effectiveFrom,
        effectiveTo: dto.effectiveTo,
      },
      include: {
        product: { select: { id: true, code: true, name: true } },
        customerCategory: { select: { id: true, name: true } },
      },
    });

    this.logger.log(`Price list created: ${priceList.name}`);
    return { data: priceList as PriceListWithRelations };
  }

  async updatePriceList(
    id: string,
    dto: UpdatePriceListDto,
  ): Promise<{ data: PriceListWithRelations }> {
    const priceList = await this.prisma.priceList.findUnique({
      where: { id },
    });
    if (!priceList) {
      throw new NotFoundException('Price list not found');
    }

    // Verify customer category if provided
    if (dto.customerCategoryId) {
      const customerCategory =
        await this.prisma.customerCategory.findUnique({
          where: { id: dto.customerCategoryId },
        });
      if (!customerCategory) {
        throw new BadRequestException(
          `Customer category with ID ${dto.customerCategoryId} not found`,
        );
      }
    }

    const updated = await this.prisma.priceList.update({
      where: { id },
      data: {
        name: dto.name,
        customerCategoryId: dto.customerCategoryId,
        minQty: dto.minQty,
        maxQty: dto.maxQty,
        unitPrice: dto.unitPrice,
        effectiveFrom: dto.effectiveFrom,
        effectiveTo: dto.effectiveTo,
      },
      include: {
        product: { select: { id: true, code: true, name: true } },
        customerCategory: { select: { id: true, name: true } },
      },
    });

    this.logger.log(`Price list updated: ${updated.name}`);
    return { data: updated as PriceListWithRelations };
  }

  async removePriceList(id: string): Promise<{ data: { message: string } }> {
    const priceList = await this.prisma.priceList.findUnique({
      where: { id },
    });
    if (!priceList) {
      throw new NotFoundException('Price list not found');
    }

    await this.prisma.priceList.delete({ where: { id } });
    this.logger.log(`Price list deleted: ${priceList.name}`);
    return { data: { message: 'Price list deleted successfully' } };
  }

  // ═══════════════════════════════════════════
  // Price Update (direct product price)
  // ═══════════════════════════════════════════

  async updatePrice(
    id: string,
    companyId: string,
    dto: UpdatePriceDto,
  ): Promise<{ data: ProductWithRelations }> {
    const product = await this.prisma.product.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!product) {
      throw new NotFoundException(`Product with ID ${id} not found`);
    }

    const updateData: Prisma.ProductUpdateInput = {};

    if (dto.type === 'avgCost') {
      updateData.avgCost = dto.newPrice;
    } else if (dto.type === 'sale') {
      updateData.salePrice = dto.newPrice;
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: updateData,
      include: {
        category: { select: { id: true, name: true, code: true, type: true } },
        unit: { select: { id: true, name: true, code: true } },
      },
    });

    this.logger.log(
      `Price updated for ${product.code}: ${dto.type} = ${dto.newPrice}${dto.reason ? ` (${dto.reason})` : ''}`,
    );
    return { data: updated as ProductWithRelations };
  }

  // ═══════════════════════════════════════════
  // Low Stock Alerts
  // ═══════════════════════════════════════════

  async getLowStockProducts(
    companyId: string,
    query: StockAlertQueryDto,
  ): Promise<
    PaginatedResult<
      ProductWithRelations & {
        currentStock: number;
        stockStatus: 'critical' | 'low' | 'ok';
      }
    >
  > {
    const page = query.page ?? 1;
    const limit = query.limit ?? 10;
    const skip = (page - 1) * limit;

    // Fetch products with reorderPoint > 0 (meaningful alerts only)
    const where: Prisma.ProductWhereInput = {
      companyId,
      deletedAt: null,
      reorderPoint: { gt: 0 },
    };

    const [products, total] = await Promise.all([
      this.prisma.product.findMany({
        where,
        skip,
        take: limit,
        orderBy: { reorderPoint: 'asc' },
        include: {
          category: {
            select: { id: true, name: true, code: true, type: true },
          },
          unit: { select: { id: true, name: true, code: true } },
        },
      }),
      this.prisma.product.count({ where }),
    ]);

    const productIds = products.map((p) => p.id);
    const stockLevels = await this.getStockLevels(productIds);

    const enriched = products.map((product) => {
      const currentStock = stockLevels.get(product.id) ?? 0;
      const reorder = Number(product.reorderPoint);
      const minStock = Number(product.minStockLevel);

      let stockStatus: 'critical' | 'low' | 'ok';
      if (currentStock <= reorder) {
        stockStatus = 'critical';
      } else if (minStock > 0 && currentStock <= minStock) {
        stockStatus = 'low';
      } else {
        stockStatus = 'ok';
      }

      return {
        ...product,
        currentStock,
        stockStatus,
      };
    });

    // Filter to only show critical and low
    const alerts = enriched.filter(
      (p) => p.stockStatus === 'critical' || p.stockStatus === 'low',
    );

    return {
      data: alerts,
      meta: this.computePaginationMeta(page, limit, total),
    };
  }

  // ═══════════════════════════════════════════
  // Product Analytics
  // ═══════════════════════════════════════════

  async getTopSelling(
    companyId: string,
    options: { limit?: number; startDate?: Date; endDate?: Date } = {},
  ): Promise<{
    data: Array<{
      productId: string;
      productCode: string;
      productName: string;
      categoryName: string;
      totalQuantity: number;
      totalRevenue: number;
      avgUnitPrice: number;
    }>;
  }> {
    const { limit = 10, startDate, endDate } = options;

    const dateFilter: Prisma.DateTimeFilter = {};
    if (startDate) dateFilter.gte = startDate;
    if (endDate) dateFilter.lte = endDate;

    const lines = await this.prisma.salesInvoiceLine.findMany({
      where: {
        invoice: {
          branch: { companyId },
          status: { not: InvoiceStatus.CANCELLED },
          ...(Object.keys(dateFilter).length > 0 && { createdAt: dateFilter }),
        },
      },
      include: {
        product: {
          select: {
            id: true,
            code: true,
            name: true,
            category: { select: { name: true } },
          },
        },
      },
      orderBy: { quantity: 'desc' },
      take: limit * 3, // oversample for aggregation
    });

    // Aggregate by product
    const aggregated = new Map<
      string,
      {
        productId: string;
        productCode: string;
        productName: string;
        categoryName: string;
        totalQuantity: number;
        totalRevenue: number;
        totalUnitPrice: number;
        count: number;
      }
    >();

    for (const line of lines) {
      const pid = line.productId;
      const existing = aggregated.get(pid);
      const qty = Number(line.quantity);
      const revenue = Number(line.totalPrice);
      const unitPrice = Number(line.unitPrice);

      if (existing) {
        existing.totalQuantity += qty;
        existing.totalRevenue += revenue;
        existing.totalUnitPrice += unitPrice;
        existing.count += 1;
      } else {
        aggregated.set(pid, {
          productId: pid,
          productCode: line.product.code,
          productName: line.product.name,
          categoryName: line.product.category?.name ?? '',
          totalQuantity: qty,
          totalRevenue: revenue,
          totalUnitPrice: unitPrice,
          count: 1,
        });
      }
    }

    const sorted = Array.from(aggregated.values())
      .sort((a, b) => b.totalQuantity - a.totalQuantity)
      .slice(0, limit)
      .map((item) => ({
        productId: item.productId,
        productCode: item.productCode,
        productName: item.productName,
        categoryName: item.categoryName,
        totalQuantity: item.totalQuantity,
        totalRevenue: Math.round(item.totalRevenue * 100) / 100,
        avgUnitPrice:
          Math.round((item.totalUnitPrice / item.count) * 10000) / 10000,
      }));

    return { data: sorted };
  }

  async getProfitability(
    companyId: string,
    options: { limit?: number; startDate?: Date; endDate?: Date } = {},
  ): Promise<{
    data: Array<{
      productId: string;
      productCode: string;
      productName: string;
      avgCost: number;
      avgSalePrice: number;
      marginPercent: number;
      totalSold: number;
      estimatedProfit: number;
    }>;
  }> {
    const { limit = 10, startDate, endDate } = options;

    const dateFilter: Prisma.DateTimeFilter = {};
    if (startDate) dateFilter.gte = startDate;
    if (endDate) dateFilter.lte = endDate;

    const lines = await this.prisma.salesInvoiceLine.findMany({
      where: {
        invoice: {
          branch: { companyId },
          status: { not: InvoiceStatus.CANCELLED },
          ...(Object.keys(dateFilter).length > 0 && { createdAt: dateFilter }),
        },
      },
      include: {
        product: {
          select: {
            id: true,
            code: true,
            name: true,
            avgCost: true,
          },
        },
      },
      orderBy: { totalPrice: 'desc' },
      take: limit * 3,
    });

    const aggregated = new Map<
      string,
      {
        productId: string;
        productCode: string;
        productName: string;
        avgCost: number;
        totalQuantity: number;
        totalRevenue: number;
        totalUnitPrice: number;
        count: number;
      }
    >();

    for (const line of lines) {
      const pid = line.productId;
      const existing = aggregated.get(pid);
      const qty = Number(line.quantity);
      const revenue = Number(line.totalPrice);
      const unitPrice = Number(line.unitPrice);

      if (existing) {
        existing.totalQuantity += qty;
        existing.totalRevenue += revenue;
        existing.totalUnitPrice += unitPrice;
        existing.count += 1;
      } else {
        aggregated.set(pid, {
          productId: pid,
          productCode: line.product.code,
          productName: line.product.name,
          avgCost: Number(line.product.avgCost),
          totalQuantity: qty,
          totalRevenue: revenue,
          totalUnitPrice: unitPrice,
          count: 1,
        });
      }
    }

    const result = Array.from(aggregated.values())
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, limit)
      .map((item) => {
        const avgSalePrice = item.totalUnitPrice / item.count;
        const marginPercent =
          item.avgCost > 0
            ? Math.round(
                ((avgSalePrice - item.avgCost) / avgSalePrice) * 10000,
              ) / 100
            : 0;
        const estimatedProfit =
          Math.round(
            (avgSalePrice - item.avgCost) * item.totalQuantity * 100,
          ) / 100;

        return {
          productId: item.productId,
          productCode: item.productCode,
          productName: item.productName,
          avgCost: item.avgCost,
          avgSalePrice: Math.round(avgSalePrice * 10000) / 10000,
          marginPercent,
          totalSold: item.totalQuantity,
          estimatedProfit,
        };
      });

    return { data: result };
  }

  // ═══════════════════════════════════════════
  // Summary / Dashboard
  // ═══════════════════════════════════════════

  async getInventorySummary(companyId: string): Promise<{
    data: {
      totalProducts: number;
      activeProducts: number;
      lowStockCount: number;
      totalCategories: number;
      totalUnits: number;
      avgMarginPercent: number;
    };
  }> {
    const [
      totalProducts,
      activeProducts,
      categoriesCount,
      unitsCount,
    ] = await Promise.all([
      this.prisma.product.count({ where: { companyId, deletedAt: null } }),
      this.prisma.product.count({
        where: { companyId, deletedAt: null, status: UserStatus.ACTIVE },
      }),
      this.prisma.productCategory.count(),
      this.prisma.unitOfMeasure.count(),
    ]);

    // Calculate avg margin across active products
    const productsWithPrices = await this.prisma.product.findMany({
      where: {
        companyId,
        deletedAt: null,
        status: UserStatus.ACTIVE,
        avgCost: { gt: 0 },
        salePrice: { gt: 0 },
      },
      select: { avgCost: true, salePrice: true },
    });

    let avgMarginPercent = 0;
    if (productsWithPrices.length > 0) {
      const totalMargin = productsWithPrices.reduce((sum, p) => {
        const margin =
          (Number(p.salePrice) - Number(p.avgCost)) / Number(p.salePrice);
        return sum + (Number.isFinite(margin) ? margin : 0);
      }, 0);
      avgMarginPercent =
        Math.round((totalMargin / productsWithPrices.length) * 10000) / 100;
    }

    // Count low stock items
    const productsWithReorder = await this.prisma.product.findMany({
      where: {
        companyId,
        deletedAt: null,
        reorderPoint: { gt: 0 },
      },
      select: { id: true, reorderPoint: true, minStockLevel: true },
    });

    const productIds = productsWithReorder.map((p) => p.id);
    const stockLevels = await this.getStockLevels(productIds);

    let lowStockCount = 0;
    for (const product of productsWithReorder) {
      const currentStock = stockLevels.get(product.id) ?? 0;
      if (currentStock <= Number(product.reorderPoint)) {
        lowStockCount++;
      }
    }

    return {
      data: {
        totalProducts,
        activeProducts,
        lowStockCount,
        totalCategories: categoriesCount,
        totalUnits: unitsCount,
        avgMarginPercent,
      },
    };
  }
}
