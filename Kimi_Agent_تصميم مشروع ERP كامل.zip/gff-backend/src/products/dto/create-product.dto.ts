import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsNumber,
  IsUUID,
  IsEnum,
  IsDecimal,
  Min,
} from 'class-validator';
import { Type } from 'class-transformer';
import { UserStatus, ProductType } from '@prisma/client';

// ─────────────────────────────────────────────
// Product DTOs
// ─────────────────────────────────────────────

export class CreateProductDto {
  @ApiProperty({ example: 'PRD-001', description: 'Unique product code (was SKU)' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  code: string;

  @ApiProperty({ example: 'Organic Chicken Feed 25kg' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  name: string;

  @ApiProperty({ example: 'Premium organic chicken feed for layers', required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: '1234567890123', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  barcode?: string;

  @ApiProperty({ example: 15.5, description: 'Average cost (replaces costPrice)' })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  avgCost: number;

  @ApiProperty({ example: 22.0 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  salePrice: number;

  @ApiProperty({ example: 10, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  minStockLevel?: number;

  @ApiProperty({ example: 1000, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  maxStockLevel?: number;

  @ApiProperty({ example: 50, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  reorderPoint?: number;

  @ApiProperty({ example: 25.5, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  weight?: number;

  @ApiProperty({ example: 'ACTIVE', enum: UserStatus, required: false })
  @IsOptional()
  @IsEnum(UserStatus)
  status?: UserStatus;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  categoryId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001' })
  @IsUUID()
  unitId: string;
}

export class UpdateProductDto {
  @ApiProperty({ example: 'PRD-001', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  code?: string;

  @ApiProperty({ example: 'Organic Chicken Feed 25kg', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  name?: string;

  @ApiProperty({ example: 'Updated description', required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: '1234567890123', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  barcode?: string;

  @ApiProperty({ example: 15.5, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  avgCost?: number;

  @ApiProperty({ example: 22.0, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  salePrice?: number;

  @ApiProperty({ example: 10, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  minStockLevel?: number;

  @ApiProperty({ example: 1000, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  maxStockLevel?: number;

  @ApiProperty({ example: 50, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  reorderPoint?: number;

  @ApiProperty({ example: 25.5, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  weight?: number;

  @ApiProperty({ example: 'ACTIVE', enum: UserStatus, required: false })
  @IsOptional()
  @IsEnum(UserStatus)
  status?: UserStatus;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  unitId?: string;
}

// ─────────────────────────────────────────────
// Category DTOs
// ─────────────────────────────────────────────

export class CreateCategoryDto {
  @ApiProperty({ example: 'Animal Feed' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  name: string;

  @ApiProperty({ example: 'FEED' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  code: string;

  @ApiProperty({
    example: 'FINISHED_GOOD',
    enum: ProductType,
    enumName: 'ProductType',
    description: 'Category product type enum',
  })
  @IsEnum(ProductType)
  type: ProductType;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  parentId?: string;
}

export class UpdateCategoryDto {
  @ApiProperty({ example: 'Animal Feed', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  name?: string;

  @ApiProperty({ example: 'FEED', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  code?: string;

  @ApiProperty({
    example: 'FINISHED_GOOD',
    enum: ProductType,
    enumName: 'ProductType',
    required: false,
  })
  @IsOptional()
  @IsEnum(ProductType)
  type?: ProductType;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  parentId?: string;
}

// ─────────────────────────────────────────────
// Unit of Measure DTOs
// ─────────────────────────────────────────────

export class CreateUnitDto {
  @ApiProperty({ example: 'Kilogram' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  name: string;

  @ApiProperty({ example: 'KG' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(10)
  code: string;

  @ApiProperty({ example: 1.0, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  conversionRate?: number;

  @ApiProperty({ example: 'KG', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(10)
  baseUnit?: string;
}

export class UpdateUnitDto {
  @ApiProperty({ example: 'Kilogram', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  name?: string;

  @ApiProperty({ example: 'KG', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(10)
  code?: string;

  @ApiProperty({ example: 1.0, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  conversionRate?: number;

  @ApiProperty({ example: 'KG', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(10)
  baseUnit?: string;
}

// ─────────────────────────────────────────────
// Price List DTOs
// ─────────────────────────────────────────────

export class CreatePriceListDto {
  @ApiProperty({ example: 'Wholesale Q1 2024' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  name: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  productId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  customerCategoryId?: string;

  @ApiProperty({ example: 1, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  minQty?: number;

  @ApiProperty({ example: 100, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  maxQty?: number;

  @ApiProperty({ example: 18.5 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  unitPrice: number;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z' })
  @IsNotEmpty()
  effectiveFrom: Date;

  @ApiProperty({ example: '2024-12-31T23:59:59.000Z', required: false })
  @IsOptional()
  effectiveTo?: Date;
}

export class UpdatePriceListDto {
  @ApiProperty({ example: 'Wholesale Q1 2024', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  name?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  customerCategoryId?: string;

  @ApiProperty({ example: 1, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  minQty?: number;

  @ApiProperty({ example: 100, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  maxQty?: number;

  @ApiProperty({ example: 18.5, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  unitPrice?: number;

  @ApiProperty({ example: '2024-01-01T00:00:00.000Z', required: false })
  @IsOptional()
  effectiveFrom?: Date;

  @ApiProperty({ example: '2024-12-31T23:59:59.000Z', required: false })
  @IsOptional()
  effectiveTo?: Date;
}

// ─────────────────────────────────────────────
// Price Update DTO
// ─────────────────────────────────────────────

export class UpdatePriceDto {
  @ApiProperty({ example: 25.0 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  newPrice: number;

  @ApiProperty({ example: 'avgCost', description: 'avgCost or sale' })
  @IsString()
  @IsNotEmpty()
  type: 'avgCost' | 'sale';

  @ApiProperty({ example: 'Supplier price increase', required: false })
  @IsOptional()
  @IsString()
  reason?: string;
}

// ─────────────────────────────────────────────
// Filter / Query DTOs
// ─────────────────────────────────────────────

export class FilterProductsDto {
  @ApiProperty({ example: 1, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  page?: number;

  @ApiProperty({ example: 10, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  limit?: number;

  @ApiProperty({ example: 'chicken feed', required: false })
  @IsOptional()
  @IsString()
  search?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @ApiProperty({ example: 'FINISHED_GOOD', enum: ProductType, required: false })
  @IsOptional()
  @IsEnum(ProductType)
  categoryType?: ProductType;
}

// ─────────────────────────────────────────────
// Stock / Analytics DTOs
// ─────────────────────────────────────────────

export class StockAlertQueryDto {
  @ApiProperty({ example: 1, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  page?: number;

  @ApiProperty({ example: 10, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  limit?: number;
}
