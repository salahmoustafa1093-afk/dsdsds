import { Injectable, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common';
import Redis from 'ioredis';

@Injectable()
export class RedisService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(RedisService.name);
  private client: Redis;
  private subscriber: Redis;

  async onModuleInit(): Promise<void> {
    const host = process.env.REDIS_HOST || 'localhost';
    const port = parseInt(process.env.REDIS_PORT || '6379', 10);
    const password = process.env.REDIS_PASSWORD || undefined;
    const db = parseInt(process.env.REDIS_DB || '0', 10);
    const keyPrefix = process.env.REDIS_KEY_PREFIX || 'gff:';
    const enableReadyCheck = process.env.REDIS_ENABLE_READY_CHECK !== 'false';
    const maxRetriesPerRequest = parseInt(
      process.env.REDIS_MAX_RETRIES_PER_REQUEST || '3',
      10,
    );
    const connectTimeout = parseInt(
      process.env.REDIS_CONNECT_TIMEOUT || '10000',
      10,
    );
    const lazyConnect = process.env.REDIS_LAZY_CONNECT === 'true';

    const options: Redis.RedisOptions = {
      host,
      port,
      password,
      db,
      keyPrefix,
      enableReadyCheck,
      maxRetriesPerRequest,
      connectTimeout,
      lazyConnect,
      retryStrategy: (times: number) => {
        const delay = Math.min(times * 100, 3000);
        this.logger.warn(
          `Redis connection retry ${times}/20, next attempt in ${delay}ms`,
        );
        return times > 20 ? null : delay;
      },
      reconnectOnError: (err: Error) => {
        const targetErrors = ['READONLY', 'ECONNREFUSED', 'ETIMEDOUT', 'ECONNRESET'];
        const shouldReconnect = targetErrors.some((e) =>
          err.message.includes(e),
        );
        if (shouldReconnect) {
          this.logger.error(`Redis reconnect triggered: ${err.message}`);
        }
        return shouldReconnect;
      },
    };

    // Sentinel configuration
    if (process.env.REDIS_SENTINEL_HOSTS) {
      const sentinels = process.env.REDIS_SENTINEL_HOSTS.split(',').map(
        (h) => {
          const [host, port] = h.split(':');
          return { host, port: parseInt(port, 10) };
        },
      );
      options.sentinels = sentinels;
      options.name = process.env.REDIS_SENTINEL_MASTER_NAME || 'mymaster';
      options.sentinelRetryStrategy = (times: number) => {
        return Math.min(times * 100, 3000);
      };
    }

    // Cluster configuration
    if (process.env.REDIS_CLUSTER_HOSTS) {
      const clusterNodes = process.env.REDIS_CLUSTER_HOSTS.split(',').map(
        (h) => {
          const [host, port] = h.split(':');
          return { host, port: parseInt(port, 10) };
        },
      );
      this.client = new Redis.Cluster(clusterNodes, {
        redisOptions: {
          password,
          connectTimeout,
        },
      });
    } else {
      this.client = new Redis(options);
    }

    // Dedicated subscriber for pub/sub
    this.subscriber = new Redis({
      host,
      port,
      password,
      db,
      keyPrefix,
    });

    this.client.on('connect', () => {
      this.logger.log(`Redis connected to ${host}:${port} (DB ${db})`);
    });

    this.client.on('ready', () => {
      this.logger.log('Redis client is ready');
    });

    this.client.on('error', (err) => {
      this.logger.error(`Redis error: ${err.message}`);
    });

    this.client.on('close', () => {
      this.logger.warn('Redis connection closed');
    });

    this.client.on('reconnecting', () => {
      this.logger.log('Redis reconnecting...');
    });

    if (!lazyConnect) {
      await this.client.ping();
    }
  }

  async onModuleDestroy(): Promise<void> {
    this.logger.log('Closing Redis connections...');
    await this.client.quit();
    await this.subscriber.quit();
  }

  /** Get the underlying ioredis client for advanced operations */
  getClient(): Redis {
    return this.client;
  }

  /** Get value by key */
  async get<T = unknown>(key: string): Promise<T | null> {
    const value = await this.client.get(key);
    if (!value) return null;
    try {
      return JSON.parse(value) as T;
    } catch {
      return value as unknown as T;
    }
  }

  /** Set key with optional TTL (seconds) */
  async set<T = unknown>(
    key: string,
    value: T,
    ttlSeconds?: number,
  ): Promise<'OK'> {
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    if (ttlSeconds && ttlSeconds > 0) {
      return this.client.set(key, serialized, 'EX', ttlSeconds);
    }
    return this.client.set(key, serialized);
  }

  /** Delete key(s) */
  async del(key: string | string[]): Promise<number> {
    return this.client.del(...(Array.isArray(key) ? key : [key]));
  }

  /** Set key expiration in seconds */
  async expire(key: string, seconds: number): Promise<number> {
    return this.client.expire(key, seconds);
  }

  /** Get hash field value */
  async hget<T = unknown>(key: string, field: string): Promise<T | null> {
    const value = await this.client.hget(key, field);
    if (!value) return null;
    try {
      return JSON.parse(value) as T;
    } catch {
      return value as unknown as T;
    }
  }

  /** Set hash field value */
  async hset<T = unknown>(
    key: string,
    field: string,
    value: T,
  ): Promise<number> {
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    return this.client.hset(key, field, serialized);
  }

  /** Delete hash field(s) */
  async hdel(key: string, ...fields: string[]): Promise<number> {
    return this.client.hdel(key, ...fields);
  }

  /** Check if key exists */
  async exists(key: string | string[]): Promise<number> {
    return this.client.exists(...(Array.isArray(key) ? key : [key]));
  }

  /** Flush current database - WARNING: destructive */
  async flushdb(): Promise<'OK'> {
    this.logger.warn('FLUSHDB executed - all keys deleted');
    return this.client.flushdb();
  }

  /** Find keys matching pattern (use sparingly in production) */
  async keys(pattern: string): Promise<string[]> {
    return this.client.keys(pattern);
  }

  /** Scan keys incrementally (production-safe) */
  async scan(
    pattern: string,
    count = 100,
  ): Promise<{ cursor: string; keys: string[] }> {
    const [cursor, keys] = await this.client.scan(
      '0',
      'MATCH',
      pattern,
      'COUNT',
      count,
    );
    return { cursor, keys };
  }

  /** Increment key by amount (default 1) */
  async increment(key: string, amount = 1): Promise<number> {
    if (amount === 1) {
      return this.client.incr(key);
    }
    return this.client.incrby(key, amount);
  }

  /** Decrement key by amount (default 1) */
  async decrement(key: string, amount = 1): Promise<number> {
    if (amount === 1) {
      return this.client.decr(key);
    }
    return this.client.decrby(key, amount);
  }

  /** Get remaining TTL for a key */
  async ttl(key: string): Promise<number> {
    return this.client.ttl(key);
  }

  /** Execute a pipeline (batch) of commands atomically */
  async pipeline(
    operations: (pipeline: Redis.Pipeline) => Redis.Pipeline,
  ): Promise<[Error | null, unknown][] | unknown[]> {
    const pipeline = this.client.pipeline();
    operations(pipeline);
    return pipeline.exec();
  }

  /** Execute a transaction (multi/exec) */
  async transaction(
    operations: (transaction: Redis.Pipeline) => Redis.Pipeline,
  ): Promise<[Error | null, unknown][] | unknown[]> {
    const transaction = this.client.multi();
    operations(transaction);
    return transaction.exec();
  }

  /** Publish a message to a channel */
  async publish(channel: string, message: unknown): Promise<number> {
    const serialized =
      typeof message === 'string' ? message : JSON.stringify(message);
    return this.client.publish(channel, serialized);
  }

  /** Subscribe to a channel */
  subscribe(
    channel: string,
    callback: (message: string, channel: string) => void,
  ): void {
    this.subscriber.subscribe(channel, (err) => {
      if (err) {
        this.logger.error(`Failed to subscribe to ${channel}: ${err.message}`);
      } else {
        this.logger.log(`Subscribed to channel: ${channel}`);
      }
    });
    this.subscriber.on('message', (recvChannel, message) => {
      if (recvChannel === channel) {
        callback(message, recvChannel);
      }
    });
  }

  /** Unsubscribe from a channel */
  async unsubscribe(channel: string): Promise<void> {
    await this.subscriber.unsubscribe(channel);
  }

  /** Get Redis server info */
  async info(section?: string): Promise<string> {
    return this.client.info(section);
  }

  /** Health check for readiness probes */
  async healthCheck(): Promise<{ status: string; latencyMs: number }> {
    const start = Date.now();
    await this.client.ping();
    const latencyMs = Date.now() - start;
    return { status: 'healthy', latencyMs };
  }

  /** Get memory usage in bytes for a key */
  async memoryUsage(key: string): Promise<number> {
    return this.client.call('MEMORY', 'USAGE', key) as Promise<number>;
  }

  /** Set key only if it does not exist (NX) */
  async setnx(key: string, value: unknown, ttlSeconds?: number): Promise<number> {
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    const args: (string | number)[] = [key, serialized];
    if (ttlSeconds) {
      args.push('EX', ttlSeconds);
    }
    args.push('NX');
    const result = await this.client.set(...(args as [string, string, ...Array<string | number>]));
    return result === 'OK' ? 1 : 0;
  }

  /** Acquire a distributed lock */
  async lock(
    lockKey: string,
    ttlSeconds: number,
    identifier = `lock-${Date.now()}`,
  ): Promise<{ identifier: string; release: () => Promise<void> } | null> {
    const acquired = await this.setnx(lockKey, identifier, ttlSeconds);
    if (acquired) {
      return {
        identifier,
        release: async () => {
          const current = await this.get<string>(lockKey);
          if (current === identifier) {
            await this.del(lockKey);
          }
        },
      };
    }
    return null;
  }
}
