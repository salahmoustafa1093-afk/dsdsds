import { Module, Global } from '@nestjs/common';
import { RedisService } from './redis.service';

/**
 * Global Redis Module
 *
 * Provides a single Redis connection instance across the application.
 * Uses ioredis for cluster support, Sentinel, and advanced features.
 */
@Global()
@Module({
  providers: [RedisService],
  exports: [RedisService],
})
export class RedisModule {}
