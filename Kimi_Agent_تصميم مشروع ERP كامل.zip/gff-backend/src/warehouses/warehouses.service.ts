import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { UserStatus } from '@prisma/client';
import { PrismaService } from '@/prisma/prisma.service';
import { CreateWarehouseDto, UpdateWarehouseDto, WarehouseLocationDto } from './dto';

@Injectable()
export class WarehousesService {
  private readonly logger = new Logger(WarehousesService.name);

  constructor(private readonly prisma: PrismaService) {}

  private warehouseWhere(companyId: string, extra: Record<string, any> = {}) {
    return { branch: { companyId }, deletedAt: null, ...extra };
  }

  async findAll(companyId: string, options: { page?: number; limit?: number; branchId?: string; search?: string }) {
    const { page = 1, limit = 10, branchId, search } = options;
    const skip = (page - 1) * limit;

    const where: any = this.warehouseWhere(companyId);
    if (branchId) where.branchId = branchId;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.warehouse.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          branch: { select: { id: true, name: true } },
          locations: { select: { id: true, zone: true, aisle: true, rack: true } },
          _count: { select: { locations: true, stockMovements: true } },
        },
      }),
      this.prisma.warehouse.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOne(id: string, companyId: string) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: this.warehouseWhere(companyId, { id }),
      include: {
        branch: { select: { id: true, name: true, code: true } },
        locations: true,
      },
    });

    if (!warehouse) throw new NotFoundException(`Warehouse with ID ${id} not found`);

    return { data: warehouse };
  }

  async create(companyId: string, dto: CreateWarehouseDto) {
    const existing = await this.prisma.warehouse.findFirst({
      where: { code: dto.code, branch: { companyId } },
    });
    if (existing) throw new ConflictException('Warehouse code already exists');

    const warehouse = await this.prisma.warehouse.create({
      data: { ...dto },
      include: { branch: { select: { id: true, name: true } } },
    });

    this.logger.log(`Warehouse created: ${warehouse.code}`);
    return { data: warehouse };
  }

  async update(id: string, companyId: string, dto: UpdateWarehouseDto) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: this.warehouseWhere(companyId, { id }),
    });
    if (!warehouse) throw new NotFoundException(`Warehouse with ID ${id} not found`);

    const updated = await this.prisma.warehouse.update({
      where: { id },
      data: dto,
      include: { branch: { select: { id: true, name: true } } },
    });

    return { data: updated };
  }

  async remove(id: string, companyId: string) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: this.warehouseWhere(companyId, { id }),
    });
    if (!warehouse) throw new NotFoundException(`Warehouse with ID ${id} not found`);

    await this.prisma.warehouse.update({
      where: { id },
      data: { deletedAt: new Date(), status: UserStatus.INACTIVE },
    });

    return { data: { message: 'Warehouse deleted successfully' } };
  }

  async getStock(id: string, companyId: string) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: this.warehouseWhere(companyId, { id }),
    });
    if (!warehouse) throw new NotFoundException(`Warehouse with ID ${id} not found`);

    // Aggregate stock from StockMovement (no Stock model in schema)
    const movements = await this.prisma.stockMovement.findMany({
      where: { warehouseId: id },
      include: {
        product: { select: { id: true, name: true, code: true, minStockLevel: true, maxStockLevel: true } },
        location: { select: { id: true, zone: true, aisle: true, rack: true, bin: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Group by product to compute current stock
    const stockMap = new Map<string, { product: any; quantity: number; location: any }>();
    for (const m of movements) {
      const key = m.productId + (m.locationId || '');
      const existing = stockMap.get(key);
      const qty = Number(m.quantity);
      if (m.type === 'RECEIPT' || m.type === 'RETURN' || m.type === 'ADJUSTMENT') {
        stockMap.set(key, { product: m.product, quantity: (existing?.quantity || 0) + qty, location: m.location });
      } else if (m.type === 'ISSUE' || m.type === 'TRANSFER' || m.type === 'WASTE') {
        stockMap.set(key, { product: m.product, quantity: (existing?.quantity || 0) - qty, location: m.location });
      }
    }

    const stocks = Array.from(stockMap.values());
    const summary = {
      totalProducts: stocks.length,
      totalQuantity: stocks.reduce((sum, s) => sum + s.quantity, 0),
      lowStockItems: stocks.filter((s) => s.quantity <= Number(s.product.minStockLevel || 0)).length,
    };

    return { data: { stocks, summary } };
  }

  async addLocation(id: string, companyId: string, dto: WarehouseLocationDto) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: this.warehouseWhere(companyId, { id }),
    });
    if (!warehouse) throw new NotFoundException(`Warehouse with ID ${id} not found`);

    const location = await this.prisma.warehouseLocation.create({
      data: { ...dto, warehouseId: id },
    });

    return { data: location };
  }

  async getLocations(id: string, companyId: string) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: this.warehouseWhere(companyId, { id }),
    });
    if (!warehouse) throw new NotFoundException(`Warehouse with ID ${id} not found`);

    const locations = await this.prisma.warehouseLocation.findMany({
      where: { warehouseId: id },
    });

    return { data: locations };
  }
}
