import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsBoolean,
  IsNumber,
  IsUUID,
  IsEnum,
} from 'class-validator';
import { WarehouseType } from '@prisma/client';

export class CreateWarehouseDto {
  @ApiProperty({ example: 'Main Warehouse' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(150)
  name: string;

  @ApiProperty({ example: 'WH-MAIN' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(20)
  code: string;

  @ApiProperty({ example: 'MAIN', enum: WarehouseType })
  @IsEnum(WarehouseType)
  type: WarehouseType;

  @ApiProperty({ example: 'Industrial Area, St. 5', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(250)
  address?: string;

  @ApiProperty({ example: 10000, required: false })
  @IsOptional()
  @IsNumber()
  capacity?: number;

  @ApiProperty({ example: true, required: false })
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  branchId: string;
}

export class UpdateWarehouseDto {
  @ApiProperty({ example: 'Main Warehouse', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(150)
  name?: string;

  @ApiProperty({ example: 'Industrial Area, St. 5', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(250)
  address?: string;

  @ApiProperty({ example: 10000, required: false })
  @IsOptional()
  @IsNumber()
  capacity?: number;

  @ApiProperty({ example: true, required: false })
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class WarehouseLocationDto {
  @ApiProperty({ example: 'A' })
  @IsString()
  @IsNotEmpty()
  zone: string;

  @ApiProperty({ example: '01' })
  @IsString()
  @IsNotEmpty()
  aisle: string;

  @ApiProperty({ example: 'R1' })
  @IsString()
  @IsNotEmpty()
  rack: string;

  @ApiProperty({ example: 'S1' })
  @IsString()
  @IsNotEmpty()
  shelf: string;

  @ApiProperty({ example: 'B01' })
  @IsString()
  @IsNotEmpty()
  bin: string;
}
