import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { WarehousesService } from './warehouses.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import { CreateWarehouseDto, UpdateWarehouseDto, WarehouseLocationDto } from './dto';

@ApiTags('Warehouses')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('warehouses')
export class WarehousesController {
  constructor(private readonly warehousesService: WarehousesService) {}

  @Get()
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'List warehouses' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'branchId', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiResponse({ status: 200, description: 'Warehouses retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAll(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('branchId') branchId?: string,
    @Query('search') search?: string,
  ) {
    return this.warehousesService.findAll(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      branchId,
      search,
    });
  }

  @Get(':id')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get warehouse by ID' })
  @ApiResponse({ status: 200, description: 'Warehouse retrieved' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.warehousesService.findOne(id, companyId);
  }

  @Post()
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Create warehouse' })
  @ApiResponse({ status: 201, description: 'Warehouse created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async create(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateWarehouseDto,
  ) {
    return this.warehousesService.create(companyId, dto);
  }

  @Put(':id')
  @Permissions('inventory:update')
  @ApiOperation({ summary: 'Update warehouse' })
  @ApiResponse({ status: 200, description: 'Warehouse updated' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateWarehouseDto,
  ) {
    return this.warehousesService.update(id, companyId, dto);
  }

  @Delete(':id')
  @Permissions('inventory:delete')
  @ApiOperation({ summary: 'Soft delete warehouse' })
  @ApiResponse({ status: 200, description: 'Warehouse deleted' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.warehousesService.remove(id, companyId);
  }

  @Get(':id/stock')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get warehouse stock' })
  @ApiResponse({ status: 200, description: 'Stock retrieved' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getStock(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.warehousesService.getStock(id, companyId);
  }

  @Get(':id/locations')
  @Permissions('inventory:view')
  @ApiOperation({ summary: 'Get warehouse locations' })
  @ApiResponse({ status: 200, description: 'Locations retrieved' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getLocations(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.warehousesService.getLocations(id, companyId);
  }

  @Post(':id/locations')
  @Permissions('inventory:create')
  @ApiOperation({ summary: 'Add warehouse location' })
  @ApiResponse({ status: 201, description: 'Location added' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async addLocation(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: WarehouseLocationDto,
  ) {
    return this.warehousesService.addLocation(id, companyId, dto);
  }
}
