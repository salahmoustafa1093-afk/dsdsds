import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  CreateDeliveryDto,
  AssignDriverDto,
  ConfirmDeliveryOrderDto,
  ApproveDeliveryDto,
  StartPickingDto,
  ConfirmPickedLoadedDto,
  StartTransitDto,
  AtCustomerDto,
  GpsTrackingUpdateDto,
  DeliveryConfirmationDto,
  PaymentCollectionDto,
  FailDeliveryDto,
  DeliveryFilterDto,
  CreateDeliveryRouteDto,
  UpdateDeliveryRouteDto,
} from './dto';
import { DeliveryStatus, Prisma } from '@prisma/client';

/** ------------------------------------------------------------------ */
/*  Types                                                               */
/** ------------------------------------------------------------------ */
interface ListOptions {
  page?: number;
  limit?: number;
  filters?: DeliveryFilterDto;
}

interface PaginatedResult<T> {
  data: T[];
  meta: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

/** ------------------------------------------------------------------ */
/*  Service                                                             */
/** ------------------------------------------------------------------ */
@Injectable()
export class DeliveryService {
  private readonly logger = new Logger(DeliveryService.name);

  /**
   * Valid status transitions for the 12-step delivery lifecycle.
   * FAILED_CLOSED is terminal for failed deliveries.
   */
  private readonly statusTransitions: Record<DeliveryStatus, DeliveryStatus[]> =
    {
      [DeliveryStatus.PENDING]: [DeliveryStatus.CONFIRMED],
      [DeliveryStatus.CONFIRMED]: [DeliveryStatus.APPROVED],
      [DeliveryStatus.APPROVED]: [DeliveryStatus.PICKING],
      [DeliveryStatus.PICKING]: [DeliveryStatus.PICKED_LOADED],
      [DeliveryStatus.PICKED_LOADED]: [DeliveryStatus.DRIVER_ASSIGNED],
      [DeliveryStatus.DRIVER_ASSIGNED]: [DeliveryStatus.IN_TRANSIT],
      [DeliveryStatus.IN_TRANSIT]: [DeliveryStatus.AT_CUSTOMER],
      [DeliveryStatus.AT_CUSTOMER]: [DeliveryStatus.DELIVERED],
      [DeliveryStatus.DELIVERED]: [
        DeliveryStatus.PAYMENT_COLLECTED,
        DeliveryStatus.FAILED_CLOSED,
      ],
      [DeliveryStatus.PAYMENT_COLLECTED]: [DeliveryStatus.CLOSED],
      [DeliveryStatus.FAILED_CLOSED]: [],
      [DeliveryStatus.CLOSED]: [],
    };

  constructor(private readonly prisma: PrismaService) {}

  /** ---------------------------------------------------------------- */
  /*  Helpers                                                           */
  /** ---------------------------------------------------------------- */
  private canTransition(
    current: DeliveryStatus,
    next: DeliveryStatus,
  ): boolean {
    return this.statusTransitions[current]?.includes(next) ?? false;
  }

  /**
   * Build the company-scoped where clause for DeliveryOrder.
   * DeliveryOrder has branchId; Branch has companyId.
   */
  private companyScope(companyId: string): Prisma.DeliveryOrderWhereInput {
    return { branch: { companyId } };
  }

  /**
   * Find a single delivery order ensuring it belongs to the company.
   */
  private async findDeliveryForCompany(
    id: string,
    companyId: string,
    include?: Prisma.DeliveryOrderInclude,
  ) {
    const delivery = await this.prisma.deliveryOrder.findFirst({
      where: { id, ...this.companyScope(companyId), deletedAt: null },
      include,
    });
    if (!delivery) {
      throw new NotFoundException(`Delivery order with ID ${id} not found`);
    }
    return delivery;
  }

  /**
   * Apply filters on top of a base where clause.
   */
  private applyFilters(
    baseWhere: Prisma.DeliveryOrderWhereInput,
    filters?: DeliveryFilterDto,
  ): Prisma.DeliveryOrderWhereInput {
    const where: Prisma.DeliveryOrderWhereInput = { ...baseWhere };

    if (filters?.status) {
      where.status = filters.status;
    }
    if (filters?.driverId) {
      where.driverId = filters.driverId;
    }
    if (filters?.vehicleId) {
      where.vehicleId = filters.vehicleId;
    }
    if (filters?.branchId) {
      where.branchId = filters.branchId;
    }
    if (filters?.routeId) {
      where.routeId = filters.routeId;
    }
    if (filters?.customerId) {
      where.customerId = filters.customerId;
    }

    const dateFilter: Prisma.DateTimeFilter<"DeliveryOrder"> = {};
    if (filters?.startDate) {
      dateFilter.gte = new Date(filters.startDate);
    }
    if (filters?.endDate) {
      dateFilter.lte = new Date(filters.endDate);
    }
    if (filters?.startDate || filters?.endDate) {
      where.createdAt = dateFilter;
    }

    if (filters?.scheduledDate) {
      const start = new Date(filters.scheduledDate);
      const end = new Date(start);
      end.setDate(end.getDate() + 1);
      where.scheduledDate = { gte: start, lt: end };
    }

    return where;
  }

  /** ---------------------------------------------------------------- */
  /*  CRUD                                                              */
  /** ---------------------------------------------------------------- */

  async findAll(
    companyId: string,
    options: ListOptions,
  ): Promise<PaginatedResult<unknown>> {
    const { page = 1, limit = 10, filters } = options;
    const skip = (page - 1) * limit;

    const baseWhere = this.companyScope(companyId);
    const where = this.applyFilters(baseWhere, filters);

    const [data, total] = await Promise.all([
      this.prisma.deliveryOrder.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: { select: { id: true, name: true, phone: true, address: true } },
          branch: { select: { id: true, name: true } },
          driver: { select: { id: true, fullName: true } },
          vehicle: { select: { id: true, plateNumber: true, type: true } },
          route: { select: { id: true, name: true } },
          invoice: { select: { id: true, invoiceNumber: true, totalAmount: true, balance: true } },
        },
      }),
      this.prisma.deliveryOrder.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOne(id: string, companyId: string): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId, {
      customer: { select: { id: true, name: true, phone: true, address: true } },
      branch: { select: { id: true, name: true, address: true } },
      driver: { select: { id: true, fullName: true, phone: true } },
      vehicle: { select: { id: true, plateNumber: true, type: true, status: true } },
      route: { select: { id: true, name: true, startPoint: true, endPoint: true } },
      invoice: {
        select: {
          id: true,
          invoiceNumber: true,
          totalAmount: true,
          balance: true,
          status: true,
          lines: {
            select: {
              id: true,
              quantity: true,
              unitPrice: true,
              totalPrice: true,
              product: { select: { id: true, name: true, code: true } },
            },
          },
        },
      },
      trackingRecords: {
        orderBy: { timestamp: 'desc' },
      },
    });

    return { data: delivery };
  }

  async create(
    companyId: string,
    dto: CreateDeliveryDto,
  ): Promise<{ data: unknown }> {
    // Verify branch belongs to company
    const branch = await this.prisma.branch.findFirst({
      where: { id: dto.branchId, companyId },
    });
    if (!branch) {
      throw new NotFoundException('Branch not found for this company');
    }

    // Verify customer belongs to company (scoped through branch)
    const customer = await this.prisma.customer.findFirst({
      where: { id: dto.customerId, branch: { companyId } },
    });
    if (!customer) {
      throw new NotFoundException('Customer not found for this company');
    }

    // Verify invoice exists and belongs to the same customer & branch
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: {
        id: dto.invoiceId,
        customerId: dto.customerId,
        branchId: dto.branchId,
      },
      select: { id: true, invoiceNumber: true },
    });
    if (!invoice) {
      throw new NotFoundException(
        'Invoice not found or does not match customer/branch',
      );
    }

    // Generate order number
    const orderNumber = `DLV-${Date.now().toString(36).toUpperCase()}`;

    const delivery = await this.prisma.deliveryOrder.create({
      data: {
        orderNumber,
        status: DeliveryStatus.PENDING,
        invoiceId: dto.invoiceId,
        customerId: dto.customerId,
        branchId: dto.branchId,
        routeId: dto.routeId ?? null,
        scheduledDate: dto.scheduledDate
          ? new Date(dto.scheduledDate)
          : null,
        notes: dto.notes ?? null,
      },
      include: {
        customer: { select: { id: true, name: true, phone: true } },
        branch: { select: { id: true, name: true } },
        invoice: { select: { id: true, invoiceNumber: true, totalAmount: true } },
        route: { select: { id: true, name: true } },
      },
    });

    this.logger.log(`Delivery order created: ${delivery.orderNumber}`);
    return { data: delivery };
  }

  /** Soft-delete a delivery order (only if not in active transit). */
  async remove(id: string, companyId: string): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);

    const activeStatuses: DeliveryStatus[] = [
      DeliveryStatus.IN_TRANSIT,
      DeliveryStatus.AT_CUSTOMER,
      DeliveryStatus.DELIVERED,
      DeliveryStatus.PAYMENT_COLLECTED,
      DeliveryStatus.CLOSED,
      DeliveryStatus.FAILED_CLOSED,
    ];
    if (activeStatuses.includes(delivery.status)) {
      throw new BadRequestException(
        `Cannot delete a delivery with status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: { deletedAt: new Date(), status: DeliveryStatus.FAILED_CLOSED },
    });

    this.logger.log(`Delivery order ${delivery.orderNumber} soft-deleted`);
    return { data: updated };
  }

  /** ---------------------------------------------------------------- */
  /*  12-Step Status Workflow                                           */
  /*  PENDING -> CONFIRMED -> APPROVED -> PICKING -> PICKED_LOADED      */
  /*  -> DRIVER_ASSIGNED -> IN_TRANSIT -> AT_CUSTOMER -> DELIVERED      */
  /*  -> PAYMENT_COLLECTED -> CLOSED                                    */
  /*  FAILED_CLOSED is a terminal failure state.                        */
  /** ---------------------------------------------------------------- */

  /** Step 1->2: PENDING -> CONFIRMED */
  async confirmDeliveryOrder(
    id: string,
    companyId: string,
    dto: ConfirmDeliveryOrderDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.CONFIRMED)) {
      throw new BadRequestException(
        `Cannot confirm delivery from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.CONFIRMED,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true } },
        driver: { select: { id: true, fullName: true } },
        vehicle: { select: { id: true, plateNumber: true } },
        invoice: { select: { id: true, invoiceNumber: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} confirmed`);
    return { data: updated };
  }

  /** Step 2->3: CONFIRMED -> APPROVED */
  async approveDelivery(
    id: string,
    companyId: string,
    dto: ApproveDeliveryDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.APPROVED)) {
      throw new BadRequestException(
        `Cannot approve delivery from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.APPROVED,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true } },
        invoice: { select: { id: true, invoiceNumber: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} approved`);
    return { data: updated };
  }

  /** Step 3->4: APPROVED -> PICKING */
  async startPicking(
    id: string,
    companyId: string,
    dto: StartPickingDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.PICKING)) {
      throw new BadRequestException(
        `Cannot start picking from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.PICKING,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true } },
        invoice: { select: { id: true, invoiceNumber: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} picking started`);
    return { data: updated };
  }

  /** Step 4->5: PICKING -> PICKED_LOADED */
  async confirmPickedLoaded(
    id: string,
    companyId: string,
    dto: ConfirmPickedLoadedDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.PICKED_LOADED)) {
      throw new BadRequestException(
        `Cannot confirm picked/loaded from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.PICKED_LOADED,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true } },
        driver: { select: { id: true, fullName: true } },
        vehicle: { select: { id: true, plateNumber: true } },
        invoice: { select: { id: true, invoiceNumber: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} picked and loaded`);
    return { data: updated };
  }

  /** Step 5->6: PICKED_LOADED -> DRIVER_ASSIGNED */
  async assignDriver(
    id: string,
    companyId: string,
    dto: AssignDriverDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.DRIVER_ASSIGNED)) {
      throw new BadRequestException(
        `Cannot assign driver from status ${delivery.status}`,
      );
    }

    // Verify driver exists and belongs to the company
    const driver = await this.prisma.user.findFirst({
      where: { id: dto.driverId, companyId, status: 'ACTIVE' },
    });
    if (!driver) {
      throw new NotFoundException(
        'Driver (user) not found or not active for this company',
      );
    }

    // Verify vehicle exists and belongs to the company (via branch)
    const vehicle = await this.prisma.vehicle.findFirst({
      where: {
        id: dto.vehicleId,
        branch: { companyId },
        status: 'ACTIVE',
      },
    });
    if (!vehicle) {
      throw new NotFoundException(
        'Vehicle not found or not active for this company',
      );
    }

    const updateData: Prisma.DeliveryOrderUpdateInput = {
      status: DeliveryStatus.DRIVER_ASSIGNED,
      driver: { connect: { id: dto.driverId } },
      vehicle: { connect: { id: dto.vehicleId } },
    };
    if (dto.routeId) {
      updateData.route = { connect: { id: dto.routeId } };
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: updateData,
      include: {
        customer: { select: { id: true, name: true } },
        driver: { select: { id: true, fullName: true } },
        vehicle: { select: { id: true, plateNumber: true, type: true } },
        route: { select: { id: true, name: true } },
        invoice: { select: { id: true, invoiceNumber: true } },
      },
    });

    this.logger.log(
      `Delivery ${delivery.orderNumber} assigned to driver ${dto.driverId} / vehicle ${dto.vehicleId}`,
    );
    return { data: updated };
  }

  /** Step 6->7: DRIVER_ASSIGNED -> IN_TRANSIT */
  async startTransit(
    id: string,
    companyId: string,
    dto: StartTransitDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.IN_TRANSIT)) {
      throw new BadRequestException(
        `Cannot start transit from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.IN_TRANSIT,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true, address: true } },
        driver: { select: { id: true, fullName: true } },
        vehicle: { select: { id: true, plateNumber: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} in transit`);
    return { data: updated };
  }

  /** Step 7->8: IN_TRANSIT -> AT_CUSTOMER */
  async atCustomer(
    id: string,
    companyId: string,
    dto: AtCustomerDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.AT_CUSTOMER)) {
      throw new BadRequestException(
        `Cannot mark at-customer from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.AT_CUSTOMER,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true } },
        driver: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} arrived at customer`);
    return { data: updated };
  }

  /** Step 8->9: AT_CUSTOMER -> DELIVERED */
  async confirmDelivery(
    id: string,
    companyId: string,
    dto: DeliveryConfirmationDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.DELIVERED)) {
      throw new BadRequestException(
        `Cannot confirm delivery from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.DELIVERED,
        deliveryDate: new Date(),
        customerSignature: dto.customerSignature ?? delivery.customerSignature,
        photoUrl: dto.photoUrl ?? delivery.photoUrl,
        gpsCoordinates: dto.gpsCoordinates ?? delivery.gpsCoordinates,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true, phone: true } },
        driver: { select: { id: true, fullName: true } },
        invoice: { select: { id: true, invoiceNumber: true, totalAmount: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} confirmed delivered`);
    return { data: updated };
  }

  /** Step 9->10: DELIVERED -> PAYMENT_COLLECTED */
  async collectPayment(
    id: string,
    companyId: string,
    dto: PaymentCollectionDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.PAYMENT_COLLECTED)) {
      throw new BadRequestException(
        'Payment can only be collected for delivered orders',
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.PAYMENT_COLLECTED,
        paymentCollected: new Prisma.Decimal(dto.amount),
        paymentMethod: dto.paymentMethod,
        notes: dto.notes
          ? delivery.notes
            ? `${delivery.notes}\n${dto.notes}`
            : dto.notes
          : delivery.notes,
      },
      include: {
        customer: { select: { id: true, name: true, phone: true } },
        driver: { select: { id: true, fullName: true } },
        invoice: { select: { id: true, invoiceNumber: true, totalAmount: true, balance: true } },
      },
    });

    this.logger.log(
      `Payment collected for delivery ${delivery.orderNumber}: ${dto.amount}`,
    );
    return { data: updated };
  }

  /** Step 10->11: PAYMENT_COLLECTED -> CLOSED */
  async closeDelivery(
    id: string,
    companyId: string,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);
    if (!this.canTransition(delivery.status, DeliveryStatus.CLOSED)) {
      throw new BadRequestException(
        `Cannot close delivery from status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: { status: DeliveryStatus.CLOSED },
      include: {
        customer: { select: { id: true, name: true } },
        driver: { select: { id: true, fullName: true } },
        invoice: { select: { id: true, invoiceNumber: true } },
      },
    });

    this.logger.log(`Delivery ${delivery.orderNumber} closed`);
    return { data: updated };
  }

  /** Any non-terminal -> FAILED_CLOSED */
  async failDelivery(
    id: string,
    companyId: string,
    dto: FailDeliveryDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);

    const terminalStatuses: DeliveryStatus[] = [
      DeliveryStatus.CLOSED,
      DeliveryStatus.FAILED_CLOSED,
    ];
    if (terminalStatuses.includes(delivery.status)) {
      throw new BadRequestException(
        `Cannot fail a delivery already in status ${delivery.status}`,
      );
    }

    const updated = await this.prisma.deliveryOrder.update({
      where: { id },
      data: {
        status: DeliveryStatus.FAILED_CLOSED,
        notes: delivery.notes
          ? `${delivery.notes}\nFAILED: ${dto.reason}`
          : `FAILED: ${dto.reason}`,
      },
      include: {
        customer: { select: { id: true, name: true } },
        driver: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(
      `Delivery ${delivery.orderNumber} failed: ${dto.reason}`,
    );
    return { data: updated };
  }

  /** ---------------------------------------------------------------- */
  /*  GPS Tracking                                                      */
  /** ---------------------------------------------------------------- */

  /**
   * Record a GPS tracking point for a delivery.
   * Creates a DeliveryTracking record and optionally updates
   * the delivery's gpsCoordinates string field.
   */
  async recordTrackingPoint(
    id: string,
    companyId: string,
    dto: GpsTrackingUpdateDto,
  ): Promise<{ data: unknown }> {
    const delivery = await this.findDeliveryForCompany(id, companyId);

    if (
      delivery.status !== DeliveryStatus.IN_TRANSIT &&
      delivery.status !== DeliveryStatus.DRIVER_ASSIGNED &&
      delivery.status !== DeliveryStatus.AT_CUSTOMER
    ) {
      throw new BadRequestException(
        'Cannot record GPS tracking for a delivery not assigned to a driver or in transit',
      );
    }

    // Create tracking record
    const trackingRecord = await this.prisma.deliveryTracking.create({
      data: {
        delivery: { connect: { id } },
        timestamp: new Date(),
        latitude: new Prisma.Decimal(dto.latitude),
        longitude: new Prisma.Decimal(dto.longitude),
        status: dto.status
          ? (dto.status as DeliveryStatus)
          : delivery.status,
        notes: dto.notes ?? null,
      },
    });

    // Update current GPS coordinates on the delivery order
    const gpsString = `${dto.latitude},${dto.longitude}`;
    await this.prisma.deliveryOrder.update({
      where: { id },
      data: { gpsCoordinates: gpsString },
    });

    return { data: trackingRecord };
  }

  /** Get full GPS tracking history for a delivery. */
  async getTrackingHistory(
    id: string,
    companyId: string,
  ): Promise<{ data: unknown[] }> {
    await this.findDeliveryForCompany(id, companyId);

    const records = await this.prisma.deliveryTracking.findMany({
      where: { deliveryId: id },
      orderBy: { timestamp: 'asc' },
    });

    return { data: records };
  }

  /** ---------------------------------------------------------------- */
  /*  Delivery Routes                                                   */
  /** ---------------------------------------------------------------- */

  async createRoute(
    dto: CreateDeliveryRouteDto,
  ): Promise<{ data: unknown }> {
    const route = await this.prisma.deliveryRoute.create({
      data: {
        name: dto.name,
        startPoint: dto.startPoint,
        endPoint: dto.endPoint,
        waypoints: dto.waypoints ?? null,
        estimatedDistance:
          dto.estimatedDistance != null
            ? new Prisma.Decimal(dto.estimatedDistance)
            : null,
        estimatedTime: dto.estimatedTime ?? null,
      },
    });

    this.logger.log(`Delivery route created: ${route.name}`);
    return { data: route };
  }

  async findAllRoutes(
    options: ListOptions,
  ): Promise<PaginatedResult<unknown>> {
    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const [data, total] = await Promise.all([
      this.prisma.deliveryRoute.findMany({
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { deliveryOrders: true } },
        },
      }),
      this.prisma.deliveryRoute.count(),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOneRoute(id: string): Promise<{ data: unknown }> {
    const route = await this.prisma.deliveryRoute.findUnique({
      where: { id },
      include: {
        deliveryOrders: {
          select: {
            id: true,
            orderNumber: true,
            status: true,
            scheduledDate: true,
            deliveryDate: true,
          },
        },
      },
    });
    if (!route) {
      throw new NotFoundException(`Delivery route with ID ${id} not found`);
    }
    return { data: route };
  }

  async updateRoute(
    id: string,
    dto: UpdateDeliveryRouteDto,
  ): Promise<{ data: unknown }> {
    await this.findOneRoute(id);

    const updateData: Prisma.DeliveryRouteUpdateInput = {};
    if (dto.name !== undefined) updateData.name = dto.name;
    if (dto.startPoint !== undefined) updateData.startPoint = dto.startPoint;
    if (dto.endPoint !== undefined) updateData.endPoint = dto.endPoint;
    if (dto.waypoints !== undefined) updateData.waypoints = dto.waypoints;
    if (dto.estimatedDistance !== undefined) {
      updateData.estimatedDistance = new Prisma.Decimal(dto.estimatedDistance);
    }
    if (dto.estimatedTime !== undefined) {
      updateData.estimatedTime = dto.estimatedTime;
    }

    const updated = await this.prisma.deliveryRoute.update({
      where: { id },
      data: updateData,
    });

    this.logger.log(`Delivery route ${id} updated`);
    return { data: updated };
  }

  async deleteRoute(id: string): Promise<{ data: unknown }> {
    await this.findOneRoute(id);

    const deleted = await this.prisma.deliveryRoute.delete({
      where: { id },
    });

    this.logger.log(`Delivery route ${id} deleted`);
    return { data: deleted };
  }

  /** ---------------------------------------------------------------- */
  /*  Analytics                                                         */
  /** ---------------------------------------------------------------- */

  /** Calculate on-time delivery rate (%) for a company. */
  async onTimeRate(companyId: string): Promise<{
    data: { totalCompleted: number; onTime: number; rate: number };
  }> {
    const baseWhere = this.companyScope(companyId);

    const [totalCompleted, onTime] = await Promise.all([
      this.prisma.deliveryOrder.count({
        where: {
          ...baseWhere,
          deletedAt: null,
          status: {
            in: [
              DeliveryStatus.DELIVERED,
              DeliveryStatus.PAYMENT_COLLECTED,
              DeliveryStatus.CLOSED,
            ],
          },
        },
      }),
      this.prisma.deliveryOrder.count({
        where: {
          ...baseWhere,
          deletedAt: null,
          status: {
            in: [
              DeliveryStatus.DELIVERED,
              DeliveryStatus.PAYMENT_COLLECTED,
              DeliveryStatus.CLOSED,
            ],
          },
          deliveryDate: { not: null },
          scheduledDate: { not: null },
        },
      }),
    ]);

    // Refinement: count truly on-time (delivered on or before scheduled date)
    const onTimeDeliveries = await this.prisma.deliveryOrder.findMany({
      where: {
        ...baseWhere,
        deletedAt: null,
        status: {
          in: [
            DeliveryStatus.DELIVERED,
            DeliveryStatus.PAYMENT_COLLECTED,
            DeliveryStatus.CLOSED,
          ],
        },
        deliveryDate: { not: null },
        scheduledDate: { not: null },
      },
      select: { deliveryDate: true, scheduledDate: true },
    });

    const onTimeCount = onTimeDeliveries.filter(
      (d) =>
        d.deliveryDate &&
        d.scheduledDate &&
        d.deliveryDate <= d.scheduledDate,
    ).length;

    const rate = totalCompleted > 0 ? (onTimeCount / totalCompleted) * 100 : 0;

    return {
      data: {
        totalCompleted,
        onTime: onTimeCount,
        rate: Math.round(rate * 100) / 100,
      },
    };
  }

  /** Calculate failed delivery rate (%) for a company. */
  async failedDeliveryRate(companyId: string): Promise<{
    data: { total: number; failed: number; rate: number };
  }> {
    const baseWhere = this.companyScope(companyId);

    const [total, failed] = await Promise.all([
      this.prisma.deliveryOrder.count({
        where: { ...baseWhere, deletedAt: null },
      }),
      this.prisma.deliveryOrder.count({
        where: {
          ...baseWhere,
          deletedAt: null,
          status: DeliveryStatus.FAILED_CLOSED,
        },
      }),
    ]);

    const rate = total > 0 ? (failed / total) * 100 : 0;

    return {
      data: { total, failed, rate: Math.round(rate * 100) / 100 },
    };
  }

  /** Delivery summary by status for a company. */
  async deliverySummary(companyId: string): Promise<{
    data: { status: string; count: number }[];
  }> {
    const baseWhere = this.companyScope(companyId);

    const counts = await this.prisma.deliveryOrder.groupBy({
      by: ['status'],
      where: { ...baseWhere, deletedAt: null },
      _count: { status: true },
    });

    const data = counts.map((c) => ({
      status: c.status,
      count: c._count.status,
    }));

    return { data };
  }

  /** ---------------------------------------------------------------- */
  /*  Customer Delivery History                                         */
  /** ---------------------------------------------------------------- */

  /** Get delivery history for a specific customer. */
  async customerDeliveryHistory(
    customerId: string,
    companyId: string,
    options: ListOptions,
  ): Promise<PaginatedResult<unknown>> {
    const { page = 1, limit = 10, filters } = options;
    const skip = (page - 1) * limit;

    // Verify customer belongs to company
    const customer = await this.prisma.customer.findFirst({
      where: { id: customerId, branch: { companyId } },
    });
    if (!customer) {
      throw new NotFoundException(
        'Customer not found for this company',
      );
    }

    const where: Prisma.DeliveryOrderWhereInput = {
      customerId,
      branch: { companyId },
      deletedAt: null,
    };

    if (filters?.status) where.status = filters.status;
    if (filters?.startDate) {
      where.createdAt = { gte: new Date(filters.startDate) };
    }
    if (filters?.endDate) {
      where.createdAt = {
        ...((where.createdAt as Prisma.DateTimeFilter<"DeliveryOrder">) ?? {}),
        lte: new Date(filters.endDate),
      };
    }

    const [data, total] = await Promise.all([
      this.prisma.deliveryOrder.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          branch: { select: { id: true, name: true } },
          driver: { select: { id: true, fullName: true } },
          vehicle: { select: { id: true, plateNumber: true } },
          route: { select: { id: true, name: true } },
          invoice: { select: { id: true, invoiceNumber: true, totalAmount: true } },
          trackingRecords: {
            orderBy: { timestamp: 'desc' },
            take: 5,
          },
        },
      }),
      this.prisma.deliveryOrder.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /** ---------------------------------------------------------------- */
  /*  Driver Deliveries                                                 */
  /** ---------------------------------------------------------------- */

  /** Get all active deliveries assigned to a driver. */
  async driverDeliveries(
    driverId: string,
    companyId: string,
  ): Promise<{ data: unknown[] }> {
    const baseWhere = this.companyScope(companyId);

    const deliveries = await this.prisma.deliveryOrder.findMany({
      where: {
        ...baseWhere,
        driverId,
        deletedAt: null,
        status: {
          in: [
            DeliveryStatus.DRIVER_ASSIGNED,
            DeliveryStatus.IN_TRANSIT,
            DeliveryStatus.AT_CUSTOMER,
          ],
        },
      },
      orderBy: { scheduledDate: 'asc' },
      include: {
        customer: { select: { id: true, name: true, phone: true, address: true } },
        branch: { select: { id: true, name: true } },
        vehicle: { select: { id: true, plateNumber: true } },
        route: { select: { id: true, name: true } },
        invoice: { select: { id: true, invoiceNumber: true, totalAmount: true } },
        trackingRecords: {
          orderBy: { timestamp: 'desc' },
          take: 1,
        },
      },
    });

    return { data: deliveries };
  }
}
