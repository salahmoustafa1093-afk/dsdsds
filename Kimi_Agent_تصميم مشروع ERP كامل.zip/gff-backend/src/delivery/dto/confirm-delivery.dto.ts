import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsOptional, MaxLength } from 'class-validator';

export class DeliveryConfirmationDto {
  @ApiProperty({
    description: 'Customer signature (base64 encoded image or URL)',
    example: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...',
    required: false,
  })
  @IsOptional()
  @IsString()
  customerSignature?: string;

  @ApiProperty({
    description: 'Delivery photo URL',
    example: 'https://cdn.example.com/delivery-photo.jpg',
    required: false,
  })
  @IsOptional()
  @IsString()
  photoUrl?: string;

  @ApiProperty({
    description: 'GPS coordinates at delivery point (lat,lng)',
    example: '31.9454,35.9284',
    required: false,
  })
  @IsOptional()
  @IsString()
  gpsCoordinates?: string;

  @ApiProperty({
    description: 'Delivery confirmation notes',
    example: 'Delivered to customer in person',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}
