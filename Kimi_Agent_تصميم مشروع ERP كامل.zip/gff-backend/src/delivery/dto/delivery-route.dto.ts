import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
} from 'class-validator';

export class CreateDeliveryRouteDto {
  @ApiProperty({
    description: 'Route name',
    example: 'Amman City Center Loop',
  })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({
    description: 'Starting point address or coordinates',
    example: 'Warehouse A, Amman',
  })
  @IsString()
  @IsNotEmpty()
  startPoint: string;

  @ApiProperty({
    description: 'Ending point address or coordinates',
    example: 'Industrial Zone, Amman',
  })
  @IsString()
  @IsNotEmpty()
  endPoint: string;

  @ApiProperty({
    description: 'JSON array of waypoint strings',
    example: '["Stop 1","Stop 2","Stop 3"]',
    required: false,
  })
  @IsOptional()
  @IsString()
  waypoints?: string;

  @ApiProperty({
    description: 'Estimated distance in kilometers',
    example: 45.5,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  estimatedDistance?: number;

  @ApiProperty({
    description: 'Estimated time in minutes',
    example: 120,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  estimatedTime?: number;
}

export class UpdateDeliveryRouteDto {
  @ApiProperty({
    description: 'Route name',
    example: 'Amman City Center Loop',
    required: false,
  })
  @IsOptional()
  @IsString()
  @IsNotEmpty()
  name?: string;

  @ApiProperty({
    description: 'Starting point address or coordinates',
    example: 'Warehouse A, Amman',
    required: false,
  })
  @IsOptional()
  @IsString()
  startPoint?: string;

  @ApiProperty({
    description: 'Ending point address or coordinates',
    example: 'Industrial Zone, Amman',
    required: false,
  })
  @IsOptional()
  @IsString()
  endPoint?: string;

  @ApiProperty({
    description: 'JSON array of waypoint strings',
    example: '["Stop 1","Stop 2","Stop 3"]',
    required: false,
  })
  @IsOptional()
  @IsString()
  waypoints?: string;

  @ApiProperty({
    description: 'Estimated distance in kilometers',
    example: 45.5,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  estimatedDistance?: number;

  @ApiProperty({
    description: 'Estimated time in minutes',
    example: 120,
    required: false,
  })
  @IsOptional()
  @IsNumber()
  estimatedTime?: number;
}
