import { ApiProperty } from '@nestjs/swagger';
import { IsUUID, IsOptional } from 'class-validator';

export class AssignDriverDto {
  @ApiProperty({
    description: 'Driver (User) ID to assign',
    example: '550e8400-e29b-41d4-a716-446655440000',
  })
  @IsUUID()
  driverId: string;

  @ApiProperty({
    description: 'Vehicle ID to assign',
    example: '550e8400-e29b-41d4-a716-446655440001',
  })
  @IsUUID()
  vehicleId: string;

  @ApiProperty({
    description: 'Route ID to assign',
    example: '550e8400-e29b-41d4-a716-446655440003',
    required: false,
  })
  @IsOptional()
  @IsUUID()
  routeId?: string;
}
