import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsOptional, MaxLength } from 'class-validator';

export class ConfirmDeliveryOrderDto {
  @ApiProperty({
    description: 'Confirmation notes',
    example: 'Order confirmed for delivery',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}

export class ApproveDeliveryDto {
  @ApiProperty({
    description: 'Approval notes',
    example: 'Approved by warehouse manager',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}

export class StartPickingDto {
  @ApiProperty({
    description: 'Picking notes',
    example: 'Picking started at 09:00',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}

export class ConfirmPickedLoadedDto {
  @ApiProperty({
    description: 'Loading confirmation notes',
    example: 'All items loaded on vehicle',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}

export class StartTransitDto {
  @ApiProperty({
    description: 'Transit start notes',
    example: 'Driver departed from warehouse',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}

export class AtCustomerDto {
  @ApiProperty({
    description: 'Arrival notes',
    example: 'Arrived at customer location',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}
