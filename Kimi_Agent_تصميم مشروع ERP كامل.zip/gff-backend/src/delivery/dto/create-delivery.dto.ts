import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsUUID,
  IsDateString,
} from 'class-validator';

export class CreateDeliveryDto {
  @ApiProperty({
    description: 'Sales invoice ID to create delivery from',
    example: '550e8400-e29b-41d4-a716-446655440000',
  })
  @IsUUID()
  invoiceId: string;

  @ApiProperty({
    description: 'Customer ID (must match invoice customer)',
    example: '550e8400-e29b-41d4-a716-446655440001',
  })
  @IsUUID()
  customerId: string;

  @ApiProperty({
    description: 'Branch ID for the delivery',
    example: '550e8400-e29b-41d4-a716-446655440002',
  })
  @IsUUID()
  branchId: string;

  @ApiProperty({
    description: 'Scheduled delivery date',
    example: '2024-01-20T08:00:00.000Z',
    required: false,
  })
  @IsOptional()
  @IsDateString()
  scheduledDate?: string;

  @ApiProperty({
    description: 'Route ID for the delivery',
    example: '550e8400-e29b-41d4-a716-446655440003',
    required: false,
  })
  @IsOptional()
  @IsUUID()
  routeId?: string;

  @ApiProperty({
    description: 'Additional notes',
    example: 'Please deliver before noon',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;
}
