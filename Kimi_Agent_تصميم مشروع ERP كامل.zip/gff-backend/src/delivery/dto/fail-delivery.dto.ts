import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, MaxLength } from 'class-validator';

export class FailDeliveryDto {
  @ApiProperty({
    description: 'Reason for delivery failure',
    example: 'Customer not available at address',
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(1000)
  reason: string;
}
