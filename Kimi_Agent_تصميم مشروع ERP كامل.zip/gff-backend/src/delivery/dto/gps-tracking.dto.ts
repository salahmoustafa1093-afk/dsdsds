import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString, IsOptional, MaxLength } from 'class-validator';

export class GpsTrackingUpdateDto {
  @ApiProperty({
    description: 'Latitude coordinate',
    example: 31.9454,
  })
  @IsNumber()
  latitude: number;

  @ApiProperty({
    description: 'Longitude coordinate',
    example: 35.9284,
  })
  @IsNumber()
  longitude: number;

  @ApiProperty({
    description: 'Status at this tracking point',
    example: 'IN_TRANSIT',
    required: false,
  })
  @IsOptional()
  @IsString()
  status?: string;

  @ApiProperty({
    description: 'Optional notes for this tracking point',
    example: 'Stopped for refuel',
    required: false,
  })
  @IsOptional()
  @IsString()
  @MaxLength(500)
  notes?: string;
}
