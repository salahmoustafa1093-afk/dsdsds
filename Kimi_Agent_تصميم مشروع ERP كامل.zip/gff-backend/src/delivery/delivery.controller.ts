import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { DeliveryService } from './delivery.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateDeliveryDto,
  AssignDriverDto,
  ConfirmDeliveryOrderDto,
  ApproveDeliveryDto,
  StartPickingDto,
  ConfirmPickedLoadedDto,
  StartTransitDto,
  AtCustomerDto,
  GpsTrackingUpdateDto,
  DeliveryConfirmationDto,
  PaymentCollectionDto,
  FailDeliveryDto,
  DeliveryFilterDto,
  CreateDeliveryRouteDto,
  UpdateDeliveryRouteDto,
} from './dto';

@ApiTags('Delivery')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('deliveries')
export class DeliveryController {
  constructor(private readonly deliveryService: DeliveryService) {}

  // ========================= CRUD =========================

  @Get()
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'List delivery orders with filters' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'driverId', required: false })
  @ApiQuery({ name: 'vehicleId', required: false })
  @ApiQuery({ name: 'branchId', required: false })
  @ApiQuery({ name: 'routeId', required: false })
  @ApiQuery({ name: 'customerId', required: false })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiQuery({ name: 'scheduledDate', required: false })
  @ApiResponse({ status: 200, description: 'Delivery orders retrieved' })
  async findAll(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query() filters?: DeliveryFilterDto,
  ) {
    return this.deliveryService.findAll(companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
      filters,
    });
  }

  @Get(':id')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'Get delivery order detail' })
  @ApiResponse({ status: 200, description: 'Delivery order retrieved' })
  @ApiResponse({ status: 404, description: 'Delivery order not found' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.deliveryService.findOne(id, companyId);
  }

  @Post()
  @Permissions('delivery:create')
  @ApiOperation({ summary: 'Create a delivery order from an invoice' })
  @ApiResponse({ status: 201, description: 'Delivery order created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async create(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateDeliveryDto,
  ) {
    return this.deliveryService.create(companyId, dto);
  }

  @Delete(':id')
  @Permissions('delivery:delete')
  @ApiOperation({ summary: 'Soft-delete a delivery order' })
  @ApiResponse({ status: 200, description: 'Delivery order deleted' })
  @ApiResponse({ status: 404, description: 'Delivery order not found' })
  @ApiResponse({ status: 400, description: 'Cannot delete active delivery' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.deliveryService.remove(id, companyId);
  }

  // ========================= 12-STEP WORKFLOW =========================

  /** Step 1->2: PENDING -> CONFIRMED */
  @Put(':id/confirm')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Confirm delivery order (PENDING -> CONFIRMED)' })
  @ApiResponse({ status: 200, description: 'Delivery confirmed' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async confirmDeliveryOrder(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: ConfirmDeliveryOrderDto,
  ) {
    return this.deliveryService.confirmDeliveryOrder(id, companyId, dto);
  }

  /** Step 2->3: CONFIRMED -> APPROVED */
  @Put(':id/approve')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Approve delivery (CONFIRMED -> APPROVED)' })
  @ApiResponse({ status: 200, description: 'Delivery approved' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async approveDelivery(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: ApproveDeliveryDto,
  ) {
    return this.deliveryService.approveDelivery(id, companyId, dto);
  }

  /** Step 3->4: APPROVED -> PICKING */
  @Put(':id/pick')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Start warehouse picking (APPROVED -> PICKING)' })
  @ApiResponse({ status: 200, description: 'Picking started' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async startPicking(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: StartPickingDto,
  ) {
    return this.deliveryService.startPicking(id, companyId, dto);
  }

  /** Step 4->5: PICKING -> PICKED_LOADED */
  @Put(':id/picked-loaded')
  @Permissions('delivery:update')
  @ApiOperation({
    summary: 'Confirm picked & loaded (PICKING -> PICKED_LOADED)',
  })
  @ApiResponse({ status: 200, description: 'Picked and loaded confirmed' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async confirmPickedLoaded(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: ConfirmPickedLoadedDto,
  ) {
    return this.deliveryService.confirmPickedLoaded(id, companyId, dto);
  }

  /** Step 5->6: PICKED_LOADED -> DRIVER_ASSIGNED */
  @Put(':id/assign-driver')
  @Permissions('delivery:assign')
  @ApiOperation({
    summary: 'Assign driver and vehicle (PICKED_LOADED -> DRIVER_ASSIGNED)',
  })
  @ApiResponse({ status: 200, description: 'Driver assigned' })
  @ApiResponse({ status: 404, description: 'Delivery/driver/vehicle not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async assignDriver(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: AssignDriverDto,
  ) {
    return this.deliveryService.assignDriver(id, companyId, dto);
  }

  /** Step 6->7: DRIVER_ASSIGNED -> IN_TRANSIT */
  @Put(':id/transit')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Start transit (DRIVER_ASSIGNED -> IN_TRANSIT)' })
  @ApiResponse({ status: 200, description: 'Transit started' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async startTransit(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: StartTransitDto,
  ) {
    return this.deliveryService.startTransit(id, companyId, dto);
  }

  /** Step 7->8: IN_TRANSIT -> AT_CUSTOMER */
  @Put(':id/at-customer')
  @Permissions('delivery:update')
  @ApiOperation({
    summary: 'Mark arrived at customer (IN_TRANSIT -> AT_CUSTOMER)',
  })
  @ApiResponse({ status: 200, description: 'Arrived at customer' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async atCustomer(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: AtCustomerDto,
  ) {
    return this.deliveryService.atCustomer(id, companyId, dto);
  }

  /** Step 8->9: AT_CUSTOMER -> DELIVERED */
  @Put(':id/confirm-delivery')
  @Permissions('delivery:update')
  @ApiOperation({
    summary: 'Confirm delivery with signature/photo (AT_CUSTOMER -> DELIVERED)',
  })
  @ApiResponse({ status: 200, description: 'Delivery confirmed' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async confirmDelivery(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: DeliveryConfirmationDto,
  ) {
    return this.deliveryService.confirmDelivery(id, companyId, dto);
  }

  /** Step 9->10: DELIVERED -> PAYMENT_COLLECTED */
  @Put(':id/payment')
  @Permissions('delivery:update')
  @ApiOperation({
    summary: 'Collect payment on delivery (DELIVERED -> PAYMENT_COLLECTED)',
  })
  @ApiResponse({ status: 200, description: 'Payment collected' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status for payment' })
  async collectPayment(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: PaymentCollectionDto,
  ) {
    return this.deliveryService.collectPayment(id, companyId, dto);
  }

  /** Step 10->11: PAYMENT_COLLECTED -> CLOSED */
  @Put(':id/close')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Close delivery (PAYMENT_COLLECTED -> CLOSED)' })
  @ApiResponse({ status: 200, description: 'Delivery closed' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  async closeDelivery(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.deliveryService.closeDelivery(id, companyId);
  }

  /** Any non-terminal -> FAILED_CLOSED */
  @Put(':id/fail')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Mark delivery as failed' })
  @ApiResponse({ status: 200, description: 'Delivery marked as failed' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Cannot fail terminal delivery' })
  async failDelivery(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: FailDeliveryDto,
  ) {
    return this.deliveryService.failDelivery(id, companyId, dto);
  }

  // ========================= GPS TRACKING =========================

  @Post(':id/track')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Record a GPS tracking point' })
  @ApiResponse({ status: 201, description: 'Tracking point recorded' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  @ApiResponse({ status: 400, description: 'Delivery not in transit' })
  async recordTrackingPoint(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: GpsTrackingUpdateDto,
  ) {
    return this.deliveryService.recordTrackingPoint(id, companyId, dto);
  }

  @Get(':id/track')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'Get GPS tracking history' })
  @ApiResponse({ status: 200, description: 'Tracking history retrieved' })
  @ApiResponse({ status: 404, description: 'Delivery not found' })
  async getTrackingHistory(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.deliveryService.getTrackingHistory(id, companyId);
  }

  // ========================= DELIVERY ROUTES =========================

  @Post('routes')
  @Permissions('delivery:create')
  @ApiOperation({ summary: 'Create a delivery route' })
  @ApiResponse({ status: 201, description: 'Route created' })
  async createRoute(@Body() dto: CreateDeliveryRouteDto) {
    return this.deliveryService.createRoute(dto);
  }

  @Get('routes/all')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'List all delivery routes' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async findAllRoutes(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.deliveryService.findAllRoutes({
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
    });
  }

  @Get('routes/:routeId')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'Get delivery route detail' })
  @ApiResponse({ status: 200, description: 'Route retrieved' })
  @ApiResponse({ status: 404, description: 'Route not found' })
  async findOneRoute(@Param('routeId', ParseUUIDPipe) routeId: string) {
    return this.deliveryService.findOneRoute(routeId);
  }

  @Put('routes/:routeId')
  @Permissions('delivery:update')
  @ApiOperation({ summary: 'Update a delivery route' })
  @ApiResponse({ status: 200, description: 'Route updated' })
  @ApiResponse({ status: 404, description: 'Route not found' })
  async updateRoute(
    @Param('routeId', ParseUUIDPipe) routeId: string,
    @Body() dto: UpdateDeliveryRouteDto,
  ) {
    return this.deliveryService.updateRoute(routeId, dto);
  }

  @Delete('routes/:routeId')
  @Permissions('delivery:delete')
  @ApiOperation({ summary: 'Delete a delivery route' })
  @ApiResponse({ status: 200, description: 'Route deleted' })
  @ApiResponse({ status: 404, description: 'Route not found' })
  async deleteRoute(@Param('routeId', ParseUUIDPipe) routeId: string) {
    return this.deliveryService.deleteRoute(routeId);
  }

  // ========================= ANALYTICS =========================

  @Get('analytics/on-time-rate')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'On-time delivery rate (%)' })
  @ApiResponse({ status: 200, description: 'Analytics retrieved' })
  async onTimeRate(@CurrentUser('companyId') companyId: string) {
    return this.deliveryService.onTimeRate(companyId);
  }

  @Get('analytics/failed-rate')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'Failed delivery rate (%)' })
  @ApiResponse({ status: 200, description: 'Analytics retrieved' })
  async failedDeliveryRate(@CurrentUser('companyId') companyId: string) {
    return this.deliveryService.failedDeliveryRate(companyId);
  }

  @Get('analytics/summary')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'Delivery summary by status' })
  @ApiResponse({ status: 200, description: 'Summary retrieved' })
  async deliverySummary(@CurrentUser('companyId') companyId: string) {
    return this.deliveryService.deliverySummary(companyId);
  }

  // ========================= CUSTOMER HISTORY =========================

  @Get('customers/:customerId/history')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'Delivery history for a customer' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiResponse({ status: 200, description: 'History retrieved' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  async customerDeliveryHistory(
    @Param('customerId', ParseUUIDPipe) customerId: string,
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query() filters?: DeliveryFilterDto,
  ) {
    return this.deliveryService.customerDeliveryHistory(
      customerId,
      companyId,
      {
        page: page ? parseInt(page, 10) : 1,
        limit: limit ? parseInt(limit, 10) : 10,
        filters,
      },
    );
  }

  // ========================= DRIVER DELIVERIES =========================

  @Get('drivers/:driverId/active')
  @Permissions('delivery:view')
  @ApiOperation({ summary: 'Active deliveries assigned to a driver' })
  @ApiResponse({ status: 200, description: 'Deliveries retrieved' })
  async driverDeliveries(
    @Param('driverId', ParseUUIDPipe) driverId: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.deliveryService.driverDeliveries(driverId, companyId);
  }
}
