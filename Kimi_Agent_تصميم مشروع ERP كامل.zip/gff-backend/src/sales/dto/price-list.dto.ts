import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  IsNumber,
  IsUUID,
  Min,
  IsDateString,
} from 'class-validator';
import { Type } from 'class-transformer';

// ─────────────── Create Price List DTO ───────────────

export class CreatePriceListDto {
  @ApiProperty({ example: 'Summer 2024 Wholesale Pricing' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000' })
  @IsUUID()
  productId: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  customerCategoryId?: string;

  @ApiProperty({ example: 50, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  minQty?: number;

  @ApiProperty({ example: 500, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  maxQty?: number;

  @ApiProperty({ example: 18.75 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  unitPrice: number;

  @ApiProperty({ example: '2024-01-01' })
  @IsDateString()
  effectiveFrom: string;

  @ApiProperty({ example: '2024-12-31', required: false })
  @IsOptional()
  @IsDateString()
  effectiveTo?: string;
}

// ─────────────── Update Price List DTO ───────────────

export class UpdatePriceListDto {
  @ApiProperty({ example: 'Updated Pricing', required: false })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  customerCategoryId?: string;

  @ApiProperty({ example: 50, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  minQty?: number;

  @ApiProperty({ example: 500, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  maxQty?: number;

  @ApiProperty({ example: 19.5, required: false })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  unitPrice?: number;

  @ApiProperty({ example: '2024-06-01', required: false })
  @IsOptional()
  @IsDateString()
  effectiveFrom?: string;

  @ApiProperty({ example: '2024-12-31', required: false })
  @IsOptional()
  @IsDateString()
  effectiveTo?: string;
}
