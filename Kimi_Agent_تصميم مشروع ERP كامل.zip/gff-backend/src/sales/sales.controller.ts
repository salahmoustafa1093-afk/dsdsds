import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { SalesService } from './sales.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateInvoiceDto,
  UpdateInvoiceDto,
  UpdateInvoiceStatusDto,
  RecordPaymentDto,
  UpdateDeliveryStatusDto,
  CreateSalesReturnDto,
  UpdateSalesReturnDto,
  CreatePriceListDto,
  UpdatePriceListDto,
  SalesFilterDto,
} from './dto';

@ApiTags('Sales')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('sales')
export class SalesController {
  constructor(private readonly salesService: SalesService) {}

  // ═══════════════════════════════════════════════════
  //  INVOICES
  // ═══════════════════════════════════════════════════

  @Get('invoices')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'List sales invoices' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiQuery({ name: 'customerId', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'channel', required: false })
  @ApiQuery({ name: 'salesRepId', required: false })
  @ApiQuery({ name: 'branchId', required: false })
  @ApiResponse({ status: 200, description: 'Invoices retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllInvoices(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query() filters?: SalesFilterDto,
  ) {
    return this.salesService.findAllInvoices(companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
      filters,
    });
  }

  @Get('invoices/:id')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get invoice by ID' })
  @ApiResponse({ status: 200, description: 'Invoice retrieved' })
  @ApiResponse({ status: 404, description: 'Invoice not found' })
  async findOneInvoice(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.findOneInvoice(id, companyId);
  }

  @Post('invoices')
  @Permissions('sales:create')
  @ApiOperation({ summary: 'Create sales invoice (draft)' })
  @ApiResponse({ status: 201, description: 'Invoice created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createInvoice(
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
    @Body() dto: CreateInvoiceDto,
  ) {
    return this.salesService.createInvoice(companyId, userId, dto);
  }

  @Put('invoices/:id')
  @Permissions('sales:update')
  @ApiOperation({ summary: 'Update draft invoice' })
  @ApiResponse({ status: 200, description: 'Invoice updated' })
  @ApiResponse({ status: 404, description: 'Invoice not found' })
  async updateInvoice(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateInvoiceDto,
  ) {
    return this.salesService.updateInvoice(id, companyId, dto);
  }

  @Delete('invoices/:id')
  @Permissions('sales:delete')
  @ApiOperation({ summary: 'Cancel/delete draft invoice' })
  @ApiResponse({ status: 200, description: 'Invoice cancelled' })
  @ApiResponse({ status: 404, description: 'Invoice not found' })
  async deleteInvoice(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.deleteInvoice(id, companyId);
  }

  @Post('invoices/:id/confirm')
  @Permissions('sales:update')
  @ApiOperation({ summary: 'Confirm draft invoice and auto-post to accounting' })
  @ApiResponse({ status: 200, description: 'Invoice confirmed' })
  @ApiResponse({ status: 404, description: 'Invoice not found' })
  async confirmInvoice(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.confirmInvoice(id, companyId);
  }

  @Post('invoices/:id/payment')
  @Permissions('sales:update')
  @ApiOperation({ summary: 'Record a payment on an invoice' })
  @ApiResponse({ status: 200, description: 'Payment recorded' })
  @ApiResponse({ status: 404, description: 'Invoice not found' })
  async recordPayment(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: RecordPaymentDto,
  ) {
    return this.salesService.recordPayment(id, companyId, dto);
  }

  @Put('invoices/:id/delivery-status')
  @Permissions('sales:update')
  @ApiOperation({ summary: 'Update delivery status of an invoice' })
  @ApiResponse({ status: 200, description: 'Delivery status updated' })
  @ApiResponse({ status: 404, description: 'Invoice not found' })
  async updateDeliveryStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateDeliveryStatusDto,
  ) {
    return this.salesService.updateDeliveryStatus(id, companyId, dto);
  }

  // ═══════════════════════════════════════════════════
  //  SALES RETURNS
  // ═══════════════════════════════════════════════════

  @Get('returns')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'List sales returns' })
  @ApiResponse({ status: 200, description: 'Returns retrieved' })
  async findAllReturns(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.salesService.findAllReturns(companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
    });
  }

  @Get('returns/:id')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get sales return by ID' })
  @ApiResponse({ status: 200, description: 'Return retrieved' })
  @ApiResponse({ status: 404, description: 'Return not found' })
  async findOneReturn(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.findOneReturn(id, companyId);
  }

  @Post('returns')
  @Permissions('sales:create')
  @ApiOperation({ summary: 'Create a sales return' })
  @ApiResponse({ status: 201, description: 'Return created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createReturn(
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
    @Body() dto: CreateSalesReturnDto,
  ) {
    return this.salesService.createReturn(companyId, userId, dto);
  }

  @Post('returns/:id/process')
  @Permissions('sales:update')
  @ApiOperation({ summary: 'Process/approve a sales return (restores stock, reverses AR)' })
  @ApiResponse({ status: 200, description: 'Return processed' })
  @ApiResponse({ status: 404, description: 'Return not found' })
  async processReturn(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
  ) {
    return this.salesService.processReturn(id, companyId, userId);
  }

  @Put('returns/:id/status')
  @Permissions('sales:update')
  @ApiOperation({ summary: 'Update return status' })
  @ApiResponse({ status: 200, description: 'Return status updated' })
  @ApiResponse({ status: 404, description: 'Return not found' })
  async updateReturnStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateSalesReturnDto,
  ) {
    return this.salesService.updateReturnStatus(id, companyId, dto);
  }

  // ═══════════════════════════════════════════════════
  //  PRICE LISTS
  // ═══════════════════════════════════════════════════

  @Get('price-lists')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'List price lists' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiResponse({ status: 200, description: 'Price lists retrieved' })
  async findAllPriceLists(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.salesService.findAllPriceLists(companyId, {
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 10,
    });
  }

  @Get('price-lists/:id')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get price list by ID' })
  @ApiResponse({ status: 200, description: 'Price list retrieved' })
  @ApiResponse({ status: 404, description: 'Price list not found' })
  async findOnePriceList(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.findOnePriceList(id, companyId);
  }

  @Post('price-lists')
  @Permissions('sales:create')
  @ApiOperation({ summary: 'Create price list entry' })
  @ApiResponse({ status: 201, description: 'Price list created' })
  async createPriceList(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreatePriceListDto,
  ) {
    return this.salesService.createPriceList(companyId, dto);
  }

  @Put('price-lists/:id')
  @Permissions('sales:update')
  @ApiOperation({ summary: 'Update price list entry' })
  @ApiResponse({ status: 200, description: 'Price list updated' })
  @ApiResponse({ status: 404, description: 'Price list not found' })
  async updatePriceList(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdatePriceListDto,
  ) {
    return this.salesService.updatePriceList(id, companyId, dto);
  }

  @Delete('price-lists/:id')
  @Permissions('sales:delete')
  @ApiOperation({ summary: 'Delete price list entry' })
  @ApiResponse({ status: 200, description: 'Price list deleted' })
  @ApiResponse({ status: 404, description: 'Price list not found' })
  async deletePriceList(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.deletePriceList(id, companyId);
  }

  // ═══════════════════════════════════════════════════
  //  CUSTOMER CREDIT
  // ═══════════════════════════════════════════════════

  @Get('customers/:id/credit-check')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Check customer credit limit and utilization' })
  @ApiResponse({ status: 200, description: 'Credit info retrieved' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  async checkCustomerCredit(
    @Param('id', ParseUUIDPipe) customerId: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.checkCustomerCredit(customerId, companyId);
  }

  // ═══════════════════════════════════════════════════
  //  REPORTS & ANALYTICS
  // ═══════════════════════════════════════════════════

  @Get('reports/summary')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get sales report summary by period' })
  @ApiResponse({ status: 200, description: 'Sales report retrieved' })
  async getSalesReport(
    @CurrentUser('companyId') companyId: string,
    @Query() filters: SalesFilterDto,
  ) {
    return this.salesService.getSalesReport(companyId, filters);
  }

  @Get('channels')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get sales grouped by channel' })
  @ApiResponse({ status: 200, description: 'Channels retrieved' })
  async getSalesChannels(
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.getSalesChannels(companyId);
  }

  @Get('reports/by-product')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get sales analytics by product' })
  @ApiResponse({ status: 200, description: 'Product sales retrieved' })
  async getSalesByProduct(
    @CurrentUser('companyId') companyId: string,
    @Query() filters: SalesFilterDto,
  ) {
    return this.salesService.getSalesByProduct(companyId, filters);
  }

  @Get('reports/by-customer')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get sales analytics by customer' })
  @ApiResponse({ status: 200, description: 'Customer sales retrieved' })
  async getSalesByCustomer(
    @CurrentUser('companyId') companyId: string,
    @Query() filters: SalesFilterDto,
  ) {
    return this.salesService.getSalesByCustomer(companyId, filters);
  }

  @Get('reports/by-rep')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get sales analytics by sales representative' })
  @ApiResponse({ status: 200, description: 'Rep sales retrieved' })
  async getSalesByRep(
    @CurrentUser('companyId') companyId: string,
    @Query() filters: SalesFilterDto,
  ) {
    return this.salesService.getSalesByRep(companyId, filters);
  }

  @Get('reports/aging-receivables')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'Get aging receivables report' })
  @ApiResponse({ status: 200, description: 'Aging report retrieved' })
  async getAgingReceivables(
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.salesService.getAgingReceivables(companyId);
  }
}
