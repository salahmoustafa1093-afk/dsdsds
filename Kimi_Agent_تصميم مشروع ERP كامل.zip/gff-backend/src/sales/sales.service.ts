import {
  Injectable,
  NotFoundException,
  Logger,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  CreateInvoiceDto,
  UpdateInvoiceDto,
  UpdateInvoiceStatusDto,
  RecordPaymentDto,
  UpdateDeliveryStatusDto,
  CreateSalesReturnDto,
  UpdateSalesReturnDto,
  CreatePriceListDto,
  UpdatePriceListDto,
  SalesFilterDto,
  InvoiceLineDto,
} from './dto';
import {
  InvoiceStatus,
  SalesChannel,
  PaymentMethod,
  DeliveryStatus,
  MovementType,
  JournalStatus,
  Prisma,
} from '@prisma/client';

// ─── helpers ───
const toDecimal = (n: number): Prisma.Decimal => new Prisma.Decimal(n);

const dAdd = (a: Prisma.Decimal, b: Prisma.Decimal | number): Prisma.Decimal =>
  a.add(typeof b === 'number' ? toDecimal(b) : b);

const dSub = (a: Prisma.Decimal, b: Prisma.Decimal | number): Prisma.Decimal =>
  a.sub(typeof b === 'number' ? toDecimal(b) : b);

const dMul = (a: Prisma.Decimal | number, b: Prisma.Decimal | number): Prisma.Decimal => {
  const av = typeof a === 'number' ? toDecimal(a) : a;
  const bv = typeof b === 'number' ? toDecimal(b) : b;
  return av.mul(bv);
}

@Injectable()
export class SalesService {
  private readonly logger = new Logger(SalesService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════════════════
  //  INVOICES
  // ═══════════════════════════════════════════════════════

  /** List all sales invoices scoped to a company (via branch). */
  async findAllInvoices(
    companyId: string,
    options: { page?: number; limit?: number; filters?: SalesFilterDto },
  ) {
    const { page = 1, limit = 10, filters } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.SalesInvoiceWhereInput = {
      deletedAt: null,
      branch: { companyId },
    };

    if (filters) {
      if (filters.startDate) {
        where.createdAt = { gte: new Date(filters.startDate) };
      }
      if (filters.endDate) {
        where.createdAt = { ...(where.createdAt as Prisma.DateTimeFilter), lte: new Date(filters.endDate) };
      }
      if (filters.customerId) where.customerId = filters.customerId;
      if (filters.status) where.status = filters.status;
      if (filters.channel) where.channel = filters.channel;
      if (filters.salesRepId) where.salesRepId = filters.salesRepId;
      if (filters.branchId) where.branchId = filters.branchId;
    }

    const [data, total] = await Promise.all([
      this.prisma.salesInvoice.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: { select: { id: true, name: true, code: true, currentBalance: true } },
          branch: { select: { id: true, name: true, code: true } },
          salesRep: { select: { id: true, fullName: true } },
          lines: {
            include: {
              product: { select: { id: true, name: true, code: true } },
              warehouse: { select: { id: true, name: true, code: true } },
            },
          },
          _count: { select: { salesReturns: true } },
        },
      }),
      this.prisma.salesInvoice.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /** Get a single sales invoice by ID (scoped to company via branch). */
  async findOneInvoice(id: string, companyId: string) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id, deletedAt: null, branch: { companyId } },
      include: {
        customer: true,
        branch: { select: { id: true, name: true, code: true } },
        salesRep: { select: { id: true, fullName: true } },
        lines: {
          include: {
            product: { select: { id: true, name: true, code: true, salePrice: true } },
            warehouse: { select: { id: true, name: true, code: true } },
          },
        },
        salesReturns: {
          include: {
            product: { select: { id: true, name: true, code: true } },
          },
        },
      },
    });

    if (!invoice) {
      throw new NotFoundException(`Sales invoice with ID ${id} not found`);
    }

    return { data: invoice };
  }

  /** Create a new draft sales invoice. */
  async createInvoice(
    companyId: string,
    userId: string | undefined,
    dto: CreateInvoiceDto,
  ) {
    // ── Verify customer exists and belongs to the same company
    const customer = await this.prisma.customer.findFirst({
      where: { id: dto.customerId, companyId },
    });
    if (!customer) {
      throw new NotFoundException(
        `Customer with ID ${dto.customerId} not found in company`,
      );
    }

    // ── Credit-limit check
    const projectedBalance = dAdd(customer.currentBalance, 0);
    const { subtotal, discountAmount, taxAmount, totalAmount, lines } =
      this.calculateInvoiceTotals(dto.lines, customer.taxNumber);

    const newBalance = dAdd(projectedBalance, totalAmount);
    if (customer.creditLimit.greaterThan(0) && newBalance.greaterThan(customer.creditLimit)) {
      throw new ForbiddenException(
        `Invoice exceeds customer credit limit (${customer.creditLimit}). ` +
          `Projected balance: ${newBalance.toFixed(2)}`,
      );
    }

    // ── Generate invoice number
    const count = await this.prisma.salesInvoice.count({
      where: { branch: { companyId } },
    });
    const invoiceNumber = `INV-${Date.now().toString(36).toUpperCase()}-${(count + 1).toString().padStart(4, '0')}`;

    // ── Build line create input
    const linesCreate: Prisma.SalesInvoiceLineCreateManyInvoiceInput[] =
      lines.map((ln) => ({
        productId: ln.productId,
        quantity: ln.quantity,
        unitPrice: ln.unitPrice,
        discountPercent: ln.discountPercent,
        totalPrice: ln.totalPrice,
        warehouseId: ln.warehouseId ?? null,
      }));

    // ── Persist invoice + lines in a transaction
    const invoice = await this.prisma.$transaction(async (tx) => {
      const inv = await tx.salesInvoice.create({
        data: {
          invoiceNumber,
          customerId: dto.customerId,
          branchId: dto.branchId,
          salesRepId: dto.salesRepId ?? userId ?? null,
          channel: dto.channel ?? SalesChannel.RETAIL,
          subtotal,
          discountAmount,
          taxRate: toDecimal(14), // default 14%
          taxAmount,
          totalAmount,
          paidAmount: toDecimal(0),
          balance: totalAmount,
          status: InvoiceStatus.DRAFT,
          paymentMethod: dto.paymentMethod ?? null,
          deliveryStatus: DeliveryStatus.PENDING,
          notes: dto.notes ?? null,
          dueDate: dto.dueDate ? new Date(dto.dueDate) : null,
          lines: { createMany: { data: linesCreate } },
        },
        include: {
          customer: { select: { id: true, name: true, code: true } },
          branch: { select: { id: true, name: true, code: true } },
          salesRep: { select: { id: true, fullName: true } },
          lines: {
            include: {
              product: { select: { id: true, name: true, code: true } },
              warehouse: { select: { id: true, name: true, code: true } },
            },
          },
        },
      });

      // Update customer current balance (accounts receivable)
      await tx.customer.update({
        where: { id: dto.customerId },
        data: { currentBalance: { increment: totalAmount } },
      });

      return inv;
    });

    this.logger.log(`Sales invoice created: ${invoice.invoiceNumber}`);
    return { data: invoice };
  }

  /** Update an invoice (only while in DRAFT status). */
  async updateInvoice(
    id: string,
    companyId: string,
    dto: UpdateInvoiceDto,
  ) {
    const existing = await this.prisma.salesInvoice.findFirst({
      where: { id, deletedAt: null, branch: { companyId } },
      include: { lines: true },
    });
    if (!existing) {
      throw new NotFoundException(`Sales invoice with ID ${id} not found`);
    }
    if (existing.status !== InvoiceStatus.DRAFT) {
      throw new ForbiddenException(
        'Only draft invoices can be updated. Use status transitions instead.',
      );
    }

    // If lines are provided, recalculate and replace all lines
    let lineUpdates: Prisma.SalesInvoiceLineCreateManyInvoiceInput[] | undefined;
    let newSubtotal: Prisma.Decimal | undefined;
    let newDiscount: Prisma.Decimal | undefined;
    let newTaxAmount: Prisma.Decimal | undefined;
    let newTotal: Prisma.Decimal | undefined;

    if (dto.lines && dto.lines.length > 0) {
      const customer = await this.prisma.customer.findUnique({
        where: { id: existing.customerId },
      });
      const calc = this.calculateInvoiceTotals(
        dto.lines,
        customer?.taxNumber,
      );
      newSubtotal = calc.subtotal;
      newDiscount = calc.discountAmount;
      newTaxAmount = calc.taxAmount;
      newTotal = calc.totalAmount;
      lineUpdates = calc.lines.map((ln) => ({
        productId: ln.productId,
        quantity: ln.quantity,
        unitPrice: ln.unitPrice,
        discountPercent: ln.discountPercent,
        totalPrice: ln.totalPrice,
        warehouseId: ln.warehouseId ?? null,
      }));
    }

    const updated = await this.prisma.$transaction(async (tx) => {
      // Reverse old customer balance adjustment
      if (newTotal !== undefined) {
        await tx.customer.update({
          where: { id: existing.customerId },
          data: { currentBalance: { decrement: existing.totalAmount } },
        });
      }

      // Delete old lines and create new ones if lines were provided
      if (lineUpdates) {
        await tx.salesInvoiceLine.deleteMany({ where: { invoiceId: id } });
        await tx.salesInvoiceLine.createMany({
          data: lineUpdates.map((l) => ({ ...l, invoiceId: id })),
        });
      }

      const inv = await tx.salesInvoice.update({
        where: { id },
        data: {
          salesRepId: dto.salesRepId ?? undefined,
          channel: dto.channel ?? undefined,
          dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined,
          paymentMethod: dto.paymentMethod ?? undefined,
          notes: dto.notes ?? undefined,
          ...(newSubtotal !== undefined
            ? {
                subtotal: newSubtotal,
                discountAmount: newDiscount,
                taxAmount: newTaxAmount,
                totalAmount: newTotal,
                balance: newTotal,
              }
            : {}),
        },
        include: {
          customer: { select: { id: true, name: true, code: true } },
          branch: { select: { id: true, name: true, code: true } },
          salesRep: { select: { id: true, fullName: true } },
          lines: {
            include: {
              product: { select: { id: true, name: true, code: true } },
              warehouse: { select: { id: true, name: true, code: true } },
            },
          },
        },
      });

      // Apply new customer balance adjustment
      if (newTotal !== undefined) {
        await tx.customer.update({
          where: { id: existing.customerId },
          data: { currentBalance: { increment: newTotal } },
        });
      }

      return inv;
    });

    this.logger.log(`Sales invoice updated: ${updated.invoiceNumber}`);
    return { data: updated };
  }

  /** Soft-delete (cancel) a draft invoice. */
  async deleteInvoice(id: string, companyId: string) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id, deletedAt: null, branch: { companyId } },
    });
    if (!invoice) {
      throw new NotFoundException(`Sales invoice with ID ${id} not found`);
    }
    if (invoice.status !== InvoiceStatus.DRAFT) {
      throw new ForbiddenException('Only draft invoices can be deleted.');
    }

    await this.prisma.$transaction([
      // Reverse customer balance
      this.prisma.customer.update({
        where: { id: invoice.customerId },
        data: { currentBalance: { decrement: invoice.totalAmount } },
      }),
      // Soft-delete invoice
      this.prisma.salesInvoice.update({
        where: { id },
        data: { deletedAt: new Date(), status: InvoiceStatus.CANCELLED },
      }),
    ]);

    this.logger.log(`Sales invoice cancelled: ${invoice.invoiceNumber}`);
    return { data: { message: 'Invoice cancelled' } };
  }

  /** Confirm a draft invoice (transition to CONFIRMED). */
  async confirmInvoice(id: string, companyId: string) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id, deletedAt: null, branch: { companyId } },
      include: { lines: true },
    });
    if (!invoice) {
      throw new NotFoundException(`Sales invoice with ID ${id} not found`);
    }
    if (invoice.status !== InvoiceStatus.DRAFT) {
      throw new BadRequestException('Only draft invoices can be confirmed.');
    }

    const updated = await this.prisma.$transaction(async (tx) => {
      const inv = await tx.salesInvoice.update({
        where: { id },
        data: { status: InvoiceStatus.CONFIRMED },
      });

      // Auto-post to accounting (journal entry)
      await this.postInvoiceToAccounting(tx, inv, companyId);

      return inv;
    });

    this.logger.log(`Sales invoice confirmed: ${updated.invoiceNumber}`);
    return { data: updated };
  }

  /** Record a payment against an invoice. */
  async recordPayment(
    id: string,
    companyId: string,
    dto: RecordPaymentDto,
  ) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id, deletedAt: null, branch: { companyId } },
    });
    if (!invoice) {
      throw new NotFoundException(`Sales invoice with ID ${id} not found`);
    }
    if (invoice.status === InvoiceStatus.CANCELLED) {
      throw new BadRequestException('Cannot record payment on a cancelled invoice.');
    }

    const paymentAmt = toDecimal(dto.amount);
    const newPaid = dAdd(invoice.paidAmount, paymentAmt);
    const newBalance = dSub(invoice.totalAmount, newPaid);

    if (newPaid.greaterThan(invoice.totalAmount)) {
      throw new BadRequestException(
        `Payment amount (${paymentAmt.toFixed(2)}) exceeds remaining balance (${invoice.balance.toFixed(2)})`,
      );
    }

    let newStatus: InvoiceStatus = InvoiceStatus.PARTIALLY_PAID;
    if (newBalance.equals(0)) {
      newStatus = InvoiceStatus.PAID;
    }

    const updated = await this.prisma.$transaction(async (tx) => {
      const inv = await tx.salesInvoice.update({
        where: { id },
        data: {
          paidAmount: newPaid,
          balance: newBalance,
          status: newStatus,
          paymentMethod: dto.paymentMethod,
        },
      });

      // Reduce customer current balance (AR)
      await tx.customer.update({
        where: { id: invoice.customerId },
        data: { currentBalance: { decrement: paymentAmt } },
      });

      return inv;
    });

    this.logger.log(
      `Payment of ${paymentAmt.toFixed(2)} recorded on invoice ${invoice.invoiceNumber}`,
    );
    return { data: updated };
  }

  /** Update delivery status of an invoice. */
  async updateDeliveryStatus(
    id: string,
    companyId: string,
    dto: UpdateDeliveryStatusDto,
  ) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id, deletedAt: null, branch: { companyId } },
    });
    if (!invoice) {
      throw new NotFoundException(`Sales invoice with ID ${id} not found`);
    }

    const updated = await this.prisma.salesInvoice.update({
      where: { id },
      data: { deliveryStatus: dto.status },
    });

    // If delivered, mark invoice as delivered too
    if (
      dto.status === DeliveryStatus.DELIVERED &&
      invoice.status === InvoiceStatus.CONFIRMED
    ) {
      await this.prisma.salesInvoice.update({
        where: { id },
        data: { status: InvoiceStatus.DELIVERED },
      });
    }

    return { data: updated };
  }

  // ═══════════════════════════════════════════════════════
  //  SALES RETURNS
  // ═══════════════════════════════════════════════════════

  /** List all sales returns scoped to a company. */
  async findAllReturns(
    companyId: string,
    options: { page?: number; limit?: number },
  ) {
    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.SalesReturnWhereInput = {
      customer: { companyId },
    };

    const [data, total] = await Promise.all([
      this.prisma.salesReturn.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          originalInvoice: { select: { id: true, invoiceNumber: true } },
          customer: { select: { id: true, name: true, code: true } },
          product: { select: { id: true, name: true, code: true } },
        },
      }),
      this.prisma.salesReturn.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /** Get a single sales return by ID (scoped to company). */
  async findOneReturn(id: string, companyId: string) {
    const ret = await this.prisma.salesReturn.findFirst({
      where: { id, customer: { companyId } },
      include: {
        originalInvoice: true,
        customer: true,
        product: { select: { id: true, name: true, code: true } },
      },
    });
    if (!ret) {
      throw new NotFoundException(`Sales return with ID ${id} not found`);
    }
    return { data: ret };
  }

  /** Create a sales return. */
  async createReturn(
    companyId: string,
    _userId: string | undefined,
    dto: CreateSalesReturnDto,
  ) {
    // ── Verify original invoice exists and belongs to company
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: {
        id: dto.originalInvoiceId,
        deletedAt: null,
        branch: { companyId },
      },
      include: { lines: true },
    });
    if (!invoice) {
      throw new NotFoundException('Original invoice not found');
    }

    // ── Verify the product was actually on the invoice
    const line = invoice.lines.find((l) => l.productId === dto.productId);
    if (!line) {
      throw new BadRequestException(
        'Product was not part of the original invoice',
      );
    }

    // ── Verify return quantity does not exceed sold quantity
    const existingReturns = await this.prisma.salesReturn.aggregate({
      where: {
        originalInvoiceId: dto.originalInvoiceId,
        productId: dto.productId,
        status: { not: InvoiceStatus.CANCELLED },
      },
      _sum: { quantity: true },
    });
    const alreadyReturned = existingReturns._sum.quantity ?? toDecimal(0);
    const maxReturn = dSub(line.quantity, alreadyReturned);
    if (toDecimal(dto.quantity).greaterThan(maxReturn)) {
      throw new BadRequestException(
        `Return quantity (${dto.quantity}) exceeds remaining sellable quantity (${maxReturn}). ` +
          `Already returned: ${alreadyReturned}`,
      );
    }

    // ── Generate return number
    const count = await this.prisma.salesReturn.count({
      where: { customer: { companyId } },
    });
    const returnNumber = `RET-${Date.now().toString(36).toUpperCase()}-${(count + 1).toString().padStart(4, '0')}`;

    const totalAmount = dMul(dto.quantity, dto.unitPrice);

    const salesReturn = await this.prisma.salesReturn.create({
      data: {
        returnNumber,
        originalInvoiceId: dto.originalInvoiceId,
        customerId: dto.customerId,
        productId: dto.productId,
        quantity: toDecimal(dto.quantity),
        unitPrice: toDecimal(dto.unitPrice),
        totalAmount,
        reason: dto.reason,
        status: InvoiceStatus.DRAFT,
      },
      include: {
        originalInvoice: { select: { id: true, invoiceNumber: true } },
        customer: { select: { id: true, name: true, code: true } },
        product: { select: { id: true, name: true, code: true } },
      },
    });

    this.logger.log(`Sales return created: ${salesReturn.returnNumber}`);
    return { data: salesReturn };
  }

  /** Approve/process a sales return: update status, reverse customer balance, restore stock. */
  async processReturn(id: string, companyId: string, userId: string) {
    const ret = await this.prisma.salesReturn.findFirst({
      where: { id, customer: { companyId } },
      include: { originalInvoice: true },
    });
    if (!ret) {
      throw new NotFoundException('Sales return not found');
    }
    if (ret.status !== InvoiceStatus.DRAFT) {
      throw new BadRequestException('Return has already been processed.');
    }

    // Find a warehouse to return stock to (use first warehouse of the invoice's branch)
    const warehouse = await this.prisma.warehouse.findFirst({
      where: { branchId: ret.originalInvoice.branchId },
    });

    await this.prisma.$transaction(async (tx) => {
      // Update return status
      await tx.salesReturn.update({
        where: { id },
        data: { status: InvoiceStatus.CONFIRMED },
      });

      // Reverse customer balance (reduce AR)
      await tx.customer.update({
        where: { id: ret.customerId },
        data: { currentBalance: { decrement: ret.totalAmount } },
      });

      // Update original invoice
      await tx.salesInvoice.update({
        where: { id: ret.originalInvoiceId },
        data: {
          status: InvoiceStatus.RETURNED,
          totalAmount: { decrement: ret.totalAmount },
          balance: { decrement: ret.totalAmount },
        },
      });

      // Create stock movement (RETURN type) to restore inventory
      if (warehouse) {
        const count = await tx.stockMovement.count({
          where: { warehouse: { branch: { companyId } } },
        });
        await tx.stockMovement.create({
          data: {
            movementNumber: `SM-RET-${Date.now().toString(36).toUpperCase()}-${(count + 1).toString().padStart(4, '0')}`,
            type: MovementType.RETURN,
            productId: ret.productId,
            warehouseId: warehouse.id,
            quantity: ret.quantity,
            unitCost: ret.unitPrice,
            referenceType: 'SALES_RETURN',
            referenceId: ret.id,
            createdBy: userId,
          },
        });
      }
    });

    this.logger.log(`Sales return processed: ${ret.returnNumber}`);
    return { data: { message: 'Return processed successfully' } };
  }

  /** Update a sales return's status. */
  async updateReturnStatus(
    id: string,
    companyId: string,
    dto: UpdateSalesReturnDto,
  ) {
    const ret = await this.prisma.salesReturn.findFirst({
      where: { id, customer: { companyId } },
    });
    if (!ret) {
      throw new NotFoundException('Sales return not found');
    }

    const updated = await this.prisma.salesReturn.update({
      where: { id },
      data: { status: dto.status, reason: dto.reason ?? undefined },
    });

    return { data: updated };
  }

  // ═══════════════════════════════════════════════════════
  //  PRICE LISTS
  // ═══════════════════════════════════════════════════════

  /** List all price lists scoped to company (via product). */
  async findAllPriceLists(
    companyId: string,
    options: { page?: number; limit?: number },
  ) {
    const { page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.PriceListWhereInput = {
      product: { companyId },
    };

    const [data, total] = await Promise.all([
      this.prisma.priceList.findMany({
        where,
        skip,
        take: limit,
        orderBy: { effectiveFrom: 'desc' },
        include: {
          product: { select: { id: true, name: true, code: true } },
          customerCategory: { select: { id: true, name: true, color: true } },
        },
      }),
      this.prisma.priceList.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /** Get a single price list entry. */
  async findOnePriceList(id: string, companyId: string) {
    const priceList = await this.prisma.priceList.findFirst({
      where: { id, product: { companyId } },
      include: {
        product: { select: { id: true, name: true, code: true, salePrice: true } },
        customerCategory: { select: { id: true, name: true, color: true } },
      },
    });
    if (!priceList) {
      throw new NotFoundException(`Price list with ID ${id} not found`);
    }
    return { data: priceList };
  }

  /** Create a price list entry. */
  async createPriceList(companyId: string, dto: CreatePriceListDto) {
    // Verify product belongs to company
    const product = await this.prisma.product.findFirst({
      where: { id: dto.productId, companyId },
    });
    if (!product) {
      throw new NotFoundException(
        `Product with ID ${dto.productId} not found in company`,
      );
    }

    const priceList = await this.prisma.priceList.create({
      data: {
        name: dto.name,
        productId: dto.productId,
        customerCategoryId: dto.customerCategoryId ?? null,
        minQty: dto.minQty ?? 1,
        maxQty: dto.maxQty ?? null,
        unitPrice: toDecimal(dto.unitPrice),
        effectiveFrom: new Date(dto.effectiveFrom),
        effectiveTo: dto.effectiveTo ? new Date(dto.effectiveTo) : null,
      },
      include: {
        product: { select: { id: true, name: true, code: true } },
        customerCategory: { select: { id: true, name: true } },
      },
    });

    return { data: priceList };
  }

  /** Update a price list entry. */
  async updatePriceList(
    id: string,
    companyId: string,
    dto: UpdatePriceListDto,
  ) {
    const existing = await this.prisma.priceList.findFirst({
      where: { id, product: { companyId } },
    });
    if (!existing) {
      throw new NotFoundException(`Price list with ID ${id} not found`);
    }

    const updated = await this.prisma.priceList.update({
      where: { id },
      data: {
        name: dto.name ?? undefined,
        customerCategoryId: dto.customerCategoryId ?? undefined,
        minQty: dto.minQty ?? undefined,
        maxQty: dto.maxQty ?? undefined,
        unitPrice: dto.unitPrice !== undefined ? toDecimal(dto.unitPrice) : undefined,
        effectiveFrom: dto.effectiveFrom ? new Date(dto.effectiveFrom) : undefined,
        effectiveTo: dto.effectiveTo ? new Date(dto.effectiveTo) : undefined,
      },
      include: {
        product: { select: { id: true, name: true, code: true } },
        customerCategory: { select: { id: true, name: true } },
      },
    });

    return { data: updated };
  }

  /** Delete a price list entry. */
  async deletePriceList(id: string, companyId: string) {
    const existing = await this.prisma.priceList.findFirst({
      where: { id, product: { companyId } },
    });
    if (!existing) {
      throw new NotFoundException(`Price list with ID ${id} not found`);
    }

    await this.prisma.priceList.delete({ where: { id } });
    return { data: { message: 'Price list deleted' } };
  }

  // ═══════════════════════════════════════════════════════
  //  CUSTOMER CREDIT
  // ═══════════════════════════════════════════════════════

  /** Check if a customer has available credit. */
  async checkCustomerCredit(customerId: string, companyId: string) {
    const customer = await this.prisma.customer.findFirst({
      where: { id: customerId, companyId },
    });
    if (!customer) {
      throw new NotFoundException(`Customer with ID ${customerId} not found`);
    }

    const availableCredit = dSub(customer.creditLimit, customer.currentBalance);
    const utilizationPct = customer.creditLimit.greaterThan(0)
      ? dMul(customer.currentBalance.dividedBy(customer.creditLimit), 100)
      : toDecimal(0);

    return {
      data: {
        customerId: customer.id,
        name: customer.name,
        creditLimit: customer.creditLimit,
        currentBalance: customer.currentBalance,
        availableCredit: availableCredit.greaterThan(0) ? availableCredit : toDecimal(0),
        utilizationPercent: utilizationPct,
        isBlocked: customer.creditLimit.greaterThan(0)
          ? customer.currentBalance.greaterThanOrEqualTo(customer.creditLimit)
          : false,
      },
    };
  }

  // ═══════════════════════════════════════════════════════
  //  SALES ANALYTICS
  // ═══════════════════════════════════════════════════════

  /** Sales report summary by period. */
  async getSalesReport(companyId: string, filters: SalesFilterDto) {
    const where: Prisma.SalesInvoiceWhereInput = {
      deletedAt: null,
      branch: { companyId },
      status: { not: InvoiceStatus.CANCELLED },
    };

    if (filters?.startDate) {
      where.createdAt = { gte: new Date(filters.startDate) };
    }
    if (filters?.endDate) {
      where.createdAt = {
        ...(where.createdAt as Prisma.DateTimeFilter),
        lte: new Date(filters.endDate),
      };
    }
    if (filters?.customerId) where.customerId = filters.customerId;
    if (filters?.status) where.status = filters.status;
    if (filters?.channel) where.channel = filters.channel;
    if (filters?.salesRepId) where.salesRepId = filters.salesRepId;
    if (filters?.branchId) where.branchId = filters.branchId;

    const invoices = await this.prisma.salesInvoice.findMany({
      where,
      include: {
        lines: { select: { totalPrice: true, quantity: true, productId: true } },
      },
    });

    const totalSales = invoices.reduce(
      (sum, inv) => sum.add(inv.totalAmount),
      toDecimal(0),
    );
    const totalPaid = invoices.reduce(
      (sum, inv) => sum.add(inv.paidAmount),
      toDecimal(0),
    );
    const totalPending = invoices.reduce(
      (sum, inv) => sum.add(inv.balance),
      toDecimal(0),
    );
    const totalDiscount = invoices.reduce(
      (sum, inv) => sum.add(inv.discountAmount),
      toDecimal(0),
    );
    const totalTax = invoices.reduce(
      (sum, inv) => sum.add(inv.taxAmount),
      toDecimal(0),
    );

    // By status
    const byStatus: Record<string, number> = {};
    invoices.forEach((inv) => {
      const key = inv.status;
      byStatus[key] = (byStatus[key] || 0) + inv.totalAmount.toNumber();
    });

    // By channel
    const byChannel: Record<string, number> = {};
    invoices.forEach((inv) => {
      const key = inv.channel;
      byChannel[key] = (byChannel[key] || 0) + inv.totalAmount.toNumber();
    });

    // By sales rep
    const byRep: Record<string, { name: string; total: number }> = {};

    return {
      data: {
        totalInvoices: invoices.length,
        totalSales: totalSales.toNumber(),
        totalPaid: totalPaid.toNumber(),
        totalPending: totalPending.toNumber(),
        totalDiscount: totalDiscount.toNumber(),
        totalTax: totalTax.toNumber(),
        byStatus,
        byChannel,
        averageInvoiceValue: invoices.length > 0 ? totalSales.dividedBy(invoices.length).toNumber() : 0,
      },
    };
  }

  /** Sales grouped by channel. */
  async getSalesChannels(companyId: string) {
    const channels = await this.prisma.salesInvoice.groupBy({
      by: ['channel'],
      where: {
        deletedAt: null,
        branch: { companyId },
        status: { not: InvoiceStatus.CANCELLED },
      },
      _sum: { totalAmount: true },
      _count: { id: true },
    });

    return { data: channels };
  }

  /** Sales analytics by product. */
  async getSalesByProduct(
    companyId: string,
    filters: SalesFilterDto,
  ) {
    const where: Prisma.SalesInvoiceWhereInput = {
      deletedAt: null,
      branch: { companyId },
      status: { not: InvoiceStatus.CANCELLED },
    };

    if (filters?.startDate)
      where.createdAt = { gte: new Date(filters.startDate) };
    if (filters?.endDate) {
      where.createdAt = {
        ...(where.createdAt as Prisma.DateTimeFilter),
        lte: new Date(filters.endDate),
      };
    }

    const lines = await this.prisma.salesInvoiceLine.findMany({
      where: {
        invoice: where,
      },
      include: {
        product: { select: { id: true, name: true, code: true } },
      },
    });

    const productMap = new Map<
      string,
      { productId: string; productName: string; productCode: string; totalQty: number; totalRevenue: number; totalDiscount: number }
    >();

    lines.forEach((ln) => {
      const key = ln.productId;
      const existing = productMap.get(key);
      if (existing) {
        existing.totalQty += ln.quantity.toNumber();
        existing.totalRevenue += ln.totalPrice.toNumber();
      } else {
        productMap.set(key, {
          productId: ln.productId,
          productName: ln.product.name,
          productCode: ln.product.code,
          totalQty: ln.quantity.toNumber(),
          totalRevenue: ln.totalPrice.toNumber(),
          totalDiscount: dMul(ln.quantity, ln.unitPrice).sub(ln.totalPrice).toNumber(),
        });
      }
    });

    return { data: Array.from(productMap.values()) };
  }

  /** Sales analytics by customer. */
  async getSalesByCustomer(
    companyId: string,
    filters: SalesFilterDto,
  ) {
    const where: Prisma.SalesInvoiceWhereInput = {
      deletedAt: null,
      branch: { companyId },
      status: { not: InvoiceStatus.CANCELLED },
    };

    if (filters?.startDate)
      where.createdAt = { gte: new Date(filters.startDate) };
    if (filters?.endDate) {
      where.createdAt = {
        ...(where.createdAt as Prisma.DateTimeFilter),
        lte: new Date(filters.endDate),
      };
    }

    const invoices = await this.prisma.salesInvoice.findMany({
      where,
      include: {
        customer: { select: { id: true, name: true, code: true } },
      },
    });

    const customerMap = new Map<
      string,
      { customerId: string; customerName: string; customerCode: string; invoiceCount: number; totalPurchases: number; totalPaid: number; balanceOwed: number }
    >();

    invoices.forEach((inv) => {
      const key = inv.customerId;
      const existing = customerMap.get(key);
      if (existing) {
        existing.invoiceCount += 1;
        existing.totalPurchases += inv.totalAmount.toNumber();
        existing.totalPaid += inv.paidAmount.toNumber();
        existing.balanceOwed += inv.balance.toNumber();
      } else {
        customerMap.set(key, {
          customerId: inv.customer.id,
          customerName: inv.customer.name,
          customerCode: inv.customer.code,
          invoiceCount: 1,
          totalPurchases: inv.totalAmount.toNumber(),
          totalPaid: inv.paidAmount.toNumber(),
          balanceOwed: inv.balance.toNumber(),
        });
      }
    });

    return { data: Array.from(customerMap.values()) };
  }

  /** Sales analytics by sales representative. */
  async getSalesByRep(
    companyId: string,
    filters: SalesFilterDto,
  ) {
    const where: Prisma.SalesInvoiceWhereInput = {
      deletedAt: null,
      branch: { companyId },
      status: { not: InvoiceStatus.CANCELLED },
      salesRepId: { not: null },
    };

    if (filters?.startDate)
      where.createdAt = { gte: new Date(filters.startDate) };
    if (filters?.endDate) {
      where.createdAt = {
        ...(where.createdAt as Prisma.DateTimeFilter),
        lte: new Date(filters.endDate),
      };
    }

    const invoices = await this.prisma.salesInvoice.findMany({
      where,
      include: {
        salesRep: { select: { id: true, fullName: true } },
      },
    });

    const repMap = new Map<
      string,
      { salesRepId: string; salesRepName: string; invoiceCount: number; totalSales: number; totalPaid: number; commissionEstimate: number }
    >();

    invoices.forEach((inv) => {
      if (!inv.salesRepId || !inv.salesRep) return;
      const key = inv.salesRepId;
      const existing = repMap.get(key);
      if (existing) {
        existing.invoiceCount += 1;
        existing.totalSales += inv.totalAmount.toNumber();
        existing.totalPaid += inv.paidAmount.toNumber();
      } else {
        repMap.set(key, {
          salesRepId: inv.salesRep.id,
          salesRepName: inv.salesRep.fullName,
          invoiceCount: 1,
          totalSales: inv.totalAmount.toNumber(),
          totalPaid: inv.paidAmount.toNumber(),
          commissionEstimate: inv.totalAmount.toNumber() * 0.025, // 2.5% placeholder
        });
      }
    });

    return { data: Array.from(repMap.values()) };
  }

  /** Aging receivables report. */
  async getAgingReceivables(companyId: string) {
    const now = new Date();
    const invoices = await this.prisma.salesInvoice.findMany({
      where: {
        deletedAt: null,
        branch: { companyId },
        status: {
          in: [
            InvoiceStatus.CONFIRMED,
            InvoiceStatus.PENDING,
            InvoiceStatus.DELIVERED,
            InvoiceStatus.PARTIALLY_PAID,
            InvoiceStatus.OVERDUE,
          ],
        },
        balance: { gt: toDecimal(0) },
      },
      include: {
        customer: { select: { id: true, name: true, code: true, paymentTerms: true } },
      },
      orderBy: { dueDate: 'asc' },
    });

    // Aging buckets (in days)
    const buckets = {
      current: toDecimal(0),
      days1to30: toDecimal(0),
      days31to60: toDecimal(0),
      days61to90: toDecimal(0),
      over90: toDecimal(0),
    };

    const customerAging = new Map<
      string,
      {
        customerId: string;
        customerName: string;
        totalOwed: number;
        current: number;
        days1to30: number;
        days31to60: number;
        days61to90: number;
        over90: number;
      }
    >();

    invoices.forEach((inv) => {
      if (inv.balance.equals(0)) return;

      const dueDate = inv.dueDate ? new Date(inv.dueDate) : new Date(inv.createdAt);
      const diffMs = now.getTime() - dueDate.getTime();
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

      let bucket: keyof typeof buckets;
      if (diffDays <= 0) bucket = 'current';
      else if (diffDays <= 30) bucket = 'days1to30';
      else if (diffDays <= 60) bucket = 'days31to60';
      else if (diffDays <= 90) bucket = 'days61to90';
      else bucket = 'over90';

      buckets[bucket] = dAdd(buckets[bucket], inv.balance);

      const key = inv.customerId;
      const existing = customerAging.get(key);
      if (existing) {
        existing.totalOwed += inv.balance.toNumber();
        existing[bucket] += inv.balance.toNumber();
      } else {
        customerAging.set(key, {
          customerId: inv.customer.id,
          customerName: inv.customer.name,
          totalOwed: inv.balance.toNumber(),
          current: 0,
          days1to30: 0,
          days31to60: 0,
          days61to90: 0,
          over90: 0,
          [bucket]: inv.balance.toNumber(),
        } as ReturnType<typeof customerAging.get> & Record<string, number>);
      }
    });

    return {
      data: {
        summary: {
          totalOwed: Object.values(buckets).reduce((s, d) => s + d.toNumber(), 0),
          current: buckets.current.toNumber(),
          days1to30: buckets.days1to30.toNumber(),
          days31to60: buckets.days31to60.toNumber(),
          days61to90: buckets.days61to90.toNumber(),
          over90: buckets.over90.toNumber(),
        },
        customerBreakdown: Array.from(customerAging.values()),
        invoiceCount: invoices.length,
      },
    };
  }

  // ═══════════════════════════════════════════════════════
  //  ACCOUNTING INTEGRATION
  // ═══════════════════════════════════════════════════════

  /**
   * Auto-post a confirmed invoice to the accounting system.
   * Creates a journal entry debiting AR and crediting Revenue.
   */
  private async postInvoiceToAccounting(
    tx: Prisma.TransactionClient,
    invoice: {
      id: string;
      invoiceNumber: string;
      customerId: string;
      branchId: string;
      subtotal: Prisma.Decimal;
      discountAmount: Prisma.Decimal;
      taxAmount: Prisma.Decimal;
      totalAmount: Prisma.Decimal;
    },
    companyId: string,
  ) {
    try {
      // Find chart of accounts
      const arAccount = await tx.chartOfAccount.findFirst({
        where: { companyId, type: 'ASSET', code: { startsWith: '1' } },
        orderBy: { code: 'asc' },
      });
      const revenueAccount = await tx.chartOfAccount.findFirst({
        where: { companyId, type: 'REVENUE', code: { startsWith: '4' } },
        orderBy: { code: 'asc' },
      });
      const taxAccount = await tx.chartOfAccount.findFirst({
        where: { companyId, type: 'LIABILITY', code: { contains: 'tax' } },
      });

      if (!arAccount || !revenueAccount) {
        this.logger.warn(
          `Chart accounts missing for company ${companyId}. Skipping auto-post.`,
        );
        return;
      }

      const entryNumber = `JE-${Date.now().toString(36).toUpperCase()}`;

      // Build journal entry lines
      const netRevenue = dSub(invoice.subtotal, invoice.discountAmount);

      await tx.journalEntry.create({
        data: {
          entryNumber,
          date: new Date(),
          description: `Auto-posted from sales invoice ${invoice.invoiceNumber}`,
          totalDebit: invoice.totalAmount,
          totalCredit: invoice.totalAmount,
          status: JournalStatus.POSTED,
          companyId,
          postedBy: null,
        },
      });

      // Update AR account balance
      await tx.chartOfAccount.update({
        where: { id: arAccount.id },
        data: { balance: { increment: invoice.totalAmount } },
      });

      // Update Revenue account balance
      await tx.chartOfAccount.update({
        where: { id: revenueAccount.id },
        data: { balance: { increment: netRevenue } },
      });

      // Update Tax liability if applicable
      if (taxAccount && invoice.taxAmount.greaterThan(0)) {
        await tx.chartOfAccount.update({
          where: { id: taxAccount.id },
          data: { balance: { increment: invoice.taxAmount } },
        });
      }

      this.logger.log(
        `Invoice ${invoice.invoiceNumber} auto-posted to accounting: ${entryNumber}`,
      );
    } catch (err) {
      this.logger.error(
        `Failed to auto-post invoice ${invoice.invoiceNumber} to accounting: ${(err as Error).message}`,
      );
      // Don't throw — posting failure shouldn't block invoice confirmation
    }
  }

  // ═══════════════════════════════════════════════════════
  //  PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════

  /** Calculate invoice totals from line DTOs. */
  private calculateInvoiceTotals(
    lines: InvoiceLineDto[],
    _taxNumber?: string | null,
  ) {
    let subtotal = toDecimal(0);
    let discountAmount = toDecimal(0);

    const processedLines = lines.map((ln) => {
      const qty = toDecimal(ln.quantity);
      const price = toDecimal(ln.unitPrice);
      const lineGross = dMul(qty, price);
      const discPct = toDecimal(ln.discountPercent ?? 0);
      const lineDiscount = dMul(lineGross, discPct.dividedBy(100));
      const lineTotal = dSub(lineGross, lineDiscount);

      subtotal = dAdd(subtotal, lineGross);
      discountAmount = dAdd(discountAmount, lineDiscount);

      return {
        productId: ln.productId,
        quantity: qty,
        unitPrice: price,
        discountPercent: discPct,
        totalPrice: lineTotal,
        warehouseId: ln.warehouseId ?? null,
      };
    });

    const taxableAmount = dSub(subtotal, discountAmount);
    const taxRate = toDecimal(14); // 14% default VAT
    const taxAmount = dMul(taxableAmount, taxRate.dividedBy(100));
    const totalAmount = dAdd(taxableAmount, taxAmount);

    return {
      subtotal,
      discountAmount,
      taxAmount,
      taxRate,
      totalAmount,
      lines: processedLines,
    };
  }
}
