import { IsString, IsNumber, IsOptional, IsUUID, IsDateString, IsNotEmpty } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateFeedCostDto {
  @ApiProperty({ description: 'Feed formula ID' })
  @IsUUID()
  @IsNotEmpty()
  formulaId: string;

  @ApiProperty({ description: 'Raw material cost' })
  @IsNumber()
  rawMaterialCost: number;

  @ApiProperty({ description: 'Labor cost' })
  @IsNumber()
  laborCost: number;

  @ApiProperty({ description: 'Overhead cost' })
  @IsNumber()
  overheadCost: number;

  @ApiProperty({ description: 'Total cost' })
  @IsNumber()
  totalCost: number;

  @ApiProperty({ description: 'Cost per ton' })
  @IsNumber()
  costPerTon: number;

  @ApiPropertyOptional({ description: 'Margin percentage' })
  @IsOptional()
  @IsNumber()
  margin?: number;

  @ApiPropertyOptional({ description: 'Effective date (ISO string)' })
  @IsOptional()
  @IsDateString()
  effectiveDate?: string;
}
