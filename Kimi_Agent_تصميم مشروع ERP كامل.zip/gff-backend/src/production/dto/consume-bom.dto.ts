import { IsUUID, IsOptional, IsString, IsNumber } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class ConsumeBomDto {
  @ApiProperty({ description: 'Production order (stock movement) ID' })
  @IsUUID()
  productionOrderId: string;

  @ApiPropertyOptional({ description: 'Warehouse ID to consume materials from' })
  @IsOptional()
  @IsUUID()
  warehouseId?: string;

  @ApiPropertyOptional({ description: 'User ID performing the consumption' })
  @IsOptional()
  @IsUUID()
  createdBy?: string;
}

export class ConsumptionIngredientDto {
  @ApiProperty({ description: 'Ingredient name' })
  @IsString()
  ingredientName: string;

  @ApiProperty({ description: 'Required quantity' })
  @IsNumber()
  requiredQty: number;

  @ApiProperty({ description: 'Available quantity' })
  @IsNumber()
  availableQty: number;

  @ApiProperty({ description: 'Unit cost' })
  @IsNumber()
  unitCost: number;

  @ApiProperty({ description: 'Total cost' })
  @IsNumber()
  totalCost: number;

  @ApiProperty({ description: 'Whether stock is sufficient' })
  sufficient: boolean;
}
