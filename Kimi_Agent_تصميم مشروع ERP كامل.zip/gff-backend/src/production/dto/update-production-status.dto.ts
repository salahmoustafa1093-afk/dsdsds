import { IsString, IsNotEmpty, IsOptional, IsUUID, IsDateString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class UpdateProductionStatusDto {
  @ApiProperty({
    description: 'Production status',
    enum: ['DRAFT', 'SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'ON_HOLD', 'CLOSED', 'CANCELLED', 'QUARANTINE'],
  })
  @IsString()
  @IsNotEmpty()
  status: string;

  @ApiPropertyOptional({ description: 'Actual quantity produced' })
  @IsOptional()
  @IsString()
  actualQty?: string;

  @ApiPropertyOptional({ description: 'Start date (ISO string)' })
  @IsOptional()
  @IsDateString()
  startDate?: string;

  @ApiPropertyOptional({ description: 'End date (ISO string)' })
  @IsOptional()
  @IsDateString()
  endDate?: string;

  @ApiPropertyOptional({ description: 'Labor rate per hour' })
  @IsOptional()
  @IsString()
  laborRate?: string;

  @ApiPropertyOptional({ description: 'Overhead rate per hour' })
  @IsOptional()
  @IsString()
  overheadRate?: string;

  @ApiPropertyOptional({ description: 'User ID updating the status' })
  @IsOptional()
  @IsUUID()
  updatedBy?: string;
}
