import { IsString, IsNumber, IsOptional, IsUUID, IsEnum, IsDateString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export enum DowntimeReason {
  MAINTENANCE = 'MAINTENANCE',
  MATERIAL_SHORTAGE = 'MATERIAL_SHORTAGE',
  POWER_OUTAGE = 'POWER_OUTAGE',
  QUALITY_ISSUE = 'QUALITY_ISSUE',
  CHANGEOVER = 'CHANGEOVER',
  OTHER = 'OTHER',
}

export class DowntimeRecordDto {
  @ApiProperty({ enum: DowntimeReason, description: 'Reason for downtime' })
  @IsEnum(DowntimeReason)
  reason: DowntimeReason;

  @ApiProperty({ description: 'Duration in minutes' })
  @IsNumber()
  durationMinutes: number;

  @ApiPropertyOptional({ description: 'Additional notes' })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({ description: 'Linked production order ID' })
  @IsOptional()
  @IsUUID()
  productionOrderId?: string;

  @ApiPropertyOptional({ description: 'Start time of downtime' })
  @IsOptional()
  @IsDateString()
  startTime?: string;
}

export class DowntimeRecord {
  id: string;
  reason: DowntimeReason;
  durationMinutes: number;
  notes?: string;
  productionOrderId?: string;
  startTime: Date;
  createdAt: Date;
}
