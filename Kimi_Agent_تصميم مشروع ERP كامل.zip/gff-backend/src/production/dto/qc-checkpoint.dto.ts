import { IsString, IsNumber, IsOptional, IsEnum, IsNotEmpty } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export enum QCCheckpointType {
  IN_PROCESS = 'IN_PROCESS',
  FINAL = 'FINAL',
}

export enum QCParameter {
  MOISTURE = 'MOISTURE',
  PROTEIN = 'PROTEIN',
  PARTICLE_SIZE = 'PARTICLE_SIZE',
  FOREIGN_MATTER = 'FOREIGN_MATTER',
  CUSTOM = 'CUSTOM',
}

export class QcCheckpointDto {
  @ApiProperty({ enum: QCCheckpointType, description: 'Checkpoint type' })
  @IsEnum(QCCheckpointType)
  @IsNotEmpty()
  checkpointType: QCCheckpointType;

  @ApiProperty({ enum: QCParameter, description: 'Quality parameter being checked' })
  @IsEnum(QCParameter)
  @IsNotEmpty()
  parameter: QCParameter;

  @ApiProperty({ description: 'Measured value' })
  @IsNumber()
  value: number;

  @ApiProperty({ description: 'Unit of measurement' })
  @IsString()
  @IsNotEmpty()
  unit: string;

  @ApiProperty({ description: 'Minimum acceptable value' })
  @IsNumber()
  minAcceptable: number;

  @ApiProperty({ description: 'Maximum acceptable value' })
  @IsNumber()
  maxAcceptable: number;

  @ApiPropertyOptional({ description: 'Additional notes' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class QcCheckpointResultDto {
  checkpointId: string;
  productionOrderId: string;
  status: 'PASS' | 'FAIL';
  parameter: string;
  value: number;
  message: string;
  actionRequired?: string;
}
