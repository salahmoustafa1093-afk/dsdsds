import { IsString, IsNumber, IsOptional, IsUUID, IsEnum, IsNotEmpty } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { AnimalType, FeedType, FeedFormulaStatus } from '@prisma/client';

export class CreateFeedFormulaIngredientDto {
  @ApiProperty({ description: 'Ingredient name' })
  @IsString()
  @IsNotEmpty()
  ingredientName: string;

  @ApiProperty({ description: 'Percentage in formula (0-100)' })
  @IsNumber()
  percentage: number;

  @ApiPropertyOptional({ description: 'Protein percentage' })
  @IsOptional()
  @IsNumber()
  proteinPercent?: number;

  @ApiPropertyOptional({ description: 'Energy value' })
  @IsOptional()
  @IsNumber()
  energyValue?: number;

  @ApiPropertyOptional({ description: 'Cost per kg' })
  @IsOptional()
  @IsNumber()
  costPerKg?: number;

  @ApiPropertyOptional({ description: 'Display order' })
  @IsOptional()
  @IsNumber()
  order?: number;
}

export class CreateFeedFormulaDto {
  @ApiProperty({ description: 'Formula name' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ enum: AnimalType, description: 'Target animal type' })
  @IsEnum(AnimalType)
  targetAnimal: AnimalType;

  @ApiProperty({ enum: FeedType, description: 'Feed type' })
  @IsEnum(FeedType)
  feedType: FeedType;

  @ApiPropertyOptional({ description: 'Created by user ID' })
  @IsOptional()
  @IsUUID()
  createdBy?: string;

  @ApiProperty({ type: [CreateFeedFormulaIngredientDto], description: 'Formula ingredients' })
  ingredients: CreateFeedFormulaIngredientDto[];
}

export class UpdateFeedFormulaDto {
  @ApiPropertyOptional({ description: 'Formula name' })
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional({ enum: FeedFormulaStatus, description: 'Formula status' })
  @IsOptional()
  @IsEnum(FeedFormulaStatus)
  status?: FeedFormulaStatus;

  @ApiPropertyOptional({ enum: AnimalType, description: 'Target animal type' })
  @IsOptional()
  @IsEnum(AnimalType)
  targetAnimal?: AnimalType;

  @ApiPropertyOptional({ enum: FeedType, description: 'Feed type' })
  @IsOptional()
  @IsEnum(FeedType)
  feedType?: FeedType;

  @ApiPropertyOptional({ description: 'Approved by user ID' })
  @IsOptional()
  @IsUUID()
  approvedBy?: string;
}

export class ApproveFeedFormulaDto {
  @ApiProperty({ description: 'User ID approving the formula' })
  @IsUUID()
  @IsNotEmpty()
  approvedBy: string;
}
