import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  MovementType,
  FeedFormulaStatus,
  AnimalType,
  Prisma,
} from '@prisma/client';
import type {
  StockMovement,
  Product,
  FeedFormula,
  FeedFormulaIngredient,
} from '@prisma/client';
import {
  CreateProductionOrderDto,
  UpdateProductionStatusDto,
  ConsumeBomDto,
  QcCheckpointDto,
  QCCheckpointType,
  QcCheckpointResultDto,
  DowntimeRecordDto,
  CreateFeedFormulaDto,
  CreateFeedFormulaIngredientDto,
  UpdateFeedFormulaDto,
  ApproveFeedFormulaDto,
  CreateFeedCostDto,
} from './dto';

// ═══════════════════════════════════════════════════════════
// INTERFACES (computed/service-level types)
// ═══════════════════════════════════════════════════════════

interface BOMConsumptionResult {
  productionOrderId: string;
  productId: string;
  plannedQty: number;
  ingredients: Array<{
    name: string;
    requiredQty: number;
    availableQty: number;
    unitCost: number;
    totalCost: number;
    sufficient: boolean;
  }>;
  totalMaterialCost: number;
  allSufficient: boolean;
  shortages: Array<{ name: string; required: number; available: number; shortfall: number }>;
  stockMovementsCreated: number;
}

interface YieldResult {
  productionOrderId: string;
  plannedQty: number;
  actualOutputQty: number;
  yieldPercent: number;
  wastePercent: number;
  standardYield: number;
  belowThreshold: boolean;
  status: 'PASS' | 'WARNING' | 'FAIL';
}

interface CostAllocationResult {
  productionOrderId: string;
  materialCost: number;
  laborCost: number;
  overheadCost: number;
  totalCost: number;
  actualOutputQty: number;
  costPerUnit: number;
  costBreakdown: { category: string; amount: number; percent: number }[];
}

interface QCCheckpointRecord {
  id: string;
  productionOrderId: string;
  checkpointType: 'IN_PROCESS' | 'FINAL';
  parameter: 'MOISTURE' | 'PROTEIN' | 'PARTICLE_SIZE' | 'FOREIGN_MATTER' | 'CUSTOM';
  value: number;
  unit: string;
  minAcceptable: number;
  maxAcceptable: number;
  status: 'PASS' | 'FAIL';
  notes: string | null;
  createdAt: Date;
}

interface DowntimeRecord {
  id: string;
  reason: string;
  durationMinutes: number;
  notes: string | null;
  productionOrderId: string | null;
  startTime: Date;
  createdAt: Date;
}

interface ProductionScheduleItem {
  orderId: string;
  orderNumber: string;
  priority: number;
  productName: string;
  plannedQty: number;
  dueDate: Date | null;
  assignedWarehouseId: string | null;
  assignedWarehouseName: string | null;
  estimatedStart: Date | null;
  estimatedCompletion: Date | null;
  status: string;
}

interface DowntimeSummary {
  reason: string;
  totalMinutes: number;
  occurrenceCount: number;
  avgDurationMinutes: number;
}

interface OEEResult {
  warehouseId: string;
  startDate: Date;
  endDate: Date;
  availabilityPercent: number;
  performancePercent: number;
  qualityPercent: number;
  oeePercent: number;
  details: {
    plannedMinutes: number;
    downtimeMinutes: number;
    actualOutput: number;
    theoreticalOutput: number;
    goodOutput: number;
    totalOutput: number;
  };
}

// ═══════════════════════════════════════════════════════════

@Injectable()
export class ProductionService {
  private readonly logger = new Logger(ProductionService.name);
  private readonly YIELD_THRESHOLD = 95;

  // In-memory stores for service-level entities (no DB models exist)
  private qcCheckpoints: Map<string, QCCheckpointRecord[]> = new Map();
  private downtimeRecords: Map<string, DowntimeRecord[]> = new Map();
  private productionOrderCounter = 0;

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════════════════════
  // HELPER: Generate production order number
  // ═══════════════════════════════════════════════════════════

  private async generateOrderNumber(): Promise<string> {
    this.productionOrderCounter++;
    return `PROD-${Date.now().toString(36).toUpperCase()}-${this.productionOrderCounter.toString().padStart(4, '0')}`;
  }

  // ═══════════════════════════════════════════════════════════
  // HELPER: Build a production order from StockMovement (CONVERSION)
  // ═══════════════════════════════════════════════════════════
  // ═══════════════════════════════════════════════════════════

  private buildProductionOrder(
    movement: StockMovement & {
      product?: { id: string; name: string } | null;
      warehouse?: { id: string; name: string } | null;
    },
    status?: string,
    actualQty?: number | null,
    startDate?: Date | null,
    endDate?: Date | null,
    laborRate?: number,
    overheadRate?: number,
    isUrgent?: boolean,
    quarantineReason?: string | null,
  ) {
    const notesParsed = this.parseNotesJson(movement.notes);
    return {
      id: movement.id,
      orderNumber: movement.movementNumber,
      status: status ?? notesParsed.status ?? 'DRAFT',
      productId: movement.productId,
      product: movement.product,
      quantity: Number(movement.quantity),
      actualQty: actualQty ?? notesParsed.actualQty ?? null,
      plannedDate: movement.createdAt,
      startDate: startDate ?? notesParsed.startDate ?? null,
      endDate: endDate ?? notesParsed.endDate ?? null,
      batchNumber: movement.batchNumber ?? null,
      warehouseId: movement.warehouseId,
      warehouse: movement.warehouse,
      companyId: null,
      notes: movement.notes,
      createdBy: movement.createdBy,
      createdAt: movement.createdAt,
      laborRate: laborRate ?? notesParsed.laborRate ?? null,
      overheadRate: overheadRate ?? notesParsed.overheadRate ?? null,
      isUrgent: isUrgent ?? notesParsed.isUrgent ?? false,
      quarantineReason: quarantineReason ?? notesParsed.quarantineReason ?? null,
    };
  }

  private parseNotesJson(notes: string | null): Record<string, unknown> {
    if (!notes) return {};
    try {
      const parsed = JSON.parse(notes);
      if (typeof parsed === 'object' && parsed !== null) return parsed;
      return {};
    } catch {
      return {};
    }
  }

  private buildNotesJson(data: Record<string, unknown>): string {
    return JSON.stringify(data);
  }

  // ═══════════════════════════════════════════════════════════
  // CRUD OPERATIONS — Production Orders (via StockMovement)
  // ═══════════════════════════════════════════════════════════

  /**
   * List production orders.
   * Production orders are StockMovements with type = 'CONVERSION'.
   */
  async findAll(
    companyId: string,
    options: { page?: number; limit?: number; status?: string; productId?: string; warehouseId?: string },
  ) {
    const { page = 1, limit = 10, status, productId, warehouseId } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.StockMovementWhereInput = {
      type: 'CONVERSION' as MovementType,
      product: { companyId },
    };
    if (productId) where.productId = productId;
    if (warehouseId) where.warehouseId = warehouseId;

    const [movements, total] = await Promise.all([
      this.prisma.stockMovement.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          product: { select: { id: true, name: true, code: true } },
          warehouse: { select: { id: true, name: true, code: true } },
        },
      }),
      this.prisma.stockMovement.count({ where }),
    ]);

    // Filter by status if requested (status stored in notes JSON)
    let filtered = movements;
    if (status) {
      filtered = movements.filter((m) => {
        const parsed = this.parseNotesJson(m.notes);
        return (parsed.status as string | undefined) === status;
      });
    }

    const data = filtered.map((m) => {
      const parsed = this.parseNotesJson(m.notes);
      return this.buildProductionOrder(
        m,
        parsed.status as string | undefined,
        parsed.actualQty as number | undefined,
        parsed.startDate ? new Date(parsed.startDate as string) : undefined,
        parsed.endDate ? new Date(parsed.endDate as string) : undefined,
        parsed.laborRate as number | undefined,
        parsed.overheadRate as number | undefined,
        parsed.isUrgent as boolean | undefined,
        parsed.quarantineReason as string | undefined,
      );
    });

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Get a single production order by ID.
   */
  async findOne(id: string, companyId: string) {
    const movement = await this.prisma.stockMovement.findFirst({
      where: {
        id,
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
      include: {
        product: { select: { id: true, name: true, code: true } },
        warehouse: { select: { id: true, name: true, code: true } },
      },
    });

    if (!movement) throw new NotFoundException('Production order not found');

    const parsed = this.parseNotesJson(movement.notes);
    const order = this.buildProductionOrder(
      movement,
      parsed.status as string | undefined,
      parsed.actualQty as number | undefined,
      parsed.startDate ? new Date(parsed.startDate as string) : undefined,
      parsed.endDate ? new Date(parsed.endDate as string) : undefined,
      parsed.laborRate as number | undefined,
      parsed.overheadRate as number | undefined,
      parsed.isUrgent as boolean | undefined,
      parsed.quarantineReason as string | undefined,
    );

    // Attach related data
    const yieldData = this.computeYieldFromOrder(order);
    const qcData = this.qcCheckpoints.get(id) ?? [];
    const dtData = this.downtimeRecords.get(id) ?? [];

    return {
      data: {
        ...order,
        yield: yieldData,
        qcCheckpoints: qcData,
        downtimeRecords: dtData,
      },
    };
  }

  /**
   * Create a new production order.
   * Stored as a StockMovement with type = 'CONVERSION'.
   */
  async create(companyId: string, dto: CreateProductionOrderDto) {
    const orderNumber = await this.generateOrderNumber();

    // Verify product exists and belongs to company
    const product = await this.prisma.product.findFirst({
      where: { id: dto.productId, companyId, deletedAt: null },
    });
    if (!product) throw new NotFoundException('Product not found');

    // Determine warehouse
    let warehouseId = dto.warehouseId;
    if (!warehouseId) {
      const warehouse = await this.prisma.warehouse.findFirst({
        where: { branch: { companyId }, status: 'ACTIVE' },
        orderBy: { createdAt: 'asc' },
      });
      if (!warehouse) throw new BadRequestException('No active warehouse found for this company');
      warehouseId = warehouse.id;
    } else {
      const wh = await this.prisma.warehouse.findFirst({
        where: { id: warehouseId, branch: { companyId } },
      });
      if (!wh) throw new NotFoundException('Warehouse not found');
    }

    // Build notes JSON with order metadata
    const notesObj: Record<string, unknown> = {
      status: 'DRAFT',
      isUrgent: false,
      actualQty: null,
      startDate: null,
      endDate: null,
      laborRate: null,
      overheadRate: null,
      quarantineReason: null,
      plannedQty: dto.quantity,
      formulaId: dto.formulaId ?? null,
      productionNotes: dto.notes ?? null,
    };

    const movement = await this.prisma.stockMovement.create({
      data: {
        movementNumber: orderNumber,
        type: 'CONVERSION' as MovementType,
        productId: dto.productId,
        warehouseId: warehouseId,
        quantity: dto.quantity,
        unitCost: product.avgCost,
        totalCost: 0,
        batchNumber: dto.batchNumber ?? null,
        referenceType: 'PRODUCTION_ORDER',
        referenceId: null,
        notes: this.buildNotesJson(notesObj),
        createdBy: dto.createdBy ?? 'system',
      },
      include: {
        product: { select: { id: true, name: true, code: true } },
        warehouse: { select: { id: true, name: true, code: true } },
      },
    });

    const order = this.buildProductionOrder(movement, 'DRAFT', null, null, null, null, null, false, null);

    this.logger.log(`Production order created: ${order.orderNumber}`);
    return { data: order };
  }

  /**
   * Update production order status with state-machine validation.
   */
  async updateStatus(id: string, companyId: string, dto: UpdateProductionStatusDto) {
    const validTransitions: Record<string, string[]> = {
      DRAFT: ['SCHEDULED', 'CANCELLED'],
      SCHEDULED: ['IN_PROGRESS', 'CANCELLED'],
      IN_PROGRESS: ['COMPLETED', 'ON_HOLD', 'CANCELLED'],
      ON_HOLD: ['IN_PROGRESS', 'CANCELLED'],
      COMPLETED: ['CLOSED'],
      CLOSED: [],
      CANCELLED: [],
      QUARANTINE: ['ON_HOLD', 'CANCELLED'],
    };

    const movement = await this.prisma.stockMovement.findFirst({
      where: {
        id,
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
    });
    if (!movement) throw new NotFoundException('Production order not found');

    const parsed = this.parseNotesJson(movement.notes);
    const currentStatus = (parsed.status as string) || 'DRAFT';

    const allowedNext = validTransitions[currentStatus] || [];
    if (!allowedNext.includes(dto.status)) {
      throw new BadRequestException(
        `Invalid status transition from ${currentStatus} to ${dto.status}. Allowed: ${allowedNext.join(', ')}`,
      );
    }

    // Update notes JSON with new status and metadata
    const updatedNotes: Record<string, unknown> = {
      ...parsed,
      status: dto.status,
    };

    if (dto.status === 'IN_PROGRESS') {
      updatedNotes.startDate = dto.startDate ?? new Date().toISOString();
    }
    if (dto.status === 'COMPLETED') {
      updatedNotes.endDate = dto.endDate ?? new Date().toISOString();
      updatedNotes.actualQty = dto.actualQty ? parseFloat(dto.actualQty) : Number(movement.quantity);
    }
    if (dto.laborRate) updatedNotes.laborRate = parseFloat(dto.laborRate);
    if (dto.overheadRate) updatedNotes.overheadRate = parseFloat(dto.overheadRate);

    const updated = await this.prisma.stockMovement.update({
      where: { id },
      data: {
        notes: this.buildNotesJson(updatedNotes),
        unitCost: dto.actualQty ? movement.unitCost : movement.unitCost,
      },
    });

    this.logger.log(
      `Production order ${movement.movementNumber} status: ${currentStatus} -> ${dto.status}`,
    );
    return { data: { ...updated, status: dto.status } };
  }


  // ═══════════════════════════════════════════════════════════
  // 1. BILL OF MATERIALS (BOM) CONSUMPTION
  // ═══════════════════════════════════════════════════════════

  /**
   * Consume raw materials based on BOM (feed formula) for a production order.
   * Reads the feed formula for the product, calculates required quantities,
   * checks stock availability, and creates stock movements (ISSUE).
   */
  async consumeBOM(
    productionOrderId: string,
    companyId: string,
    dto?: ConsumeBomDto,
  ): Promise<BOMConsumptionResult> {
    const movement = await this.prisma.stockMovement.findFirst({
      where: {
        id: productionOrderId,
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
      include: { product: true },
    });
    if (!movement) throw new NotFoundException('Production order not found');

    const notesParsed = this.parseNotesJson(movement.notes);
    const currentStatus = (notesParsed.status as string) || 'DRAFT';
    if (currentStatus === 'CANCELLED' || currentStatus === 'CLOSED') {
      throw new BadRequestException(`Cannot consume BOM for order in ${currentStatus} status`);
    }

    const plannedQty = Number(movement.quantity);

    // Find the feed formula — try formulaId from notes first, then by feed type
    let formula: FeedFormula & { ingredients: FeedFormulaIngredient[] } | null = null;
    const formulaId = (notesParsed.formulaId as string) || undefined;

    if (formulaId) {
      formula = await this.prisma.feedFormula.findFirst({
        where: { id: formulaId, status: 'ACTIVE' },
        include: { ingredients: { orderBy: { order: 'asc' } } },
      });
    }

    if (!formula) {
      // Find any active formula with ingredients
      formula = await this.prisma.feedFormula.findFirst({
        where: { status: 'ACTIVE', ingredients: { some: {} } },
        include: { ingredients: { orderBy: { order: 'asc' } } },
        orderBy: { createdAt: 'desc' },
      });
    }

    if (!formula) {
      throw new NotFoundException(
        `No active BOM (feed formula) found for product ${movement.product?.name || movement.productId}`,
      );
    }

    this.logger.log(
      `Consuming BOM for order ${movement.movementNumber} using formula "${formula.name}" with ${formula.ingredients.length} ingredients`,
    );

    const ingredientsResult: BOMConsumptionResult['ingredients'] = [];
    const shortages: BOMConsumptionResult['shortages'] = [];
    let totalMaterialCost = 0;
    let allSufficient = true;
    let stockMovementsCreated = 0;

    // Determine source warehouse for consumption
    const sourceWarehouseId =
      dto?.warehouseId ||
      movement.warehouseId ||
      (
        await this.prisma.warehouse.findFirst({
          where: { branch: { companyId }, status: 'ACTIVE' },
          orderBy: { createdAt: 'asc' },
        })
      )?.id;

    // For each BOM ingredient, calculate required quantity and check stock
    for (const ingredient of formula.ingredients) {
      const requiredQty = (plannedQty * Number(ingredient.percentage)) / 100;
      const unitCost = Number(ingredient.costPerKg || 0);
      const totalCost = requiredQty * unitCost;

      // Check current stock for this raw material
      // Look up by ingredient name matching product name
      const stockProduct = await this.prisma.product.findFirst({
        where: {
          companyId,
          name: { contains: ingredient.ingredientName, mode: 'insensitive' },
          deletedAt: null,
        },
      });

      let availableQty = 0;
      if (stockProduct) {
        // Calculate net stock from movements
        const movements = await this.prisma.stockMovement.findMany({
          where: { productId: stockProduct.id },
          select: { quantity: true, type: true },
        });
        availableQty = movements.reduce((s: number, m: { quantity: Prisma.Decimal; type: string }) => {
          const qty = Number(m.quantity);
          if (m.type === 'RECEIPT') return s + qty;
          if (m.type === 'ISSUE' || m.type === 'WASTE') return s - qty;
          return s;
        }, 0);
      }

      const sufficient = availableQty >= requiredQty;
      if (!sufficient) {
        allSufficient = false;
        shortages.push({
          name: ingredient.ingredientName,
          required: Math.round(requiredQty * 1000) / 1000,
          available: Math.round(availableQty * 1000) / 1000,
          shortfall: Math.round((requiredQty - availableQty) * 1000) / 1000,
        });
      }

      ingredientsResult.push({
        name: ingredient.ingredientName,
        requiredQty: Math.round(requiredQty * 1000) / 1000,
        availableQty: Math.round(availableQty * 1000) / 1000,
        unitCost,
        totalCost: Math.round(totalCost * 100) / 100,
        sufficient,
      });

      totalMaterialCost += totalCost;

      // If sufficient stock, create stock movement (ISSUE from inventory)
      if (sufficient && stockProduct && sourceWarehouseId) {
        const movementCount = await this.prisma.stockMovement.count({
          where: { warehouseId: sourceWarehouseId },
        });
        await this.prisma.stockMovement.create({
          data: {
            movementNumber: `SM-CON-${Date.now().toString(36).toUpperCase()}-${(movementCount + 1).toString().padStart(4, '0')}`,
            type: 'ISSUE' as MovementType,
            productId: stockProduct.id,
            warehouseId: sourceWarehouseId,
            quantity: requiredQty,
            unitCost,
            totalCost,
            referenceType: 'PRODUCTION_ORDER',
            referenceId: productionOrderId,
            notes: `BOM consumption for ${movement.movementNumber} -- ${ingredient.ingredientName}`,
            createdBy: dto?.createdBy || movement.createdBy || 'system',
          },
        });
        stockMovementsCreated++;
      }
    }

    // Update the production order notes with consumed materials summary
    const updatedNotes = {
      ...notesParsed,
      consumedFormulaId: formula.id,
      consumedFormulaName: formula.name,
      consumedAt: new Date().toISOString(),
      totalMaterialCost,
      allSufficient,
      shortagesCount: shortages.length,
    };

    await this.prisma.stockMovement.update({
      where: { id: productionOrderId },
      data: { notes: this.buildNotesJson(updatedNotes) },
    });

    this.logger.log(
      `BOM consumption for ${movement.movementNumber}: ${ingredientsResult.length} ingredients, ${shortages.length} shortages, ${stockMovementsCreated} stock movements`,
    );

    return {
      productionOrderId,
      productId: movement.productId,
      plannedQty,
      ingredients: ingredientsResult,
      totalMaterialCost: Math.round(totalMaterialCost * 100) / 100,
      allSufficient,
      shortages,
      stockMovementsCreated,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 2. YIELD CALCULATION
  // ═══════════════════════════════════════════════════════════

  /**
   * Calculate production yield percentage and waste.
   */
  async calculateYield(productionOrderId: string, companyId: string): Promise<YieldResult> {
    const movement = await this.prisma.stockMovement.findFirst({
      where: {
        id: productionOrderId,
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
      include: { product: true },
    });
    if (!movement) throw new NotFoundException('Production order not found');

    const order = this.buildProductionOrder(
      movement,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
      undefined,
    );
    return this.computeYieldFromOrder(order);
  }

  private computeYieldFromOrder(order: {
    id: string;
    quantity: number;
    actualQty?: number | null;
  }): YieldResult {
    const plannedQty = Number(order.quantity);
    const actualOutputQty = Number(order.actualQty || order.quantity);

    if (plannedQty <= 0) {
      throw new BadRequestException('Planned quantity must be greater than 0');
    }

    const yieldPercent = (actualOutputQty / plannedQty) * 100;
    const wastePercent = ((plannedQty - actualOutputQty) / plannedQty) * 100;
    const standardYield = 98; // Industry standard for feed production
    const belowThreshold = yieldPercent < this.YIELD_THRESHOLD;

    let status: YieldResult['status'] = 'PASS';
    if (yieldPercent < 90) status = 'FAIL';
    else if (yieldPercent < this.YIELD_THRESHOLD) status = 'WARNING';

    return {
      productionOrderId: order.id,
      plannedQty,
      actualOutputQty,
      yieldPercent: Math.round(yieldPercent * 100) / 100,
      wastePercent: Math.round(wastePercent * 100) / 100,
      standardYield,
      belowThreshold,
      status,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 3. COST ALLOCATION
  // ═══════════════════════════════════════════════════════════

  /**
   * Allocate production costs: material, labor, overhead.
   * Calculates total cost and cost per unit.
   */
  async allocateCosts(
    productionOrderId: string,
    companyId: string,
  ): Promise<CostAllocationResult> {
    const movement = await this.prisma.stockMovement.findFirst({
      where: {
        id: productionOrderId,
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
      include: {
        product: true,
      },
    });
    if (!movement) throw new NotFoundException('Production order not found');

    const notesParsed = this.parseNotesJson(movement.notes);
    const actualOutputQty = Number(
      (notesParsed.actualQty as number) || movement.quantity,
    );
    if (actualOutputQty <= 0) {
      throw new BadRequestException('Actual output quantity must be greater than 0');
    }

    // Material cost: sum of all ISSUE stock movements linked to this production order
    const materialMovements = await this.prisma.stockMovement.findMany({
      where: {
        type: 'ISSUE' as MovementType,
        referenceType: 'PRODUCTION_ORDER',
        referenceId: productionOrderId,
      },
      select: { totalCost: true },
    });
    const materialCost = materialMovements.reduce(
      (s: number, m: { totalCost: Prisma.Decimal | null }) => s + Number(m.totalCost || 0),
      0,
    );

    // Labor cost: production hours x hourly rate
    // Calculate from order duration (startDate to endDate)
    let productionHours = 8; // default 8-hour shift
    const startDate = notesParsed.startDate ? new Date(notesParsed.startDate as string) : null;
    const endDate = notesParsed.endDate ? new Date(notesParsed.endDate as string) : null;
    if (startDate && endDate) {
      const diffMs = endDate.getTime() - startDate.getTime();
      productionHours = diffMs / (1000 * 60 * 60);
    }
    const hourlyRate = Number(notesParsed.laborRate) || 25; // default 25 EGP/hour
    const laborCost = productionHours * hourlyRate;

    // Overhead cost: machine hours x overhead rate per hour
    const overheadRatePerHour = Number(notesParsed.overheadRate) || 15; // default 15 EGP/hour
    const overheadCost = productionHours * overheadRatePerHour;

    // Downtime cost impact from in-memory records
    const dtRecords = this.downtimeRecords.get(productionOrderId) || [];
    const downtimeCost = dtRecords.reduce((s: number, d: DowntimeRecord) => {
      return s + d.durationMinutes * 0.5; // cost = 0.5 EGP per minute downtime
    }, 0);

    const totalCost = materialCost + laborCost + overheadCost + downtimeCost;
    const costPerUnit = totalCost / actualOutputQty;

    // Persist cost allocation summary back into production order notes
    const updatedNotes = {
      ...notesParsed,
      costAllocation: {
        materialCost,
        laborCost,
        overheadCost,
        downtimeCost,
        totalCost,
        costPerUnit,
        productionHours,
        allocatedAt: new Date().toISOString(),
      },
    };

    await this.prisma.stockMovement.update({
      where: { id: productionOrderId },
      data: { notes: this.buildNotesJson(updatedNotes) },
    });

    this.logger.log(
      `Cost allocation for ${movement.movementNumber}: total=${totalCost.toFixed(2)}, perUnit=${costPerUnit.toFixed(4)}`,
    );

    return {
      productionOrderId: movement.id,
      materialCost: Math.round(materialCost * 100) / 100,
      laborCost: Math.round(laborCost * 100) / 100,
      overheadCost: Math.round(overheadCost * 100) / 100,
      totalCost: Math.round(totalCost * 100) / 100,
      actualOutputQty,
      costPerUnit: Math.round(costPerUnit * 10000) / 10000,
      costBreakdown: [
        {
          category: 'Materials',
          amount: Math.round(materialCost * 100) / 100,
          percent: totalCost > 0 ? Math.round((materialCost / totalCost) * 10000) / 100 : 0,
        },
        {
          category: 'Labor',
          amount: Math.round(laborCost * 100) / 100,
          percent: totalCost > 0 ? Math.round((laborCost / totalCost) * 10000) / 100 : 0,
        },
        {
          category: 'Overhead',
          amount: Math.round(overheadCost * 100) / 100,
          percent: totalCost > 0 ? Math.round((overheadCost / totalCost) * 10000) / 100 : 0,
        },
        {
          category: 'Downtime',
          amount: Math.round(downtimeCost * 100) / 100,
          percent: totalCost > 0 ? Math.round((downtimeCost / totalCost) * 10000) / 100 : 0,
        },
      ],
    };
  }


  // ═══════════════════════════════════════════════════════════
  // 4. QUALITY CONTROL CHECKPOINTS (service-level, in-memory)
  // ═══════════════════════════════════════════════════════════

  /**
   * Add a QC checkpoint to a production order.
   * Checks parameter against acceptable range.
   * If FAIL on FINAL checkpoint, flags for quarantine.
   */
  async addQCCheckpoint(
    productionOrderId: string,
    companyId: string,
    checkpoint: QcCheckpointDto,
  ): Promise<QcCheckpointResultDto> {
    const movement = await this.prisma.stockMovement.findFirst({
      where: {
        id: productionOrderId,
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
    });
    if (!movement) throw new NotFoundException('Production order not found');

    const notesParsed = this.parseNotesJson(movement.notes);
    const currentStatus = (notesParsed.status as string) || 'DRAFT';
    if (currentStatus === 'CANCELLED' || currentStatus === 'CLOSED') {
      throw new BadRequestException(`Cannot add QC to ${currentStatus} order`);
    }

    const { value, minAcceptable, maxAcceptable } = checkpoint;
    const passed = value >= minAcceptable && value <= maxAcceptable;
    const status: 'PASS' | 'FAIL' = passed ? 'PASS' : 'FAIL';

    // Persist the checkpoint in-memory (no DB model exists)
    const qcRecord: QCCheckpointRecord = {
      id: crypto.randomUUID(),
      productionOrderId,
      checkpointType: checkpoint.checkpointType as 'IN_PROCESS' | 'FINAL',
      parameter: checkpoint.parameter as 'MOISTURE' | 'PROTEIN' | 'PARTICLE_SIZE' | 'FOREIGN_MATTER' | 'CUSTOM',
      value,
      unit: checkpoint.unit,
      minAcceptable,
      maxAcceptable,
      status,
      notes: checkpoint.notes || null,
      createdAt: new Date(),
    };

    const existing = this.qcCheckpoints.get(productionOrderId) || [];
    existing.push(qcRecord);
    this.qcCheckpoints.set(productionOrderId, existing);

    let actionRequired: string | undefined;

    // If FINAL checkpoint FAILs, quarantine the batch
    if (status === 'FAIL' && checkpoint.checkpointType === QCCheckpointType.FINAL) {
      const updatedNotes = {
        ...notesParsed,
        status: 'QUARANTINE',
        quarantineReason: `QC FAIL: ${checkpoint.parameter}=${value}${checkpoint.unit} (acceptable: ${minAcceptable}-${maxAcceptable})`,
      };
      await this.prisma.stockMovement.update({
        where: { id: productionOrderId },
        data: { notes: this.buildNotesJson(updatedNotes) },
      });
      actionRequired =
        'Batch quarantined. Review required before release. Parameter out of acceptable range.';
      this.logger.warn(
        `QC FAIL on ${movement.movementNumber}: ${checkpoint.parameter}=${value}${checkpoint.unit}. Batch quarantined.`,
      );
    }

    // If IN_PROCESS FAILs, stop production
    if (status === 'FAIL' && checkpoint.checkpointType === QCCheckpointType.IN_PROCESS) {
      const updatedNotes = {
        ...notesParsed,
        status: 'ON_HOLD',
        onHoldReason: `QC IN_PROCESS FAIL: ${checkpoint.parameter}=${value}${checkpoint.unit}`,
      };
      await this.prisma.stockMovement.update({
        where: { id: productionOrderId },
        data: { notes: this.buildNotesJson(updatedNotes) },
      });
      actionRequired = 'Production stopped. In-process quality check failed.';
      this.logger.warn(
        `QC IN_PROCESS FAIL on ${movement.movementNumber}: ${checkpoint.parameter}=${value}${checkpoint.unit}. Production stopped.`,
      );
    }

    const message = passed
      ? `${checkpoint.parameter}: ${value}${checkpoint.unit} -- within acceptable range (${minAcceptable}-${maxAcceptable})`
      : `${checkpoint.parameter}: ${value}${checkpoint.unit} -- OUT OF RANGE (${minAcceptable}-${maxAcceptable})`;

    return {
      checkpointId: qcRecord.id,
      productionOrderId,
      status,
      parameter: checkpoint.parameter,
      value,
      message,
      actionRequired,
    };
  }

  /**
   * Get all QC checkpoints for a production order.
   */
  async getQCCheckpoints(productionOrderId: string, companyId: string) {
    const movement = await this.prisma.stockMovement.findFirst({
      where: {
        id: productionOrderId,
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
    });
    if (!movement) throw new NotFoundException('Production order not found');

    const checkpoints = this.qcCheckpoints.get(productionOrderId) || [];
    // Sort by createdAt desc (already in that order since we push)
    const sorted = [...checkpoints].sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
    );

    const summary = {
      total: sorted.length,
      passed: sorted.filter((c) => c.status === 'PASS').length,
      failed: sorted.filter((c) => c.status === 'FAIL').length,
      passRate:
        sorted.length > 0
          ? Math.round(
              (sorted.filter((c) => c.status === 'PASS').length / sorted.length) * 10000,
            ) / 100
          : 0,
    };

    return { data: sorted, summary };
  }

  // ═══════════════════════════════════════════════════════════
  // 5. OEE CALCULATION (Overall Equipment Effectiveness)
  // ═══════════════════════════════════════════════════════════

  /**
   * Calculate OEE for a warehouse/production area over a date range.
   * OEE = Availability x Performance x Quality
   */
  async calculateOEE(
    warehouseId: string,
    startDate: Date,
    endDate: Date,
    companyId: string,
  ): Promise<OEEResult> {
    // Verify warehouse exists and belongs to company
    const warehouse = await this.prisma.warehouse.findFirst({
      where: { id: warehouseId, branch: { companyId } },
    });
    if (!warehouse) throw new NotFoundException('Warehouse not found');

    // Get all completed CONVERSION stock movements in this warehouse during the date range
    const movements = await this.prisma.stockMovement.findMany({
      where: {
        warehouseId,
        type: 'CONVERSION' as MovementType,
        createdAt: { gte: startDate, lte: endDate },
      },
    });

    // Filter to only completed orders (status in notes = COMPLETED or CLOSED)
    const completedMovements = movements.filter((m) => {
      const parsed = this.parseNotesJson(m.notes);
      const status = (parsed.status as string) || 'DRAFT';
      return status === 'COMPLETED' || status === 'CLOSED';
    });

    if (completedMovements.length === 0) {
      return {
        warehouseId,
        startDate,
        endDate,
        availabilityPercent: 0,
        performancePercent: 0,
        qualityPercent: 0,
        oeePercent: 0,
        details: {
          plannedMinutes: 0,
          downtimeMinutes: 0,
          actualOutput: 0,
          theoreticalOutput: 0,
          goodOutput: 0,
          totalOutput: 0,
        },
      };
    }

    // Calculate planned time and other metrics
    let plannedMinutes = 0;
    let downtimeMinutes = 0;
    let actualOutput = 0;
    let totalOutput = 0;
    let goodOutput = 0;

    for (const movement of completedMovements) {
      const parsed = this.parseNotesJson(movement.notes);

      // Planned time for this order
      const orderStart = parsed.startDate ? new Date(parsed.startDate as string) : null;
      const orderEnd = parsed.endDate ? new Date(parsed.endDate as string) : null;
      if (orderStart && orderEnd) {
        const orderMinutes = (orderEnd.getTime() - orderStart.getTime()) / (1000 * 60);
        plannedMinutes += orderMinutes;
      } else {
        plannedMinutes += 480; // default 8 hours
      }

      // Downtime from in-memory records
      const orderDowntime = (this.downtimeRecords.get(movement.id) || []).reduce(
        (s: number, d: DowntimeRecord) => s + Number(d.durationMinutes || 0),
        0,
      );
      downtimeMinutes += orderDowntime;

      // Output quantities
      const orderOutput = Number((parsed.actualQty as number) || movement.quantity);
      actualOutput += orderOutput;
      totalOutput += orderOutput;

      // Quality: count good output (based on QC pass rate)
      const qcChecks = this.qcCheckpoints.get(movement.id) || [];
      const qcPassRate =
        qcChecks.length > 0
          ? qcChecks.filter((c) => c.status === 'PASS').length / qcChecks.length
          : 1;
      goodOutput += orderOutput * qcPassRate;
    }

    // Availability = (Planned Time - Downtime) / Planned Time
    const availabilityPercent =
      plannedMinutes > 0
        ? ((plannedMinutes - downtimeMinutes) / plannedMinutes) * 100
        : 0;

    // Performance = Actual Output / Theoretical Output
    // Theoretical output = 10 tons per hour x running hours (default assumption)
    const capacityPerHour = 10;
    const runningHours = (plannedMinutes - downtimeMinutes) / 60;
    const theoreticalOutput = capacityPerHour * runningHours;
    const performancePercent =
      theoreticalOutput > 0 ? (actualOutput / theoreticalOutput) * 100 : 0;

    // Quality = Good Output / Total Output
    const qualityPercent = totalOutput > 0 ? (goodOutput / totalOutput) * 100 : 0;

    // OEE = Availability x Performance x Quality
    const oeePercent =
      (availabilityPercent / 100) *
      (performancePercent / 100) *
      (qualityPercent / 100) *
      100;

    return {
      warehouseId,
      startDate,
      endDate,
      availabilityPercent: Math.round(availabilityPercent * 100) / 100,
      performancePercent: Math.round(performancePercent * 100) / 100,
      qualityPercent: Math.round(qualityPercent * 100) / 100,
      oeePercent: Math.round(oeePercent * 100) / 100,
      details: {
        plannedMinutes: Math.round(plannedMinutes),
        downtimeMinutes: Math.round(downtimeMinutes),
        actualOutput: Math.round(actualOutput * 100) / 100,
        theoreticalOutput: Math.round(theoreticalOutput * 100) / 100,
        goodOutput: Math.round(goodOutput * 100) / 100,
        totalOutput: Math.round(totalOutput * 100) / 100,
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 6. DOWNTIME TRACKING (service-level, in-memory)
  // ═══════════════════════════════════════════════════════════

  /**
   * Record a downtime event for a warehouse/production area.
   */
  async recordDowntime(
    warehouseId: string,
    companyId: string,
    downtime: DowntimeRecordDto,
  ) {
    // Verify warehouse exists
    const warehouse = await this.prisma.warehouse.findFirst({
      where: { id: warehouseId, branch: { companyId } },
    });
    if (!warehouse) throw new NotFoundException('Warehouse not found');

    // If linked to a production order, verify it exists
    if (downtime.productionOrderId) {
      const order = await this.prisma.stockMovement.findFirst({
        where: {
          id: downtime.productionOrderId,
          type: 'CONVERSION' as MovementType,
          product: { companyId },
        },
      });
      if (!order) throw new NotFoundException('Linked production order not found');
    }

    const record: DowntimeRecord = {
      id: crypto.randomUUID(),
      reason: downtime.reason,
      durationMinutes: downtime.durationMinutes,
      notes: downtime.notes || null,
      productionOrderId: downtime.productionOrderId || null,
      startTime: downtime.startTime ? new Date(downtime.startTime) : new Date(),
      createdAt: new Date(),
    };

    // Store in-memory keyed by warehouseId
    const warehouseRecords = this.downtimeRecords.get(warehouseId) || [];
    warehouseRecords.push(record);
    this.downtimeRecords.set(warehouseId, warehouseRecords);

    // Also store keyed by production order if linked
    if (downtime.productionOrderId) {
      const orderRecords = this.downtimeRecords.get(downtime.productionOrderId) || [];
      orderRecords.push(record);
      this.downtimeRecords.set(downtime.productionOrderId, orderRecords);
    }

    this.logger.log(
      `Downtime recorded on warehouse ${warehouseId}: ${downtime.reason} for ${downtime.durationMinutes}min`,
    );

    return { data: record };
  }

  /**
   * Get downtime summary grouped by reason for a warehouse and date range.
   */
  async getDowntimeSummary(
    warehouseId: string,
    companyId: string,
    startDate: Date,
    endDate: Date,
  ): Promise<DowntimeSummary[]> {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: { id: warehouseId, branch: { companyId } },
    });
    if (!warehouse) throw new NotFoundException('Warehouse not found');

    const records = (this.downtimeRecords.get(warehouseId) || []).filter(
      (r) => r.startTime >= startDate && r.startTime <= endDate,
    );

    const grouped = new Map<string, { totalMinutes: number; count: number }>();
    for (const r of records) {
      const existing = grouped.get(r.reason) || { totalMinutes: 0, count: 0 };
      existing.totalMinutes += Number(r.durationMinutes);
      existing.count++;
      grouped.set(r.reason, existing);
    }

    return Array.from(grouped.entries())
      .map(([reason, data]) => ({
        reason,
        totalMinutes: data.totalMinutes,
        occurrenceCount: data.count,
        avgDurationMinutes: Math.round((data.totalMinutes / data.count) * 100) / 100,
      }))
      .sort((a, b) => b.totalMinutes - a.totalMinutes);
  }


  // ═══════════════════════════════════════════════════════════
  // 7. FEED FORMULA MANAGEMENT
  // ═══════════════════════════════════════════════════════════

  /**
   * List all feed formulas.
   */
  async findAllFormulas(options: {
    status?: FeedFormulaStatus;
    targetAnimal?: AnimalType;
    feedType?: string;
    search?: string;
    page?: number;
    limit?: number;
  }) {
    const { status, targetAnimal, feedType, search, page = 1, limit = 10 } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.FeedFormulaWhereInput = {};
    if (status) where.status = status;
    if (targetAnimal) where.targetAnimal = targetAnimal;
    if (feedType) where.feedType = feedType as FeedType;
    if (search) {
      where.name = { contains: search, mode: 'insensitive' };
    }

    const [data, total] = await Promise.all([
      this.prisma.feedFormula.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          ingredients: { orderBy: { order: 'asc' } },
          creator: { select: { id: true, fullName: true } },
          approver: { select: { id: true, fullName: true } },
          _count: { select: { ingredients: true, feedCosts: true } },
        },
      }),
      this.prisma.feedFormula.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Get a single feed formula by ID.
   */
  async findFormulaById(id: string) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id },
      include: {
        ingredients: { orderBy: { order: 'asc' } },
        feedCosts: { orderBy: { effectiveDate: 'desc' } },
        creator: { select: { id: true, fullName: true } },
        approver: { select: { id: true, fullName: true } },
      },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');
    return { data: formula };
  }

  /**
   * Create a new feed formula with ingredients.
   */
  async createFormula(dto: CreateFeedFormulaDto) {
    // Validate ingredient percentages sum to 100
    const totalPercentage = dto.ingredients.reduce(
      (sum: number, ing: CreateFeedFormulaIngredientDto) => sum + ing.percentage,
      0,
    );
    if (Math.abs(totalPercentage - 100) > 0.01) {
      throw new BadRequestException(
        `Ingredient percentages must sum to 100, got ${totalPercentage.toFixed(2)}`,
      );
    }

    const formula = await this.prisma.feedFormula.create({
      data: {
        name: dto.name,
        targetAnimal: dto.targetAnimal,
        feedType: dto.feedType,
        status: 'DRAFT',
        createdBy: dto.createdBy || 'system',
        ingredients: {
          create: dto.ingredients.map(
            (ing: CreateFeedFormulaIngredientDto, index: number) => ({
              ingredientName: ing.ingredientName,
              percentage: ing.percentage,
              proteinPercent: ing.proteinPercent ?? null,
              energyValue: ing.energyValue ?? null,
              costPerKg: ing.costPerKg ?? null,
              order: ing.order ?? index,
            }),
          ),
        },
      },
      include: {
        ingredients: { orderBy: { order: 'asc' } },
        creator: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Feed formula created: ${formula.name}`);
    return { data: formula };
  }

  /**
   * Update a feed formula (name, status, target, etc.).
   */
  async updateFormula(id: string, dto: UpdateFeedFormulaDto) {
    const formula = await this.prisma.feedFormula.findUnique({ where: { id } });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const data: Prisma.FeedFormulaUpdateInput = {};
    if (dto.name !== undefined) data.name = dto.name;
    if (dto.status !== undefined) data.status = dto.status;
    if (dto.targetAnimal !== undefined) data.targetAnimal = dto.targetAnimal;
    if (dto.feedType !== undefined) data.feedType = dto.feedType;

    const updated = await this.prisma.feedFormula.update({
      where: { id },
      data,
      include: {
        ingredients: { orderBy: { order: 'asc' } },
        creator: { select: { id: true, fullName: true } },
        approver: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Feed formula updated: ${updated.name}`);
    return { data: updated };
  }

  /**
   * Approve a feed formula.
   */
  async approveFormula(id: string, dto: ApproveFeedFormulaDto) {
    const formula = await this.prisma.feedFormula.findUnique({ where: { id } });
    if (!formula) throw new NotFoundException('Feed formula not found');
    if (formula.status === 'ACTIVE') {
      throw new BadRequestException('Formula is already active');
    }

    const updated = await this.prisma.feedFormula.update({
      where: { id },
      data: {
        status: 'ACTIVE',
        approvedBy: dto.approvedBy,
      },
      include: {
        ingredients: { orderBy: { order: 'asc' } },
        creator: { select: { id: true, fullName: true } },
        approver: { select: { id: true, fullName: true } },
      },
    });

    this.logger.log(`Feed formula approved: ${updated.name} by ${dto.approvedBy}`);
    return { data: updated };
  }

  /**
   * Delete/archive a feed formula.
   */
  async deleteFormula(id: string) {
    const formula = await this.prisma.feedFormula.findUnique({ where: { id } });
    if (!formula) throw new NotFoundException('Feed formula not found');

    await this.prisma.feedFormula.update({
      where: { id },
      data: { status: 'ARCHIVED' },
    });

    this.logger.log(`Feed formula archived: ${formula.name}`);
    return { message: 'Feed formula archived successfully' };
  }

  // ═══════════════════════════════════════════════════════════
  // 8. FEED COST TRACKING
  // ═══════════════════════════════════════════════════════════

  /**
   * Record feed production costs for a formula.
   */
  async createFeedCost(dto: CreateFeedCostDto) {
    const formula = await this.prisma.feedFormula.findUnique({
      where: { id: dto.formulaId },
    });
    if (!formula) throw new NotFoundException('Feed formula not found');

    // Validate that totalCost matches the sum of components
    const computedTotal = dto.rawMaterialCost + dto.laborCost + dto.overheadCost;
    if (Math.abs(computedTotal - dto.totalCost) > 0.01) {
      throw new BadRequestException(
        `Total cost (${dto.totalCost}) must equal rawMaterial + labor + overhead (${computedTotal})`,
      );
    }

    const feedCost = await this.prisma.feedCost.create({
      data: {
        formulaId: dto.formulaId,
        rawMaterialCost: dto.rawMaterialCost,
        laborCost: dto.laborCost,
        overheadCost: dto.overheadCost,
        totalCost: dto.totalCost,
        costPerTon: dto.costPerTon,
        margin: dto.margin ?? null,
        effectiveDate: dto.effectiveDate ? new Date(dto.effectiveDate) : new Date(),
      },
    });

    this.logger.log(
      `Feed cost recorded for formula ${formula.name}: ${dto.totalCost} EGP/ton`,
    );
    return { data: feedCost };
  }

  /**
   * Get cost history for a feed formula.
   */
  async getFormulaCostHistory(formulaId: string) {
    const formula = await this.prisma.feedFormula.findUnique({ where: { id: formulaId } });
    if (!formula) throw new NotFoundException('Feed formula not found');

    const costs = await this.prisma.feedCost.findMany({
      where: { formulaId },
      orderBy: { effectiveDate: 'desc' },
    });

    // Calculate cost trend
    const costTrend =
      costs.length >= 2
        ? {
            latestCost: Number(costs[0].costPerTon),
            previousCost: Number(costs[1].costPerTon),
            change: Number(costs[0].costPerTon) - Number(costs[1].costPerTon),
            changePercent:
              Number(costs[1].costPerTon) > 0
                ? ((Number(costs[0].costPerTon) - Number(costs[1].costPerTon)) /
                    Number(costs[1].costPerTon)) *
                  100
                : 0,
          }
        : null;

    return { data: costs, costTrend };
  }

  /**
   * Compare costs across different formulas.
   */
  async compareFormulaCosts(formulaIds: string[]) {
    if (formulaIds.length === 0) throw new BadRequestException('No formula IDs provided');

    const formulas = await this.prisma.feedFormula.findMany({
      where: { id: { in: formulaIds } },
      include: {
        ingredients: { orderBy: { order: 'asc' } },
        feedCosts: { orderBy: { effectiveDate: 'desc' }, take: 1 },
      },
    });

    const comparisons = formulas.map((f) => ({
      formulaId: f.id,
      name: f.name,
      targetAnimal: f.targetAnimal,
      feedType: f.feedType,
      ingredientCount: f.ingredients.length,
      latestCost: f.feedCosts[0] ? Number(f.feedCosts[0].costPerTon) : null,
      totalCost: f.feedCosts[0] ? Number(f.feedCosts[0].totalCost) : null,
      margin: f.feedCosts[0] ? Number(f.feedCosts[0].margin) : null,
      effectiveDate: f.feedCosts[0]?.effectiveDate || null,
      proteinTotal: f.ingredients.reduce(
        (sum: number, i: FeedFormulaIngredient) => sum + Number(i.proteinPercent || 0),
        0,
      ),
    }));

    // Sort by cost per ton ascending
    comparisons.sort((a, b) => (a.latestCost || Infinity) - (b.latestCost || Infinity));

    return { data: comparisons };
  }

  // ═══════════════════════════════════════════════════════════
  // 9. PRODUCTION SCHEDULE OPTIMIZATION
  // ═══════════════════════════════════════════════════════════

  /**
   * Optimize production schedule by assigning pending orders to available warehouses.
   * Priority: urgent orders -> due date -> FIFO.
   */
  async optimizeSchedule(
    companyId: string,
    warehouseId?: string,
  ): Promise<{
    schedule: ProductionScheduleItem[];
    warehouseUtilization: Array<{
      warehouseId: string;
      warehouseName: string;
      assignedOrders: number;
      totalPlannedMinutes: number;
      utilizationPercent: number;
    }>;
  }> {
    // Get all pending production orders (CONVERSION with DRAFT or SCHEDULED status)
    const allMovements = await this.prisma.stockMovement.findMany({
      where: {
        type: 'CONVERSION' as MovementType,
        product: { companyId },
      },
      include: {
        product: { select: { name: true } },
        warehouse: { select: { id: true, name: true } },
      },
      orderBy: [{ createdAt: 'asc' }],
    });

    // Filter to pending orders
    const pendingMovements = allMovements.filter((m) => {
      const parsed = this.parseNotesJson(m.notes);
      const status = (parsed.status as string) || 'DRAFT';
      return status === 'DRAFT' || status === 'SCHEDULED';
    });

    // Get all available warehouses
    const whereWarehouses: Prisma.WarehouseWhereInput = {
      branch: { companyId },
      status: 'ACTIVE',
    };
    if (warehouseId) whereWarehouses.id = warehouseId;

    const warehouses = await this.prisma.warehouse.findMany({
      where: whereWarehouses,
      orderBy: { createdAt: 'asc' },
    });

    if (warehouses.length === 0) {
      this.logger.warn('No active warehouses found for scheduling');
      return {
        schedule: pendingMovements.map((o) => {
          const parsed = this.parseNotesJson(o.notes);
          return {
            orderId: o.id,
            orderNumber: o.movementNumber,
            priority: 0,
            productName: o.product?.name || 'Unknown',
            plannedQty: Number(o.quantity),
            dueDate: parsed.plannedDate ? new Date(parsed.plannedDate as string) : null,
            assignedWarehouseId: null,
            assignedWarehouseName: null,
            estimatedStart: null,
            estimatedCompletion: null,
            status: 'NO_WAREHOUSE_AVAILABLE',
          };
        }),
        warehouseUtilization: [],
      };
    }

    // Calculate priority score for each order
    const now = new Date();
    const scoredOrders = pendingMovements.map((movement) => {
      const parsed = this.parseNotesJson(movement.notes);
      let priorityScore = 0;

      // Urgency based on due date proximity
      const plannedDate = parsed.plannedDate
        ? new Date(parsed.plannedDate as string)
        : null;
      if (plannedDate) {
        const hoursUntilDue = (plannedDate.getTime() - now.getTime()) / (1000 * 60 * 60);
        if (hoursUntilDue < 24) priorityScore += 1000; // due within 24h
        else if (hoursUntilDue < 72) priorityScore += 500;
        else if (hoursUntilDue < 168) priorityScore += 200;
      }

      // FIFO bonus (older orders get higher priority)
      const ageHours =
        (now.getTime() - new Date(movement.createdAt).getTime()) / (1000 * 60 * 60);
      priorityScore += Math.min(ageHours, 720); // cap at 30 days

      // Urgent flag
      if (parsed.isUrgent) priorityScore += 2000;

      return { movement, priorityScore };
    });

    // Sort by priority (highest first)
    scoredOrders.sort((a, b) => b.priorityScore - a.priorityScore);

    // Track warehouse availability (simple approach: assume 8-hour shifts)
    const warehouseSchedule = new Map<
      string,
      { nextAvailable: Date; assignedMinutes: number; orderCount: number }
    >();
    for (const wh of warehouses) {
      warehouseSchedule.set(wh.id, {
        nextAvailable: now,
        assignedMinutes: 0,
        orderCount: 0,
      });
    }

    const schedule: ProductionScheduleItem[] = [];
    const SHIFT_MINUTES = 8 * 60; // 8 hours

    for (const { movement, priorityScore } of scoredOrders) {
      // Find the best warehouse (earliest available)
      let bestWarehouseId: string | null = null;
      let bestWarehouseName: string | null = null;
      let earliestTime = new Date('2099-12-31');

      for (const wh of warehouses) {
        const slot = warehouseSchedule.get(wh.id)!;
        if (slot.nextAvailable < earliestTime) {
          earliestTime = slot.nextAvailable;
          bestWarehouseId = wh.id;
          bestWarehouseName = wh.name;
        }
      }

      if (!bestWarehouseId) {
        schedule.push({
          orderId: movement.id,
          orderNumber: movement.movementNumber,
          priority: Math.round(priorityScore),
          productName: movement.product?.name || 'Unknown',
          plannedQty: Number(movement.quantity),
          dueDate: movement.createdAt,
          assignedWarehouseId: null,
          assignedWarehouseName: null,
          estimatedStart: null,
          estimatedCompletion: null,
          status: 'NO_WAREHOUSE_AVAILABLE',
        });
        continue;
      }

      // Estimate production time (assume 1 ton per hour default)
      const qty = Number(movement.quantity);
      const capacityPerHour = 10; // default 10 units per hour
      const estimatedMinutes = Math.max(60, (qty / capacityPerHour) * 60);

      const slot = warehouseSchedule.get(bestWarehouseId)!;
      const startTime = new Date(slot.nextAvailable);
      const completionTime = new Date(startTime.getTime() + estimatedMinutes * 60000);

      // Update warehouse schedule
      slot.nextAvailable = completionTime;
      slot.assignedMinutes += estimatedMinutes;
      slot.orderCount++;

      // Check if order will be late
      let status = 'SCHEDULED';
      const parsed = this.parseNotesJson(movement.notes);
      const plannedDate = parsed.plannedDate
        ? new Date(parsed.plannedDate as string)
        : null;
      if (plannedDate && completionTime > plannedDate) {
        status = 'AT_RISK_LATE';
      }

      schedule.push({
        orderId: movement.id,
        orderNumber: movement.movementNumber,
        priority: Math.round(priorityScore),
        productName: movement.product?.name || 'Unknown',
        plannedQty: qty,
        dueDate: plannedDate,
        assignedWarehouseId: bestWarehouseId,
        assignedWarehouseName: bestWarehouseName,
        estimatedStart: startTime,
        estimatedCompletion: completionTime,
        status,
      });
    }

    // Calculate warehouse utilization
    const warehouseUtilization = warehouses.map((wh) => {
      const slot = warehouseSchedule.get(wh.id)!;
      const utilizationPercent =
        SHIFT_MINUTES > 0 ? (slot.assignedMinutes / SHIFT_MINUTES) * 100 : 0;
      return {
        warehouseId: wh.id,
        warehouseName: wh.name,
        assignedOrders: slot.orderCount,
        totalPlannedMinutes: Math.round(slot.assignedMinutes),
        utilizationPercent: Math.round(utilizationPercent * 100) / 100,
      };
    });

    this.logger.log(
      `Schedule optimized: ${schedule.length} orders assigned across ${warehouses.length} warehouses`,
    );

    return { schedule, warehouseUtilization };
  }


  // ═══════════════════════════════════════════════════════════
  // 10. DASHBOARD & REPORTING
  // ═══════════════════════════════════════════════════════════

  /**
   * Get production dashboard KPIs for a company.
   */
  async getDashboard(
    companyId: string,
    dateRange?: { start: Date; end: Date },
  ) {
    const start = dateRange?.start || getMonthStart();
    const end = dateRange?.end || new Date();

    // Get all CONVERSION movements for this company in the date range
    const allMovements = await this.prisma.stockMovement.findMany({
      where: {
        type: 'CONVERSION' as MovementType,
        product: { companyId },
        createdAt: { gte: start, lte: end },
      },
      include: {
        product: { select: { id: true, name: true } },
        warehouse: { select: { id: true, name: true } },
      },
    });

    // Categorize by status (from notes JSON)
    let completedOrders = 0;
    let inProgressOrders = 0;
    let quarantinedOrders = 0;
    let cancelledOrders = 0;
    let totalActualQty = 0;

    for (const m of allMovements) {
      const parsed = this.parseNotesJson(m.notes);
      const status = (parsed.status as string) || 'DRAFT';
      if (status === 'COMPLETED' || status === 'CLOSED') {
        completedOrders++;
        totalActualQty += Number(parsed.actualQty || m.quantity);
      } else if (status === 'IN_PROGRESS') {
        inProgressOrders++;
      } else if (status === 'QUARANTINE') {
        quarantinedOrders++;
      } else if (status === 'CANCELLED') {
        cancelledOrders++;
      }
    }

    const totalOrders = allMovements.length;

    // Count total downtime minutes from in-memory records
    let totalDowntimeMinutes = 0;
    for (const [, records] of this.downtimeRecords) {
      for (const r of records) {
        if (r.startTime >= start && r.startTime <= end) {
          totalDowntimeMinutes += r.durationMinutes;
        }
      }
    }

    // Collect recent QC checks across all orders
    const allQC: QCCheckpointRecord[] = [];
    for (const [, records] of this.qcCheckpoints) {
      for (const r of records) {
        if (r.createdAt >= start && r.createdAt <= end) {
          allQC.push(r);
        }
      }
    }
    // Sort by createdAt desc and take 10
    const recentQC = allQC
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, 10);

    const avgYield = completedOrders > 0 ? totalActualQty / completedOrders : 0;

    const qcPassRate =
      recentQC.length > 0
        ? (recentQC.filter((c) => c.status === 'PASS').length / recentQC.length) * 100
        : 0;

    // Get top produced products
    const productTotals = new Map<string, { name: string; totalQty: number; count: number }>();
    for (const m of allMovements) {
      if (!m.product) continue;
      const existing = productTotals.get(m.product.id) || {
        name: m.product.name,
        totalQty: 0,
        count: 0,
      };
      const parsed = this.parseNotesJson(m.notes);
      existing.totalQty += Number(parsed.actualQty || m.quantity);
      existing.count++;
      productTotals.set(m.product.id, existing);
    }

    const topProducts = Array.from(productTotals.entries())
      .map(([productId, data]) => ({ productId, ...data }))
      .sort((a, b) => b.totalQty - a.totalQty)
      .slice(0, 5);

    // Get feed formula stats
    const formulaCount = await this.prisma.feedFormula.count();
    const activeFormulaCount = await this.prisma.feedFormula.count({
      where: { status: 'ACTIVE' },
    });

    return {
      data: {
        period: { start, end },
        orders: {
          total: totalOrders,
          completed: completedOrders,
          inProgress: inProgressOrders,
          quarantined: quarantinedOrders,
          cancelled: cancelledOrders,
          completionRate: totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 0,
        },
        yield: {
          average: Math.round(avgYield * 100) / 100,
        },
        downtime: {
          totalMinutes: totalDowntimeMinutes,
          totalHours: Math.round((totalDowntimeMinutes / 60) * 100) / 100,
        },
        quality: {
          recentChecks: recentQC.length,
          passRate: Math.round(qcPassRate * 100) / 100,
          failRate: Math.round((100 - qcPassRate) * 100) / 100,
        },
        topProducts,
        formulas: {
          total: formulaCount,
          active: activeFormulaCount,
        },
      },
    };
  }

  /**
   * Get production report with detailed breakdown.
   */
  async getProductionReport(
    companyId: string,
    dateRange: { start: Date; end: Date },
    groupBy: 'day' | 'week' | 'month' = 'day',
  ) {
    const movements = await this.prisma.stockMovement.findMany({
      where: {
        type: 'CONVERSION' as MovementType,
        product: { companyId },
        createdAt: { gte: dateRange.start, lte: dateRange.end },
      },
      include: {
        product: { select: { id: true, name: true, code: true } },
        warehouse: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'asc' },
    });

    // Group by date bucket
    const grouped = new Map<
      string,
      {
        date: string;
        orders: number;
        completed: number;
        totalQty: number;
        actualQty: number;
        materialCost: number;
        products: Map<string, { name: string; qty: number }>;
      }
    >();

    for (const m of movements) {
      const parsed = this.parseNotesJson(m.notes);
      const date = m.createdAt;
      const bucket = this.getDateBucket(date, groupBy);

      const existing = grouped.get(bucket) || {
        date: bucket,
        orders: 0,
        completed: 0,
        totalQty: 0,
        actualQty: 0,
        materialCost: 0,
        products: new Map(),
      };

      existing.orders++;
      existing.totalQty += Number(m.quantity);
      existing.actualQty += Number(parsed.actualQty || m.quantity);

      const status = (parsed.status as string) || 'DRAFT';
      if (status === 'COMPLETED' || status === 'CLOSED') {
        existing.completed++;
      }

      // Material cost from ISSUE movements
      if (status === 'COMPLETED' || status === 'CLOSED') {
        existing.materialCost += Number(parsed.totalMaterialCost || 0);
      }

      // Product grouping
      if (m.product) {
        const prod = existing.products.get(m.product.id) || {
          name: m.product.name,
          qty: 0,
        };
        prod.qty += Number(parsed.actualQty || m.quantity);
        existing.products.set(m.product.id, prod);
      }

      grouped.set(bucket, existing);
    }

    const report = Array.from(grouped.values())
      .map((bucket) => ({
        ...bucket,
        products: Array.from(bucket.products.values()),
        yield: bucket.totalQty > 0 ? (bucket.actualQty / bucket.totalQty) * 100 : 0,
      }))
      .sort((a, b) => a.date.localeCompare(b.date));

    return {
      data: {
        summary: {
          totalOrders: movements.length,
          totalPlannedQty: movements.reduce((s, m) => s + Number(m.quantity), 0),
          totalActualQty: movements.reduce((s, m) => {
            const parsed = this.parseNotesJson(m.notes);
            return s + Number(parsed.actualQty || m.quantity);
          }, 0),
          avgYield:
            movements.length > 0
              ? movements.reduce((s, m) => {
                  const parsed = this.parseNotesJson(m.notes);
                  const qty = Number(m.quantity);
                  return qty > 0
                    ? s + (Number(parsed.actualQty || m.quantity) / qty) * 100
                    : s;
                }, 0) / movements.length
              : 0,
        },
        report,
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 11. RAW MATERIAL STOCK LEVELS & REORDER ALERTS
  // ═══════════════════════════════════════════════════════════

  /**
   * Check raw material stock levels and generate reorder alerts.
   */
  async checkMaterialStockLevels(companyId: string) {
    // Get all raw material products
    const rawMaterials = await this.prisma.product.findMany({
      where: {
        companyId,
        category: { type: 'RAW_MATERIAL' },
        deletedAt: null,
      },
      include: {
        category: { select: { name: true, type: true } },
        unit: { select: { name: true, code: true } },
      },
    });

    const alerts = [];
    for (const material of rawMaterials) {
      // Calculate net stock
      const movements = await this.prisma.stockMovement.findMany({
        where: { productId: material.id },
        select: { quantity: true, type: true },
      });
      const availableQty = movements.reduce(
        (s: number, m: { quantity: Prisma.Decimal; type: string }) => {
          const qty = Number(m.quantity);
          if (m.type === 'RECEIPT') return s + qty;
          if (m.type === 'ISSUE' || m.type === 'WASTE') return s - qty;
          return s;
        },
        0,
      );

      const reorderPoint = Number(material.reorderPoint);
      const minStockLevel = Number(material.minStockLevel);

      let alertLevel: 'CRITICAL' | 'LOW' | 'OK' = 'OK';
      if (availableQty <= minStockLevel) {
        alertLevel = 'CRITICAL';
      } else if (availableQty <= reorderPoint) {
        alertLevel = 'LOW';
      }

      if (alertLevel !== 'OK') {
        alerts.push({
          productId: material.id,
          productCode: material.code,
          productName: material.name,
          unit: material.unit?.code || 'unit',
          availableQty: Math.round(availableQty * 1000) / 1000,
          reorderPoint: Math.round(reorderPoint * 1000) / 1000,
          minStockLevel: Math.round(minStockLevel * 1000) / 1000,
          alertLevel,
          shortage: alertLevel === 'CRITICAL'
            ? Math.round((minStockLevel - availableQty) * 1000) / 1000
            : Math.round((reorderPoint - availableQty) * 1000) / 1000,
        });
      }
    }

    // Sort by alert level: CRITICAL first
    alerts.sort((a, b) => (a.alertLevel === 'CRITICAL' ? -1 : 1));

    return {
      data: {
        totalMaterials: rawMaterials.length,
        criticalCount: alerts.filter((a) => a.alertLevel === 'CRITICAL').length,
        lowCount: alerts.filter((a) => a.alertLevel === 'LOW').length,
        alerts,
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════════

  private async findProductByName(
    name: string,
    companyId: string,
  ): Promise<string | undefined> {
    const product = await this.prisma.product.findFirst({
      where: {
        companyId,
        name: { contains: name, mode: 'insensitive' },
        deletedAt: null,
      },
      select: { id: true },
    });
    return product?.id;
  }

  private getDateBucket(date: Date, groupBy: 'day' | 'week' | 'month'): string {
    const d = new Date(date);
    if (groupBy === 'day') {
      return d.toISOString().split('T')[0]; // YYYY-MM-DD
    }
    if (groupBy === 'week') {
      const year = d.getFullYear();
      const week = Math.ceil(
        ((d.getTime() - new Date(year, 0, 1).getTime()) / 86400000 + 1) / 7,
      );
      return `${year}-W${week.toString().padStart(2, '0')}`;
    }
    // month
    return `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}`;
  }
}

// ═══════════════════════════════════════════════════════════
// Utility functions
// ═══════════════════════════════════════════════════════════

function getMonthStart(): Date {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1, 0, 0, 0);
}
