import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
  Delete,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { ProductionService } from './production.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateProductionOrderDto,
  UpdateProductionStatusDto,
  ConsumeBomDto,
  QcCheckpointDto,
  DowntimeRecordDto,
  CreateFeedFormulaDto,
  CreateFeedCostDto,
  UpdateFeedFormulaDto,
  ApproveFeedFormulaDto,
} from './dto';

@ApiTags('Production')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('production')
export class ProductionController {
  constructor(private readonly productionService: ProductionService) {}

  // ─── Production Orders ─────────────────────────────────────

  @Get('orders')
  @Permissions('production:view')
  @ApiOperation({ summary: 'List production orders' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'productId', required: false })
  @ApiQuery({ name: 'warehouseId', required: false })
  @ApiResponse({ status: 200, description: 'Production orders retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAll(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
    @Query('productId') productId?: string,
    @Query('warehouseId') warehouseId?: string,
  ) {
    return this.productionService.findAll(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      status,
      productId,
      warehouseId,
    });
  }

  @Get('orders/:id')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get production order by ID' })
  @ApiResponse({ status: 200, description: 'Production order retrieved' })
  @ApiResponse({ status: 404, description: 'Production order not found' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productionService.findOne(id, companyId);
  }

  @Post('orders')
  @Permissions('production:create')
  @ApiOperation({ summary: 'Create a production order' })
  @ApiResponse({ status: 201, description: 'Production order created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async create(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateProductionOrderDto,
  ) {
    return this.productionService.create(companyId, dto);
  }

  @Put('orders/:id/status')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Update production order status' })
  @ApiResponse({ status: 200, description: 'Status updated' })
  @ApiResponse({ status: 404, description: 'Production order not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateProductionStatusDto,
  ) {
    return this.productionService.updateStatus(id, companyId, dto);
  }

  // ─── BOM Consumption ───────────────────────────────────────

  @Post('orders/:id/consume-bom')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Consume BOM (raw materials) for a production order' })
  @ApiResponse({ status: 200, description: 'BOM consumed' })
  @ApiResponse({ status: 404, description: 'Production order not found' })
  async consumeBOM(
    @Param('id', ParseUUIDPipe) productionOrderId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: ConsumeBomDto,
  ) {
    return this.productionService.consumeBOM(productionOrderId, companyId, dto);
  }

  // ─── Yield ─────────────────────────────────────────────────

  @Get('orders/:id/yield')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Calculate production yield' })
  @ApiResponse({ status: 200, description: 'Yield calculated' })
  async calculateYield(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productionService.calculateYield(id, companyId);
  }

  // ─── Cost Allocation ───────────────────────────────────────

  @Post('orders/:id/allocate-costs')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Allocate production costs' })
  @ApiResponse({ status: 200, description: 'Costs allocated' })
  async allocateCosts(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productionService.allocateCosts(id, companyId);
  }

  // ─── Quality Control ───────────────────────────────────────

  @Post('orders/:id/qc-checkpoints')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Add QC checkpoint to a production order' })
  @ApiResponse({ status: 201, description: 'QC checkpoint added' })
  @ApiResponse({ status: 404, description: 'Production order not found' })
  async addQCCheckpoint(
    @Param('id', ParseUUIDPipe) productionOrderId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: QcCheckpointDto,
  ) {
    return this.productionService.addQCCheckpoint(productionOrderId, companyId, dto);
  }

  @Get('orders/:id/qc-checkpoints')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get QC checkpoints for a production order' })
  @ApiResponse({ status: 200, description: 'QC checkpoints retrieved' })
  async getQCCheckpoints(
    @Param('id', ParseUUIDPipe) productionOrderId: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productionService.getQCCheckpoints(productionOrderId, companyId);
  }

  // ─── Downtime ──────────────────────────────────────────────

  @Post('warehouses/:id/downtime')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Record a downtime event' })
  @ApiResponse({ status: 201, description: 'Downtime recorded' })
  @ApiResponse({ status: 404, description: 'Warehouse not found' })
  async recordDowntime(
    @Param('id', ParseUUIDPipe) warehouseId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: DowntimeRecordDto,
  ) {
    return this.productionService.recordDowntime(warehouseId, companyId, dto);
  }

  @Get('warehouses/:id/downtime-summary')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get downtime summary for a warehouse' })
  @ApiQuery({ name: 'startDate', required: true })
  @ApiQuery({ name: 'endDate', required: true })
  @ApiResponse({ status: 200, description: 'Downtime summary retrieved' })
  async getDowntimeSummary(
    @Param('id', ParseUUIDPipe) warehouseId: string,
    @CurrentUser('companyId') companyId: string,
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    return this.productionService.getDowntimeSummary(
      warehouseId,
      companyId,
      new Date(startDate),
      new Date(endDate),
    );
  }

  // ─── OEE ───────────────────────────────────────────────────

  @Get('warehouses/:id/oee')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Calculate OEE for a warehouse' })
  @ApiQuery({ name: 'startDate', required: true })
  @ApiQuery({ name: 'endDate', required: true })
  @ApiResponse({ status: 200, description: 'OEE calculated' })
  async calculateOEE(
    @Param('id', ParseUUIDPipe) warehouseId: string,
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productionService.calculateOEE(
      warehouseId,
      new Date(startDate),
      new Date(endDate),
      companyId,
    );
  }

  // ─── Production Schedule ───────────────────────────────────

  @Get('schedule/optimize')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Optimize production schedule' })
  @ApiQuery({ name: 'warehouseId', required: false })
  @ApiResponse({ status: 200, description: 'Schedule optimized' })
  async optimizeSchedule(
    @CurrentUser('companyId') companyId: string,
    @Query('warehouseId') warehouseId?: string,
  ) {
    return this.productionService.optimizeSchedule(companyId, warehouseId);
  }

  // ─── Feed Formulas ─────────────────────────────────────────

  @Get('feed-formulas')
  @Permissions('production:view')
  @ApiOperation({ summary: 'List feed formulas' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'targetAnimal', required: false })
  @ApiQuery({ name: 'feedType', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiResponse({ status: 200, description: 'Feed formulas retrieved' })
  async findAllFormulas(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
    @Query('targetAnimal') targetAnimal?: string,
    @Query('feedType') feedType?: string,
    @Query('search') search?: string,
  ) {
    return this.productionService.findAllFormulas({
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      status: status as 'DRAFT' | 'ACTIVE' | 'ARCHIVED' | undefined,
      targetAnimal: targetAnimal as 'CATTLE' | 'BUFFALO' | 'SHEEP' | 'GOAT' | 'CAMEL' | undefined,
      feedType,
      search,
    });
  }

  @Get('feed-formulas/:id')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get feed formula by ID' })
  @ApiResponse({ status: 200, description: 'Feed formula retrieved' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async findFormulaById(@Param('id', ParseUUIDPipe) id: string) {
    return this.productionService.findFormulaById(id);
  }

  @Post('feed-formulas')
  @Permissions('production:create')
  @ApiOperation({ summary: 'Create a feed formula' })
  @ApiResponse({ status: 201, description: 'Feed formula created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createFormula(@Body() dto: CreateFeedFormulaDto) {
    return this.productionService.createFormula(dto);
  }

  @Put('feed-formulas/:id')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Update a feed formula' })
  @ApiResponse({ status: 200, description: 'Feed formula updated' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async updateFormula(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateFeedFormulaDto,
  ) {
    return this.productionService.updateFormula(id, dto);
  }

  @Put('feed-formulas/:id/approve')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Approve a feed formula' })
  @ApiResponse({ status: 200, description: 'Feed formula approved' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async approveFormula(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: ApproveFeedFormulaDto,
  ) {
    return this.productionService.approveFormula(id, dto);
  }

  @Delete('feed-formulas/:id')
  @Permissions('production:delete')
  @ApiOperation({ summary: 'Archive a feed formula' })
  @ApiResponse({ status: 200, description: 'Feed formula archived' })
  @ApiResponse({ status: 404, description: 'Feed formula not found' })
  async deleteFormula(@Param('id', ParseUUIDPipe) id: string) {
    return this.productionService.deleteFormula(id);
  }

  // ─── Feed Costs ────────────────────────────────────────────

  @Post('feed-costs')
  @Permissions('production:create')
  @ApiOperation({ summary: 'Record feed production cost' })
  @ApiResponse({ status: 201, description: 'Feed cost recorded' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createFeedCost(@Body() dto: CreateFeedCostDto) {
    return this.productionService.createFeedCost(dto);
  }

  @Get('feed-formulas/:id/cost-history')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get cost history for a feed formula' })
  @ApiResponse({ status: 200, description: 'Cost history retrieved' })
  async getFormulaCostHistory(@Param('id', ParseUUIDPipe) formulaId: string) {
    return this.productionService.getFormulaCostHistory(formulaId);
  }

  @Post('feed-formulas/compare-costs')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Compare costs across formulas' })
  @ApiResponse({ status: 200, description: 'Cost comparison retrieved' })
  async compareFormulaCosts(@Body('formulaIds') formulaIds: string[]) {
    return this.productionService.compareFormulaCosts(formulaIds);
  }

  // ─── Dashboard & Reports ───────────────────────────────────

  @Get('dashboard')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get production dashboard KPIs' })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiResponse({ status: 200, description: 'Dashboard data retrieved' })
  async getDashboard(
    @CurrentUser('companyId') companyId: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    const dateRange =
      startDate && endDate
        ? { start: new Date(startDate), end: new Date(endDate) }
        : undefined;
    return this.productionService.getDashboard(companyId, dateRange);
  }

  @Get('report')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get detailed production report' })
  @ApiQuery({ name: 'startDate', required: true })
  @ApiQuery({ name: 'endDate', required: true })
  @ApiQuery({ name: 'groupBy', required: false, enum: ['day', 'week', 'month'] })
  @ApiResponse({ status: 200, description: 'Production report retrieved' })
  async getProductionReport(
    @CurrentUser('companyId') companyId: string,
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
    @Query('groupBy') groupBy?: 'day' | 'week' | 'month',
  ) {
    return this.productionService.getProductionReport(companyId, {
      start: new Date(startDate),
      end: new Date(endDate),
    }, groupBy || 'day');
  }

  @Get('materials/stock-alerts')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get raw material stock level alerts' })
  @ApiResponse({ status: 200, description: 'Stock alerts retrieved' })
  async checkMaterialStockLevels(
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.productionService.checkMaterialStockLevels(companyId);
  }
}
