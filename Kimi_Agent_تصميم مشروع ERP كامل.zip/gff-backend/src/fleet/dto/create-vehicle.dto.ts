import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsNumber,
  IsEnum,
  IsDateString,
} from 'class-validator';
import { VehicleType, FuelType, VehicleStatus } from '@prisma/client';

export class CreateVehicleDto {
  @ApiProperty({ example: '32-12345' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(20)
  plateNumber: string;

  @ApiProperty({ example: 'Toyota', required: false })
  @IsOptional()
  @IsString()
  make?: string;

  @ApiProperty({ example: 'Hilux', required: false })
  @IsOptional()
  @IsString()
  model?: string;

  @ApiProperty({ example: 2023, required: false })
  @IsOptional()
  @IsNumber()
  year?: number;

  @ApiProperty({ example: 'White', required: false })
  @IsOptional()
  @IsString()
  color?: string;

  @ApiProperty({ example: 'TRUCK', enum: VehicleType })
  @IsEnum(VehicleType)
  type: VehicleType;

  @ApiProperty({ example: 2000, required: false })
  @IsOptional()
  @IsNumber()
  capacityKg?: number;

  @ApiProperty({ example: 15, required: false })
  @IsOptional()
  @IsNumber()
  capacityVolume?: number;

  @ApiProperty({ example: 'DIESEL', enum: FuelType, required: false })
  @IsOptional()
  @IsEnum(FuelType)
  fuelType?: FuelType;

  @ApiProperty({ example: 15000, required: false })
  @IsOptional()
  @IsNumber()
  currentMileage?: number;

  @ApiProperty({ example: '2023-01-01', required: false })
  @IsOptional()
  @IsDateString()
  purchaseDate?: string;

  @ApiProperty({ example: '2025-01-01', required: false })
  @IsOptional()
  @IsDateString()
  insuranceExpiry?: string;

  @ApiProperty({ example: '2025-06-01', required: false })
  @IsOptional()
  @IsDateString()
  licenseExpiry?: string;

  @ApiProperty({ example: 'GPS-DEV-001', required: false })
  @IsOptional()
  @IsString()
  gpsDeviceId?: string;

  @ApiProperty({ example: 'Fleet vehicle', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class CreateDriverDto {
  @ApiProperty({ example: 'DL-123456' })
  @IsString()
  @IsNotEmpty()
  licenseNumber: string;

  @ApiProperty({ example: 'Heavy Vehicle', required: false })
  @IsOptional()
  @IsString()
  licenseType?: string;

  @ApiProperty({ example: '2025-06-01', required: false })
  @IsOptional()
  @IsDateString()
  licenseExpiry?: string;

  @ApiProperty({ example: 5, required: false })
  @IsOptional()
  @IsNumber()
  experienceYears?: number;
}

export class FuelLogDto {
  @ApiProperty({ example: 'DIESEL', enum: FuelType })
  @IsEnum(FuelType)
  fuelType: FuelType;

  @ApiProperty({ example: 50 })
  @IsNumber()
  liters: number;

  @ApiProperty({ example: 0.85 })
  @IsNumber()
  pricePerLiter: number;

  @ApiProperty({ example: 15200 })
  @IsNumber()
  mileage: number;

  @ApiProperty({ example: 'Total Station - Airport Road', required: false })
  @IsOptional()
  @IsString()
  station?: string;

  @ApiProperty({ example: 'Regular fill-up', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class MaintenanceDto {
  @ApiProperty({ example: 'PREVENTIVE', enum: ['PREVENTIVE', 'CORRECTIVE', 'INSPECTION', 'TIRE_CHANGE', 'OIL_CHANGE', 'BRAKE_CHECK', 'ELECTRICAL', 'OTHER'] })
  @IsString()
  @IsNotEmpty()
  type: string;

  @ApiProperty({ example: 'Regular oil change and filter replacement' })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({ example: 150, required: false })
  @IsOptional()
  @IsNumber()
  cost?: number;

  @ApiProperty({ example: 15000, required: false })
  @IsOptional()
  @IsNumber()
  mileage?: number;

  @ApiProperty({ example: '2024-02-01', required: false })
  @IsOptional()
  @IsDateString()
  scheduledDate?: string;

  @ApiProperty({ example: '2024-03-01', required: false })
  @IsOptional()
  @IsDateString()
  nextDueDate?: string;

  @ApiProperty({ example: 20000, required: false })
  @IsOptional()
  @IsNumber()
  nextDueMileage?: number;

  @ApiProperty({ example: 'Quick Service Garage', required: false })
  @IsOptional()
  @IsString()
  performedBy?: string;

  @ApiProperty({ example: 'Use synthetic oil', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}
