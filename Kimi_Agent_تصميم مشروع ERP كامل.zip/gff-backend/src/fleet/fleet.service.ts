import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import { CreateVehicleDto, CreateDriverDto, FuelLogDto, MaintenanceDto } from './dto';

@Injectable()
export class FleetService {
  private readonly logger = new Logger(FleetService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ========== VEHICLES ==========

  async findAllVehicles(companyId: string, options: { page?: number; limit?: number; search?: string; status?: string }) {
    const { page = 1, limit = 10, search, status } = options;
    const skip = (page - 1) * limit;

    const where: any = { companyId, deletedAt: null };
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { plateNumber: { contains: search, mode: 'insensitive' } },
        { make: { contains: search, mode: 'insensitive' } },
        { model: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.vehicle.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { fuelLogs: true, maintenanceRecords: true } },
        },
      }),
      this.prisma.vehicle.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOneVehicle(id: string, companyId: string) {
    const vehicle = await this.prisma.vehicle.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        fuelLogs: { orderBy: { date: 'desc' }, take: 10 },
        maintenanceRecords: { orderBy: { createdAt: 'desc' }, take: 10 },
      },
    });

    if (!vehicle) throw new NotFoundException(`Vehicle with ID ${id} not found`);
    return { data: vehicle };
  }

  async createVehicle(companyId: string, dto: CreateVehicleDto) {
    const existing = await this.prisma.vehicle.findUnique({
      where: { plateNumber: dto.plateNumber },
    });
    if (existing) throw new ConflictException('Plate number already exists');

    const vehicle = await this.prisma.vehicle.create({
      data: {
        ...dto,
        companyId,
        purchaseDate: dto.purchaseDate ? new Date(dto.purchaseDate) : undefined,
        insuranceExpiry: dto.insuranceExpiry ? new Date(dto.insuranceExpiry) : undefined,
        licenseExpiry: dto.licenseExpiry ? new Date(dto.licenseExpiry) : undefined,
      },
    });

    this.logger.log(`Vehicle created: ${vehicle.plateNumber}`);
    return { data: vehicle };
  }

  async updateVehicle(id: string, companyId: string, dto: Partial<CreateVehicleDto>) {
    const vehicle = await this.prisma.vehicle.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!vehicle) throw new NotFoundException(`Vehicle with ID ${id} not found`);

    const updated = await this.prisma.vehicle.update({
      where: { id },
      data: dto,
    });

    return { data: updated };
  }

  async removeVehicle(id: string, companyId: string) {
    const vehicle = await this.prisma.vehicle.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!vehicle) throw new NotFoundException(`Vehicle with ID ${id} not found`);

    await this.prisma.vehicle.update({
      where: { id },
      data: { deletedAt: new Date(), status: 'RETIRED' },
    });

    return { data: { message: 'Vehicle deleted successfully' } };
  }

  // ========== DRIVERS ==========

  async findAllDrivers(options: { page?: number; limit?: number; search?: string }) {
    const { page = 1, limit = 10, search } = options;
    const skip = (page - 1) * limit;

    const where: any = {};
    if (search) {
      where.OR = [
        { licenseNumber: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.driver.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.driver.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async createDriver(dto: CreateDriverDto) {
    const driver = await this.prisma.driver.create({
      data: {
        ...dto,
        licenseExpiry: dto.licenseExpiry ? new Date(dto.licenseExpiry) : undefined,
      },
    });

    return { data: driver };
  }

  async updateDriver(id: string, dto: Partial<CreateDriverDto>) {
    const driver = await this.prisma.driver.findUnique({ where: { id } });
    if (!driver) throw new NotFoundException(`Driver with ID ${id} not found`);

    const updated = await this.prisma.driver.update({ where: { id }, data: dto });
    return { data: updated };
  }

  // ========== FUEL LOGS ==========

  async addFuelLog(vehicleId: string, companyId: string, dto: FuelLogDto) {
    const vehicle = await this.prisma.vehicle.findFirst({
      where: { id: vehicleId, companyId },
    });
    if (!vehicle) throw new NotFoundException('Vehicle not found');

    const totalCost = dto.liters * dto.pricePerLiter;

    const fuelLog = await this.prisma.fuelLog.create({
      data: {
        vehicleId,
        fuelType: dto.fuelType,
        liters: dto.liters,
        pricePerLiter: dto.pricePerLiter,
        totalCost,
        mileage: dto.mileage,
        station: dto.station,
        notes: dto.notes,
      },
    });

    // Update vehicle mileage
    await this.prisma.vehicle.update({
      where: { id: vehicleId },
      data: { currentMileage: dto.mileage },
    });

    return { data: fuelLog };
  }

  async getFuelLogs(vehicleId: string, companyId: string) {
    const vehicle = await this.prisma.vehicle.findFirst({
      where: { id: vehicleId, companyId },
    });
    if (!vehicle) throw new NotFoundException('Vehicle not found');

    const logs = await this.prisma.fuelLog.findMany({
      where: { vehicleId },
      orderBy: { date: 'desc' },
    });

    const totalCost = logs.reduce((sum, l) => sum + Number(l.totalCost), 0);
    const totalLiters = logs.reduce((sum, l) => sum + l.liters, 0);

    return { data: { logs, totalCost, totalLiters } };
  }

  // ========== MAINTENANCE ==========

  async addMaintenance(vehicleId: string, companyId: string, dto: MaintenanceDto) {
    const vehicle = await this.prisma.vehicle.findFirst({
      where: { id: vehicleId, companyId },
    });
    if (!vehicle) throw new NotFoundException('Vehicle not found');

    const maintenance = await this.prisma.maintenanceRecord.create({
      data: {
        vehicleId,
        type: dto.type as any,
        description: dto.description,
        cost: dto.cost,
        mileage: dto.mileage,
        scheduledDate: dto.scheduledDate ? new Date(dto.scheduledDate) : undefined,
        nextDueDate: dto.nextDueDate ? new Date(dto.nextDueDate) : undefined,
        nextDueMileage: dto.nextDueMileage,
        performedBy: dto.performedBy,
        notes: dto.notes,
      },
    });

    // Update vehicle status if maintenance is in progress
    if (dto.type === 'CORRECTIVE' || dto.type === 'PREVENTIVE') {
      await this.prisma.vehicle.update({
        where: { id: vehicleId },
        data: { status: 'MAINTENANCE' },
      });
    }

    return { data: maintenance };
  }

  async getMaintenanceRecords(vehicleId: string, companyId: string) {
    const vehicle = await this.prisma.vehicle.findFirst({
      where: { id: vehicleId, companyId },
    });
    if (!vehicle) throw new NotFoundException('Vehicle not found');

    const records = await this.prisma.maintenanceRecord.findMany({
      where: { vehicleId },
      orderBy: { createdAt: 'desc' },
    });

    return { data: records };
  }

  async updateMaintenanceStatus(id: string, companyId: string, status: string) {
    const record = await this.prisma.maintenanceRecord.findFirst({
      where: { id, vehicle: { companyId } },
    });
    if (!record) throw new NotFoundException('Maintenance record not found');

    const updated = await this.prisma.maintenanceRecord.update({
      where: { id },
      data: {
        status: status as any,
        completedDate: status === 'COMPLETED' ? new Date() : undefined,
      },
    });

    // Update vehicle status if maintenance completed
    if (status === 'COMPLETED') {
      await this.prisma.vehicle.update({
        where: { id: record.vehicleId },
        data: { status: 'ACTIVE' },
      });
    }

    return { data: updated };
  }

  // ========== DASHBOARD ==========

  async getFleetStats(companyId: string) {
    const [total, active, inMaintenance, retired] = await Promise.all([
      this.prisma.vehicle.count({ where: { companyId, deletedAt: null } }),
      this.prisma.vehicle.count({ where: { companyId, deletedAt: null, status: 'ACTIVE' } }),
      this.prisma.vehicle.count({ where: { companyId, deletedAt: null, status: 'MAINTENANCE' } }),
      this.prisma.vehicle.count({ where: { companyId, deletedAt: null, status: 'RETIRED' } }),
    ]);

    return { data: { total, active, inMaintenance, retired } };
  }

  async getUpcomingMaintenance(companyId: string) {
    const upcomingDate = new Date();
    upcomingDate.setDate(upcomingDate.getDate() + 30);

    const records = await this.prisma.maintenanceRecord.findMany({
      where: {
        vehicle: { companyId },
        status: { in: ['SCHEDULED', 'OVERDUE'] },
        OR: [
          { nextDueDate: { lte: upcomingDate } },
        ],
      },
      include: {
        vehicle: { select: { id: true, plateNumber: true, make: true, model: true } },
      },
      orderBy: { nextDueDate: 'asc' },
    });

    return { data: records };
  }
}
