import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { FleetService } from './fleet.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import { CreateVehicleDto, CreateDriverDto, FuelLogDto, MaintenanceDto } from './dto';

@ApiTags('Fleet')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('fleet')
export class FleetController {
  constructor(private readonly fleetService: FleetService) {}

  // ========== VEHICLES ==========
  @Get('vehicles')
  @Permissions('fleet:view')
  @ApiOperation({ summary: 'List vehicles' })
  @ApiResponse({ status: 200, description: 'Vehicles retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllVehicles(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
    @Query('status') status?: string,
  ) {
    return this.fleetService.findAllVehicles(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      search,
      status,
    });
  }

  @Get('vehicles/:id')
  @Permissions('fleet:view')
  @ApiOperation({ summary: 'Get vehicle by ID' })
  @ApiResponse({ status: 200, description: 'Vehicle retrieved' })
  @ApiResponse({ status: 404, description: 'Vehicle not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOneVehicle(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.fleetService.findOneVehicle(id, companyId);
  }

  @Post('vehicles')
  @Permissions('fleet:create')
  @ApiOperation({ summary: 'Create vehicle' })
  @ApiResponse({ status: 201, description: 'Vehicle created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createVehicle(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateVehicleDto,
  ) {
    return this.fleetService.createVehicle(companyId, dto);
  }

  @Put('vehicles/:id')
  @Permissions('fleet:update')
  @ApiOperation({ summary: 'Update vehicle' })
  @ApiResponse({ status: 200, description: 'Vehicle updated' })
  @ApiResponse({ status: 404, description: 'Vehicle not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateVehicle(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: Partial<CreateVehicleDto>,
  ) {
    return this.fleetService.updateVehicle(id, companyId, dto);
  }

  @Delete('vehicles/:id')
  @Permissions('fleet:update')
  @ApiOperation({ summary: 'Delete vehicle' })
  @ApiResponse({ status: 200, description: 'Vehicle deleted' })
  @ApiResponse({ status: 404, description: 'Vehicle not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async removeVehicle(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.fleetService.removeVehicle(id, companyId);
  }

  // ========== DRIVERS ==========
  @Get('drivers')
  @Permissions('fleet:view')
  @ApiOperation({ summary: 'List drivers' })
  @ApiResponse({ status: 200, description: 'Drivers retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllDrivers(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
  ) {
    return this.fleetService.findAllDrivers({
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      search,
    });
  }

  @Post('drivers')
  @Permissions('fleet:create')
  @ApiOperation({ summary: 'Create driver' })
  @ApiResponse({ status: 201, description: 'Driver created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createDriver(@Body() dto: CreateDriverDto) {
    return this.fleetService.createDriver(dto);
  }

  @Put('drivers/:id')
  @Permissions('fleet:update')
  @ApiOperation({ summary: 'Update driver' })
  @ApiResponse({ status: 200, description: 'Driver updated' })
  @ApiResponse({ status: 404, description: 'Driver not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateDriver(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: Partial<CreateDriverDto>,
  ) {
    return this.fleetService.updateDriver(id, dto);
  }

  // ========== FUEL ==========
  @Get('vehicles/:id/fuel-logs')
  @Permissions('fleet:view')
  @ApiOperation({ summary: 'Get fuel logs for vehicle' })
  @ApiResponse({ status: 200, description: 'Fuel logs retrieved' })
  @ApiResponse({ status: 404, description: 'Vehicle not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getFuelLogs(
    @Param('id', ParseUUIDPipe) vehicleId: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.fleetService.getFuelLogs(vehicleId, companyId);
  }

  @Post('vehicles/:id/fuel-logs')
  @Permissions('fleet:create')
  @ApiOperation({ summary: 'Add fuel log' })
  @ApiResponse({ status: 201, description: 'Fuel log added' })
  @ApiResponse({ status: 404, description: 'Vehicle not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async addFuelLog(
    @Param('id', ParseUUIDPipe) vehicleId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: FuelLogDto,
  ) {
    return this.fleetService.addFuelLog(vehicleId, companyId, dto);
  }

  // ========== MAINTENANCE ==========
  @Get('vehicles/:id/maintenance')
  @Permissions('fleet:view')
  @ApiOperation({ summary: 'Get maintenance records' })
  @ApiResponse({ status: 200, description: 'Maintenance records retrieved' })
  @ApiResponse({ status: 404, description: 'Vehicle not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getMaintenanceRecords(
    @Param('id', ParseUUIDPipe) vehicleId: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.fleetService.getMaintenanceRecords(vehicleId, companyId);
  }

  @Post('vehicles/:id/maintenance')
  @Permissions('fleet:create')
  @ApiOperation({ summary: 'Add maintenance record' })
  @ApiResponse({ status: 201, description: 'Maintenance record added' })
  @ApiResponse({ status: 404, description: 'Vehicle not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async addMaintenance(
    @Param('id', ParseUUIDPipe) vehicleId: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: MaintenanceDto,
  ) {
    return this.fleetService.addMaintenance(vehicleId, companyId, dto);
  }

  @Put('maintenance/:id/status')
  @Permissions('fleet:update')
  @ApiOperation({ summary: 'Update maintenance status' })
  @ApiResponse({ status: 200, description: 'Maintenance status updated' })
  @ApiResponse({ status: 404, description: 'Maintenance record not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateMaintenanceStatus(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body('status') status: string,
  ) {
    return this.fleetService.updateMaintenanceStatus(id, companyId, status);
  }

  // ========== DASHBOARD ==========
  @Get('stats')
  @Permissions('fleet:view')
  @ApiOperation({ summary: 'Get fleet statistics' })
  @ApiResponse({ status: 200, description: 'Fleet stats retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getFleetStats(@CurrentUser('companyId') companyId: string) {
    return this.fleetService.getFleetStats(companyId);
  }

  @Get('upcoming-maintenance')
  @Permissions('fleet:view')
  @ApiOperation({ summary: 'Get upcoming maintenance' })
  @ApiResponse({ status: 200, description: 'Upcoming maintenance retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getUpcomingMaintenance(@CurrentUser('companyId') companyId: string) {
    return this.fleetService.getUpcomingMaintenance(companyId);
  }
}
