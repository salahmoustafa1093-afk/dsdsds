import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import { Prisma } from '@prisma/client';
import { AnimalType, AnimalStatus, FeedType, Gender } from '@prisma/client';

// ─────────────────────────────────────────────────────────────
// Types & Interfaces
// ─────────────────────────────────────────────────────────────

interface FCRResult {
  fcr: number;
  targetFcr: { min: number; max: number };
  status: 'good' | 'warning' | 'poor';
  totalFeedKg: number;
  totalWeightGainKg: number;
  daysOnFeed: number;
}

interface GrowthResult {
  adg: number; // Average Daily Gain (grams/day)
  currentWeight: number;
  initialWeight: number;
  daysOnFeed: number;
  targetWeight: number;
  estimatedDaysToTarget: number | null;
  growthCurveStatus: 'on_track' | 'below_target' | 'above_target';
  adgTrend: 'improving' | 'stable' | 'declining';
  flaggedDays: number; // consecutive days below breed standard
  weightRecords: Array<{
    date: Date;
    weight: number;
    dailyGain: number | null;
  }>;
}

interface MortalityResult {
  cumulativeMortalityPercent: number;
  dailyMortalityRate: number;
  status: 'good' | 'warning' | 'critical';
  trend: 'increasing' | 'stable' | 'decreasing';
  totalDeaths: number;
  initialQuantity: number;
  currentQuantity: number;
  causes: Array<{ cause: string; count: number; percent: number }>;
  targetMaxPercent: number;
}

interface VaccinationDue {
  vaccineName: string;
  dueDate: Date;
  daysUntilDue: number;
  status: 'overdue' | 'due_soon' | 'upcoming';
  lastAdministered: Date | null;
}

interface BatchAnalytics {
  batchId: string;
  batchNumber: string;
  species: string;
  growth: {
    adg: number;
    currentWeight: number;
    weightGainPercent: number;
  };
  fcr: FCRResult | null;
  mortality: MortalityResult | null;
  feedCostPerKgGain: number | null;
  vaccinationStatus: {
    totalScheduled: number;
    completed: number;
    overdue: number;
    compliance: number;
  };
  profitability: {
    totalFeedCost: number;
    estimatedRevenue: number | null;
    estimatedProfit: number | null;
  } | null;
  benchmarks: {
    adgBenchmark: number;
    fcrBenchmark: { min: number; max: number };
    mortalityBenchmark: number;
  };
}

interface BreedingRecord {
  id: string;
  sireTag: string;
  damTag: string;
  breedingDate: Date;
  expectedDeliveryDate: Date | null;
  method: 'AI' | 'natural';
  status: 'pending' | 'confirmed' | 'failed';
  notes: string | null;
  createdAt: Date;
}

interface OffspringRecord {
  id: string;
  motherId: string;
  birthDate: Date;
  quantity: number;
  males: number;
  females: number;
  totalBirthWeight: number;
  status: 'healthy' | 'complications' | 'deceased';
  notes: string | null;
}

interface PenAssignment {
  penNumber: string;
  animalCount: number;
  density: number; // animals per sqm
  densityLimit: number;
  status: 'optimal' | 'overcrowded' | 'underutilized';
  species: string;
}

// ─────────────────────────────────────────────────────────────
// Species Benchmarks
// ─────────────────────────────────────────────────────────────

const SPECIES_BENCHMARKS: Record<
  string,
  {
    targetFcr: { min: number; max: number };
    targetAdg: number; // grams per day
    maxMortalityPercent: number;
    targetWeight: number; // kg at market
    densityLimitPerSqm: number;
  }
> = {
  BROILER: {
    targetFcr: { min: 1.6, max: 1.8 },
    targetAdg: 55,
    maxMortalityPercent: 5,
    targetWeight: 2.5,
    densityLimitPerSqm: 15,
  },
  CATTLE: {
    targetFcr: { min: 6.0, max: 8.0 },
    targetAdg: 1200,
    maxMortalityPercent: 3,
    targetWeight: 500,
    densityLimitPerSqm: 5,
  },
  SHEEP: {
    targetFcr: { min: 4.0, max: 6.0 },
    targetAdg: 250,
    maxMortalityPercent: 4,
    targetWeight: 45,
    densityLimitPerSqm: 8,
  },
  GOAT: {
    targetFcr: { min: 4.0, max: 7.0 },
    targetAdg: 120,
    maxMortalityPercent: 4,
    targetWeight: 35,
    densityLimitPerSqm: 8,
  },
  BUFFALO: {
    targetFcr: { min: 7.0, max: 10.0 },
    targetAdg: 800,
    maxMortalityPercent: 3,
    targetWeight: 450,
    densityLimitPerSqm: 4,
  },
  CAMEL: {
    targetFcr: { min: 5.0, max: 8.0 },
    targetAdg: 700,
    maxMortalityPercent: 2,
    targetWeight: 400,
    densityLimitPerSqm: 2,
  },
};

const DEFAULT_BENCHMARKS = {
  targetFcr: { min: 4.0, max: 8.0 },
  targetAdg: 200,
  maxMortalityPercent: 5,
  targetWeight: 50,
  densityLimitPerSqm: 5,
};

function getBenchmarks(species: string) {
  return SPECIES_BENCHMARKS[species?.toUpperCase()] || DEFAULT_BENCHMARKS;
}

// ─────────────────────────────────────────────────────────────
// Service
// ─────────────────────────────────────────────────────────────

@Injectable()
export class LivestockService {
  private readonly logger = new Logger(LivestockService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════════════════════
  // 1. FEED CONVERSION RATIO (FCR) CALCULATOR
  // ═══════════════════════════════════════════════════════════

  /**
   * Calculate Feed Conversion Ratio for a poultry batch.
   * FCR = totalFeedConsumed(kg) / totalWeightGain(kg)
   */
  async calculateFCR(batchId: string, companyId: string): Promise<FCRResult> {
    const batch = await this.prisma.poultryBatch.findFirst({
      where: { id: batchId, branch: { companyId } },
      include: {
        supplier: true,
      },
    });
    if (!batch) throw new NotFoundException('Poultry batch not found');

    // Get all animals in this batch's branch that arrived around the same time
    const animals = await this.prisma.animal.findMany({
      where: {
        branchId: batch.branchId,
        type: AnimalType.CATTLE, // Adjust based on species mapping
        createdAt: { gte: new Date(batch.arrivalDate.getTime() - 86400000) },
      },
      include: {
        feedRecords: true,
        weightRecords: { orderBy: { date: 'asc' } },
      },
    });

    // Sum all feed consumed by animals in this batch
    let totalFeedKg = 0;
    for (const animal of animals) {
      for (const feed of animal.feedRecords) {
        totalFeedKg += Number(feed.quantity);
      }
    }

    // If no animal-level feed records, fall back to poultry mortality records for count
    if (totalFeedKg === 0) {
      // Estimate feed based on standard industry values
      // This is a fallback when detailed feed records aren't available
      const daysOnFeed = Math.max(
        1,
        Math.floor(
          (Date.now() - batch.arrivalDate.getTime()) / 86400000,
        ),
      );
      const estimatedDailyFeedPerBird = 0.08; // ~80g per bird per day average
      totalFeedKg =
        batch.currentCount * estimatedDailyFeedPerBird * daysOnFeed;
    }

    // Calculate total weight gain
    let totalWeightGainKg = 0;
    let totalInitialWeightKg = 0;
    let totalCurrentWeightKg = 0;

    for (const animal of animals) {
      const initialWeight =
        animal.weightRecords.length > 0
          ? Number(animal.weightRecords[0].weight)
          : Number(animal.currentWeight) * 0.4; // estimate if no records
      const currentWeight =
        animal.weightRecords.length > 0
          ? Number(animal.weightRecords[animal.weightRecords.length - 1].weight)
          : Number(animal.currentWeight);

      totalInitialWeightKg += initialWeight;
      totalCurrentWeightKg += currentWeight;
    }

    totalWeightGainKg = totalCurrentWeightKg - totalInitialWeightKg;

    // If no weight records, use poultry batch as proxy
    if (totalWeightGainKg <= 0 && animals.length === 0) {
      // Estimate: broilers gain ~40g/day on average
      const daysOnFeed = Math.max(
        1,
        Math.floor(
          (Date.now() - batch.arrivalDate.getTime()) / 86400000,
        ),
      );
      totalWeightGainKg = batch.currentCount * 0.04 * daysOnFeed;
    }

    const daysOnFeed = Math.max(
      1,
      Math.floor(
        (Date.now() - batch.arrivalDate.getTime()) / 86400000,
      ),
    );

    const fcr =
      totalWeightGainKg > 0 ? totalFeedKg / totalWeightGainKg : 0;

    const speciesKey = this.mapBreedToSpecies(batch.breed);
    const benchmark = getBenchmarks(speciesKey);
    const targetFcr = benchmark.targetFcr;

    let status: 'good' | 'warning' | 'poor';
    if (fcr <= targetFcr.max * 1.05) {
      status = 'good';
    } else if (fcr <= targetFcr.max * 1.2) {
      status = 'warning';
    } else {
      status = 'poor';
    }

    this.logger.log(
      `FCR calculated for batch ${batch.batchNumber}: ${fcr.toFixed(2)} (${status})`,
    );

    return {
      fcr: Math.round(fcr * 100) / 100,
      targetFcr,
      status,
      totalFeedKg: Math.round(totalFeedKg * 100) / 100,
      totalWeightGainKg: Math.round(totalWeightGainKg * 100) / 100,
      daysOnFeed,
    };
  }

  /**
   * Calculate FCR for an individual animal
   */
  async calculateAnimalFCR(
    animalId: string,
    companyId: string,
  ): Promise<FCRResult> {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
      include: {
        feedRecords: true,
        weightRecords: { orderBy: { date: 'asc' } },
      },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const totalFeedKg = animal.feedRecords.reduce(
      (sum, f) => sum + Number(f.quantity),
      0,
    );

    const initialWeight =
      animal.weightRecords.length > 0
        ? Number(animal.weightRecords[0].weight)
        : Number(animal.currentWeight) * 0.5;
    const currentWeight =
      animal.weightRecords.length > 0
        ? Number(animal.weightRecords[animal.weightRecords.length - 1].weight)
        : Number(animal.currentWeight);

    const totalWeightGainKg = currentWeight - initialWeight;

    const daysOnFeed = animal.purchaseDate
      ? Math.max(
          1,
          Math.floor(
            (Date.now() - animal.purchaseDate.getTime()) / 86400000,
          ),
        )
      : animal.birthDate
        ? Math.max(
            1,
            Math.floor(
              (Date.now() - animal.birthDate.getTime()) / 86400000,
            ),
          )
        : 1;

    const fcr =
      totalWeightGainKg > 0 ? totalFeedKg / totalWeightGainKg : 0;

    const benchmark = getBenchmarks(animal.type);
    const targetFcr = benchmark.targetFcr;

    let status: 'good' | 'warning' | 'poor';
    if (fcr <= targetFcr.max * 1.05) {
      status = 'good';
    } else if (fcr <= targetFcr.max * 1.2) {
      status = 'warning';
    } else {
      status = 'poor';
    }

    return {
      fcr: Math.round(fcr * 100) / 100,
      targetFcr,
      status,
      totalFeedKg: Math.round(totalFeedKg * 100) / 100,
      totalWeightGainKg: Math.round(totalWeightGainKg * 100) / 100,
      daysOnFeed,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 2. GROWTH TRACKING & PROJECTION
  // ═══════════════════════════════════════════════════════════

  /**
   * Track growth for an individual animal with ADG calculation
   * and projection to target weight.
   */
  async trackGrowth(
    animalId: string,
    companyId: string,
  ): Promise<GrowthResult> {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
      include: {
        weightRecords: { orderBy: { date: 'asc' } },
      },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const benchmark = getBenchmarks(animal.type);
    const targetWeight = benchmark.targetWeight;

    const weightRecords = animal.weightRecords;
    const currentWeight =
      weightRecords.length > 0
        ? Number(weightRecords[weightRecords.length - 1].weight)
        : Number(animal.currentWeight);

    const initialWeight =
      weightRecords.length > 0
        ? Number(weightRecords[0].weight)
        : currentWeight * 0.5;

    const startDate =
      weightRecords.length > 0
        ? weightRecords[0].date
        : animal.purchaseDate || animal.birthDate || new Date();

    const daysOnFeed = Math.max(
      1,
      Math.floor((Date.now() - startDate.getTime()) / 86400000),
    );

    const adg =
      weightRecords.length >= 2
        ? (currentWeight - initialWeight) * 1000 / daysOnFeed // convert kg to grams for ADG
        : 0;

    // Calculate estimated days to target
    const remainingGain = targetWeight - currentWeight;
    const estimatedDaysToTarget =
      adg > 0 ? Math.ceil((remainingGain * 1000) / adg) : null;

    // Determine growth curve status
    const expectedWeightToday =
      initialWeight + (benchmark.targetAdg / 1000) * daysOnFeed;
    let growthCurveStatus: 'on_track' | 'below_target' | 'above_target';
    if (currentWeight >= expectedWeightToday * 0.95) {
      growthCurveStatus = 'on_track';
    } else if (currentWeight >= expectedWeightToday * 0.85) {
      growthCurveStatus = 'below_target';
    } else {
      growthCurveStatus = 'above_target';
    }

    // Calculate ADG trend (last 7 days vs previous 7 days)
    let adgTrend: 'improving' | 'stable' | 'declining' = 'stable';
    if (weightRecords.length >= 14) {
      const recent7 = weightRecords.slice(-7);
      const previous7 = weightRecords.slice(-14, -7);
      const recentGain =
        Number(recent7[recent7.length - 1].weight) - Number(recent7[0].weight);
      const previousGain =
        Number(previous7[previous7.length - 1].weight) -
        Number(previous7[0].weight);
      if (recentGain > previousGain * 1.1) {
        adgTrend = 'improving';
      } else if (recentGain < previousGain * 0.9) {
        adgTrend = 'declining';
      }
    }

    // Flag consecutive days below breed standard
    let flaggedDays = 0;
    if (weightRecords.length >= 2) {
      for (let i = weightRecords.length - 1; i > 0; i--) {
        const dayGain =
          Number(weightRecords[i].weight) - Number(weightRecords[i - 1].weight);
        if (dayGain * 1000 < benchmark.targetAdg) {
          flaggedDays++;
        } else {
          break;
        }
      }
    }

    const formattedRecords = weightRecords.map((wr, idx) => ({
      date: wr.date,
      weight: Number(wr.weight),
      dailyGain:
        idx > 0
          ? Number(wr.weight) - Number(weightRecords[idx - 1].weight)
          : null,
    }));

    return {
      adg: Math.round(adg * 100) / 100,
      currentWeight: Math.round(currentWeight * 100) / 100,
      initialWeight: Math.round(initialWeight * 100) / 100,
      daysOnFeed,
      targetWeight,
      estimatedDaysToTarget,
      growthCurveStatus,
      adgTrend,
      flaggedDays,
      weightRecords: formattedRecords,
    };
  }

  /**
   * Track growth for an entire poultry batch
   */
  async trackBatchGrowth(
    batchId: string,
    companyId: string,
  ): Promise<GrowthResult> {
    const batch = await this.prisma.poultryBatch.findFirst({
      where: { id: batchId, branch: { companyId } },
      include: {
        mortalityRecords: { orderBy: { date: 'asc' } },
      },
    });
    if (!batch) throw new NotFoundException('Poultry batch not found');

    const benchmark = getBenchmarks('BROILER');
    const targetWeight = benchmark.targetWeight;

    // Use batch-level tracking since poultry is managed as a flock
    const daysOnFeed = Math.max(
      1,
      Math.floor((Date.now() - batch.arrivalDate.getTime()) / 86400000),
    );

    // Estimate current average weight based on age
    // Broilers typically reach 2.0-2.5 kg in 35-42 days
    const estimatedCurrentWeight = Math.min(
      targetWeight,
      0.04 * daysOnFeed, // ~40g/day gain
    );

    const initialWeight = 0.04; // day-old chick ~40g
    const currentWeight = estimatedCurrentWeight;
    const adg =
      ((currentWeight - initialWeight) * 1000) / Math.max(1, daysOnFeed);

    const remainingGain = targetWeight - currentWeight;
    const estimatedDaysToTarget =
      adg > 0 ? Math.ceil((remainingGain * 1000) / adg) : null;

    const expectedWeightToday =
      initialWeight + (benchmark.targetAdg / 1000) * daysOnFeed;
    let growthCurveStatus: 'on_track' | 'below_target' | 'above_target';
    if (currentWeight >= expectedWeightToday * 0.95) {
      growthCurveStatus = 'on_track';
    } else if (currentWeight >= expectedWeightToday * 0.85) {
      growthCurveStatus = 'below_target';
    } else {
      growthCurveStatus = 'above_target';
    }

    return {
      adg: Math.round(adg * 100) / 100,
      currentWeight: Math.round(currentWeight * 100) / 100,
      initialWeight: Math.round(initialWeight * 100) / 100,
      daysOnFeed,
      targetWeight,
      estimatedDaysToTarget,
      growthCurveStatus,
      adgTrend: 'stable',
      flaggedDays: 0,
      weightRecords: [],
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 3. MORTALITY ANALYSIS
  // ═══════════════════════════════════════════════════════════

  /**
   * Analyze mortality for a poultry batch
   */
  async analyzeMortality(
    batchId: string,
    companyId: string,
  ): Promise<MortalityResult> {
    const batch = await this.prisma.poultryBatch.findFirst({
      where: { id: batchId, branch: { companyId } },
      include: {
        mortalityRecords: { orderBy: { date: 'asc' } },
      },
    });
    if (!batch) throw new NotFoundException('Poultry batch not found');

    const initialQuantity = batch.quantity;
    const mortalityRecords = batch.mortalityRecords;

    const totalDeaths = mortalityRecords.reduce(
      (sum, mr) => sum + mr.count,
      0,
    );
    const currentQuantity = batch.currentCount;

    const cumulativeMortalityPercent =
      initialQuantity > 0 ? (totalDeaths / initialQuantity) * 100 : 0;

    const daysOnFeed = Math.max(
      1,
      Math.floor(
        (Date.now() - batch.arrivalDate.getTime()) / 86400000,
      ),
    );

    const dailyMortalityRate = totalDeaths / daysOnFeed;

    const benchmark = getBenchmarks('BROILER');
    const targetMaxPercent = benchmark.maxMortalityPercent;

    let status: 'good' | 'warning' | 'critical';
    if (cumulativeMortalityPercent <= targetMaxPercent * 0.6) {
      status = 'good';
    } else if (cumulativeMortalityPercent <= targetMaxPercent) {
      status = 'warning';
    } else {
      status = 'critical';
    }

    // Calculate trend: compare first half to second half
    let trend: 'increasing' | 'stable' | 'decreasing' = 'stable';
    if (mortalityRecords.length >= 4) {
      const mid = Math.floor(mortalityRecords.length / 2);
      const firstHalf = mortalityRecords.slice(0, mid);
      const secondHalf = mortalityRecords.slice(mid);
      const firstDeaths = firstHalf.reduce((s, mr) => s + mr.count, 0);
      const secondDeaths = secondHalf.reduce((s, mr) => s + mr.count, 0);
      if (secondDeaths > firstDeaths * 1.2) {
        trend = 'increasing';
      } else if (secondDeaths < firstDeaths * 0.8) {
        trend = 'decreasing';
      }
    }

    // Cause breakdown
    const causeMap: Record<string, number> = {};
    mortalityRecords.forEach((mr) => {
      const cause = mr.cause || 'Unknown';
      causeMap[cause] = (causeMap[cause] || 0) + mr.count;
    });
    const causes = Object.entries(causeMap)
      .map(([cause, count]) => ({
        cause,
        count,
        percent: totalDeaths > 0 ? Math.round((count / totalDeaths) * 10000) / 100 : 0,
      }))
      .sort((a, b) => b.count - a.count);

    return {
      cumulativeMortalityPercent:
        Math.round(cumulativeMortalityPercent * 100) / 100,
      dailyMortalityRate: Math.round(dailyMortalityRate * 100) / 100,
      status,
      trend,
      totalDeaths,
      initialQuantity,
      currentQuantity,
      causes,
      targetMaxPercent,
    };
  }

  /**
   * Analyze mortality for an individual animal's cohort (same pen/type)
   */
  async analyzeAnimalCohortMortality(
    animalId: string,
    companyId: string,
  ): Promise<MortalityResult> {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    // Count all animals of same type in the same pen
    const cohort = await this.prisma.animal.findMany({
      where: {
        branchId: animal.branchId,
        type: animal.type,
        penNumber: animal.penNumber,
      },
    });

    const initialQuantity = cohort.length;
    const deceasedCount = cohort.filter(
      (a) => a.status === AnimalStatus.DECEASED,
    ).length;
    const currentQuantity = cohort.filter(
      (a) => a.status === AnimalStatus.ACTIVE || a.status === AnimalStatus.GROWING,
    ).length;

    const cumulativeMortalityPercent =
      initialQuantity > 0 ? (deceasedCount / initialQuantity) * 100 : 0;

    const daysOnFeed = animal.purchaseDate
      ? Math.floor((Date.now() - animal.purchaseDate.getTime()) / 86400000)
      : 30;

    const dailyMortalityRate = deceasedCount / Math.max(1, daysOnFeed);

    const benchmark = getBenchmarks(animal.type);
    const targetMaxPercent = benchmark.maxMortalityPercent;

    let status: 'good' | 'warning' | 'critical';
    if (cumulativeMortalityPercent <= targetMaxPercent * 0.6) {
      status = 'good';
    } else if (cumulativeMortalityPercent <= targetMaxPercent) {
      status = 'warning';
    } else {
      status = 'critical';
    }

    return {
      cumulativeMortalityPercent:
        Math.round(cumulativeMortalityPercent * 100) / 100,
      dailyMortalityRate: Math.round(dailyMortalityRate * 100) / 100,
      status,
      trend: 'stable',
      totalDeaths: deceasedCount,
      initialQuantity,
      currentQuantity,
      causes: [{ cause: 'No detailed records', count: deceasedCount, percent: 100 }],
      targetMaxPercent,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 4. VACCINATION SCHEDULER
  // ═══════════════════════════════════════════════════════════

  /**
   * Get upcoming vaccinations for a poultry batch
   */
  async getUpcomingVaccinations(
    batchId: string,
    companyId: string,
    daysAhead = 7,
  ): Promise<VaccinationDue[]> {
    const batch = await this.prisma.poultryBatch.findFirst({
      where: { id: batchId, branch: { companyId } },
      include: {
        vaccinationRecords: { orderBy: { date: 'desc' } },
      },
    });
    if (!batch) throw new NotFoundException('Poultry batch not found');

    const results: VaccinationDue[] = [];
    const now = new Date();
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() + daysAhead);

    // Standard poultry vaccination schedule
    const standardSchedule = this.getStandardVaccinationSchedule(batch.breed);

    for (const scheduled of standardSchedule) {
      // Check if this vaccine has been administered
      const administered = batch.vaccinationRecords.filter(
        (vr) =>
          vr.vaccineName.toLowerCase() === scheduled.vaccineName.toLowerCase(),
      );

      const lastAdministered =
        administered.length > 0 ? administered[0].date : null;

      // Calculate due date from batch arrival
      const dueDate = new Date(batch.arrivalDate);
      dueDate.setDate(dueDate.getDate() + scheduled.day);

      const daysUntilDue = Math.floor(
        (dueDate.getTime() - now.getTime()) / 86400000,
      );

      // Only include if due within window or overdue
      if (dueDate <= cutoff || daysUntilDue < 0) {
        let status: 'overdue' | 'due_soon' | 'upcoming';
        if (daysUntilDue < 0) {
          status = 'overdue';
        } else if (daysUntilDue <= 3) {
          status = 'due_soon';
        } else {
          status = 'upcoming';
        }

        // Skip if already done and not a booster
        if (!lastAdministered || scheduled.isBooster) {
          results.push({
            vaccineName: scheduled.vaccineName,
            dueDate,
            daysUntilDue,
            status,
            lastAdministered,
          });
        }
      }
    }

    return results.sort((a, b) => a.daysUntilDue - b.daysUntilDue);
  }

  /**
   * Get upcoming vaccinations for an individual animal
   */
  async getAnimalVaccinations(
    animalId: string,
    companyId: string,
    daysAhead = 7,
  ): Promise<VaccinationDue[]> {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
      include: {
        vaccinationRecords: { orderBy: { date: 'desc' } },
      },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const results: VaccinationDue[] = [];
    const now = new Date();
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() + daysAhead);

    const schedule = this.getAnimalVaccinationSchedule(animal.type);

    const baseDate = animal.birthDate || animal.purchaseDate || new Date();

    for (const scheduled of schedule) {
      const administered = animal.vaccinationRecords.filter(
        (vr) =>
          vr.vaccineName.toLowerCase() === scheduled.vaccineName.toLowerCase(),
      );

      const lastAdministered =
        administered.length > 0 ? administered[0].date : null;

      const dueDate = new Date(baseDate);
      dueDate.setDate(dueDate.getDate() + scheduled.day);

      const daysUntilDue = Math.floor(
        (dueDate.getTime() - now.getTime()) / 86400000,
      );

      if (dueDate <= cutoff || daysUntilDue < 0) {
        let status: 'overdue' | 'due_soon' | 'upcoming';
        if (daysUntilDue < 0) {
          status = 'overdue';
        } else if (daysUntilDue <= 3) {
          status = 'due_soon';
        } else {
          status = 'upcoming';
        }

        if (!lastAdministered || scheduled.isBooster) {
          results.push({
            vaccineName: scheduled.vaccineName,
            dueDate,
            daysUntilDue,
            status,
            lastAdministered,
          });
        }
      }
    }

    return results.sort((a, b) => a.daysUntilDue - b.daysUntilDue);
  }

  // ═══════════════════════════════════════════════════════════
  // 5. BREEDING RECORDS
  // ═══════════════════════════════════════════════════════════

  /**
   * Add a breeding record for an animal
   */
  async addBreedingRecord(
    animalId: string,
    companyId: string,
    record: {
      sireTag: string;
      damTag: string;
      breedingDate: Date;
      expectedDeliveryDate?: Date;
      method: 'AI' | 'natural';
      notes?: string;
    },
  ): Promise<BreedingRecord> {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    if (animal.gender !== Gender.FEMALE) {
      throw new BadRequestException('Breeding records can only be added for female animals (dams)');
    }

    // Validate sire exists
    const sire = await this.prisma.animal.findFirst({
      where: {
        tagNumber: record.sireTag,
        branch: { companyId },
        gender: Gender.MALE,
      },
    });
    if (!sire) {
      throw new BadRequestException(`Sire with tag ${record.sireTag} not found or is not male`);
    }

    // Validate dam exists
    const dam = await this.prisma.animal.findFirst({
      where: {
        tagNumber: record.damTag,
        branch: { companyId },
        gender: Gender.FEMALE,
      },
    });
    if (!dam) {
      throw new BadRequestException(`Dam with tag ${record.damTag} not found or is not female`);
    }

    // Calculate expected delivery if not provided
    let expectedDeliveryDate = record.expectedDeliveryDate;
    if (!expectedDeliveryDate) {
      expectedDeliveryDate = new Date(record.breedingDate);
      // Gestation periods by species
      const gestationDays: Record<string, number> = {
        CATTLE: 283,
        BUFFALO: 310,
        SHEEP: 152,
        GOAT: 150,
        CAMEL: 385,
      };
      const days =
        gestationDays[animal.type] || 150;
      expectedDeliveryDate.setDate(expectedDeliveryDate.getDate() + days);
    }

    this.logger.log(
      `Breeding record added: ${record.damTag} x ${record.sireTag} via ${record.method}`,
    );

    return {
      id: `BR-${Date.now()}`,
      sireTag: record.sireTag,
      damTag: record.damTag,
      breedingDate: record.breedingDate,
      expectedDeliveryDate,
      method: record.method,
      status: 'pending',
      notes: record.notes || null,
      createdAt: new Date(),
    };
  }

  /**
   * Create offspring record after birth
   */
  async createOffspringRecord(
    damId: string,
    companyId: string,
    record: {
      birthDate: Date;
      quantity: number;
      males: number;
      females: number;
      totalBirthWeight: number;
      status: 'healthy' | 'complications' | 'deceased';
      notes?: string;
    },
  ): Promise<OffspringRecord> {
    const dam = await this.prisma.animal.findFirst({
      where: { id: damId, branch: { companyId } },
    });
    if (!dam) throw new NotFoundException('Dam animal not found');

    if (record.quantity !== record.males + record.females) {
      throw new BadRequestException(
        `Quantity (${record.quantity}) must equal males (${record.males}) + females (${record.females})`,
      );
    }

    if (record.quantity <= 0) {
      throw new BadRequestException('Offspring quantity must be greater than zero');
    }

    this.logger.log(
      `Offspring record created: ${record.quantity} born to dam ${dam.tagNumber}`,
    );

    return {
      id: `OFF-${Date.now()}`,
      motherId: damId,
      birthDate: record.birthDate,
      quantity: record.quantity,
      males: record.males,
      females: record.females,
      totalBirthWeight: record.totalBirthWeight,
      status: record.status,
      notes: record.notes || null,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 6. LIVESTOCK ANALYTICS
  // ═══════════════════════════════════════════════════════════

  /**
   * Get comprehensive analytics for a poultry batch
   */
  async getBatchAnalytics(
    batchId: string,
    companyId: string,
  ): Promise<BatchAnalytics> {
    const batch = await this.prisma.poultryBatch.findFirst({
      where: { id: batchId, branch: { companyId } },
      include: {
        mortalityRecords: true,
        vaccinationRecords: true,
        supplier: true,
      },
    });
    if (!batch) throw new NotFoundException('Poultry batch not found');

    const benchmark = getBenchmarks('BROILER');

    // Run all analyses in parallel
    const [fcrResult, mortalityResult] = await Promise.all([
      this.calculateFCR(batchId, companyId).catch(() => null),
      this.analyzeMortality(batchId, companyId).catch(() => null),
    ]);

    // Growth data
    const daysOnFeed = Math.floor(
      (Date.now() - batch.arrivalDate.getTime()) / 86400000,
    );
    const estimatedCurrentWeight = Math.min(
      benchmark.targetWeight,
      0.04 * daysOnFeed,
    );
    const weightGainPercent =
      ((estimatedCurrentWeight - 0.04) / 0.04) * 100;
    const adg = ((estimatedCurrentWeight - 0.04) * 1000) / Math.max(1, daysOnFeed);

    // Vaccination status
    const vaccinations = await this.getUpcomingVaccinations(
      batchId,
      companyId,
      365,
    );
    const totalScheduled = vaccinations.length;
    const completed = batch.vaccinationRecords.length;
    const overdue = vaccinations.filter((v) => v.status === 'overdue').length;
    const compliance =
      totalScheduled > 0
        ? Math.round(((completed / totalScheduled) * 100) * 100) / 100
        : 100;

    // Feed cost calculation
    let totalFeedCost = 0;
    if (fcrResult) {
      totalFeedCost = fcrResult.totalFeedKg * 12; // estimated 12 EGP/kg feed
    }

    // Profitability estimation
    const estimatedRevenue = batch.currentCount * estimatedCurrentWeight * 60; // ~60 EGP/kg live weight
    const estimatedProfit = estimatedRevenue - totalFeedCost;

    const feedCostPerKgGain =
      fcrResult && fcrResult.totalWeightGainKg > 0
        ? Math.round((totalFeedCost / fcrResult.totalWeightGainKg) * 100) / 100
        : null;

    return {
      batchId: batch.id,
      batchNumber: batch.batchNumber,
      species: batch.breed,
      growth: {
        adg: Math.round(adg * 100) / 100,
        currentWeight: Math.round(estimatedCurrentWeight * 100) / 100,
        weightGainPercent: Math.round(weightGainPercent * 100) / 100,
      },
      fcr: fcrResult,
      mortality: mortalityResult,
      feedCostPerKgGain,
      vaccinationStatus: {
        totalScheduled,
        completed,
        overdue,
        compliance,
      },
      profitability:
        estimatedRevenue > 0
          ? {
              totalFeedCost: Math.round(totalFeedCost * 100) / 100,
              estimatedRevenue: Math.round(estimatedRevenue * 100) / 100,
              estimatedProfit: Math.round(estimatedProfit * 100) / 100,
            }
          : null,
      benchmarks: {
        adgBenchmark: benchmark.targetAdg,
        fcrBenchmark: benchmark.targetFcr,
        mortalityBenchmark: benchmark.maxMortalityPercent,
      },
    };
  }

  /**
   * Get analytics for an individual animal
   */
  async getAnimalAnalytics(
    animalId: string,
    companyId: string,
  ): Promise<any> {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
      include: {
        weightRecords: { orderBy: { date: 'asc' } },
        feedRecords: true,
        vaccinationRecords: true,
      },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const benchmark = getBenchmarks(animal.type);
    const growth = await this.trackGrowth(animalId, companyId);
    const fcr = await this.calculateAnimalFCR(animalId, companyId).catch(
      () => null,
    );

    const totalFeedCost = animal.feedRecords.reduce(
      (sum, f) => sum + (f.cost ? Number(f.cost) : 0),
      0,
    );
    const feedCostPerKgGain =
      growth.currentWeight > growth.initialWeight
        ? totalFeedCost / (growth.currentWeight - growth.initialWeight)
        : null;

    const vaccinationsCompleted = animal.vaccinationRecords.length;

    return {
      animalId: animal.id,
      tagNumber: animal.tagNumber,
      type: animal.type,
      breed: animal.breed,
      gender: animal.gender,
      growth,
      fcr,
      feedCostPerKgGain:
        feedCostPerKgGain !== null
          ? Math.round(feedCostPerKgGain * 100) / 100
          : null,
      vaccinationsCompleted,
      benchmarks: {
        adgBenchmark: benchmark.targetAdg,
        fcrBenchmark: benchmark.targetFcr,
        targetWeight: benchmark.targetWeight,
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 7. PEN MANAGEMENT
  // ═══════════════════════════════════════════════════════════

  /**
   * Assign an animal to a pen, tracking occupancy and density
   */
  async assignToPen(
    animalId: string,
    companyId: string,
    penNumber: string,
    penAreaSqm?: number,
  ): Promise<PenAssignment> {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    // Update the animal's pen assignment
    await this.prisma.animal.update({
      where: { id: animalId },
      data: { penNumber },
    });

    // Get all animals now in this pen
    const penAnimals = await this.prisma.animal.findMany({
      where: {
        branchId: animal.branchId,
        penNumber,
        status: { in: [AnimalStatus.ACTIVE, AnimalStatus.GROWING] },
      },
    });

    const animalCount = penAnimals.length;
    const species = animal.type;
    const benchmark = getBenchmarks(species);

    // Estimate pen area if not provided
    const estimatedArea =
      penAreaSqm || animalCount * (1 / benchmark.densityLimitPerSqm) * 1.2;

    const density = estimatedArea > 0 ? animalCount / estimatedArea : 0;
    const densityLimit = benchmark.densityLimitPerSqm;

    let status: 'optimal' | 'overcrowded' | 'underutilized';
    if (density > densityLimit * 1.1) {
      status = 'overcrowded';
    } else if (density < densityLimit * 0.3) {
      status = 'underutilized';
    } else {
      status = 'optimal';
    }

    this.logger.log(
      `Animal ${animal.tagNumber} assigned to pen ${penNumber}. Occupancy: ${animalCount}, Density: ${density.toFixed(2)}/sqm (${status})`,
    );

    return {
      penNumber,
      animalCount,
      density: Math.round(density * 100) / 100,
      densityLimit,
      status,
      species,
    };
  }

  /**
   * Get pen occupancy summary for a branch
   */
  async getPenOccupancy(
    branchId: string,
    companyId: string,
  ): Promise<PenAssignment[]> {
    const branch = await this.prisma.branch.findFirst({
      where: { id: branchId, companyId },
    });
    if (!branch) throw new NotFoundException('Branch not found');

    // Get all active animals grouped by pen
    const animals = await this.prisma.animal.findMany({
      where: {
        branchId,
        status: { in: [AnimalStatus.ACTIVE, AnimalStatus.GROWING] },
        penNumber: { not: null },
      },
    });

    // Group by pen
    const penMap: Record<
      string,
      { count: number; type: string; penNumber: string }
    > = {};

    for (const animal of animals) {
      const pen = animal.penNumber || 'UNASSIGNED';
      if (!penMap[pen]) {
        penMap[pen] = { count: 0, type: animal.type, penNumber: pen };
      }
      penMap[pen].count++;
    }

    return Object.values(penMap).map((p) => {
      const benchmark = getBenchmarks(p.type);
      const estimatedArea = p.count * (1 / benchmark.densityLimitPerSqm) * 1.2;
      const density = estimatedArea > 0 ? p.count / estimatedArea : 0;
      let status: 'optimal' | 'overcrowded' | 'underutilized';
      if (density > benchmark.densityLimitPerSqm * 1.1) {
        status = 'overcrowded';
      } else if (density < benchmark.densityLimitPerSqm * 0.3) {
        status = 'underutilized';
      } else {
        status = 'optimal';
      }

      return {
        penNumber: p.penNumber,
        animalCount: p.count,
        density: Math.round(density * 100) / 100,
        densityLimit: benchmark.densityLimitPerSqm,
        status,
        species: p.type,
      };
    });
  }

  // ═══════════════════════════════════════════════════════════
  // CRUD OPERATIONS
  // ═══════════════════════════════════════════════════════════

  async findAllAnimals(
    companyId: string,
    options: {
      page?: number;
      limit?: number;
      type?: AnimalType;
      status?: AnimalStatus;
      branchId?: string;
    },
  ) {
    const { page = 1, limit = 10, type, status, branchId } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.AnimalWhereInput = {
      branch: { companyId },
    };
    if (type) where.type = type;
    if (status) where.status = status;
    if (branchId) where.branchId = branchId;

    const [data, total] = await Promise.all([
      this.prisma.animal.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          weightRecords: { orderBy: { date: 'desc' }, take: 1 },
          feedRecords: { orderBy: { date: 'desc' }, take: 1 },
        },
      }),
      this.prisma.animal.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOneAnimal(id: string, companyId: string) {
    const animal = await this.prisma.animal.findFirst({
      where: { id, branch: { companyId } },
      include: {
        weightRecords: { orderBy: { date: 'desc' }, take: 30 },
        feedRecords: { orderBy: { date: 'desc' }, take: 30 },
        vaccinationRecords: { orderBy: { date: 'desc' }, take: 30 },
      },
    });
    if (!animal) throw new NotFoundException('Animal not found');
    return { data: animal };
  }

  async createAnimal(
    companyId: string,
    dto: {
      tagNumber: string;
      type: AnimalType;
      breed?: string;
      gender: Gender;
      birthDate?: Date;
      purchaseDate?: Date;
      purchasePrice?: number;
      currentWeight?: number;
      penNumber?: string;
      branchId: string;
      notes?: string;
    },
  ) {
    // Check tag number uniqueness
    const existing = await this.prisma.animal.findUnique({
      where: { tagNumber: dto.tagNumber },
    });
    if (existing) {
      throw new ConflictException(
        `Animal with tag number ${dto.tagNumber} already exists`,
      );
    }

    // Verify branch belongs to company
    const branch = await this.prisma.branch.findFirst({
      where: { id: dto.branchId, companyId },
    });
    if (!branch) throw new NotFoundException('Branch not found for this company');

    const animal = await this.prisma.animal.create({
      data: {
        tagNumber: dto.tagNumber,
        type: dto.type,
        breed: dto.breed || null,
        gender: dto.gender,
        birthDate: dto.birthDate || null,
        purchaseDate: dto.purchaseDate || null,
        purchasePrice: dto.purchasePrice
          ? new Prisma.Decimal(dto.purchasePrice)
          : null,
        currentWeight: dto.currentWeight
          ? new Prisma.Decimal(dto.currentWeight)
          : new Prisma.Decimal(0),
        penNumber: dto.penNumber || null,
        branchId: dto.branchId,
        status: AnimalStatus.GROWING,
        notes: dto.notes,
      },
    });

    this.logger.log(`Animal created: ${animal.tagNumber}`);
    return { data: animal };
  }

  async updateAnimal(
    id: string,
    companyId: string,
    dto: {
      breed?: string;
      currentWeight?: number;
      penNumber?: string;
      status?: AnimalStatus;
      notes?: string;
    },
  ) {
    const animal = await this.prisma.animal.findFirst({
      where: { id, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const data: Prisma.AnimalUpdateInput = {};
    if (dto.breed !== undefined) data.breed = dto.breed;
    if (dto.currentWeight !== undefined)
      data.currentWeight = new Prisma.Decimal(dto.currentWeight);
    if (dto.penNumber !== undefined) data.penNumber = dto.penNumber;
    if (dto.status !== undefined) data.status = dto.status;
    if (dto.notes !== undefined) data.notes = dto.notes;

    const updated = await this.prisma.animal.update({
      where: { id },
      data,
    });

    return { data: updated };
  }

  async deleteAnimal(id: string, companyId: string) {
    const animal = await this.prisma.animal.findFirst({
      where: { id, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    await this.prisma.animal.update({
      where: { id },
      data: { status: AnimalStatus.DECEASED, deletedAt: new Date() },
    });

    return { message: 'Animal marked as deceased' };
  }

  // ── Weight Record ──

  async addWeightRecord(
    animalId: string,
    companyId: string,
    dto: {
      weight: number;
      date?: Date;
      measuredBy: string;
      notes?: string;
    },
  ) {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const record = await this.prisma.animalWeight.create({
      data: {
        animalId,
        weight: new Prisma.Decimal(dto.weight),
        date: dto.date ? new Date(dto.date) : new Date(),
        measuredBy: dto.measuredBy,
        notes: dto.notes,
      },
    });

    // Update animal's current weight
    await this.prisma.animal.update({
      where: { id: animalId },
      data: { currentWeight: new Prisma.Decimal(dto.weight) },
    });

    return { data: record };
  }

  async getWeightRecords(animalId: string, companyId: string) {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const records = await this.prisma.animalWeight.findMany({
      where: { animalId },
      orderBy: { date: 'desc' },
    });

    return { data: records };
  }

  // ── Feed Record ──

  async addFeedRecord(
    animalId: string,
    companyId: string,
    dto: {
      feedType: FeedType;
      quantity: number;
      cost?: number;
      date?: Date;
      notes?: string;
    },
  ) {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const record = await this.prisma.animalFeedRecord.create({
      data: {
        animalId,
        feedType: dto.feedType,
        quantity: new Prisma.Decimal(dto.quantity),
        cost: dto.cost ? new Prisma.Decimal(dto.cost) : null,
        date: dto.date ? new Date(dto.date) : new Date(),
        notes: dto.notes,
      },
    });

    return { data: record };
  }

  // ── Vaccination Record ──

  async addVaccinationRecord(
    animalId: string,
    companyId: string,
    dto: {
      vaccineName: string;
      batchNumber?: string;
      date?: Date;
      nextDueDate?: Date;
      veterinarian?: string;
      notes?: string;
    },
  ) {
    const animal = await this.prisma.animal.findFirst({
      where: { id: animalId, branch: { companyId } },
    });
    if (!animal) throw new NotFoundException('Animal not found');

    const record = await this.prisma.vaccinationRecord.create({
      data: {
        animalId,
        vaccineName: dto.vaccineName,
        batchNumber: dto.batchNumber || null,
        date: dto.date ? new Date(dto.date) : new Date(),
        nextDueDate: dto.nextDueDate ? new Date(dto.nextDueDate) : null,
        veterinarian: dto.veterinarian || null,
        notes: dto.notes,
      },
    });

    return { data: record };
  }

  // ── Poultry Batch CRUD ──

  async findAllPoultryBatches(
    companyId: string,
    options: {
      page?: number;
      limit?: number;
      status?: string;
      branchId?: string;
    },
  ) {
    const { page = 1, limit = 10, status, branchId } = options;
    const skip = (page - 1) * limit;

    const where: any = { branch: { companyId } };
    if (status) where.status = status;
    if (branchId) where.branchId = branchId;

    const [data, total] = await Promise.all([
      this.prisma.poultryBatch.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { mortalityRecords: true, vaccinationRecords: true } },
          supplier: { select: { name: true } },
        },
      }),
      this.prisma.poultryBatch.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOnePoultryBatch(id: string, companyId: string) {
    const batch = await this.prisma.poultryBatch.findFirst({
      where: { id, branch: { companyId } },
      include: {
        mortalityRecords: { orderBy: { date: 'desc' }, take: 30 },
        vaccinationRecords: { orderBy: { date: 'desc' }, take: 30 },
        supplier: true,
      },
    });
    if (!batch) throw new NotFoundException('Poultry batch not found');
    return { data: batch };
  }

  async createPoultryBatch(
    companyId: string,
    dto: {
      breed: string;
      supplierId?: string;
      quantity: number;
      arrivalDate: Date;
      branchId: string;
      notes?: string;
    },
  ) {
    const branch = await this.prisma.branch.findFirst({
      where: { id: dto.branchId, companyId },
    });
    if (!branch) throw new NotFoundException('Branch not found');

    const count = await this.prisma.poultryBatch.count({
      where: { branch: { companyId } },
    });
    const batchNumber = `PLY-${Date.now().toString(36).toUpperCase()}-${(count + 1).toString().padStart(4, '0')}`;

    const batch = await this.prisma.poultryBatch.create({
      data: {
        batchNumber,
        breed: dto.breed,
        supplierId: dto.supplierId || null,
        quantity: dto.quantity,
        currentCount: dto.quantity,
        arrivalDate: new Date(dto.arrivalDate),
        branchId: dto.branchId,
      },
    });

    this.logger.log(`Poultry batch created: ${batch.batchNumber}`);
    return { data: batch };
  }

  async addMortalityRecord(
    batchId: string,
    companyId: string,
    dto: {
      date: Date;
      count: number;
      cause?: string;
      notes?: string;
    },
  ) {
    const batch = await this.prisma.poultryBatch.findFirst({
      where: { id: batchId, branch: { companyId } },
    });
    if (!batch) throw new NotFoundException('Poultry batch not found');

    if (dto.count <= 0) {
      throw new BadRequestException('Mortality count must be greater than zero');
    }
    if (dto.count > batch.currentCount) {
      throw new BadRequestException(
        `Mortality count (${dto.count}) exceeds current count (${batch.currentCount})`,
      );
    }

    const record = await this.prisma.poultryMortality.create({
      data: {
        batchId,
        date: new Date(dto.date),
        count: dto.count,
        cause: dto.cause || null,
        notes: dto.notes,
      },
    });

    // Update batch counts
    await this.prisma.poultryBatch.update({
      where: { id: batchId },
      data: {
        currentCount: { decrement: dto.count },
        mortalityCount: { increment: dto.count },
      },
    });

    this.logger.log(
      `Mortality record added for batch ${batch.batchNumber}: ${dto.count} (${dto.cause || 'unknown cause'})`,
    );

    return { data: record };
  }

  // ═══════════════════════════════════════════════════════════
  // HELPER METHODS
  // ═══════════════════════════════════════════════════════════

  private mapBreedToSpecies(breed: string): string {
    const breedLower = breed.toLowerCase();
    if (breedLower.includes('ross') || breedLower.includes('cobb') || breedLower.includes('broiler')) return 'BROILER';
    if (breedLower.includes('holstein') || breedLower.includes('angus') || breedLower.includes('cattle')) return 'CATTLE';
    if (breedLower.includes('buffalo')) return 'BUFFALO';
    if (breedLower.includes('sheep') || breedLower.includes('merino') || breedLower.includes('awassi')) return 'SHEEP';
    if (breedLower.includes('goat') || breedLower.includes('boer') || breedLower.includes('saanen')) return 'GOAT';
    if (breedLower.includes('camel')) return 'CAMEL';
    return 'BROILER';
  }

  private getStandardVaccinationSchedule(breed: string): Array<{
    vaccineName: string;
    day: number;
    isBooster: boolean;
  }> {
    return [
      { vaccineName: 'Marek\'s Disease', day: 1, isBooster: false },
      { vaccineName: 'Newcastle Disease (NDV)', day: 1, isBooster: false },
      { vaccineName: 'Infectious Bronchitis', day: 1, isBooster: false },
      { vaccineName: 'Newcastle Disease (NDV)', day: 7, isBooster: true },
      { vaccineName: 'Infectious Bursal Disease (Gumboro)', day: 10, isBooster: false },
      { vaccineName: 'Infectious Bronchitis', day: 14, isBooster: true },
      { vaccineName: 'Newcastle Disease (NDV)', day: 21, isBooster: true },
      { vaccineName: 'Infectious Bursal Disease (Gumboro)', day: 21, isBooster: true },
      { vaccineName: 'Avian Influenza (H5N1)', day: 14, isBooster: false },
      { vaccineName: 'Avian Influenza (H5N1)', day: 35, isBooster: true },
      { vaccineName: 'Fowl Pox', day: 28, isBooster: false },
      { vaccineName: 'Laryngotracheitis (ILT)', day: 35, isBooster: false },
    ];
  }

  private getAnimalVaccinationSchedule(type: AnimalType): Array<{
    vaccineName: string;
    day: number;
    isBooster: boolean;
  }> {
    const schedules: Record<string, Array<{ vaccineName: string; day: number; isBooster: boolean }>> = {
      CATTLE: [
        { vaccineName: 'Brucellosis', day: 120, isBooster: false },
        { vaccineName: 'Foot and Mouth Disease', day: 150, isBooster: false },
        { vaccineName: 'Foot and Mouth Disease', day: 270, isBooster: true },
        { vaccineName: 'Blackleg', day: 90, isBooster: false },
        { vaccineName: 'Bovine Viral Diarrhea', day: 60, isBooster: false },
        { vaccineName: 'Infectious Bovine Rhinotracheitis', day: 180, isBooster: false },
      ],
      SHEEP: [
        { vaccineName: 'Enterotoxemia', day: 60, isBooster: false },
        { vaccineName: 'Enterotoxemia', day: 120, isBooster: true },
        { vaccineName: 'Peste des Petits Ruminants', day: 90, isBooster: false },
        { vaccineName: 'Foot and Mouth Disease', day: 120, isBooster: false },
        { vaccineName: 'Sheep Pox', day: 90, isBooster: false },
      ],
      GOAT: [
        { vaccineName: 'Enterotoxemia', day: 60, isBooster: false },
        { vaccineName: 'Peste des Petits Ruminants', day: 90, isBooster: false },
        { vaccineName: 'Foot and Mouth Disease', day: 120, isBooster: false },
        { vaccineName: 'Goat Pox', day: 90, isBooster: false },
      ],
      BUFFALO: [
        { vaccineName: 'Foot and Mouth Disease', day: 120, isBooster: false },
        { vaccineName: 'Foot and Mouth Disease', day: 240, isBooster: true },
        { vaccineName: 'Brucellosis', day: 180, isBooster: false },
        { vaccineName: 'Blackleg', day: 90, isBooster: false },
      ],
      CAMEL: [
        { vaccineName: 'Camel Pox', day: 90, isBooster: false },
        { vaccineName: 'Camel Contagious Ecthyma', day: 60, isBooster: false },
        { vaccineName: 'Trypanosomiasis', day: 120, isBooster: false },
      ],
    };

    return schedules[type] || [];
  }
}
