import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { LivestockService } from './livestock.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';

@ApiTags('Livestock')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('livestock')
export class LivestockController {
  constructor(private readonly livestockService: LivestockService) {}

  @Get('batches')
  @Permissions('production:view')
  @ApiOperation({ summary: 'List livestock batches' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiResponse({ status: 200, description: 'Livestock batches retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllBatches(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('status') status?: string,
  ) {
    return this.livestockService.findAllBatches(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      status,
    });
  }

  @Get('batches/:id')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get livestock batch' })
  @ApiResponse({ status: 200, description: 'Livestock batch retrieved' })
  @ApiResponse({ status: 404, description: 'Livestock batch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOneBatch(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.livestockService.findOneBatch(id, companyId);
  }

  @Post('batches')
  @Permissions('production:create')
  @ApiOperation({ summary: 'Create livestock batch' })
  @ApiResponse({ status: 201, description: 'Livestock batch created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createBatch(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: any,
  ) {
    return this.livestockService.createBatch(companyId, dto);
  }

  @Put('batches/:id')
  @Permissions('production:update')
  @ApiOperation({ summary: 'Update livestock batch' })
  @ApiResponse({ status: 200, description: 'Livestock batch updated' })
  @ApiResponse({ status: 404, description: 'Livestock batch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateBatch(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: any,
  ) {
    return this.livestockService.updateBatch(id, companyId, dto);
  }

  @Post('batches/:id/daily-records')
  @Permissions('production:create')
  @ApiOperation({ summary: 'Add daily record' })
  @ApiResponse({ status: 201, description: 'Daily record added' })
  @ApiResponse({ status: 404, description: 'Livestock batch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async addDailyRecord(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: any,
  ) {
    return this.livestockService.addDailyRecord(id, companyId, dto);
  }

  @Get('batches/:id/daily-records')
  @Permissions('production:view')
  @ApiOperation({ summary: 'Get daily records' })
  @ApiResponse({ status: 200, description: 'Daily records retrieved' })
  @ApiResponse({ status: 404, description: 'Livestock batch not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getDailyRecords(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.livestockService.getDailyRecords(id, companyId);
  }
}
