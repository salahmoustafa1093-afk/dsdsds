/**
 * ─────────────────────────────────────────────────────────────
 * PERMISSION CONSTANTS
 * ─────────────────────────────────────────────────────────────
 *
 * All system permissions are defined here as granular strings.
 * Format: module:action
 *
 * Used by PermissionsGuard, decorators, and role mappings.
 * ─────────────────────────────────────────────────────────────
 */

// ─── Dashboard ───────────────────────────────────────────
export const DASHBOARD_VIEW = 'dashboard:view';

// ─── Inventory ───────────────────────────────────────────
export const INVENTORY_VIEW = 'inventory:view';
export const INVENTORY_CREATE = 'inventory:create';
export const INVENTORY_UPDATE = 'inventory:update';
export const INVENTORY_DELETE = 'inventory:delete';

// ─── Sales ───────────────────────────────────────────────
export const SALES_VIEW = 'sales:view';
export const SALES_CREATE = 'sales:create';
export const SALES_UPDATE = 'sales:update';
export const SALES_DELETE = 'sales:delete';
export const SALES_APPROVE = 'sales:approve';

// ─── Customers ───────────────────────────────────────────
export const CUSTOMERS_VIEW = 'customers:view';
export const CUSTOMERS_CREATE = 'customers:create';
export const CUSTOMERS_UPDATE = 'customers:update';
export const CUSTOMERS_DELETE = 'customers:delete';

// ─── Suppliers ───────────────────────────────────────────
export const SUPPLIERS_VIEW = 'suppliers:view';
export const SUPPLIERS_CREATE = 'suppliers:create';

// ─── Purchases ───────────────────────────────────────────
export const PURCHASES_VIEW = 'purchases:view';
export const PURCHASES_CREATE = 'purchases:create';
export const PURCHASES_APPROVE = 'purchases:approve';

// ─── Accounting ──────────────────────────────────────────
export const ACCOUNTING_VIEW = 'accounting:view';
export const ACCOUNTING_CREATE = 'accounting:create';
export const ACCOUNTING_APPROVE = 'accounting:approve';

// ─── Production ──────────────────────────────────────────
export const PRODUCTION_VIEW = 'production:view';
export const PRODUCTION_CREATE = 'production:create';
export const PRODUCTION_UPDATE = 'production:update';

// ─── HR ──────────────────────────────────────────────────
export const HR_VIEW = 'hr:view';
export const HR_CREATE = 'hr:create';
export const HR_UPDATE = 'hr:update';
export const HR_DELETE = 'hr:delete';
export const HR_PAYROLL = 'hr:payroll';

// ─── Fleet ───────────────────────────────────────────────
export const FLEET_VIEW = 'fleet:view';
export const FLEET_CREATE = 'fleet:create';
export const FLEET_UPDATE = 'fleet:update';

// ─── Delivery ────────────────────────────────────────────
export const DELIVERY_VIEW = 'delivery:view';
export const DELIVERY_CREATE = 'delivery:create';
export const DELIVERY_UPDATE = 'delivery:update';
export const DELIVERY_ASSIGN = 'delivery:assign';

// ─── Reports ─────────────────────────────────────────────
export const REPORTS_VIEW = 'reports:view';

// ─── Branches ────────────────────────────────────────────
export const BRANCHES_VIEW = 'branches:view';
export const BRANCHES_CREATE = 'branches:create';

// ─── Settings ────────────────────────────────────────────
export const SETTINGS_VIEW = 'settings:view';
export const SETTINGS_UPDATE = 'settings:update';

// ─── Users ───────────────────────────────────────────────
export const USERS_VIEW = 'users:view';
export const USERS_CREATE = 'users:create';
export const USERS_UPDATE = 'users:update';
export const USERS_DELETE = 'users:delete';
export const USERS_PERMISSIONS = 'users:permissions';

// ─── Permission Groups (for convenience) ─────────────────

/** All permission strings as a single array */
export const ALL_PERMISSIONS = [
  DASHBOARD_VIEW,
  INVENTORY_VIEW,
  INVENTORY_CREATE,
  INVENTORY_UPDATE,
  INVENTORY_DELETE,
  SALES_VIEW,
  SALES_CREATE,
  SALES_UPDATE,
  SALES_DELETE,
  SALES_APPROVE,
  CUSTOMERS_VIEW,
  CUSTOMERS_CREATE,
  CUSTOMERS_UPDATE,
  CUSTOMERS_DELETE,
  SUPPLIERS_VIEW,
  SUPPLIERS_CREATE,
  PURCHASES_VIEW,
  PURCHASES_CREATE,
  PURCHASES_APPROVE,
  ACCOUNTING_VIEW,
  ACCOUNTING_CREATE,
  ACCOUNTING_APPROVE,
  PRODUCTION_VIEW,
  PRODUCTION_CREATE,
  PRODUCTION_UPDATE,
  HR_VIEW,
  HR_CREATE,
  HR_UPDATE,
  HR_DELETE,
  HR_PAYROLL,
  FLEET_VIEW,
  FLEET_CREATE,
  FLEET_UPDATE,
  DELIVERY_VIEW,
  DELIVERY_CREATE,
  DELIVERY_UPDATE,
  DELIVERY_ASSIGN,
  REPORTS_VIEW,
  BRANCHES_VIEW,
  BRANCHES_CREATE,
  SETTINGS_VIEW,
  SETTINGS_UPDATE,
  USERS_VIEW,
  USERS_CREATE,
  USERS_UPDATE,
  USERS_DELETE,
  USERS_PERMISSIONS,
];
