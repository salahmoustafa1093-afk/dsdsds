/**
 * ─────────────────────────────────────────────────────────────
 * ROLE-TO-PERMISSION MAPPINGS
 * ─────────────────────────────────────────────────────────────
 *
 * Each role is mapped to a set of permissions that grant access
 * to specific modules and actions throughout the system.
 *
 * ─────────────────────────────────────────────────────────────
 */

import * as P from './permissions.constant';

// ─── Wildcard ────────────────────────────────────────────
/** Grants every permission in the system */
export const WILDCARD_PERMISSION = '*';

// ─── Role Definitions ────────────────────────────────────

/** Super Admin — full system access (all permissions) */
export const SUPER_ADMIN_PERMISSIONS = [WILDCARD_PERMISSION];

/** Admin — full access except user permission management */
export const ADMIN_PERMISSIONS = [
  P.DASHBOARD_VIEW,
  P.INVENTORY_VIEW,
  P.INVENTORY_CREATE,
  P.INVENTORY_UPDATE,
  P.INVENTORY_DELETE,
  P.SALES_VIEW,
  P.SALES_CREATE,
  P.SALES_UPDATE,
  P.SALES_DELETE,
  P.SALES_APPROVE,
  P.CUSTOMERS_VIEW,
  P.CUSTOMERS_CREATE,
  P.CUSTOMERS_UPDATE,
  P.CUSTOMERS_DELETE,
  P.SUPPLIERS_VIEW,
  P.SUPPLIERS_CREATE,
  P.PURCHASES_VIEW,
  P.PURCHASES_CREATE,
  P.PURCHASES_APPROVE,
  P.ACCOUNTING_VIEW,
  P.ACCOUNTING_CREATE,
  P.ACCOUNTING_APPROVE,
  P.PRODUCTION_VIEW,
  P.PRODUCTION_CREATE,
  P.PRODUCTION_UPDATE,
  P.HR_VIEW,
  P.HR_CREATE,
  P.HR_UPDATE,
  P.HR_DELETE,
  P.HR_PAYROLL,
  P.FLEET_VIEW,
  P.FLEET_CREATE,
  P.FLEET_UPDATE,
  P.DELIVERY_VIEW,
  P.DELIVERY_CREATE,
  P.DELIVERY_UPDATE,
  P.DELIVERY_ASSIGN,
  P.REPORTS_VIEW,
  P.BRANCHES_VIEW,
  P.BRANCHES_CREATE,
  P.SETTINGS_VIEW,
  P.SETTINGS_UPDATE,
  P.USERS_VIEW,
  P.USERS_CREATE,
  P.USERS_UPDATE,
  P.USERS_DELETE,
];

/** Branch Manager — operational oversight at branch level */
export const BRANCH_MANAGER_PERMISSIONS = [
  P.DASHBOARD_VIEW,
  P.INVENTORY_VIEW,
  P.INVENTORY_CREATE,
  P.INVENTORY_UPDATE,
  P.SALES_VIEW,
  P.SALES_CREATE,
  P.SALES_UPDATE,
  P.CUSTOMERS_VIEW,
  P.CUSTOMERS_CREATE,
  P.CUSTOMERS_UPDATE,
  P.SUPPLIERS_VIEW,
  P.PURCHASES_VIEW,
  P.PURCHASES_CREATE,
  P.DELIVERY_VIEW,
  P.DELIVERY_CREATE,
  P.DELIVERY_UPDATE,
  P.FLEET_VIEW,
  P.REPORTS_VIEW,
  P.BRANCHES_VIEW,
  P.HR_VIEW,
  P.SETTINGS_VIEW,
];

/** Accountant — financial management and reporting */
export const ACCOUNTANT_PERMISSIONS = [
  P.DASHBOARD_VIEW,
  P.ACCOUNTING_VIEW,
  P.ACCOUNTING_CREATE,
  P.REPORTS_VIEW,
  P.PURCHASES_VIEW,
  P.SUPPLIERS_VIEW,
];

/** Sales Representative — sales and customer management */
export const SALES_REP_PERMISSIONS = [
  P.DASHBOARD_VIEW,
  P.SALES_VIEW,
  P.SALES_CREATE,
  P.CUSTOMERS_VIEW,
  P.CUSTOMERS_CREATE,
  P.DELIVERY_VIEW,
];

/** Warehouse Manager — inventory and logistics */
export const WAREHOUSE_MANAGER_PERMISSIONS = [
  P.INVENTORY_VIEW,
  P.INVENTORY_CREATE,
  P.INVENTORY_UPDATE,
  P.PURCHASES_VIEW,
  P.DELIVERY_VIEW,
  P.DELIVERY_CREATE,
  P.DELIVERY_UPDATE,
  P.SUPPLIERS_VIEW,
];

/** Production Manager — manufacturing and feed operations */
export const PRODUCTION_MANAGER_PERMISSIONS = [
  P.PRODUCTION_VIEW,
  P.PRODUCTION_CREATE,
  P.PRODUCTION_UPDATE,
  P.INVENTORY_VIEW,
  P.REPORTS_VIEW,
];

/** HR Manager — human resources and payroll */
export const HR_MANAGER_PERMISSIONS = [
  P.HR_VIEW,
  P.HR_CREATE,
  P.HR_UPDATE,
  P.HR_DELETE,
  P.HR_PAYROLL,
  P.DASHBOARD_VIEW,
  P.REPORTS_VIEW,
  P.SETTINGS_VIEW,
];

// ─── Permission Resolution ───────────────────────────────

/**
 * Resolve a role name to its permission array.
 * Returns an empty array for unknown roles.
 */
export function getPermissionsForRole(roleName: string): string[] {
  switch (roleName) {
    case 'super_admin':
      return [...SUPER_ADMIN_PERMISSIONS];
    case 'admin':
      return [...ADMIN_PERMISSIONS];
    case 'branch_manager':
      return [...BRANCH_MANAGER_PERMISSIONS];
    case 'accountant':
      return [...ACCOUNTANT_PERMISSIONS];
    case 'sales_rep':
      return [...SALES_REP_PERMISSIONS];
    case 'warehouse_manager':
      return [...WAREHOUSE_MANAGER_PERMISSIONS];
    case 'production_manager':
      return [...PRODUCTION_MANAGER_PERMISSIONS];
    case 'hr_manager':
      return [...HR_MANAGER_PERMISSIONS];
    default:
      return [];
  }
}

/**
 * Resolve permissions for multiple roles.
 * De-duplicates and returns a combined permission set.
 */
export function getPermissionsForRoles(roleNames: string[]): string[] {
  const allPerms = roleNames.flatMap((r) => getPermissionsForRole(r));
  const unique = [...new Set(allPerms)];
  return unique;
}

/**
 * Check whether a permission list includes the wildcard (all access).
 */
export function hasWildcardPermission(permissions: string[]): boolean {
  return permissions.includes(WILDCARD_PERMISSION);
}

/**
 * Check if a user with the given permissions can perform the required permission.
 * Respects the wildcard '*' permission.
 */
export function hasPermission(
  userPermissions: string[],
  requiredPermission: string,
): boolean {
  if (hasWildcardPermission(userPermissions)) return true;
  return userPermissions.includes(requiredPermission);
}

/**
 * Check if a user with the given permissions has ALL of the required permissions.
 * Respects the wildcard '*' permission.
 */
export function hasAllPermissions(
  userPermissions: string[],
  requiredPermissions: string[],
): boolean {
  if (hasWildcardPermission(userPermissions)) return true;
  return requiredPermissions.every((p) => userPermissions.includes(p));
}

/**
 * Check if a user with the given permissions has ANY of the required permissions.
 * Respects the wildcard '*' permission.
 */
export function hasAnyPermission(
  userPermissions: string[],
  requiredPermissions: string[],
): boolean {
  if (hasWildcardPermission(userPermissions)) return true;
  return requiredPermissions.some((p) => userPermissions.includes(p));
}
