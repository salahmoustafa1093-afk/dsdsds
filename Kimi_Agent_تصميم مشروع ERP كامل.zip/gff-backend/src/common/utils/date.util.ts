export function startOfDay(date: Date = new Date()): Date {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function endOfDay(date: Date = new Date()): Date {
  const d = new Date(date);
  d.setHours(23, 59, 59, 999);
  return d;
}

export function startOfMonth(date: Date = new Date()): Date {
  const d = new Date(date);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function endOfMonth(date: Date = new Date()): Date {
  const d = new Date(date);
  d.setMonth(d.getMonth() + 1);
  d.setDate(0);
  d.setHours(23, 59, 59, 999);
  return d;
}

export function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

export function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

export function isDateInRange(
  date: Date,
  start: Date,
  end: Date,
): boolean {
  return date >= start && date <= end;
}

export function getQuarter(date: Date = new Date()): number {
  return Math.floor(date.getMonth() / 3) + 1;
}

export function getFiscalYear(
  date: Date = new Date(),
  startMonth: number = 7,
): { start: Date; end: Date } {
  const d = new Date(date);
  const year = d.getMonth() >= startMonth ? d.getFullYear() : d.getFullYear() - 1;
  return {
    start: new Date(year, startMonth - 1, 1),
    end: new Date(year + 1, startMonth - 1, 0, 23, 59, 59, 999),
  };
}
