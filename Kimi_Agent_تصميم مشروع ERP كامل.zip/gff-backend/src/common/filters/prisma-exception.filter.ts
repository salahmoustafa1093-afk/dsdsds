import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Response } from 'express';
import { Prisma } from '@prisma/client';

@Catch(Prisma.PrismaClientKnownRequestError)
export class PrismaExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(PrismaExceptionFilter.name);

  catch(
    exception: Prisma.PrismaClientKnownRequestError,
    host: ArgumentsHost,
  ) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Database error occurred';
    let error = 'Database Error';

    switch (exception.code) {
      case 'P2002':
        status = HttpStatus.CONFLICT;
        const fields = exception.meta?.target as string[];
        message = `Unique constraint failed on field(s): ${fields?.join(', ') || 'unknown'}`;
        error = 'Conflict';
        break;
      case 'P2003':
        status = HttpStatus.BAD_REQUEST;
        message = `Foreign key constraint failed on field: ${exception.meta?.field_name || 'unknown'}`;
        error = 'Foreign Key Constraint';
        break;
      case 'P2025':
        status = HttpStatus.NOT_FOUND;
        message = exception.meta?.cause as string || 'Record not found';
        error = 'Not Found';
        break;
      case 'P2001':
        status = HttpStatus.NOT_FOUND;
        message = `Record not found for the given where condition`;
        error = 'Not Found';
        break;
      case 'P2014':
        status = HttpStatus.BAD_REQUEST;
        message = 'Invalid relation: the changed records did not have a relation';
        error = 'Invalid Relation';
        break;
      case 'P2016':
        status = HttpStatus.BAD_REQUEST;
        message = `Query interpretation error: ${exception.message}`;
        error = 'Query Error';
        break;
      default:
        message = exception.message;
        break;
    }

    this.logger.error(
      `Prisma Error [${exception.code}]: ${request.method} ${request.url} - ${message}`,
      exception.stack,
    );

    response.status(status).json({
      success: false,
      statusCode: status,
      message: [message],
      error,
      path: request.url,
      method: request.method,
      timestamp: new Date().toISOString(),
    });
  }
}
