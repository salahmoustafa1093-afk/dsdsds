import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    totalPages?: number;
  };
  timestamp: string;
}

@Injectable()
export class ResponseInterceptor<T>
  implements NestInterceptor<T, ApiResponse<T>>
{
  intercept(
    context: ExecutionContext,
    next: CallHandler<T>,
  ): Observable<ApiResponse<T>> {
    const request = context.switchToHttp().getRequest();
    const page = Number(request.query.page) || undefined;
    const limit = Number(request.query.limit) || undefined;

    return next.handle().pipe(
      map((data: any) => {
        const response: ApiResponse<T> = {
          success: true,
          data: data?.data ?? data,
          timestamp: new Date().toISOString(),
        };

        if (data?.meta || (page && limit)) {
          response.meta = {
            page: data?.meta?.page ?? page ?? 1,
            limit: data?.meta?.limit ?? limit ?? 10,
            total: data?.meta?.total ?? 0,
            totalPages: data?.meta?.totalPages ?? 0,
          };
        }

        return response;
      }),
    );
  }
}
