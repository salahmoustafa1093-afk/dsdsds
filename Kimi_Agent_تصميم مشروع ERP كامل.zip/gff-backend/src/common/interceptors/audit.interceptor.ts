import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
  Logger,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { PrismaService } from '@/prisma/prisma.service';

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  private readonly logger = new Logger(AuditInterceptor.name);

  constructor(private readonly prisma: PrismaService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const method = request.method;
    const url = request.url;
    const body = request.body;
    const startTime = Date.now();

    return next.handle().pipe(
      tap(async (response) => {
        const duration = Date.now() - startTime;
        const statusCode = context.switchToHttp().getResponse().statusCode;

        const auditLogData = {
          timestamp: new Date().toISOString(),
          userId: user?.id || null,
          userEmail: user?.email || null,
          action: `${method} ${url}`,
          method,
          url,
          requestBody: this.sanitizeBody(body),
          statusCode,
          durationMs: duration,
          ip: request.ip,
          userAgent: request.headers['user-agent'],
        };

        // Persist to database via Prisma — fire and forget
        try {
          await this.prisma.auditLog.create({
            data: {
              userId: auditLogData.userId,
              action: auditLogData.action,
              entityType: 'HTTP_REQUEST',
              entityId: `${auditLogData.method}_${auditLogData.url}`,
              newValues: JSON.stringify({
                requestBody: auditLogData.requestBody,
                statusCode: auditLogData.statusCode,
                durationMs: auditLogData.durationMs,
                timestamp: auditLogData.timestamp,
              }),
              ipAddress: auditLogData.ip,
              userAgent: auditLogData.userAgent,
            },
          });
        } catch (err) {
          // Never crash the response if audit write fails
          this.logger.warn(
            `Audit log persistence failed: ${err instanceof Error ? err.message : 'unknown error'}`,
          );
        }

        this.logger.log(
          `[AUDIT] ${auditLogData.method} ${auditLogData.url} - ${auditLogData.statusCode} - ${auditLogData.durationMs}ms - User: ${auditLogData.userEmail || 'anonymous'}`,
        );
      }),
    );
  }

  private sanitizeBody(body: any): any {
    if (!body) return body;
    const sanitized = { ...body };
    const sensitiveFields = ['password', 'newPassword', 'oldPassword', 'token', 'accessToken', 'refreshToken'];
    for (const field of sensitiveFields) {
      if (field in sanitized) {
        sanitized[field] = '***REDACTED***';
      }
    }
    return sanitized;
  }
}
