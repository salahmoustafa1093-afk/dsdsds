import {
  Injectable,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  AccountType,
  MovementType,
  InvoiceStatus,
  UserStatus,
  JournalStatus,
  DeliveryStatus,
  FeedFormulaStatus,
  CashTransactionType,
  Prisma,
} from '@prisma/client';

// ─────────────────────────────────────────────────────────────
// Types & Interfaces
// ─────────────────────────────────────────────────────────────

interface IncomeStatement {
  revenue: number;
  cogs: number;
  grossProfit: number;
  grossMargin: number;
  operatingExpenses: number;
  operatingIncome: number;
  financeCosts: number;
  netIncome: number;
  netMargin: number;
  monthlyData: Array<{
    month: string;
    revenue: number;
    cogs: number;
    grossProfit: number;
    operatingExpenses: number;
    operatingIncome: number;
    netIncome: number;
  }>;
  period: { startDate: Date; endDate: Date };
}

interface BalanceSheet {
  assets: {
    total: number;
    current: number;
    fixed: number;
    cash: number;
    accountsReceivable: number;
    inventory: number;
    fixedAssets: number;
  };
  liabilities: {
    total: number;
    current: number;
    longTerm: number;
    accountsPayable: number;
    shortTermLoans: number;
    vatPayable: number;
  };
  equity: {
    total: number;
    capital: number;
    retainedEarnings: number;
  };
  asOfDate: Date;
}

interface CashFlowStatement {
  operating: number;
  investing: number;
  financing: number;
  netChange: number;
  openingBalance: number;
  closingBalance: number;
  details: {
    collectionsFromCustomers: number;
    paymentsToSuppliers: number;
    operatingExpensePayments: number;
    assetPurchases: number;
    assetSales: number;
    loanProceeds: number;
    loanRepayments: number;
    capitalInjections: number;
    dividendsPaid: number;
  };
}

interface BranchPerformance {
  branchId: string;
  name: string;
  revenue: number;
  expenses: number;
  profit: number;
  profitMargin: number;
  employeeCount: number;
  activeCustomers: number;
  growthPercent: number;
  rank: number;
}

interface ProductProfitability {
  productId: string;
  name: string;
  code: string;
  revenue: number;
  cogs: number;
  unitsSold: number;
  profit: number;
  marginPercent: number;
  rank: number;
}

interface CustomerAging {
  customers: Array<{
    customerId: string;
    name: string;
    totalAR: number;
    current: number;
    bucket1: number;
    bucket2: number;
    bucket3: number;
    bucket4: number;
    status: 'current' | 'warning' | 'critical';
  }>;
  totals: {
    current: number;
    bucket1: number;
    bucket2: number;
    bucket3: number;
    bucket4: number;
    grandTotal: number;
  };
}

interface InventoryValuation {
  totalValue: number;
  byWarehouse: Array<{
    warehouseId: string;
    name: string;
    value: number;
    itemCount: number;
  }>;
  slowMoving: Array<{
    productId: string;
    name: string;
    code: string;
    currentQuantity: number;
    avgCost: number;
    totalValue: number;
    lastMovementDate: Date | null;
    daysSinceMovement: number;
  }>;
  turnoverRatio: number | null;
}

interface SalesTrend {
  period: string;
  revenue: number;
  units: number;
  invoices: number;
  aov: number;
  yoyGrowthPercent: number | null;
}

interface DeliveryPerformance {
  onTimePercent: number;
  avgDeliveryTimeHours: number;
  failedPercent: number;
  totalDeliveries: number;
  byDriver: Array<{
    driverId: string;
    driverName: string;
    totalDeliveries: number;
    onTimeDeliveries: number;
    onTimePercent: number;
    avgDeliveryTimeHours: number;
    failedDeliveries: number;
  }>;
  byBranch: Array<{
    branchId: string;
    branchName: string;
    totalDeliveries: number;
    onTimeDeliveries: number;
    onTimePercent: number;
    failedDeliveries: number;
  }>;
}

interface FeedCostReport {
  formulas: Array<{
    formulaId: string;
    name: string;
    targetAnimal: string;
    costPerTon: number;
    latestCostDate: Date;
    margin: number | null;
  }>;
  ingredientTrends: Array<{
    ingredientName: string;
    prices: Array<{ date: Date; costPerKg: number }>;
    trend: 'rising' | 'stable' | 'falling';
    percentChange: number;
  }>;
  margins: Array<{
    formulaId: string;
    formulaName: string;
    costPerTon: number;
    sellingPrice: number;
    margin: number;
  }>;
  savingsPotential: number;
}

// ─────────────────────────────────────────────────────────────
// Service
// ─────────────────────────────────────────────────────────────

@Injectable()
export class ReportsService {
  private readonly logger = new Logger(ReportsService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════════════════════
  // 1. PROFIT & LOSS STATEMENT (Income Statement)
  // ═══════════════════════════════════════════════════════════

  /**
   * Generate a full Income Statement (Profit & Loss) for a company
   * over a specified period with monthly breakdown.
   */
  async generateIncomeStatement(
    companyId: string,
    startDate: Date | string,
    endDate: Date | string,
  ): Promise<IncomeStatement> {
    const start = startDate instanceof Date ? startDate : new Date(startDate);
    const end = endDate instanceof Date ? endDate : new Date(endDate);

    // Revenue: sum of all confirmed/paid/delivered invoices
    const invoices = await this.prisma.salesInvoice.findMany({
      where: {
        branch: { companyId },
        createdAt: { gte: start, lte: end },
        status: {
          in: [
            InvoiceStatus.CONFIRMED,
            InvoiceStatus.DELIVERED,
            InvoiceStatus.PAID,
            InvoiceStatus.PARTIALLY_PAID,
          ],
        },
        deletedAt: null,
      },
      include: {
        lines: { include: { product: { select: { avgCost: true } } } },
      },
    });

    const revenue = invoices.reduce(
      (sum, inv) => sum + Number(inv.totalAmount),
      0,
    );

    // COGS: Calculate from invoice lines using product avgCost
    let cogs = 0;
    for (const inv of invoices) {
      for (const line of inv.lines) {
        const costPerUnit = Number(line.product?.avgCost || 0);
        cogs += costPerUnit * Number(line.quantity);
      }
    }

    // If no COGS from invoice lines, estimate from stock movements
    if (cogs === 0) {
      const stockIssues = await this.prisma.stockMovement.findMany({
        where: {
          warehouse: { branch: { companyId } },
          type: MovementType.ISSUE,
          createdAt: { gte: start, lte: end },
        },
      });
      cogs = stockIssues.reduce(
        (sum, sm) => sum + Number(sm.totalCost || sm.unitCost || 0) * Number(sm.quantity),
        0,
      );
    }

    const grossProfit = revenue - cogs;
    const grossMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;

    // Operating Expenses: from journal entries for expense accounts
    const expenseAccounts = await this.prisma.chartOfAccount.findMany({
      where: { companyId, type: AccountType.EXPENSE, status: UserStatus.ACTIVE },
      select: { id: true },
    });
    const expenseAccountIds = expenseAccounts.map((ea) => ea.id);

    const journalLines = await this.prisma.journalEntryLine.findMany({
      where: {
        accountId: { in: expenseAccountIds },
        entry: {
          companyId,
          date: { gte: start, lte: end },
          status: JournalStatus.POSTED,
        },
      },
      include: { entry: true },
    });

    const operatingExpenses = journalLines.reduce(
      (sum, jl) => sum + Number(jl.debit),
      0,
    );

    const operatingIncome = grossProfit - operatingExpenses;

    // Finance costs: interest expense accounts
    const financeAccountNames = ['interest', 'finance', 'bank charges', 'loan'];
    const financeAccounts = await this.prisma.chartOfAccount.findMany({
      where: {
        companyId,
        type: AccountType.EXPENSE,
        status: UserStatus.ACTIVE,
        OR: financeAccountNames.map((name) => ({
          nameEn: { contains: name, mode: 'insensitive' as const },
        })),
      },
      select: { id: true },
    });
    const financeAccountIds = financeAccounts.map((fa) => fa.id);

    const financeJournalLines = await this.prisma.journalEntryLine.findMany({
      where: {
        accountId: { in: financeAccountIds },
        entry: {
          companyId,
          date: { gte: start, lte: end },
          status: JournalStatus.POSTED,
        },
      },
    });

    const financeCosts = financeJournalLines.reduce(
      (sum, jl) => sum + Number(jl.debit),
      0,
    );

    const netIncome = operatingIncome - financeCosts;
    const netMargin = revenue > 0 ? (netIncome / revenue) * 100 : 0;

    // Monthly breakdown
    const monthlyData = await this.generateMonthlyBreakdown(
      companyId,
      start,
      end,
      expenseAccountIds,
      financeAccountIds,
    );

    return {
      revenue: Math.round(revenue * 100) / 100,
      cogs: Math.round(cogs * 100) / 100,
      grossProfit: Math.round(grossProfit * 100) / 100,
      grossMargin: Math.round(grossMargin * 100) / 100,
      operatingExpenses: Math.round(operatingExpenses * 100) / 100,
      operatingIncome: Math.round(operatingIncome * 100) / 100,
      financeCosts: Math.round(financeCosts * 100) / 100,
      netIncome: Math.round(netIncome * 100) / 100,
      netMargin: Math.round(netMargin * 100) / 100,
      monthlyData,
      period: { startDate: start, endDate: end },
    };
  }

  private async generateMonthlyBreakdown(
    companyId: string,
    start: Date,
    end: Date,
    expenseAccountIds: string[],
    financeAccountIds: string[],
  ): Promise<IncomeStatement['monthlyData']> {
    const months: IncomeStatement['monthlyData'] = [];
    let current = new Date(start.getFullYear(), start.getMonth(), 1);
    const finalMonth = new Date(end.getFullYear(), end.getMonth(), 1);

    while (current <= finalMonth) {
      const monthStart = new Date(current);
      const monthEnd = new Date(
        current.getFullYear(),
        current.getMonth() + 1,
        0,
        23,
        59,
        59,
      );

      const monthInvoices = await this.prisma.salesInvoice.findMany({
        where: {
          branch: { companyId },
          createdAt: { gte: monthStart, lte: monthEnd },
          status: {
            in: [
              InvoiceStatus.CONFIRMED,
              InvoiceStatus.DELIVERED,
              InvoiceStatus.PAID,
              InvoiceStatus.PARTIALLY_PAID,
            ],
          },
          deletedAt: null,
        },
        include: {
          lines: { include: { product: { select: { avgCost: true } } } },
        },
      });

      const monthRevenue = monthInvoices.reduce(
        (sum, inv) => sum + Number(inv.totalAmount),
        0,
      );

      let monthCogs = 0;
      for (const inv of monthInvoices) {
        for (const line of inv.lines) {
          monthCogs +=
            Number(line.product?.avgCost || 0) * Number(line.quantity);
        }
      }

      const monthGrossProfit = monthRevenue - monthCogs;

      const monthExpenseLines = await this.prisma.journalEntryLine.findMany({
        where: {
          accountId: { in: expenseAccountIds },
          entry: {
            companyId,
            date: { gte: monthStart, lte: monthEnd },
            status: JournalStatus.POSTED,
          },
        },
      });
      const monthOpEx = monthExpenseLines.reduce(
        (sum, jl) => sum + Number(jl.debit),
        0,
      );

      const monthFinanceLines = await this.prisma.journalEntryLine.findMany({
        where: {
          accountId: { in: financeAccountIds },
          entry: {
            companyId,
            date: { gte: monthStart, lte: monthEnd },
            status: JournalStatus.POSTED,
          },
        },
      });
      const monthFinance = monthFinanceLines.reduce(
        (sum, jl) => sum + Number(jl.debit),
        0,
      );

      const monthOperatingIncome = monthGrossProfit - monthOpEx;
      const monthNetIncome = monthOperatingIncome - monthFinance;

      months.push({
        month: monthStart.toISOString().slice(0, 7),
        revenue: Math.round(monthRevenue * 100) / 100,
        cogs: Math.round(monthCogs * 100) / 100,
        grossProfit: Math.round(monthGrossProfit * 100) / 100,
        operatingExpenses: Math.round(monthOpEx * 100) / 100,
        operatingIncome: Math.round(monthOperatingIncome * 100) / 100,
        netIncome: Math.round(monthNetIncome * 100) / 100,
      });

      current.setMonth(current.getMonth() + 1);
    }

    return months;
  }

  // ═══════════════════════════════════════════════════════════
  // 2. BALANCE SHEET
  // ═══════════════════════════════════════════════════════════

  /**
   * Generate a Balance Sheet as of a specific date.
   */
  async generateBalanceSheet(
    companyId: string,
    asOfDate?: Date | string,
  ): Promise<BalanceSheet> {
    const asOf = asOfDate
      ? asOfDate instanceof Date
        ? asOfDate
        : new Date(asOfDate)
      : new Date();
    const endOfDay = new Date(asOf);
    endOfDay.setHours(23, 59, 59, 999);

    // ── Assets ──

    // Cash: Bank accounts + cash transactions
    const bankAccounts = await this.prisma.bankAccount.findMany({
      where: { companyId, status: UserStatus.ACTIVE },
    });
    const cash = bankAccounts.reduce(
      (sum, ba) => sum + Number(ba.currentBalance),
      0,
    );

    // Cash transactions (treasury) — CashTransaction has no companyId field
    const cashTransactions = await this.prisma.cashTransaction.findMany({
      where: {
        date: { lte: endOfDay },
      },
    });
    const cashBalance = cashTransactions.reduce((sum, ct) => {
      return ct.type === CashTransactionType.RECEIPT
        ? sum + Number(ct.amount)
        : sum - Number(ct.amount);
    }, 0);

    const totalCash = cash + cashBalance;

    // Accounts Receivable: unpaid invoices
    const arInvoices = await this.prisma.salesInvoice.findMany({
      where: {
        branch: { companyId },
        status: {
          in: [
            InvoiceStatus.CONFIRMED,
            InvoiceStatus.DELIVERED,
            InvoiceStatus.PARTIALLY_PAID,
            InvoiceStatus.OVERDUE,
          ],
        },
        deletedAt: null,
      },
    });
    const accountsReceivable = arInvoices.reduce(
      (sum, inv) => sum + Number(inv.balance),
      0,
    );

    // Inventory valuation
    const stocks = await this.prisma.stockMovement.findMany({
      where: {
        warehouse: { branch: { companyId } },
        type: { in: [MovementType.RECEIPT, MovementType.ADJUSTMENT] },
        createdAt: { lte: endOfDay },
      },
      include: { product: { select: { avgCost: true } } },
    });

    const inventoryMap: Record<string, { qty: number; cost: number }> = {};
    for (const sm of stocks) {
      const pid = sm.productId;
      if (!inventoryMap[pid]) {
        inventoryMap[pid] = { qty: 0, cost: Number(sm.product?.avgCost || sm.unitCost || 0) };
      }
      inventoryMap[pid].qty += Number(sm.quantity);
    }

    // Subtract issues
    const issues = await this.prisma.stockMovement.findMany({
      where: {
        warehouse: { branch: { companyId } },
        type: MovementType.ISSUE,
        createdAt: { lte: endOfDay },
      },
    });
    for (const issue of issues) {
      const pid = issue.productId;
      if (inventoryMap[pid]) {
        inventoryMap[pid].qty -= Number(issue.quantity);
      }
    }

    const inventory = Object.values(inventoryMap).reduce(
      (sum, item) => sum + item.qty * item.cost,
      0,
    );

    // Fixed assets from chart of accounts
    const assetAccounts = await this.prisma.chartOfAccount.findMany({
      where: {
        companyId,
        type: AccountType.ASSET,
        status: UserStatus.ACTIVE,
        nameEn: { contains: 'fixed', mode: 'insensitive' as const },
      },
    });
    const fixedAssets = assetAccounts.reduce(
      (sum, aa) => sum + Number(aa.balance),
      0,
    );

    const currentAssets = totalCash + accountsReceivable + inventory;
    const totalAssets = currentAssets + fixedAssets;

    // ── Liabilities ──

    // Accounts Payable: unpaid purchase orders
    const apOrders = await this.prisma.purchaseOrder.findMany({
      where: {
        branch: { companyId },
        status: { in: [InvoiceStatus.CONFIRMED, InvoiceStatus.PENDING, InvoiceStatus.PARTIALLY_PAID] },
        deletedAt: null,
      },
    });
    const accountsPayable = apOrders.reduce(
      (sum, po) => sum + Number(po.totalAmount),
      0,
    );

    // Short-term loans (liability accounts)
    const liabilityAccounts = await this.prisma.chartOfAccount.findMany({
      where: {
        companyId,
        type: AccountType.LIABILITY,
        status: UserStatus.ACTIVE,
      },
    });

    const loanAccounts = liabilityAccounts.filter((la) =>
      la.nameEn.toLowerCase().includes('loan'),
    );
    const shortTermLoans = loanAccounts.reduce(
      (sum, la) => sum + Number(la.balance),
      0,
    );

    // VAT payable
    const vatAccounts = liabilityAccounts.filter(
      (la) =>
        la.nameEn.toLowerCase().includes('vat') ||
        la.nameEn.toLowerCase().includes('tax'),
    );
    const vatPayable = vatAccounts.reduce(
      (sum, va) => sum + Number(va.balance),
      0,
    );

    const currentLiabilities = accountsPayable + shortTermLoans + vatPayable;
    const totalLiabilities = currentLiabilities;

    // ── Equity ──

    const equityAccounts = await this.prisma.chartOfAccount.findMany({
      where: {
        companyId,
        type: AccountType.EQUITY,
        status: UserStatus.ACTIVE,
      },
    });

    const capitalAccounts = equityAccounts.filter((ea) =>
      ea.nameEn.toLowerCase().includes('capital'),
    );
    const capital = capitalAccounts.reduce(
      (sum, ca) => sum + Number(ca.balance),
      0,
    );

    const retainedEarningsAccounts = equityAccounts.filter(
      (ea) =>
        ea.nameEn.toLowerCase().includes('retained') ||
        ea.nameEn.toLowerCase().includes('earnings') ||
        ea.nameEn.toLowerCase().includes('profit'),
    );
    const retainedEarnings = retainedEarningsAccounts.reduce(
      (sum, rea) => sum + Number(rea.balance),
      0,
    );

    // Add net income since fiscal year start to retained earnings
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: { fiscalYearStart: true },
    });
    const fyStart = company?.fiscalYearStart || new Date(asOf.getFullYear(), 0, 1);

    const { netIncome } = await this.generateIncomeStatement(
      companyId,
      fyStart,
      asOf,
    ).catch(() => ({ netIncome: 0 }));

    const totalRetainedEarnings = retainedEarnings + netIncome;
    const totalEquity = capital + totalRetainedEarnings;

    return {
      assets: {
        total: Math.round(totalAssets * 100) / 100,
        current: Math.round(currentAssets * 100) / 100,
        fixed: Math.round(fixedAssets * 100) / 100,
        cash: Math.round(totalCash * 100) / 100,
        accountsReceivable: Math.round(accountsReceivable * 100) / 100,
        inventory: Math.round(inventory * 100) / 100,
        fixedAssets: Math.round(fixedAssets * 100) / 100,
      },
      liabilities: {
        total: Math.round(totalLiabilities * 100) / 100,
        current: Math.round(currentLiabilities * 100) / 100,
        longTerm: 0,
        accountsPayable: Math.round(accountsPayable * 100) / 100,
        shortTermLoans: Math.round(shortTermLoans * 100) / 100,
        vatPayable: Math.round(vatPayable * 100) / 100,
      },
      equity: {
        total: Math.round(totalEquity * 100) / 100,
        capital: Math.round(capital * 100) / 100,
        retainedEarnings: Math.round(totalRetainedEarnings * 100) / 100,
      },
      asOfDate: asOf,
    };
  }


  // ═══════════════════════════════════════════════════════════
  // 3. CASH FLOW STATEMENT
  // ═══════════════════════════════════════════════════════════

  /**
   * Generate a Cash Flow Statement for a period.
   */
  async generateCashFlow(
    companyId: string,
    startDate: Date | string,
    endDate: Date | string,
  ): Promise<CashFlowStatement> {
    const start = startDate instanceof Date ? startDate : new Date(startDate);
    const end = endDate instanceof Date ? endDate : new Date(endDate);

    // ── Operating Activities ──

    // Collections from customers (paid invoices + partial payments)
    const paidInvoices = await this.prisma.salesInvoice.findMany({
      where: {
        branch: { companyId },
        status: { in: [InvoiceStatus.PAID, InvoiceStatus.PARTIALLY_PAID] },
        deletedAt: null,
      },
    });
    const collectionsFromCustomers = paidInvoices.reduce(
      (sum, inv) => sum + Number(inv.paidAmount),
      0,
    );

    // Payments to suppliers (treasury outflows categorized as supplier payments)
    // CashTransaction has no companyId; filter by type and category only
    const supplierPayments = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.PAYMENT,
        category: { contains: 'supplier', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const paymentsToSuppliers = supplierPayments.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    // Operating expense payments
    const opExPayments = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.PAYMENT,
        category: { contains: 'expense', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const operatingExpensePayments = opExPayments.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    const operating =
      collectionsFromCustomers -
      paymentsToSuppliers -
      operatingExpensePayments;

    // ── Investing Activities ──

    // Asset purchases
    const assetPurchases = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.PAYMENT,
        category: { contains: 'asset', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const assetPurchaseAmount = assetPurchases.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    // Asset sales
    const assetSales = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.RECEIPT,
        category: { contains: 'asset', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const assetSaleAmount = assetSales.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    const investing = assetSaleAmount - assetPurchaseAmount;

    // ── Financing Activities ──

    // Loan proceeds
    const loanProceeds = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.RECEIPT,
        category: { contains: 'loan', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const loanProceedsAmount = loanProceeds.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    // Loan repayments
    const loanRepayments = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.PAYMENT,
        category: { contains: 'loan', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const loanRepaymentAmount = loanRepayments.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    // Capital injections
    const capitalInjections = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.RECEIPT,
        category: { contains: 'capital', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const capitalInjectionAmount = capitalInjections.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    // Dividends paid
    const dividends = await this.prisma.cashTransaction.findMany({
      where: {
        type: CashTransactionType.PAYMENT,
        category: { contains: 'dividend', mode: 'insensitive' as const },
        date: { gte: start, lte: end },
      },
    });
    const dividendAmount = dividends.reduce(
      (sum, ct) => sum + Number(ct.amount),
      0,
    );

    const financing =
      loanProceedsAmount -
      loanRepaymentAmount +
      capitalInjectionAmount -
      dividendAmount;

    const netChange = operating + investing + financing;

    // Opening and closing balances
    const openingBankBalance = await this.getBankBalanceAsOf(companyId, start);
    const closingBankBalance = openingBankBalance + netChange;

    return {
      operating: Math.round(operating * 100) / 100,
      investing: Math.round(investing * 100) / 100,
      financing: Math.round(financing * 100) / 100,
      netChange: Math.round(netChange * 100) / 100,
      openingBalance: Math.round(openingBankBalance * 100) / 100,
      closingBalance: Math.round(closingBankBalance * 100) / 100,
      details: {
        collectionsFromCustomers: Math.round(collectionsFromCustomers * 100) / 100,
        paymentsToSuppliers: Math.round(paymentsToSuppliers * 100) / 100,
        operatingExpensePayments: Math.round(operatingExpensePayments * 100) / 100,
        assetPurchases: Math.round(assetPurchaseAmount * 100) / 100,
        assetSales: Math.round(assetSaleAmount * 100) / 100,
        loanProceeds: Math.round(loanProceedsAmount * 100) / 100,
        loanRepayments: Math.round(loanRepaymentAmount * 100) / 100,
        capitalInjections: Math.round(capitalInjectionAmount * 100) / 100,
        dividendsPaid: Math.round(dividendAmount * 100) / 100,
      },
    };
  }

  private async getBankBalanceAsOf(
    companyId: string,
    _date: Date,
  ): Promise<number> {
    // BankAccount stores currentBalance directly; no historical snapshots
    const bankAccounts = await this.prisma.bankAccount.findMany({
      where: { companyId, status: UserStatus.ACTIVE },
    });
    return bankAccounts.reduce(
      (sum, ba) => sum + Number(ba.currentBalance),
      0,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 4. BRANCH PERFORMANCE COMPARISON
  // ═══════════════════════════════════════════════════════════

  /**
   * Compare performance across all branches.
   */
  async generateBranchComparison(
    companyId: string,
    startDate: Date | string,
    endDate: Date | string,
  ): Promise<BranchPerformance[]> {
    const start = startDate instanceof Date ? startDate : new Date(startDate);
    const end = endDate instanceof Date ? endDate : new Date(endDate);

    const branches = await this.prisma.branch.findMany({
      where: { companyId, status: UserStatus.ACTIVE },
    });

    const results: BranchPerformance[] = [];

    for (const branch of branches) {
      // Revenue from invoices
      const invoices = await this.prisma.salesInvoice.findMany({
        where: {
          branchId: branch.id,
          createdAt: { gte: start, lte: end },
          status: {
            in: [
              InvoiceStatus.CONFIRMED,
              InvoiceStatus.DELIVERED,
              InvoiceStatus.PAID,
              InvoiceStatus.PARTIALLY_PAID,
            ],
          },
          deletedAt: null,
        },
      });
      const revenue = invoices.reduce(
        (sum, inv) => sum + Number(inv.totalAmount),
        0,
      );

      // Expenses from journal entries for this branch
      const expenseLines = await this.prisma.journalEntryLine.findMany({
        where: {
          entry: {
            companyId,
            date: { gte: start, lte: end },
            status: JournalStatus.POSTED,
          },
        },
        include: {
          account: true,
          entry: true,
        },
      });
      const expenses = expenseLines
        .filter((el) => el.account.type === AccountType.EXPENSE)
        .reduce((sum, el) => sum + Number(el.debit), 0);

      const profit = revenue - expenses;
      const profitMargin = revenue > 0 ? (profit / revenue) * 100 : 0;

      // Employee count
      const employeeCount = await this.prisma.employee.count({
        where: {
          branchId: branch.id,
          companyId,
          deletedAt: null,
          status: UserStatus.ACTIVE,
        },
      });

      // Active customers — Customer has status enum, not isActive boolean
      const activeCustomers = await this.prisma.customer.count({
        where: {
          branchId: branch.id,
          companyId,
          deletedAt: null,
          status: UserStatus.ACTIVE,
        },
      });

      // Calculate growth: compare to previous period
      const prevPeriodDays = Math.floor(
        (end.getTime() - start.getTime()) / 86400000,
      );
      const prevStart = new Date(start);
      prevStart.setDate(prevStart.getDate() - prevPeriodDays);
      const prevEnd = new Date(start);
      prevEnd.setDate(prevEnd.getDate() - 1);

      const prevInvoices = await this.prisma.salesInvoice.findMany({
        where: {
          branchId: branch.id,
          createdAt: { gte: prevStart, lte: prevEnd },
          status: {
            in: [
              InvoiceStatus.CONFIRMED,
              InvoiceStatus.DELIVERED,
              InvoiceStatus.PAID,
              InvoiceStatus.PARTIALLY_PAID,
            ],
          },
          deletedAt: null,
        },
      });
      const prevRevenue = prevInvoices.reduce(
        (sum, inv) => sum + Number(inv.totalAmount),
        0,
      );

      const growthPercent =
        prevRevenue > 0
          ? ((revenue - prevRevenue) / prevRevenue) * 100
          : 0;

      results.push({
        branchId: branch.id,
        name: branch.name,
        revenue: Math.round(revenue * 100) / 100,
        expenses: Math.round(expenses * 100) / 100,
        profit: Math.round(profit * 100) / 100,
        profitMargin: Math.round(profitMargin * 100) / 100,
        employeeCount,
        activeCustomers,
        growthPercent: Math.round(growthPercent * 100) / 100,
        rank: 0, // filled after sorting
      });
    }

    // Sort by profit and assign ranks
    results.sort((a, b) => b.profit - a.profit);
    results.forEach((r, i) => {
      r.rank = i + 1;
    });

    return results;
  }

  // ═══════════════════════════════════════════════════════════
  // 5. PRODUCT PROFITABILITY REPORT
  // ═══════════════════════════════════════════════════════════

  /**
   * Analyze profitability for each product.
   */
  async generateProductProfitability(
    companyId: string,
    startDate: Date | string,
    endDate: Date | string,
  ): Promise<ProductProfitability[]> {
    const start = startDate instanceof Date ? startDate : new Date(startDate);
    const end = endDate instanceof Date ? endDate : new Date(endDate);

    // Get all invoice lines with product info in the period
    const invoiceLines = await this.prisma.salesInvoiceLine.findMany({
      where: {
        invoice: {
          branch: { companyId },
          createdAt: { gte: start, lte: end },
          status: {
            in: [
              InvoiceStatus.CONFIRMED,
              InvoiceStatus.DELIVERED,
              InvoiceStatus.PAID,
              InvoiceStatus.PARTIALLY_PAID,
            ],
          },
          deletedAt: null,
        },
      },
      include: {
        product: { select: { id: true, name: true, code: true, avgCost: true } },
      },
    });

    // Aggregate by product
    const productMap: Record<
      string,
      {
        revenue: number;
        cogs: number;
        units: number;
        product: { id: string; name: string; code: string };
      }
    > = {};

    for (const line of invoiceLines) {
      const pid = line.productId;
      if (!productMap[pid]) {
        productMap[pid] = {
          revenue: 0,
          cogs: 0,
          units: 0,
          product: line.product,
        };
      }
      const lineRevenue = Number(line.totalPrice);
      const lineUnits = Number(line.quantity);
      const unitCost = Number(line.product?.avgCost || 0);
      const lineCogs = unitCost * lineUnits;

      productMap[pid].revenue += lineRevenue;
      productMap[pid].cogs += lineCogs;
      productMap[pid].units += lineUnits;
    }

    const results: ProductProfitability[] = Object.values(productMap).map(
      (p) => {
        const profit = p.revenue - p.cogs;
        const marginPercent = p.revenue > 0 ? (profit / p.revenue) * 100 : 0;
        return {
          productId: p.product.id,
          name: p.product.name,
          code: p.product.code,
          revenue: Math.round(p.revenue * 100) / 100,
          cogs: Math.round(p.cogs * 100) / 100,
          unitsSold: Math.round(p.units * 1000) / 1000,
          profit: Math.round(profit * 100) / 100,
          marginPercent: Math.round(marginPercent * 100) / 100,
          rank: 0,
        };
      },
    );

    // Sort by profit and assign ranks
    results.sort((a, b) => b.profit - a.profit);
    results.forEach((r, i) => {
      r.rank = i + 1;
    });

    return results;
  }

  // ═══════════════════════════════════════════════════════════
  // 6. CUSTOMER AGING REPORT
  // ═══════════════════════════════════════════════════════════

  /**
   * Generate customer aging report showing outstanding AR by bucket.
   */
  async generateCustomerAging(
    companyId: string,
    asOfDate?: Date | string,
  ): Promise<CustomerAging> {
    const asOf = asOfDate
      ? asOfDate instanceof Date
        ? asOfDate
        : new Date(asOfDate)
      : new Date();
    const asOfTime = asOf.getTime();

    const customers = await this.prisma.customer.findMany({
      where: {
        companyId,
        deletedAt: null,
      },
    });

    const customerAging: CustomerAging['customers'] = [];
    const totals: CustomerAging['totals'] = {
      current: 0,
      bucket1: 0,
      bucket2: 0,
      bucket3: 0,
      bucket4: 0,
      grandTotal: 0,
    };

    for (const customer of customers) {
      // Get unpaid invoices for this customer
      const invoices = await this.prisma.salesInvoice.findMany({
        where: {
          customerId: customer.id,
          status: {
            in: [
              InvoiceStatus.CONFIRMED,
              InvoiceStatus.DELIVERED,
              InvoiceStatus.PARTIALLY_PAID,
              InvoiceStatus.OVERDUE,
            ],
          },
          deletedAt: null,
          balance: { gt: 0 },
        },
      });

      if (invoices.length === 0) continue;

      let totalAR = 0;
      let current = 0;
      let bucket1 = 0;
      let bucket2 = 0;
      let bucket3 = 0;
      let bucket4 = 0;

      for (const inv of invoices) {
        const balance = Number(inv.balance);
        if (balance <= 0) continue;

        totalAR += balance;

        const dueDate = inv.dueDate
          ? inv.dueDate.getTime()
          : inv.createdAt.getTime() + 30 * 86400000;
        const daysOverdue = Math.floor((asOfTime - dueDate) / 86400000);

        if (daysOverdue <= 0) {
          current += balance;
        } else if (daysOverdue <= 30) {
          bucket1 += balance;
        } else if (daysOverdue <= 60) {
          bucket2 += balance;
        } else if (daysOverdue <= 90) {
          bucket3 += balance;
        } else {
          bucket4 += balance;
        }
      }

      if (totalAR <= 0) continue;

      let status: 'current' | 'warning' | 'critical';
      const percentOver90 = totalAR > 0 ? (bucket4 / totalAR) * 100 : 0;
      if (percentOver90 > 25 || totalAR > Number(customer.creditLimit) * 0.8) {
        status = 'critical';
      } else if (bucket3 + bucket4 > current) {
        status = 'warning';
      } else {
        status = 'current';
      }

      customerAging.push({
        customerId: customer.id,
        name: customer.name,
        totalAR: Math.round(totalAR * 100) / 100,
        current: Math.round(current * 100) / 100,
        bucket1: Math.round(bucket1 * 100) / 100,
        bucket2: Math.round(bucket2 * 100) / 100,
        bucket3: Math.round(bucket3 * 100) / 100,
        bucket4: Math.round(bucket4 * 100) / 100,
        status,
      });

      totals.current += current;
      totals.bucket1 += bucket1;
      totals.bucket2 += bucket2;
      totals.bucket3 += bucket3;
      totals.bucket4 += bucket4;
      totals.grandTotal += totalAR;
    }

    // Sort by total AR descending
    customerAging.sort((a, b) => b.totalAR - a.totalAR);

    return {
      customers: customerAging,
      totals: {
        current: Math.round(totals.current * 100) / 100,
        bucket1: Math.round(totals.bucket1 * 100) / 100,
        bucket2: Math.round(totals.bucket2 * 100) / 100,
        bucket3: Math.round(totals.bucket3 * 100) / 100,
        bucket4: Math.round(totals.bucket4 * 100) / 100,
        grandTotal: Math.round(totals.grandTotal * 100) / 100,
      },
    };
  }


  // ═══════════════════════════════════════════════════════════
  // 7. INVENTORY VALUATION REPORT
  // ═══════════════════════════════════════════════════════════

  /**
   * Generate inventory valuation using FIFO method.
   */
  async generateInventoryValuation(
    companyId: string,
  ): Promise<InventoryValuation> {
    // Get all products for this company
    const products = await this.prisma.product.findMany({
      where: { companyId, deletedAt: null, status: UserStatus.ACTIVE },
      include: {
        stockMovements: {
          where: { warehouse: { branch: { companyId } } },
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    const byWarehouse: InventoryValuation['byWarehouse'] = [];
    const slowMoving: InventoryValuation['slowMoving'] = [];
    let totalValue = 0;
    let totalCogs = 0;

    // Get warehouses for grouping
    const warehouses = await this.prisma.warehouse.findMany({
      where: { branch: { companyId } },
      include: { branch: true },
    });

    const warehouseValues: Record<string, { name: string; value: number; itemCount: number }> = {};
    for (const wh of warehouses) {
      warehouseValues[wh.id] = { name: wh.name, value: 0, itemCount: 0 };
    }

    const now = new Date();
    const ninetyDaysAgo = new Date(now.getTime() - 90 * 86400000);

    for (const product of products) {
      const avgCost = Number(product.avgCost || 0);

      // Calculate quantity on hand using FIFO
      let qtyOnHand = 0;
      for (const sm of product.stockMovements) {
        if (
          sm.type === MovementType.RECEIPT ||
          sm.type === MovementType.ADJUSTMENT
        ) {
          qtyOnHand += Number(sm.quantity);
        } else if (sm.type === MovementType.ISSUE) {
          qtyOnHand -= Number(sm.quantity);
        } else if (sm.type === MovementType.RETURN) {
          qtyOnHand += Number(sm.quantity);
        }
      }

      if (qtyOnHand <= 0) continue;

      const itemValue = qtyOnHand * avgCost;
      totalValue += itemValue;

      // Get last movement date
      const lastMovement = product.stockMovements.length > 0
        ? product.stockMovements[product.stockMovements.length - 1]
        : null;
      const lastMovementDate = lastMovement?.createdAt || null;
      const daysSinceMovement = lastMovementDate
        ? Math.floor((now.getTime() - lastMovementDate.getTime()) / 86400000)
        : 999;

      // Check slow-moving (no movement in 90 days)
      if (
        !lastMovementDate ||
        lastMovementDate < ninetyDaysAgo
      ) {
        slowMoving.push({
          productId: product.id,
          name: product.name,
          code: product.code,
          currentQuantity: Math.round(qtyOnHand * 1000) / 1000,
          avgCost: Math.round(avgCost * 10000) / 10000,
          totalValue: Math.round(itemValue * 100) / 100,
          lastMovementDate,
          daysSinceMovement,
        });
      }

      // Accumulate COGS for turnover calculation
      const issues = product.stockMovements.filter(
        (sm) => sm.type === MovementType.ISSUE,
      );
      totalCogs += issues.reduce(
        (sum, sm) => sum + Number(sm.totalCost || sm.unitCost || avgCost) * Number(sm.quantity),
        0,
      );

      // Accumulate by warehouse
      for (const sm of product.stockMovements) {
        if (sm.warehouseId && warehouseValues[sm.warehouseId]) {
          const wh = warehouseValues[sm.warehouseId];
          if (wh.itemCount === 0 || !wh.value) {
            // First time seeing this product in warehouse, add partial value
          }
          wh.value += itemValue * (sm.type === MovementType.RECEIPT ? 1 : 0);
        }
      }
    }

    // Build warehouse summary
    for (const [whId, wh] of Object.entries(warehouseValues)) {
      if (wh.value > 0) {
        // Recalculate properly by warehouse
        const whMovements = await this.prisma.stockMovement.findMany({
          where: {
            warehouseId: whId,
            product: { companyId, deletedAt: null },
          },
          include: { product: { select: { avgCost: true } } },
        });

        const whProductQtys: Record<string, number> = {};
        for (const sm of whMovements) {
          const pid = sm.productId;
          if (!whProductQtys[pid]) whProductQtys[pid] = 0;
          if (
            sm.type === MovementType.RECEIPT ||
            sm.type === MovementType.ADJUSTMENT ||
            sm.type === MovementType.RETURN
          ) {
            whProductQtys[pid] += Number(sm.quantity);
          } else if (sm.type === MovementType.ISSUE) {
            whProductQtys[pid] -= Number(sm.quantity);
          }
        }

        let whValue = 0;
        let whItemCount = 0;
        for (const [pid, qty] of Object.entries(whProductQtys)) {
          if (qty > 0) {
            const product = products.find((p) => p.id === pid);
            if (product) {
              whValue += qty * Number(product.avgCost || 0);
              whItemCount++;
            }
          }
        }

        byWarehouse.push({
          warehouseId: whId,
          name: wh.name,
          value: Math.round(whValue * 100) / 100,
          itemCount: whItemCount,
        });
      }
    }

    // Inventory turnover ratio (COGS / Average Inventory)
    const avgInventory = totalValue;
    const turnoverRatio =
      avgInventory > 0 ? totalCogs / avgInventory : null;

    return {
      totalValue: Math.round(totalValue * 100) / 100,
      byWarehouse,
      slowMoving: slowMoving.sort(
        (a, b) => b.daysSinceMovement - a.daysSinceMovement,
      ),
      turnoverRatio: turnoverRatio !== null ? Math.round(turnoverRatio * 100) / 100 : null,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 8. SALES TREND ANALYSIS
  // ═══════════════════════════════════════════════════════════

  /**
   * Analyze sales trends over time with YoY comparison.
   */
  async generateSalesTrend(
    companyId: string,
    period: 'daily' | 'weekly' | 'monthly' = 'monthly',
    months = 12,
  ): Promise<SalesTrend[]> {
    const end = new Date();
    const start = new Date();
    start.setMonth(start.getMonth() - months);

    const invoices = await this.prisma.salesInvoice.findMany({
      where: {
        branch: { companyId },
        createdAt: { gte: start, lte: end },
        status: {
          in: [
            InvoiceStatus.CONFIRMED,
            InvoiceStatus.DELIVERED,
            InvoiceStatus.PAID,
            InvoiceStatus.PARTIALLY_PAID,
          ],
        },
        deletedAt: null,
      },
      include: { lines: true },
    });

    // Group by period
    const periodMap: Record<
      string,
      { revenue: number; units: number; invoices: number }
    > = {};

    for (const inv of invoices) {
      const date = new Date(inv.createdAt);
      let key: string;

      if (period === 'daily') {
        key = date.toISOString().slice(0, 10);
      } else if (period === 'weekly') {
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        key = weekStart.toISOString().slice(0, 10);
      } else {
        key = date.toISOString().slice(0, 7);
      }

      if (!periodMap[key]) {
        periodMap[key] = { revenue: 0, units: 0, invoices: 0 };
      }

      periodMap[key].revenue += Number(inv.totalAmount);
      periodMap[key].units += inv.lines.reduce(
        (sum, line) => sum + Number(line.quantity),
        0,
      );
      periodMap[key].invoices++;
    }

    // Sort periods and build results
    const sortedKeys = Object.keys(periodMap).sort();
    const results: SalesTrend[] = [];

    // Get previous year data for YoY
    const prevYearStart = new Date(start);
    prevYearStart.setFullYear(prevYearStart.getFullYear() - 1);
    const prevYearEnd = new Date(end);
    prevYearEnd.setFullYear(prevYearEnd.getFullYear() - 1);

    const prevYearInvoices = await this.prisma.salesInvoice.findMany({
      where: {
        branch: { companyId },
        createdAt: { gte: prevYearStart, lte: prevYearEnd },
        status: {
          in: [
            InvoiceStatus.CONFIRMED,
            InvoiceStatus.DELIVERED,
            InvoiceStatus.PAID,
            InvoiceStatus.PARTIALLY_PAID,
          ],
        },
        deletedAt: null,
      },
    });

    const prevYearMap: Record<string, number> = {};
    for (const inv of prevYearInvoices) {
      const date = new Date(inv.createdAt);
      let key: string;
      if (period === 'daily') {
        key = date.toISOString().slice(0, 10);
      } else if (period === 'weekly') {
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        key = weekStart.toISOString().slice(0, 10);
      } else {
        key = date.toISOString().slice(0, 7);
      }
      prevYearMap[key] = (prevYearMap[key] || 0) + Number(inv.totalAmount);
    }

    for (const key of sortedKeys) {
      const data = periodMap[key];
      const aov = data.invoices > 0 ? data.revenue / data.invoices : 0;

      // Calculate YoY growth
      const prevKeyDate = new Date(key + '-01');
      const prevYearKey =
        period === 'monthly'
          ? `${prevKeyDate.getFullYear() - 1}-${key.slice(5)}`
          : key;
      const prevYearRevenue = prevYearMap[prevYearKey] || 0;
      const yoyGrowthPercent =
        prevYearRevenue > 0
          ? ((data.revenue - prevYearRevenue) / prevYearRevenue) * 100
          : null;

      results.push({
        period: key,
        revenue: Math.round(data.revenue * 100) / 100,
        units: Math.round(data.units * 1000) / 1000,
        invoices: data.invoices,
        aov: Math.round(aov * 100) / 100,
        yoyGrowthPercent:
          yoyGrowthPercent !== null
            ? Math.round(yoyGrowthPercent * 100) / 100
            : null,
      });
    }

    return results;
  }

  // ═══════════════════════════════════════════════════════════
  // 9. DELIVERY PERFORMANCE REPORT
  // ═══════════════════════════════════════════════════════════

  /**
   * Analyze delivery performance metrics.
   */
  async generateDeliveryPerformance(
    companyId: string,
    startDate: Date | string,
    endDate: Date | string,
  ): Promise<DeliveryPerformance> {
    const start = startDate instanceof Date ? startDate : new Date(startDate);
    const end = endDate instanceof Date ? endDate : new Date(endDate);

    const deliveries = await this.prisma.deliveryOrder.findMany({
      where: {
        branch: { companyId },
        createdAt: { gte: start, lte: end },
        deletedAt: null,
      },
      include: {
        driver: { select: { id: true, fullName: true } },
        branch: true,
        trackingRecords: { orderBy: { timestamp: 'asc' } },
      },
    });

    const totalDeliveries = deliveries.length;
    if (totalDeliveries === 0) {
      return {
        onTimePercent: 0,
        avgDeliveryTimeHours: 0,
        failedPercent: 0,
        totalDeliveries: 0,
        byDriver: [],
        byBranch: [],
      };
    }

    let onTimeDeliveries = 0;
    let failedDeliveries = 0;
    let totalDeliveryTimeMs = 0;
    let deliveryTimeCount = 0;

    // Driver aggregation
    const driverMap: Record<
      string,
      {
        total: number;
        onTime: number;
        failed: number;
        totalTimeMs: number;
        timeCount: number;
        name: string;
      }
    > = {};

    // Branch aggregation
    const branchMap: Record<
      string,
      { total: number; onTime: number; failed: number; name: string }
    > = {};

    for (const delivery of deliveries) {
      const scheduledDate = delivery.scheduledDate;
      const deliveryDate = delivery.deliveryDate;
      const status = delivery.status;

      // Check failed — DeliveryStatus.FAILED_CLOSED is the correct enum value
      const isFailed = status === DeliveryStatus.FAILED_CLOSED;
      if (isFailed) {
        failedDeliveries++;
      }

      // On-time check: delivered before or on scheduled date
      if (
        deliveryDate &&
        scheduledDate &&
        deliveryDate <= scheduledDate &&
        !isFailed
      ) {
        onTimeDeliveries++;
      }

      // Delivery time calculation
      if (deliveryDate && delivery.createdAt) {
        const dtMs = deliveryDate.getTime() - delivery.createdAt.getTime();
        if (dtMs > 0) {
          totalDeliveryTimeMs += dtMs;
          deliveryTimeCount++;
        }
      }

      // Driver stats — driver is User relation, access fullName directly
      const driverId = delivery.driverId;
      if (driverId) {
        if (!driverMap[driverId]) {
          driverMap[driverId] = {
            total: 0,
            onTime: 0,
            failed: 0,
            totalTimeMs: 0,
            timeCount: 0,
            name: delivery.driver?.fullName || 'Unknown',
          };
        }
        driverMap[driverId].total++;
        if (
          deliveryDate &&
          scheduledDate &&
          deliveryDate <= scheduledDate &&
          !isFailed
        ) {
          driverMap[driverId].onTime++;
        }
        if (isFailed) driverMap[driverId].failed++;
        if (deliveryDate && delivery.createdAt) {
          const dtMs = deliveryDate.getTime() - delivery.createdAt.getTime();
          if (dtMs > 0) {
            driverMap[driverId].totalTimeMs += dtMs;
            driverMap[driverId].timeCount++;
          }
        }
      }

      // Branch stats
      const branchId = delivery.branchId;
      if (!branchMap[branchId]) {
        branchMap[branchId] = {
          total: 0,
          onTime: 0,
          failed: 0,
          name: delivery.branch?.name || 'Unknown',
        };
      }
      branchMap[branchId].total++;
      if (
        deliveryDate &&
        scheduledDate &&
        deliveryDate <= scheduledDate &&
        !isFailed
      ) {
        branchMap[branchId].onTime++;
      }
      if (isFailed) branchMap[branchId].failed++;
    }

    const onTimePercent =
      (onTimeDeliveries / totalDeliveries) * 100;
    const failedPercent =
      (failedDeliveries / totalDeliveries) * 100;
    const avgDeliveryTimeHours =
      deliveryTimeCount > 0
        ? totalDeliveryTimeMs / deliveryTimeCount / 3600000
        : 0;

    const byDriver = Object.entries(driverMap).map(
      ([driverId, d]) => ({
        driverId,
        driverName: d.name,
        totalDeliveries: d.total,
        onTimeDeliveries: d.onTime,
        onTimePercent:
          d.total > 0 ? Math.round((d.onTime / d.total) * 10000) / 100 : 0,
        avgDeliveryTimeHours:
          d.timeCount > 0
            ? Math.round((d.totalTimeMs / d.timeCount / 3600000) * 100) / 100
            : 0,
        failedDeliveries: d.failed,
      }),
    );

    const byBranch = Object.entries(branchMap).map(
      ([branchId, b]) => ({
        branchId,
        branchName: b.name,
        totalDeliveries: b.total,
        onTimeDeliveries: b.onTime,
        onTimePercent:
          b.total > 0 ? Math.round((b.onTime / b.total) * 10000) / 100 : 0,
        failedDeliveries: b.failed,
      }),
    );

    return {
      onTimePercent: Math.round(onTimePercent * 100) / 100,
      avgDeliveryTimeHours: Math.round(avgDeliveryTimeHours * 100) / 100,
      failedPercent: Math.round(failedPercent * 100) / 100,
      totalDeliveries,
      byDriver,
      byBranch,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 10. FEED COST INTELLIGENCE
  // ═══════════════════════════════════════════════════════════

  /**
   * Generate comprehensive feed cost intelligence report.
   */
  async generateFeedCostReport(
    companyId: string,
  ): Promise<FeedCostReport> {
    // Get all feed formulas with latest costs
    const formulas = await this.prisma.feedFormula.findMany({
      include: {
        feedCosts: { orderBy: { effectiveDate: 'desc' }, take: 1 },
        ingredients: {
          include: { product: { select: { avgCost: true } } },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const formulaResults: FeedCostReport['formulas'] = [];
    const margins: FeedCostReport['margins'] = [];

    for (const formula of formulas) {
      const latestCost = formula.feedCosts[0];
      if (!latestCost) continue;

      formulaResults.push({
        formulaId: formula.id,
        name: formula.name,
        targetAnimal: formula.targetAnimal,
        costPerTon: Number(latestCost.costPerTon),
        latestCostDate: latestCost.effectiveDate,
        margin: latestCost.margin ? Number(latestCost.margin) : null,
      });

      // Margin analysis: compare cost to estimated selling price
      // Estimate selling price with 15% markup as baseline
      const costPerTon = Number(latestCost.costPerTon);
      const estimatedSellingPrice = costPerTon * 1.15;
      const margin = estimatedSellingPrice - costPerTon;

      margins.push({
        formulaId: formula.id,
        formulaName: formula.name,
        costPerTon: Math.round(costPerTon * 100) / 100,
        sellingPrice: Math.round(estimatedSellingPrice * 100) / 100,
        margin: Math.round(margin * 100) / 100,
      });
    }

    // Ingredient price trends
    const allIngredients = await this.prisma.feedFormulaIngredient.findMany({
      include: {
        formula: true,
      },
      orderBy: { ingredientName: 'asc' },
    });

    // Group ingredients by name and track price history
    const ingredientHistory: Record<
      string,
      Array<{ date: Date; costPerKg: number }>
    > = {};

    for (const ing of allIngredients) {
      const name = ing.ingredientName;
      if (!ingredientHistory[name]) {
        ingredientHistory[name] = [];
      }
      if (ing.costPerKg) {
        ingredientHistory[name].push({
          date: ing.formula.createdAt,
          costPerKg: Number(ing.costPerKg),
        });
      }
    }

    // Also get product cost trends — Product.category is a relation, not a scalar
    // Use categoryId to look up feed products via ProductCategory
    const feedCategoryIds = await this.prisma.productCategory.findMany({
      where: {
        name: { contains: 'feed', mode: 'insensitive' as const },
      },
      select: { id: true },
    });
    const feedCategoryIdList = feedCategoryIds.map((c) => c.id);

    const feedProducts = feedCategoryIdList.length > 0
      ? await this.prisma.product.findMany({
          where: {
            companyId,
            deletedAt: null,
            categoryId: { in: feedCategoryIdList },
          },
          include: {
            stockMovements: {
              where: { type: MovementType.RECEIPT },
              orderBy: { createdAt: 'asc' },
            },
          },
        })
      : [];

    for (const product of feedProducts) {
      const name = product.name;
      if (!ingredientHistory[name]) {
        ingredientHistory[name] = [];
      }
      for (const sm of product.stockMovements) {
        if (sm.unitCost) {
          ingredientHistory[name].push({
            date: sm.createdAt,
            costPerKg: Number(sm.unitCost),
          });
        }
      }
    }

    const ingredientTrends: FeedCostReport['ingredientTrends'] = [];
    for (const [name, prices] of Object.entries(ingredientHistory)) {
      if (prices.length < 1) continue;

      // Sort by date
      prices.sort((a, b) => a.date.getTime() - b.date.getTime());

      const latest = prices[prices.length - 1].costPerKg;
      const earliest = prices[0].costPerKg;
      const percentChange =
        earliest > 0 ? ((latest - earliest) / earliest) * 100 : 0;

      let trend: 'rising' | 'stable' | 'falling';
      if (percentChange > 5) {
        trend = 'rising';
      } else if (percentChange < -5) {
        trend = 'falling';
      } else {
        trend = 'stable';
      }

      // Take last 6 data points to avoid too many
      const recentPrices = prices.slice(-6);

      ingredientTrends.push({
        ingredientName: name,
        prices: recentPrices,
        trend,
        percentChange: Math.round(percentChange * 100) / 100,
      });
    }

    // Savings potential: compare each formula to the lowest cost formula for same target animal
    const animalGroups: Record<string, number[]> = {};
    for (const fr of formulaResults) {
      if (!animalGroups[fr.targetAnimal]) {
        animalGroups[fr.targetAnimal] = [];
      }
      animalGroups[fr.targetAnimal].push(fr.costPerTon);
    }

    let savingsPotential = 0;
    for (const [, costs] of Object.entries(animalGroups)) {
      if (costs.length >= 2) {
        const minCost = Math.min(...costs);
        const avgCost = costs.reduce((s, c) => s + c, 0) / costs.length;
        savingsPotential += (avgCost - minCost) * costs.length;
      }
    }

    return {
      formulas: formulaResults,
      ingredientTrends,
      margins,
      savingsPotential: Math.round(savingsPotential * 100) / 100,
    };
  }


  // ═══════════════════════════════════════════════════════════
  // EXISTING REPORTS (kept for compatibility)
  // ═══════════════════════════════════════════════════════════

  async getFinancialReport(
    companyId: string,
    filters: { startDate?: string; endDate?: string },
  ) {
    interface DateFilter {
      gte?: Date;
      lte?: Date;
    }
    const dateFilter: DateFilter = {};
    if (filters.startDate) dateFilter.gte = new Date(filters.startDate);
    if (filters.endDate) dateFilter.lte = new Date(filters.endDate);

    const invoices = await this.prisma.salesInvoice.findMany({
      where: {
        branch: { companyId },
        createdAt: dateFilter,
        deletedAt: null,
      },
    });

    const totalRevenue = invoices.reduce(
      (sum, i) => sum + Number(i.totalAmount),
      0,
    );
    const totalTax = invoices.reduce(
      (sum, i) => sum + Number(i.taxAmount),
      0,
    );
    const totalPaid = invoices.reduce(
      (sum, i) => sum + Number(i.paidAmount),
      0,
    );

    const bankAccounts = await this.prisma.bankAccount.findMany({
      where: { companyId },
    });

    const treasuryIn = bankAccounts.reduce(
      (sum, ba) => sum + Number(ba.currentBalance),
      0,
    );

    const expenseLines = await this.prisma.journalEntryLine.findMany({
      where: {
        account: { type: AccountType.EXPENSE, companyId },
        entry: { date: dateFilter, status: JournalStatus.POSTED },
      },
    });
    const treasuryOut = expenseLines.reduce(
      (sum, el) => sum + Number(el.debit),
      0,
    );

    return {
      data: {
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        totalTax: Math.round(totalTax * 100) / 100,
        totalPaid: Math.round(totalPaid * 100) / 100,
        totalPending: Math.round((totalRevenue - totalPaid) * 100) / 100,
        treasuryIn: Math.round(treasuryIn * 100) / 100,
        treasuryOut: Math.round(treasuryOut * 100) / 100,
        treasuryBalance: Math.round((treasuryIn - treasuryOut) * 100) / 100,
        invoiceCount: invoices.length,
      },
    };
  }

  async getInventoryReport(companyId: string, warehouseId?: string) {
    interface MovementWhere {
      warehouse: { branch: { companyId: string } };
      warehouseId?: string;
    }
    const where: MovementWhere = {
      warehouse: { branch: { companyId } },
    };
    if (warehouseId) where.warehouseId = warehouseId;

    const movements = await this.prisma.stockMovement.findMany({
      where,
      include: {
        product: {
          select: {
            id: true,
            name: true,
            code: true,
            minStockLevel: true,
            maxStockLevel: true,
            avgCost: true,
          },
        },
        warehouse: { select: { id: true, name: true } },
      },
    });

    // Aggregate quantities per product per warehouse
    interface StockItem {
      product: {
        id: string;
        name: string;
        code: string;
        minStockLevel: Prisma.Decimal;
        maxStockLevel: Prisma.Decimal;
        avgCost: Prisma.Decimal;
      };
      warehouse: { id: string; name: string };
      quantity: number;
      value: number;
    }

    const stockMap: Record<string, StockItem> = {};

    for (const m of movements) {
      const key = `${m.productId}-${m.warehouseId}`;
      if (!stockMap[key]) {
        stockMap[key] = {
          product: m.product,
          warehouse: m.warehouse,
          quantity: 0,
          value: 0,
        };
      }
      if (
        m.type === MovementType.RECEIPT ||
        m.type === MovementType.ADJUSTMENT ||
        m.type === MovementType.RETURN
      ) {
        stockMap[key].quantity += Number(m.quantity);
      } else if (m.type === MovementType.ISSUE) {
        stockMap[key].quantity -= Number(m.quantity);
      }
    }

    const stocks = Object.values(stockMap).filter((s) => s.quantity > 0);
    const totalValue = stocks.reduce(
      (sum, s) => sum + s.quantity * Number(s.product.avgCost || 0),
      0,
    );
    const totalItems = stocks.length;
    const totalQuantity = stocks.reduce((sum, s) => sum + s.quantity, 0);
    const lowStockItems = stocks.filter(
      (s) => s.quantity <= Number(s.product.minStockLevel || 0),
    );

    return {
      data: {
        stocks,
        totalValue: Math.round(totalValue * 100) / 100,
        totalItems,
        totalQuantity: Math.round(totalQuantity * 1000) / 1000,
        lowStockCount: lowStockItems.length,
      },
    };
  }

  async getSalesReport(
    companyId: string,
    filters: { startDate?: string; endDate?: string; groupBy?: string },
  ) {
    interface DateFilter {
      gte?: Date;
      lte?: Date;
    }
    const dateFilter: DateFilter = {};
    if (filters.startDate) dateFilter.gte = new Date(filters.startDate);
    if (filters.endDate) dateFilter.lte = new Date(filters.endDate);

    const invoices = await this.prisma.salesInvoice.findMany({
      where: {
        branch: { companyId },
        createdAt: dateFilter,
        deletedAt: null,
      },
      include: {
        customer: { select: { name: true } },
        lines: true,
      },
    });

    const totalSales = invoices.reduce(
      (sum, i) => sum + Number(i.totalAmount),
      0,
    );
    const totalInvoices = invoices.length;
    const avgOrderValue =
      totalInvoices > 0 ? totalSales / totalInvoices : 0;

    // Top customers
    const customerSales: Record<string, number> = {};
    invoices.forEach((i) => {
      const name = i.customer?.name || 'Unknown';
      customerSales[name] = (customerSales[name] || 0) + Number(i.totalAmount);
    });
    const topCustomers = Object.entries(customerSales)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([name, amount]) => ({ name, amount }));

    return {
      data: {
        totalSales: Math.round(totalSales * 100) / 100,
        totalInvoices,
        avgOrderValue: Math.round(avgOrderValue * 100) / 100,
        topCustomers,
      },
    };
  }

  async getProductionReport(companyId: string) {
    // Use feed formula count as production proxy
    const formulas = await this.prisma.feedFormula.findMany({
      include: { feedCosts: true },
    });

    const totalFormulas = formulas.length;
    const activeFormulas = formulas.filter((f) => f.status === FeedFormulaStatus.ACTIVE).length;
    const totalProductionCost = formulas.reduce((sum, f) => {
      return sum + f.feedCosts.reduce((s, fc) => s + Number(fc.totalCost), 0);
    }, 0);

    return {
      data: {
        totalFormulas,
        activeFormulas,
        totalProductionCost: Math.round(totalProductionCost * 100) / 100,
        avgCostPerFormula:
          totalFormulas > 0
            ? Math.round((totalProductionCost / totalFormulas) * 100) / 100
            : 0,
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // DASHBOARD KPIs
  // ═══════════════════════════════════════════════════════════

  async getDashboardKpis(companyId: string) {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    const [
      totalSales,
      totalInvoices,
      totalCustomers,
      totalProducts,
      lowStockCount,
      totalEmployees,
      activeDeliveries,
      monthlyRevenue,
    ] = await Promise.all([
      this.prisma.salesInvoice.count({
        where: { branch: { companyId }, deletedAt: null },
      }),
      this.prisma.salesInvoice.aggregate({
        where: { branch: { companyId }, deletedAt: null },
        _sum: { totalAmount: true },
      }),
      this.prisma.customer.count({
        where: { companyId, deletedAt: null, status: UserStatus.ACTIVE },
      }),
      this.prisma.product.count({
        where: { companyId, deletedAt: null, status: UserStatus.ACTIVE },
      }),
      this.prisma.stockMovement.count({
        where: {
          warehouse: { branch: { companyId } },
          product: { minStockLevel: { gt: 0 } },
        },
      }),
      this.prisma.employee.count({
        where: {
          companyId,
          deletedAt: null,
          status: UserStatus.ACTIVE,
        },
      }),
      this.prisma.deliveryOrder.count({
        where: {
          branch: { companyId },
          status: {
            in: [
              DeliveryStatus.DRIVER_ASSIGNED,
              DeliveryStatus.IN_TRANSIT,
              DeliveryStatus.AT_CUSTOMER,
            ],
          },
        },
      }),
      this.prisma.salesInvoice.aggregate({
        where: {
          branch: { companyId },
          createdAt: { gte: monthStart, lte: monthEnd },
          deletedAt: null,
        },
        _sum: { totalAmount: true },
      }),
    ]);

    // Calculate monthly expense
    const expenseAccounts = await this.prisma.chartOfAccount.findMany({
      where: { companyId, type: AccountType.EXPENSE, status: UserStatus.ACTIVE },
      select: { id: true },
    });
    const expenseAccountIds = expenseAccounts.map((ea) => ea.id);

    const monthlyExpense = await this.prisma.journalEntryLine.aggregate({
      where: {
        accountId: { in: expenseAccountIds },
        entry: {
          companyId,
          date: { gte: monthStart, lte: monthEnd },
          status: JournalStatus.POSTED,
        },
      },
      _sum: { debit: true },
    });

    return {
      data: {
        totalSales,
        totalRevenue: totalInvoices._sum.totalAmount
          ? Number(totalInvoices._sum.totalAmount)
          : 0,
        totalCustomers,
        totalProducts,
        lowStockCount,
        totalEmployees,
        activeDeliveries,
        monthlyRevenue: monthlyRevenue._sum.totalAmount
          ? Number(monthlyRevenue._sum.totalAmount)
          : 0,
        monthlyExpenses: monthlyExpense._sum.debit
          ? Number(monthlyExpense._sum.debit)
          : 0,
      },
    };
  }
}
