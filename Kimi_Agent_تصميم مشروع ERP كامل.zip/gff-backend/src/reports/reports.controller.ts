import {
  Controller,
  Get,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { ReportsService } from './reports.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  DateRangeQueryDto,
  SalesReportQueryDto,
  AsOfDateQueryDto,
  InventoryReportQueryDto,
  SalesTrendQueryDto,
} from './dto';

@ApiTags('Reports')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('reports')
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  // ═══════════════════════════════════════════════════════════
  // FINANCIAL REPORTS
  // ═══════════════════════════════════════════════════════════

  @Get('income-statement')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Generate Profit & Loss (Income Statement)' })
  @ApiQuery({ name: 'startDate', required: true })
  @ApiQuery({ name: 'endDate', required: true })
  @ApiResponse({ status: 200, description: 'Income statement generated' })
  async getIncomeStatement(
    @CurrentUser('companyId') companyId: string,
    @Query() query: DateRangeQueryDto,
  ) {
    return this.reportsService.generateIncomeStatement(
      companyId,
      query.startDate || new Date(new Date().getFullYear(), 0, 1),
      query.endDate || new Date(),
    );
  }

  @Get('balance-sheet')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Generate Balance Sheet' })
  @ApiQuery({ name: 'asOfDate', required: false })
  @ApiResponse({ status: 200, description: 'Balance sheet generated' })
  async getBalanceSheet(
    @CurrentUser('companyId') companyId: string,
    @Query() query: AsOfDateQueryDto,
  ) {
    return this.reportsService.generateBalanceSheet(
      companyId,
      query.asOfDate,
    );
  }

  @Get('cash-flow')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Generate Cash Flow Statement' })
  @ApiQuery({ name: 'startDate', required: true })
  @ApiQuery({ name: 'endDate', required: true })
  @ApiResponse({ status: 200, description: 'Cash flow statement generated' })
  async getCashFlow(
    @CurrentUser('companyId') companyId: string,
    @Query() query: DateRangeQueryDto,
  ) {
    return this.reportsService.generateCashFlow(
      companyId,
      query.startDate || new Date(new Date().getFullYear(), 0, 1),
      query.endDate || new Date(),
    );
  }

  @Get('financial')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Generate legacy financial report' })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiResponse({ status: 200, description: 'Financial report generated' })
  async getFinancialReport(
    @CurrentUser('companyId') companyId: string,
    @Query() query: DateRangeQueryDto,
  ) {
    return this.reportsService.getFinancialReport(companyId, query);
  }

  // ═══════════════════════════════════════════════════════════
  // SALES REPORTS
  // ═══════════════════════════════════════════════════════════

  @Get('sales')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Generate sales report' })
  @ApiQuery({ name: 'startDate', required: false })
  @ApiQuery({ name: 'endDate', required: false })
  @ApiQuery({ name: 'groupBy', required: false })
  @ApiResponse({ status: 200, description: 'Sales report generated' })
  async getSalesReport(
    @CurrentUser('companyId') companyId: string,
    @Query() query: SalesReportQueryDto,
  ) {
    return this.reportsService.getSalesReport(companyId, query);
  }

  @Get('sales-trend')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Analyze sales trends with YoY comparison' })
  @ApiResponse({ status: 200, description: 'Sales trend analysis generated' })
  async getSalesTrend(
    @CurrentUser('companyId') companyId: string,
    @Query() query: SalesTrendQueryDto,
  ) {
    return this.reportsService.generateSalesTrend(
      companyId,
      query.period,
      query.months,
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INVENTORY REPORTS
  // ═══════════════════════════════════════════════════════════

  @Get('inventory')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Generate inventory report' })
  @ApiQuery({ name: 'warehouseId', required: false })
  @ApiResponse({ status: 200, description: 'Inventory report generated' })
  async getInventoryReport(
    @CurrentUser('companyId') companyId: string,
    @Query() query: InventoryReportQueryDto,
  ) {
    return this.reportsService.getInventoryReport(companyId, query.warehouseId);
  }

  // ═══════════════════════════════════════════════════════════
  // PRODUCTION REPORTS
  // ═══════════════════════════════════════════════════════════

  @Get('production')
  @Permissions('reports:view')
  @ApiOperation({ summary: 'Generate production report' })
  @ApiResponse({ status: 200, description: 'Production report generated' })
  async getProductionReport(@CurrentUser('companyId') companyId: string) {
    return this.reportsService.getProductionReport(companyId);
  }

  // ═══════════════════════════════════════════════════════════
  // DASHBOARD
  // ═══════════════════════════════════════════════════════════

  @Get('dashboard')
  @Permissions('dashboard:view')
  @ApiOperation({ summary: 'Get dashboard KPIs' })
  @ApiResponse({ status: 200, description: 'Dashboard KPIs retrieved' })
  async getDashboardKpis(@CurrentUser('companyId') companyId: string) {
    return this.reportsService.getDashboardKpis(companyId);
  }
}
