import { IsOptional, IsIn, IsInt, Min } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class SalesTrendQueryDto {
  @ApiPropertyOptional({ description: 'Aggregation period', enum: ['daily', 'weekly', 'monthly'], default: 'monthly' })
  @IsOptional()
  @IsIn(['daily', 'weekly', 'monthly'])
  period?: 'daily' | 'weekly' | 'monthly';

  @ApiPropertyOptional({ description: 'Number of months to look back', default: 12 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  months?: number;
}
