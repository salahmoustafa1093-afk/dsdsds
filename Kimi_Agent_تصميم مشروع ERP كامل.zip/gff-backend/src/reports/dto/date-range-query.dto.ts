import { IsOptional, IsDateString, IsString } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class DateRangeQueryDto {
  @ApiPropertyOptional({ description: 'Start date (ISO 8601)', example: '2024-01-01' })
  @IsOptional()
  @IsDateString()
  startDate?: string;

  @ApiPropertyOptional({ description: 'End date (ISO 8601)', example: '2024-12-31' })
  @IsOptional()
  @IsDateString()
  endDate?: string;
}

export class SalesReportQueryDto extends DateRangeQueryDto {
  @ApiPropertyOptional({ description: 'Group results by field', example: 'customer' })
  @IsOptional()
  @IsString()
  groupBy?: string;
}

export class AsOfDateQueryDto {
  @ApiPropertyOptional({ description: 'As-of date for the report (ISO 8601)', example: '2024-12-31' })
  @IsOptional()
  @IsDateString()
  asOfDate?: string;
}
