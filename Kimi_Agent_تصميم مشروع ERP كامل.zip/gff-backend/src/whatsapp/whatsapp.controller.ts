import {
  Controller,
  Post,
  Body,
  Get,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { WhatsappService } from './whatsapp.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import { Public } from '@/common/decorators/public.decorator';

@ApiTags('WhatsApp')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('whatsapp')
export class WhatsappController {
  constructor(private readonly whatsappService: WhatsappService) {}

  @Post('send')
  @Permissions('sales:create')
  @ApiOperation({ summary: 'Send WhatsApp message' })
  @ApiResponse({ status: 201, description: 'Message sent' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async sendMessage(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: { to: string; body: string; type?: string },
  ) {
    return this.whatsappService.sendMessage(companyId, dto);
  }

  @Post('send-template')
  @Permissions('sales:create')
  @ApiOperation({ summary: 'Send template message' })
  @ApiResponse({ status: 201, description: 'Template message sent' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async sendTemplate(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: { to: string; templateName: string; languageCode?: string; components?: any[] },
  ) {
    return this.whatsappService.sendTemplate(companyId, dto);
  }

  @Public()
  @Get('webhook')
  @ApiOperation({ summary: 'Webhook verification (GET)' })
  @ApiQuery({ name: 'hub.mode', required: true })
  @ApiQuery({ name: 'hub.verify_token', required: true })
  @ApiQuery({ name: 'hub.challenge', required: true })
  @ApiResponse({ status: 200, description: 'Webhook verified' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async verifyWebhook(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
  ) {
    return this.whatsappService.verifyWebhook(mode, token, challenge);
  }

  @Public()
  @Post('webhook')
  @ApiOperation({ summary: 'Webhook receive (POST)' })
  @ApiResponse({ status: 200, description: 'Webhook processed' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async receiveWebhook(@Body() body: any) {
    return this.whatsappService.processWebhook(body);
  }

  @Get('messages')
  @Permissions('sales:view')
  @ApiOperation({ summary: 'List sent messages' })
  @ApiResponse({ status: 200, description: 'Messages retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getMessages(@CurrentUser('companyId') companyId: string) {
    return this.whatsappService.getMessages(companyId);
  }
}
