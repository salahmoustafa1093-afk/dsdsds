import {
  Injectable,
  Logger,
  BadRequestException,
  NotFoundException,
  InternalServerErrorException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '@/prisma/prisma.service';

// ─────────────────────────────────────────────────────────────
// Types & Interfaces
// ─────────────────────────────────────────────────────────────

interface WhatsAppApiResponse {
  messaging_product: string;
  contacts: Array<{ input: string; wa_id: string }>;
  messages: Array<{ id: string }>;
}

interface WebhookMessage {
  id: string;
  from: string;
  timestamp: string;
  type: 'text' | 'image' | 'document' | 'audio' | 'video' | 'location' | 'contacts' | 'button' | 'interactive';
  text?: { body: string };
  image?: { id: string; mime_type: string; sha256: string; caption?: string };
  document?: { id: string; mime_type: string; sha256: string; filename: string; caption?: string };
  location?: { latitude: number; longitude: number; name?: string; address?: string };
  button?: { payload: string; text: string };
  interactive?: { type: string; button_reply?: { id: string; title: string }; list_reply?: { id: string; title: string } };
  context?: { from: string; id: string };
}

interface WebhookStatus {
  id: string;
  recipient_id: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
  timestamp: string;
  conversation?: { id: string; origin: { type: string } };
  pricing?: { billable: boolean; pricing_model: string; category: string };
  errors?: Array<{ code: number; title: string; message: string; error_data: { details: string } }>;
}

interface TemplateComponent {
  type: 'header' | 'body' | 'footer' | 'button';
  parameters: Array<{
    type: 'text' | 'currency' | 'date_time' | 'image' | 'document' | 'video';
    text?: string;
    currency?: { fallback_value: string; code: string; amount_1000: number };
    date_time?: { fallback_value: string };
    image?: { link: string };
  }>;
}

interface BusinessWorkflowResult {
  messageId: string;
  to: string;
  templateName: string;
  status: string;
  sentAt: Date;
}

interface DailyReportData {
  date: string;
  totalSales: number;
  invoiceCount: number;
  totalPurchases: number;
  lowStockCount: number;
  deliveryCount: number;
  topProduct: string;
  cashBalance: number;
}

interface MessageLog {
  id: string;
  direction: 'INBOUND' | 'OUTBOUND';
  to?: string;
  from?: string;
  body: string;
  type: string;
  status: string;
  templateName?: string;
  mediaUrl?: string;
  createdAt: Date;
}

// ─────────────────────────────────────────────────────────────
// Template definitions
// ─────────────────────────────────────────────────────────────

const TEMPLATES: Record<string, { name: string; language: string; category: string; description: string }> = {
  order_confirmation: {
    name: 'order_confirmation',
    language: 'ar',
    category: 'UTILITY',
    description: 'Confirm order placement with order number and total',
  },
  delivery_notification: {
    name: 'delivery_notification',
    language: 'ar',
    category: 'UTILITY',
    description: 'Notify customer of delivery assignment with driver and ETA',
  },
  payment_reminder: {
    name: 'payment_reminder',
    language: 'ar',
    category: 'UTILITY',
    description: 'Remind customer of upcoming or overdue payment',
  },
  low_stock_alert: {
    name: 'low_stock_alert',
    language: 'ar',
    category: 'UTILITY',
    description: 'Alert warehouse manager of low stock item',
  },
  daily_report: {
    name: 'daily_report',
    language: 'ar',
    category: 'UTILITY',
    description: 'Send daily business summary to manager',
  },
  welcome_message: {
    name: 'welcome_message',
    language: 'ar',
    category: 'GREETING',
    description: 'Welcome message for new contacts',
  },
  otp_verification: {
    name: 'otp_verification',
    language: 'ar',
    category: 'AUTHENTICATION',
    description: 'One-time password verification code',
  },
  invoice_ready: {
    name: 'invoice_ready',
    language: 'ar',
    category: 'UTILITY',
    description: 'Notify customer that invoice is ready',
  },
};

// ─────────────────────────────────────────────────────────────
// Auto-response keywords (Arabic + English)
// ─────────────────────────────────────────────────────────────

const AUTO_RESPONSES: Array<{
  keywords: string[];
  response: string;
  language: 'ar' | 'en';
}> = [
  {
    keywords: ['مرحبا', 'اهلا', 'أهلا', 'السلام عليكم', 'hello', 'hi', 'hey'],
    response:
      'أهلاً وسهلاً! 👋 أنا مساعد Green Farm Foods. كيف يمكنني مساعدتك اليوم؟ يمكنك الاستفسار عن: الطلبات، الفواتير، التوصيل، أو الأسعار.',
    language: 'ar',
  },
  {
    keywords: ['شكرا', 'شكراً', 'thanks', 'thank you', 'شكر'],
    response: 'العفو! 😊 نحن هنا دائماً لمساعدتك. هل تحتاج مساعدة بأي شيء آخر؟',
    language: 'ar',
  },
  {
    keywords: ['سعر', 'أسعار', 'السعر', 'price', 'pricing', 'cost', 'how much'],
    response:
      'للاستفسار عن الأسعار، يرجى التواصل مع قسم المبيعات على الرقم 077XXXXXXX أو زيارة الفرع الأقرب.',
    language: 'ar',
  },
  {
    keywords: ['طلب', 'طلبات', 'order', 'orders', 'my order'],
    response:
      'للاستعلام عن طلبك، يرجى إرسال رقم الطلب وسنقوم بالرد عليك فوراً.',
    language: 'ar',
  },
  {
    keywords: ['فاتورة', 'فواتير', 'invoice', 'bill', 'payment'],
    response:
      'للاستفسار عن الفواتير والمدفوعات، يرجى التواصل مع قسم المحاسبة على الرقم 077XXXXXXX.',
    language: 'ar',
  },
  {
    keywords: ['توصيل', 'delivery', 'shipping', 'موعد التوصيل'],
    response:
      'يمكنك متابعة حالة التوصيل من خلال إرسال رقم الفاتورة. سنوافيك بالتفاصيل فوراً. 🚚',
    language: 'ar',
  },
  {
    keywords: ['وداعا', 'مع السلامة', 'bye', 'goodbye', 'see you'],
    response: 'مع السلامة! 👋 نتمنى لك يوماً سعيداً. نحن هنا إذا احتجتنا.',
    language: 'ar',
  },
  {
    keywords: ['وقت العمل', 'ساعات العمل', 'hours', 'working hours', 'open'],
    response:
      '🕐 ساعات العمل:\nالسبت - الخميس: 8:00 صباحاً - 6:00 مساءً\nالجمعة: مغلق',
    language: 'ar',
  },
  {
    keywords: ['عنوان', 'موقع', 'address', 'location', 'where are you'],
    response:
      '📍 المقر الرئيسي:\nالزرقاء - الأردن\nللطلب والاستفسار: 077XXXXXXX\ninfo@greenfarmfoods.com',
    language: 'ar',
  },
  {
    keywords: ['منتج', 'منتجات', 'products', 'items', 'catalog', 'menu'],
    response:
      '🌾 ننتج أعلاف عالية الجودة للدواجن والمواشي:\n• علف بادئ للتسمين\n• علف ناهي\n• علف نخالة\n• مكملات غذائية\n\nللحصول على كامل الكتالوج، تواصل مع المبيعات.',
    language: 'ar',
  },
  {
    keywords: ['مساعدة', 'مساعده', 'help', 'support', 'مساعدة فنية'],
    response:
      '🔧 للدعم الفني أو أي استفسار:\n☎️ 077XXXXXXX\n📧 support@greenfarmfoods.com\nسنكون سعداء بمساعدتك!',
    language: 'ar',
  },
];

// ─────────────────────────────────────────────────────────────

@Injectable()
export class WhatsappService {
  private readonly logger = new Logger(WhatsappService.name);
  private readonly apiBaseUrl = 'https://graph.facebook.com/v18.0';

  constructor(
    private readonly prisma: PrismaService,
    private readonly configService: ConfigService,
  ) {}

  private groupByTemplateName(): Array<{ templateName: string; _count: number }> {
    const map = new Map<string, number>();
    for (const m of this.messageStore) {
      if (m.templateName) {
        map.set(m.templateName, (map.get(m.templateName) || 0) + 1);
      }
    }
    return Array.from(map.entries()).map(([templateName, count]) => ({ templateName, _count: count }));
  }

  // In-memory message store (whatsappMessage model not in schema)
  private messageStore: Array<{
    id: string; companyId: string; to?: string; from?: string; body: string;
    type: string; status: string; direction: 'INBOUND' | 'OUTBOUND';
    apiMessageId?: string; templateName?: string; mediaUrl?: string; createdAt: Date;
  }> = [];
  private msgIdCounter = 0;

  private storeMsg(data: any) {
    const id = 'wm_' + (++this.msgIdCounter);
    const entry = { id, createdAt: new Date(), ...data };
    this.messageStore.push(entry);
    return entry;
  }

  // ═══════════════════════════════════════════════════════════
  // 1. SEND TEXT MESSAGE
  // ═══════════════════════════════════════════════════════════

  /**
   * Send a plain text message via WhatsApp Business Cloud API.
   */
  async sendTextMessage(
    companyId: string,
    to: string,
    message: string,
    replyToMessageId?: string,
  ) {
    this.validatePhone(to);
    this.validateMessageLength(message);

    // Normalize phone number (remove leading + if present, add country code if needed)
    const normalizedPhone = this.normalizePhone(to);

    // Build API payload
    const payload: any = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: normalizedPhone,
      type: 'text',
      text: { body: message, preview_url: true },
    };
    if (replyToMessageId) {
      payload.context = { message_id: replyToMessageId };
    }

    // Store message in database (optimistic: mark as SENT, update later if failed)
    const dbMessage = this.storeMsg({
        companyId,
        to: normalizedPhone,
        body: message,
        type: 'TEXT',
        status: 'SENT',
        direction: 'OUTBOUND',
      },
    });

    // Call WhatsApp API
    const apiResponse = await this.callWhatsAppApi(payload);

    // Update with API message ID
    const idx = this.messageStore.findIndex(m => m.id === dbMessage.id);
    if (idx !== -1) {
      this.messageStore[idx] = { ...this.messageStore[idx], apiMessageId: apiResponse.messages?.[0]?.id },
    });

    this.logger.log(`[WA TEXT] To: ${normalizedPhone}, Length: ${message.length} chars`);

    return {
      data: {
        messageId: apiResponse.messages?.[0]?.id,
        dbId: dbMessage.id,
        to: normalizedPhone,
        status: 'SENT',
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 2. SEND TEMPLATE MESSAGE
  // ═══════════════════════════════════════════════════════════

  /**
   * Send a WhatsApp template message.
   * Templates must be pre-approved in Meta Business Manager.
   */
  async sendTemplateMessage(
    companyId: string,
    to: string,
    templateName: string,
    languageCode: string = 'ar',
    components?: TemplateComponent[],
  ) {
    this.validatePhone(to);

    // Validate template exists
    const templateDef = TEMPLATES[templateName];
    if (!templateDef) {
      throw new BadRequestException(
        `Unknown template: "${templateName}". Available: ${Object.keys(TEMPLATES).join(', ')}`,
      );
    }

    const normalizedPhone = this.normalizePhone(to);

    const payload: any = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: normalizedPhone,
      type: 'template',
      template: {
        name: templateName,
        language: { code: languageCode || templateDef.language },
      },
    };

    if (components && components.length > 0) {
      payload.template.components = components;
    }

    // Store in database
    const dbMessage = this.storeMsg({
        companyId,
        to: normalizedPhone,
        body: `[Template: ${templateName}]`,
        type: 'TEMPLATE',
        templateName,
        status: 'SENT',
        direction: 'OUTBOUND',
      },
    });

    // Call API
    const apiResponse = await this.callWhatsAppApi(payload);

    const idx = this.messageStore.findIndex(m => m.id === dbMessage.id);
    if (idx !== -1) {
      this.messageStore[idx] = { ...this.messageStore[idx], apiMessageId: apiResponse.messages?.[0]?.id },
    });

    this.logger.log(`[WA TEMPLATE] To: ${normalizedPhone}, Template: ${templateName}`);

    return {
      data: {
        messageId: apiResponse.messages?.[0]?.id,
        dbId: dbMessage.id,
        templateName,
        to: normalizedPhone,
        status: 'SENT',
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 3. SEND MEDIA MESSAGE
  // ═══════════════════════════════════════════════════════════

  /**
   * Send a media message (image, document, or video).
   */
  async sendMediaMessage(
    companyId: string,
    to: string,
    mediaUrl: string,
    caption: string = '',
    type: 'image' | 'document' | 'video' = 'image',
    filename?: string,
  ) {
    this.validatePhone(to);
    if (!mediaUrl || !mediaUrl.startsWith('http')) {
      throw new BadRequestException('mediaUrl must be a valid HTTP(S) URL');
    }

    const normalizedPhone = this.normalizePhone(to);

    const payload: any = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: normalizedPhone,
      type,
    };

    switch (type) {
      case 'image':
        payload.image = { link: mediaUrl, caption };
        break;
      case 'document':
        payload.document = { link: mediaUrl, caption, filename: filename || 'document.pdf' };
        break;
      case 'video':
        payload.video = { link: mediaUrl, caption };
        break;
    }

    const dbMessage = this.storeMsg({
        companyId,
        to: normalizedPhone,
        body: caption || `[${type.toUpperCase()}]`,
        type: type.toUpperCase() as any,
        mediaUrl,
        status: 'SENT',
        direction: 'OUTBOUND',
      },
    });

    const apiResponse = await this.callWhatsAppApi(payload);

    const idx = this.messageStore.findIndex(m => m.id === dbMessage.id);
    if (idx !== -1) {
      this.messageStore[idx] = { ...this.messageStore[idx], apiMessageId: apiResponse.messages?.[0]?.id },
    });

    this.logger.log(`[WA ${type.toUpperCase()}] To: ${normalizedPhone}, URL: ${mediaUrl}`);

    return {
      data: {
        messageId: apiResponse.messages?.[0]?.id,
        dbId: dbMessage.id,
        to: normalizedPhone,
        type,
        status: 'SENT',
      },
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 4. WEBHOOK HANDLER
  // ═══════════════════════════════════════════════════════════

  /**
   * Verify webhook subscription (called by Meta during setup).
   */
  async verifyWebhook(mode: string, token: string, challenge: string): Promise<string> {
    const verifyToken = this.configService.get('WHATSAPP_WEBHOOK_VERIFY_TOKEN');
    if (!verifyToken) {
      this.logger.warn('WHATSAPP_WEBHOOK_VERIFY_TOKEN not configured');
      return 'Verification token not configured';
    }
    if (mode === 'subscribe' && token === verifyToken) {
      this.logger.log('Webhook verified successfully');
      return challenge;
    }
    this.logger.warn('Webhook verification failed: token mismatch');
    return 'Verification failed';
  }

  /**
   * Handle incoming webhook events from WhatsApp.
   * Processes: messages, delivery receipts, read receipts, statuses.
   */
  async handleWebhook(body: any): Promise<{ processed: number; events: string[] }> {
    if (!body || !body.entry) {
      return { processed: 0, events: [] };
    }

    const events: string[] = [];
    let processed = 0;

    for (const entry of body.entry) {
      for (const change of entry.changes || []) {
        const value = change.value;

        if (!value) continue;

        // Process messages
        if (value.messages && Array.isArray(value.messages)) {
          for (const message of value.messages) {
            await this.processIncomingMessage(value, message);
            events.push(`message:${message.type}`);
            processed++;
          }
        }

        // Process statuses (sent, delivered, read, failed)
        if (value.statuses && Array.isArray(value.statuses)) {
          for (const status of value.statuses) {
            await this.processStatusUpdate(status);
            events.push(`status:${status.status}`);
            processed++;
          }
        }
      }
    }

    return { processed, events };
  }

  /**
   * Process an incoming message from a customer.
   */
  private async processIncomingMessage(
    value: any,
    message: WebhookMessage,
  ): Promise<void> {
    const phoneNumberId = value.metadata?.phone_number_id;
    const from = message.from;
    const messageType = message.type;

    this.logger.log(`[WA INBOUND] From: ${from}, Type: ${messageType}, ID: ${message.id}`);

    // Extract message content based on type
    let body = '';
    let mediaUrl: string | undefined;
    let locationData: any;

    switch (messageType) {
      case 'text':
        body = message.text?.body || '';
        break;
      case 'image':
        body = `[Image${message.image?.caption ? ': ' + message.image.caption : ''}]`;
        mediaUrl = message.image?.id;
        break;
      case 'document':
        body = `[Document: ${message.document?.filename}]`;
        mediaUrl = message.document?.id;
        break;
      case 'location':
        body = `[Location: ${message.location?.latitude}, ${message.location?.longitude}]`;
        locationData = message.location;
        break;
      case 'button':
        body = `[Button: ${message.button?.text}]`;
        break;
      case 'interactive':
        body = `[Interactive: ${message.interactive?.button_reply?.title || message.interactive?.list_reply?.title}]`;
        break;
      default:
        body = `[${messageType.toUpperCase()}]`;
    }

    // Store incoming message
    this.storeMsg({
        companyId: 'default', // Will be resolved by phone matching in production
        from: from,
        body,
        type: messageType.toUpperCase() as any,
        status: 'RECEIVED',
        direction: 'INBOUND',
        apiMessageId: message.id,
        mediaUrl,
        metadata: locationData
          ? JSON.stringify(locationData)
          : message.context
            ? JSON.stringify({ replyTo: message.context })
            : undefined,
      },
    });

    // Trigger auto-response for known keywords
    if (messageType === 'text' && body) {
      const autoResponse = this.findAutoResponse(body);
      if (autoResponse) {
        try {
          await this.sendTextMessage('default', from, autoResponse.response);
          this.logger.log(`[WA AUTO-REPLY] Sent to ${from}: keyword matched`);
        } catch (e) {
          this.logger.error(`[WA AUTO-REPLY] Failed: ${e.message}`);
        }
      }
    }
  }

  /**
   * Process a status update (sent, delivered, read, failed).
   */
  private async processStatusUpdate(status: WebhookStatus): Promise<void> {
    const { id: apiMessageId, status: messageStatus, timestamp, errors } = status;

    // Find our stored message by API message ID
    const dbMessage = this.messageStore.find(m => m.apiMessageId === apiMessageId);

    if (dbMessage) {
      const idx = this.messageStore.findIndex(m => m.id === dbMessage.id);
    if (idx !== -1) {
      this.messageStore[idx] = { ...this.messageStore[idx],
          status: messageStatus.toUpperCase() as any,
          deliveredAt: messageStatus === 'delivered' ? new Date(parseInt(timestamp) * 1000) : undefined,
          readAt: messageStatus === 'read' ? new Date(parseInt(timestamp) * 1000) : undefined,
          errorDetails: errors ? JSON.stringify(errors) : undefined,
        },
      });
    }

    if (messageStatus === 'failed' && errors) {
      this.logger.error(
        `[WA FAILED] Message ${apiMessageId}: ${errors.map((e) => `${e.code} - ${e.title}`).join(', ')}`,
      );
    } else {
      this.logger.debug(`[WA ${messageStatus.toUpperCase()}] Message ${apiMessageId}`);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 5. BUSINESS WORKFLOWS
  // ═══════════════════════════════════════════════════════════

  /**
   * Send order confirmation to customer.
   */
  async notifyOrderConfirmation(
    companyId: string,
    customerPhone: string,
    orderNumber: string,
    total: number,
    customerName?: string,
  ): Promise<BusinessWorkflowResult> {
    const greeting = customerName ? `مرحباً ${customerName}،` : 'مرحباً،';
    const message = `${greeting}\n\n✅ تم تأكيد طلبك بنجاح!\n📋 رقم الطلب: *${orderNumber}*\n💰 الإجمالي: *${total.toFixed(2)} ج.م*\n\nسنقوم بإشعارك حين يتم شحن الطلب. شكراً لاختياركم Green Farm Foods! 🌾`;

    const result = await this.sendTextMessage(companyId, customerPhone, message);

    return {
      messageId: result.data.messageId,
      to: customerPhone,
      templateName: 'order_confirmation',
      status: 'SENT',
      sentAt: new Date(),
    };
  }

  /**
   * Notify customer that delivery has been assigned.
   */
  async notifyDeliveryAssigned(
    companyId: string,
    customerPhone: string,
    driverName: string,
    vehiclePlate: string,
    eta: string,
    trackingUrl?: string,
  ): Promise<BusinessWorkflowResult> {
    const message = `🚚 *تم تعيين سائق لطلبك!*\n\n👤 السائق: *${driverName}*\n🚗 المركبة: *${vehiclePlate}*\n⏰ متوقع الوصول: *خلال ${eta}*\n\n${trackingUrl ? `📍 تتبع الطلب: ${trackingUrl}` : 'سنقوم بإشعارك عند الوصول.'}\n\nشكراً لثقتكم! 🌾`;

    const result = await this.sendTextMessage(companyId, customerPhone, message);

    return {
      messageId: result.data.messageId,
      to: customerPhone,
      templateName: 'delivery_notification',
      status: 'SENT',
      sentAt: new Date(),
    };
  }

  /**
   * Send payment due reminder to customer.
   */
  async notifyPaymentDue(
    companyId: string,
    customerPhone: string,
    invoiceNumber: string,
    amount: number,
    dueDate: string,
    daysOverdue?: number,
  ): Promise<BusinessWorkflowResult> {
    const overdueText =
      daysOverdue && daysOverdue > 0
        ? `⚠️ *متأخر ${daysOverdue} يوم*\n`
        : '';

    const message = `💳 *تذكير بالدفع*\n\n${overdueText}📋 رقم الفاتورة: *${invoiceNumber}*\n💰 المبلغ المستحق: *${amount.toFixed(2)} ج.م*\n📅 تاريخ الاستحقاق: *${dueDate}*\n\nيرجى التسديد في أقرب وقت لتجنب أي رسوم إضافية.\n\nللاستفسار: 077XXXXXXX 📞`;

    const result = await this.sendTextMessage(companyId, customerPhone, message);

    return {
      messageId: result.data.messageId,
      to: customerPhone,
      templateName: 'payment_reminder',
      status: 'SENT',
      sentAt: new Date(),
    };
  }

  /**
   * Send low stock alert to warehouse manager.
   */
  async notifyLowStock(
    companyId: string,
    warehouseManagerPhone: string,
    productName: string,
    currentQty: number,
    minQty: number,
    warehouseName?: string,
  ): Promise<BusinessWorkflowResult> {
    const shortfall = Math.max(0, minQty - currentQty);
    const warehouseText = warehouseName ? `📍 المستودع: *${warehouseName}*\n` : '';

    const message = `⚠️ *تنبيه مخزون منخفض!*\n\n📦 المنتج: *${productName}*\n${warehouseText}📊 الكمية الحالية: *${currentQty}*\n📉 الحد الأدنى: *${minQty}*\n❌ النقص: *${shortfall}*\n\nيرجى طلب التوريد فوراً لتجنب الانقطاع.\n\nGreen Farm Foods 🌾`;

    const result = await this.sendTextMessage(companyId, warehouseManagerPhone, message);

    return {
      messageId: result.data.messageId,
      to: warehouseManagerPhone,
      templateName: 'low_stock_alert',
      status: 'SENT',
      sentAt: new Date(),
    };
  }

  /**
   * Send daily business report to manager.
   */
  async sendDailyReport(
    companyId: string,
    managerPhone: string,
    reportData: DailyReportData,
  ): Promise<BusinessWorkflowResult> {
    const message = `📊 *التقرير اليومي — ${reportData.date}*\n\n💰 إجمالي المبيعات: *${reportData.totalSales.toFixed(2)} ج.م*\n🧾 عدد الفواتير: *${reportData.invoiceCount}*\n📦 إجمالي المشتريات: *${reportData.totalPurchases.toFixed(2)} ج.م*\n⚠️ منتجات منخفضة: *${reportData.lowStockCount}*\n🚚 عمليات توصيل: *${reportData.deliveryCount}*\n🏆 أفضل منتج: *${reportData.topProduct}*\n💵 الرصيد النقدي: *${reportData.cashBalance.toFixed(2)} ج.م*\n\nGreen Farm Foods 🌾`;

    const result = await this.sendTextMessage(companyId, managerPhone, message);

    return {
      messageId: result.data.messageId,
      to: managerPhone,
      templateName: 'daily_report',
      status: 'SENT',
      sentAt: new Date(),
    };
  }

  /**
   * Send OTP verification code.
   */
  async sendOTP(
    companyId: string,
    phone: string,
    otpCode: string,
    expiryMinutes: number = 10,
  ): Promise<BusinessWorkflowResult> {
    const message = `🔐 *رمز التحقق*\n\nرمزك هو: *${otpCode}*\nصالح لمدة ${expiryMinutes} دقائق.\n\nلا تشارك هذا الرمز مع أحد.`;

    const result = await this.sendTextMessage(companyId, phone, message);

    return {
      messageId: result.data.messageId,
      to: phone,
      templateName: 'otp_verification',
      status: 'SENT',
      sentAt: new Date(),
    };
  }

  // ═══════════════════════════════════════════════════════════
  // 6. MESSAGE TEMPLATES & VALIDATION
  // ═══════════════════════════════════════════════════════════

  /**
   * Get all available message templates.
   */
  getAvailableTemplates(): Array<{
    name: string;
    language: string;
    category: string;
    description: string;
  }> {
    return Object.values(TEMPLATES);
  }

  /**
   * Validate a message before sending (length, content checks).
   */
  validateMessage(content: string, type: 'text' | 'template' | 'image' | 'document' | 'video'): {
    valid: boolean;
    errors: string[];
    warnings: string[];
  } {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!content || content.trim().length === 0) {
      errors.push('Message content cannot be empty');
      return { valid: false, errors, warnings };
    }

    // Length checks per message type
    const trimmed = content.trim();
    switch (type) {
      case 'text':
        if (trimmed.length > 4096) {
          errors.push('Text message exceeds 4096 character limit');
        } else if (trimmed.length > 1000) {
          warnings.push('Long message — consider using a template for better readability');
        }
        break;
      case 'template':
        if (trimmed.length > 1024) {
          errors.push('Template body exceeds 1024 character limit');
        }
        break;
      case 'image':
        warnings.push('Ensure image URL is accessible and ≤ 5MB (JPEG/PNG)');
        break;
      case 'document':
        warnings.push('Ensure document URL is accessible and ≤ 100MB (PDF)');
        break;
      case 'video':
        warnings.push('Ensure video URL is accessible and ≤ 16MB (MP4)');
        break;
    }

    // Check for forbidden content patterns
    const forbiddenPatterns = [
      /\b(password|كلمة السر)\b/i,
    ];
    for (const pattern of forbiddenPatterns) {
      if (pattern.test(trimmed)) {
        warnings.push('Message may contain sensitive content — review before sending');
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Validate a phone number format.
   */
  validatePhone(phone: string): void {
    if (!phone || phone.trim().length < 8) {
      throw new BadRequestException('Phone number is required (min 8 digits)');
    }
    // Remove + and spaces, check if remaining is digits
    const cleaned = phone.replace(/[\s+]/g, '');
    if (!/^\d+$/.test(cleaned)) {
      throw new BadRequestException('Phone number must contain only digits, spaces, or leading +');
    }
  }

  /**
   * Validate message length.
   */
  validateMessageLength(message: string): void {
    if (!message || message.trim().length === 0) {
      throw new BadRequestException('Message body cannot be empty');
    }
    if (message.length > 4096) {
      throw new BadRequestException('Message exceeds WhatsApp 4096 character limit');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // MESSAGE HISTORY & ANALYTICS
  // ═══════════════════════════════════════════════════════════

  /**
   * Get message history for a company.
   */
  async getMessages(
    companyId: string,
    options: {
      page?: number;
      limit?: number;
      direction?: 'INBOUND' | 'OUTBOUND';
      phone?: string;
      startDate?: Date;
      endDate?: Date;
    } = {},
  ) {
    const { page = 1, limit = 50, direction, phone, startDate, endDate } = options;
    const skip = (page - 1) * limit;

    const where: any = { companyId };
    if (direction) where.direction = direction;
    if (phone) {
      where.OR = [{ to: phone }, { from: phone }];
    }
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = startDate;
      if (endDate) where.createdAt.lte = endDate;
    }

    const [messages, total] = await Promise.all([
      this.messageStore.filter(m => {
        for (const [k, v] of Object.entries(where)) {
          if (k === 'OR') continue;
          if ((m as any)[k] !== v) return false;
        }
        return true;
      }).slice(skip, skip + limit),
      this.messageStore.filter(m => {
        for (const [k, v] of Object.entries(where)) { if (k === 'OR') continue; if ((m as any)[k] !== v) return false; }
        return true;
      }).length,
    ]);

    return {
      data: messages,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  /**
   * Get conversation thread with a specific phone number.
   */
  async getConversation(
    companyId: string,
    phone: string,
    limit: number = 100,
  ) {
    const normalizedPhone = this.normalizePhone(phone);

    const messages = this.messageStore.filter(m =>
      m.companyId === companyId && (m.to === normalizedPhone || m.from === normalizedPhone)
    ).sort((a, b) => +b.createdAt - +a.createdAt).slice(0, limit);

    return {
      data: messages.reverse(), // chronological order
      contact: normalizedPhone,
      messageCount: messages.length,
    };
  }

  /**
   * Get WhatsApp messaging analytics.
   */
  async getAnalytics(
    companyId: string,
    startDate: Date,
    endDate: Date,
  ) {
    const where = {
      companyId,
      createdAt: { gte: startDate, lte: endDate },
    };

    const [
      totalSent,
      totalReceived,
      deliveredCount,
      readCount,
      failedCount,
      templateUsage,
    ] = await Promise.all([
      this.messageStore.filter(m => m.direction === 'OUTBOUND').length,
      this.messageStore.filter(m => m.direction === 'INBOUND').length,
      this.messageStore.filter(m => m.status === 'DELIVERED').length,
      this.messageStore.filter(m => m.status === 'READ').length,
      this.messageStore.filter(m => m.status === 'FAILED').length,
      this.groupByTemplateName(),
    ]);

    const deliveryRate =
      totalSent > 0 ? (deliveredCount / totalSent) * 100 : 0;
    const readRate =
      deliveredCount > 0 ? (readCount / deliveredCount) * 100 : 0;

    return {
      period: { start: startDate, end: endDate },
      messages: {
        sent: totalSent,
        received: totalReceived,
        delivered: deliveredCount,
        read: readCount,
        failed: failedCount,
      },
      rates: {
        deliveryRate: Math.round(deliveryRate * 100) / 100,
        readRate: Math.round(readRate * 100) / 100,
        failureRate:
          totalSent > 0 ? Math.round((failedCount / totalSent) * 10000) / 100 : 0,
      },
      templateUsage: templateUsage.map((t) => ({
        templateName: t.templateName,
        count: t._count.templateName,
      })),
    };
  }

  // ═══════════════════════════════════════════════════════════
  // SETTINGS & CONFIGURATION
  // ═══════════════════════════════════════════════════════════

  /**
   * Get WhatsApp API configuration status.
   */
  getConfigStatus() {
    const apiToken = this.configService.get('WHATSAPP_API_TOKEN');
    const phoneNumberId = this.configService.get('WHATSAPP_PHONE_NUMBER_ID');
    const verifyToken = this.configService.get('WHATSAPP_WEBHOOK_VERIFY_TOKEN');

    return {
      configured: !!(apiToken && phoneNumberId),
      apiTokenPresent: !!apiToken,
      phoneNumberIdPresent: !!phoneNumberId,
      verifyTokenPresent: !!verifyToken,
      apiBaseUrl: this.apiBaseUrl,
      phoneNumberId: phoneNumberId || null,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════════

  /**
   * Call the WhatsApp Business Cloud API.
   */
  private async callWhatsAppApi(payload: any): Promise<WhatsAppApiResponse> {
    const apiToken = this.configService.get('WHATSAPP_API_TOKEN');
    const phoneNumberId = this.configService.get('WHATSAPP_PHONE_NUMBER_ID');

    // If not configured, log and return mock response (dev mode)
    if (!apiToken || !phoneNumberId) {
      this.logger.warn(
        `[WA MOCK] WhatsApp API not configured. Payload: ${JSON.stringify(payload).slice(0, 200)}`,
      );
      return {
        messaging_product: 'whatsapp',
        contacts: [{ input: payload.to, wa_id: payload.to }],
        messages: [{ id: `mock_${Date.now()}` }],
      };
    }

    try {
      const response = await fetch(
        `${this.apiBaseUrl}/${phoneNumberId}/messages`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${apiToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        },
      );

      if (!response.ok) {
        const errorBody = await response.text();
        let parsedError: any;
        try {
          parsedError = JSON.parse(errorBody);
        } catch {
          parsedError = { error: errorBody };
        }
        throw new InternalServerErrorException(
          `WhatsApp API error (${response.status}): ${parsedError.error?.message || errorBody}`,
        );
      }

      const result = await response.json();
      return result as WhatsAppApiResponse;
    } catch (error) {
      if (error instanceof InternalServerErrorException) throw error;
      throw new InternalServerErrorException(
        `Failed to call WhatsApp API: ${error.message}`,
      );
    }
  }

  /**
   * Normalize phone number for WhatsApp API.
   * Removes spaces, dashes, and ensures consistent format.
   */
  private normalizePhone(phone: string): string {
    let cleaned = phone.replace(/[\s\-().]/g, '');
    if (cleaned.startsWith('+')) cleaned = cleaned.substring(1);
    // If starts with 0, assume local format and add country code (Jordan: 962)
    if (cleaned.startsWith('0') && cleaned.length === 10) {
      cleaned = '962' + cleaned.substring(1);
    }
    return cleaned;
  }

  /**
   * Find an auto-response for given message text.
   */
  private findAutoResponse(text: string): { response: string; language: 'ar' | 'en' } | null {
    const lowerText = text.toLowerCase().trim();
    for (const entry of AUTO_RESPONSES) {
      for (const keyword of entry.keywords) {
        if (lowerText.includes(keyword.toLowerCase())) {
          return { response: entry.response, language: entry.language };
        }
      }
    }
    return null;
  }
}
