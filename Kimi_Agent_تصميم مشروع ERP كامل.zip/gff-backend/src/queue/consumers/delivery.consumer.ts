import { Processor, WorkerHost, OnWorkerEvent } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { DeliveryProcessor, DeliveryPayload } from '../processors/delivery.processor';
import { QueueService } from '../queue.service';

/**
 * Delivery Consumer
 *
 * Processes delivery workflow jobs from the 'delivery' queue.
 * GPS batch updates and route optimization are CPU-intensive
 * and run with controlled concurrency.
 */
@Processor('delivery', {
  concurrency: 5,
  limiter: { max: 50, duration: 60000 }, // 50 delivery ops per minute
  lockDuration: 60000, // 1 minute lock for GPS processing
})
export class DeliveryConsumer extends WorkerHost {
  private readonly logger = new Logger(DeliveryConsumer.name);

  constructor(
    private readonly deliveryProcessor: DeliveryProcessor,
    private readonly queueService: QueueService,
  ) {
    super();
  }

  async process(job: Job<DeliveryPayload>): Promise<unknown> {
    const startTime = Date.now();
    const { step, deliveryId } = job.data;

    this.logger.log(
      `[Job ${job.id}] Processing delivery step "${step}" for ${deliveryId} — attempt ${job.attemptsMade + 1}/${job.opts.attempts}`,
    );

    try {
      const result = await this.deliveryProcessor.process(job.data);
      const duration = Date.now() - startTime;
      this.logger.log(
        `[Job ${job.id}] Delivery step "${step}" completed in ${duration}ms — ${result.status}`,
      );
      return result;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`[Job ${job.id}] Delivery step "${step}" failed: ${message}`);
      throw err;
    }
  }

  @OnWorkerEvent('completed')
  onCompleted(job: Job): void {
    this.logger.log(`[Job ${job.id}] Delivery job completed`);
  }

  @OnWorkerEvent('failed')
  async onFailed(job: Job, error: Error): Promise<void> {
    this.logger.error(`[Job ${job.id}] Delivery job failed: ${error.message}`);

    if (job.attemptsMade >= (job.opts.attempts || 3)) {
      this.logger.warn(`[Job ${job.id}] Max retries reached — moving to dead-letter queue`);
      try {
        await this.queueService.moveToDeadLetter('delivery', job.id as string, error.message);
      } catch (dlqErr: unknown) {
        const dlqMsg = dlqErr instanceof Error ? dlqErr.message : 'Unknown error';
        this.logger.error(`[Job ${job.id}] Failed to move to DLQ: ${dlqMsg}`);
      }
    }
  }

  @OnWorkerEvent('stalled')
  onStalled(jobId: string): void {
    this.logger.warn(`[Job ${jobId}] Delivery job stalled`);
  }
}
