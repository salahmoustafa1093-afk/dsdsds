import { Processor, WorkerHost, OnWorkerEvent } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { AuditProcessor, AuditPayload } from '../processors/audit.processor';
import { QueueService } from '../queue.service';

/**
 * Audit Consumer
 *
 * Processes bulk audit log jobs from the 'audit' queue.
 * Handles bulk-insert, archive, export, analyze, cleanup, and compliance-check.
 * Memory-intensive operations run with limited concurrency.
 */
@Processor('audit', {
  concurrency: 3, // Limit concurrent audit jobs to control memory
  limiter: { max: 20, duration: 60000 }, // 20 audit ops per minute
  lockDuration: 300000, // 5 minute lock for large audit batches
})
export class AuditConsumer extends WorkerHost {
  private readonly logger = new Logger(AuditConsumer.name);

  constructor(
    private readonly auditProcessor: AuditProcessor,
    private readonly queueService: QueueService,
  ) {
    super();
  }

  async process(job: Job<AuditPayload>): Promise<unknown> {
    const startTime = Date.now();
    const { operation, companyId } = job.data;

    this.logger.log(
      `[Job ${job.id}] Processing audit ${operation} for company ${companyId} — attempt ${job.attemptsMade + 1}/${job.opts.attempts}`,
    );

    try {
      const result = await this.auditProcessor.process(job.data);
      const duration = Date.now() - startTime;
      this.logger.log(
        `[Job ${job.id}] Audit ${operation} completed in ${duration}ms — ${result.recordsProcessed} records processed`,
      );
      return result;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`[Job ${job.id}] Audit processing failed: ${message}`);
      throw err;
    }
  }

  @OnWorkerEvent('completed')
  onCompleted(job: Job): void {
    this.logger.log(`[Job ${job.id}] Audit job completed`);
  }

  @OnWorkerEvent('failed')
  async onFailed(job: Job, error: Error): Promise<void> {
    this.logger.error(`[Job ${job.id}] Audit job failed: ${error.message}`);

    if (job.attemptsMade >= (job.opts.attempts || 3)) {
      this.logger.warn(
        `[Job ${job.id}] Max retries reached — moving to dead-letter queue`,
      );
      try {
        await this.queueService.moveToDeadLetter(
          'audit',
          job.id as string,
          error.message,
        );
      } catch (dlqErr: unknown) {
        const dlqMsg = dlqErr instanceof Error ? dlqErr.message : 'Unknown error';
        this.logger.error(`[Job ${job.id}] Failed to move to DLQ: ${dlqMsg}`);
      }
    }
  }

  @OnWorkerEvent('stalled')
  onStalled(jobId: string): void {
    this.logger.warn(`[Job ${jobId}] Audit job stalled`);
  }
}
