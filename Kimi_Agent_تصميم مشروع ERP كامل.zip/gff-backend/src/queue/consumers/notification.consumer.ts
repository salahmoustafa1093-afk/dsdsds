import { Processor, WorkerHost, OnWorkerEvent } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import {
  NotificationProcessor,
  NotificationPayload,
} from '../processors/notification.processor';
import { QueueService } from '../queue.service';

/**
 * Notification Consumer
 *
 * Processes notification jobs from the 'notification' queue.
 * Handles push (FCM), SMS (Twilio), WhatsApp, and in-app notifications.
 * Implements per-channel rate limiting.
 */
@Processor('notification', {
  concurrency: 10,
  limiter: { max: 100, duration: 60000 }, // 100 notifications per minute
  lockDuration: 30000,
})
export class NotificationConsumer extends WorkerHost {
  private readonly logger = new Logger(NotificationConsumer.name);

  constructor(
    private readonly notificationProcessor: NotificationProcessor,
    private readonly queueService: QueueService,
  ) {
    super();
  }

  async process(job: Job<NotificationPayload>): Promise<unknown> {
    const startTime = Date.now();
    const { channel, to, category } = job.data;

    this.logger.log(
      `[Job ${job.id}] Sending ${channel} notification [${category}] to ${to.substring(0, 20)}... — attempt ${job.attemptsMade + 1}/${job.opts.attempts}`,
    );

    try {
      const result = await this.notificationProcessor.send(job.data);
      const duration = Date.now() - startTime;
      this.logger.log(
        `[Job ${job.id}] ${channel} notification completed in ${duration}ms — ${result.status}`,
      );
      return result;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`[Job ${job.id}] Notification failed: ${message}`);
      throw err;
    }
  }

  @OnWorkerEvent('completed')
  onCompleted(job: Job): void {
    this.logger.log(`[Job ${job.id}] Notification job completed`);
  }

  @OnWorkerEvent('failed')
  async onFailed(job: Job, error: Error): Promise<void> {
    this.logger.error(`[Job ${job.id}] Notification job failed: ${error.message}`);

    if (job.attemptsMade >= (job.opts.attempts || 3)) {
      this.logger.warn(
        `[Job ${job.id}] Max retries reached — moving to dead-letter queue`,
      );
      try {
        await this.queueService.moveToDeadLetter(
          'notification',
          job.id as string,
          error.message,
        );
      } catch (dlqErr: unknown) {
        const dlqMsg = dlqErr instanceof Error ? dlqErr.message : 'Unknown error';
        this.logger.error(`[Job ${job.id}] Failed to move to DLQ: ${dlqMsg}`);
      }
    }
  }

  @OnWorkerEvent('stalled')
  onStalled(jobId: string): void {
    this.logger.warn(`[Job ${jobId}] Notification job stalled`);
  }
}
