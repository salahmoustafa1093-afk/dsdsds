import { Processor, WorkerHost, OnWorkerEvent } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { SyncProcessor, SyncPayload } from '../processors/sync.processor';
import { QueueService } from '../queue.service';

/**
 * Sync Consumer
 *
 * Processes mobile data sync jobs from the 'sync' queue.
 * Handles push, pull, bidirectional sync, and conflict resolution.
 * Long-running syncs use extended lock duration.
 */
@Processor('sync', {
  concurrency: 10,
  limiter: { max: 30, duration: 60000 }, // 30 syncs per minute
  lockDuration: 120000, // 2 minute lock for large syncs
})
export class SyncConsumer extends WorkerHost {
  private readonly logger = new Logger(SyncConsumer.name);

  constructor(
    private readonly syncProcessor: SyncProcessor,
    private readonly queueService: QueueService,
  ) {
    super();
  }

  async process(job: Job<SyncPayload>): Promise<unknown> {
    const startTime = Date.now();
    const { operation, companyId, userId } = job.data;

    this.logger.log(
      `[Job ${job.id}] Processing ${operation} sync for company ${companyId}, user ${userId} — attempt ${job.attemptsMade + 1}/${job.opts.attempts}`,
    );

    try {
      const result = await this.syncProcessor.sync(job.data);
      const duration = Date.now() - startTime;

      const totalRecords = result.syncedEntities.reduce(
        (sum, e) => sum + e.pushed + e.pulled,
        0,
      );
      this.logger.log(
        `[Job ${job.id}] ${operation} sync completed in ${duration}ms — ${totalRecords} records synced`,
      );

      return result;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`[Job ${job.id}] Sync failed: ${message}`);
      throw err;
    }
  }

  @OnWorkerEvent('completed')
  onCompleted(job: Job): void {
    this.logger.log(`[Job ${job.id}] Sync job completed`);
  }

  @OnWorkerEvent('failed')
  async onFailed(job: Job, error: Error): Promise<void> {
    this.logger.error(`[Job ${job.id}] Sync job failed: ${error.message}`);

    if (job.attemptsMade >= (job.opts.attempts || 3)) {
      this.logger.warn(
        `[Job ${job.id}] Max retries reached — moving to dead-letter queue`,
      );
      try {
        await this.queueService.moveToDeadLetter(
          'sync',
          job.id as string,
          error.message,
        );
      } catch (dlqErr: unknown) {
        const dlqMsg = dlqErr instanceof Error ? dlqErr.message : 'Unknown error';
        this.logger.error(`[Job ${job.id}] Failed to move to DLQ: ${dlqMsg}`);
      }
    }
  }

  @OnWorkerEvent('stalled')
  onStalled(jobId: string): void {
    this.logger.warn(`[Job ${jobId}] Sync job stalled`);
  }
}
