import { Processor, WorkerHost, OnWorkerEvent } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { EmailProcessor, EmailPayload } from '../processors/email.processor';
import { QueueService } from '../queue.service';

/**
 * Email Consumer
 *
 * Processes email jobs from the 'email' queue with exponential backoff.
 * Handles failed jobs by retrying and ultimately moving to dead-letter queue.
 */
@Processor('email', {
  concurrency: 5,
  limiter: { max: 30, duration: 60000 }, // 30 emails per minute
  lockDuration: 30000,
})
export class EmailConsumer extends WorkerHost {
  private readonly logger = new Logger(EmailConsumer.name);

  constructor(
    private readonly emailProcessor: EmailProcessor,
    private readonly queueService: QueueService,
  ) {
    super();
  }

  async process(job: Job<EmailPayload & { _meta?: { queueName: string } }>): Promise<unknown> {
    const startTime = Date.now();
    const { category } = job.data;

    this.logger.log(`[Job ${job.id}] Processing email [${category}] — attempt ${job.attemptsMade + 1}/${job.opts.attempts}`);

    try {
      let result: unknown;

      switch (category) {
        case 'password-reset':
          result = await this.emailProcessor.sendPasswordReset(job.data);
          break;
        case 'order-confirmation':
          result = await this.emailProcessor.sendOrderConfirmation(job.data);
          break;
        case 'low-stock':
          result = await this.emailProcessor.sendLowStockAlert(job.data);
          break;
        default:
          result = await this.emailProcessor.healthCheck();
          break;
      }

      const duration = Date.now() - startTime;
      this.logger.log(`[Job ${job.id}] Email [${category}] sent in ${duration}ms`);

      return result;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`[Job ${job.id}] Email processing failed: ${message}`);
      throw err; // Re-throw for BullMQ retry logic
    }
  }

  @OnWorkerEvent('completed')
  onCompleted(job: Job): void {
    this.logger.log(`[Job ${job.id}] Email job completed successfully`);
  }

  @OnWorkerEvent('failed')
  async onFailed(job: Job, error: Error): Promise<void> {
    this.logger.error(`[Job ${job.id}] Email job failed: ${error.message}`);

    // Move to dead letter queue after all retries exhausted
    if (job.attemptsMade >= (job.opts.attempts || 3)) {
      this.logger.warn(`[Job ${job.id}] Max retries reached — moving to dead-letter queue`);
      try {
        await this.queueService.moveToDeadLetter('email', job.id as string, error.message);
      } catch (dlqErr: unknown) {
        const dlqMsg = dlqErr instanceof Error ? dlqErr.message : 'Unknown error';
        this.logger.error(`[Job ${job.id}] Failed to move to DLQ: ${dlqMsg}`);
      }
    }
  }

  @OnWorkerEvent('stalled')
  onStalled(jobId: string): void {
    this.logger.warn(`[Job ${jobId}] Email job stalled`);
  }
}
