import { Processor, WorkerHost, OnWorkerEvent } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { ReportProcessor, ReportPayload } from '../processors/report.processor';
import { QueueService } from '../queue.service';

/**
 * Report Consumer
 *
 * Processes report generation jobs from the 'report' queue.
 * Heavy CPU/memory tasks run with limited concurrency.
 * Failed jobs after max retries are moved to dead-letter queue.
 */
@Processor('report', {
  concurrency: 2, // Limit concurrent reports to prevent memory exhaustion
  limiter: { max: 10, duration: 60000 }, // 10 reports per minute
  lockDuration: 300000, // 5 minute lock for long-running reports
})
export class ReportConsumer extends WorkerHost {
  private readonly logger = new Logger(ReportConsumer.name);

  constructor(
    private readonly reportProcessor: ReportProcessor,
    private readonly queueService: QueueService,
  ) {
    super();
  }

  async process(job: Job<ReportPayload>): Promise<unknown> {
    const startTime = Date.now();
    const { reportType, companyId, format } = job.data;

    this.logger.log(
      `[Job ${job.id}] Generating ${reportType} report for company ${companyId} (${format}) — attempt ${job.attemptsMade + 1}/${job.opts.attempts}`,
    );

    try {
      const result = await this.reportProcessor.generate(job.data);
      const duration = Date.now() - startTime;
      this.logger.log(
        `[Job ${job.id}] Report ${reportType} completed in ${duration}ms — status: ${result.status}`,
      );
      return result;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`[Job ${job.id}] Report generation failed: ${message}`);
      throw err;
    }
  }

  @OnWorkerEvent('completed')
  onCompleted(job: Job): void {
    this.logger.log(`[Job ${job.id}] Report job completed`);
  }

  @OnWorkerEvent('failed')
  async onFailed(job: Job, error: Error): Promise<void> {
    this.logger.error(`[Job ${job.id}] Report job failed: ${error.message}`);

    if (job.attemptsMade >= (job.opts.attempts || 3)) {
      this.logger.warn(`[Job ${job.id}] Max retries reached — moving to dead-letter queue`);
      try {
        await this.queueService.moveToDeadLetter('report', job.id as string, error.message);
      } catch (dlqErr: unknown) {
        const dlqMsg = dlqErr instanceof Error ? dlqErr.message : 'Unknown error';
        this.logger.error(`[Job ${job.id}] Failed to move to DLQ: ${dlqMsg}`);
      }
    }
  }

  @OnWorkerEvent('stalled')
  onStalled(jobId: string): void {
    this.logger.warn(`[Job ${jobId}] Report job stalled`);
  }
}
