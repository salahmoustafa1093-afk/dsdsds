import { Module, Global } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { QueueService } from './queue.service';
import { EmailProcessor } from './processors/email.processor';
import { ReportProcessor } from './processors/report.processor';
import { DeliveryProcessor } from './processors/delivery.processor';
import { NotificationProcessor } from './processors/notification.processor';
import { SyncProcessor } from './processors/sync.processor';
import { AuditProcessor } from './processors/audit.processor';
import { EmailConsumer } from './consumers/email.consumer';
import { ReportConsumer } from './consumers/report.consumer';
import { DeliveryConsumer } from './consumers/delivery.consumer';
import { NotificationConsumer } from './consumers/notification.consumer';
import { SyncConsumer } from './consumers/sync.consumer';
import { AuditConsumer } from './consumers/audit.consumer';

/**
 * Global BullMQ Queue Module
 *
 * Registers all queues, processors, and consumers.
 * Provides QueueService for job management across the application.
 */
@Global()
@Module({
  imports: [
    ConfigModule,
    BullModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => {
        const host = configService.get<string>('REDIS_HOST', 'localhost');
        const port = configService.get<number>('REDIS_PORT', 6379);
        const password = configService.get<string>('REDIS_PASSWORD', undefined);
        const db = configService.get<number>('REDIS_QUEUE_DB', 1);

        return {
          connection: {
            host,
            port,
            password,
            db,
            maxRetriesPerRequest: 3,
            connectTimeout: 10000,
            enableReadyCheck: true,
          },
          defaultJobOptions: {
            attempts: 3,
            backoff: {
              type: 'exponential',
              delay: 5000,
            },
            removeOnComplete: {
              age: 86400,
              count: 1000,
            },
            removeOnFail: {
              age: 604800,
              count: 5000,
            },
          },
        };
      },
      inject: [ConfigService],
    }),
    BullModule.registerQueue(
      { name: 'email' },
      { name: 'report' },
      { name: 'delivery' },
      { name: 'notification' },
      { name: 'sync' },
      { name: 'audit' },
      { name: 'dead-letter' },
    ),
  ],
  providers: [
    QueueService,
    // Processors
    EmailProcessor,
    ReportProcessor,
    DeliveryProcessor,
    NotificationProcessor,
    SyncProcessor,
    AuditProcessor,
    // Consumers (integrate processors with BullMQ)
    EmailConsumer,
    ReportConsumer,
    DeliveryConsumer,
    NotificationConsumer,
    SyncConsumer,
    AuditConsumer,
  ],
  exports: [QueueService],
})
export class QueueModule {}
