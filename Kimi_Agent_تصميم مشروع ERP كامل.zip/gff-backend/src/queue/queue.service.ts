import { Injectable, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue, Job, JobType, JobCounts } from 'bullmq';

export interface JobMetrics {
  counts: JobCounts;
  throughput: { completed: number; failed: number; ratePerMinute: number };
  failedCount: number;
  waitingCount: number;
  activeCount: number;
  completedCount: number;
  delayedCount: number;
  paused: boolean;
}

export interface AddJobOptions {
  priority?: number;
  delay?: number;
  attempts?: number;
  backoff?: { type: 'exponential' | 'fixed'; delay: number };
  removeOnComplete?: boolean | { age: number; count: number };
  removeOnFail?: boolean | { age: number; count: number };
  jobId?: string;
  repeat?: { cron: string };
}

@Injectable()
export class QueueService {
  private readonly logger = new Logger(QueueService.name);
  private throughputTracker = new Map<
    string,
    { completed: number; failed: number; timestamp: number }
  >();

  constructor(
    @InjectQueue('email') private readonly emailQueue: Queue,
    @InjectQueue('report') private readonly reportQueue: Queue,
    @InjectQueue('delivery') private readonly deliveryQueue: Queue,
    @InjectQueue('notification') private readonly notificationQueue: Queue,
    @InjectQueue('sync') private readonly syncQueue: Queue,
    @InjectQueue('audit') private readonly auditQueue: Queue,
    @InjectQueue('dead-letter') private readonly deadLetterQueue: Queue,
  ) {}

  /** Resolve a queue by its name */
  private getQueue(queueName: string): Queue {
    switch (queueName) {
      case 'email':
        return this.emailQueue;
      case 'report':
        return this.reportQueue;
      case 'delivery':
        return this.deliveryQueue;
      case 'notification':
        return this.notificationQueue;
      case 'sync':
        return this.syncQueue;
      case 'audit':
        return this.auditQueue;
      case 'dead-letter':
        return this.deadLetterQueue;
      default:
        throw new Error(`Unknown queue: ${queueName}`);
    }
  }

  /**
   * Add a job to a named queue.
   *
   * @param queueName - Target queue name
   * @param jobName   - Job processor name (maps to @Processor handler)
   * @param data      - Serializable job payload
   * @param opts      - BullMQ job options
   * @returns The created Job instance
   */
  async addJob<T = unknown>(
    queueName: string,
    jobName: string,
    data: T,
    opts: AddJobOptions = {},
  ): Promise<Job<T>> {
    const queue = this.getQueue(queueName);
    const job = await queue.add(jobName, data, {
      ...opts,
      attempts: opts.attempts ?? 3,
      backoff: opts.backoff ?? { type: 'exponential', delay: 5000 },
    });
    this.logger.log(`Job ${job.id} [${jobName}] added to queue [${queueName}]`);
    return job;
  }

  /**
   * Add multiple jobs in a single pipeline (batch insert).
   */
  async addBulk<T = unknown>(
    queueName: string,
    jobs: { name: string; data: T; opts?: AddJobOptions }[],
  ): Promise<Job<T>[]> {
    const queue = this.getQueue(queueName);
    const result = await queue.addBulk(
      jobs.map((j) => ({
        name: j.name,
        data: j.data,
        opts: {
          ...j.opts,
          attempts: j.opts?.attempts ?? 3,
          backoff: j.opts?.backoff ?? { type: 'exponential', delay: 5000 },
        },
      })),
    );
    this.logger.log(
      `Bulk added ${result.length} jobs to queue [${queueName}]`,
    );
    return result;
  }

  /** Retrieve a single job by its ID */
  async getJob(queueName: string, jobId: string): Promise<Job | null> {
    const queue = this.getQueue(queueName);
    return queue.getJob(jobId);
  }

  /** Retrieve jobs filtered by status */
  async getJobs(
    queueName: string,
    status: JobType | JobType[] = ['completed', 'failed', 'waiting', 'active', 'delayed'],
    start = 0,
    end = 100,
  ): Promise<Job[]> {
    const queue = this.getQueue(queueName);
    const types = Array.isArray(status) ? status : [status];
    return queue.getJobs(types, start, end, true);
  }

  /** Remove a specific job from a queue */
  async removeJob(queueName: string, jobId: string): Promise<boolean> {
    const queue = this.getQueue(queueName);
    const job = await queue.getJob(jobId);
    if (!job) return false;
    await job.remove();
    this.logger.log(`Job ${jobId} removed from queue [${queueName}]`);
    return true;
  }

  /** Pause a queue (no new jobs picked up by workers) */
  async pauseQueue(queueName: string): Promise<void> {
    const queue = this.getQueue(queueName);
    await queue.pause();
    this.logger.log(`Queue [${queueName}] paused`);
  }

  /** Resume a paused queue */
  async resumeQueue(queueName: string): Promise<void> {
    const queue = this.getQueue(queueName);
    await queue.resume();
    this.logger.log(`Queue [${queueName}] resumed`);
  }

  /** Empty all jobs from a queue */
  async emptyQueue(queueName: string): Promise<void> {
    const queue = this.getQueue(queueName);
    await queue.drain();
    this.logger.log(`Queue [${queueName}] emptied`);
  }

  /** Trim completed/failed jobs older than the given age (seconds) */
  async trimQueue(queueName: string, ageSeconds: number): Promise<void> {
    const queue = this.getQueue(queueName);
    await queue.trimEvents(ageSeconds);
    this.logger.log(`Queue [${queueName}] trimmed (age > ${ageSeconds}s)`);
  }

  /** Get comprehensive queue metrics */
  async getQueueMetrics(queueName: string): Promise<JobMetrics> {
    const queue = this.getQueue(queueName);
    const counts = await queue.getJobCounts(
      'waiting',
      'active',
      'completed',
      'failed',
      'delayed',
      'paused',
    );

    const now = Date.now();
    const tracker = this.throughputTracker.get(queueName);

    let ratePerMinute = 0;
    if (tracker) {
      const elapsed = (now - tracker.timestamp) / 60000;
      if (elapsed > 0) {
        const completedDelta = (counts.completed || 0) - tracker.completed;
        const failedDelta = (counts.failed || 0) - tracker.failed;
        ratePerMinute = (completedDelta + failedDelta) / elapsed;
      }
    }

    this.throughputTracker.set(queueName, {
      completed: counts.completed || 0,
      failed: counts.failed || 0,
      timestamp: now,
    });

    const isPaused = await queue.isPaused();

    return {
      counts,
      throughput: {
        completed: counts.completed || 0,
        failed: counts.failed || 0,
        ratePerMinute: Math.round(ratePerMinute * 100) / 100,
      },
      failedCount: counts.failed || 0,
      waitingCount: counts.waiting || 0,
      activeCount: counts.active || 0,
      completedCount: counts.completed || 0,
      delayedCount: counts.delayed || 0,
      paused: isPaused,
    };
  }

  /** Retry a failed job */
  async retryJob(queueName: string, jobId: string): Promise<void> {
    const queue = this.getQueue(queueName);
    const job = await queue.getJob(jobId);
    if (!job) throw new Error(`Job ${jobId} not found in queue ${queueName}`);
    await job.retry();
    this.logger.log(`Job ${jobId} retried in queue [${queueName}]`);
  }

  /** Move a failed job to the dead-letter queue for later inspection */
  async moveToDeadLetter(
    queueName: string,
    jobId: string,
    reason: string,
  ): Promise<Job> {
    const queue = this.getQueue(queueName);
    const job = await queue.getJob(jobId);
    if (!job) throw new Error(`Job ${jobId} not found`);

    const dlqJob = await this.deadLetterQueue.add(
      'dead-letter',
      {
        originalQueue: queueName,
        originalJobId: jobId,
        originalJobName: job.name,
        data: job.data,
        failedReason: job.failedReason,
        stacktrace: job.stacktrace,
        moveReason: reason,
        movedAt: new Date().toISOString(),
      },
      {
        attempts: 10,
        backoff: { type: 'fixed', delay: 60000 },
      },
    );

    await job.remove();
    this.logger.warn(
      `Job ${jobId} moved from [${queueName}] to dead-letter queue (reason: ${reason})`,
    );
    return dlqJob;
  }

  /** Get all queue names managed by this service */
  getQueueNames(): string[] {
    return ['email', 'report', 'delivery', 'notification', 'sync', 'audit', 'dead-letter'];
  }

  /** Get waiting children for a flow job */
  async getWaitingChildren(queueName: string, jobId: string): Promise<Job[]> {
    const queue = this.getQueue(queueName);
    const job = await queue.getJob(jobId);
    if (!job) return [];
    return job.getChildrenValues().then(() => []); // flow jobs not used in current config
  }

  /** Close all queue connections gracefully */
  async onModuleDestroy(): Promise<void> {
    const queues = [
      this.emailQueue,
      this.reportQueue,
      this.deliveryQueue,
      this.notificationQueue,
      this.syncQueue,
      this.auditQueue,
      this.deadLetterQueue,
    ];
    await Promise.all(queues.map((q) => q.close()));
    this.logger.log('All queue connections closed');
  }
}
