import { Injectable, Logger } from '@nestjs/common';

export interface SyncPayload {
  /** Type of sync operation */
  operation: 'push' | 'pull' | 'bidirectional' | 'conflict-resolve' | 'full-refresh' | 'delta-sync';
  /** Company/tenant ID */
  companyId: string;
  /** User/device initiating the sync */
  userId: string;
  deviceId?: string;
  /** Tables/entities to sync */
  entities: Array<{
    name: string;
    lastSyncAt?: string;
    filters?: Record<string, unknown>;
  }>;
  /** Data being pushed from mobile */
  pushData?: Array<{
    entity: string;
    records: Record<string, unknown>[];
    deletedIds?: string[];
  }>;
  /** Sync direction preferences per entity */
  syncConfig?: Record<string, 'client-wins' | 'server-wins' | 'manual' | 'last-write-wins'>;
  /** Batch size for large syncs */
  batchSize?: number;
  /** Client timestamp for conflict detection */
  clientTimestamp: string;
  /** Client schema version */
  schemaVersion?: string;
  /** Metadata */
  metadata?: Record<string, unknown>;
}

export interface SyncResult {
  operation: string;
  status: 'completed' | 'failed' | 'partial' | 'conflicts-detected';
  syncedEntities: Array<{
    entity: string;
    pushed: number;
    pulled: number;
    conflicts: number;
    deleted: number;
    lastSyncAt: string;
  }>;
  conflicts?: Array<{
    entity: string;
    recordId: string;
    serverVersion: Record<string, unknown>;
    clientVersion: Record<string, unknown>;
  }>;
  processingTimeMs: number;
  nextSyncToken?: string;
  errors?: string[];
}

/**
 * Sync Processor
 *
 * Handles mobile data synchronization:
 * - Push: Client uploads local changes to server
 * - Pull: Server sends changes since last sync to client
 * - Bidirectional: Two-way sync with conflict resolution
 * - Conflict-resolve: Handle data conflicts using configured strategy
 * - Full-refresh: Complete data refresh for initial sync
 * - Delta-sync: Incremental sync using change tracking
 *
 * Implements offline-first pattern with conflict resolution strategies.
 */
@Injectable()
export class SyncProcessor {
  private readonly logger = new Logger(SyncProcessor.name);
  private readonly defaultBatchSize = parseInt(
    process.env.SYNC_BATCH_SIZE || '500',
    10,
  );
  private readonly maxRecordSize = parseInt(
    process.env.SYNC_MAX_RECORD_SIZE || '10000',
    10,
  );

  /**
   * Main sync entry point.
   * Dispatches to the appropriate handler based on operation type.
   */
  async sync(payload: SyncPayload): Promise<SyncResult> {
    const startTime = Date.now();
    const { operation, companyId, userId, deviceId } = payload;

    this.logger.log(`Starting ${operation} sync for company ${companyId}, user ${userId}${deviceId ? `, device ${deviceId}` : ''}`);

    try {
      let result: SyncResult;

      switch (operation) {
        case 'push':
          result = await this.handlePush(payload);
          break;
        case 'pull':
          result = await this.handlePull(payload);
          break;
        case 'bidirectional':
          result = await this.handleBidirectional(payload);
          break;
        case 'conflict-resolve':
          result = await this.handleConflictResolve(payload);
          break;
        case 'full-refresh':
          result = await this.handleFullRefresh(payload);
          break;
        case 'delta-sync':
          result = await this.handleDeltaSync(payload);
          break;
        default:
          throw new Error(`Unknown sync operation: ${operation}`);
      }

      const processingTimeMs = Date.now() - startTime;
      const totalRecords = result.syncedEntities.reduce(
        (sum, e) => sum + e.pushed + e.pulled,
        0,
      );
      this.logger.log(
        `${operation} sync completed in ${processingTimeMs}ms — ${totalRecords} records synced across ${result.syncedEntities.length} entities`,
      );

      return { ...result, processingTimeMs };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`${operation} sync failed: ${message}`);
      return {
        operation,
        status: 'failed',
        syncedEntities: [],
        processingTimeMs: Date.now() - startTime,
        errors: [message],
      };
    }
  }

  /**
   * Handle push: Client uploads local changes to server.
   * Applies changes in order: deletes first, then inserts/updates.
   */
  private async handlePush(payload: SyncPayload): Promise<SyncResult> {
    const { pushData, companyId, userId, syncConfig } = payload;
    const syncedEntities: SyncResult['syncedEntities'] = [];

    if (!pushData || pushData.length === 0) {
      return {
        operation: 'push',
        status: 'completed',
        syncedEntities: [],
        processingTimeMs: 0,
      };
    }

    for (const entityBatch of pushData) {
      const { entity, records, deletedIds } = entityBatch;
      const config = syncConfig?.[entity] || 'last-write-wins';

      let pushed = 0;
      let conflicts = 0;
      let deleted = 0;

      // Step 1: Process deletions first
      if (deletedIds && deletedIds.length > 0) {
        for (const id of deletedIds) {
          await this.softDeleteRecord(entity, id, companyId);
          deleted++;
        }
      }

      // Step 2: Process inserts/updates with conflict detection
      for (const record of records) {
        const recordId = (record.id as string) || crypto.randomUUID();
        const existingRecord = await this.getServerRecord(entity, recordId, companyId);

        if (existingRecord) {
          // Check for conflicts
          const serverModifiedAt = (existingRecord.updatedAt as string) || '1970-01-01T00:00:00Z';
          const clientModifiedAt = (record.updatedAt as string) || payload.clientTimestamp;

          if (serverModifiedAt > clientModifiedAt) {
            // Conflict detected
            conflicts++;
            const resolution = await this.resolveConflict(
              entity,
              recordId,
              existingRecord,
              record,
              config,
              userId,
            );
            if (resolution === 'server-wins') {
              continue; // Skip client update
            }
          }

          // Apply update
          await this.updateServerRecord(entity, recordId, {
            ...record,
            companyId,
            updatedAt: new Date().toISOString(),
            updatedBy: userId,
          });
        } else {
          // Insert new record
          await this.insertServerRecord(entity, {
            ...record,
            id: recordId,
            companyId,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            createdBy: userId,
            updatedBy: userId,
          });
        }
        pushed++;
      }

      syncedEntities.push({
        entity,
        pushed,
        pulled: 0,
        conflicts,
        deleted,
        lastSyncAt: new Date().toISOString(),
      });
    }

    return {
      operation: 'push',
      status: 'completed',
      syncedEntities,
      processingTimeMs: 0,
    };
  }

  /**
   * Handle pull: Server sends changes since last sync to client.
   * Uses lastSyncAt timestamps for each entity to determine what changed.
   */
  private async handlePull(payload: SyncPayload): Promise<SyncResult> {
    const { entities, companyId, userId } = payload;
    const syncedEntities: SyncResult['syncedEntities'] = [];

    for (const entityDef of entities) {
      const { name, lastSyncAt, filters } = entityDef;
      const batchSize = payload.batchSize || this.defaultBatchSize;

      // Get changed records since last sync
      const changedRecords = await this.getChangedRecords(
        name,
        companyId,
        lastSyncAt,
        filters,
        batchSize,
      );

      // Get deleted record IDs since last sync
      const deletedIds = await this.getDeletedRecordIds(name, companyId, lastSyncAt);

      syncedEntities.push({
        entity: name,
        pushed: 0,
        pulled: changedRecords.length,
        conflicts: 0,
        deleted: deletedIds.length,
        lastSyncAt: new Date().toISOString(),
      });

      // In production: return changedRecords and deletedIds to client
      this.logger.debug(`Pull for ${name}: ${changedRecords.length} changed, ${deletedIds.length} deleted`);
    }

    return {
      operation: 'pull',
      status: 'completed',
      syncedEntities,
      processingTimeMs: 0,
    };
  }

  /**
   * Handle bidirectional sync: Two-way sync with conflict resolution.
   * First pushes client changes, then pulls server changes.
   */
  private async handleBidirectional(payload: SyncPayload): Promise<SyncResult> {
    // Step 1: Push client changes
    const pushResult = await this.handlePush(payload);

    // Step 2: Pull server changes
    const pullResult = await this.handlePull(payload);

    // Merge results
    const merged = payload.entities.map((e) => {
      const pushEntity = pushResult.syncedEntities.find((se) => se.entity === e.name);
      const pullEntity = pullResult.syncedEntities.find((se) => se.entity === e.name);
      return {
        entity: e.name,
        pushed: pushEntity?.pushed || 0,
        pulled: pullEntity?.pulled || 0,
        conflicts: pushEntity?.conflicts || 0,
        deleted: (pushEntity?.deleted || 0) + (pullEntity?.deleted || 0),
        lastSyncAt: new Date().toISOString(),
      };
    });

    return {
      operation: 'bidirectional',
      status: pushResult.conflicts ? 'conflicts-detected' : 'completed',
      syncedEntities: merged,
      processingTimeMs: 0,
    };
  }

  /**
   * Handle conflict resolution with configurable strategies.
   */
  private async handleConflictResolve(payload: SyncPayload): Promise<SyncResult> {
    const { pushData, syncConfig } = payload;
    const syncedEntities: SyncResult['syncedEntities'] = [];

    if (!pushData) {
      return {
        operation: 'conflict-resolve',
        status: 'completed',
        syncedEntities: [],
        processingTimeMs: 0,
      };
    }

    for (const entityBatch of pushData) {
      const { entity, records } = entityBatch;
      const config = syncConfig?.[entity] || 'last-write-wins';
      let resolved = 0;

      for (const record of records) {
        const recordId = (record.id as string) || crypto.randomUUID();
        const existingRecord = await this.getServerRecord(
          entity,
          recordId,
          payload.companyId,
        );

        if (existingRecord) {
          await this.resolveConflict(
            entity,
            recordId,
            existingRecord,
            record,
            config,
            payload.userId,
          );
          resolved++;
        }
      }

      syncedEntities.push({
        entity,
        pushed: 0,
        pulled: 0,
        conflicts: resolved,
        deleted: 0,
        lastSyncAt: new Date().toISOString(),
      });
    }

    return {
      operation: 'conflict-resolve',
      status: 'completed',
      syncedEntities,
      processingTimeMs: 0,
    };
  }

  /**
   * Handle full refresh: Complete data refresh for initial sync.
   * Sends all data for requested entities without filtering.
   */
  private async handleFullRefresh(payload: SyncPayload): Promise<SyncResult> {
    const { entities, companyId } = payload;
    const syncedEntities: SyncResult['syncedEntities'] = [];

    for (const entityDef of entities) {
      const { name, filters } = entityDef;
      const batchSize = payload.batchSize || this.defaultBatchSize;

      // Get all records without lastSyncAt filter
      const allRecords = await this.getAllRecords(name, companyId, filters, batchSize);

      syncedEntities.push({
        entity: name,
        pushed: 0,
        pulled: allRecords.length,
        conflicts: 0,
        deleted: 0,
        lastSyncAt: new Date().toISOString(),
      });

      this.logger.debug(`Full refresh for ${name}: ${allRecords.length} records`);
    }

    return {
      operation: 'full-refresh',
      status: 'completed',
      syncedEntities,
      processingTimeMs: 0,
    };
  }

  /**
   * Handle delta sync: Incremental sync using change tracking.
   * Uses a change log table to track all modifications.
   */
  private async handleDeltaSync(payload: SyncPayload): Promise<SyncResult> {
    const { entities, companyId } = payload;
    const syncedEntities: SyncResult['syncedEntities'] = [];

    for (const entityDef of entities) {
      const { name, lastSyncAt } = entityDef;
      const batchSize = payload.batchSize || this.defaultBatchSize;

      // Read from change log table
      const changes = await this.getChangeLog(name, companyId, lastSyncAt, batchSize);

      let inserts = 0;
      let updates = 0;
      let deletes = 0;

      for (const change of changes) {
        switch (change.operation) {
          case 'INSERT':
            inserts++;
            break;
          case 'UPDATE':
            updates++;
            break;
          case 'DELETE':
            deletes++;
            break;
        }
      }

      syncedEntities.push({
        entity: name,
        pushed: 0,
        pulled: changes.length,
        conflicts: 0,
        deleted: deletes,
        lastSyncAt: new Date().toISOString(),
      });

      this.logger.debug(`Delta sync for ${name}: ${inserts} inserts, ${updates} updates, ${deletes} deletes`);
    }

    return {
      operation: 'delta-sync',
      status: 'completed',
      syncedEntities,
      processingTimeMs: 0,
    };
  }

  /**
   * Conflict resolution with configurable strategy.
   */
  private async resolveConflict(
    entity: string,
    recordId: string,
    serverVersion: Record<string, unknown>,
    clientVersion: Record<string, unknown>,
    strategy: string,
    userId: string,
  ): Promise<string> {
    switch (strategy) {
      case 'server-wins':
        this.logger.debug(`Conflict on ${entity}/${recordId}: server wins`);
        return 'server-wins';

      case 'client-wins':
        await this.updateServerRecord(entity, recordId, {
          ...clientVersion,
          updatedAt: new Date().toISOString(),
          updatedBy: userId,
        });
        this.logger.debug(`Conflict on ${entity}/${recordId}: client wins`);
        return 'client-wins';

      case 'last-write-wins':
        const serverTime = new Date((serverVersion.updatedAt as string) || 0).getTime();
        const clientTime = new Date((clientVersion.updatedAt as string) || 0).getTime();
        if (clientTime > serverTime) {
          await this.updateServerRecord(entity, recordId, {
            ...clientVersion,
            updatedAt: new Date().toISOString(),
            updatedBy: userId,
          });
          return 'client-wins';
        }
        return 'server-wins';

      case 'manual':
        // Flag for manual review
        await this.flagConflictForReview(entity, recordId, serverVersion, clientVersion, userId);
        this.logger.warn(`Conflict on ${entity}/${recordId} flagged for manual review`);
        return 'manual';

      default:
        return 'server-wins';
    }
  }

  // ─── Database Stubs (replace with actual repository calls) ──────────

  private async getServerRecord(
    entity: string,
    recordId: string,
    companyId: string,
  ): Promise<Record<string, unknown> | null> {
    this.logger.debug(`Getting ${entity} record ${recordId} for company ${companyId}`);
    return null;
  }

  private async updateServerRecord(
    entity: string,
    recordId: string,
    data: Record<string, unknown>,
  ): Promise<void> {
    this.logger.debug(`Updating ${entity} record ${recordId}`);
  }

  private async insertServerRecord(
    entity: string,
    data: Record<string, unknown>,
  ): Promise<void> {
    this.logger.debug(`Inserting ${entity} record: ${JSON.stringify(data).substring(0, 200)}`);
  }

  private async softDeleteRecord(
    entity: string,
    recordId: string,
    companyId: string,
  ): Promise<void> {
    this.logger.debug(`Soft-deleting ${entity} record ${recordId} for company ${companyId}`);
  }

  private async getChangedRecords(
    entity: string,
    companyId: string,
    lastSyncAt?: string,
    _filters?: Record<string, unknown>,
    _batchSize?: number,
  ): Promise<Record<string, unknown>[]> {
    this.logger.debug(`Getting changed ${entity} records since ${lastSyncAt} for company ${companyId}`);
    return [];
  }

  private async getDeletedRecordIds(
    entity: string,
    companyId: string,
    lastSyncAt?: string,
  ): Promise<string[]> {
    this.logger.debug(`Getting deleted ${entity} IDs since ${lastSyncAt} for company ${companyId}`);
    return [];
  }

  private async getAllRecords(
    entity: string,
    companyId: string,
    _filters?: Record<string, unknown>,
    _batchSize?: number,
  ): Promise<Record<string, unknown>[]> {
    this.logger.debug(`Getting all ${entity} records for company ${companyId}`);
    return [];
  }

  private async getChangeLog(
    entity: string,
    companyId: string,
    lastSyncAt?: string,
    _batchSize?: number,
  ): Promise<Array<{ operation: string; data: Record<string, unknown> }>> {
    this.logger.debug(`Reading change log for ${entity} since ${lastSyncAt} for company ${companyId}`);
    return [];
  }

  private async flagConflictForReview(
    entity: string,
    recordId: string,
    serverVersion: Record<string, unknown>,
    clientVersion: Record<string, unknown>,
    userId: string,
  ): Promise<void> {
    this.logger.debug(`Flagging ${entity}/${recordId} for review by ${userId}`);
  }
}
