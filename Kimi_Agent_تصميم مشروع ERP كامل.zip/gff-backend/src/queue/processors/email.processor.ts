import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import SMTPTransport from 'nodemailer/lib/smtp-transport';

export interface EmailPayload {
  /** Recipient email address */
  to: string | string[];
  /** Email subject line */
  subject: string;
  /** HTML email body */
  html?: string;
  /** Plain text fallback */
  text?: string;
  /** CC recipients */
  cc?: string | string[];
  /** BCC recipients */
  bcc?: string | string[];
  /** Reply-to address */
  replyTo?: string;
  /** Attachments as base64 or URLs */
  attachments?: Array<{
    filename: string;
    content?: string | Buffer;
    path?: string;
    contentType?: string;
  }>;
  /** Template variables for dynamic content */
  templateVars?: Record<string, unknown>;
  /** Job category for metrics */
  category: 'password-reset' | 'order-confirmation' | 'low-stock' | 'welcome' | 'invoice' | 'generic';
  /** Company context for multi-tenant emails */
  companyId?: string;
  /** Metadata for tracking */
  metadata?: Record<string, unknown>;
}

/**
 * Email Processor
 *
 * Handles all outbound email via SMTP with support for:
 * - Password reset emails
 * - Order confirmations
 * - Low-stock alerts
 * - Welcome/onboarding emails
 * - Invoice delivery
 *
 * Uses connection pooling and rate limiting for reliable delivery.
 */
@Injectable()
export class EmailProcessor {
  private readonly logger = new Logger(EmailProcessor.name);
  private transporter: nodemailer.Transporter<SMTPTransport.SentMessageInfo>;
  private readonly fromAddress: string;
  private readonly fromName: string;
  private readonly rateLimitMs: number;
  private lastSendTime = 0;

  constructor() {
    const host = process.env.SMTP_HOST || 'smtp.example.com';
    const port = parseInt(process.env.SMTP_PORT || '587', 10);
    const secure = process.env.SMTP_SECURE === 'true' || port === 465;
    const user = process.env.SMTP_USER || '';
    const pass = process.env.SMTP_PASS || '';
    const pool = process.env.SMTP_POOL !== 'false';
    const maxConnections = parseInt(process.env.SMTP_MAX_CONNECTIONS || '5', 10);

    this.fromAddress = process.env.EMAIL_FROM_ADDRESS || 'noreply@example.com';
    this.fromName = process.env.EMAIL_FROM_NAME || 'GFF Platform';
    this.rateLimitMs = parseInt(process.env.EMAIL_RATE_LIMIT_MS || '100', 10);

    this.transporter = nodemailer.createTransport({
      pool,
      host,
      port,
      secure,
      auth: { user, pass },
      maxConnections,
      maxMessages: parseInt(process.env.SMTP_MAX_MESSAGES || '100', 10),
      rateDelta: this.rateLimitMs,
      rateLimit: parseInt(process.env.SMTP_RATE_LIMIT || '10', 10),
      tls: {
        rejectUnauthorized: process.env.SMTP_REJECT_UNAUTHORIZED !== 'false',
      },
    } as SMTPTransport.Options);

    this.transporter.verify((err) => {
      if (err) {
        this.logger.error(`SMTP connection failed: ${err.message}`);
      } else {
        this.logger.log(`SMTP connected to ${host}:${port}`);
      }
    });
  }

  /**
   * Send a password reset email to a user.
   * Includes a time-limited reset token link.
   */
  async sendPasswordReset(payload: EmailPayload): Promise<{ messageId: string; accepted: string[] }> {
    const { to, templateVars, metadata } = payload;
    const resetToken = (templateVars?.resetToken as string) || '';
    const resetUrl = (templateVars?.resetUrl as string) || '#';
    const userName = (templateVars?.userName as string) || 'User';
    const expiryMinutes = (templateVars?.expiryMinutes as number) || 30;

    const html = `
      <!DOCTYPE html>
      <html>
        <head><meta charset="utf-8"><title>Password Reset</title></head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #2563eb;">Password Reset Request</h2>
            <p>Hello ${userName},</p>
            <p>We received a request to reset your password. Click the button below to proceed:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetUrl}?token=${resetToken}"
                 style="background: #2563eb; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; display: inline-block;">
                Reset Password
              </a>
            </div>
            <p>Or copy this link: <code>${resetUrl}?token=${resetToken}</code></p>
            <p style="color: #dc2626;">This link expires in ${expiryMinutes} minutes.</p>
            <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;">
            <p style="font-size: 12px; color: #6b7280;">
              If you did not request this, please ignore this email. Your account is safe.
            </p>
          </div>
        </body>
      </html>`;

    const result = await this.send({
      ...payload,
      subject: payload.subject || 'Password Reset Request',
      html,
      text: `Password Reset\n\nHello ${userName},\n\nReset your password: ${resetUrl}?token=${resetToken}\nThis link expires in ${expiryMinutes} minutes.`,
    });

    this.logger.log(`Password reset email sent to ${Array.isArray(to) ? to.join(', ') : to} (msgId: ${result.messageId})`);
    return result;
  }

  /**
   * Send an order confirmation email to a customer.
   */
  async sendOrderConfirmation(payload: EmailPayload): Promise<{ messageId: string; accepted: string[] }> {
    const { to, templateVars } = payload;
    const orderNumber = (templateVars?.orderNumber as string) || 'N/A';
    const items = (templateVars?.items as Array<{ name: string; qty: number; price: number }>) || [];
    const total = (templateVars?.total as number) || 0;
    const customerName = (templateVars?.customerName as string) || 'Valued Customer';
    const orderDate = (templateVars?.orderDate as string) || new Date().toLocaleDateString();

    const itemsHtml = items
      .map(
        (item) => `
          <tr>
            <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;">${item.name}</td>
            <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: center;">${item.qty}</td>
            <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right;">$${item.price.toFixed(2)}</td>
          </tr>`,
      )
      .join('');

    const html = `
      <!DOCTYPE html>
      <html>
        <head><meta charset="utf-8"><title>Order Confirmation</title></head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #059669;">Order Confirmed</h2>
            <p>Hello ${customerName},</p>
            <p>Thank you for your order! Here are the details:</p>
            <div style="background: #f9fafb; padding: 15px; border-radius: 8px; margin: 15px 0;">
              <p><strong>Order #:</strong> ${orderNumber}</p>
              <p><strong>Date:</strong> ${orderDate}</p>
            </div>
            <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
              <thead>
                <tr style="background: #f3f4f6;">
                  <th style="padding: 10px; text-align: left;">Item</th>
                  <th style="padding: 10px; text-align: center;">Qty</th>
                  <th style="padding: 10px; text-align: right;">Price</th>
                </tr>
              </thead>
              <tbody>${itemsHtml}</tbody>
              <tfoot>
                <tr style="font-weight: bold; font-size: 1.1em;">
                  <td colspan="2" style="padding: 15px 10px; text-align: right;">Total:</td>
                  <td style="padding: 15px 10px; text-align: right;">$${total.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>
            <p style="color: #6b7280; font-size: 12px;">Questions? Reply to this email or contact support.</p>
          </div>
        </body>
      </html>`;

    const result = await this.send({
      ...payload,
      subject: payload.subject || `Order Confirmation #${orderNumber}`,
      html,
      text: `Order #${orderNumber} Confirmed\nTotal: $${total.toFixed(2)}\n\nItems:\n${items.map((i) => `- ${i.name} x${i.qty} @ $${i.price.toFixed(2)}`).join('\n')}`,
    });

    this.logger.log(`Order confirmation sent for order #${orderNumber} to ${Array.isArray(to) ? to.join(', ') : to}`);
    return result;
  }

  /**
   * Send a low-stock alert email to inventory managers.
   */
  async sendLowStockAlert(payload: EmailPayload): Promise<{ messageId: string; accepted: string[] }> {
    const { to, templateVars } = payload;
    const productName = (templateVars?.productName as string) || 'Unknown Product';
    const sku = (templateVars?.sku as string) || 'N/A';
    const currentStock = (templateVars?.currentStock as number) || 0;
    const threshold = (templateVars?.threshold as number) || 0;
    const warehouse = (templateVars?.warehouse as string) || 'Main Warehouse';
    const reorderUrl = (templateVars?.reorderUrl as string) || '#';

    const urgencyLevel = currentStock <= threshold * 0.5 ? 'critical' : 'warning';
    const color = urgencyLevel === 'critical' ? '#dc2626' : '#f59e0b';

    const html = `
      <!DOCTYPE html>
      <html>
        <head><meta charset="utf-8"><title>Low Stock Alert</title></head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: ${color}; color: white; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
              <h2 style="margin: 0;">Low Stock Alert — ${urgencyLevel.toUpperCase()}</h2>
            </div>
            <p>The following product is running low on inventory:</p>
            <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
              <tr style="background: #f9fafb;">
                <td style="padding: 10px; font-weight: bold;">Product</td>
                <td style="padding: 10px;">${productName}</td>
              </tr>
              <tr>
                <td style="padding: 10px; font-weight: bold;">SKU</td>
                <td style="padding: 10px;"><code>${sku}</code></td>
              </tr>
              <tr style="background: #f9fafb;">
                <td style="padding: 10px; font-weight: bold;">Current Stock</td>
                <td style="padding: 10px; color: ${color}; font-weight: bold;">${currentStock} units</td>
              </tr>
              <tr>
                <td style="padding: 10px; font-weight: bold;">Threshold</td>
                <td style="padding: 10px;">${threshold} units</td>
              </tr>
              <tr style="background: #f9fafb;">
                <td style="padding: 10px; font-weight: bold;">Warehouse</td>
                <td style="padding: 10px;">${warehouse}</td>
              </tr>
            </table>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${reorderUrl}"
                 style="background: ${color}; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; display: inline-block;">
                Reorder Now
              </a>
            </div>
          </div>
        </body>
      </html>`;

    const result = await this.send({
      ...payload,
      subject: payload.subject || `[${urgencyLevel.toUpperCase()}] Low Stock: ${productName} (${sku})`,
      html,
      text: `LOW STOCK ALERT\n\nProduct: ${productName}\nSKU: ${sku}\nCurrent Stock: ${currentStock}\nThreshold: ${threshold}\nWarehouse: ${warehouse}\n\nAction required: ${reorderUrl}`,
    });

    this.logger.warn(`Low stock alert sent for ${sku} (stock: ${currentStock}, threshold: ${threshold})`);
    return result;
  }

  /** Generic email send with rate limiting */
  private async send(payload: EmailPayload): Promise<{ messageId: string; accepted: string[] }> {
    // Rate limiting
    const now = Date.now();
    const elapsed = now - this.lastSendTime;
    if (elapsed < this.rateLimitMs) {
      await this.sleep(this.rateLimitMs - elapsed);
    }
    this.lastSendTime = Date.now();

    const info = await this.transporter.sendMail({
      from: `"${this.fromName}" <${this.fromAddress}>`,
      to: payload.to,
      cc: payload.cc,
      bcc: payload.bcc,
      replyTo: payload.replyTo,
      subject: payload.subject,
      text: payload.text,
      html: payload.html,
      attachments: payload.attachments,
    });

    this.logger.debug(`Email sent: ${info.messageId}`);
    return { messageId: info.messageId, accepted: info.accepted };
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /** Verify SMTP connection health */
  async healthCheck(): Promise<{ status: string; message: string }> {
    try {
      await this.transporter.verify();
      return { status: 'healthy', message: 'SMTP connection verified' };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      return { status: 'unhealthy', message };
    }
  }
}
