import { Injectable, Logger } from '@nestjs/common';

export interface DeliveryPayload {
  /** Delivery workflow step to execute */
  step: 'gps-batch-update' | 'auto-assign' | 'route-optimize' | 'status-update' | 'proof-of-delivery' | 'delivery-complete';
  /** Delivery/Dispatch ID */
  deliveryId: string;
  /** Company/tenant ID */
  companyId: string;
  /** Associated invoice or order ID */
  orderId?: string;
  /** Driver information */
  driverId?: string;
  /** GPS coordinates payload */
  gpsData?: Array<{
    latitude: number;
    longitude: number;
    timestamp: string;
    accuracy?: number;
  }>;
  /** Route optimization parameters */
  routeParams?: {
    startLocation: { lat: number; lng: number };
    stops: Array<{ lat: number; lng: number; orderId: string; priority: number }>;
    vehicleCapacity?: number;
    timeWindows?: Array<{ start: string; end: string }>;
  };
  /** Status update payload */
  status?: 'pending' | 'assigned' | 'picked_up' | 'in_transit' | 'at_location' | 'delivered' | 'failed' | 'returned';
  /** Proof of delivery data */
  podData?: {
    signatureBase64?: string;
    photoUrls?: string[];
    recipientName?: string;
    recipientId?: string;
    notes?: string;
  };
  /** Metadata for tracking */
  metadata?: Record<string, unknown>;
}

export interface DeliveryResult {
  deliveryId: string;
  step: string;
  status: 'completed' | 'failed' | 'partial';
  message: string;
  processingTimeMs: number;
  data?: Record<string, unknown>;
  errors?: string[];
}

/**
 * Delivery Processor
 *
 * Handles all delivery workflow steps asynchronously:
 * - GPS batch updates: Processes bulk GPS coordinate uploads from driver mobile apps
 * - Auto-assign: Intelligently assigns deliveries to available drivers
 * - Route optimize: Computes optimal delivery routes using VRP solver
 * - Status updates: Propagates delivery status changes
 * - Proof of delivery: Processes signatures, photos, and recipient verification
 * - Delivery complete: Finalizes delivery and triggers downstream workflows
 */
@Injectable()
export class DeliveryProcessor {
  private readonly logger = new Logger(DeliveryProcessor.name);
  private readonly gpsBatchSize = parseInt(
    process.env.DELIVERY_GPS_BATCH_SIZE || '500',
    10,
  );

  /**
   * Main delivery workflow entry point.
   * Dispatches to the appropriate handler based on the step.
   */
  async process(payload: DeliveryPayload): Promise<DeliveryResult> {
    const startTime = Date.now();
    const { step, deliveryId, companyId } = payload;

    this.logger.log(`Processing delivery step "${step}" for ${deliveryId} (company: ${companyId})`);

    try {
      let result: DeliveryResult;

      switch (step) {
        case 'gps-batch-update':
          result = await this.gpsBatchUpdate(payload);
          break;
        case 'auto-assign':
          result = await this.autoAssign(payload);
          break;
        case 'route-optimize':
          result = await this.routeOptimize(payload);
          break;
        case 'status-update':
          result = await this.statusUpdate(payload);
          break;
        case 'proof-of-delivery':
          result = await this.proofOfDelivery(payload);
          break;
        case 'delivery-complete':
          result = await this.deliveryComplete(payload);
          break;
        default:
          throw new Error(`Unknown delivery step: ${step}`);
      }

      const processingTimeMs = Date.now() - startTime;
      this.logger.log(
        `Delivery step "${step}" for ${deliveryId} completed in ${processingTimeMs}ms — ${result.status}`,
      );

      return { ...result, processingTimeMs };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`Delivery step "${step}" for ${deliveryId} failed: ${message}`);
      return {
        deliveryId,
        step,
        status: 'failed',
        message,
        processingTimeMs: Date.now() - startTime,
        errors: [message],
      };
    }
  }

  /**
   * GPS Batch Update
   * Processes bulk GPS coordinate uploads from driver mobile apps.
   * Stores coordinates in time-series format for route playback and ETA calculation.
   */
  private async gpsBatchUpdate(payload: DeliveryPayload): Promise<DeliveryResult> {
    const { deliveryId, driverId, gpsData } = payload;

    if (!gpsData || gpsData.length === 0) {
      return {
        deliveryId,
        step: 'gps-batch-update',
        status: 'failed',
        message: 'No GPS data provided',
        processingTimeMs: 0,
      };
    }

    this.logger.log(`Processing ${gpsData.length} GPS points for delivery ${deliveryId} (driver: ${driverId})`);

    const validPoints = gpsData.filter(
      (p) =>
        p.latitude >= -90 &&
        p.latitude <= 90 &&
        p.longitude >= -180 &&
        p.longitude <= 180,
    );

    const invalidCount = gpsData.length - validPoints.length;
    if (invalidCount > 0) {
      this.logger.warn(`${invalidCount} invalid GPS points filtered out for delivery ${deliveryId}`);
    }

    // Process in batches for memory efficiency
    for (let i = 0; i < validPoints.length; i += this.gpsBatchSize) {
      const batch = validPoints.slice(i, i + this.gpsBatchSize);

      // In production: INSERT INTO delivery_gps_points (delivery_id, driver_id, latitude, longitude, timestamp, accuracy)
      // VALUES ... ON CONFLICT DO NOTHING
      await this.storeGpsPoints(deliveryId, driverId || 'unknown', batch);

      // Yield to event loop
      if (i % (this.gpsBatchSize * 2) === 0) {
        await new Promise((resolve) => setImmediate(resolve));
      }
    }

    // Calculate current speed and ETA from last 5 points
    const lastPoints = validPoints.slice(-5);
    const speedKmh = this.calculateSpeed(lastPoints);

    return {
      deliveryId,
      step: 'gps-batch-update',
      status: 'completed',
      message: `Stored ${validPoints.length} GPS points (${invalidCount} invalid filtered)`,
      processingTimeMs: 0,
      data: {
        pointsProcessed: validPoints.length,
        invalidPoints: invalidCount,
        estimatedSpeedKmh: speedKmh,
        lastPosition: validPoints[validPoints.length - 1],
      },
    };
  }

  /**
   * Auto Assign
   * Intelligently assigns deliveries to available drivers based on:
   * - Proximity to pickup location
   * - Driver workload (current active deliveries)
   * - Vehicle capacity
   * - Driver rating/performance
   * - Historical delivery times in the area
   */
  private async autoAssign(payload: DeliveryPayload): Promise<DeliveryResult> {
    const { deliveryId, companyId, orderId } = payload;

    this.logger.log(`Auto-assigning delivery ${deliveryId} (order: ${orderId})`);

    // Step 1: Get available drivers for this company
    const availableDrivers = await this.getAvailableDrivers(companyId);

    if (availableDrivers.length === 0) {
      return {
        deliveryId,
        step: 'auto-assign',
        status: 'failed',
        message: 'No available drivers for assignment',
        processingTimeMs: 0,
        data: { companyId },
      };
    }

    // Step 2: Score each driver
    const scoredDrivers = availableDrivers.map((driver) => ({
      ...driver,
      score: this.calculateDriverScore(driver, deliveryId),
    }));

    // Step 3: Select best driver
    scoredDrivers.sort((a, b) => b.score - a.score);
    const selectedDriver = scoredDrivers[0];

    // Step 4: Assign delivery
    await this.assignDeliveryToDriver(deliveryId, selectedDriver.id);

    this.logger.log(
      `Delivery ${deliveryId} assigned to driver ${selectedDriver.id} (score: ${selectedDriver.score.toFixed(2)}, active deliveries: ${selectedDriver.activeDeliveries})`,
    );

    return {
      deliveryId,
      step: 'auto-assign',
      status: 'completed',
      message: `Assigned to driver ${selectedDriver.id}`,
      processingTimeMs: 0,
      data: {
        driverId: selectedDriver.id,
        driverName: selectedDriver.name,
        score: selectedDriver.score,
        candidatesConsidered: availableDrivers.length,
      },
    };
  }

  /**
   * Route Optimize
   * Solves the Vehicle Routing Problem (VRP) for a driver's delivery stops.
   * Uses a nearest-neighbor heuristic with time window constraints.
   */
  private async routeOptimize(payload: DeliveryPayload): Promise<DeliveryResult> {
    const { deliveryId, routeParams } = payload;

    if (!routeParams) {
      return {
        deliveryId,
        step: 'route-optimize',
        status: 'failed',
        message: 'No route parameters provided',
        processingTimeMs: 0,
      };
    }

    const { startLocation, stops, vehicleCapacity, timeWindows } = routeParams;
    this.logger.log(`Optimizing route for delivery ${deliveryId} with ${stops.length} stops`);

    if (stops.length === 0) {
      return {
        deliveryId,
        step: 'route-optimize',
        status: 'completed',
        message: 'No stops to optimize',
        processingTimeMs: 0,
        data: { route: [] },
      };
    }

    // Greedy nearest-neighbor with capacity and time window constraints
    const unvisited = [...stops.map((s, idx) => ({ ...s, originalIndex: idx }))];
    const route: typeof unvisited = [];
    let currentPos = { ...startLocation };
    let remainingCapacity = vehicleCapacity || Infinity;

    while (unvisited.length > 0) {
      // Find nearest unvisited stop that fits constraints
      let bestIdx = 0;
      let bestDist = Infinity;

      for (let i = 0; i < unvisited.length; i++) {
        const stop = unvisited[i];

        // Check capacity constraint
        if (remainingCapacity !== Infinity && stop.priority > remainingCapacity) {
          continue;
        }

        // Check time window constraint
        if (timeWindows && timeWindows[stop.originalIndex]) {
          const tw = timeWindows[stop.originalIndex];
          const estimatedArrival = this.estimateArrival(currentPos, stop);
          if (estimatedArrival < tw.start || estimatedArrival > tw.end) {
            continue;
          }
        }

        // Calculate distance (Haversine)
        const dist = this.haversineDistance(
          currentPos.lat,
          currentPos.lng,
          stop.lat,
          stop.lng,
        );

        // Prioritize high-priority stops within a reasonable distance
        const adjustedDist = dist / (1 + stop.priority * 0.1);

        if (adjustedDist < bestDist) {
          bestDist = adjustedDist;
          bestIdx = i;
        }
      }

      const selected = unvisited.splice(bestIdx, 1)[0];
      route.push(selected);
      currentPos = { lat: selected.lat, lng: selected.lng };
      remainingCapacity -= selected.priority;
    }

    // Calculate total route distance
    let totalDistance = 0;
    let prevPos = startLocation;
    for (const stop of route) {
      totalDistance += this.haversineDistance(prevPos.lat, prevPos.lng, stop.lat, stop.lng);
      prevPos = { lat: stop.lat, lng: stop.lng };
    }

    const optimizedRoute = route.map((s, idx) => ({
      sequence: idx + 1,
      orderId: s.orderId,
      lat: s.lat,
      lng: s.lng,
      estimatedMinutes: Math.round(this.estimateTravelMinutes(prevPos, s)),
    }));

    return {
      deliveryId,
      step: 'route-optimize',
      status: 'completed',
      message: `Optimized route with ${stops.length} stops, total ${totalDistance.toFixed(1)} km`,
      processingTimeMs: 0,
      data: {
        stops: stops.length,
        totalDistanceKm: Math.round(totalDistance * 100) / 100,
        estimatedMinutes: optimizedRoute.reduce((sum, s) => sum + s.estimatedMinutes, 0),
        route: optimizedRoute,
      },
    };
  }

  /** Status Update — propagate delivery status changes */
  private async statusUpdate(payload: DeliveryPayload): Promise<DeliveryResult> {
    const { deliveryId, status, orderId } = payload;

    if (!status) {
      return {
        deliveryId,
        step: 'status-update',
        status: 'failed',
        message: 'No status provided',
        processingTimeMs: 0,
      };
    }

    // Valid status transitions
    const validTransitions: Record<string, string[]> = {
      pending: ['assigned', 'picked_up'],
      assigned: ['picked_up', 'failed'],
      picked_up: ['in_transit', 'failed'],
      in_transit: ['at_location', 'failed'],
      at_location: ['delivered', 'failed', 'returned'],
      delivered: [],
      failed: ['returned'],
      returned: ['pending'],
    };

    // Get current status
    const currentStatus = await this.getCurrentStatus(deliveryId);
    const allowedNext = validTransitions[currentStatus] || [];

    if (!allowedNext.includes(status) && currentStatus !== status) {
      return {
        deliveryId,
        step: 'status-update',
        status: 'failed',
        message: `Invalid transition: ${currentStatus} -> ${status}`,
        processingTimeMs: 0,
        data: { currentStatus, requestedStatus: status },
      };
    }

    await this.updateDeliveryStatus(deliveryId, status);

    // If delivered, trigger completion workflow
    if (status === 'delivered' && orderId) {
      // Queue delivery-complete job
      this.logger.log(`Delivery ${deliveryId} delivered — triggering completion workflow`);
    }

    return {
      deliveryId,
      step: 'status-update',
      status: 'completed',
      message: `Status updated: ${currentStatus} -> ${status}`,
      processingTimeMs: 0,
      data: { previousStatus: currentStatus, newStatus: status, orderId },
    };
  }

  /** Proof of Delivery — process signatures, photos, recipient verification */
  private async proofOfDelivery(payload: DeliveryPayload): Promise<DeliveryResult> {
    const { deliveryId, podData } = payload;

    if (!podData) {
      return {
        deliveryId,
        step: 'proof-of-delivery',
        status: 'failed',
        message: 'No POD data provided',
        processingTimeMs: 0,
      };
    }

    const { signatureBase64, photoUrls, recipientName, recipientId, notes } = podData;

    // Validate signature
    if (signatureBase64) {
      const signatureSize = Buffer.from(signatureBase64, 'base64').length;
      if (signatureSize > 5 * 1024 * 1024) {
        return {
          deliveryId,
          step: 'proof-of-delivery',
          status: 'failed',
          message: 'Signature image exceeds 5MB limit',
          processingTimeMs: 0,
        };
      }
      await this.storeSignature(deliveryId, signatureBase64);
    }

    // Validate and store photos
    const validPhotos: string[] = [];
    if (photoUrls && photoUrls.length > 0) {
      for (const url of photoUrls.slice(0, 5)) {
        // Validate URL format and size
        if (this.isValidPhotoUrl(url)) {
          validPhotos.push(url);
        }
      }
    }

    // Store POD record
    await this.storePodRecord(deliveryId, {
      signatureBase64: signatureBase64 ? true : false,
      photos: validPhotos,
      recipientName: recipientName || 'Unknown',
      recipientId,
      notes: notes || '',
      capturedAt: new Date().toISOString(),
    });

    return {
      deliveryId,
      step: 'proof-of-delivery',
      status: 'completed',
      message: `POD captured: ${signatureBase64 ? 'signature, ' : ''}${validPhotos.length} photos`,
      processingTimeMs: 0,
      data: {
        hasSignature: !!signatureBase64,
        photosCaptured: validPhotos.length,
        recipientName,
        recipientId,
      },
    };
  }

  /** Delivery Complete — finalize delivery and trigger downstream workflows */
  private async deliveryComplete(payload: DeliveryPayload): Promise<DeliveryResult> {
    const { deliveryId, orderId, companyId } = payload;

    this.logger.log(`Finalizing delivery ${deliveryId} (order: ${orderId})`);

    // Step 1: Mark delivery as complete in DB
    await this.finalizeDelivery(deliveryId);

    // Step 2: Update order status
    if (orderId) {
      await this.updateOrderStatus(orderId, 'delivered');
    }

    // Step 3: Trigger invoice generation if COD
    const isCod = await this.isCashOnDelivery(orderId || '');
    if (isCod) {
      // Queue invoice generation job
      this.logger.log(`COD delivery ${deliveryId} complete — queuing invoice generation`);
    }

    // Step 4: Update driver stats
    if (payload.driverId) {
      await this.updateDriverStats(payload.driverId, deliveryId);
    }

    // Step 5: Send delivery notification to customer
    // This would queue a notification job

    return {
      deliveryId,
      step: 'delivery-complete',
      status: 'completed',
      message: `Delivery ${deliveryId} finalized successfully`,
      processingTimeMs: 0,
      data: {
        orderId,
        companyId,
        isCod,
        completedAt: new Date().toISOString(),
      },
    };
  }

  // ─── Helpers ───────────────────────────────────────────────────────

  private calculateSpeed(points: Array<{ latitude: number; longitude: number; timestamp: string }>): number {
    if (points.length < 2) return 0;
    const totalDistKm = points.reduce((sum, p, i) => {
      if (i === 0) return 0;
      return sum + this.haversineDistance(points[i - 1].latitude, points[i - 1].longitude, p.latitude, p.longitude);
    }, 0);
    const timeHours = (new Date(points[points.length - 1].timestamp).getTime() - new Date(points[0].timestamp).getTime()) / 3600000;
    return timeHours > 0 ? Math.round((totalDistKm / timeHours) * 100) / 100 : 0;
  }

  private haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private estimateArrival(from: { lat: number; lng: number }, to: { lat: number; lng: number }): string {
    const distKm = this.haversineDistance(from.lat, from.lng, to.lat, to.lng);
    const minutes = Math.round((distKm / 30) * 60); // Assume 30 km/h average
    const arrival = new Date(Date.now() + minutes * 60000);
    return arrival.toISOString();
  }

  private estimateTravelMinutes(from: { lat: number; lng: number }, to: { lat: number; lng: number }): number {
    const distKm = this.haversineDistance(from.lat, from.lng, to.lat, to.lng);
    return Math.round((distKm / 30) * 60);
  }

  private calculateDriverScore(driver: Record<string, unknown>, _deliveryId: string): number {
    const activeDeliveries = (driver.activeDeliveries as number) || 0;
    const rating = (driver.rating as number) || 4.0;
    const proximity = (driver.proximityKm as number) || 10;

    // Lower active deliveries = higher score
    const workloadScore = Math.max(0, 100 - activeDeliveries * 20);
    // Higher rating = higher score
    const ratingScore = rating * 20;
    // Closer proximity = higher score
    const proximityScore = Math.max(0, 100 - proximity * 5);

    return workloadScore * 0.4 + ratingScore * 0.3 + proximityScore * 0.3;
  }

  // ─── GPS & Audit Persistence ──────────────────────────────────────

  private async storeGpsPoints(
    deliveryId: string,
    driverId: string,
    points: DeliveryPayload['gpsData'],
  ): Promise<void> {
    // Implementation: INSERT INTO delivery_gps_points ...
    this.logger.debug(`Storing ${points?.length} GPS points for ${deliveryId}`);
  }

  private async getAvailableDrivers(companyId: string): Promise<Array<Record<string, unknown>>> {
    // Implementation: SELECT * FROM drivers WHERE company_id = $1 AND status = 'available'
    this.logger.debug(`Fetching available drivers for company ${companyId}`);
    return [];
  }

  private async assignDeliveryToDriver(deliveryId: string, driverId: string): Promise<void> {
    // Implementation: UPDATE deliveries SET driver_id = $1, status = 'assigned' WHERE id = $2
    this.logger.debug(`Assigning delivery ${deliveryId} to driver ${driverId}`);
  }

  private async getCurrentStatus(deliveryId: string): Promise<string> {
    // Implementation: SELECT status FROM deliveries WHERE id = $1
    this.logger.debug(`Getting current status for delivery ${deliveryId}`);
    return 'pending';
  }

  private async updateDeliveryStatus(deliveryId: string, status: string): Promise<void> {
    // Implementation: UPDATE deliveries SET status = $1, updated_at = NOW() WHERE id = $2
    this.logger.debug(`Updating delivery ${deliveryId} status to ${status}`);
  }

  private async storeSignature(deliveryId: string, signatureBase64: string): Promise<void> {
    // Implementation: Store in S3/filesystem and save reference
    this.logger.debug(`Storing signature for delivery ${deliveryId} (${signatureBase64.length} chars)`);
  }

  private async storePodRecord(deliveryId: string, podData: Record<string, unknown>): Promise<void> {
    // Implementation: INSERT INTO proof_of_delivery ...
    this.logger.debug(`Storing POD record for delivery ${deliveryId}`);
  }

  private async finalizeDelivery(deliveryId: string): Promise<void> {
    // Implementation: UPDATE deliveries SET status = 'completed', completed_at = NOW() WHERE id = $1
    this.logger.debug(`Finalizing delivery ${deliveryId}`);
  }

  private async updateOrderStatus(orderId: string, status: string): Promise<void> {
    // Implementation: UPDATE orders SET status = $1 WHERE id = $2
    this.logger.debug(`Updating order ${orderId} status to ${status}`);
  }

  private async isCashOnDelivery(orderId: string): Promise<boolean> {
    // Implementation: SELECT payment_method FROM orders WHERE id = $1
    this.logger.debug(`Checking COD status for order ${orderId}`);
    return false;
  }

  private async updateDriverStats(driverId: string, deliveryId: string): Promise<void> {
    // Implementation: UPDATE drivers SET completed_deliveries = completed_deliveries + 1 ...
    this.logger.debug(`Updating stats for driver ${driverId} (delivery: ${deliveryId})`);
  }

  private isValidPhotoUrl(url: string): boolean {
    try {
      const parsed = new URL(url);
      const validHosts = ['s3.amazonaws.com', 'storage.googleapis.com', 'blob.core.windows.net'];
      return validHosts.some((h) => parsed.hostname.includes(h));
    } catch {
      return false;
    }
  }
}
