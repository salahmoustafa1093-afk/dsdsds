import { Injectable, Logger } from '@nestjs/common';

export interface AuditPayload {
  /** Type of audit batch operation */
  operation: 'bulk-insert' | 'archive' | 'export' | 'analyze' | 'cleanup' | 'compliance-check';
  /** Company/tenant ID */
  companyId: string;
  /** Audit log entries to process */
  entries?: Array<{
    id?: string;
    timestamp: string;
    action: string;
    entityType: string;
    entityId: string;
    userId: string;
    userEmail?: string;
    changes?: Record<string, { old: unknown; new: unknown }>;
    metadata?: Record<string, unknown>;
    ipAddress?: string;
    userAgent?: string;
    severity?: 'info' | 'warning' | 'critical';
  }>;
  /** Date range for archive/export/analyze */
  dateRange?: { startDate: string; endDate: string };
  /** Archive configuration */
  archiveConfig?: {
    destination: 's3' | 'gcs' | 'azure' | 'local';
    path?: string;
    compress?: boolean;
    retentionDays?: number;
  };
  /** Analysis parameters */
  analysisConfig?: {
    detectAnomalies?: boolean;
    flagSuspiciousPatterns?: boolean;
    generateComplianceReport?: boolean;
    reportFormat?: 'json' | 'pdf';
  };
  /** Cleanup parameters */
  cleanupConfig?: {
    olderThanDays: number;
    excludeCritical?: boolean;
    dryRun?: boolean;
  };
  /** Batch size for processing */
  batchSize?: number;
  /** Metadata */
  metadata?: Record<string, unknown>;
}

export interface AuditResult {
  operation: string;
  status: 'completed' | 'failed' | 'partial';
  recordsProcessed: number;
  recordsInserted?: number;
  recordsArchived?: number;
  recordsDeleted?: number;
  anomaliesDetected?: number;
  complianceScore?: number;
  outputPath?: string;
  processingTimeMs: number;
  errors?: string[];
  warnings?: string[];
}

/**
 * Audit Processor
 *
 * Handles bulk audit log processing:
 * - Bulk-insert: Efficiently inserts large batches of audit log entries
 * - Archive: Moves old audit logs to cold storage (S3/GCS/Azure)
 * - Export: Exports audit logs in various formats for compliance
 * - Analyze: Detects anomalies and suspicious patterns
 * - Cleanup: Removes old audit logs per retention policy
 * - Compliance-check: Validates compliance requirements
 *
 * Uses batching and streaming for memory-efficient processing of large audit datasets.
 */
@Injectable()
export class AuditProcessor {
  private readonly logger = new Logger(AuditProcessor.name);
  private readonly defaultBatchSize = parseInt(
    process.env.AUDIT_BATCH_SIZE || '1000',
    10,
  );
  private readonly maxBatchSize = 10000;

  /**
   * Main audit processing entry point.
   * Dispatches to the appropriate handler based on operation type.
   */
  async process(payload: AuditPayload): Promise<AuditResult> {
    const startTime = Date.now();
    const { operation, companyId } = payload;

    this.logger.log(`Starting audit ${operation} for company ${companyId}`);

    try {
      let result: AuditResult;

      switch (operation) {
        case 'bulk-insert':
          result = await this.bulkInsert(payload);
          break;
        case 'archive':
          result = await this.archive(payload);
          break;
        case 'export':
          result = await this.export(payload);
          break;
        case 'analyze':
          result = await this.analyze(payload);
          break;
        case 'cleanup':
          result = await this.cleanup(payload);
          break;
        case 'compliance-check':
          result = await this.complianceCheck(payload);
          break;
        default:
          throw new Error(`Unknown audit operation: ${operation}`);
      }

      const processingTimeMs = Date.now() - startTime;
      this.logger.log(
        `Audit ${operation} completed in ${processingTimeMs}ms — ${result.recordsProcessed} records processed`,
      );

      return { ...result, processingTimeMs };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      this.logger.error(`Audit ${operation} failed: ${message}`);
      return {
        operation,
        status: 'failed',
        recordsProcessed: 0,
        processingTimeMs: Date.now() - startTime,
        errors: [message],
      };
    }
  }

  /**
   * Bulk Insert: Efficiently inserts large batches of audit log entries.
   * Uses COPY protocol for PostgreSQL or batch INSERT for other databases.
   */
  private async bulkInsert(payload: AuditPayload): Promise<AuditResult> {
    const { entries, companyId, batchSize } = payload;

    if (!entries || entries.length === 0) {
      return {
        operation: 'bulk-insert',
        status: 'completed',
        recordsProcessed: 0,
        recordsInserted: 0,
        processingTimeMs: 0,
      };
    }

    const effectiveBatchSize = Math.min(
      batchSize || this.defaultBatchSize,
      this.maxBatchSize,
    );
    let inserted = 0;
    let failed = 0;
    const errors: string[] = [];

    this.logger.log(`Bulk inserting ${entries.length} audit entries for company ${companyId} (batch size: ${effectiveBatchSize})`);

    for (let i = 0; i < entries.length; i += effectiveBatchSize) {
      const batch = entries.slice(i, i + effectiveBatchSize);

      // Enrich entries with computed fields
      const enrichedBatch = batch.map((entry) => ({
        ...entry,
        id: entry.id || crypto.randomUUID(),
        companyId,
        processedAt: new Date().toISOString(),
        hash: this.computeEntryHash(entry),
      }));

      try {
        // In production: Use COPY or batch INSERT
        await this.insertAuditBatch(enrichedBatch);
        inserted += enrichedBatch.length;
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Unknown error';
        failed += batch.length;
        errors.push(`Batch ${i / effectiveBatchSize + 1}: ${message}`);
        this.logger.error(`Batch insert failed at offset ${i}: ${message}`);

        // Retry individual records in failed batch
        for (const entry of enrichedBatch) {
          try {
            await this.insertAuditBatch([entry]);
            inserted++;
            failed--;
          } catch (retryErr: unknown) {
            const retryMsg = retryErr instanceof Error ? retryErr.message : 'Unknown error';
            this.logger.error(`Individual insert failed for ${entry.id}: ${retryMsg}`);
          }
        }
      }

      // Yield to event loop
      if (i % (effectiveBatchSize * 5) === 0) {
        await new Promise((resolve) => setImmediate(resolve));
      }
    }

    const status = failed === 0 ? 'completed' : failed < entries.length ? 'partial' : 'failed';

    return {
      operation: 'bulk-insert',
      status,
      recordsProcessed: entries.length,
      recordsInserted: inserted,
      processingTimeMs: 0,
      errors: errors.length > 0 ? errors : undefined,
    };
  }

  /**
   * Archive: Moves old audit logs to cold storage.
   * Supports S3, GCS, Azure Blob, and local filesystem.
   */
  private async archive(payload: AuditPayload): Promise<AuditResult> {
    const { companyId, dateRange, archiveConfig } = payload;

    if (!dateRange) {
      return {
        operation: 'archive',
        status: 'failed',
        recordsProcessed: 0,
        errors: ['Date range is required for archive operation'],
        processingTimeMs: 0,
      };
    }

    const config = archiveConfig || {
      destination: 'local' as const,
      path: `/tmp/audit-archive/${companyId}`,
      compress: true,
    };

    this.logger.log(`Archiving audit logs for ${companyId} (${dateRange.startDate} to ${dateRange.endDate}) -> ${config.destination}`);

    // Step 1: Read audit logs in the date range
    const records = await this.getAuditLogsInRange(
      companyId,
      dateRange.startDate,
      dateRange.endDate,
    );

    if (records.length === 0) {
      return {
        operation: 'archive',
        status: 'completed',
        recordsProcessed: 0,
        recordsArchived: 0,
        processingTimeMs: 0,
      };
    }

    // Step 2: Serialize to NDJSON format
    const lines = records.map((r) => JSON.stringify(r)).join('\n');

    // Step 3: Compress if configured
    let outputData: Buffer | string = lines;
    let extension = 'ndjson';

    if (config.compress) {
      const zlib = await import('zlib');
      outputData = zlib.gzipSync(Buffer.from(lines));
      extension = 'ndjson.gz';
    }

    // Step 4: Store to destination
    const filename = `audit-${companyId}-${dateRange.startDate}_${dateRange.endDate}.${extension}`;
    const outputPath = `${config.path}/${filename}`;

    await this.storeArchive(config.destination, outputPath, outputData);

    // Step 5: Mark archived records (soft delete from hot storage)
    await this.markArchived(companyId, dateRange.startDate, dateRange.endDate, outputPath);

    this.logger.log(`Archived ${records.length} audit records to ${outputPath}`);

    return {
      operation: 'archive',
      status: 'completed',
      recordsProcessed: records.length,
      recordsArchived: records.length,
      outputPath,
      processingTimeMs: 0,
    };
  }

  /**
   * Export: Exports audit logs in various formats for compliance requests.
   */
  private async export(payload: AuditPayload): Promise<AuditResult> {
    const { companyId, dateRange, archiveConfig } = payload;

    if (!dateRange) {
      return {
        operation: 'export',
        status: 'failed',
        recordsProcessed: 0,
        errors: ['Date range is required for export operation'],
        processingTimeMs: 0,
      };
    }

    const format = (archiveConfig?.reportFormat as 'json' | 'pdf' | 'csv') || 'json';
    const records = await this.getAuditLogsInRange(
      companyId,
      dateRange.startDate,
      dateRange.endDate,
    );

    const outputPath = `/tmp/audit-export/${companyId}/audit-export-${Date.now()}.${format}`;
    let outputData: string;

    switch (format) {
      case 'csv':
        outputData = this.convertToCsv(records);
        break;
      case 'pdf':
        outputData = JSON.stringify({ records, exportedAt: new Date().toISOString() });
        break;
      case 'json':
      default:
        outputData = JSON.stringify({ records, exportedAt: new Date().toISOString() }, null, 2);
        break;
    }

    await this.storeArchive('local', outputPath, Buffer.from(outputData));

    return {
      operation: 'export',
      status: 'completed',
      recordsProcessed: records.length,
      outputPath,
      processingTimeMs: 0,
    };
  }

  /**
   * Analyze: Detects anomalies and suspicious patterns in audit logs.
   */
  private async analyze(payload: AuditPayload): Promise<AuditResult> {
    const { companyId, dateRange, analysisConfig } = payload;
    const config = analysisConfig || { detectAnomalies: true, flagSuspiciousPatterns: true };

    const records = await this.getAuditLogsInRange(
      companyId,
      dateRange?.startDate,
      dateRange?.endDate,
    );

    let anomaliesDetected = 0;
    const warnings: string[] = [];

    if (config.detectAnomalies) {
      // Detect unusually high activity from a single user
      const userActivity = this.groupBy(records, (r) => r.userId);
      for (const [userId, userRecords] of userActivity.entries()) {
        if (userRecords.length > 1000) {
          anomaliesDetected++;
          warnings.push(`Unusually high activity: user ${userId} performed ${userRecords.length} actions`);
        }
      }

      // Detect after-hours access patterns
      const afterHoursRecords = records.filter((r) => {
        const hour = new Date(r.timestamp).getHours();
        return hour < 6 || hour > 22;
      });
      if (afterHoursRecords.length > records.length * 0.3) {
        anomaliesDetected++;
        warnings.push(`High after-hours activity: ${afterHoursRecords.length} records (${Math.round((afterHoursRecords.length / records.length) * 100)}%)`);
      }

      // Detect rapid sequential actions (potential automation/scripting)
      const sortedByUser = records.sort(
        (a, b) => a.userId.localeCompare(b.userId) || new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
      );
      for (let i = 1; i < sortedByUser.length; i++) {
        if (sortedByUser[i].userId === sortedByUser[i - 1].userId) {
          const diff =
            new Date(sortedByUser[i].timestamp).getTime() -
            new Date(sortedByUser[i - 1].timestamp).getTime();
          if (diff < 100) {
            anomaliesDetected++;
            warnings.push(`Rapid actions detected for user ${sortedByUser[i].userId}`);
            break; // Only flag once per user
          }
        }
      }
    }

    if (config.flagSuspiciousPatterns) {
      // Detect failed login patterns
      const failedLogins = records.filter(
        (r) => r.action === 'LOGIN_FAILED' || r.action === 'AUTH_FAILURE',
      );
      const failedByIp = this.groupBy(failedLogins, (r) => r.ipAddress || 'unknown');
      for (const [ip, failures] of failedByIp.entries()) {
        if (failures.length > 10) {
          anomaliesDetected++;
          warnings.push(`Brute force attempt suspected from IP ${ip}: ${failures.length} failed logins`);
        }
      }

      // Detect mass data access
      const bulkAccessRecords = records.filter(
        (r) => r.action === 'BULK_EXPORT' || r.action === 'MASS_DOWNLOAD',
      );
      if (bulkAccessRecords.length > 5) {
        anomaliesDetected++;
        warnings.push(`${bulkAccessRecords.length} bulk data access events detected`);
      }
    }

    return {
      operation: 'analyze',
      status: 'completed',
      recordsProcessed: records.length,
      anomaliesDetected,
      complianceScore: Math.max(0, 100 - anomaliesDetected * 5),
      processingTimeMs: 0,
      warnings: warnings.length > 0 ? warnings : undefined,
    };
  }

  /**
   * Cleanup: Removes old audit logs per retention policy.
   * Supports dry-run mode for safe preview.
   */
  private async cleanup(payload: AuditPayload): Promise<AuditResult> {
    const { companyId, cleanupConfig } = payload;

    if (!cleanupConfig) {
      return {
        operation: 'cleanup',
        status: 'failed',
        recordsProcessed: 0,
        errors: ['Cleanup configuration is required'],
        processingTimeMs: 0,
      };
    }

    const { olderThanDays, excludeCritical = true, dryRun = false } = cleanupConfig;
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);

    this.logger.log(`Cleaning up audit logs older than ${cutoffDate.toISOString()} for company ${companyId}${dryRun ? ' (DRY RUN)' : ''}${excludeCritical ? ' (excluding critical)' : ''}`);

    // Get records to delete
    const recordsToDelete = await this.getAuditLogsToDelete(
      companyId,
      cutoffDate.toISOString(),
      excludeCritical,
    );

    if (!dryRun && recordsToDelete.length > 0) {
      await this.deleteAuditLogs(companyId, cutoffDate.toISOString(), excludeCritical);
    }

    return {
      operation: 'cleanup',
      status: 'completed',
      recordsProcessed: recordsToDelete.length,
      recordsDeleted: dryRun ? 0 : recordsToDelete.length,
      processingTimeMs: 0,
      warnings: dryRun ? [`DRY RUN: Would delete ${recordsToDelete.length} records`] : undefined,
    };
  }

  /**
   * Compliance Check: Validates compliance requirements.
   */
  private async complianceCheck(payload: AuditPayload): Promise<AuditResult> {
    const { companyId, dateRange } = payload;

    const records = await this.getAuditLogsInRange(
      companyId,
      dateRange?.startDate,
      dateRange?.endDate,
    );

    let complianceScore = 100;
    const warnings: string[] = [];

    // Check 1: All records must have userId
    const missingUserId = records.filter((r) => !r.userId);
    if (missingUserId.length > 0) {
      complianceScore -= 10;
      warnings.push(`${missingUserId.length} records missing userId`);
    }

    // Check 2: All records must have timestamp
    const missingTimestamp = records.filter((r) => !r.timestamp);
    if (missingTimestamp.length > 0) {
      complianceScore -= 10;
      warnings.push(`${missingTimestamp.length} records missing timestamp`);
    }

    // Check 3: IP address must be present for authentication actions
    const authWithoutIp = records.filter(
      (r) => (r.action === 'LOGIN' || r.action === 'LOGOUT') && !r.ipAddress,
    );
    if (authWithoutIp.length > 0) {
      complianceScore -= 15;
      warnings.push(`${authWithoutIp.length} auth records missing IP address`);
    }

    // Check 4: Changes must be recorded for data modifications
    const modifyWithoutChanges = records.filter(
      (r) =>
        (r.action === 'UPDATE' || r.action === 'DELETE') &&
        (!r.changes || Object.keys(r.changes).length === 0),
    );
    if (modifyWithoutChanges.length > 0) {
      complianceScore -= 10;
      warnings.push(`${modifyWithoutChanges.length} modification records missing change details`);
    }

    // Check 5: No gaps in audit log (continuous sequence)
    const sortedTimestamps = records
      .map((r) => new Date(r.timestamp).getTime())
      .filter((t) => !isNaN(t))
      .sort((a, b) => a - b);
    if (sortedTimestamps.length > 1) {
      const maxGap = 86400000 * 7; // 7 days
      for (let i = 1; i < sortedTimestamps.length; i++) {
        if (sortedTimestamps[i] - sortedTimestamps[i - 1] > maxGap) {
          const gapDays = Math.round((sortedTimestamps[i] - sortedTimestamps[i - 1]) / 86400000);
          warnings.push(`Gap detected in audit log: ${gapDays} days`);
          complianceScore -= 5;
          break;
        }
      }
    }

    return {
      operation: 'compliance-check',
      status: 'completed',
      recordsProcessed: records.length,
      complianceScore: Math.max(0, complianceScore),
      processingTimeMs: 0,
      warnings: warnings.length > 0 ? warnings : undefined,
    };
  }

  // ─── Helpers ────────────────────────────────────────────────────────

  private computeEntryHash(entry: AuditPayload['entries'][0]): string {
    const crypto = require('crypto');
    const data = `${entry.timestamp}|${entry.action}|${entry.entityType}|${entry.entityId}|${entry.userId}`;
    return crypto.createHash('sha256').update(data).digest('hex').substring(0, 16);
  }

  private groupBy<T, K>(array: T[], keyFn: (item: T) => K): Map<K, T[]> {
    const map = new Map<K, T[]>();
    for (const item of array) {
      const key = keyFn(item);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(item);
    }
    return map;
  }

  private convertToCsv(records: Array<Record<string, unknown>>): string {
    if (records.length === 0) return '';
    const headers = Object.keys(records[0]);
    const rows = records.map((r) =>
      headers
        .map((h) => {
          const val = r[h];
          const str = typeof val === 'object' ? JSON.stringify(val) : String(val ?? '');
          return `"${str.replace(/"/g, '""')}"`;
        })
        .join(','),
    );
    return [headers.join(','), ...rows].join('\n');
  }

  // ─── Database Stubs (replace with actual repository calls) ──────────

  private async insertAuditBatch(
    _entries: Array<Record<string, unknown>>,
  ): Promise<void> {
    this.logger.debug(`Inserting batch of ${_entries.length} audit entries`);
  }

  private async getAuditLogsInRange(
    companyId: string,
    startDate?: string,
    endDate?: string,
  ): Promise<Array<Record<string, unknown>>> {
    this.logger.debug(`Getting audit logs for ${companyId} (${startDate} to ${endDate})`);
    return [];
  }

  private async storeArchive(
    destination: string,
    path: string,
    data: Buffer | string,
  ): Promise<void> {
    const fs = require('fs');
    const dir = path.substring(0, path.lastIndexOf('/'));
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(path, data);
    this.logger.debug(`Archive stored to ${destination}:${path} (${Buffer.byteLength(data)} bytes)`);
  }

  private async markArchived(
    _companyId: string,
    _startDate: string,
    _endDate: string,
    _archivePath: string,
  ): Promise<void> {
    this.logger.debug(`Marked records as archived to ${_archivePath}`);
  }

  private async getAuditLogsToDelete(
    companyId: string,
    cutoffDate: string,
    excludeCritical: boolean,
  ): Promise<Array<Record<string, unknown>>> {
    this.logger.debug(`Finding audit logs to delete for ${companyId} before ${cutoffDate}${excludeCritical ? ' (excluding critical)' : ''}`);
    return [];
  }

  private async deleteAuditLogs(
    companyId: string,
    cutoffDate: string,
    excludeCritical: boolean,
  ): Promise<void> {
    this.logger.debug(`Deleting audit logs for ${companyId} before ${cutoffDate}${excludeCritical ? ' (excluding critical)' : ''}`);
  }
}
