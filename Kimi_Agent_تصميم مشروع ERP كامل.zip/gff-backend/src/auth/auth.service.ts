import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '@/prisma/prisma.service';
import { hashPassword, comparePassword } from '@/common/utils/password.util';
import { generateSecureToken, hashToken } from '@/common/utils/token.util';
import {
  RegisterDto,
  LoginDto,
  RefreshTokenDto,
  ForgotPasswordDto,
  ResetPasswordDto,
  ChangePasswordDto,
} from './dto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async register(dto: RegisterDto) {
    const existing = await this.prisma.user.findFirst({
      where: { email: dto.email },
    });
    if (existing) {
      throw new ConflictException('Email already registered');
    }

    const hashedPassword = await hashPassword(dto.password);

    const company = await this.prisma.company.create({
      data: {
        name: dto.companyName,
        email: dto.email,
        phone: dto.phone,
      },
    });

    const adminRole = await this.prisma.role.create({
      data: {
        name: 'super_admin',
        description: 'Super Administrator with full access',
        permissions: ['*'],
        isSystem: true,
        companyId: company.id,
      },
    });

    const user = await this.prisma.user.create({
      data: {
        name: dto.name,
        email: dto.email,
        password: hashedPassword,
        phone: dto.phone,
        companyId: company.id,
        roleId: adminRole.id,
        emailVerified: true,
      },
      include: { role: true, company: true },
    });

    const tokens = await this.generateTokens(user.id, user.email, company.id, {
      role: adminRole.name,
      permissions: adminRole.permissions,
    });

    this.logger.log(`New company registered: ${company.name} (${company.id})`);

    return {
      user: this.sanitizeUser(user),
      company: { id: company.id, name: company.name },
      ...tokens,
    };
  }

  async login(dto: LoginDto) {
    const user = await this.validateUser(dto.email, dto.password);
    if (!user) {
      throw new UnauthorizedException('Invalid email or password');
    }

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const tokens = await this.generateTokens(
      user.id,
      user.email,
      user.companyId,
      {
        role: user.role?.name || null,
        permissions: user.role?.permissions || [],
      },
    );

    this.logger.log(`User logged in: ${user.email}`);

    return {
      user: this.sanitizeUser(user),
      ...tokens,
    };
  }

  async refresh(dto: RefreshTokenDto) {
    const storedToken = await this.prisma.refreshToken.findUnique({
      where: { token: dto.refreshToken },
      include: { user: { include: { role: true } } },
    });

    if (!storedToken || storedToken.revokedAt) {
      throw new UnauthorizedException('Invalid refresh token');
    }

    if (new Date() > storedToken.expiresAt) {
      throw new UnauthorizedException('Refresh token has expired');
    }

    const { user } = storedToken;

    const tokens = await this.generateTokens(
      user.id,
      user.email,
      user.companyId,
      {
        role: user.role?.name || null,
        permissions: user.role?.permissions || [],
      },
    );

    // Revoke old refresh token
    await this.prisma.refreshToken.update({
      where: { id: storedToken.id },
      data: { revokedAt: new Date() },
    });

    return tokens;
  }

  async logout(refreshToken: string) {
    const stored = await this.prisma.refreshToken.findUnique({
      where: { token: refreshToken },
    });
    if (stored) {
      await this.prisma.refreshToken.update({
        where: { id: stored.id },
        data: { revokedAt: new Date() },
      });
    }
    return { message: 'Logged out successfully' };
  }

  async forgotPassword(dto: ForgotPasswordDto) {
    const user = await this.prisma.user.findFirst({
      where: { email: dto.email },
    });

    if (!user) {
      // Don't reveal if email exists
      return {
        message: 'If the email exists, a reset link will be sent.',
      };
    }

    // Generate a cryptographically secure reset token
    const resetToken = generateSecureToken();
    const tokenHash = hashToken(resetToken);

    // Set expiry to 24 hours from now
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    // Delete any existing unused reset tokens for this user
    await this.prisma.passwordResetToken.deleteMany({
      where: {
        userId: user.id,
        usedAt: null,
      },
    });

    // Store the hashed token in the database
    await this.prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        tokenHash,
        expiresAt,
      },
    });

    this.logger.log(`Password reset requested for: ${dto.email}`);

    // In production, send an email with the plain resetToken here
    // await this.mailService.sendPasswordResetEmail(user.email, resetToken);

    return {
      message: 'If the email exists, a reset link will be sent.',
    };
  }

  async resetPassword(dto: ResetPasswordDto) {
    // Hash the incoming token to match against stored hash
    const incomingTokenHash = hashToken(dto.token);

    // Find the token record by its hash
    const tokenRecord = await this.prisma.passwordResetToken.findFirst({
      where: {
        tokenHash: incomingTokenHash,
      },
      include: { user: true },
    });

    if (!tokenRecord) {
      throw new BadRequestException('Invalid or expired reset token');
    }

    // Check if token has already been used
    if (tokenRecord.usedAt) {
      throw new BadRequestException('This reset token has already been used');
    }

    // Check if token has expired
    if (new Date() > tokenRecord.expiresAt) {
      throw new BadRequestException('Reset token has expired');
    }

    // Hash the new password
    const hashedPassword = await hashPassword(dto.password);

    // Update user's password
    await this.prisma.user.update({
      where: { id: tokenRecord.userId },
      data: { password: hashedPassword },
    });

    // Mark the token as used (invalidate it)
    await this.prisma.passwordResetToken.update({
      where: { id: tokenRecord.id },
      data: { usedAt: new Date() },
    });

    // For security: revoke all refresh tokens for this user
    await this.prisma.refreshToken.updateMany({
      where: { userId: tokenRecord.userId },
      data: { revokedAt: new Date() },
    });

    this.logger.log(`Password reset completed for user: ${tokenRecord.user.email}`);

    return { message: 'Password reset successfully' };
  }

  async changePassword(userId: string, dto: ChangePasswordDto) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const isMatch = await comparePassword(dto.oldPassword, user.password);
    if (!isMatch) {
      throw new BadRequestException('Current password is incorrect');
    }

    const hashedPassword = await hashPassword(dto.newPassword);

    await this.prisma.user.update({
      where: { id: userId },
      data: { password: hashedPassword },
    });

    // Revoke all refresh tokens for security
    await this.prisma.refreshToken.updateMany({
      where: { userId },
      data: { revokedAt: new Date() },
    });

    this.logger.log(`Password changed for user: ${user.email}`);

    return { message: 'Password changed successfully' };
  }

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        role: true,
        company: {
          select: { id: true, name: true, email: true, phone: true },
        },
        branch: { select: { id: true, name: true } },
      },
    });

    if (!user) {
      throw new NotFoundException('User not found');
    }

    return { user: this.sanitizeUser(user) };
  }

  async updateProfile(userId: string, data: { name?: string; phone?: string }) {
    const user = await this.prisma.user.update({
      where: { id: userId },
      data: {
        name: data.name,
        phone: data.phone,
      },
      include: {
        role: true,
        company: true,
        branch: true,
      },
    });

    return { user: this.sanitizeUser(user) };
  }

  async validateUser(email: string, password: string) {
    const user = await this.prisma.user.findFirst({
      where: { email },
      include: { role: true, company: true },
    });

    if (!user) return null;
    if (user.status !== 'ACTIVE') return null;

    const isMatch = await comparePassword(password, user.password);
    if (!isMatch) return null;

    return user;
  }

  private async generateTokens(
    userId: string,
    email: string,
    companyId: string,
    roleData: { role: string | null; permissions: string[] },
  ) {
    const payload = {
      sub: userId,
      email,
      companyId,
      role: roleData.role,
      permissions: roleData.permissions,
    };

    const accessToken = this.jwtService.sign(payload, {
      secret: this.configService.get<string>('JWT_SECRET'),
      expiresIn: this.configService.get<string>('JWT_ACCESS_EXPIRATION', '15m'),
    });

    const refreshTokenStr = generateSecureToken();
    const refreshExpiresIn = this.configService.get<string>(
      'JWT_REFRESH_EXPIRATION',
      '7d',
    );

    // Parse duration to days
    const days = parseInt(refreshExpiresIn) || 7;

    await this.prisma.refreshToken.create({
      data: {
        token: refreshTokenStr,
        userId,
        expiresAt: new Date(Date.now() + days * 24 * 60 * 60 * 1000),
      },
    });

    return { accessToken, refreshToken: refreshTokenStr };
  }

  private sanitizeUser(user: any) {
    const { password, ...rest } = user;
    return rest;
  }
}
