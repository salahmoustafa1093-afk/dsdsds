import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsString, MaxLength } from 'class-validator';

export class LoginDto {
  @ApiProperty({ description: 'Email address', example: 'john@company.com' })
  @IsEmail()
  @IsNotEmpty()
  @MaxLength(150)
  email: string;

  @ApiProperty({ description: 'Password', example: 'StrongP@ss123' })
  @IsString()
  @IsNotEmpty()
  password: string;
}
