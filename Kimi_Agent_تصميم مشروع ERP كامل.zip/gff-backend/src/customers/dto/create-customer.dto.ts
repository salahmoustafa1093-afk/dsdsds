import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsNumber,
  IsEmail,
  IsUUID,
  IsEnum,
} from 'class-validator';
import { CustomerType } from '@prisma/client';

export class CreateCustomerDto {
  @ApiProperty({ example: 'Al-Shamal Poultry Farm' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(150)
  name: string;

  @ApiProperty({ example: 'CUST-001', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  code?: string;

  @ApiProperty({ example: 'BREEDER', enum: CustomerType, required: false })
  @IsOptional()
  @IsEnum(CustomerType)
  type?: CustomerType;

  @ApiProperty({ example: '+962799111222', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  phone?: string;

  @ApiProperty({ example: 'info@shamalpoultry.com', required: false })
  @IsOptional()
  @IsEmail()
  @MaxLength(150)
  email?: string;

  @ApiProperty({ example: 'Airport Road, Building 15', required: false })
  @IsOptional()
  @IsString()
  address?: string;

  @ApiProperty({ example: 'Amman', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  city?: string;

  @ApiProperty({ example: '12345678', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  taxNumber?: string;

  @ApiProperty({ example: 5000, required: false })
  @IsOptional()
  @IsNumber()
  creditLimit?: number;

  @ApiProperty({ example: 30, required: false })
  @IsOptional()
  @IsNumber()
  paymentTerms?: number;

  @ApiProperty({ example: 'Key customer - always pays on time', required: false })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440001', required: false })
  @IsOptional()
  @IsUUID()
  branchId?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440002', required: false })
  @IsOptional()
  @IsUUID()
  salesRepId?: string;
}

export class UpdateCustomerDto {
  @ApiProperty({ example: 'Al-Shamal Poultry Farm', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(150)
  name?: string;

  @ApiProperty({ example: '+962799111222', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(20)
  phone?: string;

  @ApiProperty({ example: 'Airport Road, Building 15', required: false })
  @IsOptional()
  @IsString()
  address?: string;

  @ApiProperty({ example: 'Amman', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(50)
  city?: string;

  @ApiProperty({ example: 5000, required: false })
  @IsOptional()
  @IsNumber()
  creditLimit?: number;

  @ApiProperty({ example: 30, required: false })
  @IsOptional()
  @IsNumber()
  paymentTerms?: number;

  @ApiProperty({ example: 'Key customer - always pays on time', required: false })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  categoryId?: string;
}

export class CreateCustomerCategoryDto {
  @ApiProperty({ example: 'VIP Customers' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  name: string;

  @ApiProperty({ example: 'High-volume customers with special pricing', required: false })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: 100, required: false })
  @IsOptional()
  @IsNumber()
  minOrders?: number;

  @ApiProperty({ example: 50000, required: false })
  @IsOptional()
  @IsNumber()
  minAmount?: number;

  @ApiProperty({ example: '#FF0000', required: false })
  @IsOptional()
  @IsString()
  color?: string;

  @ApiProperty({ example: 'Volume > 100K', required: false })
  @IsOptional()
  @IsString()
  criteria?: string;
}

export class UpdateCreditLimitDto {
  @ApiProperty({ example: 10000 })
  @IsNumber()
  creditLimit: number;

  @ApiProperty({ example: 'Annual review - increased limit', required: false })
  @IsOptional()
  @IsString()
  reason?: string;
}

export class CreateTransactionDto {
  @ApiProperty({ example: 'payment' })
  @IsString()
  @IsNotEmpty()
  type: string;

  @ApiProperty({ example: 5000 })
  @IsNumber()
  amount: number;

  @ApiProperty({ example: 'Invoice #INV-001 payment', required: false })
  @IsOptional()
  @IsString()
  reference?: string;

  @ApiProperty({ example: 'Cash payment received', required: false })
  @IsOptional()
  @IsString()
  notes?: string;
}
