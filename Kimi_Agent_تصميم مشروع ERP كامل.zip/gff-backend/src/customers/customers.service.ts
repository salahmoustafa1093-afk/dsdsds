import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import { UserStatus } from '@prisma/client';
import {
  CreateCustomerDto,
  UpdateCustomerDto,
  CreateCustomerCategoryDto,
  UpdateCreditLimitDto,
  CreateTransactionDto,
} from './dto';

@Injectable()
export class CustomersService {
  private readonly logger = new Logger(CustomersService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findAll(companyId: string, options: { page?: number; limit?: number; search?: string; categoryId?: string }) {
    const { page = 1, limit = 10, search, categoryId } = options;
    const skip = (page - 1) * limit;

    const where: any = { companyId, deletedAt: null };
    if (categoryId) where.categoryId = categoryId;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.customer.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          category: true,
          _count: { select: { salesInvoices: true, salesReturns: true } },
        },
      }),
      this.prisma.customer.count({ where }),
    ]);

    return { data, meta: { page, limit, total, totalPages: Math.ceil(total / limit) } };
  }

  async findOne(id: string, companyId: string) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        category: true,
        salesInvoices: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: { id: true, invoiceNumber: true, totalAmount: true, status: true, createdAt: true },
        },
      },
    });

    if (!customer) throw new NotFoundException(`Customer with ID ${id} not found`);
    return { data: customer };
  }

  async create(companyId: string, dto: CreateCustomerDto) {
    if (dto.email) {
      const existing = await this.prisma.customer.findFirst({
        where: { email: dto.email, companyId },
      });
      if (existing) throw new ConflictException('Customer email already exists');
    }

    const customer = await this.prisma.customer.create({
      data: { ...dto, companyId },
      include: { category: true },
    });

    this.logger.log(`Customer created: ${customer.name}`);
    return { data: customer };
  }

  async update(id: string, companyId: string, dto: UpdateCustomerDto) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!customer) throw new NotFoundException(`Customer with ID ${id} not found`);

    const updated = await this.prisma.customer.update({
      where: { id },
      data: dto,
      include: { category: true },
    });

    return { data: updated };
  }

  async remove(id: string, companyId: string) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!customer) throw new NotFoundException(`Customer with ID ${id} not found`);

    await this.prisma.customer.update({
      where: { id },
      data: { deletedAt: new Date(), status: UserStatus.INACTIVE },
    });

    return { data: { message: 'Customer deleted successfully' } };
  }

  async getDebts(companyId: string) {
    const customers = await this.prisma.customer.findMany({
      where: { companyId, deletedAt: null, currentBalance: { gt: 0 } },
      orderBy: { currentBalance: 'desc' },
      select: {
        id: true,
        name: true,
        code: true,
        currentBalance: true,
        creditLimit: true,
        paymentTerms: true,
      },
    });

    const totalDebt = customers.reduce((sum, c) => sum + Number(c.currentBalance), 0);
    const overdueCustomers = customers.filter(
      (c) => Number(c.currentBalance) > Number(c.creditLimit),
    );

    return { data: { customers, totalDebt, overdueCount: overdueCustomers.length } };
  }

  // Categories
  async findAllCategories(companyId: string) {
    const categories = await this.prisma.customerCategory.findMany({
      where: { companyId },
      include: { _count: { select: { customers: true } } },
      orderBy: { name: 'asc' },
    });

    return { data: categories };
  }

  async createCategory(companyId: string, dto: CreateCustomerCategoryDto) {
    const category = await this.prisma.customerCategory.create({
      data: { ...dto, companyId },
    });

    return { data: category };
  }

  async updateCategory(id: string, companyId: string, dto: Partial<CreateCustomerCategoryDto>) {
    const category = await this.prisma.customerCategory.findFirst({
      where: { id, companyId },
    });
    if (!category) throw new NotFoundException('Category not found');

    const updated = await this.prisma.customerCategory.update({
      where: { id },
      data: dto,
    });

    return { data: updated };
  }

  async removeCategory(id: string, companyId: string) {
    const category = await this.prisma.customerCategory.findFirst({
      where: { id, companyId },
      include: { _count: { select: { customers: true } } },
    });
    if (!category) throw new NotFoundException('Category not found');
    if ((category._count?.customers || 0) > 0) {
      throw new ConflictException('Cannot delete category with customers');
    }

    await this.prisma.customerCategory.delete({ where: { id } });
    return { data: { message: 'Category deleted' } };
  }

  // Credit Limit
  async updateCreditLimit(id: string, companyId: string, dto: UpdateCreditLimitDto) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!customer) throw new NotFoundException(`Customer with ID ${id} not found`);

    const updated = await this.prisma.customer.update({
      where: { id },
      data: { creditLimit: dto.creditLimit },
    });

    return { data: updated };
  }

  // Transactions
  async createTransaction(id: string, companyId: string, dto: CreateTransactionDto) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!customer) throw new NotFoundException(`Customer with ID ${id} not found`);

    let newBalance = Number(customer.currentBalance);
    if (dto.type === 'payment') {
      newBalance -= dto.amount;
    } else if (dto.type === 'charge') {
      newBalance += dto.amount;
    }

    await this.prisma.customer.update({
      where: { id },
      data: { currentBalance: newBalance },
    });

    await this.prisma.activityLog.create({
      data: {
        action: `CUSTOMER_${dto.type.toUpperCase()}`,
        description: `Customer ${dto.type}: ${dto.amount} EGP. Balance: ${newBalance}`,
        module: 'customers',
      },
    });

    return { data: { customerId: id, type: dto.type, amount: dto.amount, balance: newBalance } };
  }

  async getTransactions(id: string, companyId: string) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!customer) throw new NotFoundException(`Customer with ID ${id} not found`);

    const invoices = await this.prisma.salesInvoice.findMany({
      where: { customerId: id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      select: {
        id: true, invoiceNumber: true, totalAmount: true, paidAmount: true,
        balance: true, status: true, createdAt: true,
      },
    });

    return { data: invoices };
  }
}
