import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { CustomersService } from './customers.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateCustomerDto,
  UpdateCustomerDto,
  CreateCustomerCategoryDto,
  UpdateCreditLimitDto,
  CreateTransactionDto,
} from './dto';

@ApiTags('Customers')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('customers')
export class CustomersController {
  constructor(private readonly customersService: CustomersService) {}

  @Get()
  @Permissions('customers:view')
  @ApiOperation({ summary: 'List customers' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'categoryId', required: false })
  @ApiResponse({ status: 200, description: 'Customers retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAll(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('search') search?: string,
    @Query('categoryId') categoryId?: string,
  ) {
    return this.customersService.findAll(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      search,
      categoryId,
    });
  }

  @Get('debts')
  @Permissions('customers:view')
  @ApiOperation({ summary: 'Get all customer debts' })
  @ApiResponse({ status: 200, description: 'Debts retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getDebts(@CurrentUser('companyId') companyId: string) {
    return this.customersService.getDebts(companyId);
  }

  @Get(':id')
  @Permissions('customers:view')
  @ApiOperation({ summary: 'Get customer by ID' })
  @ApiResponse({ status: 200, description: 'Customer retrieved' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.customersService.findOne(id, companyId);
  }

  @Post()
  @Permissions('customers:create')
  @ApiOperation({ summary: 'Create customer' })
  @ApiResponse({ status: 201, description: 'Customer created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async create(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateCustomerDto,
  ) {
    return this.customersService.create(companyId, dto);
  }

  @Put(':id')
  @Permissions('customers:update')
  @ApiOperation({ summary: 'Update customer' })
  @ApiResponse({ status: 200, description: 'Customer updated' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateCustomerDto,
  ) {
    return this.customersService.update(id, companyId, dto);
  }

  @Delete(':id')
  @Permissions('customers:delete')
  @ApiOperation({ summary: 'Soft delete customer' })
  @ApiResponse({ status: 200, description: 'Customer deleted' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.customersService.remove(id, companyId);
  }

  // Categories
  @Get('categories/all')
  @Permissions('customers:view')
  @ApiOperation({ summary: 'List customer categories' })
  @ApiResponse({ status: 200, description: 'Categories retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllCategories(@CurrentUser('companyId') companyId: string) {
    return this.customersService.findAllCategories(companyId);
  }

  @Post('categories')
  @Permissions('customers:create')
  @ApiOperation({ summary: 'Create customer category' })
  @ApiResponse({ status: 201, description: 'Category created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createCategory(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateCustomerCategoryDto,
  ) {
    return this.customersService.createCategory(companyId, dto);
  }

  @Put('categories/:id')
  @Permissions('customers:update')
  @ApiOperation({ summary: 'Update customer category' })
  @ApiResponse({ status: 200, description: 'Category updated' })
  @ApiResponse({ status: 404, description: 'Category not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateCategory(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: Partial<CreateCustomerCategoryDto>,
  ) {
    return this.customersService.updateCategory(id, companyId, dto);
  }

  @Delete('categories/:id')
  @Permissions('customers:delete')
  @ApiOperation({ summary: 'Delete customer category' })
  @ApiResponse({ status: 200, description: 'Category deleted' })
  @ApiResponse({ status: 404, description: 'Category not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async removeCategory(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.customersService.removeCategory(id, companyId);
  }

  // Credit Limit
  @Put(':id/credit-limit')
  @Permissions('customers:update')
  @ApiOperation({ summary: 'Update customer credit limit' })
  @ApiResponse({ status: 200, description: 'Credit limit updated' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateCreditLimit(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: UpdateCreditLimitDto,
  ) {
    return this.customersService.updateCreditLimit(id, companyId, dto);
  }

  // Transactions
  @Get(':id/transactions')
  @Permissions('customers:view')
  @ApiOperation({ summary: 'Get customer transactions' })
  @ApiResponse({ status: 200, description: 'Transactions retrieved' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getTransactions(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.customersService.getTransactions(id, companyId);
  }

  @Post(':id/transactions')
  @Permissions('customers:create')
  @ApiOperation({ summary: 'Create customer transaction' })
  @ApiResponse({ status: 201, description: 'Transaction created' })
  @ApiResponse({ status: 404, description: 'Customer not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createTransaction(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateTransactionDto,
  ) {
    return this.customersService.createTransaction(id, companyId, dto);
  }
}
