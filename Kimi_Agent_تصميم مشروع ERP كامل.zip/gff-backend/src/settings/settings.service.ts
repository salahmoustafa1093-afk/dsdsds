import {
  Injectable,
  NotFoundException,
  BadRequestException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

// ─────────────────────────────────────────────────────────────
// Types & Interfaces
// ─────────────────────────────────────────────────────────────

type SettingCategory =
  | 'general'
  | 'financial'
  | 'inventory'
  | 'sales'
  | 'production'
  | 'purchase'
  | 'hr'
  | 'security'
  | 'notifications';

interface CompanySettings {
  general: GeneralSettings;
  financial: FinancialSettings;
  inventory: InventorySettings;
  sales: SalesSettings;
  production: ProductionSettings;
  purchase: PurchaseSettings;
  hr: HRSettings;
  security: SecuritySettings;
  notifications: NotificationSettings;
}

interface GeneralSettings {
  companyName: string;
  address: string;
  phone: string;
  email: string;
  taxNumber: string;
  currency: string;
  timezone: string;
  dateFormat: string;
  language: string;
}

interface FinancialSettings {
  fiscalYearStart: string; // MM-DD format
  taxRate: number; // percentage 0-100
  taxRegistrationNumber: string;
  defaultPaymentTerms: number; // days
  invoicePrefix: string;
  invoiceNumbering: 'sequential' | 'date_based' | 'branch_based';
}

interface InventorySettings {
  defaultWarehouse: string;
  stockAlertThreshold: number; // percentage 0-100
  valuationMethod: 'FIFO' | 'LIFO' | 'AVERAGE';
  autoReorder: boolean;
  barcodeFormat: 'CODE128' | 'EAN13' | 'QR';
}

interface SalesSettings {
  defaultSalesChannel: 'retail' | 'wholesale' | 'distributor' | 'export';
  maxDiscountPercent: number; // 0-100
  creditCheckEnabled: boolean;
  minOrderAmount: number;
  priceListManagement: boolean;
}

interface ProductionSettings {
  shiftStartTime: string; // HH:MM
  shiftEndTime: string; // HH:MM
  shiftsPerDay: number;
  oeeTarget: number; // percentage 0-100
  yieldTarget: number; // percentage 0-100
  qualityCheckFrequency: 'every_batch' | 'hourly' | 'daily' | 'weekly';
}

interface PurchaseSettings {
  poApprovalThreshold: number;
  poPrefix: string;
  grnRequired: boolean;
  threeWayMatchEnabled: boolean;
  defaultSupplierTerms: number; // days
}

interface HRSettings {
  workHoursPerDay: number; // 1-24
  workDaysPerWeek: number; // 1-7
  overtimeRate: number; // multiplier (e.g., 1.5x)
  lateToleranceMinutes: number;
  payrollCycle: 'monthly' | 'biweekly' | 'weekly';
}

interface SecuritySettings {
  passwordPolicy: {
    minLength: number;
    requireUppercase: boolean;
    requireLowercase: boolean;
    requireNumbers: boolean;
    requireSymbols: boolean;
    expiryDays: number;
  };
  sessionTimeout: number; // minutes 5-1440
  mfaRequired: boolean;
  ipWhitelist: string[];
  loginAttempts: number;
}

interface NotificationSettings {
  emailNotifications: boolean;
  smsNotifications: boolean;
  pushNotifications: boolean;
  notificationChannels: {
    sales: ('email' | 'sms' | 'push')[];
    inventory: ('email' | 'sms' | 'push')[];
    finance: ('email' | 'sms' | 'push')[];
    hr: ('email' | 'sms' | 'push')[];
    system: ('email' | 'sms' | 'push')[];
  };
}

// ─────────────────────────────────────────────────────────────
// Default Settings
// ─────────────────────────────────────────────────────────────

const DEFAULT_SETTINGS: CompanySettings = {
  general: {
    companyName: '',
    address: '',
    phone: '',
    email: '',
    taxNumber: '',
    currency: 'EGP',
    timezone: 'Africa/Cairo',
    dateFormat: 'DD/MM/YYYY',
    language: 'ar',
  },
  financial: {
    fiscalYearStart: '01-01',
    taxRate: 14,
    taxRegistrationNumber: '',
    defaultPaymentTerms: 30,
    invoicePrefix: 'INV',
    invoiceNumbering: 'sequential',
  },
  inventory: {
    defaultWarehouse: '',
    stockAlertThreshold: 20,
    valuationMethod: 'FIFO',
    autoReorder: false,
    barcodeFormat: 'CODE128',
  },
  sales: {
    defaultSalesChannel: 'retail',
    maxDiscountPercent: 10,
    creditCheckEnabled: true,
    minOrderAmount: 0,
    priceListManagement: false,
  },
  production: {
    shiftStartTime: '08:00',
    shiftEndTime: '17:00',
    shiftsPerDay: 1,
    oeeTarget: 85,
    yieldTarget: 95,
    qualityCheckFrequency: 'every_batch',
  },
  purchase: {
    poApprovalThreshold: 10000,
    poPrefix: 'PO',
    grnRequired: true,
    threeWayMatchEnabled: true,
    defaultSupplierTerms: 30,
  },
  hr: {
    workHoursPerDay: 8,
    workDaysPerWeek: 6,
    overtimeRate: 1.5,
    lateToleranceMinutes: 15,
    payrollCycle: 'monthly',
  },
  security: {
    passwordPolicy: {
      minLength: 8,
      requireUppercase: true,
      requireLowercase: true,
      requireNumbers: true,
      requireSymbols: false,
      expiryDays: 90,
    },
    sessionTimeout: 120,
    mfaRequired: false,
    ipWhitelist: [],
    loginAttempts: 5,
  },
  notifications: {
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
    notificationChannels: {
      sales: ['email', 'push'],
      inventory: ['email'],
      finance: ['email'],
      hr: ['email', 'push'],
      system: ['push'],
    },
  },
};

// ─────────────────────────────────────────────────────────────
// Validation Rules
// ─────────────────────────────────────────────────────────────

const VALIDATION_RULES: Record<string, Record<string, (v: any) => string | null>> = {
  financial: {
    taxRate: (v) =>
      typeof v !== 'number' || v < 0 || v > 100
        ? 'Tax rate must be a number between 0 and 100'
        : null,
    defaultPaymentTerms: (v) =>
      typeof v !== 'number' || v < 0 || v > 365
        ? 'Payment terms must be between 0 and 365 days'
        : null,
  },
  sales: {
    maxDiscountPercent: (v) =>
      typeof v !== 'number' || v < 0 || v > 100
        ? 'Max discount must be between 0 and 100'
        : null,
    minOrderAmount: (v) =>
      typeof v !== 'number' || v < 0
        ? 'Min order amount must be a non-negative number'
        : null,
  },
  inventory: {
    stockAlertThreshold: (v) =>
      typeof v !== 'number' || v < 0 || v > 100
        ? 'Alert threshold must be between 0 and 100'
        : null,
  },
  production: {
    shiftsPerDay: (v) =>
      typeof v !== 'number' || v < 1 || v > 3
        ? 'Shifts per day must be between 1 and 3'
        : null,
    oeeTarget: (v) =>
      typeof v !== 'number' || v < 0 || v > 100
        ? 'OEE target must be between 0 and 100'
        : null,
    yieldTarget: (v) =>
      typeof v !== 'number' || v < 0 || v > 100
        ? 'Yield target must be between 0 and 100'
        : null,
  },
  purchase: {
    poApprovalThreshold: (v) =>
      typeof v !== 'number' || v < 0
        ? 'PO approval threshold must be a non-negative number'
        : null,
    defaultSupplierTerms: (v) =>
      typeof v !== 'number' || v < 0 || v > 365
        ? 'Supplier terms must be between 0 and 365 days'
        : null,
  },
  hr: {
    workHoursPerDay: (v) =>
      typeof v !== 'number' || v < 1 || v > 24
        ? 'Work hours per day must be between 1 and 24'
        : null,
    workDaysPerWeek: (v) =>
      typeof v !== 'number' || v < 1 || v > 7
        ? 'Work days per week must be between 1 and 7'
        : null,
    overtimeRate: (v) =>
      typeof v !== 'number' || v < 1
        ? 'Overtime rate must be at least 1.0x'
        : null,
    lateToleranceMinutes: (v) =>
      typeof v !== 'number' || v < 0 || v > 120
        ? 'Late tolerance must be between 0 and 120 minutes'
        : null,
  },
  security: {
    sessionTimeout: (v) =>
      typeof v !== 'number' || v < 5 || v > 1440
        ? 'Session timeout must be between 5 and 1440 minutes'
        : null,
    loginAttempts: (v) =>
      typeof v !== 'number' || v < 1 || v > 10
        ? 'Login attempts must be between 1 and 10'
        : null,
  },
};

// ─────────────────────────────────────────────────────────────
// Service
// ─────────────────────────────────────────────────────────────

@Injectable()
export class SettingsService {
  private readonly logger = new Logger(SettingsService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════════════════════
  // 1. COMPANY SETTINGS CRUD
  // ═══════════════════════════════════════════════════════════

  /**
   * Get all company-specific settings.
   */
  async getCompanySettings(companyId: string): Promise<CompanySettings> {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: { settings: true },
    });
    if (!company) throw new NotFoundException('Company not found');

    // Parse stored settings and merge with defaults
    const storedSettings = this.parseStoredSettings(company.settings);
    return this.mergeWithDefaults(storedSettings);
  }

  /**
   * Get settings for a specific category.
   */
  async getSettingsByCategory<
    T extends SettingCategory,
  >(companyId: string, category: T): Promise<CompanySettings[T]> {
    const allSettings = await this.getCompanySettings(companyId);
    return allSettings[category];
  }

  /**
   * Batch update settings with validation.
   */
  async updateCompanySettings(
    companyId: string,
    settings: Partial<CompanySettings>,
  ): Promise<CompanySettings> {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: { settings: true },
    });
    if (!company) throw new NotFoundException('Company not found');

    // Validate all provided settings
    const errors = this.validateAllSettings(settings);
    if (errors.length > 0) {
      throw new BadRequestException(
        `Settings validation failed: ${errors.join('; ')}`,
      );
    }

    // Merge with existing settings
    const storedSettings = this.parseStoredSettings(company.settings);
    const merged = this.mergeWithDefaults(storedSettings);

    // Deep merge the updates
    const updated = this.deepMerge(merged, settings);

    // Store as JSON string on the company record
    await this.prisma.company.update({
      where: { id: companyId },
      data: { settings: JSON.stringify(updated) },
    });

    this.logger.log(`Settings updated for company ${companyId}`);
    return updated;
  }

  /**
   * Update settings for a single category.
   */
  async updateCategorySettings<T extends SettingCategory>(
    companyId: string,
    category: T,
    settings: Partial<CompanySettings[T]>,
  ): Promise<CompanySettings[T]> {
    const allSettings = await this.getCompanySettings(companyId);

    // Validate category-specific settings
    const errors = this.validateSettings(category, settings);
    if (errors.length > 0) {
      throw new BadRequestException(
        `Validation failed for ${category}: ${errors.join('; ')}`,
      );
    }

    // Merge category settings
    allSettings[category] = {
      ...allSettings[category],
      ...settings,
    } as CompanySettings[T];

    await this.prisma.company.update({
      where: { id: companyId },
      data: { settings: JSON.stringify(allSettings) },
    });

    this.logger.log(`Category settings updated: ${category} for company ${companyId}`);
    return allSettings[category];
  }

  // ═══════════════════════════════════════════════════════════
  // 2. INDIVIDUAL SETTING OPERATIONS
  // ═══════════════════════════════════════════════════════════

  /**
   * Get a single setting value by key path (e.g., 'financial.taxRate').
   */
  async getSetting(companyId: string, keyPath: string): Promise<any> {
    const settings = await this.getCompanySettings(companyId);
    return this.getValueByPath(settings, keyPath);
  }

  /**
   * Update a single setting value by key path.
   */
  async updateSetting(
    companyId: string,
    keyPath: string,
    value: any,
  ): Promise<CompanySettings> {
    const [category, key] = keyPath.split('.');
    if (!category || !key) {
      throw new BadRequestException(
        'Key path must be in format "category.key" or "category.nested.key"',
      );
    }

    // Validate the specific value
    const categoryRules = VALIDATION_RULES[category];
    if (categoryRules && categoryRules[key]) {
      const error = categoryRules[key](value);
      if (error) throw new BadRequestException(error);
    }

    const settings = await this.getCompanySettings(companyId);
    this.setValueByPath(settings, keyPath, value);

    await this.prisma.company.update({
      where: { id: companyId },
      data: { settings: JSON.stringify(settings) },
    });

    return settings;
  }

  // ═══════════════════════════════════════════════════════════
  // 3. VALIDATION
  // ═══════════════════════════════════════════════════════════

  /**
   * Validate settings for a specific category.
   */
  validateSettings(
    category: SettingCategory,
    settings: Record<string, any>,
  ): string[] {
    const errors: string[] = [];
    const rules = VALIDATION_RULES[category];

    if (!rules) return errors;

    for (const [key, value] of Object.entries(settings)) {
      if (rules[key]) {
        const error = rules[key](value);
        if (error) errors.push(`${key}: ${error}`);
      }
    }

    // Cross-field validation
    if (category === 'production') {
      const startTime = settings.shiftStartTime;
      const endTime = settings.shiftEndTime;
      if (startTime && endTime && startTime >= endTime) {
        errors.push('shiftEndTime: Shift end time must be after start time');
      }
    }

    if (category === 'security') {
      const passwordPolicy = settings.passwordPolicy;
      if (passwordPolicy) {
        if (passwordPolicy.minLength < 6) {
          errors.push('passwordPolicy.minLength: Minimum password length is 6');
        }
        if (passwordPolicy.minLength > 128) {
          errors.push(
            'passwordPolicy.minLength: Maximum password length is 128',
          );
        }
        if (passwordPolicy.expiryDays < 1 || passwordPolicy.expiryDays > 365) {
          errors.push(
            'passwordPolicy.expiryDays: Password expiry must be between 1 and 365 days',
          );
        }
      }
    }

    return errors;
  }

  /**
   * Validate all settings across categories.
   */
  private validateAllSettings(
    settings: Partial<CompanySettings>,
  ): string[] {
    const errors: string[] = [];

    for (const [category, categorySettings] of Object.entries(settings)) {
      if (categorySettings && typeof categorySettings === 'object') {
        const categoryErrors = this.validateSettings(
          category as SettingCategory,
          categorySettings as Record<string, any>,
        );
        errors.push(...categoryErrors);
      }
    }

    return errors;
  }

  // ═══════════════════════════════════════════════════════════
  // 4. DEFAULT SETTINGS
  // ═══════════════════════════════════════════════════════════

  /**
   * Return hardcoded defaults for new companies.
   */
  getDefaultSettings(): CompanySettings {
    // Return deep clone to prevent mutation
    return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  }

  /**
   * Apply all default settings to a new company.
   */
  async applyDefaults(companyId: string): Promise<CompanySettings> {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: { id: true, name: true },
    });
    if (!company) throw new NotFoundException('Company not found');

    const defaults = this.getDefaultSettings();

    // Pre-fill company name from company record
    defaults.general.companyName = company.name || '';

    await this.prisma.company.update({
      where: { id: companyId },
      data: { settings: JSON.stringify(defaults) },
    });

    this.logger.log(`Default settings applied to company ${companyId}`);
    return defaults;
  }

  /**
   * Reset a specific category to defaults.
   */
  async resetCategoryToDefaults<T extends SettingCategory>(
    companyId: string,
    category: T,
  ): Promise<CompanySettings[T]> {
    const defaults = this.getDefaultSettings();
    const categoryDefaults = defaults[category];

    const allSettings = await this.getCompanySettings(companyId);
    allSettings[category] = JSON.parse(JSON.stringify(categoryDefaults));

    await this.prisma.company.update({
      where: { id: companyId },
      data: { settings: JSON.stringify(allSettings) },
    });

    this.logger.log(`Category ${category} reset to defaults for company ${companyId}`);
    return allSettings[category];
  }

  // ═══════════════════════════════════════════════════════════
  // 5. SETTINGS EXPORT/IMPORT
  // ═══════════════════════════════════════════════════════════

  /**
   * Export all settings as JSON.
   */
  async exportSettings(companyId: string): Promise<{
    companyId: string;
    exportedAt: string;
    version: string;
    settings: CompanySettings;
  }> {
    const settings = await this.getCompanySettings(companyId);

    return {
      companyId,
      exportedAt: new Date().toISOString(),
      version: '1.0',
      settings,
    };
  }

  /**
   * Import and validate settings from JSON.
   */
  async importSettings(
    companyId: string,
    settings: CompanySettings,
    options: { overwrite?: boolean; validateOnly?: boolean } = {},
  ): Promise<{
    applied: boolean;
    errors: string[];
    warnings: string[];
    appliedSettings: CompanySettings | null;
  }> {
    const { overwrite = true, validateOnly = false } = options;
    const errors: string[] = [];
    const warnings: string[] = [];

    // Validate all categories
    const allErrors = this.validateAllSettings(settings);
    if (allErrors.length > 0) {
      errors.push(...allErrors);
      return { applied: false, errors, warnings, appliedSettings: null };
    }

    // Check for unknown categories
    const validCategories = Object.keys(DEFAULT_SETTINGS);
    for (const category of Object.keys(settings)) {
      if (!validCategories.includes(category)) {
        warnings.push(`Unknown category "${category}" will be ignored`);
      }
    }

    // Check for missing categories
    for (const category of validCategories) {
      if (!(category in settings)) {
        warnings.push(
          `Missing category "${category}" - will use existing/default values`,
        );
      }
    }

    if (validateOnly) {
      return { applied: false, errors, warnings, appliedSettings: null };
    }

    if (!overwrite) {
      // Merge with existing settings
      const existing = await this.getCompanySettings(companyId);
      const merged = this.deepMerge(existing, settings);

      await this.prisma.company.update({
        where: { id: companyId },
        data: { settings: JSON.stringify(merged) },
      });

      this.logger.log(`Settings imported (merged) for company ${companyId}`);
      return { applied: true, errors, warnings, appliedSettings: merged };
    }

    // Full overwrite - merge with defaults first, then with imported settings
    const defaults = this.getDefaultSettings();
    const merged = this.deepMerge(defaults, settings);

    await this.prisma.company.update({
      where: { id: companyId },
      data: { settings: JSON.stringify(merged) },
    });

    this.logger.log(`Settings imported (overwrite) for company ${companyId}`);
    return { applied: true, errors, warnings, appliedSettings: merged };
  }

  // ═══════════════════════════════════════════════════════════
  // 6. COMPANY INFO (Legacy support)
  // ═══════════════════════════════════════════════════════════

  async getCompanyInfo(companyId: string) {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        address: true,
        city: true,
        country: true,
        taxNumber: true,
        commercialRegister: true,
        logo: true,
        fiscalYearStart: true,
        defaultCurrency: true,
        timezone: true,
        status: true,
        settings: true,
      },
    });
    if (!company) throw new NotFoundException('Company not found');
    return { data: company };
  }

  async updateCompanyInfo(
    companyId: string,
    dto: {
      name?: string;
      email?: string;
      phone?: string;
      address?: string;
      city?: string;
      country?: string;
      taxNumber?: string;
      commercialRegister?: string;
      logo?: string;
      fiscalYearStart?: Date;
      defaultCurrency?: string;
      timezone?: string;
      status?: string;
    },
  ) {
    const company = await this.prisma.company.findUnique({
      where: { id: companyId },
    });
    if (!company) throw new NotFoundException('Company not found');

    const updated = await this.prisma.company.update({
      where: { id: companyId },
      data: dto,
    });

    this.logger.log(`Company info updated for ${companyId}`);
    return { data: updated };
  }

  async getSystemConfig() {
    const configs = await this.prisma.company.findMany({
      select: {
        id: true,
        name: true,
        defaultCurrency: true,
        timezone: true,
        status: true,
      },
    });
    return { data: configs };
  }

  // ═══════════════════════════════════════════════════════════
  // 7. SETTINGS COMPARISON & ANALYSIS
  // ═══════════════════════════════════════════════════════════

  /**
   * Compare current settings against defaults to find deviations.
   */
  async compareWithDefaults(companyId: string): Promise<
    Array<{
      category: string;
      key: string;
      currentValue: any;
      defaultValue: any;
      isDifferent: boolean;
    }>
  > {
    const current = await this.getCompanySettings(companyId);
    const defaults = this.getDefaultSettings();
    const differences: Array<{
      category: string;
      key: string;
      currentValue: any;
      defaultValue: any;
      isDifferent: boolean;
    }> = [];

    for (const [category, defaultValues] of Object.entries(defaults)) {
      const currentValues = current[category as SettingCategory];
      this.findDifferences(
        category,
        '',
        defaultValues,
        currentValues,
        differences,
      );
    }

    return differences;
  }

  // ═══════════════════════════════════════════════════════════
  // HELPER METHODS
  // ═══════════════════════════════════════════════════════════

  private parseStoredSettings(settingsRaw: any): Partial<CompanySettings> {
    if (!settingsRaw) return {};
    if (typeof settingsRaw === 'string') {
      try {
        return JSON.parse(settingsRaw);
      } catch {
        return {};
      }
    }
    if (typeof settingsRaw === 'object') {
      return settingsRaw as Partial<CompanySettings>;
    }
    return {};
  }

  private mergeWithDefaults(
    stored: Partial<CompanySettings>,
  ): CompanySettings {
    const defaults = this.getDefaultSettings();
    return this.deepMerge(defaults, stored) as CompanySettings;
  }

  private deepMerge(target: any, source: any): any {
    const result = JSON.parse(JSON.stringify(target));

    for (const key of Object.keys(source)) {
      if (
        source[key] &&
        typeof source[key] === 'object' &&
        !Array.isArray(source[key]) &&
        result[key] &&
        typeof result[key] === 'object'
      ) {
        result[key] = this.deepMerge(result[key], source[key]);
      } else if (source[key] !== undefined) {
        result[key] = source[key];
      }
    }

    return result;
  }

  private getValueByPath(obj: any, path: string): any {
    const keys = path.split('.');
    let current = obj;

    for (const key of keys) {
      if (current === null || current === undefined) return undefined;
      current = current[key];
    }

    return current;
  }

  private setValueByPath(obj: any, path: string, value: any): void {
    const keys = path.split('.');
    let current = obj;

    for (let i = 0; i < keys.length - 1; i++) {
      const key = keys[i];
      if (
        current[key] === null ||
        current[key] === undefined ||
        typeof current[key] !== 'object'
      ) {
        current[key] = {};
      }
      current = current[key];
    }

    current[keys[keys.length - 1]] = value;
  }

  private findDifferences(
    category: string,
    prefix: string,
    defaultObj: any,
    currentObj: any,
    result: Array<{
      category: string;
      key: string;
      currentValue: any;
      defaultValue: any;
      isDifferent: boolean;
    }>,
  ): void {
    if (
      typeof defaultObj !== 'object' ||
      defaultObj === null ||
      Array.isArray(defaultObj)
    ) {
      const key = prefix;
      const isDifferent = JSON.stringify(defaultObj) !== JSON.stringify(currentObj);
      result.push({
        category,
        key,
        currentValue: currentObj,
        defaultValue: defaultObj,
        isDifferent,
      });
      return;
    }

    for (const key of Object.keys(defaultObj)) {
      const newPrefix = prefix ? `${prefix}.${key}` : key;
      if (
        currentObj &&
        typeof currentObj === 'object' &&
        key in currentObj
      ) {
        this.findDifferences(
          category,
          newPrefix,
          defaultObj[key],
          currentObj[key],
          result,
        );
      } else {
        result.push({
          category,
          key: newPrefix,
          currentValue: currentObj?.[key],
          defaultValue: defaultObj[key],
          isDifferent: true,
        });
      }
    }
  }
}
