import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { SettingsService } from './settings.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { RolesGuard } from '@/common/guards/roles.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { Roles } from '@/common/decorators/roles.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';

@ApiTags('Settings')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('settings')
export class SettingsController {
  constructor(private readonly settingsService: SettingsService) {}

  @Get()
  @Permissions('settings:view')
  @ApiOperation({ summary: 'Get all company settings' })
  @ApiResponse({ status: 200, description: 'Settings retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getSettings(@CurrentUser('companyId') companyId: string) {
    return this.settingsService.getSettings(companyId);
  }

  @Get('company')
  @Permissions('settings:view')
  @ApiOperation({ summary: 'Get company info' })
  @ApiResponse({ status: 200, description: 'Company info retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getCompanyInfo(@CurrentUser('companyId') companyId: string) {
    return this.settingsService.getCompanyInfo(companyId);
  }

  @Put('company')
  @Permissions('settings:update')
  @ApiOperation({ summary: 'Update company info' })
  @ApiResponse({ status: 200, description: 'Company info updated' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateCompanyInfo(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: any,
  ) {
    return this.settingsService.updateCompanyInfo(companyId, dto);
  }

  @Post()
  @Permissions('settings:update')
  @ApiOperation({ summary: 'Create or update setting' })
  @ApiResponse({ status: 201, description: 'Setting saved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async upsertSetting(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: { key: string; value: any; category?: string; description?: string },
  ) {
    return this.settingsService.upsertSetting(companyId, dto);
  }

  @Get('system-config')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('ADMIN', 'SUPER_ADMIN')
  @ApiOperation({ summary: 'Get system config (Admin only)' })
  @ApiResponse({ status: 200, description: 'System config retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getSystemConfig() {
    return this.settingsService.getSystemConfig();
  }
}
