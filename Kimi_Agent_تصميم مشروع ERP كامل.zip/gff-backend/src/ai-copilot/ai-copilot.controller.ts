import {
  Controller,
  Post,
  Body,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { AiCopilotService } from './ai-copilot.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';

@ApiTags('AI Copilot')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('ai')
export class AiCopilotController {
  constructor(private readonly aiCopilotService: AiCopilotService) {}

  @Post('query')
  @Permissions('dashboard:view')
  @ApiOperation({ summary: 'Natural language query' })
  @ApiResponse({ status: 200, description: 'Query processed' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async query(
    @CurrentUser('companyId') companyId: string,
    @Body('query') query: string,
  ) {
    return this.aiCopilotService.processQuery(companyId, query);
  }
}
