import {
  Injectable,
  Logger,
  BadRequestException,
  InternalServerErrorException,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

// ─────────────────────────────────────────────────────────────
// Types & Interfaces
// ─────────────────────────────────────────────────────────────

interface QueryIntent {
  module: string;
  action: string;
  filters: Record<string, any>;
  aggregations: Record<string, any>;
  timeRange?: { start: Date; end: Date };
  limit?: number;
  language: 'ar' | 'en';
}

interface CacheEntry {
  result: any;
  expiresAt: Date;
}

interface NLPResponse {
  answer: string;
  type: string;
  data?: any;
  metadata?: Record<string, any>;
}

// ─────────────────────────────────────────────────────────────
// Arabic → English keyword maps for normalization
// ─────────────────────────────────────────────────────────────

const AR_TO_EN_KEYWORDS: Record<string, string[]> = {
  sales: ['مبيعات', 'مبيعات', 'البيع', 'مبيعاتنا', 'revenue', 'turnover'],
  today: ['اليوم', 'هذا اليوم', 'اليوم الحالي', 'today'],
  month: ['هذا الشهر', 'الشهر الحالي', 'الشهر', 'month', 'this month', 'current month'],
  stock: ['مخزون', 'المخزون', 'الكمية', 'stock', 'inventory', 'quantity'],
  low_stock: ['تحت الحد', 'منخفض', 'قليل', 'نفذ', 'low stock', 'below minimum', 'under limit'],
  customers: ['عملاء', 'العملاء', 'customer', 'clients', 'buyers'],
  top: ['أعلى', 'اكثر', 'أكثر', 'top', 'best', 'highest'],
  debts: ['مديونيات', 'ديون', 'مستحقات', 'debt', 'debts', 'dues', 'receivables'],
  delivery: ['توصيل', 'توصيلات', 'طرود', 'delivery', 'deliveries', 'shipping'],
  branch: ['فرع', 'فروع', 'branch', 'branches'],
  feed: ['علف', 'أعلاف', 'feed', 'poultry feed', 'animal feed'],
  mortality: ['نفوق', 'معدل النفوق', 'النفوق', 'mortality', 'death rate', 'loss rate'],
  employees: ['موظفين', 'الموظفين', 'employee', 'staff', 'workers', 'personnel'],
  absent: ['غائبين', 'غياب', 'غائب', 'absent', 'absence', 'missing'],
  rep: ['مندوبين', 'مندوب', 'مندوبين', 'sales rep', 'representative', 'salesman'],
  invoices: ['فواتير', 'فاتورة', 'invoice', 'invoices', 'bills'],
  overdue: ['مستحقة', 'متأخرة', 'مستحق', 'overdue', 'past due', 'due'],
  movements: ['حركة', 'حركات', 'movements', 'transactions', 'activity'],
  production: ['إنتاج', 'تكلفة الإنتاج', 'production', 'manufacturing', 'output'],
  fuel: ['وقود', 'استهلاك الوقود', 'fuel', 'gasoline', 'diesel', 'petrol'],
  cash: ['صناديق', 'صندوق', 'نقدية', 'treasury', 'cash', 'cash position', 'till'],
  comparison: ['مقارنة', 'مقارنة الشهر', 'compare', 'comparison', 'month over month', 'vs'],
  profitability: ['ربحية', 'أرباح', 'ربح', 'profit', 'profitability', 'margin', 'earnings'],
  forecast: ['تنبؤ', 'توقع', 'تنبؤ المبيعات', 'forecast', 'prediction', 'project'],
  cost: ['تكلفة', 'تكاليف', 'cost', 'costs', 'expense'],
  quality: ['جودة', 'اختبار', 'quality', 'qc', 'inspection'],
  attendance: ['حضور', '_attendance', 'attendance', 'present'],
};

// ─────────────────────────────────────────────────────────────
// Time-range helpers
// ─────────────────────────────────────────────────────────────

function getTodayRange(): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
  const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
  return { start, end };
}

function getThisMonthRange(): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
  return { start, end };
}

function getLastMonthRange(): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0);
  const end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59);
  return { start, end };
}

function getYearRange(): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1, 0, 0, 0);
  const end = new Date(now.getFullYear(), 11, 31, 23, 59, 59);
  return { start, end };
}

// ─────────────────────────────────────────────────────────────
// Detect query language
// ─────────────────────────────────────────────────────────────

function detectLanguage(query: string): 'ar' | 'en' {
  const arabicRegex = /[\u0600-\u06FF]/;
  return arabicRegex.test(query) ? 'ar' : 'en';
}

// ─────────────────────────────────────────────────────────────
// Number extraction helper (extract "top 5", "best 10", etc.)
// ─────────────────────────────────────────────────────────────

function extractLimit(query: string): number | undefined {
  const match = query.match(/(?:top|best|أعلى|اكثر|أكثر|first|first)\s*(\d+)/i);
  return match ? parseInt(match[1], 10) : undefined;
}

// ─────────────────────────────────────────────────────────────

@Injectable()
export class AiCopilotService {
  private readonly logger = new Logger(AiCopilotService.name);

  // In-memory LRU cache: queryKey → CacheEntry
  private readonly queryCache = new Map<string, CacheEntry>();
  private readonly CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes
  private readonly MAX_CACHE_SIZE = 200;

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════════════════════
  // PUBLIC API
  // ═══════════════════════════════════════════════════════════

  /**
   * Main entry point: parse natural-language query, execute, format response.
   */
  async processQuery(companyId: string, query: string): Promise<NLPResponse> {
    if (!query || !query.trim()) {
      throw new BadRequestException('Query cannot be empty');
    }

    const trimmedQuery = query.trim();
    this.logger.log(`AI query: "${trimmedQuery}" for company ${companyId}`);

    // Check cache
    const cacheKey = `${companyId}::${trimmedQuery.toLowerCase()}`;
    const cached = this.getCached(cacheKey);
    if (cached) {
      this.logger.debug('Cache hit for query');
      return { ...cached, metadata: { ...cached.metadata, cached: true } };
    }

    try {
      const intent = this.parseQuery(trimmedQuery);
      const result = await this.executeQuery(intent, companyId);
      const response = this.formatResponse(result, trimmedQuery, intent.language);

      // Store in cache
      this.setCache(cacheKey, response);

      return response;
    } catch (error) {
      this.logger.error(`AI query failed: ${error.message}`, error.stack);
      throw new InternalServerErrorException(
        detectLanguage(trimmedQuery) === 'ar'
          ? `عذراً، حدث خطأ أثناء معالجة استفسارك: ${error.message}`
          : `Sorry, an error occurred processing your query: ${error.message}`,
      );
    }
  }

  /**
   * Clear the query cache (useful for testing or admin ops).
   */
  clearCache(): void {
    this.queryCache.clear();
    this.logger.log('Query cache cleared');
  }

  /**
   * Get cache statistics.
   */
  getCacheStats(): { size: number; maxSize: number; ttlMs: number } {
    return { size: this.queryCache.size, maxSize: this.MAX_CACHE_SIZE, ttlMs: this.CACHE_TTL_MS };
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 1: PARSING — Extract intent from natural language
  // ═══════════════════════════════════════════════════════════

  parseQuery(query: string): QueryIntent {
    const normalized = query.toLowerCase().trim();
    const language = detectLanguage(query);
    const limit = extractLimit(normalized);

    // ── 1. Today's sales ──────────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['sales', 'today']) ||
      this.matchesKeywords(normalized, ['مبيعات', 'اليوم']) ||
      normalized.includes('total sales today') ||
      normalized.includes('مبيعات اليوم') ||
      normalized.includes('revenue today')
    ) {
      return {
        module: 'sales',
        action: 'sum_today',
        filters: { companyId: true },
        aggregations: { sum: 'totalAmount' },
        timeRange: getTodayRange(),
        limit,
        language,
      };
    }

    // ── 2. This month's sales ─────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['sales', 'month']) ||
      this.matchesKeywords(normalized, ['مبيعات', 'الشهر']) ||
      normalized.includes('sales this month') ||
      normalized.includes('مبيعات هذا الشهر') ||
      normalized.includes('monthly revenue') ||
      normalized.includes('monthly sales')
    ) {
      return {
        module: 'sales',
        action: 'sum_month',
        filters: { companyId: true },
        aggregations: { sum: 'totalAmount' },
        timeRange: getThisMonthRange(),
        limit,
        language,
      };
    }

    // ── 3. Stock of product X ─────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['stock', 'product']) ||
      this.matchesKeywords(normalized, ['مخزون', 'منتج']) ||
      normalized.includes('stock of') ||
      normalized.includes('مخزون منتج') ||
      normalized.includes('كمية منتج')
    ) {
      const productName = this.extractProductName(query);
      return {
        module: 'inventory',
        action: 'product_stock',
        filters: { companyId: true, productName },
        aggregations: { sum: 'quantity' },
        limit,
        language,
      };
    }

    // ── 4. Low stock products ─────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['low_stock']) ||
      this.matchesKeywords(normalized, ['منخفض']) ||
      this.matchesKeywords(normalized, ['نفذ']) ||
      normalized.includes('low stock') ||
      normalized.includes('under minimum') ||
      normalized.includes('products below') ||
      normalized.includes('منتجات تحت الحد') ||
      normalized.includes('مخزون منخفض')
    ) {
      return {
        module: 'inventory',
        action: 'low_stock',
        filters: { companyId: true },
        aggregations: { count: true },
        limit: limit || 20,
        language,
      };
    }

    // ── 5. Top N customers ────────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['top', 'customers']) ||
      this.matchesKeywords(normalized, ['أعلى', 'عملاء']) ||
      this.matchesKeywords(normalized, ['top', 'عملاء']) ||
      normalized.includes('top customers') ||
      normalized.includes('أعلى عملاء') ||
      normalized.includes('best customers')
    ) {
      return {
        module: 'sales',
        action: 'top_customers',
        filters: { companyId: true },
        aggregations: { sum: 'totalAmount', groupBy: 'customerId' },
        limit: limit || 5,
        language,
      };
    }

    // ── 6. Customer debts ─────────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['customers', 'debts']) ||
      this.matchesKeywords(normalized, ['مديونيات', 'العملاء']) ||
      normalized.includes('customer debt') ||
      normalized.includes('مديونيات العملاء') ||
      normalized.includes('debtors') ||
      normalized.includes('receivables')
    ) {
      return {
        module: 'sales',
        action: 'customer_debts',
        filters: { companyId: true, balanceGt: 0 },
        aggregations: { sum: 'balance', groupBy: 'customerId' },
        limit: limit || 10,
        language,
      };
    }

    // ── 7. Delivery status ────────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['delivery']) ||
      this.matchesKeywords(normalized, ['توصيل']) ||
      normalized.includes('delivery status') ||
      normalized.includes('حالة التوصيل') ||
      normalized.includes('حالة التوصيلات') ||
      normalized.includes('توصيلات')
    ) {
      return {
        module: 'delivery',
        action: 'status_breakdown',
        filters: { companyId: true },
        aggregations: { count: true, groupBy: 'status' },
        limit: limit || 10,
        language,
      };
    }

    // ── 8. Branch revenue ─────────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['branch', 'sales']) ||
      this.matchesKeywords(normalized, ['branch', 'revenue']) ||
      this.matchesKeywords(normalized, ['إيرادات', 'فروع']) ||
      this.matchesKeywords(normalized, ['فروع']) ||
      normalized.includes('branch revenue') ||
      normalized.includes('إيرادات الفروع') ||
      normalized.includes('revenue per branch')
    ) {
      return {
        module: 'sales',
        action: 'branch_revenue',
        filters: { companyId: true },
        aggregations: { sum: 'totalAmount', groupBy: 'branchId' },
        limit,
        language,
      };
    }

    // ── 9. Poultry feed cost ──────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['feed', 'cost']) ||
      this.matchesKeywords(normalized, ['علف', 'تكلفة']) ||
      normalized.includes('feed cost') ||
      normalized.includes('تكلفة علف') ||
      normalized.includes('poultry feed') ||
      normalized.includes('تكلفة أعلاف')
    ) {
      return {
        module: 'feed',
        action: 'feed_cost',
        filters: { companyId: true },
        aggregations: { sum: 'totalCost', avg: 'costPerTon' },
        limit,
        language,
      };
    }

    // ── 10. Mortality rate ────────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['mortality']) ||
      this.matchesKeywords(normalized, ['نفوق']) ||
      normalized.includes('mortality rate') ||
      normalized.includes('معدل النفوق') ||
      normalized.includes('death rate') ||
      normalized.includes('نسبة النفوق')
    ) {
      return {
        module: 'livestock',
        action: 'mortality_rate',
        filters: { companyId: true },
        aggregations: { sum: 'mortalityCount', sumTotal: 'quantity' },
        limit,
        language,
      };
    }

    // ── 11. Absent employees today ────────────────────────────
    if (
      this.matchesKeywords(normalized, ['employees', 'absent']) ||
      this.matchesKeywords(normalized, ['موظفين', 'غائبين']) ||
      this.matchesKeywords(normalized, ['غياب', 'اليوم']) ||
      normalized.includes('absent employees') ||
      normalized.includes('الموظفين الغائبين') ||
      normalized.includes('who is absent')
    ) {
      return {
        module: 'hr',
        action: 'absent_today',
        filters: { companyId: true, status: 'ABSENT' },
        aggregations: { count: true },
        timeRange: getTodayRange(),
        limit,
        language,
      };
    }

    // ── 12. Sales rep performance ─────────────────────────────
    if (
      this.matchesKeywords(normalized, ['rep', 'performance']) ||
      this.matchesKeywords(normalized, ['مندوبين', 'أداء']) ||
      this.matchesKeywords(normalized, ['مندوب', 'أداء']) ||
      normalized.includes('sales rep performance') ||
      normalized.includes('أداء المندوبين') ||
      normalized.includes('representative performance') ||
      normalized.includes('مبيعات المندوبين')
    ) {
      return {
        module: 'sales',
        action: 'rep_performance',
        filters: { companyId: true },
        aggregations: { sum: 'totalAmount', groupBy: 'salesRepId' },
        limit: limit || 10,
        language,
      };
    }

    // ── 13. Overdue invoices ──────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['invoices', 'overdue']) ||
      this.matchesKeywords(normalized, ['فواتير', 'مستحقة']) ||
      this.matchesKeywords(normalized, ['فواتير', 'متأخرة']) ||
      normalized.includes('overdue invoices') ||
      normalized.includes('فواتير مستحقة') ||
      normalized.includes('past due') ||
      normalized.includes('bills due')
    ) {
      return {
        module: 'sales',
        action: 'overdue_invoices',
        filters: { companyId: true, dueDatePassed: true },
        aggregations: { sum: 'balance', count: true },
        limit: limit || 20,
        language,
      };
    }

    // ── 14. Inventory movements today ─────────────────────────
    if (
      this.matchesKeywords(normalized, ['movements', 'today']) ||
      this.matchesKeywords(normalized, ['حركة', 'اليوم']) ||
      this.matchesKeywords(normalized, ['حركات', 'اليوم']) ||
      normalized.includes('inventory movements today') ||
      normalized.includes('حركة المخزون اليوم') ||
      normalized.includes('stock movements today')
    ) {
      return {
        module: 'inventory',
        action: 'movements_today',
        filters: { companyId: true },
        aggregations: { count: true, groupBy: 'type' },
        timeRange: getTodayRange(),
        limit: limit || 20,
        language,
      };
    }

    // ── 15. Production cost ───────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['production', 'cost']) ||
      this.matchesKeywords(normalized, ['تكلفة', 'إنتاج']) ||
      normalized.includes('production cost') ||
      normalized.includes('تكلفة الإنتاج') ||
      normalized.includes('manufacturing cost')
    ) {
      return {
        module: 'feed',
        action: 'production_cost',
        filters: { companyId: true },
        aggregations: { avg: 'totalCost', avgPerUnit: 'costPerTon' },
        limit,
        language,
      };
    }

    // ── 16. Fuel consumption ──────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['fuel']) ||
      this.matchesKeywords(normalized, ['وقود']) ||
      this.matchesKeywords(normalized, ['استهلاك', 'وقود']) ||
      normalized.includes('fuel consumption') ||
      normalized.includes('استهلاك الوقود') ||
      normalized.includes('gas consumption') ||
      normalized.includes('diesel usage')
    ) {
      return {
        module: 'fleet',
        action: 'fuel_consumption',
        filters: { companyId: true },
        aggregations: { sum: 'liters', sumCost: 'totalCost', groupBy: 'vehicleId' },
        timeRange: getThisMonthRange(),
        limit: limit || 10,
        language,
      };
    }

    // ── 17. Cash position / treasury ──────────────────────────
    if (
      this.matchesKeywords(normalized, ['cash']) ||
      this.matchesKeywords(normalized, ['صناديق']) ||
      this.matchesKeywords(normalized, ['صندوق']) ||
      this.matchesKeywords(normalized, ['نقدية']) ||
      normalized.includes('cash position') ||
      normalized.includes('treasury') ||
      normalized.includes('الصناديق') ||
      normalized.includes('النقدية') ||
      normalized.includes('cash balance')
    ) {
      return {
        module: 'accounting',
        action: 'cash_position',
        filters: { companyId: true },
        aggregations: { sum: 'amount' },
        limit,
        language,
      };
    }

    // ── 18. Month-over-month comparison ───────────────────────
    if (
      this.matchesKeywords(normalized, ['comparison']) ||
      this.matchesKeywords(normalized, ['مقارنة']) ||
      normalized.includes('month over month') ||
      normalized.includes('مقارنة الشهر') ||
      normalized.includes('compare this month') ||
      normalized.includes('مقارنة بالشهر') ||
      normalized.includes('current vs previous')
    ) {
      return {
        module: 'sales',
        action: 'month_comparison',
        filters: { companyId: true },
        aggregations: { sum: 'totalAmount' },
        timeRange: getThisMonthRange(),
        limit,
        language,
      };
    }

    // ── 19. Product profitability ─────────────────────────────
    if (
      this.matchesKeywords(normalized, ['profitability', 'product']) ||
      this.matchesKeywords(normalized, ['ربحية', 'منتج']) ||
      normalized.includes('profitability of') ||
      normalized.includes('ربحية منتج') ||
      normalized.includes('product profit') ||
      normalized.includes('profit margin')
    ) {
      const productName = this.extractProductName(query);
      return {
        module: 'sales',
        action: 'product_profitability',
        filters: { companyId: true, productName },
        aggregations: { sum: 'totalPrice', sumCost: 'avgCost' },
        limit,
        language,
      };
    }

    // ── 20. Sales forecast ────────────────────────────────────
    if (
      this.matchesKeywords(normalized, ['forecast']) ||
      this.matchesKeywords(normalized, ['تنبؤ']) ||
      this.matchesKeywords(normalized, ['توقع']) ||
      normalized.includes('sales forecast') ||
      normalized.includes('تنبؤ المبيعات') ||
      normalized.includes('forecast sales') ||
      normalized.includes('sales prediction')
    ) {
      return {
        module: 'sales',
        action: 'sales_forecast',
        filters: { companyId: true },
        aggregations: { avg: 'totalAmount', count: true },
        timeRange: getLastMonthRange(),
        limit: 30,
        language,
      };
    }

    // ── 21. Inventory valuation (extra) ───────────────────────
    if (
      normalized.includes('inventory value') ||
      normalized.includes('valuation') ||
      normalized.includes('قيمة المخزون')
    ) {
      return {
        module: 'inventory',
        action: 'inventory_value',
        filters: { companyId: true },
        aggregations: { sum: 'totalCost' },
        limit,
        language,
      };
    }

    // ── 22. Production output today (extra) ───────────────────
    if (
      normalized.includes('production today') ||
      normalized.includes('إنتاج اليوم') ||
      normalized.includes('output today')
    ) {
      return {
        module: 'production',
        action: 'output_today',
        filters: { companyId: true },
        aggregations: { sum: 'quantity' },
        timeRange: getTodayRange(),
        limit,
        language,
      };
    }

    // ── FALLBACK ──────────────────────────────────────────────
    return {
      module: 'unknown',
      action: 'fallback',
      filters: {},
      aggregations: {},
      limit,
      language,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 2: EXECUTION — Run Prisma queries based on intent
  // ═══════════════════════════════════════════════════════════

  async executeQuery(intent: QueryIntent, companyId: string): Promise<any> {
    const { module, action, filters, timeRange, limit } = intent;

    // ── SALES MODULE ──────────────────────────────────────────
    if (module === 'sales') {
      if (action === 'sum_today') {
        const invoices = await this.prisma.salesInvoice.findMany({
          where: {
            branch: { companyId },
            createdAt: { gte: timeRange!.start, lte: timeRange!.end },
            deletedAt: null,
            status: { notIn: ['CANCELLED', 'DRAFT'] },
          },
          select: { totalAmount: true, invoiceNumber: true },
        });
        const total = invoices.reduce((s, i) => s + Number(i.totalAmount), 0);
        return { total, count: invoices.length, invoices };
      }

      if (action === 'sum_month') {
        const invoices = await this.prisma.salesInvoice.findMany({
          where: {
            branch: { companyId },
            createdAt: { gte: timeRange!.start, lte: timeRange!.end },
            deletedAt: null,
            status: { notIn: ['CANCELLED', 'DRAFT'] },
          },
          select: { totalAmount: true, balance: true },
        });
        const total = invoices.reduce((s, i) => s + Number(i.totalAmount), 0);
        const paid = invoices.reduce(
          (s, i) => s + (Number(i.totalAmount) - Number(i.balance)),
          0,
        );
        return { total, paid, unpaid: total - paid, count: invoices.length };
      }

      if (action === 'top_customers') {
        const customers = await this.prisma.customer.findMany({
          where: { companyId, deletedAt: null },
          select: {
            id: true,
            name: true,
            code: true,
            currentBalance: true,
            salesInvoices: {
              where: {
                status: { notIn: ['CANCELLED', 'DRAFT'] },
                deletedAt: null,
              },
              select: { totalAmount: true },
            },
          },
          orderBy: { currentBalance: 'desc' },
          take: limit || 5,
        });
        const ranked = customers
          .map((c) => ({
            id: c.id,
            name: c.name,
            code: c.code,
            totalPurchases: c.salesInvoices.reduce(
              (s, i) => s + Number(i.totalAmount),
              0,
            ),
            currentBalance: Number(c.currentBalance),
          }))
          .sort((a, b) => b.totalPurchases - a.totalPurchases);
        return { customers: ranked };
      }

      if (action === 'customer_debts') {
        const customers = await this.prisma.customer.findMany({
          where: {
            companyId,
            currentBalance: { gt: 0 },
            deletedAt: null,
          },
          select: {
            id: true,
            name: true,
            code: true,
            currentBalance: true,
            creditLimit: true,
            paymentTerms: true,
          },
          orderBy: { currentBalance: 'desc' },
          take: limit || 10,
        });
        const totalDebt = customers.reduce(
          (s, c) => s + Number(c.currentBalance),
          0,
        );
        return { customers, totalDebt, count: customers.length };
      }

      if (action === 'branch_revenue') {
        const branches = await this.prisma.branch.findMany({
          where: { companyId, deletedAt: null },
          select: {
            id: true,
            name: true,
            code: true,
            salesInvoices: {
              where: {
                status: { notIn: ['CANCELLED', 'DRAFT'] },
                deletedAt: null,
              },
              select: { totalAmount: true },
            },
          },
        });
        const revenue = branches.map((b) => ({
          branchId: b.id,
          branchName: b.name,
          branchCode: b.code,
          revenue: b.salesInvoices.reduce(
            (s, i) => s + Number(i.totalAmount),
            0,
          ),
        }));
        return { branches: revenue.sort((a, b) => b.revenue - a.revenue) };
      }

      if (action === 'rep_performance') {
        const reps = await this.prisma.user.findMany({
          where: {
            companyId,
            role: { in: ['SALES_REP', 'BRANCH_MANAGER'] },
            deletedAt: null,
          },
          select: {
            id: true,
            fullName: true,
            salesInvoices: {
              where: {
                status: { notIn: ['CANCELLED', 'DRAFT'] },
                deletedAt: null,
              },
              select: { totalAmount: true },
            },
          },
        });
        const performance = reps.map((r) => ({
          repId: r.id,
          repName: r.fullName,
          totalSales: r.salesInvoices.reduce(
            (s, i) => s + Number(i.totalAmount),
            0,
          ),
          invoiceCount: r.salesInvoices.length,
        }));
        return {
          reps: performance.sort((a, b) => b.totalSales - a.totalSales),
        };
      }

      if (action === 'overdue_invoices') {
        const now = new Date();
        const invoices = await this.prisma.salesInvoice.findMany({
          where: {
            branch: { companyId },
            dueDate: { lt: now },
            balance: { gt: 0 },
            deletedAt: null,
            status: { notIn: ['CANCELLED', 'PAID', 'DRAFT'] },
          },
          select: {
            id: true,
            invoiceNumber: true,
            totalAmount: true,
            balance: true,
            dueDate: true,
            customer: { select: { name: true, phone: true } },
          },
          orderBy: { dueDate: 'asc' },
          take: limit || 20,
        });
        const totalOverdue = invoices.reduce(
          (s, i) => s + Number(i.balance),
          0,
        );
        return { invoices, totalOverdue, count: invoices.length };
      }

      if (action === 'month_comparison') {
        const thisMonth = await this.prisma.salesInvoice.findMany({
          where: {
            branch: { companyId },
            createdAt: {
              gte: getThisMonthRange().start,
              lte: getThisMonthRange().end,
            },
            deletedAt: null,
            status: { notIn: ['CANCELLED', 'DRAFT'] },
          },
          select: { totalAmount: true },
        });
        const lastMonth = await this.prisma.salesInvoice.findMany({
          where: {
            branch: { companyId },
            createdAt: {
              gte: getLastMonthRange().start,
              lte: getLastMonthRange().end,
            },
            deletedAt: null,
            status: { notIn: ['CANCELLED', 'DRAFT'] },
          },
          select: { totalAmount: true },
        });
        const thisTotal = thisMonth.reduce(
          (s, i) => s + Number(i.totalAmount),
          0,
        );
        const lastTotal = lastMonth.reduce(
          (s, i) => s + Number(i.totalAmount),
          0,
        );
        const change = lastTotal > 0 ? ((thisTotal - lastTotal) / lastTotal) * 100 : 0;
        return { thisMonth: thisTotal, lastMonth: lastTotal, changePercent: change };
      }

      if (action === 'product_profitability') {
        const productName = filters.productName;
        const where: any = {
          companyId,
          deletedAt: null,
        };
        if (productName) {
          where.name = { contains: productName, mode: 'insensitive' };
        }
        const products = await this.prisma.product.findMany({
          where,
          select: {
            id: true,
            name: true,
            code: true,
            avgCost: true,
            salePrice: true,
            salesInvoiceLines: {
              select: { totalPrice: true, quantity: true, unitPrice: true },
            },
          },
          take: limit || 10,
        });
        const results = products.map((p) => {
          const totalRevenue = p.salesInvoiceLines.reduce(
            (s, l) => s + Number(l.totalPrice),
            0,
          );
          const totalQty = p.salesInvoiceLines.reduce(
            (s, l) => s + Number(l.quantity),
            0,
          );
          const avgCost = Number(p.avgCost);
          const salePrice = Number(p.salePrice);
          const margin = salePrice - avgCost;
          const marginPercent = salePrice > 0 ? (margin / salePrice) * 100 : 0;
          return {
            productId: p.id,
            productName: p.name,
            productCode: p.code,
            totalRevenue,
            totalQtySold: totalQty,
            avgCost,
            salePrice,
            marginPerUnit: margin,
            marginPercent: Math.round(marginPercent * 100) / 100,
          };
        });
        return { products: results.sort((a, b) => b.marginPercent - a.marginPercent) };
      }

      if (action === 'sales_forecast') {
        // Get last 90 days of daily sales
        const ninetyDaysAgo = new Date();
        ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
        const invoices = await this.prisma.salesInvoice.findMany({
          where: {
            branch: { companyId },
            createdAt: { gte: ninetyDaysAgo },
            deletedAt: null,
            status: { notIn: ['CANCELLED', 'DRAFT'] },
          },
          select: { totalAmount: true, createdAt: true },
        });
        // Group by day
        const dailyMap = new Map<string, number>();
        invoices.forEach((inv) => {
          const d = new Date(inv.createdAt);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
          dailyMap.set(key, (dailyMap.get(key) || 0) + Number(inv.totalAmount));
        });
        const dailyTotals = Array.from(dailyMap.values());
        const avgDaily =
          dailyTotals.length > 0
            ? dailyTotals.reduce((s, v) => s + v, 0) / dailyTotals.length
            : 0;
        // Simple 30-day projection
        const forecast30Days = avgDaily * 30;
        // Also calculate trend (last 30 vs previous 30)
        const now = new Date();
        const thirtyAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const sixtyAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);
        const last30 = invoices
          .filter((i) => i.createdAt >= thirtyAgo)
          .reduce((s, i) => s + Number(i.totalAmount), 0);
        const prev30 = invoices
          .filter((i) => i.createdAt >= sixtyAgo && i.createdAt < thirtyAgo)
          .reduce((s, i) => s + Number(i.totalAmount), 0);
        const trend = prev30 > 0 ? ((last30 - prev30) / prev30) * 100 : 0;
        return {
          avgDailySales: Math.round(avgDaily * 100) / 100,
          forecast30Days: Math.round(forecast30Days * 100) / 100,
          actualLast30Days: last30,
          trendPercent: Math.round(trend * 100) / 100,
          dailyDataPoints: dailyTotals.length,
        };
      }
    }

    // ── INVENTORY MODULE ──────────────────────────────────────
    if (module === 'inventory') {
      if (action === 'product_stock') {
        const productName = filters.productName;
        const where: any = {
          companyId,
          deletedAt: null,
        };
        if (productName) {
          where.OR = [
            { name: { contains: productName, mode: 'insensitive' } },
            { code: { contains: productName, mode: 'insensitive' } },
          ];
        }
        const products = await this.prisma.product.findMany({
          where,
          select: {
            id: true,
            name: true,
            code: true,
            minStockLevel: true,
            avgCost: true,
            stockMovements: {
              select: { quantity: true, type: true },
            },
          },
          take: limit || 10,
        });
        const results = products.map((p) => {
          const netStock = p.stockMovements.reduce((s, m) => {
            const qty = Number(m.quantity);
            if (m.type === 'RECEIPT') return s + qty;
            if (m.type === 'ISSUE' || m.type === 'WASTE') return s - qty;
            return s;
          }, 0);
          return {
            productId: p.id,
            productName: p.name,
            productCode: p.code,
            currentStock: netStock,
            minStockLevel: Number(p.minStockLevel),
            avgCost: Number(p.avgCost),
            stockValue: Math.round(netStock * Number(p.avgCost) * 100) / 100,
          };
        });
        return { products: results };
      }

      if (action === 'low_stock') {
        const products = await this.prisma.product.findMany({
          where: { companyId, deletedAt: null },
          select: {
            id: true,
            name: true,
            code: true,
            minStockLevel: true,
            avgCost: true,
            stockMovements: { select: { quantity: true, type: true } },
          },
        });
        const lowStockProducts = products
          .map((p) => {
            const currentStock = p.stockMovements.reduce((s, m) => {
              const qty = Number(m.quantity);
              if (m.type === 'RECEIPT') return s + qty;
              if (m.type === 'ISSUE' || m.type === 'WASTE') return s - qty;
              return s;
            }, 0);
            return {
              productId: p.id,
              productName: p.name,
              productCode: p.code,
              currentStock,
              minStockLevel: Number(p.minStockLevel),
              shortfall: Math.max(0, Number(p.minStockLevel) - currentStock),
            };
          })
          .filter((p) => p.currentStock <= p.minStockLevel)
          .sort((a, b) => b.shortfall - a.shortfall)
          .slice(0, limit || 20);
        return { products: lowStockProducts, count: lowStockProducts.length };
      }

      if (action === 'movements_today') {
        const movements = await this.prisma.stockMovement.findMany({
          where: {
            warehouse: { branch: { companyId } },
            createdAt: { gte: timeRange!.start, lte: timeRange!.end },
          },
          select: { type: true, quantity: true, product: { select: { name: true } } },
        });
        const byType = new Map<string, { count: number; totalQty: number }>();
        movements.forEach((m) => {
          const existing = byType.get(m.type) || { count: 0, totalQty: 0 };
          existing.count++;
          existing.totalQty += Number(m.quantity);
          byType.set(m.type, existing);
        });
        return {
          totalMovements: movements.length,
          breakdown: Array.from(byType.entries()).map(([type, data]) => ({
            type,
            ...data,
          })),
        };
      }

      if (action === 'inventory_value') {
        const products = await this.prisma.product.findMany({
          where: { companyId, deletedAt: null },
          select: {
            id: true,
            name: true,
            avgCost: true,
            stockMovements: { select: { quantity: true, type: true } },
          },
        });
        let totalValue = 0;
        const productValues = products.map((p) => {
          const qty = p.stockMovements.reduce((s, m) => {
            const q = Number(m.quantity);
            if (m.type === 'RECEIPT') return s + q;
            if (m.type === 'ISSUE' || m.type === 'WASTE') return s - q;
            return s;
          }, 0);
          const value = qty * Number(p.avgCost);
          totalValue += value;
          return { productId: p.id, productName: p.name, quantity: qty, value };
        });
        return {
          totalValue: Math.round(totalValue * 100) / 100,
          productCount: products.length,
          products: productValues.sort((a, b) => b.value - a.value).slice(0, limit || 20),
        };
      }
    }

    // ── DELIVERY MODULE ───────────────────────────────────────
    if (module === 'delivery') {
      if (action === 'status_breakdown') {
        const deliveries = await this.prisma.deliveryOrder.findMany({
          where: {
            branch: { companyId },
            deletedAt: null,
          },
          select: { status: true },
        });
        const byStatus = new Map<string, number>();
        deliveries.forEach((d) => {
          byStatus.set(d.status, (byStatus.get(d.status) || 0) + 1);
        });
        return {
          totalDeliveries: deliveries.length,
          byStatus: Array.from(byStatus.entries()).map(([status, count]) => ({
            status,
            count,
          })),
        };
      }
    }

    // ── FEED MODULE ───────────────────────────────────────────
    if (module === 'feed') {
      if (action === 'feed_cost') {
        const costs = await this.prisma.feedCost.findMany({
          take: limit || 20,
          orderBy: { effectiveDate: 'desc' },
          include: {
            formula: { select: { name: true, targetAnimal: true, feedType: true } },
          },
        });
        const totalCost = costs.reduce((s, c) => s + Number(c.totalCost), 0);
        const avgCostPerTon =
          costs.length > 0
            ? costs.reduce((s, c) => s + Number(c.costPerTon), 0) / costs.length
            : 0;
        return {
          totalCost,
          avgCostPerTon: Math.round(avgCostPerTon * 100) / 100,
          formulaCount: costs.length,
          formulas: costs,
        };
      }

      if (action === 'production_cost') {
        const costs = await this.prisma.feedCost.findMany({
          take: limit || 50,
          select: {
            rawMaterialCost: true,
            laborCost: true,
            overheadCost: true,
            totalCost: true,
            costPerTon: true,
          },
        });
        const avgTotal =
          costs.length > 0
            ? costs.reduce((s, c) => s + Number(c.totalCost), 0) / costs.length
            : 0;
        const avgMaterial =
          costs.length > 0
            ? costs.reduce((s, c) => s + Number(c.rawMaterialCost), 0) / costs.length
            : 0;
        const avgLabor =
          costs.length > 0
            ? costs.reduce((s, c) => s + Number(c.laborCost), 0) / costs.length
            : 0;
        const avgOverhead =
          costs.length > 0
            ? costs.reduce((s, c) => s + Number(c.overheadCost), 0) / costs.length
            : 0;
        return {
          avgTotalCost: Math.round(avgTotal * 100) / 100,
          avgMaterialCost: Math.round(avgMaterial * 100) / 100,
          avgLaborCost: Math.round(avgLabor * 100) / 100,
          avgOverheadCost: Math.round(avgOverhead * 100) / 100,
          formulaCount: costs.length,
        };
      }
    }

    // ── LIVESTOCK MODULE ──────────────────────────────────────
    if (module === 'livestock') {
      if (action === 'mortality_rate') {
        const batches = await this.prisma.poultryBatch.findMany({
          where: { branch: { companyId } },
          select: {
            id: true,
            batchNumber: true,
            quantity: true,
            mortalityCount: true,
            currentCount: true,
            mortalityRecords: { select: { count: true, date: true } },
          },
        });
        let totalInitial = 0;
        let totalMortality = 0;
        const batchRates = batches.map((b) => {
          const initialQty = b.quantity;
          const mortality = b.mortalityRecords.reduce(
            (s, r) => s + r.count,
            0,
          );
          totalInitial += initialQty;
          totalMortality += mortality;
          const rate = initialQty > 0 ? (mortality / initialQty) * 100 : 0;
          return {
            batchId: b.id,
            batchNumber: b.batchNumber,
            initialQty,
            mortalityCount: mortality,
            currentCount: b.currentCount,
            mortalityRate: Math.round(rate * 100) / 100,
          };
        });
        const overallRate =
          totalInitial > 0 ? (totalMortality / totalInitial) * 100 : 0;
        return {
          overallMortalityRate: Math.round(overallRate * 100) / 100,
          totalInitial,
          totalMortality,
          batches: batchRates,
        };
      }
    }

    // ── HR MODULE ─────────────────────────────────────────────
    if (module === 'hr') {
      if (action === 'absent_today') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const absentRecords = await this.prisma.attendanceRecord.findMany({
          where: {
            employee: { companyId },
            date: { gte: today },
            status: 'ABSENT',
          },
          select: {
            id: true,
            date: true,
            status: true,
            employee: { select: { employeeNumber: true, user: { select: { fullName: true } } } },
          },
        });
        const totalEmployees = await this.prisma.employee.count({
          where: { companyId, deletedAt: null },
        });
        return {
          absentCount: absentRecords.length,
          totalEmployees,
          absentRate:
            totalEmployees > 0
              ? Math.round((absentRecords.length / totalEmployees) * 10000) / 100
              : 0,
          absentEmployees: absentRecords,
        };
      }
    }

    // ── FLEET MODULE ──────────────────────────────────────────
    if (module === 'fleet') {
      if (action === 'fuel_consumption') {
        const logs = await this.prisma.fuelLog.findMany({
          where: {
            vehicle: { companyId },
            date: {
              gte: getThisMonthRange().start,
              lte: getThisMonthRange().end,
            },
          },
          select: {
            liters: true,
            totalCost: true,
            pricePerLiter: true,
            vehicle: { select: { plateNumber: true, type: true } },
          },
        });
        const totalLiters = logs.reduce((s, l) => s + Number(l.liters), 0);
        const totalCost = logs.reduce((s, l) => s + Number(l.totalCost), 0);
        // Group by vehicle
        const byVehicle = new Map<
          string,
          { plateNumber: string; type: string; liters: number; cost: number }
        >();
        logs.forEach((l) => {
          const key = l.vehicle.plateNumber;
          const existing = byVehicle.get(key) || {
            plateNumber: l.vehicle.plateNumber,
            type: l.vehicle.type,
            liters: 0,
            cost: 0,
          };
          existing.liters += Number(l.liters);
          existing.cost += Number(l.totalCost);
          byVehicle.set(key, existing);
        });
        return {
          totalLiters: Math.round(totalLiters * 100) / 100,
          totalCost: Math.round(totalCost * 100) / 100,
          avgPricePerLiter:
            logs.length > 0
              ? Math.round(
                  (logs.reduce((s, l) => s + Number(l.pricePerLiter), 0) /
                    logs.length) *
                    10000,
                ) / 10000
              : 0,
          vehicleCount: byVehicle.size,
          byVehicle: Array.from(byVehicle.values()),
        };
      }
    }

    // ── ACCOUNTING MODULE ─────────────────────────────────────
    if (module === 'accounting') {
      if (action === 'cash_position') {
        // Sum all cash transactions (receipts positive, payments negative)
        const receipts = await this.prisma.cashTransaction.aggregate({
          where: { type: 'RECEIPT' },
          _sum: { amount: true },
        });
        const payments = await this.prisma.cashTransaction.aggregate({
          where: { type: 'PAYMENT' },
          _sum: { amount: true },
        });
        // Bank account balances
        const bankAccounts = await this.prisma.bankAccount.findMany({
          where: { companyId, status: 'ACTIVE' },
          select: { bankName: true, accountNumber: true, currentBalance: true },
        });
        const totalBank = bankAccounts.reduce(
          (s, b) => s + Number(b.currentBalance),
          0,
        );
        const totalCash = Number(receipts._sum.amount || 0) - Number(payments._sum.amount || 0);
        const totalPosition = totalCash + totalBank;
        return {
          cashOnHand: Math.round(totalCash * 100) / 100,
          totalInBank: Math.round(totalBank * 100) / 100,
          totalPosition: Math.round(totalPosition * 100) / 100,
          bankAccounts,
        };
      }
    }

    // ── PRODUCTION MODULE ─────────────────────────────────────
    if (module === 'production') {
      if (action === 'output_today') {
        const productions = await this.prisma.eggProduction.findMany({
          where: {
            branch: { companyId },
            date: {
              gte: timeRange!.start,
              lte: timeRange!.end,
            },
          },
          select: { quantity: true, brokenCount: true, grade: true },
        });
        const total = productions.reduce((s, p) => s + p.quantity, 0);
        const broken = productions.reduce((s, p) => s + p.brokenCount, 0);
        return {
          totalProduced: total,
          brokenCount: broken,
          goodCount: total - broken,
          byGrade: productions.reduce((acc, p) => {
            acc[p.grade] = (acc[p.grade] || 0) + p.quantity;
            return acc;
          }, {} as Record<string, number>),
        };
      }
    }

    // Fallback — no matching action
    return { fallback: true };
  }

  // ═══════════════════════════════════════════════════════════
  // STEP 3: FORMATTING — Build human-readable response
  // ═══════════════════════════════════════════════════════════

  formatResponse(
    result: any,
    originalQuery: string,
    language: 'ar' | 'en',
  ): NLPResponse {
    const intent = this.parseQuery(originalQuery);
    const isAr = language === 'ar';

    // Handle unknown / fallback queries
    if (intent.module === 'unknown' || result.fallback) {
      return {
        answer: isAr
          ? `عذراً، لم أفهم سؤالك: "${originalQuery}". يمكنك السؤال عن: المبيعات، المخزون، العملاء، التوصيلات، النفوق، الموظفين، الفواتير المستحقة، أو استهلاك الوقود.`
          : `Sorry, I didn't understand: "${originalQuery}". Try asking about: sales, inventory, customers, deliveries, mortality, employees, overdue invoices, or fuel consumption.`,
        type: 'fallback',
      };
    }

    // ── SALES ─────────────────────────────────────────────────
    if (intent.module === 'sales') {
      if (intent.action === 'sum_today') {
        const currency = isAr ? 'ج.م' : 'EGP';
        return {
          answer: isAr
            ? `إجمالي مبيعات اليوم: ${result.total.toFixed(2)} ${currency} عبر ${result.count} فاتورة.`
            : `Total sales today: ${result.total.toFixed(2)} ${currency} across ${result.count} invoices.`,
          type: 'sales_today',
          data: result,
        };
      }

      if (intent.action === 'sum_month') {
        const currency = isAr ? 'ج.م' : 'EGP';
        return {
          answer: isAr
            ? `مبيعات هذا الشهر: ${result.total.toFixed(2)} ${currency} (${result.count} فاتورة). المحصّل: ${result.paid.toFixed(2)}، المستحق: ${result.unpaid.toFixed(2)}.`
            : `Sales this month: ${result.total.toFixed(2)} ${currency} (${result.count} invoices). Collected: ${result.paid.toFixed(2)}, Outstanding: ${result.unpaid.toFixed(2)}.`,
          type: 'sales_month',
          data: result,
        };
      }

      if (intent.action === 'top_customers') {
        const topList = result.customers
          .slice(0, 5)
          .map(
            (c: any, i: number) =>
              `${i + 1}. ${c.name} — ${c.totalPurchases.toFixed(2)}`,
          )
          .join('\n');
        return {
          answer: isAr
            ? `أعلى ${result.customers.length} عملاء:\n${topList}`
            : `Top ${result.customers.length} customers:\n${topList}`,
          type: 'top_customers',
          data: result.customers,
        };
      }

      if (intent.action === 'customer_debts') {
        return {
          answer: isAr
            ? `إجمالي مديونيات العملاء: ${result.totalDebt.toFixed(2)} ج.م (${result.count} عميل).`
            : `Total customer debts: ${result.totalDebt.toFixed(2)} EGP (${result.count} customers).`,
          type: 'customer_debts',
          data: result,
        };
      }

      if (intent.action === 'branch_revenue') {
        const list = result.branches
          .map((b: any) => `${b.branchName}: ${b.revenue.toFixed(2)}`)
          .join('\n');
        const total = result.branches.reduce(
          (s: number, b: any) => s + b.revenue,
          0,
        );
        return {
          answer: isAr
            ? `إيرادات الفروع:\n${list}\nالإجمالي: ${total.toFixed(2)} ج.م`
            : `Branch revenue:\n${list}\nTotal: ${total.toFixed(2)} EGP`,
          type: 'branch_revenue',
          data: result.branches,
        };
      }

      if (intent.action === 'rep_performance') {
        const list = result.reps
          .slice(0, 5)
          .map(
            (r: any, i: number) =>
              `${i + 1}. ${r.repName}: ${r.totalSales.toFixed(2)} (${r.invoiceCount} inv)`,
          )
          .join('\n');
        return {
          answer: isAr
            ? `أداء المندوبين:\n${list}`
            : `Sales rep performance:\n${list}`,
          type: 'rep_performance',
          data: result.reps,
        };
      }

      if (intent.action === 'overdue_invoices') {
        return {
          answer: isAr
            ? `الفواتير المستحقة: ${result.count} فاتورة بإجمالي ${result.totalOverdue.toFixed(2)} ج.م`
            : `Overdue invoices: ${result.count} invoices totaling ${result.totalOverdue.toFixed(2)} EGP`,
          type: 'overdue_invoices',
          data: result,
        };
      }

      if (intent.action === 'month_comparison') {
        const trendDir = result.changePercent >= 0 ? '+' : '';
        return {
          answer: isAr
            ? `مقارنة الشهر: هذا الشهر ${result.thisMonth.toFixed(2)} ج.م | الشهر الماضي ${result.lastMonth.toFixed(2)} ج.م | التغير: ${trendDir}${result.changePercent.toFixed(1)}%`
            : `Month comparison: This month ${result.thisMonth.toFixed(2)} EGP | Last month ${result.lastMonth.toFixed(2)} EGP | Change: ${trendDir}${result.changePercent.toFixed(1)}%`,
          type: 'month_comparison',
          data: result,
        };
      }

      if (intent.action === 'product_profitability') {
        const top = result.products[0];
        return {
          answer: isAr
            ? `تم تحليل ${result.products.length} منتج. الأعلى ربحية: ${top?.productName || 'N/A'} (هامش ${top?.marginPercent || 0}%)`
            : `Analyzed ${result.products.length} products. Most profitable: ${top?.productName || 'N/A'} (margin ${top?.marginPercent || 0}%)`,
          type: 'product_profitability',
          data: result.products,
        };
      }

      if (intent.action === 'sales_forecast') {
        return {
          answer: isAr
            ? `تنبؤ المبيعات (30 يوم): ${result.forecast30Days.toFixed(2)} ج.م | المتوسط اليومي: ${result.avgDailySales.toFixed(2)} | الاتجاه: ${result.trendPercent >= 0 ? '+' : ''}${result.trendPercent.toFixed(1)}%`
            : `Sales forecast (30 days): ${result.forecast30Days.toFixed(2)} EGP | Daily average: ${result.avgDailySales.toFixed(2)} | Trend: ${result.trendPercent >= 0 ? '+' : ''}${result.trendPercent.toFixed(1)}%`,
          type: 'sales_forecast',
          data: result,
        };
      }
    }

    // ── INVENTORY ─────────────────────────────────────────────
    if (intent.module === 'inventory') {
      if (intent.action === 'product_stock') {
        const p = result.products[0];
        if (!p) {
          return {
            answer: isAr
              ? 'لم يتم العثور على المنتج المطلوب.'
              : 'Product not found.',
            type: 'product_stock',
            data: result.products,
          };
        }
        return {
          answer: isAr
            ? `مخزون ${p.productName}: ${p.currentStock} وحدة (الحد الأدنى: ${p.minStockLevel}) — القيمة: ${p.stockValue.toFixed(2)} ج.م`
            : `Stock of ${p.productName}: ${p.currentStock} units (min: ${p.minStockLevel}) — Value: ${p.stockValue.toFixed(2)} EGP`,
          type: 'product_stock',
          data: result.products,
        };
      }

      if (intent.action === 'low_stock') {
        return {
          answer: isAr
            ? `منتجات تحت الحد الأدنى: ${result.count} منتج${result.count !== 1 ? 'ات' : ''}`
            : `Low stock products: ${result.count} product${result.count !== 1 ? 's' : ''}`,
          type: 'low_stock',
          data: result.products,
        };
      }

      if (intent.action === 'movements_today') {
        return {
          answer: isAr
            ? `حركات المخزون اليوم: ${result.totalMovements} حركة`
            : `Inventory movements today: ${result.totalMovements} movements`,
          type: 'movements_today',
          data: result.breakdown,
        };
      }

      if (intent.action === 'inventory_value') {
        return {
          answer: isAr
            ? `إجمالي قيمة المخزون: ${result.totalValue.toFixed(2)} ج.م (${result.productCount} منتج)`
            : `Total inventory value: ${result.totalValue.toFixed(2)} EGP (${result.productCount} products)`,
          type: 'inventory_value',
          data: result,
        };
      }
    }

    // ── DELIVERY ──────────────────────────────────────────────
    if (intent.module === 'delivery') {
      if (intent.action === 'status_breakdown') {
        const list = result.byStatus
          .map((s: any) => `${s.status}: ${s.count}`)
          .join('\n');
        return {
          answer: isAr
            ? `حالة التوصيلات (${result.totalDeliverions}):\n${list}`
            : `Delivery status (${result.totalDeliverions}):\n${list}`,
          type: 'delivery_status',
          data: result.byStatus,
        };
      }
    }

    // ── FEED ──────────────────────────────────────────────────
    if (intent.module === 'feed') {
      if (intent.action === 'feed_cost') {
        return {
          answer: isAr
            ? `تكلفة الأعلاف: ${result.totalCost.toFixed(2)} ج.م | المتوسط: ${result.avgCostPerTon.toFixed(2)}/طن | ${result.formulaCount} تركيبة`
            : `Feed cost: ${result.totalCost.toFixed(2)} EGP | Avg: ${result.avgCostPerTon.toFixed(2)}/ton | ${result.formulaCount} formulas`,
          type: 'feed_cost',
          data: result,
        };
      }

      if (intent.action === 'production_cost') {
        return {
          answer: isAr
            ? `تكلفة الإنتاج — المتوسط: ${result.avgTotalCost.toFixed(2)} ج.م | مواد: ${result.avgMaterialCost.toFixed(2)} | عمالة: ${result.avgLaborCost.toFixed(2)} | عبء: ${result.avgOverheadCost.toFixed(2)}`
            : `Production cost — Avg: ${result.avgTotalCost.toFixed(2)} EGP | Materials: ${result.avgMaterialCost.toFixed(2)} | Labor: ${result.avgLaborCost.toFixed(2)} | Overhead: ${result.avgOverheadCost.toFixed(2)}`,
          type: 'production_cost',
          data: result,
        };
      }
    }

    // ── LIVESTOCK ─────────────────────────────────────────────
    if (intent.module === 'livestock') {
      if (intent.action === 'mortality_rate') {
        return {
          answer: isAr
            ? `معدل النفوق الإجمالي: ${result.overallMortalityRate}% (${result.totalMortality} من ${result.totalInitial} طير)`
            : `Overall mortality rate: ${result.overallMortalityRate}% (${result.totalMortality} of ${result.totalInitial} birds)`,
          type: 'mortality_rate',
          data: result,
        };
      }
    }

    // ── HR ────────────────────────────────────────────────────
    if (intent.module === 'hr') {
      if (intent.action === 'absent_today') {
        return {
          answer: isAr
            ? `الموظفين الغائبين اليوم: ${result.absentCount} من ${result.totalEmployees} (${result.absentRate}%)`
            : `Absent employees today: ${result.absentCount} of ${result.totalEmployees} (${result.absentRate}%)`,
          type: 'absent_today',
          data: result,
        };
      }
    }

    // ── FLEET ─────────────────────────────────────────────────
    if (intent.module === 'fleet') {
      if (intent.action === 'fuel_consumption') {
        return {
          answer: isAr
            ? `استهلاك الوقود هذا الشهر: ${result.totalLiters.toFixed(2)} لتر — ${result.totalCost.toFixed(2)} ج.م (${result.vehicleCount} مركبة)`
            : `Fuel consumption this month: ${result.totalLiters.toFixed(2)} L — ${result.totalCost.toFixed(2)} EGP (${result.vehicleCount} vehicles)`,
          type: 'fuel_consumption',
          data: result,
        };
      }
    }

    // ── ACCOUNTING ────────────────────────────────────────────
    if (intent.module === 'accounting') {
      if (intent.action === 'cash_position') {
        return {
          answer: isAr
            ? `المركز النقدي: ${result.totalPosition.toFixed(2)} ج.م (نقدية: ${result.cashOnHand.toFixed(2)} | بنوك: ${result.totalInBank.toFixed(2)})`
            : `Cash position: ${result.totalPosition.toFixed(2)} EGP (Cash: ${result.cashOnHand.toFixed(2)} | Bank: ${result.totalInBank.toFixed(2)})`,
          type: 'cash_position',
          data: result,
        };
      }
    }

    // ── PRODUCTION ────────────────────────────────────────────
    if (intent.module === 'production') {
      if (intent.action === 'output_today') {
        return {
          answer: isAr
            ? `إنتاج اليوم: ${result.totalProduced} بيضة (${result.goodCount} سليم + ${result.brokenCount} تالف)`
            : `Today's production: ${result.totalProduced} eggs (${result.goodCount} good + ${result.brokenCount} broken)`,
          type: 'production_output',
          data: result,
        };
      }
    }

    // Ultimate fallback
    return {
      answer: isAr
        ? `النتيجة: ${JSON.stringify(result).slice(0, 200)}`
        : `Result: ${JSON.stringify(result).slice(0, 200)}`,
      type: 'raw',
      data: result,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // CACHE HELPERS
  // ═══════════════════════════════════════════════════════════

  private getCached(key: string): NLPResponse | null {
    const entry = this.queryCache.get(key);
    if (!entry) return null;
    if (new Date() > entry.expiresAt) {
      this.queryCache.delete(key);
      return null;
    }
    return entry.result;
  }

  private setCache(key: string, result: NLPResponse): void {
    // LRU eviction
    if (this.queryCache.size >= this.MAX_CACHE_SIZE) {
      const oldestKey = this.queryCache.keys().next().value;
      this.queryCache.delete(oldestKey);
    }
    this.queryCache.set(key, {
      result,
      expiresAt: new Date(Date.now() + this.CACHE_TTL_MS),
    });
  }

  // ═══════════════════════════════════════════════════════════
  // NLP HELPERS
  // ═══════════════════════════════════════════════════════════

  /**
   * Check if the normalized query contains ANY keyword from each group.
   * groups example: ['sales', 'today'] → must have at least one from each
   */
  private matchesKeywords(normalized: string, groups: string[]): boolean {
    return groups.every((group) => {
      const keywords = AR_TO_EN_KEYWORDS[group] || [group];
      return keywords.some((kw) => normalized.includes(kw.toLowerCase()));
    });
  }

  /**
   * Extract product name from a query like "stock of product X" or "مخزون منتج X"
   */
  private extractProductName(query: string): string | undefined {
    const lower = query.toLowerCase().trim();

    // English patterns
    const enPatterns = [
      /stock of(?: product)?\s+(.+)/i,
      /inventory of(?: product)?\s+(.+)/i,
      /product\s+(.+?)\s+(?:stock|inventory)/i,
      /profitability of(?: product)?\s+(.+)/i,
    ];
    for (const pattern of enPatterns) {
      const match = lower.match(pattern);
      if (match && match[1]) return match[1].trim();
    }

    // Arabic patterns
    const arPatterns = [
      /مخزون منتج\s+(.+)/,
      /كمية منتج\s+(.+)/,
      /مخزون\s+(.+)/,
      /ربحية منتج\s+(.+)/,
      /ربحية\s+(.+)/,
    ];
    for (const pattern of arPatterns) {
      const match = query.match(pattern);
      if (match && match[1]) return match[1].trim();
    }

    return undefined;
  }
}
