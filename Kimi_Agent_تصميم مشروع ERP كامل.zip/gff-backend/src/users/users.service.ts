import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import { hashPassword } from '@/common/utils/password.util';
import { CreateUserDto, UpdateUserDto } from './dto';

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findAll(companyId: string, options: { page?: number; limit?: number; search?: string; status?: string }) {
    const { page = 1, limit = 10, search, status } = options;
    const skip = (page - 1) * limit;

    const where: any = { companyId, deletedAt: null };
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          role: { select: { id: true, name: true, permissions: true } },
          branch: { select: { id: true, name: true } },
        },
      }),
      this.prisma.user.count({ where }),
    ]);

    return {
      data: users.map((u) => this.sanitizeUser(u)),
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOne(id: string, companyId: string) {
    const user = await this.prisma.user.findFirst({
      where: { id, companyId, deletedAt: null },
      include: {
        role: { select: { id: true, name: true, permissions: true } },
        branch: { select: { id: true, name: true } },
      },
    });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    return { data: this.sanitizeUser(user) };
  }

  async findByEmail(email: string) {
    return this.prisma.user.findFirst({
      where: { email, deletedAt: null },
      include: { role: true, company: true },
    });
  }

  async create(companyId: string, dto: CreateUserDto) {
    const existing = await this.prisma.user.findFirst({
      where: { email: dto.email, companyId },
    });
    if (existing) {
      throw new ConflictException('Email already exists in this company');
    }

    const hashedPassword = await hashPassword(dto.password);

    const user = await this.prisma.user.create({
      data: {
        name: dto.name,
        email: dto.email,
        password: hashedPassword,
        phone: dto.phone,
        companyId,
        roleId: dto.roleId,
        branchId: dto.branchId,
        department: dto.department,
      },
      include: {
        role: { select: { id: true, name: true } },
        branch: { select: { id: true, name: true } },
      },
    });

    this.logger.log(`User created: ${user.email} in company ${companyId}`);

    return { data: this.sanitizeUser(user) };
  }

  async update(id: string, companyId: string, dto: UpdateUserDto) {
    const user = await this.prisma.user.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    if (dto.email && dto.email !== user.email) {
      const existing = await this.prisma.user.findFirst({
        where: { email: dto.email, companyId },
      });
      if (existing) {
        throw new ConflictException('Email already in use');
      }
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data: {
        name: dto.name,
        email: dto.email,
        phone: dto.phone,
        roleId: dto.roleId,
        branchId: dto.branchId,
        status: dto.status,
      },
      include: {
        role: { select: { id: true, name: true } },
        branch: { select: { id: true, name: true } },
      },
    });

    this.logger.log(`User updated: ${updated.email}`);

    return { data: this.sanitizeUser(updated) };
  }

  async remove(id: string, companyId: string) {
    const user = await this.prisma.user.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    await this.prisma.user.update({
      where: { id },
      data: { deletedAt: new Date(), status: 'INACTIVE' },
    });

    this.logger.log(`User soft deleted: ${id}`);

    return { data: { message: 'User deleted successfully' } };
  }

  async updateStatus(id: string, companyId: string, status: string) {
    const user = await this.prisma.user.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data: { status: status as any },
      include: {
        role: { select: { id: true, name: true } },
        branch: { select: { id: true, name: true } },
      },
    });

    return { data: this.sanitizeUser(updated) };
  }

  async assignRole(id: string, companyId: string, roleId: string) {
    const user = await this.prisma.user.findFirst({
      where: { id, companyId, deletedAt: null },
    });
    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    const role = await this.prisma.role.findFirst({
      where: { id: roleId, companyId },
    });
    if (!role) {
      throw new NotFoundException(`Role with ID ${roleId} not found`);
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data: { roleId },
      include: {
        role: { select: { id: true, name: true, permissions: true } },
        branch: { select: { id: true, name: true } },
      },
    });

    return { data: this.sanitizeUser(updated) };
  }

  async getPermissions(id: string, companyId: string) {
    const user = await this.prisma.user.findFirst({
      where: { id, companyId, deletedAt: null },
      include: { role: true },
    });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    const permissions = user.role?.permissions || [];

    return { data: { userId: id, role: user.role?.name, permissions } };
  }

  private sanitizeUser(user: any) {
    const { password, ...rest } = user;
    return rest;
  }
}
