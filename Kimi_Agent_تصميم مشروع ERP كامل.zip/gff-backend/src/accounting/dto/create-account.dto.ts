import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsOptional,
  IsNotEmpty,
  MaxLength,
  IsNumber,
  IsUUID,
  IsEnum,
} from 'class-validator';
import { AccountType, CashTransactionType, BankAccountType } from '@prisma/client';

export class CreateAccountDto {
  @ApiProperty({ example: '1100' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ example: 'النقدية في الصندوق' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(150)
  nameAr: string;

  @ApiProperty({ example: 'Cash on Hand', required: false })
  @IsOptional()
  @IsString()
  @MaxLength(150)
  nameEn?: string;

  @ApiProperty({ example: 'ASSET', enum: AccountType })
  @IsEnum(AccountType)
  type: AccountType;

  @ApiProperty({ example: '550e8400-e29b-41d4-a716-446655440000', required: false })
  @IsOptional()
  @IsUUID()
  parentId?: string;
}

export class CreateJournalEntryDto {
  @ApiProperty({ example: 'Sales invoice INV-001' })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({
    example: [
      { accountId: '550e8400-e29b-41d4-a716-446655440000', debit: 1000, credit: 0 },
      { accountId: '550e8400-e29b-41d4-a716-446655440001', debit: 0, credit: 1000 },
    ],
  })
  lines: Array<{
    accountId: string;
    debit: number;
    credit: number;
    description?: string;
  }>;
}

export class CreateBankAccountDto {
  @ApiProperty({ example: 'Housing Bank' })
  @IsString()
  @IsNotEmpty()
  bankName: string;

  @ApiProperty({ example: '1234567890' })
  @IsString()
  @IsNotEmpty()
  accountNumber: string;

  @ApiProperty({ example: 'CURRENT', enum: BankAccountType })
  @IsEnum(BankAccountType)
  accountType: BankAccountType;

  @ApiProperty({ example: 'Main Branch', required: false })
  @IsOptional()
  @IsString()
  branchName?: string;
}

export class CreateCashTransactionDto {
  @ApiProperty({ example: 'RECEIPT', enum: CashTransactionType })
  @IsEnum(CashTransactionType)
  type: CashTransactionType;

  @ApiProperty({ example: 5000 })
  @IsNumber()
  amount: number;

  @ApiProperty({ example: 'Cash receipt from customer payment' })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({ example: 'RCP-001', required: false })
  @IsOptional()
  @IsString()
  reference?: string;

  @ApiProperty({ example: 'customer-payment', required: false })
  @IsOptional()
  @IsString()
  category?: string;
}

export class ReconcileDto {
  @ApiProperty({ example: '2024-01-31' })
  @IsString()
  @IsNotEmpty()
  statementDate: string;

  @ApiProperty({ example: 15000 })
  @IsNumber()
  statementBalance: number;
}
