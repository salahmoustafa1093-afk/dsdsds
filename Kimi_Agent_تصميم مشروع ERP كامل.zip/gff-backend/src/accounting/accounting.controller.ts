import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  ParseUUIDPipe,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiQuery,
} from '@nestjs/swagger';
import { AccountingService } from './accounting.service';
import { JwtAuthGuard } from '@/common/guards/jwt-auth.guard';
import { PermissionsGuard } from '@/common/guards/permissions.guard';
import { Permissions } from '@/common/decorators/permissions.decorator';
import { CurrentUser } from '@/common/decorators/current-user.decorator';
import {
  CreateAccountDto,
  CreateJournalEntryDto,
  CreateBankAccountDto,
  CreateCashTransactionDto,
} from './dto';

@ApiTags('Accounting')
@ApiBearerAuth()
@ApiResponse({ status: 401, description: 'Unauthorized' })
@ApiResponse({ status: 403, description: 'Forbidden' })
@ApiResponse({ status: 429, description: 'Too Many Requests' })
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('accounting')
export class AccountingController {
  constructor(private readonly accountingService: AccountingService) {}

  // ========== CHART OF ACCOUNTS ==========
  @Get('accounts')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'List accounts' })
  @ApiResponse({ status: 200, description: 'Accounts retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllAccounts(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('type') type?: string,
  ) {
    return this.accountingService.findAllAccounts(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      type,
    });
  }

  @Get('accounts/:id')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'Get account by ID' })
  @ApiResponse({ status: 200, description: 'Account retrieved' })
  @ApiResponse({ status: 404, description: 'Account not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findOneAccount(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.accountingService.findOneAccount(id, companyId);
  }

  @Post('accounts')
  @Permissions('accounting:create')
  @ApiOperation({ summary: 'Create account' })
  @ApiResponse({ status: 201, description: 'Account created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createAccount(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateAccountDto,
  ) {
    return this.accountingService.createAccount(companyId, dto);
  }

  @Put('accounts/:id')
  @Permissions('accounting:create')
  @ApiOperation({ summary: 'Update account' })
  @ApiResponse({ status: 200, description: 'Account updated' })
  @ApiResponse({ status: 404, description: 'Account not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateAccount(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: Partial<CreateAccountDto>,
  ) {
    return this.accountingService.updateAccount(id, companyId, dto);
  }

  @Get('accounts/:id/balance')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'Get account balance' })
  @ApiResponse({ status: 200, description: 'Account balance retrieved' })
  @ApiResponse({ status: 404, description: 'Account not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getAccountBalance(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
  ) {
    return this.accountingService.getAccountBalance(id, companyId);
  }

  // ========== JOURNAL ENTRIES ==========
  @Get('journal-entries')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'List journal entries' })
  @ApiResponse({ status: 200, description: 'Journal entries retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllJournalEntries(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    return this.accountingService.findAllJournalEntries(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      startDate,
      endDate,
    });
  }

  @Post('journal-entries')
  @Permissions('accounting:create')
  @ApiOperation({ summary: 'Create journal entry' })
  @ApiResponse({ status: 201, description: 'Journal entry created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createJournalEntry(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateJournalEntryDto,
  ) {
    return this.accountingService.createJournalEntry(companyId, dto);
  }

  @Put('journal-entries/:id/post')
  @Permissions('accounting:approve')
  @ApiOperation({ summary: 'Post journal entry' })
  @ApiResponse({ status: 200, description: 'Journal entry posted' })
  @ApiResponse({ status: 404, description: 'Journal entry not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async postJournalEntry(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
  ) {
    return this.accountingService.postJournalEntry(id, companyId, userId);
  }

  // ========== BANK ACCOUNTS ==========
  @Get('bank-accounts')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'List bank accounts' })
  @ApiResponse({ status: 200, description: 'Bank accounts retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllBankAccounts(@CurrentUser('companyId') companyId: string) {
    return this.accountingService.findAllBankAccounts(companyId);
  }

  @Post('bank-accounts')
  @Permissions('accounting:create')
  @ApiOperation({ summary: 'Create bank account' })
  @ApiResponse({ status: 201, description: 'Bank account created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createBankAccount(
    @CurrentUser('companyId') companyId: string,
    @Body() dto: CreateBankAccountDto,
  ) {
    return this.accountingService.createBankAccount(companyId, dto);
  }

  @Put('bank-accounts/:id')
  @Permissions('accounting:create')
  @ApiOperation({ summary: 'Update bank account' })
  @ApiResponse({ status: 200, description: 'Bank account updated' })
  @ApiResponse({ status: 404, description: 'Bank account not found' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async updateBankAccount(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('companyId') companyId: string,
    @Body() dto: Partial<CreateBankAccountDto>,
  ) {
    return this.accountingService.updateBankAccount(id, companyId, dto);
  }

  // ========== CASH TRANSACTIONS ==========
  @Get('cash-transactions')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'List cash transactions' })
  @ApiResponse({ status: 200, description: 'Cash transactions retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async findAllCashTransactions(
    @CurrentUser('companyId') companyId: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
    @Query('type') type?: string,
  ) {
    return this.accountingService.findAllCashTransactions(companyId, {
      page: page ? parseInt(page) : 1,
      limit: limit ? parseInt(limit) : 10,
      type,
    });
  }

  @Post('cash-transactions')
  @Permissions('accounting:create')
  @ApiOperation({ summary: 'Create cash transaction' })
  @ApiResponse({ status: 201, description: 'Cash transaction created' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async createCashTransaction(
    @CurrentUser('companyId') companyId: string,
    @CurrentUser('userId') userId: string,
    @Body() dto: CreateCashTransactionDto,
  ) {
    return this.accountingService.createCashTransaction(companyId, dto, userId);
  }

  @Get('cash-transactions/balance')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'Get cash balance' })
  @ApiResponse({ status: 200, description: 'Cash balance retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getCashBalance(@CurrentUser('companyId') companyId: string) {
    return this.accountingService.getCashBalance(companyId);
  }

  // ========== REPORTS ==========
  @Get('trial-balance')
  @Permissions('accounting:view')
  @ApiOperation({ summary: 'Get trial balance' })
  @ApiResponse({ status: 200, description: 'Trial balance retrieved' })
  @ApiResponse({ status: 400, description: 'Bad Request' })
  async getTrialBalance(@CurrentUser('companyId') companyId: string) {
    return this.accountingService.getTrialBalance(companyId);
  }
}
