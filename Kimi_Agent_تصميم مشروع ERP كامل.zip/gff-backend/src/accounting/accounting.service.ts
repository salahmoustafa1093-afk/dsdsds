import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import {
  CreateAccountDto,
  CreateJournalEntryDto,
  CreateBankAccountDto,
  CreateCashTransactionDto,
} from './dto';
import { JournalStatus, Prisma, AccountType } from '@prisma/client';

// ─────────────────────────────────────────────
// Chart of Accounts constants
// ─────────────────────────────────────────────
const COA = {
  CASH: '1102',
  ACCOUNTS_RECEIVABLE: '1101',
  INVENTORY: '1105',
  INPUT_VAT: '1106',
  ACCOUNTS_PAYABLE: '2101',
  VAT_PAYABLE: '2203',
  SALES_REVENUE: '4101',
  PURCHASE_DISCOUNTS: '4102',
  COGS: '5101',
  ADMIN_EXPENSES: '5201',
  SELLING_EXPENSES: '5301',
  FINANCE_COSTS: '5401',
} as const;

// ─────────────────────────────────────────────
// Egyptian VAT rate
// ─────────────────────────────────────────────
const VAT_RATE = 0.14; // 14%

// ─────────────────────────────────────────────
// Helper: resolve account by code (ensures company-scoped)
// ─────────────────────────────────────────────
interface AccountResolution {
  id: string;
  code: string;
  nameAr: string;
  nameEn: string | null;
  type: string;
}

@Injectable()
export class AccountingService {
  private readonly logger = new Logger(AccountingService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ═══════════════════════════════════════════
  //  UTILITY: Get or create system account by code
  // ═══════════════════════════════════════════
  private async getAccountByCode(
    companyId: string,
    code: string,
  ): Promise<AccountResolution> {
    const account = await this.prisma.chartOfAccount.findFirst({
      where: { companyId, code },
      select: { id: true, code: true, nameAr: true, nameEn: true, type: true },
    });

    if (!account) {
      // Auto-create system account
      const nameArMap: Record<string, string> = {
        [COA.ACCOUNTS_RECEIVABLE]: 'الذمم المدينة',
        [COA.CASH]: 'النقدية في الصندوق',
        [COA.INVENTORY]: 'المخزون',
        [COA.INPUT_VAT]: 'ضريبة القيمة المضافة المدخلة',
        [COA.ACCOUNTS_PAYABLE]: 'الذمم الدائنة',
        [COA.VAT_PAYABLE]: 'ضريبة القيمة المضافة المستحقة',
        [COA.SALES_REVENUE]: 'إيرادات المبيعات',
        [COA.PURCHASE_DISCOUNTS]: 'خصومات المشتريات',
        [COA.COGS]: 'تكلفة البضاعة المباعة',
        [COA.ADMIN_EXPENSES]: 'مصاريف إدارية',
        [COA.SELLING_EXPENSES]: 'مصاريف بيعية',
        [COA.FINANCE_COSTS]: 'تكاليف تمويلية',
      };

      const nameEnMap: Record<string, string> = {
        [COA.ACCOUNTS_RECEIVABLE]: 'Accounts Receivable',
        [COA.CASH]: 'Cash',
        [COA.INVENTORY]: 'Inventory',
        [COA.INPUT_VAT]: 'Input VAT',
        [COA.ACCOUNTS_PAYABLE]: 'Accounts Payable',
        [COA.VAT_PAYABLE]: 'VAT Payable',
        [COA.SALES_REVENUE]: 'Sales Revenue',
        [COA.PURCHASE_DISCOUNTS]: 'Purchase Discounts',
        [COA.COGS]: 'Cost of Goods Sold',
        [COA.ADMIN_EXPENSES]: 'Administrative Expenses',
        [COA.SELLING_EXPENSES]: 'Selling Expenses',
        [COA.FINANCE_COSTS]: 'Finance Costs',
      };

      const typeMap: Record<string, string> = {
        [COA.ACCOUNTS_RECEIVABLE]: 'ASSET',
        [COA.CASH]: 'ASSET',
        [COA.INVENTORY]: 'ASSET',
        [COA.INPUT_VAT]: 'ASSET',
        [COA.ACCOUNTS_PAYABLE]: 'LIABILITY',
        [COA.VAT_PAYABLE]: 'LIABILITY',
        [COA.SALES_REVENUE]: 'REVENUE',
        [COA.PURCHASE_DISCOUNTS]: 'REVENUE',
        [COA.COGS]: 'EXPENSE',
        [COA.ADMIN_EXPENSES]: 'EXPENSE',
        [COA.SELLING_EXPENSES]: 'EXPENSE',
        [COA.FINANCE_COSTS]: 'EXPENSE',
      };

      const created = await this.prisma.chartOfAccount.create({
        data: {
          code,
          nameAr: nameArMap[code] ?? `حساب النظام ${code}`,
          nameEn: nameEnMap[code] ?? `System Account ${code}`,
          type: (typeMap[code] as AccountType) ?? 'ASSET',
          companyId,
          level: 1,
        },
        select: { id: true, code: true, nameAr: true, nameEn: true, type: true },
      });

      this.logger.log(`Auto-created system account: ${code} - ${created.nameAr}`);
      return created;
    }

    return account;
  }

  // ═══════════════════════════════════════════
  //  UTILITY: Generate entry number
  // ═══════════════════════════════════════════
  private async generateEntryNumber(companyId: string, prefix = 'JE') {
    const count = await this.prisma.journalEntry.count({ where: { companyId } });
    return `${prefix}-${Date.now().toString(36).toUpperCase()}-${(count + 1).toString().padStart(4, '0')}`;
  }

  // ═══════════════════════════════════════════
  //  UTILITY: Create journal entry atomically
  // ═══════════════════════════════════════════
  private async createJournalEntryAtomic(
    companyId: string,
    params: {
      description: string;
      date?: Date;
      lines: { accountId: string; debit: number; credit: number; description?: string }[];
    },
  ) {
    const totalDebit = params.lines.reduce((s, l) => s + l.debit, 0);
    const totalCredit = params.lines.reduce((s, l) => s + l.credit, 0);

    if (Math.abs(totalDebit - totalCredit) > 0.001) {
      throw new BadRequestException(
        `Debits (${totalDebit}) must equal credits (${totalCredit})`,
      );
    }

    const entryNumber = await this.generateEntryNumber(companyId);

    const entry = await this.prisma.$transaction(async (tx) => {
      const je = await tx.journalEntry.create({
        data: {
          entryNumber,
          companyId,
          description: params.description,
          date: params.date ?? new Date(),
          totalDebit,
          totalCredit,
          status: JournalStatus.POSTED,
          postedAt: new Date(),
          lines: {
            create: params.lines.map((line) => ({
              accountId: line.accountId,
              debit: line.debit,
              credit: line.credit,
              description: line.description,
            })),
          },
        },
        include: {
          lines: {
            include: {
              account: { select: { id: true, nameAr: true, nameEn: true, code: true } },
            },
          },
        },
      });

      // Update account balances inline
      for (const line of params.lines) {
        const netChange = line.debit - line.credit;
        await tx.chartOfAccount.update({
          where: { id: line.accountId },
          data: { balance: { increment: netChange } },
        });
      }

      return je;
    });

    this.logger.log(`Journal entry created & posted: ${entry.entryNumber}`);
    return entry;
  }

  // ═══════════════════════════════════════════
  //  UTILITY: Sum journal lines by account type range
  // ═══════════════════════════════════════════
  private async sumByAccountCodeRange(
    companyId: string,
    codePrefix: string,
    startDate?: Date,
    endDate?: Date,
  ) {
    const accountWhere: Prisma.ChartOfAccountWhereInput = {
      companyId,
      code: { startsWith: codePrefix },
    };

    const lines = await this.prisma.journalEntryLine.findMany({
      where: {
        account: accountWhere,
        entry: {
          companyId,
          ...(startDate && { date: { gte: startDate } }),
          ...(endDate && { date: { lte: endDate } }),
          status: JournalStatus.POSTED,
        },
      },
      select: { debit: true, credit: true, account: { select: { type: true } } },
    });

    let sum = 0;
    for (const line of lines) {
      if (line.account.type === 'ASSET' || line.account.type === 'EXPENSE') {
        sum += Number(line.debit) - Number(line.credit);
      } else {
        sum += Number(line.credit) - Number(line.debit);
      }
    }
    return sum;
  }

  // ═══════════════════════════════════════════
  // ========== CHART OF ACCOUNTS ==========
  // ═══════════════════════════════════════════

  async findAllAccounts(
    companyId: string,
    options: { page?: number; limit?: number; type?: string } = {},
  ) {
    const { page = 1, limit = 10, type } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.ChartOfAccountWhereInput = { companyId };
    if (type) where.type = type as Prisma.EnumAccountTypeFilter;

    const [data, total] = await Promise.all([
      this.prisma.chartOfAccount.findMany({
        where,
        skip,
        take: limit,
        orderBy: { code: 'asc' },
        include: {
          parent: { select: { id: true, nameAr: true, nameEn: true, code: true } },
          children: { select: { id: true, nameAr: true, nameEn: true, code: true } },
          _count: { select: { journalLines: true } },
        },
      }),
      this.prisma.chartOfAccount.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async findOneAccount(id: string, companyId: string) {
    const account = await this.prisma.chartOfAccount.findFirst({
      where: { id, companyId },
      include: {
        parent: true,
        children: true,
        journalLines: {
          include: {
            entry: {
              select: { id: true, entryNumber: true, date: true, description: true },
            },
          },
          take: 10,
          orderBy: { entry: { date: 'desc' } },
        },
      },
    });

    if (!account)
      throw new NotFoundException(`Account with ID ${id} not found`);
    return { data: account };
  }

  async createAccount(companyId: string, dto: CreateAccountDto) {
    const existing = await this.prisma.chartOfAccount.findFirst({
      where: { code: dto.code, companyId },
    });
    if (existing) throw new ConflictException('Account code already exists');

    const account = await this.prisma.chartOfAccount.create({
      data: { ...dto, companyId, level: 1 },
    });

    this.logger.log(`Account created: ${account.code} - ${account.nameAr}`);
    return { data: account };
  }

  async updateAccount(
    id: string,
    companyId: string,
    dto: Partial<CreateAccountDto>,
  ) {
    const account = await this.prisma.chartOfAccount.findFirst({
      where: { id, companyId },
    });
    if (!account)
      throw new NotFoundException(`Account with ID ${id} not found`);

    const updated = await this.prisma.chartOfAccount.update({
      where: { id },
      data: dto,
    });

    return { data: updated };
  }

  async getAccountBalance(id: string, companyId: string) {
    const account = await this.prisma.chartOfAccount.findFirst({
      where: { id, companyId },
      include: {
        journalLines: {
          select: { debit: true, credit: true },
        },
      },
    });

    if (!account)
      throw new NotFoundException(`Account with ID ${id} not found`);

    const totalDebit = account.journalLines.reduce(
      (sum, je) => sum + Number(je.debit),
      0,
    );
    const totalCredit = account.journalLines.reduce(
      (sum, je) => sum + Number(je.credit),
      0,
    );

    let balance = 0;
    if (account.type === 'ASSET' || account.type === 'EXPENSE') {
      balance = totalDebit - totalCredit;
    } else {
      balance = totalCredit - totalDebit;
    }

    return {
      data: {
        accountId: id,
        accountNameAr: account.nameAr,
        accountNameEn: account.nameEn,
        balance,
        totalDebit,
        totalCredit,
      },
    };
  }

  // ═══════════════════════════════════════════
  // ========== JOURNAL ENTRIES ==========
  // ═══════════════════════════════════════════

  async findAllJournalEntries(
    companyId: string,
    options: { page?: number; limit?: number; startDate?: string; endDate?: string } = {},
  ) {
    const { page = 1, limit = 10, startDate, endDate } = options;
    const skip = (page - 1) * limit;

    const where: Prisma.JournalEntryWhereInput = { companyId };
    if (startDate) where.date = { gte: new Date(startDate) };
    if (endDate) where.date = { ...where.date, lte: new Date(endDate) };

    const [data, total] = await Promise.all([
      this.prisma.journalEntry.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' },
        include: {
          lines: {
            include: {
              account: { select: { id: true, nameAr: true, nameEn: true, code: true } },
            },
          },
        },
      }),
      this.prisma.journalEntry.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async createJournalEntry(companyId: string, dto: CreateJournalEntryDto) {
    const totalDebit = dto.lines.reduce((sum, l) => sum + l.debit, 0);
    const totalCredit = dto.lines.reduce((sum, l) => sum + l.credit, 0);

    if (Math.abs(totalDebit - totalCredit) > 0.001) {
      throw new BadRequestException('Total debits must equal total credits');
    }

    const entryNumber = await this.generateEntryNumber(companyId);

    const entry = await this.prisma.journalEntry.create({
      data: {
        entryNumber,
        companyId,
        description: dto.description,
        totalDebit,
        totalCredit,
        lines: {
          create: dto.lines.map((line) => ({
            accountId: line.accountId,
            debit: line.debit,
            credit: line.credit,
            description: line.description,
          })),
        },
      },
      include: {
        lines: {
          include: {
            account: { select: { id: true, nameAr: true, nameEn: true, code: true } },
          },
        },
      },
    });

    this.logger.log(`Journal entry created: ${entry.entryNumber}`);
    return { data: entry };
  }

  async postJournalEntry(id: string, companyId: string, userId?: string) {
    const entry = await this.prisma.journalEntry.findFirst({
      where: { id, companyId },
    });
    if (!entry) throw new NotFoundException('Journal entry not found');
    if (entry.status === JournalStatus.POSTED)
      throw new BadRequestException('Journal entry already posted');

    await this.prisma.$transaction(async (tx) => {
      await tx.journalEntry.update({
        where: { id },
        data: { status: JournalStatus.POSTED, postedAt: new Date(), postedBy: userId },
      });

      const lines = await tx.journalEntryLine.findMany({
        where: { entryId: id },
      });

      for (const line of lines) {
        const netChange = Number(line.debit) - Number(line.credit);
        await tx.chartOfAccount.update({
          where: { id: line.accountId },
          data: { balance: { increment: netChange } },
        });
      }
    });

    return { data: { id, status: JournalStatus.POSTED } };
  }

  // ═══════════════════════════════════════════
  // ========== BANK ACCOUNTS ==========
  // ═══════════════════════════════════════════

  async findAllBankAccounts(companyId: string) {
    const accounts = await this.prisma.bankAccount.findMany({
      where: { companyId },
      orderBy: { createdAt: 'desc' },
    });

    return { data: accounts };
  }

  async createBankAccount(companyId: string, dto: CreateBankAccountDto) {
    const account = await this.prisma.bankAccount.create({
      data: { ...dto, companyId },
    });

    return { data: account };
  }

  async updateBankAccount(
    id: string,
    companyId: string,
    dto: Partial<CreateBankAccountDto>,
  ) {
    const account = await this.prisma.bankAccount.findFirst({
      where: { id, companyId },
    });
    if (!account) throw new NotFoundException('Bank account not found');

    const updated = await this.prisma.bankAccount.update({
      where: { id },
      data: dto,
    });

    return { data: updated };
  }

  // ═══════════════════════════════════════════
  // ========== CASH TRANSACTIONS (ex-Treasury) ==========
  // ═══════════════════════════════════════════

  /** Scope cash transactions through users belonging to a company */
  private async getUserIdsInCompany(companyId: string): Promise<string[]> {
    const users = await this.prisma.user.findMany({
      where: { companyId },
      select: { id: true },
    });
    return users.map((u) => u.id);
  }

  async findAllCashTransactions(
    companyId: string,
    options: { page?: number; limit?: number; type?: string } = {},
  ) {
    const { page = 1, limit = 10, type } = options;
    const skip = (page - 1) * limit;

    const userIds = await this.getUserIdsInCompany(companyId);

    const where: Prisma.CashTransactionWhereInput = {
      recordedBy: { in: userIds },
    };
    if (type) where.type = type as Prisma.EnumCashTransactionTypeFilter;

    const [data, total] = await Promise.all([
      this.prisma.cashTransaction.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' },
      }),
      this.prisma.cashTransaction.count({ where }),
    ]);

    return {
      data,
      meta: { page, limit, total, totalPages: Math.ceil(total / limit) },
    };
  }

  async createCashTransaction(
    companyId: string,
    dto: CreateCashTransactionDto,
    userId: string,
  ) {
    const transaction = await this.prisma.cashTransaction.create({
      data: { ...dto, recordedBy: userId },
    });

    // Auto-post cash transaction
    try {
      await this.postCashTransaction(transaction.id, companyId);
    } catch (e: unknown) {
      const err = e instanceof Error ? e.message : String(e);
      this.logger.warn(
        `Auto-post of cash transaction ${transaction.id} skipped: ${err}`,
      );
    }

    return { data: transaction };
  }

  async getCashBalance(companyId: string) {
    const userIds = await this.getUserIdsInCompany(companyId);

    const transactions = await this.prisma.cashTransaction.findMany({
      where: { recordedBy: { in: userIds } },
    });

    let totalReceipts = 0;
    let totalPayments = 0;

    transactions.forEach((t) => {
      if (t.type === 'RECEIPT') {
        totalReceipts += Number(t.amount);
      } else {
        totalPayments += Number(t.amount);
      }
    });

    return {
      data: { totalReceipts, totalPayments, balance: totalReceipts - totalPayments },
    };
  }

  // ═══════════════════════════════════════════
  // ========== TRIAL BALANCE ==========
  // ═══════════════════════════════════════════

  async getTrialBalance(companyId: string) {
    const accounts = await this.prisma.chartOfAccount.findMany({
      where: { companyId },
      include: {
        journalLines: {
          select: { debit: true, credit: true },
        },
      },
    });

    const trialBalance = accounts.map((account) => {
      const totalDebit = account.journalLines.reduce(
        (sum, je) => sum + Number(je.debit),
        0,
      );
      const totalCredit = account.journalLines.reduce(
        (sum, je) => sum + Number(je.credit),
        0,
      );

      return {
        code: account.code,
        nameAr: account.nameAr,
        nameEn: account.nameEn,
        type: account.type,
        debit: totalDebit,
        credit: totalCredit,
      };
    });

    const grandTotalDebit = trialBalance.reduce((sum, a) => sum + a.debit, 0);
    const grandTotalCredit = trialBalance.reduce(
      (sum, a) => sum + a.credit,
      0,
    );

    return {
      data: { accounts: trialBalance, grandTotalDebit, grandTotalCredit },
    };
  }

  // ═══════════════════════════════════════════
  // 1. AUTO-POSTING: SALE INVOICE
  // ═══════════════════════════════════════════
  async postSaleInvoice(invoiceId: string, companyId: string) {
    const invoice = await this.prisma.salesInvoice.findFirst({
      where: { id: invoiceId },
      include: { lines: true, customer: true },
    });

    if (!invoice) throw new NotFoundException('Invoice not found');

    const subtotal = Number(invoice.subtotal);
    const taxAmount = Number(invoice.taxAmount);
    const totalAmount = Number(invoice.totalAmount);

    const arAccount = await this.getAccountByCode(companyId, COA.ACCOUNTS_RECEIVABLE);
    const salesAccount = await this.getAccountByCode(companyId, COA.SALES_REVENUE);
    const vatAccount = await this.getAccountByCode(companyId, COA.VAT_PAYABLE);

    const entry = await this.createJournalEntryAtomic(companyId, {
      description: `Sale Invoice ${invoice.invoiceNumber} - ${invoice.customer?.name ?? 'Customer'}`,
      lines: [
        {
          accountId: arAccount.id,
          debit: totalAmount,
          credit: 0,
          description: `AR for Invoice ${invoice.invoiceNumber}`,
        },
        {
          accountId: salesAccount.id,
          debit: 0,
          credit: subtotal,
          description: `Sales Revenue ${invoice.invoiceNumber}`,
        },
        {
          accountId: vatAccount.id,
          debit: 0,
          credit: taxAmount,
          description: `VAT on Invoice ${invoice.invoiceNumber}`,
        },
      ],
    });

    this.logger.log(`Sale invoice ${invoice.invoiceNumber} posted to journal`);
    return { data: { journalEntryId: entry.id, entryNumber: entry.entryNumber, totalAmount } };
  }

  // ═══════════════════════════════════════════
  // 2. AUTO-POSTING: PURCHASE ORDER
  // ═══════════════════════════════════════════
  async postPurchaseOrder(poId: string, companyId: string) {
    const po = await this.prisma.purchaseOrder.findFirst({
      where: { id: poId },
      include: { lines: true, supplier: true },
    });

    if (!po) throw new NotFoundException('Purchase order not found');

    // Calculate subtotal and tax from lines since PO only stores totalAmount
    const subtotal = po.lines.reduce((sum, line) => sum + Number(line.totalPrice), 0);
    const totalAmount = Number(po.totalAmount);
    const taxAmount = totalAmount - subtotal;

    const inventoryAccount = await this.getAccountByCode(companyId, COA.INVENTORY);
    const inputVatAccount = await this.getAccountByCode(companyId, COA.INPUT_VAT);
    const apAccount = await this.getAccountByCode(companyId, COA.ACCOUNTS_PAYABLE);

    const entry = await this.createJournalEntryAtomic(companyId, {
      description: `Purchase Order ${po.orderNumber} - ${po.supplier?.name ?? 'Supplier'}`,
      lines: [
        {
          accountId: inventoryAccount.id,
          debit: subtotal,
          credit: 0,
          description: `Inventory received PO ${po.orderNumber}`,
        },
        {
          accountId: inputVatAccount.id,
          debit: taxAmount,
          credit: 0,
          description: `Input VAT on PO ${po.orderNumber}`,
        },
        {
          accountId: apAccount.id,
          debit: 0,
          credit: totalAmount,
          description: `AP for PO ${po.orderNumber}`,
        },
      ],
    });

    this.logger.log(`Purchase order ${po.orderNumber} posted to journal`);
    return { data: { journalEntryId: entry.id, entryNumber: entry.entryNumber, totalAmount } };
  }

  // ═══════════════════════════════════════════
  // 3. AUTO-POSTING: STOCK MOVEMENT
  // ═══════════════════════════════════════════
  async postStockMovement(movementId: string, companyId: string) {
    const movement = await this.prisma.stockMovement.findFirst({
      where: { id: movementId },
      include: { product: { include: { unit: true } } },
    });

    if (!movement) throw new NotFoundException('Stock movement not found');

    const type = movement.type; // RECEIPT, ISSUE, TRANSFER, ADJUSTMENT, etc.
    const unitCost = Number(movement.unitCost ?? 0);
    const value = Number(movement.quantity) * unitCost;

    const inventoryAccount = await this.getAccountByCode(companyId, COA.INVENTORY);
    const cogsAccount = await this.getAccountByCode(companyId, COA.COGS);
    const apAccount = await this.getAccountByCode(companyId, COA.ACCOUNTS_PAYABLE);

    let lines: { accountId: string; debit: number; credit: number; description?: string }[] = [];
    let description = '';

    const unitName = movement.product?.unit?.name ?? 'units';
    const productName = movement.product?.name ?? 'Product';

    switch (type) {
      case 'ISSUE':
        description = `Inventory issue: ${productName} (${movement.quantity} ${unitName})`;
        lines = [
          {
            accountId: cogsAccount.id,
            debit: value,
            credit: 0,
            description: `COGS for ${productName}`,
          },
          {
            accountId: inventoryAccount.id,
            debit: 0,
            credit: value,
            description: `Inventory issue ${productName}`,
          },
        ];
        break;

      case 'RECEIPT':
        description = `Inventory receipt: ${productName} (${movement.quantity} ${unitName})`;
        lines = [
          {
            accountId: inventoryAccount.id,
            debit: value,
            credit: 0,
            description: `Inventory receipt ${productName}`,
          },
          {
            accountId: apAccount.id,
            debit: 0,
            credit: value,
            description: `AP for inventory receipt`,
          },
        ];
        break;

      case 'TRANSFER':
        description = `Inventory transfer: ${productName} (${movement.quantity} ${unitName})`;
        // Transfer: debit inventory destination, credit inventory source
        // Since we use single inventory account, it's a wash within the same account
        lines = [
          {
            accountId: inventoryAccount.id,
            debit: value,
            credit: 0,
            description: `Inventory to destination`,
          },
          {
            accountId: inventoryAccount.id,
            debit: 0,
            credit: value,
            description: `Inventory from source`,
          },
        ];
        break;

      case 'ADJUSTMENT':
        description = `Inventory adjustment: ${productName}`;
        if (value >= 0) {
          lines = [
            {
              accountId: inventoryAccount.id,
              debit: value,
              credit: 0,
              description: `Inventory adjustment (+)`,
            },
            {
              accountId: cogsAccount.id,
              debit: 0,
              credit: value,
              description: `COGS adjustment offset`,
            },
          ];
        } else {
          lines = [
            {
              accountId: cogsAccount.id,
              debit: Math.abs(value),
              credit: 0,
              description: `COGS adjustment offset`,
            },
            {
              accountId: inventoryAccount.id,
              debit: 0,
              credit: Math.abs(value),
              description: `Inventory adjustment (-)`,
            },
          ];
        }
        break;

      default:
        throw new BadRequestException(`Unsupported movement type: ${type}`);
    }

    const entry = await this.createJournalEntryAtomic(companyId, {
      description,
      lines,
    });

    this.logger.log(`Stock movement ${movementId} (${type}) posted to journal`);
    return { data: { journalEntryId: entry.id, entryNumber: entry.entryNumber, type, value: Math.abs(value) } };
  }

  // ═══════════════════════════════════════════
  // 4. AUTO-POSTING: CASH TRANSACTION
  // ═══════════════════════════════════════════
  async postCashTransaction(txnId: string, companyId: string) {
    const txn = await this.prisma.cashTransaction.findFirst({
      where: { id: txnId },
    });

    if (!txn) throw new NotFoundException('Cash transaction not found');

    const amount = Number(txn.amount);
    const type = txn.type; // RECEIPT, PAYMENT

    const cashAccount = await this.getAccountByCode(companyId, COA.CASH);
    const arAccount = await this.getAccountByCode(companyId, COA.ACCOUNTS_RECEIVABLE);
    const apAccount = await this.getAccountByCode(companyId, COA.ACCOUNTS_PAYABLE);

    let lines: { accountId: string; debit: number; credit: number; description?: string }[] = [];
    let description = '';

    switch (type) {
      case 'RECEIPT':
        description = `Cash receipt: ${txn.description ?? 'Receipt'} (${amount})`;
        lines = [
          {
            accountId: cashAccount.id,
            debit: amount,
            credit: 0,
            description: `Cash received`,
          },
          {
            accountId: arAccount.id,
            debit: 0,
            credit: amount,
            description: `Collection from receivables`,
          },
        ];
        break;

      case 'PAYMENT':
        description = `Cash payment: ${txn.description ?? 'Payment'} (${amount})`;
        lines = [
          {
            accountId: apAccount.id,
            debit: amount,
            credit: 0,
            description: `Payment to payables`,
          },
          {
            accountId: cashAccount.id,
            debit: 0,
            credit: amount,
            description: `Cash paid`,
          },
        ];
        break;

      default:
        throw new BadRequestException(`Unsupported cash transaction type: ${type}`);
    }

    const entry = await this.createJournalEntryAtomic(companyId, {
      description,
      lines,
    });

    this.logger.log(`Cash transaction ${txnId} (${type}) posted to journal`);
    return { data: { journalEntryId: entry.id, entryNumber: entry.entryNumber, type, amount } };
  }

  // ═══════════════════════════════════════════
  // 5a. FINANCIAL STATEMENT: INCOME STATEMENT
  // ═══════════════════════════════════════════
  async generateIncomeStatement(
    companyId: string,
    startDate: Date,
    endDate: Date,
  ) {
    // Revenue: accounts 4101-4199
    const revenue = await this.sumByAccountCodeRange(
      companyId, '41', startDate, endDate,
    );

    // COGS: accounts 5101-5199
    const cogs = await this.sumByAccountCodeRange(
      companyId, '51', startDate, endDate,
    );

    // Operating Expenses: 5201-5299 (admin) + 5301-5399 (selling)
    const adminExpenses = await this.sumByAccountCodeRange(
      companyId, '52', startDate, endDate,
    );
    const sellingExpenses = await this.sumByAccountCodeRange(
      companyId, '53', startDate, endDate,
    );
    const operatingExpenses = adminExpenses + sellingExpenses;

    // Finance Costs: 5401-5499
    const financeCosts = await this.sumByAccountCodeRange(
      companyId, '54', startDate, endDate,
    );

    const grossProfit = revenue - cogs;
    const grossMarginPct = revenue > 0 ? (grossProfit / revenue) * 100 : 0;

    const operatingIncome = grossProfit - operatingExpenses;
    const netIncome = operatingIncome - financeCosts;
    const netMarginPct = revenue > 0 ? (netIncome / revenue) * 100 : 0;

    return {
      data: {
        period: { startDate, endDate },
        revenue: this.round(revenue),
        cogs: this.round(cogs),
        grossProfit: this.round(grossProfit),
        grossMarginPct: this.round(grossMarginPct),
        operatingExpenses: {
          total: this.round(operatingExpenses),
          administrative: this.round(adminExpenses),
          selling: this.round(sellingExpenses),
        },
        operatingIncome: this.round(operatingIncome),
        financeCosts: this.round(financeCosts),
        netIncome: this.round(netIncome),
        netMarginPct: this.round(netMarginPct),
      },
    };
  }

  // ═══════════════════════════════════════════
  // 5b. FINANCIAL STATEMENT: BALANCE SHEET
  // ═══════════════════════════════════════════
  async generateBalanceSheet(companyId: string, asOfDate: Date) {
    // All ASSET accounts (1100-1999)
    const allAssetAccounts = await this.prisma.chartOfAccount.findMany({
      where: {
        companyId,
        type: 'ASSET',
        code: { gte: '1100', lte: '1999' },
      },
      select: {
        id: true, code: true, nameAr: true, nameEn: true, type: true,
        balance: true,
      },
    });

    // All LIABILITY accounts (2100-2999)
    const allLiabilityAccounts = await this.prisma.chartOfAccount.findMany({
      where: {
        companyId,
        type: 'LIABILITY',
        code: { gte: '2100', lte: '2999' },
      },
      select: {
        id: true, code: true, nameAr: true, nameEn: true, type: true,
        balance: true,
      },
    });

    // All EQUITY accounts (3100-3999)
    const allEquityAccounts = await this.prisma.chartOfAccount.findMany({
      where: {
        companyId,
        type: 'EQUITY',
        code: { gte: '3100', lte: '3999' },
      },
      select: {
        id: true, code: true, nameAr: true, nameEn: true, type: true,
        balance: true,
      },
    });

    // Calculate balances from journal entries up to asOfDate
    const calculateBalance = async (accounts: typeof allAssetAccounts) => {
      let total = 0;
      const details: {
        code: string;
        nameAr: string;
        nameEn: string | null;
        balance: number;
      }[] = [];

      for (const acct of accounts) {
        const lines = await this.prisma.journalEntryLine.findMany({
          where: {
            accountId: acct.id,
            entry: {
              companyId,
              status: JournalStatus.POSTED,
              date: { lte: asOfDate },
            },
          },
          select: { debit: true, credit: true },
        });

        const debitSum = lines.reduce((s, l) => s + Number(l.debit), 0);
        const creditSum = lines.reduce((s, l) => s + Number(l.credit), 0);

        let balance = 0;
        if (acct.type === 'ASSET' || acct.type === 'EXPENSE') {
          balance = debitSum - creditSum;
        } else {
          balance = creditSum - debitSum;
        }

        total += balance;
        details.push({
          code: acct.code,
          nameAr: acct.nameAr,
          nameEn: acct.nameEn,
          balance: this.round(balance),
        });
      }

      return { total: this.round(total), details };
    };

    const assets = await calculateBalance(allAssetAccounts);
    const liabilities = await calculateBalance(allLiabilityAccounts);
    const equity = await calculateBalance(allEquityAccounts);

    const currentAssets = assets.details
      .reduce((s, d) => s + d.balance, 0);
    const fixedAssets = 0; // Fixed asset tracking not yet implemented - reserved for v2

    const currentLiabilities = liabilities.details
      .reduce((s, d) => s + d.balance, 0);
    const longTermLiabilities = 0; // Long-term liability tracking not yet implemented - reserved for v2

    const totalLiabilitiesAndEquity = liabilities.total + equity.total;
    const balanced = Math.abs(assets.total - totalLiabilitiesAndEquity) < 0.01;

    return {
      data: {
        asOfDate,
        assets: {
          total: this.round(assets.total),
          currentAssets: this.round(currentAssets),
          fixedAssets: this.round(fixedAssets),
          details: assets.details,
        },
        liabilities: {
          total: this.round(liabilities.total),
          currentLiabilities: this.round(currentLiabilities),
          longTermLiabilities: this.round(longTermLiabilities),
          details: liabilities.details,
        },
        equity: {
          total: this.round(equity.total),
          details: equity.details,
        },
        totalLiabilitiesAndEquity: this.round(totalLiabilitiesAndEquity),
        balanced,
        imbalance: balanced ? 0 : this.round(Math.abs(assets.total - totalLiabilitiesAndEquity)),
      },
    };
  }

  // ═══════════════════════════════════════════
  // 5c. FINANCIAL STATEMENT: CASH FLOW
  // ═══════════════════════════════════════════
  async generateCashFlow(
    companyId: string,
    startDate: Date,
    endDate: Date,
  ) {
    const cashAccount = await this.prisma.chartOfAccount.findFirst({
      where: { companyId, code: COA.CASH },
      select: { id: true },
    });

    const cashAccountId = cashAccount?.id;

    // Beginning balance: sum of all cash entries before startDate
    let beginningBalance = 0;
    if (cashAccountId) {
      const priorEntries = await this.prisma.journalEntryLine.findMany({
        where: {
          accountId: cashAccountId,
          entry: {
            companyId,
            status: JournalStatus.POSTED,
            date: { lt: startDate },
          },
        },
        select: { debit: true, credit: true },
      });
      beginningBalance = priorEntries.reduce(
        (s, e) => s + Number(e.debit) - Number(e.credit),
        0,
      );
    }

    // Operating activities: cash from/to receivables, payables, revenue, cogs
    const cashReceipts = await this.getCashFlowByAccountCode(
      companyId, startDate, endDate, COA.CASH, 'debit',
    );
    const cashPayments = await this.getCashFlowByAccountCode(
      companyId, startDate, endDate, COA.CASH, 'credit',
    );

    const operating = cashReceipts - cashPayments;

    // Investing activities: fixed asset purchases/sales (using inventory movements for now)
    const investing = 0; // Fixed asset module tracking not yet implemented - reserved for v2

    // Financing activities: loans, equity
    const financing = 0; // Loans/equity module tracking not yet implemented - reserved for v2

    const netChange = operating + investing + financing;
    const endingBalance = beginningBalance + netChange;

    return {
      data: {
        period: { startDate, endDate },
        operating: {
          netCash: this.round(operating),
          cashReceipts: this.round(cashReceipts),
          cashPayments: this.round(cashPayments),
        },
        investing: {
          netCash: this.round(investing),
        },
        financing: {
          netCash: this.round(financing),
        },
        netChange: this.round(netChange),
        beginningBalance: this.round(beginningBalance),
        endingBalance: this.round(endingBalance),
      },
    };
  }

  private async getCashFlowByAccountCode(
    companyId: string,
    startDate: Date,
    endDate: Date,
    code: string,
    direction: 'debit' | 'credit',
  ) {
    const account = await this.prisma.chartOfAccount.findFirst({
      where: { companyId, code },
      select: { id: true },
    });

    if (!account) return 0;

    const lines = await this.prisma.journalEntryLine.findMany({
      where: {
        accountId: account.id,
        ...(direction === 'debit' ? { debit: { gt: 0 } } : { credit: { gt: 0 } }),
        entry: {
          companyId,
          status: JournalStatus.POSTED,
          date: { gte: startDate, lte: endDate },
        },
      },
      select: { debit: true, credit: true },
    });

    return lines.reduce(
      (s, l) => s + Number(direction === 'debit' ? l.debit : l.credit),
      0,
    );
  }



  // ═══════════════════════════════════════════
  // 6. BANK RECONCILIATION ENGINE
  // ═══════════════════════════════════════════
  async reconcileBankAccount(
    accountId: string,
    companyId: string,
    statementDate: Date,
    statementBalance: number,
  ) {
    // Get the bank account
    const bankAccount = await this.prisma.bankAccount.findFirst({
      where: { id: accountId, companyId },
    });
    if (!bankAccount) throw new NotFoundException('Bank account not found');

    // Get all bank transactions up to statement date
    const bankTransactions = await this.prisma.bankTransaction.findMany({
      where: {
        accountId,
        date: { lte: statementDate },
      },
      orderBy: { date: 'asc' },
    });

    // Get all journal entries involving the CASH account up to statement date
    const cashAccount = await this.prisma.chartOfAccount.findFirst({
      where: { companyId, code: COA.CASH },
      select: { id: true },
    });

    const journalLines = await this.prisma.journalEntryLine.findMany({
      where: {
        accountId: cashAccount?.id ?? '',
        entry: {
          companyId,
          status: JournalStatus.POSTED,
          date: { lte: statementDate },
        },
      },
      include: {
        entry: {
          select: { id: true, entryNumber: true, date: true, description: true },
        },
        account: { select: { code: true, nameAr: true } },
      },
      orderBy: { entry: { date: 'asc' } },
    });

    // Build system entries list from journal lines
    const systemEntries: {
      journalEntryId: string;
      entryNumber: string;
      date: Date;
      amount: number;
      isDebit: boolean;
      description: string | null;
    }[] = [];

    for (const line of journalLines) {
      if (line.debit > 0 || line.credit > 0) {
        systemEntries.push({
          journalEntryId: line.entry.id,
          entryNumber: line.entry.entryNumber,
          date: line.entry.date,
          amount: Number(line.debit) > 0 ? Number(line.debit) : Number(line.credit),
          isDebit: Number(line.debit) > 0,
          description: line.entry.description,
        });
      }
    }

    // Match transactions to journal entries by amount (within 3-day window)
    const matched: {
      bankTransaction: typeof bankTransactions[0];
      journalEntry: typeof systemEntries[0];
      matchedBy: string;
      variance: number;
    }[] = [];
    const unmatchedBank = [...bankTransactions];
    const unmatchedSystem: typeof systemEntries = [];

    // Matching algorithm: amount-based with 3-day tolerance
    for (const sysEntry of systemEntries) {
      let matchedIdx = -1;

      for (let i = 0; i < unmatchedBank.length; i++) {
        const bt = unmatchedBank[i];
        const amountMatch = Math.abs(Number(bt.amount) - sysEntry.amount) < 0.01;

        // Check date within 3-day window
        const btDate = new Date(bt.date);
        const sysDate = new Date(sysEntry.date);
        const daysDiff = Math.abs(
          (btDate.getTime() - sysDate.getTime()) / (1000 * 60 * 60 * 24),
        );
        const dateMatch = daysDiff <= 3;

        if (amountMatch && dateMatch) {
          matchedIdx = i;
          break;
        }
      }

      if (matchedIdx >= 0) {
        const matchedBank = unmatchedBank[matchedIdx];
        matched.push({
          bankTransaction: matchedBank,
          journalEntry: sysEntry,
          matchedBy: 'amount+date',
          variance: Math.abs(Number(matchedBank.amount) - sysEntry.amount),
        });
        unmatchedBank.splice(matchedIdx, 1);
      } else {
        unmatchedSystem.push(sysEntry);
      }
    }

    // Calculate adjusted balance
    const bookBalance = systemEntries.reduce(
      (s, e) => s + (e.isDebit ? e.amount : -e.amount),
      0,
    );
    const adjustedBalance = statementBalance + unmatchedBank.reduce(
      (s, bt) => s + (bt.type === 'DEPOSIT' ? -Number(bt.amount) : Number(bt.amount)),
      0,
    );

    return {
      data: {
        bankAccountId: accountId,
        bankAccountName: bankAccount.bankName,
        statementDate,
        statementBalance: this.round(statementBalance),
        bookBalance: this.round(bookBalance),
        adjustedBalance: this.round(adjustedBalance),
        matched: matched.map((m) => ({
          transactionId: m.bankTransaction.id,
          journalEntryId: m.journalEntry.journalEntryId,
          amount: m.bankTransaction.amount,
          date: m.bankTransaction.date,
          description: m.bankTransaction.description || m.journalEntry.description,
          variance: this.round(m.variance),
        })),
        matchedCount: matched.length,
        unmatchedBank: unmatchedBank.map((bt) => ({
          id: bt.id,
          amount: bt.amount,
          date: bt.date,
          type: bt.type,
          description: bt.description,
        })),
        unmatchedBankCount: unmatchedBank.length,
        unmatchedSystem: unmatchedSystem.map((se) => ({
          journalEntryId: se.journalEntryId,
          entryNumber: se.entryNumber,
          amount: se.amount,
          date: se.date,
          description: se.description,
        })),
        unmatchedSystemCount: unmatchedSystem.length,
      },
    };
  }

  // ═══════════════════════════════════════════
  // 7. VAT/TAX CALCULATION (Egyptian 14% VAT)
  // ═══════════════════════════════════════════
  async calculateVAT(
    companyId: string,
    startDate: Date,
    endDate: Date,
  ) {
    // Output VAT: from sales invoices (scoped through branch → company)
    const salesInvoices = await this.prisma.salesInvoice.findMany({
      where: {
        status: { in: ['CONFIRMED', 'PAID', 'PARTIALLY_PAID'] },
        createdAt: { gte: startDate, lte: endDate },
        branch: { companyId },
      },
      select: { taxAmount: true, totalAmount: true, subtotal: true },
    });

    const outputVAT = salesInvoices.reduce(
      (s, inv) => s + Number(inv.taxAmount),
      0,
    );
    const totalSales = salesInvoices.reduce(
      (s, inv) => s + Number(inv.totalAmount),
      0,
    );

    // Input VAT: from purchase orders (scoped through branch → company)
    const purchaseOrders = await this.prisma.purchaseOrder.findMany({
      where: {
        status: { in: ['CONFIRMED', 'DELIVERED', 'PARTIALLY_PAID'] },
        createdAt: { gte: startDate, lte: endDate },
        branch: { companyId },
      },
      include: { lines: true },
    });

    // Calculate VAT from PO lines (totalAmount - sum of line totals)
    let inputVAT = 0;
    let totalPurchases = 0;
    for (const po of purchaseOrders) {
      const linesTotal = po.lines.reduce((sum, line) => sum + Number(line.totalPrice), 0);
      totalPurchases += Number(po.totalAmount);
      inputVAT += Number(po.totalAmount) - linesTotal;
    }

    const netVATPayable = outputVAT - inputVAT;

    return {
      data: {
        period: { startDate, endDate },
        outputVAT: {
          totalVAT: this.round(outputVAT),
          totalSales: this.round(totalSales),
          invoiceCount: salesInvoices.length,
        },
        inputVAT: {
          totalVAT: this.round(inputVAT),
          totalPurchases: this.round(totalPurchases),
          orderCount: purchaseOrders.length,
        },
        netVATPayable: this.round(netVATPayable),
        vatRate: VAT_RATE * 100,
        summary: netVATPayable >= 0
          ? `Net VAT payable to government: ${this.round(Math.abs(netVATPayable))}`
          : `Net VAT refundable from government: ${this.round(Math.abs(netVATPayable))}`,
      },
    };
  }

  // ═══════════════════════════════════════════
  // HELPER: round to 2 decimals
  // ═══════════════════════════════════════════
  private round(value: number): number {
    return Math.round(value * 100) / 100;
  }
}
