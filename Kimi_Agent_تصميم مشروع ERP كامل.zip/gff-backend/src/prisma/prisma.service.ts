import {
  Injectable,
  OnModuleInit,
  OnModuleDestroy,
  Logger,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService
  extends PrismaClient
  implements OnModuleInit, OnModuleDestroy
{
  private readonly logger = new Logger(PrismaService.name);

  constructor() {
    super({
      log: [
        { emit: 'event', level: 'query' },
        { emit: 'stdout', level: 'info' },
        { emit: 'stdout', level: 'warn' },
        { emit: 'stdout', level: 'error' },
      ],
    });
  }

  async onModuleInit() {
    await this.$connect();
    this.logger.log('Connected to database successfully');

    this.$on('query' as never, (event: any) => {
      const duration = event.duration;
      if (duration && parseInt(duration) > 1000) {
        this.logger.warn(
          `Slow query detected (${duration}ms): ${event.query}`,
        );
      }
    });

    this.$on('error' as never, (event: any) => {
      this.logger.error(`Database error: ${event.message}`);
    });
  }

  async onModuleDestroy() {
    await this.$disconnect();
    this.logger.log('Disconnected from database');
  }

  async cleanDatabase() {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Cannot clean database in production');
    }
    const models = Object.keys(this).filter(
      (key) =>
        !key.startsWith('$') &&
        !key.startsWith('_') &&
        typeof (this as any)[key] === 'object',
    );
    for (const model of models) {
      await (this as any)[model].deleteMany().catch(() => null);
    }
  }
}
