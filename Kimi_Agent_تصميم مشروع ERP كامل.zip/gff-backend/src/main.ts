import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import helmet from 'helmet';
import * as compression from 'compression';
import { AppModule } from './app.module';
import { HttpExceptionFilter, AllExceptionsFilter } from './common/filters';
import { PrismaExceptionFilter } from './common/filters';
import { TimingInterceptor } from './common/interceptors';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log', 'verbose'],
  });

  const configService = app.get(ConfigService);
  const port = configService.get<number>('PORT', 3000);
  const frontendUrl = configService.get<string>('FRONTEND_URL', 'http://localhost:3001');
  const apiPrefix = configService.get<string>('API_PREFIX', '/api/v1');
  const nodeEnv = configService.get<string>('NODE_ENV', 'development');

  // Security
  app.use(helmet({
    contentSecurityPolicy: nodeEnv === 'production' ? undefined : false,
  }));

  // Compression
  app.use(compression());

  // CORS
  app.enableCors({
    origin: [frontendUrl, 'http://localhost:3000', 'http://localhost:3001'],
    credentials: true,
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    allowedHeaders: 'Content-Type, Accept, Authorization, X-Request-ID',
  });

  // API Versioning
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: '1',
    prefix: 'api/v',
  });

  // Global prefix
  app.setGlobalPrefix('api/v1');

  // Validation
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: {
        enableImplicitConversion: true,
      },
    }),
  );

  // Global filters
  app.useGlobalFilters(
    new AllExceptionsFilter(),
    new HttpExceptionFilter(),
    new PrismaExceptionFilter(),
  );

  // Timing interceptor
  app.useGlobalInterceptors(new TimingInterceptor());

  // Swagger API Docs
  const swaggerConfig = new DocumentBuilder()
    .setTitle('GFF ERP API')
    .setDescription('GFF Enterprise Resource Planning API - Complete backend for feed & livestock management')
    .setVersion('1.0.0')
    .addBearerAuth(
      {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        name: 'JWT',
        description: 'Enter JWT access token',
        in: 'header',
      },
      'JWT',
    )
    .addTag('Authentication', 'Auth endpoints')
    .addTag('Users', 'User management')
    .addTag('Branches', 'Branch management')
    .addTag('Warehouses', 'Warehouse & stock locations')
    .addTag('Products', 'Product catalog & pricing')
    .addTag('Customers', 'Customer management & debt tracking')
    .addTag('Suppliers', 'Supplier management & evaluation')
    .addTag('Sales', 'Invoices, returns & quotes')
    .addTag('Purchases', 'Purchase orders')
    .addTag('Inventory', 'Stock movements, transfers & adjustments')
    .addTag('Delivery', 'Delivery workflow management')
    .addTag('Fleet', 'Vehicles, drivers & maintenance')
    .addTag('HR', 'Employees, attendance, payroll & leaves')
    .addTag('Accounting', 'Chart of accounts, journal entries & treasury')
    .addTag('Production', 'Production orders & batch management')
    .addTag('Feed', 'Feed formulas & ingredients')
    .addTag('Livestock', 'Livestock batches & daily records')
    .addTag('Reports', 'Financial, inventory & sales reports')
    .addTag('Settings', 'Company & system settings')
    .addTag('AI Copilot', 'Natural language queries')
    .addTag('WhatsApp', 'WhatsApp Business API integration')
    .build();

  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup('api/docs', app, document, {
    swaggerOptions: {
      persistAuthorization: true,
      docExpansion: 'none',
      filter: true,
      displayRequestDuration: true,
    },
    customSiteTitle: 'GFF ERP API Documentation',
  });

  await app.listen(port);

  console.log(`
========================================
  GFF ERP Backend Server
========================================
  Environment:  ${nodeEnv}
  Port:         ${port}
  API Prefix:   ${apiPrefix}
  Swagger:      http://localhost:${port}/api/docs
  Frontend:     ${frontendUrl}
========================================
  `);
}

bootstrap();
