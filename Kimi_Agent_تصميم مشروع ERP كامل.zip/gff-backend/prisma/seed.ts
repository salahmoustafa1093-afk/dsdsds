import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('Starting database seed...');

  // Create company
  const company = await prisma.company.create({
    data: {
      name: 'GFF Demo Company',
      email: 'admin@gff.demo',
      phone: '+962799000000',
      address: 'Amman, Jordan',
      city: 'Amman',
      country: 'JO',
      taxNumber: '123456789',
    },
  });

  console.log(`Created company: ${company.name}`);

  // Create super admin role
  const adminRole = await prisma.role.create({
    data: {
      name: 'super_admin',
      description: 'Super Administrator with full system access',
      permissions: ['*'],
      isSystem: true,
      companyId: company.id,
    },
  });

  // Create manager role
  const managerRole = await prisma.role.create({
    data: {
      name: 'branch_manager',
      description: 'Branch Manager',
      permissions: ['sales.read', 'sales.write', 'inventory.read', 'inventory.write', 'delivery.read', 'delivery.write'],
      companyId: company.id,
    },
  });

  // Create salesperson role
  const salesRole = await prisma.role.create({
    data: {
      name: 'salesperson',
      description: 'Sales Representative',
      permissions: ['sales.read', 'sales.write', 'customers.read', 'customers.write'],
      companyId: company.id,
    },
  });

  // Create warehouse role
  const warehouseRole = await prisma.role.create({
    data: {
      name: 'warehouse_staff',
      description: 'Warehouse Staff',
      permissions: ['inventory.read', 'inventory.write', 'products.read'],
      companyId: company.id,
    },
  });

  // Create admin user
  const hashedPassword = await bcrypt.hash('Admin@123', 12);
  const adminUser = await prisma.user.create({
    data: {
      name: 'System Administrator',
      email: 'admin@gff.demo',
      password: hashedPassword,
      phone: '+962799000001',
      companyId: company.id,
      roleId: adminRole.id,
      status: 'ACTIVE',
      emailVerified: true,
    },
  });

  console.log(`Created admin user: ${adminUser.email} (password: Admin@123)`);

  // Create branch
  const branch = await prisma.branch.create({
    data: {
      name: 'Amman Main Branch',
      code: 'AMM-01',
      address: 'King Hussein Business Park',
      city: 'Amman',
      phone: '+96265551000',
      email: 'amman@gff.demo',
      managerName: 'Ahmad Khalil',
      isActive: true,
      companyId: company.id,
    },
  });

  console.log(`Created branch: ${branch.name}`);

  // Create warehouse
  const warehouse = await prisma.warehouse.create({
    data: {
      name: 'Main Warehouse',
      code: 'WH-MAIN',
      type: 'MAIN',
      address: 'Industrial Area, St. 5',
      capacity: 10000,
      isActive: true,
      companyId: company.id,
      branchId: branch.id,
    },
  });

  console.log(`Created warehouse: ${warehouse.name}`);

  // Create product categories
  const feedCategory = await prisma.productCategory.create({
    data: {
      name: 'Animal Feed',
      description: 'All types of animal feed products',
      companyId: company.id,
    },
  });

  const supplementCategory = await prisma.productCategory.create({
    data: {
      name: 'Feed Supplements',
      description: 'Vitamins, minerals, and additives',
      companyId: company.id,
    },
  });

  // Create unit
  const kgUnit = await prisma.unit.create({
    data: {
      name: 'Kilogram',
      code: 'KG',
      conversion: 1,
      companyId: company.id,
    },
  });

  const tonUnit = await prisma.unit.create({
    data: {
      name: 'Ton',
      code: 'TON',
      conversion: 1000,
      companyId: company.id,
    },
  });

  // Create products
  const products = await Promise.all([
    prisma.product.create({
      data: {
        name: 'Organic Chicken Feed 25kg',
        sku: 'FEED-ORG-25',
        description: 'Premium organic chicken feed for layers',
        type: 'FINISHED',
        costPrice: 15.5,
        salePrice: 22.0,
        minStock: 100,
        maxStock: 5000,
        isActive: true,
        companyId: company.id,
        categoryId: feedCategory.id,
        unitId: kgUnit.id,
      },
    }),
    prisma.product.create({
      data: {
        name: 'Broiler Starter Feed',
        sku: 'FEED-BRS-50',
        description: 'High-protein starter feed for broiler chicks',
        type: 'FINISHED',
        costPrice: 18.0,
        salePrice: 25.5,
        minStock: 50,
        maxStock: 3000,
        isActive: true,
        companyId: company.id,
        categoryId: feedCategory.id,
        unitId: kgUnit.id,
      },
    }),
    prisma.product.create({
      data: {
        name: 'Vitamin Mineral Premix',
        sku: 'SUPP-VMP-10',
        description: 'Essential vitamin and mineral premix',
        type: 'RAW_MATERIAL',
        costPrice: 45.0,
        salePrice: 60.0,
        minStock: 20,
        maxStock: 500,
        isActive: true,
        companyId: company.id,
        categoryId: supplementCategory.id,
        unitId: kgUnit.id,
      },
    }),
  ]);

  console.log(`Created ${products.length} products`);

  // Create initial stock
  for (const product of products) {
    await prisma.stock.create({
      data: {
        productId: product.id,
        warehouseId: warehouse.id,
        quantity: 500,
      },
    });
  }

  // Create customer
  const customer = await prisma.customer.create({
    data: {
      name: 'Al-Shamal Poultry Farm',
      code: 'CUST-001',
      email: 'info@shamalpoultry.com',
      phone: '+962799111222',
      address: 'Airport Road, Building 15',
      city: 'Amman',
      creditLimit: 10000,
      paymentTerms: 30,
      isActive: true,
      companyId: company.id,
    },
  });

  console.log(`Created customer: ${customer.name}`);

  // Create supplier
  const supplier = await prisma.supplier.create({
    data: {
      name: 'Golden Feed Supplies Co.',
      code: 'SUP-001',
      email: 'sales@goldenfeed.com',
      phone: '+96265551000',
      address: 'Industrial Area, St. 20',
      city: 'Amman',
      contactName: 'Mohammad Ali',
      isActive: true,
      companyId: company.id,
    },
  });

  console.log(`Created supplier: ${supplier.name}`);

  // Create employee
  const employee = await prisma.employee.create({
    data: {
      employeeCode: 'EMP-001',
      firstName: 'Ahmad',
      lastName: 'Khalil',
      email: 'ahmad@company.com',
      phone: '+962799333444',
      hireDate: new Date('2023-01-15'),
      department: 'SALES',
      position: 'Sales Manager',
      salary: 1200,
      status: 'ACTIVE',
      companyId: company.id,
      branchId: branch.id,
    },
  });

  console.log(`Created employee: ${employee.firstName} ${employee.lastName}`);

  // Create chart of accounts
  const accounts = await Promise.all([
    prisma.account.create({ data: { code: '1100', name: 'Cash on Hand', type: 'ASSET', category: 'Current Assets', companyId: company.id } }),
    prisma.account.create({ data: { code: '1200', name: 'Accounts Receivable', type: 'ASSET', category: 'Current Assets', companyId: company.id } }),
    prisma.account.create({ data: { code: '1300', name: 'Inventory', type: 'ASSET', category: 'Current Assets', companyId: company.id } }),
    prisma.account.create({ data: { code: '2100', name: 'Accounts Payable', type: 'LIABILITY', category: 'Current Liabilities', companyId: company.id } }),
    prisma.account.create({ data: { code: '4000', name: 'Sales Revenue', type: 'REVENUE', category: 'Operating Revenue', companyId: company.id } }),
    prisma.account.create({ data: { code: '5000', name: 'Cost of Goods Sold', type: 'EXPENSE', category: 'Direct Costs', companyId: company.id } }),
  ]);

  console.log(`Created ${accounts.length} chart of accounts`);

  console.log('\nSeed completed successfully!');
  console.log('Login credentials:');
  console.log('  Email: admin@gff.demo');
  console.log('  Password: Admin@123');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
