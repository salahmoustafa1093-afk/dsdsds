-- ============================================================
-- GFF ERP Enterprise - Initial Migration
-- Created: 2025-08-20
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE "UserStatus" AS ENUM ('ACTIVE', 'INACTIVE', 'SUSPENDED', 'PENDING');
CREATE TYPE "UserRole" AS ENUM ('SUPER_ADMIN', 'ADMIN', 'BRANCH_MANAGER', 'ACCOUNTANT', 'SALES_REP', 'WAREHOUSE_MANAGER', 'PRODUCTION_MANAGER', 'HR_MANAGER', 'DRIVER');
CREATE TYPE "InvoiceStatus" AS ENUM ('DRAFT', 'CONFIRMED', 'PENDING', 'DELIVERED', 'PAID', 'PARTIALLY_PAID', 'OVERDUE', 'CANCELLED', 'RETURNED');
CREATE TYPE "PaymentMethod" AS ENUM ('CASH', 'CHEQUE', 'BANK_TRANSFER', 'CREDIT_CARD', 'INSTALLMENT');
CREATE TYPE "SalesChannel" AS ENUM ('RETAIL', 'WHOLESALE', 'DISTRIBUTOR', 'EXPORT');
CREATE TYPE "MovementType" AS ENUM ('RECEIPT', 'ISSUE', 'TRANSFER', 'RETURN', 'ADJUSTMENT', 'WASTE', 'CONVERSION');
CREATE TYPE "DeliveryStatus" AS ENUM ('PENDING', 'CONFIRMED', 'APPROVED', 'PICKING', 'PICKED_LOADED', 'DRIVER_ASSIGNED', 'IN_TRANSIT', 'AT_CUSTOMER', 'DELIVERED', 'FAILED_CLOSED', 'PAYMENT_COLLECTED', 'CLOSED');
CREATE TYPE "VehicleStatus" AS ENUM ('ACTIVE', 'IN_MAINTENANCE', 'OUT_OF_SERVICE', 'SOLD');
CREATE TYPE "VehicleType" AS ENUM ('VAN', 'TRUCK_PICKUP', 'TRUCK_LIGHT', 'TRUCK_HEAVY', 'TRAILER', 'REFRIGERATED', 'TANKER');
CREATE TYPE "FuelType" AS ENUM ('DIESEL', 'GASOLINE');
CREATE TYPE "MaintenanceType" AS ENUM ('PREVENTIVE', 'CORRECTIVE', 'TIRE', 'ELECTRICAL', 'BODY');
CREATE TYPE "AnimalType" AS ENUM ('CATTLE', 'BUFFALO', 'SHEEP', 'GOAT', 'CAMEL');
CREATE TYPE "AnimalStatus" AS ENUM ('ACTIVE', 'GROWING', 'READY_FOR_SALE', 'SOLD', 'DECEASED');
CREATE TYPE "Gender" AS ENUM ('MALE', 'FEMALE');
CREATE TYPE "FeedType" AS ENUM ('STARTER', 'GROWER', 'FINISHER', 'LAYER', 'BROILER_FEED', 'CATTLE_FEED', 'SHEEP_FEED');
CREATE TYPE "EggGrade" AS ENUM ('EXTRA_LARGE', 'LARGE', 'MEDIUM', 'SMALL');
CREATE TYPE "AttendanceStatus" AS ENUM ('PRESENT', 'ABSENT', 'LATE', 'LEAVE', 'VACATION', 'HALF_DAY');
CREATE TYPE "LeaveType" AS ENUM ('ANNUAL', 'SICK', 'EMERGENCY', 'UNPAID', 'HAJJ', 'MATERNITY');
CREATE TYPE "JournalStatus" AS ENUM ('DRAFT', 'REVIEWED', 'APPROVED', 'POSTED', 'REVERSED');
CREATE TYPE "ProductType" AS ENUM ('RAW_MATERIAL', 'FINISHED_GOOD', 'SEMI_FINISHED', 'PACKAGING_SUPPLY', 'SERVICE');
CREATE TYPE "WarehouseType" AS ENUM ('MAIN', 'BRANCH', 'EXTERNAL');
CREATE TYPE "CustomerType" AS ENUM ('BREEDER', 'DISTRIBUTOR', 'WHOLESALER', 'COMPANY');
CREATE TYPE "SupplierType" AS ENUM ('LOCAL', 'IMPORTED', 'MANUFACTURER', 'TRADER');
CREATE TYPE "AccountType" AS ENUM ('ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE');
CREATE TYPE "BankAccountType" AS ENUM ('CURRENT', 'SAVINGS', 'DEPOSIT');
CREATE TYPE "BankTransactionType" AS ENUM ('DEPOSIT', 'WITHDRAWAL', 'TRANSFER');
CREATE TYPE "CashTransactionType" AS ENUM ('RECEIPT', 'PAYMENT');
CREATE TYPE "LeaveRequestStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED');
CREATE TYPE "CommissionStatus" AS ENUM ('PENDING', 'APPROVED', 'PAID', 'CANCELLED');
CREATE TYPE "PayrollStatus" AS ENUM ('DRAFT', 'APPROVED', 'PAID');
CREATE TYPE "NotificationType" AS ENUM ('INFO', 'WARNING', 'ERROR', 'SUCCESS');
CREATE TYPE "FeedFormulaStatus" AS ENUM ('DRAFT', 'ACTIVE', 'ARCHIVED');

-- ============================================================
-- COMPANIES & BRANCHES
-- ============================================================

CREATE TABLE "companies" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "tax_number" TEXT,
    "commercial_register" TEXT,
    "address" TEXT,
    "phone" TEXT,
    "email" TEXT,
    "logo" TEXT,
    "fiscal_year_start" DATE,
    "default_currency" TEXT NOT NULL DEFAULT 'EGP',
    "timezone" TEXT NOT NULL DEFAULT 'Africa/Cairo',
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "companies_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "branches" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "address" TEXT,
    "phone" TEXT,
    "manager_id" UUID,
    "parent_branch_id" UUID,
    "target_revenue" DECIMAL(18,2) DEFAULT 0,
    "actual_revenue" DECIMAL(18,2) DEFAULT 0,
    "employee_count" INT NOT NULL DEFAULT 0,
    "warehouse_count" INT NOT NULL DEFAULT 0,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "company_id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "branches_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "branches_code_key" UNIQUE ("code")
);

-- ============================================================
-- USERS & AUTH
-- ============================================================

CREATE TABLE "users" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "username" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "full_name" TEXT NOT NULL,
    "phone" TEXT,
    "avatar" TEXT,
    "role" "UserRole" NOT NULL DEFAULT 'SALES_REP',
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "company_id" UUID NOT NULL,
    "branch_id" UUID,
    "last_login" TIMESTAMPTZ,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "users_username_key" UNIQUE ("username"),
    CONSTRAINT "users_email_key" UNIQUE ("email")
);

CREATE TABLE "refresh_tokens" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "user_id" UUID NOT NULL,
    "token" TEXT NOT NULL,
    "expires_at" TIMESTAMPTZ NOT NULL,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "refresh_tokens_token_key" UNIQUE ("token")
);

CREATE TABLE "password_reset_tokens" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "user_id" UUID NOT NULL,
    "token" TEXT NOT NULL,
    "expires_at" TIMESTAMPTZ NOT NULL,
    "used" BOOLEAN NOT NULL DEFAULT FALSE,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "password_reset_tokens_token_key" UNIQUE ("token")
);

-- ============================================================
-- WAREHOUSE & INVENTORY
-- ============================================================

CREATE TABLE "warehouses" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" "WarehouseType" NOT NULL DEFAULT 'BRANCH',
    "capacity" DECIMAL(18,2),
    "branch_id" UUID NOT NULL,
    "manager_id" UUID,
    "address" TEXT,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "warehouses_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "warehouses_code_key" UNIQUE ("code")
);

CREATE TABLE "warehouse_locations" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "zone" TEXT NOT NULL,
    "aisle" TEXT NOT NULL,
    "rack" TEXT NOT NULL,
    "shelf" TEXT NOT NULL,
    "bin" TEXT NOT NULL,
    "warehouse_id" UUID NOT NULL,
    "barcode" TEXT,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',

    CONSTRAINT "warehouse_locations_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "warehouse_locations_barcode_key" UNIQUE ("barcode")
);

CREATE TABLE "units_of_measure" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "conversion_rate" DECIMAL(18,6) NOT NULL DEFAULT 1,
    "base_unit" TEXT,

    CONSTRAINT "units_of_measure_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "units_of_measure_code_key" UNIQUE ("code")
);

-- ============================================================
-- PRODUCT & CATALOG
-- ============================================================

CREATE TABLE "product_categories" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "type" "ProductType" NOT NULL DEFAULT 'FINISHED_GOOD',
    "parent_id" UUID,

    CONSTRAINT "product_categories_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "product_categories_code_key" UNIQUE ("code")
);

CREATE TABLE "products" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "category_id" UUID NOT NULL,
    "unit_id" UUID NOT NULL,
    "min_stock_level" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "max_stock_level" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "reorder_point" DECIMAL(18,3) NOT NULL DEFAULT 0,
    "avg_cost" DECIMAL(18,4) NOT NULL DEFAULT 0,
    "sale_price" DECIMAL(18,4) NOT NULL DEFAULT 0,
    "barcode" TEXT,
    "weight" DECIMAL(10,3),
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "company_id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "products_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "products_code_key" UNIQUE ("code"),
    CONSTRAINT "products_barcode_key" UNIQUE ("barcode")
);

CREATE TABLE "price_lists" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "product_id" UUID NOT NULL,
    "customer_category_id" UUID,
    "min_qty" INT NOT NULL DEFAULT 1,
    "max_qty" INT,
    "unit_price" DECIMAL(18,4) NOT NULL,
    "effective_from" TIMESTAMPTZ NOT NULL,
    "effective_to" TIMESTAMPTZ,

    CONSTRAINT "price_lists_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- CUSTOMER
-- ============================================================

CREATE TABLE "customer_categories" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "min_orders" INT NOT NULL DEFAULT 0,
    "min_amount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "color" TEXT NOT NULL DEFAULT '#4A90D9',
    "criteria" TEXT,

    CONSTRAINT "customer_categories_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "customers" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" "CustomerType" NOT NULL DEFAULT 'BREEDER',
    "phone" TEXT,
    "email" TEXT,
    "address" TEXT,
    "city" TEXT,
    "tax_number" TEXT,
    "credit_limit" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "current_balance" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "payment_terms" INT NOT NULL DEFAULT 30,
    "category_id" UUID,
    "branch_id" UUID NOT NULL,
    "sales_rep_id" UUID,
    "company_id" UUID NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "customers_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "customers_code_key" UNIQUE ("code")
);

-- ============================================================
-- SUPPLIER
-- ============================================================

CREATE TABLE "suppliers" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" "SupplierType" NOT NULL DEFAULT 'LOCAL',
    "phone" TEXT,
    "email" TEXT,
    "address" TEXT,
    "city" TEXT,
    "tax_number" TEXT,
    "rating" DECIMAL(3,2),
    "company_id" UUID NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "suppliers_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "suppliers_code_key" UNIQUE ("code")
);

CREATE TABLE "supplier_evaluations" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "supplier_id" UUID NOT NULL,
    "quality_score" INT NOT NULL,
    "price_score" INT NOT NULL,
    "delivery_score" INT NOT NULL,
    "service_score" INT NOT NULL,
    "reliability_score" INT NOT NULL,
    "overall_score" INT NOT NULL,
    "evaluated_by" UUID NOT NULL,
    "notes" TEXT,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "supplier_evaluations_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- SALES
-- ============================================================

CREATE TABLE "sales_invoices" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "invoice_number" TEXT NOT NULL,
    "customer_id" UUID NOT NULL,
    "branch_id" UUID NOT NULL,
    "sales_rep_id" UUID,
    "channel" "SalesChannel" NOT NULL DEFAULT 'RETAIL',
    "subtotal" DECIMAL(18,2) NOT NULL,
    "discount_amount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "tax_rate" DECIMAL(5,2) NOT NULL DEFAULT 14,
    "tax_amount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "total_amount" DECIMAL(18,2) NOT NULL,
    "paid_amount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "balance" DECIMAL(18,2) NOT NULL,
    "status" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
    "payment_method" "PaymentMethod",
    "delivery_status" "DeliveryStatus" NOT NULL DEFAULT 'PENDING',
    "notes" TEXT,
    "due_date" DATE,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "sales_invoices_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "sales_invoices_invoice_number_key" UNIQUE ("invoice_number")
);

CREATE TABLE "sales_invoice_lines" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "invoice_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "unit_price" DECIMAL(18,4) NOT NULL,
    "discount_percent" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "total_price" DECIMAL(18,2) NOT NULL,
    "warehouse_id" UUID,

    CONSTRAINT "sales_invoice_lines_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "sales_returns" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "return_number" TEXT NOT NULL,
    "original_invoice_id" UUID NOT NULL,
    "customer_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "unit_price" DECIMAL(18,4) NOT NULL,
    "total_amount" DECIMAL(18,2) NOT NULL,
    "reason" TEXT,
    "status" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "sales_returns_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "sales_returns_return_number_key" UNIQUE ("return_number")
);

-- ============================================================
-- PURCHASE
-- ============================================================

CREATE TABLE "purchase_orders" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "order_number" TEXT NOT NULL,
    "supplier_id" UUID NOT NULL,
    "branch_id" UUID NOT NULL,
    "total_amount" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "status" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
    "expected_date" DATE,
    "notes" TEXT,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "purchase_orders_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "purchase_orders_order_number_key" UNIQUE ("order_number")
);

CREATE TABLE "purchase_order_lines" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "order_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "unit_price" DECIMAL(18,4) NOT NULL,
    "total_price" DECIMAL(18,2) NOT NULL,
    "received_quantity" DECIMAL(18,3) NOT NULL DEFAULT 0,

    CONSTRAINT "purchase_order_lines_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- STOCK
-- ============================================================

CREATE TABLE "stock_movements" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "movement_number" TEXT NOT NULL,
    "type" "MovementType" NOT NULL,
    "product_id" UUID NOT NULL,
    "warehouse_id" UUID NOT NULL,
    "location_id" UUID,
    "quantity" DECIMAL(18,3) NOT NULL,
    "unit_cost" DECIMAL(18,4),
    "total_cost" DECIMAL(18,2),
    "reference_type" TEXT,
    "reference_id" TEXT,
    "batch_number" TEXT,
    "expiry_date" DATE,
    "notes" TEXT,
    "created_by" UUID NOT NULL,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "stock_movements_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "stock_movements_movement_number_key" UNIQUE ("movement_number")
);

CREATE TABLE "stock_adjustments" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "product_id" UUID NOT NULL,
    "warehouse_id" UUID NOT NULL,
    "expected_qty" DECIMAL(18,3) NOT NULL,
    "actual_qty" DECIMAL(18,3) NOT NULL,
    "variance" DECIMAL(18,3) NOT NULL,
    "reason" TEXT,
    "status" "InvoiceStatus" NOT NULL DEFAULT 'DRAFT',
    "approved_by" UUID,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "stock_adjustments_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "stock_transfers" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "transfer_number" TEXT NOT NULL,
    "from_warehouse_id" UUID NOT NULL,
    "to_warehouse_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "quantity" DECIMAL(18,3) NOT NULL,
    "status" "DeliveryStatus" NOT NULL DEFAULT 'PENDING',
    "requested_by" UUID NOT NULL,
    "approved_by" UUID,
    "from_branch_id" UUID,
    "to_branch_id" UUID,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "completed_at" TIMESTAMPTZ,

    CONSTRAINT "stock_transfers_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "stock_transfers_transfer_number_key" UNIQUE ("transfer_number")
);

-- ============================================================
-- DELIVERY & LOGISTICS
-- ============================================================

CREATE TABLE "delivery_orders" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "order_number" TEXT NOT NULL,
    "invoice_id" UUID NOT NULL,
    "customer_id" UUID NOT NULL,
    "branch_id" UUID NOT NULL,
    "driver_id" UUID,
    "vehicle_id" UUID,
    "route_id" UUID,
    "scheduled_date" TIMESTAMPTZ,
    "delivery_date" TIMESTAMPTZ,
    "customer_signature" TEXT,
    "photo_url" TEXT,
    "gps_coordinates" TEXT,
    "payment_collected" DECIMAL(18,2) DEFAULT 0,
    "payment_method" "PaymentMethod",
    "notes" TEXT,
    "status" "DeliveryStatus" NOT NULL DEFAULT 'PENDING',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "delivery_orders_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "delivery_orders_order_number_key" UNIQUE ("order_number")
);

CREATE TABLE "delivery_tracking" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "delivery_id" UUID NOT NULL,
    "timestamp" TIMESTAMPTZ NOT NULL,
    "latitude" DECIMAL(10,6) NOT NULL,
    "longitude" DECIMAL(10,6) NOT NULL,
    "status" "DeliveryStatus" NOT NULL,
    "notes" TEXT,

    CONSTRAINT "delivery_tracking_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "delivery_routes" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "start_point" TEXT NOT NULL,
    "end_point" TEXT NOT NULL,
    "waypoints" TEXT,
    "estimated_distance" DECIMAL(10,2),
    "estimated_time" INT,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "delivery_routes_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- VEHICLE & MAINTENANCE
-- ============================================================

CREATE TABLE "vehicles" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "plate_number" TEXT NOT NULL,
    "type" "VehicleType" NOT NULL DEFAULT 'TRUCK_LIGHT',
    "make" TEXT,
    "model" TEXT,
    "year" INT,
    "capacity" DECIMAL(10,2),
    "fuel_type" "FuelType" NOT NULL DEFAULT 'DIESEL',
    "mileage" DECIMAL(12,2) DEFAULT 0,
    "status" "VehicleStatus" NOT NULL DEFAULT 'ACTIVE',
    "branch_id" UUID NOT NULL,
    "company_id" UUID NOT NULL,
    "assigned_driver_id" UUID,
    "insurance_expiry" DATE,
    "license_expiry" DATE,
    "purchase_date" DATE,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "vehicles_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "vehicles_plate_number_key" UNIQUE ("plate_number")
);

CREATE TABLE "drivers" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "user_id" UUID NOT NULL,
    "license_number" TEXT NOT NULL,
    "license_expiry" DATE,
    "rating" DECIMAL(3,2),
    "total_trips" INT NOT NULL DEFAULT 0,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',

    CONSTRAINT "drivers_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "drivers_user_id_key" UNIQUE ("user_id")
);

CREATE TABLE "fuel_logs" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "vehicle_id" UUID NOT NULL,
    "driver_id" UUID,
    "date" DATE NOT NULL,
    "liters" DECIMAL(10,2) NOT NULL,
    "price_per_liter" DECIMAL(10,4) NOT NULL,
    "total_cost" DECIMAL(12,2) NOT NULL,
    "mileage" DECIMAL(12,2),
    "station_name" TEXT,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "fuel_logs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "maintenance_records" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "vehicle_id" UUID NOT NULL,
    "type" "MaintenanceType" NOT NULL,
    "description" TEXT,
    "cost" DECIMAL(12,2),
    "workshop" TEXT,
    "start_date" TIMESTAMPTZ,
    "end_date" TIMESTAMPTZ,
    "next_service_date" DATE,
    "status" "VehicleStatus" NOT NULL DEFAULT 'ACTIVE',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "maintenance_records_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- LIVESTOCK & ANIMALS
-- ============================================================

CREATE TABLE "animals" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "tag_number" TEXT NOT NULL,
    "type" "AnimalType" NOT NULL DEFAULT 'CATTLE',
    "breed" TEXT,
    "gender" "Gender" NOT NULL DEFAULT 'MALE',
    "birth_date" DATE,
    "purchase_date" DATE,
    "purchase_price" DECIMAL(12,2),
    "current_weight" DECIMAL(10,2),
    "pen_number" TEXT,
    "status" "AnimalStatus" NOT NULL DEFAULT 'GROWING',
    "branch_id" UUID NOT NULL,
    "notes" TEXT,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "animals_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "animals_tag_number_key" UNIQUE ("tag_number")
);

CREATE TABLE "animal_weights" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "animal_id" UUID NOT NULL,
    "weight" DECIMAL(10,2) NOT NULL,
    "date" DATE NOT NULL,
    "measured_by" UUID NOT NULL,
    "notes" TEXT,

    CONSTRAINT "animal_weights_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "animal_feed_records" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "animal_id" UUID NOT NULL,
    "feed_type" "FeedType" NOT NULL,
    "quantity" DECIMAL(10,3) NOT NULL,
    "cost" DECIMAL(12,2),
    "date" DATE NOT NULL,
    "notes" TEXT,

    CONSTRAINT "animal_feed_records_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "vaccination_records" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "animal_id" UUID NOT NULL,
    "vaccine_name" TEXT NOT NULL,
    "batch_number" TEXT,
    "date" DATE NOT NULL,
    "next_due_date" DATE,
    "veterinarian" TEXT,
    "notes" TEXT,

    CONSTRAINT "vaccination_records_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- FEED MANUFACTURING
-- ============================================================

CREATE TABLE "feed_formulas" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "name" TEXT NOT NULL,
    "target_animal" "AnimalType" NOT NULL,
    "feed_type" "FeedType" NOT NULL,
    "status" "FeedFormulaStatus" NOT NULL DEFAULT 'DRAFT',
    "created_by" UUID NOT NULL,
    "approved_by" UUID,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "feed_formulas_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "feed_formula_ingredients" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "formula_id" UUID NOT NULL,
    "ingredient_name" TEXT NOT NULL,
    "percentage" DECIMAL(5,2) NOT NULL,
    "protein_percent" DECIMAL(5,2),
    "energy_value" DECIMAL(10,2),
    "cost_per_kg" DECIMAL(10,4),
    "order" INT NOT NULL DEFAULT 0,

    CONSTRAINT "feed_formula_ingredients_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "feed_costs" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "formula_id" UUID NOT NULL,
    "raw_material_cost" DECIMAL(12,2) NOT NULL,
    "labor_cost" DECIMAL(12,2) NOT NULL,
    "overhead_cost" DECIMAL(12,2) NOT NULL,
    "total_cost" DECIMAL(12,2) NOT NULL,
    "cost_per_ton" DECIMAL(12,2) NOT NULL,
    "margin" DECIMAL(5,2),
    "effective_date" DATE NOT NULL,

    CONSTRAINT "feed_costs_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- POULTRY
-- ============================================================

CREATE TABLE "poultry_batches" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "batch_number" TEXT NOT NULL,
    "breed" TEXT NOT NULL,
    "supplier_id" UUID,
    "quantity" INT NOT NULL,
    "arrival_date" TIMESTAMPTZ NOT NULL,
    "mortality_count" INT NOT NULL DEFAULT 0,
    "current_count" INT NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "branch_id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "poultry_batches_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "poultry_batches_batch_number_key" UNIQUE ("batch_number")
);

CREATE TABLE "poultry_mortalities" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "batch_id" UUID NOT NULL,
    "date" DATE NOT NULL,
    "count" INT NOT NULL,
    "cause" TEXT,
    "notes" TEXT,

    CONSTRAINT "poultry_mortalities_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "poultry_vaccinations" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "batch_id" UUID NOT NULL,
    "vaccine_name" TEXT NOT NULL,
    "date" DATE NOT NULL,
    "next_due_date" DATE,
    "veterinarian" TEXT,

    CONSTRAINT "poultry_vaccinations_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- EGGS
-- ============================================================

CREATE TABLE "egg_inventories" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "grade" "EggGrade" NOT NULL,
    "quantity" INT NOT NULL,
    "production_date" TIMESTAMPTZ NOT NULL,
    "expiry_date" TIMESTAMPTZ,
    "warehouse_id" UUID NOT NULL,
    "branch_id" UUID NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',

    CONSTRAINT "egg_inventories_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "egg_productions" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "date" DATE NOT NULL,
    "grade" "EggGrade" NOT NULL,
    "quantity" INT NOT NULL,
    "broken_count" INT NOT NULL DEFAULT 0,
    "branch_id" UUID NOT NULL,

    CONSTRAINT "egg_productions_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- HR & PAYROLL
-- ============================================================

CREATE TABLE "employees" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "employee_number" TEXT NOT NULL,
    "user_id" UUID,
    "department" TEXT,
    "position" TEXT,
    "hire_date" TIMESTAMPTZ,
    "termination_date" TIMESTAMPTZ,
    "salary" DECIMAL(12,2),
    "housing_allowance" DECIMAL(12,2) DEFAULT 0,
    "transport_allowance" DECIMAL(12,2) DEFAULT 0,
    "food_allowance" DECIMAL(12,2) DEFAULT 0,
    "insurance_number" TEXT,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "branch_id" UUID NOT NULL,
    "company_id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "employees_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "employees_employee_number_key" UNIQUE ("employee_number"),
    CONSTRAINT "employees_user_id_key" UNIQUE ("user_id")
);

CREATE TABLE "attendance_records" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "employee_id" UUID NOT NULL,
    "date" DATE NOT NULL,
    "check_in" TIMESTAMPTZ,
    "check_out" TIMESTAMPTZ,
    "status" "AttendanceStatus" NOT NULL DEFAULT 'PRESENT',
    "late_minutes" INT NOT NULL DEFAULT 0,
    "overtime_minutes" INT NOT NULL DEFAULT 0,
    "notes" TEXT,

    CONSTRAINT "attendance_records_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "payroll_records" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "employee_id" UUID NOT NULL,
    "month" INT NOT NULL,
    "year" INT NOT NULL,
    "basic_salary" DECIMAL(12,2) NOT NULL,
    "housing_allowance" DECIMAL(12,2) DEFAULT 0,
    "transport_allowance" DECIMAL(12,2) DEFAULT 0,
    "food_allowance" DECIMAL(12,2) DEFAULT 0,
    "overtime" DECIMAL(12,2) DEFAULT 0,
    "bonus" DECIMAL(12,2) DEFAULT 0,
    "deductions" DECIMAL(12,2) DEFAULT 0,
    "insurance" DECIMAL(12,2) DEFAULT 0,
    "tax" DECIMAL(12,2) DEFAULT 0,
    "loans" DECIMAL(12,2) DEFAULT 0,
    "net_salary" DECIMAL(12,2) NOT NULL,
    "status" "PayrollStatus" NOT NULL DEFAULT 'DRAFT',
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "payroll_records_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "commission_records" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "user_id" UUID NOT NULL,
    "month" INT NOT NULL,
    "year" INT NOT NULL,
    "target_amount" DECIMAL(18,2) NOT NULL,
    "achieved_amount" DECIMAL(18,2) NOT NULL,
    "commission_rate" DECIMAL(5,2) NOT NULL,
    "commission_amount" DECIMAL(18,2) NOT NULL,
    "bonus_amount" DECIMAL(18,2) DEFAULT 0,
    "status" "CommissionStatus" NOT NULL DEFAULT 'PENDING',
    "approved_by" UUID,
    "branch_id" UUID NOT NULL,
    "employee_id" UUID,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "commission_records_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "leave_requests" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "employee_id" UUID NOT NULL,
    "type" "LeaveType" NOT NULL,
    "start_date" TIMESTAMPTZ NOT NULL,
    "end_date" TIMESTAMPTZ NOT NULL,
    "days" INT NOT NULL,
    "reason" TEXT,
    "status" "LeaveRequestStatus" NOT NULL DEFAULT 'PENDING',
    "approved_by" UUID,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "leave_requests_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- ACCOUNTING & FINANCE
-- ============================================================

CREATE TABLE "chart_of_accounts" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "code" TEXT NOT NULL,
    "name_ar" TEXT NOT NULL,
    "name_en" TEXT NOT NULL,
    "type" "AccountType" NOT NULL,
    "parent_id" UUID,
    "level" INT NOT NULL,
    "balance" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "company_id" UUID NOT NULL,

    CONSTRAINT "chart_of_accounts_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "chart_of_accounts_code_key" UNIQUE ("code")
);

CREATE TABLE "journal_entries" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "entry_number" TEXT NOT NULL,
    "date" DATE NOT NULL,
    "description" TEXT,
    "total_debit" DECIMAL(18,2) NOT NULL,
    "total_credit" DECIMAL(18,2) NOT NULL,
    "status" "JournalStatus" NOT NULL DEFAULT 'DRAFT',
    "posted_by" UUID,
    "posted_at" TIMESTAMPTZ,
    "notes" TEXT,
    "company_id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    "deleted_at" TIMESTAMPTZ,

    CONSTRAINT "journal_entries_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "journal_entries_entry_number_key" UNIQUE ("entry_number")
);

CREATE TABLE "journal_entry_lines" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "entry_id" UUID NOT NULL,
    "account_id" UUID NOT NULL,
    "debit" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "credit" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "description" TEXT,

    CONSTRAINT "journal_entry_lines_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "bank_accounts" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "bank_name" TEXT NOT NULL,
    "account_number" TEXT NOT NULL,
    "account_type" "BankAccountType" NOT NULL,
    "branch_name" TEXT,
    "current_balance" DECIMAL(18,2) NOT NULL DEFAULT 0,
    "status" "UserStatus" NOT NULL DEFAULT 'ACTIVE',
    "company_id" UUID NOT NULL,

    CONSTRAINT "bank_accounts_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "bank_transactions" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "account_id" UUID NOT NULL,
    "type" "BankTransactionType" NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "description" TEXT,
    "reference" TEXT,
    "balance" DECIMAL(18,2) NOT NULL,
    "date" DATE NOT NULL,

    CONSTRAINT "bank_transactions_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "cash_transactions" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "type" "CashTransactionType" NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "category" TEXT,
    "description" TEXT,
    "reference" TEXT,
    "date" DATE NOT NULL,
    "recorded_by" UUID NOT NULL,

    CONSTRAINT "cash_transactions_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- AUDIT & LOGGING
-- ============================================================

CREATE TABLE "audit_logs" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "user_id" UUID,
    "action" TEXT NOT NULL,
    "entity_type" TEXT NOT NULL,
    "entity_id" TEXT NOT NULL,
    "old_values" TEXT,
    "new_values" TEXT,
    "ip_address" TEXT,
    "user_agent" TEXT,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "activity_logs" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "user_id" UUID,
    "action" TEXT NOT NULL,
    "description" TEXT,
    "module" TEXT,
    "ip_address" TEXT,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

CREATE TABLE "notifications" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "user_id" UUID NOT NULL,
    "type" "NotificationType" NOT NULL DEFAULT 'INFO',
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "data" TEXT,
    "is_read" BOOLEAN NOT NULL DEFAULT FALSE,
    "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT "notifications_pkey" PRIMARY KEY ("id")
);

-- ============================================================
-- FOREIGN KEY CONSTRAINTS
-- ============================================================

-- Branches
ALTER TABLE "branches" ADD CONSTRAINT "branches_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "branches" ADD CONSTRAINT "branches_manager_id_fkey"
    FOREIGN KEY ("manager_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "branches" ADD CONSTRAINT "branches_parent_branch_id_fkey"
    FOREIGN KEY ("parent_branch_id") REFERENCES "branches"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Users
ALTER TABLE "users" ADD CONSTRAINT "users_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "users" ADD CONSTRAINT "users_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Refresh Tokens
ALTER TABLE "refresh_tokens" ADD CONSTRAINT "refresh_tokens_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Password Reset Tokens
ALTER TABLE "password_reset_tokens" ADD CONSTRAINT "password_reset_tokens_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Warehouses
ALTER TABLE "warehouses" ADD CONSTRAINT "warehouses_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "warehouses" ADD CONSTRAINT "warehouses_manager_id_fkey"
    FOREIGN KEY ("manager_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Warehouse Locations
ALTER TABLE "warehouse_locations" ADD CONSTRAINT "warehouse_locations_warehouse_id_fkey"
    FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Product Categories
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_parent_id_fkey"
    FOREIGN KEY ("parent_id") REFERENCES "product_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Products
ALTER TABLE "products" ADD CONSTRAINT "products_category_id_fkey"
    FOREIGN KEY ("category_id") REFERENCES "product_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "products" ADD CONSTRAINT "products_unit_id_fkey"
    FOREIGN KEY ("unit_id") REFERENCES "units_of_measure"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "products" ADD CONSTRAINT "products_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Price Lists
ALTER TABLE "price_lists" ADD CONSTRAINT "price_lists_product_id_fkey"
    FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "price_lists" ADD CONSTRAINT "price_lists_customer_category_id_fkey"
    FOREIGN KEY ("customer_category_id") REFERENCES "customer_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Customers
ALTER TABLE "customers" ADD CONSTRAINT "customers_category_id_fkey"
    FOREIGN KEY ("category_id") REFERENCES "customer_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "customers" ADD CONSTRAINT "customers_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "customers" ADD CONSTRAINT "customers_sales_rep_id_fkey"
    FOREIGN KEY ("sales_rep_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "customers" ADD CONSTRAINT "customers_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Suppliers
ALTER TABLE "suppliers" ADD CONSTRAINT "suppliers_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Supplier Evaluations
ALTER TABLE "supplier_evaluations" ADD CONSTRAINT "supplier_evaluations_supplier_id_fkey"
    FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "supplier_evaluations" ADD CONSTRAINT "supplier_evaluations_evaluated_by_fkey"
    FOREIGN KEY ("evaluated_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Sales Invoices
ALTER TABLE "sales_invoices" ADD CONSTRAINT "sales_invoices_customer_id_fkey"
    FOREIGN KEY ("customer_id") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "sales_invoices" ADD CONSTRAINT "sales_invoices_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "sales_invoices" ADD CONSTRAINT "sales_invoices_sales_rep_id_fkey"
    FOREIGN KEY ("sales_rep_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Sales Invoice Lines
ALTER TABLE "sales_invoice_lines" ADD CONSTRAINT "sales_invoice_lines_invoice_id_fkey"
    FOREIGN KEY ("invoice_id") REFERENCES "sales_invoices"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "sales_invoice_lines" ADD CONSTRAINT "sales_invoice_lines_product_id_fkey"
    FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "sales_invoice_lines" ADD CONSTRAINT "sales_invoice_lines_warehouse_id_fkey"
    FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Sales Returns
ALTER TABLE "sales_returns" ADD CONSTRAINT "sales_returns_original_invoice_id_fkey"
    FOREIGN KEY ("original_invoice_id") REFERENCES "sales_invoices"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "sales_returns" ADD CONSTRAINT "sales_returns_customer_id_fkey"
    FOREIGN KEY ("customer_id") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "sales_returns" ADD CONSTRAINT "sales_returns_product_id_fkey"
    FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Purchase Orders
ALTER TABLE "purchase_orders" ADD CONSTRAINT "purchase_orders_supplier_id_fkey"
    FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "purchase_orders" ADD CONSTRAINT "purchase_orders_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Purchase Order Lines
ALTER TABLE "purchase_order_lines" ADD CONSTRAINT "purchase_order_lines_order_id_fkey"
    FOREIGN KEY ("order_id") REFERENCES "purchase_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "purchase_order_lines" ADD CONSTRAINT "purchase_order_lines_product_id_fkey"
    FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Stock Movements
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_product_id_fkey"
    FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_warehouse_id_fkey"
    FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_location_id_fkey"
    FOREIGN KEY ("location_id") REFERENCES "warehouse_locations"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_created_by_fkey"
    FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Stock Adjustments
ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_product_id_fkey"
    FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_warehouse_id_fkey"
    FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_approved_by_fkey"
    FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Stock Transfers
ALTER TABLE "stock_transfers" ADD CONSTRAINT "stock_transfers_from_warehouse_id_fkey"
    FOREIGN KEY ("from_warehouse_id") REFERENCES "warehouses"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_transfers" ADD CONSTRAINT "stock_transfers_to_warehouse_id_fkey"
    FOREIGN KEY ("to_warehouse_id") REFERENCES "warehouses"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_transfers" ADD CONSTRAINT "stock_transfers_product_id_fkey"
    FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_transfers" ADD CONSTRAINT "stock_transfers_requested_by_fkey"
    FOREIGN KEY ("requested_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_transfers" ADD CONSTRAINT "stock_transfers_approved_by_fkey"
    FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "stock_transfers" ADD CONSTRAINT "stock_transfers_from_branch_id_fkey"
    FOREIGN KEY ("from_branch_id") REFERENCES "branches"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "stock_transfers" ADD CONSTRAINT "stock_transfers_to_branch_id_fkey"
    FOREIGN KEY ("to_branch_id") REFERENCES "branches"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Delivery Orders
ALTER TABLE "delivery_orders" ADD CONSTRAINT "delivery_orders_invoice_id_fkey"
    FOREIGN KEY ("invoice_id") REFERENCES "sales_invoices"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "delivery_orders" ADD CONSTRAINT "delivery_orders_customer_id_fkey"
    FOREIGN KEY ("customer_id") REFERENCES "customers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "delivery_orders" ADD CONSTRAINT "delivery_orders_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "delivery_orders" ADD CONSTRAINT "delivery_orders_driver_id_fkey"
    FOREIGN KEY ("driver_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "delivery_orders" ADD CONSTRAINT "delivery_orders_vehicle_id_fkey"
    FOREIGN KEY ("vehicle_id") REFERENCES "vehicles"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "delivery_orders" ADD CONSTRAINT "delivery_orders_route_id_fkey"
    FOREIGN KEY ("route_id") REFERENCES "delivery_routes"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Delivery Tracking
ALTER TABLE "delivery_tracking" ADD CONSTRAINT "delivery_tracking_delivery_id_fkey"
    FOREIGN KEY ("delivery_id") REFERENCES "delivery_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Vehicles
ALTER TABLE "vehicles" ADD CONSTRAINT "vehicles_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "vehicles" ADD CONSTRAINT "vehicles_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "vehicles" ADD CONSTRAINT "vehicles_assigned_driver_id_fkey"
    FOREIGN KEY ("assigned_driver_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Drivers
ALTER TABLE "drivers" ADD CONSTRAINT "drivers_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Fuel Logs
ALTER TABLE "fuel_logs" ADD CONSTRAINT "fuel_logs_vehicle_id_fkey"
    FOREIGN KEY ("vehicle_id") REFERENCES "vehicles"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "fuel_logs" ADD CONSTRAINT "fuel_logs_driver_id_fkey"
    FOREIGN KEY ("driver_id") REFERENCES "drivers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Maintenance Records
ALTER TABLE "maintenance_records" ADD CONSTRAINT "maintenance_records_vehicle_id_fkey"
    FOREIGN KEY ("vehicle_id") REFERENCES "vehicles"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Animals
ALTER TABLE "animals" ADD CONSTRAINT "animals_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Animal Weights
ALTER TABLE "animal_weights" ADD CONSTRAINT "animal_weights_animal_id_fkey"
    FOREIGN KEY ("animal_id") REFERENCES "animals"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "animal_weights" ADD CONSTRAINT "animal_weights_measured_by_fkey"
    FOREIGN KEY ("measured_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Animal Feed Records
ALTER TABLE "animal_feed_records" ADD CONSTRAINT "animal_feed_records_animal_id_fkey"
    FOREIGN KEY ("animal_id") REFERENCES "animals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Vaccination Records
ALTER TABLE "vaccination_records" ADD CONSTRAINT "vaccination_records_animal_id_fkey"
    FOREIGN KEY ("animal_id") REFERENCES "animals"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Feed Formulas
ALTER TABLE "feed_formulas" ADD CONSTRAINT "feed_formulas_created_by_fkey"
    FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "feed_formulas" ADD CONSTRAINT "feed_formulas_approved_by_fkey"
    FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Feed Formula Ingredients
ALTER TABLE "feed_formula_ingredients" ADD CONSTRAINT "feed_formula_ingredients_formula_id_fkey"
    FOREIGN KEY ("formula_id") REFERENCES "feed_formulas"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Feed Costs
ALTER TABLE "feed_costs" ADD CONSTRAINT "feed_costs_formula_id_fkey"
    FOREIGN KEY ("formula_id") REFERENCES "feed_formulas"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Poultry Batches
ALTER TABLE "poultry_batches" ADD CONSTRAINT "poultry_batches_supplier_id_fkey"
    FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "poultry_batches" ADD CONSTRAINT "poultry_batches_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Poultry Mortalities
ALTER TABLE "poultry_mortalities" ADD CONSTRAINT "poultry_mortalities_batch_id_fkey"
    FOREIGN KEY ("batch_id") REFERENCES "poultry_batches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Poultry Vaccinations
ALTER TABLE "poultry_vaccinations" ADD CONSTRAINT "poultry_vaccinations_batch_id_fkey"
    FOREIGN KEY ("batch_id") REFERENCES "poultry_batches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Egg Inventories
ALTER TABLE "egg_inventories" ADD CONSTRAINT "egg_inventories_warehouse_id_fkey"
    FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "egg_inventories" ADD CONSTRAINT "egg_inventories_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Egg Productions
ALTER TABLE "egg_productions" ADD CONSTRAINT "egg_productions_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Employees
ALTER TABLE "employees" ADD CONSTRAINT "employees_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "employees" ADD CONSTRAINT "employees_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "employees" ADD CONSTRAINT "employees_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Attendance Records
ALTER TABLE "attendance_records" ADD CONSTRAINT "attendance_records_employee_id_fkey"
    FOREIGN KEY ("employee_id") REFERENCES "employees"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Payroll Records
ALTER TABLE "payroll_records" ADD CONSTRAINT "payroll_records_employee_id_fkey"
    FOREIGN KEY ("employee_id") REFERENCES "employees"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Commission Records
ALTER TABLE "commission_records" ADD CONSTRAINT "commission_records_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "commission_records" ADD CONSTRAINT "commission_records_approved_by_fkey"
    FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "commission_records" ADD CONSTRAINT "commission_records_branch_id_fkey"
    FOREIGN KEY ("branch_id") REFERENCES "branches"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "commission_records" ADD CONSTRAINT "commission_records_employee_id_fkey"
    FOREIGN KEY ("employee_id") REFERENCES "employees"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Leave Requests
ALTER TABLE "leave_requests" ADD CONSTRAINT "leave_requests_employee_id_fkey"
    FOREIGN KEY ("employee_id") REFERENCES "employees"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "leave_requests" ADD CONSTRAINT "leave_requests_approved_by_fkey"
    FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Chart of Accounts
ALTER TABLE "chart_of_accounts" ADD CONSTRAINT "chart_of_accounts_parent_id_fkey"
    FOREIGN KEY ("parent_id") REFERENCES "chart_of_accounts"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "chart_of_accounts" ADD CONSTRAINT "chart_of_accounts_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Journal Entries
ALTER TABLE "journal_entries" ADD CONSTRAINT "journal_entries_posted_by_fkey"
    FOREIGN KEY ("posted_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "journal_entries" ADD CONSTRAINT "journal_entries_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Journal Entry Lines
ALTER TABLE "journal_entry_lines" ADD CONSTRAINT "journal_entry_lines_entry_id_fkey"
    FOREIGN KEY ("entry_id") REFERENCES "journal_entries"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "journal_entry_lines" ADD CONSTRAINT "journal_entry_lines_account_id_fkey"
    FOREIGN KEY ("account_id") REFERENCES "chart_of_accounts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Bank Accounts
ALTER TABLE "bank_accounts" ADD CONSTRAINT "bank_accounts_company_id_fkey"
    FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Bank Transactions
ALTER TABLE "bank_transactions" ADD CONSTRAINT "bank_transactions_account_id_fkey"
    FOREIGN KEY ("account_id") REFERENCES "bank_accounts"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Cash Transactions
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_recorded_by_fkey"
    FOREIGN KEY ("recorded_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Audit Logs
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Activity Logs
ALTER TABLE "activity_logs" ADD CONSTRAINT "activity_logs_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Notifications
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ============================================================
-- INDEXES
-- ============================================================

-- Companies
CREATE INDEX "companies_status_idx" ON "companies"("status");

-- Branches
CREATE INDEX "branches_company_id_idx" ON "branches"("company_id");
CREATE INDEX "branches_code_idx" ON "branches"("code");
CREATE INDEX "branches_status_idx" ON "branches"("status");
CREATE INDEX "branches_city_idx" ON "branches"("city");

-- Users
CREATE INDEX "users_company_id_idx" ON "users"("company_id");
CREATE INDEX "users_branch_id_idx" ON "users"("branch_id");
CREATE INDEX "users_role_idx" ON "users"("role");
CREATE INDEX "users_status_idx" ON "users"("status");
CREATE INDEX "users_email_idx" ON "users"("email");

-- Refresh Tokens
CREATE INDEX "refresh_tokens_user_id_idx" ON "refresh_tokens"("user_id");
CREATE INDEX "refresh_tokens_token_idx" ON "refresh_tokens"("token");

-- Password Reset Tokens
CREATE INDEX "password_reset_tokens_user_id_idx" ON "password_reset_tokens"("user_id");
CREATE INDEX "password_reset_tokens_token_idx" ON "password_reset_tokens"("token");

-- Warehouses
CREATE INDEX "warehouses_branch_id_idx" ON "warehouses"("branch_id");
CREATE INDEX "warehouses_code_idx" ON "warehouses"("code");
CREATE INDEX "warehouses_status_idx" ON "warehouses"("status");

-- Warehouse Locations
CREATE INDEX "warehouse_locations_warehouse_id_idx" ON "warehouse_locations"("warehouse_id");
CREATE INDEX "warehouse_locations_barcode_idx" ON "warehouse_locations"("barcode");

-- Products
CREATE INDEX "products_company_id_idx" ON "products"("company_id");
CREATE INDEX "products_category_id_idx" ON "products"("category_id");
CREATE INDEX "products_code_idx" ON "products"("code");
CREATE INDEX "products_barcode_idx" ON "products"("barcode");
CREATE INDEX "products_status_idx" ON "products"("status");

-- Price Lists
CREATE INDEX "price_lists_product_id_idx" ON "price_lists"("product_id");
CREATE INDEX "price_lists_customer_category_id_idx" ON "price_lists"("customer_category_id");
CREATE INDEX "price_lists_effective_from_idx" ON "price_lists"("effective_from");

-- Customers
CREATE INDEX "customers_company_id_idx" ON "customers"("company_id");
CREATE INDEX "customers_branch_id_idx" ON "customers"("branch_id");
CREATE INDEX "customers_category_id_idx" ON "customers"("category_id");
CREATE INDEX "customers_sales_rep_id_idx" ON "customers"("sales_rep_id");
CREATE INDEX "customers_code_idx" ON "customers"("code");
CREATE INDEX "customers_status_idx" ON "customers"("status");

-- Suppliers
CREATE INDEX "suppliers_company_id_idx" ON "suppliers"("company_id");
CREATE INDEX "suppliers_code_idx" ON "suppliers"("code");
CREATE INDEX "suppliers_status_idx" ON "suppliers"("status");

-- Supplier Evaluations
CREATE INDEX "supplier_evaluations_supplier_id_idx" ON "supplier_evaluations"("supplier_id");
CREATE INDEX "supplier_evaluations_evaluated_by_idx" ON "supplier_evaluations"("evaluated_by");

-- Sales Invoices
CREATE INDEX "sales_invoices_branch_id_idx" ON "sales_invoices"("branch_id");
CREATE INDEX "sales_invoices_customer_id_idx" ON "sales_invoices"("customer_id");
CREATE INDEX "sales_invoices_sales_rep_id_idx" ON "sales_invoices"("sales_rep_id");
CREATE INDEX "sales_invoices_status_idx" ON "sales_invoices"("status");
CREATE INDEX "sales_invoices_invoice_number_idx" ON "sales_invoices"("invoice_number");
CREATE INDEX "sales_invoices_due_date_idx" ON "sales_invoices"("due_date");
CREATE INDEX "sales_invoices_created_at_idx" ON "sales_invoices"("created_at");

-- Sales Invoice Lines
CREATE INDEX "sales_invoice_lines_invoice_id_idx" ON "sales_invoice_lines"("invoice_id");
CREATE INDEX "sales_invoice_lines_product_id_idx" ON "sales_invoice_lines"("product_id");
CREATE INDEX "sales_invoice_lines_warehouse_id_idx" ON "sales_invoice_lines"("warehouse_id");

-- Sales Returns
CREATE INDEX "sales_returns_original_invoice_id_idx" ON "sales_returns"("original_invoice_id");
CREATE INDEX "sales_returns_customer_id_idx" ON "sales_returns"("customer_id");
CREATE INDEX "sales_returns_product_id_idx" ON "sales_returns"("product_id");

-- Purchase Orders
CREATE INDEX "purchase_orders_branch_id_idx" ON "purchase_orders"("branch_id");
CREATE INDEX "purchase_orders_supplier_id_idx" ON "purchase_orders"("supplier_id");
CREATE INDEX "purchase_orders_status_idx" ON "purchase_orders"("status");

-- Purchase Order Lines
CREATE INDEX "purchase_order_lines_order_id_idx" ON "purchase_order_lines"("order_id");
CREATE INDEX "purchase_order_lines_product_id_idx" ON "purchase_order_lines"("product_id");

-- Stock Movements
CREATE INDEX "stock_movements_product_id_idx" ON "stock_movements"("product_id");
CREATE INDEX "stock_movements_warehouse_id_idx" ON "stock_movements"("warehouse_id");
CREATE INDEX "stock_movements_location_id_idx" ON "stock_movements"("location_id");
CREATE INDEX "stock_movements_type_idx" ON "stock_movements"("type");
CREATE INDEX "stock_movements_created_at_idx" ON "stock_movements"("created_at");
CREATE INDEX "stock_movements_batch_number_idx" ON "stock_movements"("batch_number");
CREATE INDEX "stock_movements_created_by_idx" ON "stock_movements"("created_by");

-- Stock Adjustments
CREATE INDEX "stock_adjustments_product_id_idx" ON "stock_adjustments"("product_id");
CREATE INDEX "stock_adjustments_warehouse_id_idx" ON "stock_adjustments"("warehouse_id");
CREATE INDEX "stock_adjustments_status_idx" ON "stock_adjustments"("status");
CREATE INDEX "stock_adjustments_approved_by_idx" ON "stock_adjustments"("approved_by");

-- Stock Transfers
CREATE INDEX "stock_transfers_from_warehouse_id_idx" ON "stock_transfers"("from_warehouse_id");
CREATE INDEX "stock_transfers_to_warehouse_id_idx" ON "stock_transfers"("to_warehouse_id");
CREATE INDEX "stock_transfers_product_id_idx" ON "stock_transfers"("product_id");
CREATE INDEX "stock_transfers_status_idx" ON "stock_transfers"("status");
CREATE INDEX "stock_transfers_requested_by_idx" ON "stock_transfers"("requested_by");
CREATE INDEX "stock_transfers_approved_by_idx" ON "stock_transfers"("approved_by");

-- Delivery Orders
CREATE INDEX "delivery_orders_branch_id_idx" ON "delivery_orders"("branch_id");
CREATE INDEX "delivery_orders_invoice_id_idx" ON "delivery_orders"("invoice_id");
CREATE INDEX "delivery_orders_driver_id_idx" ON "delivery_orders"("driver_id");
CREATE INDEX "delivery_orders_vehicle_id_idx" ON "delivery_orders"("vehicle_id");
CREATE INDEX "delivery_orders_route_id_idx" ON "delivery_orders"("route_id");
CREATE INDEX "delivery_orders_status_idx" ON "delivery_orders"("status");
CREATE INDEX "delivery_orders_scheduled_date_idx" ON "delivery_orders"("scheduled_date");

-- Delivery Tracking
CREATE INDEX "delivery_tracking_delivery_id_idx" ON "delivery_tracking"("delivery_id");
CREATE INDEX "delivery_tracking_timestamp_idx" ON "delivery_tracking"("timestamp");

-- Vehicles
CREATE INDEX "vehicles_branch_id_idx" ON "vehicles"("branch_id");
CREATE INDEX "vehicles_company_id_idx" ON "vehicles"("company_id");
CREATE INDEX "vehicles_status_idx" ON "vehicles"("status");
CREATE INDEX "vehicles_plate_number_idx" ON "vehicles"("plate_number");
CREATE INDEX "vehicles_assigned_driver_id_idx" ON "vehicles"("assigned_driver_id");

-- Drivers
CREATE INDEX "drivers_user_id_idx" ON "drivers"("user_id");
CREATE INDEX "drivers_status_idx" ON "drivers"("status");

-- Fuel Logs
CREATE INDEX "fuel_logs_vehicle_id_idx" ON "fuel_logs"("vehicle_id");
CREATE INDEX "fuel_logs_driver_id_idx" ON "fuel_logs"("driver_id");
CREATE INDEX "fuel_logs_date_idx" ON "fuel_logs"("date");

-- Maintenance Records
CREATE INDEX "maintenance_records_vehicle_id_idx" ON "maintenance_records"("vehicle_id");
CREATE INDEX "maintenance_records_type_idx" ON "maintenance_records"("type");
CREATE INDEX "maintenance_records_status_idx" ON "maintenance_records"("status");

-- Animals
CREATE INDEX "animals_branch_id_idx" ON "animals"("branch_id");
CREATE INDEX "animals_tag_number_idx" ON "animals"("tag_number");
CREATE INDEX "animals_status_idx" ON "animals"("status");
CREATE INDEX "animals_type_idx" ON "animals"("type");

-- Animal Weights
CREATE INDEX "animal_weights_animal_id_idx" ON "animal_weights"("animal_id");
CREATE INDEX "animal_weights_date_idx" ON "animal_weights"("date");
CREATE INDEX "animal_weights_measured_by_idx" ON "animal_weights"("measured_by");

-- Animal Feed Records
CREATE INDEX "animal_feed_records_animal_id_idx" ON "animal_feed_records"("animal_id");
CREATE INDEX "animal_feed_records_date_idx" ON "animal_feed_records"("date");

-- Vaccination Records
CREATE INDEX "vaccination_records_animal_id_idx" ON "vaccination_records"("animal_id");
CREATE INDEX "vaccination_records_date_idx" ON "vaccination_records"("date");

-- Feed Formulas
CREATE INDEX "feed_formulas_target_animal_idx" ON "feed_formulas"("target_animal");
CREATE INDEX "feed_formulas_feed_type_idx" ON "feed_formulas"("feed_type");
CREATE INDEX "feed_formulas_status_idx" ON "feed_formulas"("status");
CREATE INDEX "feed_formulas_created_by_idx" ON "feed_formulas"("created_by");
CREATE INDEX "feed_formulas_approved_by_idx" ON "feed_formulas"("approved_by");

-- Feed Formula Ingredients
CREATE INDEX "feed_formula_ingredients_formula_id_idx" ON "feed_formula_ingredients"("formula_id");

-- Feed Costs
CREATE INDEX "feed_costs_formula_id_idx" ON "feed_costs"("formula_id");
CREATE INDEX "feed_costs_effective_date_idx" ON "feed_costs"("effective_date");

-- Poultry Batches
CREATE INDEX "poultry_batches_branch_id_idx" ON "poultry_batches"("branch_id");
CREATE INDEX "poultry_batches_supplier_id_idx" ON "poultry_batches"("supplier_id");
CREATE INDEX "poultry_batches_status_idx" ON "poultry_batches"("status");

-- Poultry Mortalities
CREATE INDEX "poultry_mortalities_batch_id_idx" ON "poultry_mortalities"("batch_id");
CREATE INDEX "poultry_mortalities_date_idx" ON "poultry_mortalities"("date");

-- Poultry Vaccinations
CREATE INDEX "poultry_vaccinations_batch_id_idx" ON "poultry_vaccinations"("batch_id");
CREATE INDEX "poultry_vaccinations_date_idx" ON "poultry_vaccinations"("date");

-- Egg Inventories
CREATE INDEX "egg_inventories_branch_id_idx" ON "egg_inventories"("branch_id");
CREATE INDEX "egg_inventories_warehouse_id_idx" ON "egg_inventories"("warehouse_id");
CREATE INDEX "egg_inventories_grade_idx" ON "egg_inventories"("grade");

-- Egg Productions
CREATE INDEX "egg_productions_branch_id_idx" ON "egg_productions"("branch_id");
CREATE INDEX "egg_productions_date_idx" ON "egg_productions"("date");

-- Employees
CREATE INDEX "employees_company_id_idx" ON "employees"("company_id");
CREATE INDEX "employees_branch_id_idx" ON "employees"("branch_id");
CREATE INDEX "employees_user_id_idx" ON "employees"("user_id");
CREATE INDEX "employees_status_idx" ON "employees"("status");

-- Attendance Records
CREATE INDEX "attendance_records_employee_id_idx" ON "attendance_records"("employee_id");
CREATE INDEX "attendance_records_date_idx" ON "attendance_records"("date");
CREATE INDEX "attendance_records_status_idx" ON "attendance_records"("status");

-- Payroll Records
CREATE INDEX "payroll_records_employee_id_idx" ON "payroll_records"("employee_id");
CREATE INDEX "payroll_records_month_year_idx" ON "payroll_records"("month", "year");
CREATE INDEX "payroll_records_status_idx" ON "payroll_records"("status");

-- Commission Records
CREATE INDEX "commission_records_user_id_idx" ON "commission_records"("user_id");
CREATE INDEX "commission_records_branch_id_idx" ON "commission_records"("branch_id");
CREATE INDEX "commission_records_month_year_idx" ON "commission_records"("month", "year");
CREATE INDEX "commission_records_status_idx" ON "commission_records"("status");
CREATE INDEX "commission_records_approved_by_idx" ON "commission_records"("approved_by");
CREATE INDEX "commission_records_employee_id_idx" ON "commission_records"("employee_id");

-- Leave Requests
CREATE INDEX "leave_requests_employee_id_idx" ON "leave_requests"("employee_id");
CREATE INDEX "leave_requests_status_idx" ON "leave_requests"("status");
CREATE INDEX "leave_requests_approved_by_idx" ON "leave_requests"("approved_by");

-- Chart of Accounts
CREATE INDEX "chart_of_accounts_company_id_idx" ON "chart_of_accounts"("company_id");
CREATE INDEX "chart_of_accounts_type_idx" ON "chart_of_accounts"("type");
CREATE INDEX "chart_of_accounts_parent_id_idx" ON "chart_of_accounts"("parent_id");
CREATE INDEX "chart_of_accounts_code_idx" ON "chart_of_accounts"("code");

-- Journal Entries
CREATE INDEX "journal_entries_company_id_idx" ON "journal_entries"("company_id");
CREATE INDEX "journal_entries_status_idx" ON "journal_entries"("status");
CREATE INDEX "journal_entries_date_idx" ON "journal_entries"("date");
CREATE INDEX "journal_entries_entry_number_idx" ON "journal_entries"("entry_number");
CREATE INDEX "journal_entries_posted_by_idx" ON "journal_entries"("posted_by");

-- Journal Entry Lines
CREATE INDEX "journal_entry_lines_entry_id_idx" ON "journal_entry_lines"("entry_id");
CREATE INDEX "journal_entry_lines_account_id_idx" ON "journal_entry_lines"("account_id");

-- Bank Accounts
CREATE INDEX "bank_accounts_company_id_idx" ON "bank_accounts"("company_id");
CREATE INDEX "bank_accounts_status_idx" ON "bank_accounts"("status");

-- Bank Transactions
CREATE INDEX "bank_transactions_account_id_idx" ON "bank_transactions"("account_id");
CREATE INDEX "bank_transactions_date_idx" ON "bank_transactions"("date");
CREATE INDEX "bank_transactions_type_idx" ON "bank_transactions"("type");

-- Cash Transactions
CREATE INDEX "cash_transactions_recorded_by_idx" ON "cash_transactions"("recorded_by");
CREATE INDEX "cash_transactions_date_idx" ON "cash_transactions"("date");
CREATE INDEX "cash_transactions_type_idx" ON "cash_transactions"("type");

-- Audit Logs
CREATE INDEX "audit_logs_user_id_idx" ON "audit_logs"("user_id");
CREATE INDEX "audit_logs_entity_type_entity_id_idx" ON "audit_logs"("entity_type", "entity_id");
CREATE INDEX "audit_logs_action_idx" ON "audit_logs"("action");
CREATE INDEX "audit_logs_created_at_idx" ON "audit_logs"("created_at");

-- Activity Logs
CREATE INDEX "activity_logs_user_id_idx" ON "activity_logs"("user_id");
CREATE INDEX "activity_logs_module_idx" ON "activity_logs"("module");
CREATE INDEX "activity_logs_action_idx" ON "activity_logs"("action");
CREATE INDEX "activity_logs_created_at_idx" ON "activity_logs"("created_at");

-- Notifications
CREATE INDEX "notifications_user_id_idx" ON "notifications"("user_id");
CREATE INDEX "notifications_is_read_idx" ON "notifications"("is_read");
CREATE INDEX "notifications_created_at_idx" ON "notifications"("created_at");

-- ============================================================
-- TRIGGERS: Auto-update updated_at column
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to all tables with updated_at column
CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON "companies"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_branches_updated_at BEFORE UPDATE ON "branches"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON "users"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_warehouses_updated_at BEFORE UPDATE ON "warehouses"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_warehouse_locations_updated_at BEFORE UPDATE ON "warehouse_locations"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON "products"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON "customers"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_suppliers_updated_at BEFORE UPDATE ON "suppliers"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sales_invoices_updated_at BEFORE UPDATE ON "sales_invoices"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_purchase_orders_updated_at BEFORE UPDATE ON "purchase_orders"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_delivery_orders_updated_at BEFORE UPDATE ON "delivery_orders"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_vehicles_updated_at BEFORE UPDATE ON "vehicles"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_animals_updated_at BEFORE UPDATE ON "animals"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_feed_formulas_updated_at BEFORE UPDATE ON "feed_formulas"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_poultry_batches_updated_at BEFORE UPDATE ON "poultry_batches"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON "employees"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_journal_entries_updated_at BEFORE UPDATE ON "journal_entries"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- ROW LEVEL SECURITY (RLS) - Multi-Company Isolation
-- ============================================================

-- Enable RLS on all tenant-isolated tables
ALTER TABLE "companies" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "branches" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "users" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "warehouses" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "products" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "customers" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "suppliers" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "sales_invoices" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "sales_invoice_lines" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "sales_returns" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "purchase_orders" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "purchase_order_lines" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "stock_movements" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "stock_adjustments" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "stock_transfers" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "delivery_orders" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "delivery_tracking" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "vehicles" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "fuel_logs" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "maintenance_records" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "animals" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "animal_weights" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "animal_feed_records" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "vaccination_records" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "feed_formulas" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "feed_formula_ingredients" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "feed_costs" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "poultry_batches" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "poultry_mortalities" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "poultry_vaccinations" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "egg_inventories" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "egg_productions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "employees" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "attendance_records" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "payroll_records" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "commission_records" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "leave_requests" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "chart_of_accounts" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "journal_entries" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "journal_entry_lines" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bank_accounts" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bank_transactions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "cash_transactions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "audit_logs" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "activity_logs" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "refresh_tokens" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "password_reset_tokens" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "notifications" ENABLE ROW LEVEL SECURITY;

-- Companies: users can only see their own company
CREATE POLICY "companies_isolation_policy" ON "companies"
    FOR ALL USING (
        current_setting('app.current_company_id', true)::text = "id"::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Branches: users can only see branches in their company
CREATE POLICY "branches_isolation_policy" ON "branches"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Users: users can only see users in their company
CREATE POLICY "users_isolation_policy" ON "users"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Warehouses: branch-based isolation
CREATE POLICY "warehouses_isolation_policy" ON "warehouses"
    FOR ALL USING (
        "branch_id"::text = current_setting('app.current_branch_id', true)::text
        OR current_setting('app.current_user_role', true)::text IN ('SUPER_ADMIN', 'ADMIN', 'BRANCH_MANAGER')
        OR current_setting('app.current_company_id', true) IS NULL
    );

-- Products: company-based isolation
CREATE POLICY "products_isolation_policy" ON "products"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Customers: company-based isolation
CREATE POLICY "customers_isolation_policy" ON "customers"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Suppliers: company-based isolation
CREATE POLICY "suppliers_isolation_policy" ON "suppliers"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Sales Invoices: branch-based isolation
CREATE POLICY "sales_invoices_isolation_policy" ON "sales_invoices"
    FOR ALL USING (
        "branch_id"::text = current_setting('app.current_branch_id', true)::text
        OR current_setting('app.current_user_role', true)::text IN ('SUPER_ADMIN', 'ADMIN', 'BRANCH_MANAGER', 'ACCOUNTANT')
        OR current_setting('app.current_company_id', true) IS NULL
    );

-- Purchase Orders: branch-based isolation
CREATE POLICY "purchase_orders_isolation_policy" ON "purchase_orders"
    FOR ALL USING (
        "branch_id"::text = current_setting('app.current_branch_id', true)::text
        OR current_setting('app.current_user_role', true)::text IN ('SUPER_ADMIN', 'ADMIN', 'BRANCH_MANAGER')
        OR current_setting('app.current_company_id', true) IS NULL
    );

-- Vehicles: company-based isolation
CREATE POLICY "vehicles_isolation_policy" ON "vehicles"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Employees: company-based isolation
CREATE POLICY "employees_isolation_policy" ON "employees"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Chart of Accounts: company-based isolation
CREATE POLICY "chart_of_accounts_isolation_policy" ON "chart_of_accounts"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Journal Entries: company-based isolation
CREATE POLICY "journal_entries_isolation_policy" ON "journal_entries"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Bank Accounts: company-based isolation
CREATE POLICY "bank_accounts_isolation_policy" ON "bank_accounts"
    FOR ALL USING (
        "company_id"::text = current_setting('app.current_company_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
        OR current_setting('app.current_user_role', true)::text = 'SUPER_ADMIN'
    );

-- Audit Logs: user can see audit logs from their company
CREATE POLICY "audit_logs_isolation_policy" ON "audit_logs"
    FOR ALL USING (
        "user_id"::text = current_setting('app.current_user_id', true)::text
        OR current_setting('app.current_user_role', true)::text IN ('SUPER_ADMIN', 'ADMIN')
        OR current_setting('app.current_company_id', true) IS NULL
    );

-- Notifications: user can only see their own notifications
CREATE POLICY "notifications_isolation_policy" ON "notifications"
    FOR ALL USING (
        "user_id"::text = current_setting('app.current_user_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
    );

-- Refresh Tokens: user can only see their own tokens
CREATE POLICY "refresh_tokens_isolation_policy" ON "refresh_tokens"
    FOR ALL USING (
        "user_id"::text = current_setting('app.current_user_id', true)::text
        OR current_setting('app.current_company_id', true) IS NULL
    );

-- ============================================================
-- SEED DATA: Default System Values
-- ============================================================

-- Insert default unit of measure
INSERT INTO "units_of_measure" ("id", "name", "code", "conversion_rate", "base_unit")
VALUES
    (uuid_generate_v4(), 'Piece', 'PC', 1, NULL),
    (uuid_generate_v4(), 'Kilogram', 'KG', 1, NULL),
    (uuid_generate_v4(), 'Gram', 'GM', 0.001, 'KG'),
    (uuid_generate_v4(), 'Ton', 'TON', 1000, 'KG'),
    (uuid_generate_v4(), 'Liter', 'LTR', 1, NULL),
    (uuid_generate_v4(), 'Meter', 'MTR', 1, NULL),
    (uuid_generate_v4(), 'Box', 'BOX', 1, NULL),
    (uuid_generate_v4(), 'Carton', 'CTN', 1, NULL),
    (uuid_generate_v4(), 'Bag', 'BAG', 1, NULL)
ON CONFLICT DO NOTHING;

-- Insert default customer categories
INSERT INTO "customer_categories" ("id", "name", "min_orders", "min_amount", "color", "criteria")
VALUES
    (uuid_generate_v4(), 'Bronze', 0, 0, '#CD7F32', 'New customers'),
    (uuid_generate_v4(), 'Silver', 10, 50000, '#C0C0C0', 'Regular customers'),
    (uuid_generate_v4(), 'Gold', 50, 250000, '#FFD700', 'VIP customers'),
    (uuid_generate_v4(), 'Platinum', 100, 1000000, '#E5E4E2', 'Enterprise customers')
ON CONFLICT DO NOTHING;
