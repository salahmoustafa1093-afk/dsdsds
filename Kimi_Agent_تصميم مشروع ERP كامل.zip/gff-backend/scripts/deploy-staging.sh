#!/bin/bash
# =============================================================================
# GFF ERP - Staging Deployment Script
# =============================================================================
# Automated deployment to staging environment
# Triggered after PR merge to develop branch
#
# Usage: ./scripts/deploy-staging.sh [VERSION]
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
VERSION="${1:-latest}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date +'%H:%M:%S')] OK${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARN${NC} $1"; }
error() { echo -e "${RED}[$(date +'%H:%M:%S')] ERR${NC} $1"; }

log "Starting staging deployment..."
log "Version: ${VERSION}"
log "Project: ${PROJECT_DIR}"

cd "${PROJECT_DIR}"

# Step 1: Pull latest code
log "Pulling latest code..."
git fetch origin
git checkout develop
git pull origin develop
success "Code updated"

# Step 2: Copy staging env
log "Setting up staging environment..."
if [ ! -f .env.staging ]; then
    error ".env.staging not found!"
    exit 1
fi
cp .env.staging .env
success "Environment configured"

# Step 3: Pull Docker images
log "Pulling Docker images (version: ${VERSION})..."
export VERSION

# Build/pull backend image
docker pull "ghcr.io/gff-erp/backend:${VERSION}" 2>/dev/null || {
    warn "Image not found in registry, building locally..."
    docker build -t "ghcr.io/gff-erp/backend:${VERSION}" -f docker/Dockerfile .
}

# Build/pull frontend image
docker pull "ghcr.io/gff-erp/frontend:${VERSION}" 2>/dev/null || {
    warn "Frontend image not found, will use nginx serving"
}

success "Images ready"

# Step 4: Run database migrations
log "Running database migrations..."
docker compose -f docker/docker-compose.prod.yml up -d postgres redis

# Wait for postgres
for i in $(seq 1 30); do
    if docker compose -f docker/docker-compose.prod.yml exec -T postgres pg_isready -U gff_staging > /dev/null 2>&1; then
        break
    fi
    sleep 1
done

# Run migrations
docker run --rm \
    --network gff-backend_database \
    -v "${PROJECT_DIR}/prisma:/app/prisma:ro" \
    -e "DATABASE_URL=$(grep DATABASE_URL .env | cut -d= -f2-)" \
    node:22-alpine \
    sh -c "npm install prisma@latest -g && npx prisma migrate deploy --schema=/app/prisma/schema.prisma"

success "Migrations completed"

# Step 5: Deploy services
log "Deploying services..."
docker compose -f docker/docker-compose.prod.yml -f docker/docker-compose.staging.yml up -d --remove-orphans

# Step 6: Wait for services
log "Waiting for services to be ready..."
sleep 15

# Step 7: Health check
log "Running health checks..."
HEALTH_STATUS=$(curl -sf -o /dev/null -w "%{http_code}" http://localhost:3001/api/v1/health || echo "000")

if [ "$HEALTH_STATUS" = "200" ]; then
    success "Health check passed!"
else
    error "Health check failed (HTTP ${HEALTH_STATUS})"
    log "Rolling back..."
    docker compose -f docker/docker-compose.prod.yml restart backend-api-1 backend-api-2 backend-api-3
    exit 1
fi

# Step 8: Cleanup old images
log "Cleaning up old images..."
docker image prune -f --filter "until=168h" > /dev/null 2>&1 || true

success "Staging deployment completed successfully!"
echo ""
echo -e "${BOLD}Staging Environment:${NC}"
echo "  URL: https://staging.gff-erp.com"
echo "  API: https://staging.gff-erp.com/api/v1"
echo "  Health: https://staging.gff-erp.com/api/v1/health"
echo ""