#!/bin/bash
# =============================================================================
# GFF ERP - Database Migration Script
# =============================================================================
# Wrapper for Prisma migrations with safety checks and rollback support
#
# Usage: ./scripts/migrate.sh [COMMAND] [OPTIONS]
#
# Commands:
#   status          Show migration status (default)
#   deploy          Deploy pending migrations
#   create <name>   Create a new migration
#   rollback        Rollback the last migration
#   reset           Reset database (DANGEROUS - drops all data)
#   validate        Validate schema without applying
#   seed            Run seed scripts
#
# Options:
#   --force         Skip confirmations
#   --backup        Create backup before migration
#   --env FILE      Use specific env file
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date +'%H:%M:%S')] OK${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARN${NC} $1"; }
error() { echo -e "${RED}[$(date +'%H:%M:%S')] ERR${NC} $1"; }

# Defaults
COMMAND="${1:-status}"
FORCE=false
BACKUP=false
ENV_FILE="${PROJECT_DIR}/.env"

# Parse arguments
shift 1 || true
while [[ $# -gt 0 ]]; do
    case $1 in
        --force) FORCE=true; shift ;;
        --backup) BACKUP=true; shift ;;
        --env) ENV_FILE="$2"; shift 2 ;;
        --help)
            echo "GFF ERP Database Migration"
            echo ""
            echo "Usage: ./scripts/migrate.sh [COMMAND] [OPTIONS]"
            echo ""
            echo "Commands:"
            echo "  status          Show migration status (default)"
            echo "  deploy          Deploy pending migrations"
            echo "  create <name>   Create a new migration"
            echo "  rollback        Rollback the last migration"
            echo "  reset           Reset database (DANGEROUS)"
            echo "  validate        Validate schema without applying"
            echo "  seed            Run seed scripts"
            echo ""
            echo "Options:"
            echo "  --force         Skip confirmations"
            echo "  --backup        Create backup before migration"
            echo "  --env FILE      Use specific env file"
            exit 0
            ;;
        *) shift ;;
    esac
done

# =============================================================================
# Load environment
# =============================================================================
cd "${PROJECT_DIR}"

if [ -f "$ENV_FILE" ]; then
    export $(grep -v '^#' "$ENV_FILE" | xargs)
else
    warn "Env file not found: ${ENV_FILE}"
fi

# Get database URL
DATABASE_URL="${DATABASE_URL:-}"
if [ -z "$DATABASE_URL" ]; then
    error "DATABASE_URL not set!"
    exit 1
fi

# Ensure postgres is running
ensure_postgres() {
    if ! docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" ps postgres | grep -q "Up"; then
        log "Starting PostgreSQL..."
        docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" up -d postgres redis
        
        for i in $(seq 1 30); do
            if docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres pg_isready > /dev/null 2>&1; then
                break
            fi
            sleep 1
        done
    fi
}

# =============================================================================
# Pre-migration backup
# =============================================================================
pre_migration_backup() {
    if [ "$BACKUP" = false ]; then
        return 0
    fi
    
    log "Creating pre-migration backup..."
    
    local backup_file="${PROJECT_DIR}/backups/pre-migrate-$(date +%Y%m%d_%H%M%S).sql.gz"
    mkdir -p "${PROJECT_DIR}/backups"
    
    docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
        pg_dump -U "${DB_USER:-postgres}" -d "${DB_NAME:-gff_erp}" 2>/dev/null | \
        gzip > "$backup_file"
    
    if [ -f "$backup_file" ] && [ -s "$backup_file" ]; then
        success "Pre-migration backup: ${backup_file}"
    else
        warn "Backup failed, continuing without backup"
    fi
}

# =============================================================================
# Commands
# =============================================================================
cmd_status() {
    log "Checking migration status..."
    
    ensure_postgres
    
    docker run --rm \
        --network gff-backend_database \
        -v "${PROJECT_DIR}/prisma:/app/prisma:ro" \
        -e "DATABASE_URL=${DATABASE_URL}" \
        node:22-alpine \
        sh -c "npm install prisma@latest -g && npx prisma migrate status --schema=/app/prisma/schema.prisma"
}

cmd_deploy() {
    log "Deploying migrations..."
    
    if [ "$FORCE" = false ]; then
        echo ""
        read -p "Deploy migrations to production? [y/N]: " confirm
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            log "Deployment cancelled."
            exit 0
        fi
    fi
    
    ensure_postgres
    pre_migration_backup
    
    docker run --rm \
        --network gff-backend_database \
        -v "${PROJECT_DIR}/prisma:/app/prisma:ro" \
        -e "DATABASE_URL=${DATABASE_URL}" \
        node:22-alpine \
        sh -c "npm install prisma@latest -g && npx prisma migrate deploy --schema=/app/prisma/schema.prisma"
    
    success "Migrations deployed successfully!"
}

cmd_create() {
    local name="${1:-migration}"
    
    log "Creating migration: ${name}..."
    
    ensure_postgres
    
    docker run --rm \
        --network gff-backend_database \
        -v "${PROJECT_DIR}/prisma:/app/prisma" \
        -e "DATABASE_URL=${DATABASE_URL}" \
        -it \
        node:22-alpine \
        sh -c "npm install prisma@latest -g && npx prisma migrate dev --name ${name} --schema=/app/prisma/schema.prisma"
    
    success "Migration created: ${name}"
}

cmd_rollback() {
    log "Rolling back last migration..."
    
    if [ "$FORCE" = false ]; then
        echo ""
        echo -e "${RED}${BOLD}WARNING: This will rollback the last migration!${NC}"
        read -p "Continue? [y/N]: " confirm
        if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
            log "Rollback cancelled."
            exit 0
        fi
    fi
    
    ensure_postgres
    pre_migration_backup
    
    # Rollback using prisma migrate resolve
    docker run --rm \
        --network gff-backend_database \
        -v "${PROJECT_DIR}/prisma:/app/prisma:ro" \
        -e "DATABASE_URL=${DATABASE_URL}" \
        node:22-alpine \
        sh -c "npm install prisma@latest -g && npx prisma migrate resolve --rolled-back \$(npx prisma migrate status --schema=/app/prisma/schema.prisma | grep 'Migration name' | tail -1 | awk '{print \$3}') --schema=/app/prisma/schema.prisma"
    
    success "Rollback completed"
}

cmd_reset() {
    log "Resetting database..."
    
    if [ "$FORCE" = false ]; then
        echo ""
        echo -e "${RED}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo -e "${RED}${BOLD}  DANGER: DATABASE RESET${NC}"
        echo -e "${RED}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        echo ""
        echo -e "${RED}This will DELETE ALL DATA in the database!${NC}"
        echo ""
        read -p "Type 'DELETE ALL DATA' to confirm: " confirm
        
        if [ "$confirm" != "DELETE ALL DATA" ]; then
            log "Reset cancelled."
            exit 0
        fi
    fi
    
    ensure_postgres
    pre_migration_backup
    
    docker run --rm \
        --network gff-backend_database \
        -v "${PROJECT_DIR}/prisma:/app/prisma:ro" \
        -e "DATABASE_URL=${DATABASE_URL}" \
        node:22-alpine \
        sh -c "npm install prisma@latest -g && npx prisma migrate reset --force --schema=/app/prisma/schema.prisma"
    
    success "Database reset completed"
}

cmd_validate() {
    log "Validating schema..."
    
    docker run --rm \
        -v "${PROJECT_DIR}/prisma:/app/prisma:ro" \
        node:22-alpine \
        sh -c "npm install prisma@latest -g && npx prisma validate --schema=/app/prisma/schema.prisma"
    
    success "Schema is valid"
}

cmd_seed() {
    log "Running seed scripts..."
    
    ensure_postgres
    
    docker run --rm \
        --network gff-backend_database \
        -v "${PROJECT_DIR}:/app" \
        -e "DATABASE_URL=${DATABASE_URL}" \
        node:22-alpine \
        sh -c "cd /app && npm install && npx prisma db seed"
    
    success "Seed completed"
}

# =============================================================================
# Main
# =============================================================================
echo -e "${BOLD}GFF ERP - Database Migration${NC}"
echo "Command: ${COMMAND}"
echo ""

case "$COMMAND" in
    status)    cmd_status ;;
    deploy)    cmd_deploy ;;
    create)    cmd_create "${2:-migration}" ;;
    rollback)  cmd_rollback ;;
    reset)     cmd_reset ;;
    validate)  cmd_validate ;;
    seed)      cmd_seed ;;
    *)
        error "Unknown command: ${COMMAND}"
        echo "Run with --help for usage information"
        exit 1
        ;;
esac

success "Done!"