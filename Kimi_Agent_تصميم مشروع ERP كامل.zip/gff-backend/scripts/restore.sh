#!/bin/bash
# =============================================================================
# GFF ERP - Database Restore Script
# =============================================================================
# Restores PostgreSQL database from backup file
#
# Usage: ./scripts/restore.sh <backup_file> [OPTIONS]
#
# Options:
#   --force         Skip confirmation
#   --create-db     Create database if not exists
#   --drop-first    Drop and recreate database before restore
#   --download-s3   Download from S3 first (provide S3 path)
#
# Examples:
#   ./scripts/restore.sh ./backups/gff_erp_full_20240115_020000.sql.gz
#   ./scripts/restore.sh s3://bucket/2024/01/backup.sql.gz --download-s3
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date +'%H:%M:%S')] OK${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARN${NC} $1"; }
error() { echo -e "${RED}[$(date +'%H:%M:%S')] ERR${NC} $1"; }

# Parse arguments
BACKUP_FILE=""
FORCE=false
CREATE_DB=false
DROP_FIRST=false
DOWNLOAD_S3=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --force) FORCE=true; shift ;;
        --create-db) CREATE_DB=true; shift ;;
        --drop-first) DROP_FIRST=true; shift ;;
        --download-s3) DOWNLOAD_S3=true; shift ;;
        --help)
            echo "GFF ERP Database Restore"
            echo ""
            echo "Usage: ./scripts/restore.sh <backup_file> [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --force         Skip confirmation"
            echo "  --create-db     Create database if not exists"
            echo "  --drop-first    Drop and recreate database"
            echo "  --download-s3   Download from S3 first"
            echo "  --help          Show this help"
            echo ""
            echo "Examples:"
            echo "  ./scripts/restore.sh ./backups/gff_erp_full_20240115.sql.gz"
            echo "  ./scripts/restore.sh s3://bucket/backup.sql.gz --download-s3"
            exit 0
            ;;
        *)
            if [ -z "$BACKUP_FILE" ]; then
                BACKUP_FILE="$1"
            fi
            shift
            ;;
    esac
done

# Validate backup file
if [ -z "$BACKUP_FILE" ]; then
    error "No backup file specified!"
    echo "Usage: ./scripts/restore.sh <backup_file>"
    exit 1
fi

# Load environment
cd "${PROJECT_DIR}"
if [ -f .env.production ]; then
    source .env.production
elif [ -f .env ]; then
    source .env
fi

DB_PASSWORD="${DB_PASSWORD:-${POSTGRES_PASSWORD:-}}"
DB_USER="${DB_USER:-${POSTGRES_USER:-}}"
DB_NAME="${DB_NAME:-${POSTGRES_DB:-}}"

# =============================================================================
# Download from S3 if needed
# =============================================================================
if [ "$DOWNLOAD_S3" = true ]; then
    S3_PATH="$BACKUP_FILE"
    BACKUP_FILE="${PROJECT_DIR}/backups/$(basename "$S3_PATH")"
    
    log "Downloading from S3: ${S3_PATH}..."
    mkdir -p "${PROJECT_DIR}/backups"
    
    if command -v aws &> /dev/null; then
        aws s3 cp "$S3_PATH" "$BACKUP_FILE"
    else
        docker run --rm \
            -e AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-}" \
            -e AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-}" \
            -e AWS_REGION="${AWS_REGION:-us-east-1}" \
            -v "${PROJECT_DIR}/backups:/backups" \
            amazon/aws-cli:latest \
            s3 cp "$S3_PATH" "/backups/$(basename "$BACKUP_FILE")"
    fi
    
    success "Downloaded to ${BACKUP_FILE}"
fi

# Validate backup file exists
if [ ! -f "$BACKUP_FILE" ]; then
    error "Backup file not found: ${BACKUP_FILE}"
    exit 1
fi

# Get backup info
BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
IS_COMPRESSED=false
if [[ "$BACKUP_FILE" == *.gz ]]; then
    IS_COMPRESSED=true
fi

# =============================================================================
# Confirmation
# =============================================================================
if [ "$FORCE" = false ]; then
    echo ""
    echo -e "${RED}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${RED}${BOLD}  DATABASE RESTORE${NC}"
    echo -e "${RED}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "Database:    ${BOLD}${DB_NAME}${NC}"
    echo -e "Backup:      ${BOLD}${BACKUP_FILE}${NC}"
    echo -e "Size:        ${BOLD}${BACKUP_SIZE}${NC}"
    echo -e "Compressed:  ${BOLD}${IS_COMPRESSED}${NC}"
    echo ""
    echo -e "${YELLOW}WARNING: This will OVERWRITE the current database!${NC}"
    echo -e "${YELLOW}All current data will be lost!${NC}"
    echo ""
    
    if [ "$DROP_FIRST" = true ]; then
        echo -e "${RED}The database will be DROPPED and recreated!${NC}"
        echo ""
    fi
    
    read -p "Type 'RESTORE' to confirm: " confirm
    
    if [ "$confirm" != "RESTORE" ]; then
        log "Restore cancelled."
        exit 0
    fi
fi

# =============================================================================
# Pre-restore backup (safety net)
# =============================================================================
log "Creating safety backup before restore..."
SAFETY_BACKUP="${PROJECT_DIR}/backups/pre-restore-safety-$(date +%Y%m%d_%H%M%S).sql.gz"
mkdir -p "${PROJECT_DIR}/backups"

docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
    pg_dump -U "$DB_USER" -d "$DB_NAME" 2>/dev/null | gzip > "$SAFETY_BACKUP"

if [ -f "$SAFETY_BACKUP" ] && [ -s "$SAFETY_BACKUP" ]; then
    SAFETY_SIZE=$(du -h "$SAFETY_BACKUP" | cut -f1)
    success "Safety backup created: ${SAFETY_BACKUP} (${SAFETY_SIZE})"
else
    warn "Safety backup failed - continuing anyway"
fi

# =============================================================================
# Restore
# =============================================================================
log "Starting restore..."

# Ensure postgres is running
docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" up -d postgres

# Wait for postgres
for i in $(seq 1 30); do
    if docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres pg_isready -U "$DB_USER" > /dev/null 2>&1; then
        break
    fi
    sleep 1
done

# Drop and recreate if requested
if [ "$DROP_FIRST" = true ]; then
    log "Dropping and recreating database..."
    docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
        psql -U "$DB_USER" -d postgres -c "DROP DATABASE IF EXISTS ${DB_NAME};" 2>/dev/null || true
    docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
        psql -U "$DB_USER" -d postgres -c "CREATE DATABASE ${DB_NAME};" 2>/dev/null
    success "Database recreated"
fi

# Create database if not exists
if [ "$CREATE_DB" = true ]; then
    docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
        psql -U "$DB_USER" -d postgres -c "CREATE DATABASE ${DB_NAME};" 2>/dev/null || true
fi

# Restore from backup
log "Restoring from backup (this may take a while)..."

if [ "$IS_COMPRESSED" = true ]; then
    gunzip -c "$BACKUP_FILE" | \
        docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
        psql -U "$DB_USER" -d "$DB_NAME" 2>/dev/null
else
    docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
        psql -U "$DB_USER" -d "$DB_NAME" < "$BACKUP_FILE" 2>/dev/null
fi

# Verify
log "Verifying restore..."
TABLE_COUNT=$(docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
    psql -U "$DB_USER" -d "$DB_NAME" -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public';" 2>/dev/null | tr -d ' ')

success "Restore completed!"
echo "Tables restored: ${TABLE_COUNT}"

echo ""
echo "========================================"
echo "Restore Summary:"
echo "  Database:    ${DB_NAME}"
echo "  Backup:      ${BACKUP_FILE}"
echo "  Size:        ${BACKUP_SIZE}"
echo "  Tables:      ${TABLE_COUNT}"
echo "  Safety:      ${SAFETY_BACKUP}"
echo "========================================"