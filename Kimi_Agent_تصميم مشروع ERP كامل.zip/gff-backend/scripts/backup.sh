#!/bin/bash
# =============================================================================
# GFF ERP - Database Backup Script
# =============================================================================
# Creates compressed PostgreSQL backup and uploads to S3
#
# Usage: ./scripts/backup.sh [OPTIONS]
#
# Options:
#   --full          Full database backup (default)
#   --data-only     Data only, no schema
#   --schema-only   Schema only, no data
#   --upload-s3     Upload to S3 after backup
#   --retention N   Retention days (default: 30)
#   --output DIR    Output directory (default: ./backups)
#
# Cron: 0 2 * * * /opt/gff-erp/scripts/backup.sh --upload-s3
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

# Defaults
BACKUP_TYPE="full"
UPLOAD_S3=false
RETENTION_DAYS=30
OUTPUT_DIR="${PROJECT_DIR}/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
DATE=$(date +"%Y-%m-%d")

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date +'%H:%M:%S')] OK${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARN${NC} $1"; }
error() { echo -e "${RED}[$(date +'%H:%M:%S')] ERR${NC} $1"; }

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --full) BACKUP_TYPE="full"; shift ;;
        --data-only) BACKUP_TYPE="data-only"; shift ;;
        --schema-only) BACKUP_TYPE="schema-only"; shift ;;
        --upload-s3) UPLOAD_S3=true; shift ;;
        --retention) RETENTION_DAYS="$2"; shift 2 ;;
        --output) OUTPUT_DIR="$2"; shift 2 ;;
        --help)
            echo "GFF ERP Database Backup"
            echo ""
            echo "Usage: ./scripts/backup.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --full          Full database backup (default)"
            echo "  --data-only     Data only, no schema"
            echo "  --schema-only   Schema only, no data"
            echo "  --upload-s3     Upload to S3 after backup"
            echo "  --retention N   Retention days (default: 30)"
            echo "  --output DIR    Output directory"
            echo "  --help          Show this help"
            exit 0
            ;;
        *) shift ;;
    esac
done

# Load environment
cd "${PROJECT_DIR}"
if [ -f .env.production ]; then
    source .env.production
elif [ -f .env ]; then
    source .env
fi

DB_PASSWORD="${DB_PASSWORD:-${POSTGRES_PASSWORD:-}}"
DB_USER="${DB_USER:-${POSTGRES_USER:-}}"
DB_NAME="${DB_NAME:-${POSTGRES_DB:-}}"

# Validate
if [ -z "$DB_PASSWORD" ] || [ -z "$DB_USER" ] || [ -z "$DB_NAME" ]; then
    error "Database credentials not found. Set DB_USER, DB_PASSWORD, DB_NAME in .env"
    exit 1
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Build backup filename
BACKUP_FILE="${OUTPUT_DIR}/gff_erp_${BACKUP_TYPE}_${TIMESTAMP}.sql.gz"

# Build pg_dump options
PGDUMP_OPTS="--verbose --no-owner --no-privileges --encoding=UTF8"
case "$BACKUP_TYPE" in
    data-only) PGDUMP_OPTS="$PGDUMP_OPTS --data-only" ;;
    schema-only) PGDUMP_OPTS="$PGDUMP_OPTS --schema-only" ;;
    *) ;; # full: default
esac

# =============================================================================
# Create Backup
# =============================================================================
log "Starting ${BACKUP_TYPE} backup..."
log "Database: ${DB_NAME}"
log "Output: ${BACKUP_FILE}"

# Run pg_dump
docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
    pg_dump -U "$DB_USER" -d "$DB_NAME" $PGDUMP_OPTS 2>/dev/null | \
    gzip -9 > "$BACKUP_FILE"

if [ ! -f "$BACKUP_FILE" ] || [ ! -s "$BACKUP_FILE" ]; then
    error "Backup failed - output file is empty"
    exit 1
fi

BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
success "Backup created: ${BACKUP_FILE} (${BACKUP_SIZE})"

# Create checksum
cd "$OUTPUT_DIR"
sha256sum "$(basename "$BACKUP_FILE")" > "${BACKUP_FILE}.sha256"
success "Checksum: $(sha256sum "$BACKUP_FILE" | cut -d' ' -f1)"

# =============================================================================
# Upload to S3
# =============================================================================
if [ "$UPLOAD_S3" = true ]; then
    S3_BUCKET="${S3_BACKUP_BUCKET:-}"
    
    if [ -z "$S3_BUCKET" ] || [ -z "${AWS_ACCESS_KEY_ID:-}" ] || [ -z "${AWS_SECRET_ACCESS_KEY:-}" ]; then
        warn "S3 not configured, skipping upload"
    else
        log "Uploading to S3: ${S3_BUCKET}..."
        
        # Check AWS CLI
        if ! command -v aws &> /dev/null; then
            # Use Docker AWS CLI
            docker run --rm \
                -e AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY_ID" \
                -e AWS_SECRET_ACCESS_KEY="$AWS_SECRET_ACCESS_KEY" \
                -e AWS_REGION="${AWS_REGION:-us-east-1}" \
                -v "${OUTPUT_DIR}:/backups" \
                amazon/aws-cli:latest \
                s3 cp "/backups/$(basename "$BACKUP_FILE")" "s3://${S3_BUCKET}/$(date +%Y/%m)/$(basename "$BACKUP_FILE")" \
                --storage-class STANDARD_IA
        else
            aws s3 cp "$BACKUP_FILE" "s3://${S3_BUCKET}/$(date +%Y/%m)/$(basename "$BACKUP_FILE")" \
                --storage-class STANDARD_IA
        fi
        
        success "Backup uploaded to S3"
    fi
fi

# =============================================================================
# Cleanup old backups
# =============================================================================
log "Cleaning up backups older than ${RETENTION_DAYS} days..."

DELETED=$(find "$OUTPUT_DIR" -name "gff_erp_*.sql.gz" -type f -mtime +${RETENTION_DAYS} | wc -l)
find "$OUTPUT_DIR" -name "gff_erp_*.sql.gz" -type f -mtime +${RETENTION_DAYS} -delete
find "$OUTPUT_DIR" -name "gff_erp_*.sql.gz.sha256" -type f -mtime +${RETENTION_DAYS} -delete

success "Deleted ${DELETED} old backup(s)"

# =============================================================================
# Summary
# =============================================================================
echo ""
echo "========================================"
echo "Backup Summary:"
echo "  Type:        ${BACKUP_TYPE}"
echo "  Database:    ${DB_NAME}"
echo "  File:        ${BACKUP_FILE}"
echo "  Size:        ${BACKUP_SIZE}"
echo "  Checksum:    $(sha256sum "$BACKUP_FILE" | cut -d' ' -f1)"
echo "  Retention:   ${RETENTION_DAYS} days"
if [ "$UPLOAD_S3" = true ] && [ -n "${S3_BACKUP_BUCKET:-}" ]; then
    echo "  S3 Bucket:   ${S3_BACKUP_BUCKET}"
fi
echo "========================================"