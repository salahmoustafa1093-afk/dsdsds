#!/bin/bash
# =============================================================================
# GFF ERP - Production Deployment Script
# =============================================================================
# Production deployment with approval gate and blue-green deployment
#
# Usage: ./scripts/deploy-production.sh [VERSION] [--force]
#
# Features:
#   - Manual approval gate
#   - Blue-green deployment
#   - Database migrations with backup
#   - Health checks and rollback
#   - Slack notifications
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
VERSION="${1:-latest}"
FORCE=false
SLACK_WEBHOOK="${SLACK_WEBHOOK_URL:-}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log() { echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $1"; }
success() { echo -e "${GREEN}[$(date +'%H:%M:%S')] OK${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARN${NC} $1"; }
error() { echo -e "${RED}[$(date +'%H:%M:%S')] ERR${NC} $1"; }

# Parse args
if [ "${2:-}" = "--force" ]; then
    FORCE=true
fi

# =============================================================================
# Pre-deployment checks
# =============================================================================
pre_deployment_checks() {
    log "Running pre-deployment checks..."
    
    # Check if .env.production exists
    if [ ! -f "${PROJECT_DIR}/.env.production" ]; then
        error ".env.production not found!"
        exit 1
    fi
    
    # Check Docker
    if ! docker info > /dev/null 2>&1; then
        error "Docker is not running!"
        exit 1
    fi
    
    # Check disk space
    local disk_usage
    disk_usage=$(df / | awk 'NR==2 {print $5}' | tr -d '%')
    if [ "$disk_usage" -gt 85 ]; then
        error "Disk usage is ${disk_usage}%. Free up space before deploying."
        exit 1
    fi
    
    # Check current health
    local current_health
    current_health=$(curl -sf -o /dev/null -w "%{http_code}" https://gff-erp.com/api/v1/health 2>/dev/null || echo "000")
    if [ "$current_health" != "200" ]; then
        warn "Current production health check returned HTTP ${current_health}"
        if [ "$FORCE" = false ]; then
            read -p "Production is not healthy. Continue anyway? [y/N]: " confirm
            if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
                log "Deployment cancelled."
                exit 0
            fi
        fi
    fi
    
    success "Pre-deployment checks passed"
}

# =============================================================================
# Approval Gate
# =============================================================================
approval_gate() {
    if [ "$FORCE" = true ]; then
        warn "Force mode - skipping approval gate"
        return 0
    fi
    
    echo ""
    echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}${BOLD}  PRODUCTION DEPLOYMENT APPROVAL${NC}"
    echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo -e "Version:    ${BOLD}${VERSION}${NC}"
    echo -e "Branch:     ${BOLD}$(git branch --show-current)${NC}"
    echo -e "Commit:     ${BOLD}$(git rev-parse --short HEAD)${NC}"
    echo -e "Committer:  ${BOLD}$(git log -1 --pretty=format:'%an <%ae>')${NC}"
    echo -e "Message:    ${BOLD}$(git log -1 --pretty=format:'%s')${NC}"
    echo ""
    echo -e "${YELLOW}This will deploy to PRODUCTION environment!${NC}"
    echo ""
    
    read -p "Type 'deploy' to confirm: " confirm
    
    if [ "$confirm" != "deploy" ]; then
        log "Deployment cancelled."
        exit 0
    fi
    
    success "Deployment approved"
}

# =============================================================================
# Backup before deployment
# =============================================================================
pre_deploy_backup() {
    log "Creating pre-deployment backup..."
    
    local backup_file="${PROJECT_DIR}/backups/pre-deploy-$(date +%Y%m%d-%H%M%S).sql.gz"
    mkdir -p "${PROJECT_DIR}/backups"
    
    # Get DB credentials from .env
    local db_url
    db_url=$(grep DATABASE_URL "${PROJECT_DIR}/.env.production" | cut -d= -f2-)
    
    # Extract components from DATABASE_URL
    docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" exec -T postgres \
        pg_dump -U gff_prod -d gff_erp_production --verbose 2>/dev/null | \
        gzip > "$backup_file"
    
    if [ -f "$backup_file" ] && [ -s "$backup_file" ]; then
        local size
        size=$(du -h "$backup_file" | cut -f1)
        success "Pre-deployment backup created: ${backup_file} (${size})"
    else
        warn "Backup file is empty or not created"
        if [ "$FORCE" = false ]; then
            read -p "Continue without backup? [y/N]: " confirm
            if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
                exit 1
            fi
        fi
    fi
}

# =============================================================================
# Deploy
# =============================================================================
deploy() {
    log "Starting production deployment..."
    
    cd "${PROJECT_DIR}"
    
    # Copy production env
    cp .env.production .env
    export VERSION
    
    # Pull images
    log "Pulling images..."
    docker pull "ghcr.io/gff-erp/backend:${VERSION}" || {
        error "Failed to pull backend image: ${VERSION}"
        exit 1
    }
    
    # Run migrations first
    log "Running database migrations..."
    docker compose -f docker/docker-compose.prod.yml up -d postgres redis
    
    # Wait for postgres
    for i in $(seq 1 30); do
        if docker compose -f docker/docker-compose.prod.yml exec -T postgres pg_isready -U gff_prod > /dev/null 2>&1; then
            break
        fi
        sleep 1
    done
    
    # Run migrations in a temporary container
    docker run --rm \
        --network gff-backend_database \
        -v "${PROJECT_DIR}/prisma:/app/prisma:ro" \
        -e "DATABASE_URL=$(grep DATABASE_URL .env | cut -d= -f2-)" \
        "ghcr.io/gff-erp/backend:${VERSION}" \
        npx prisma migrate deploy
    
    success "Migrations completed"
    
    # Deploy with zero-downtime
    log "Deploying application..."
    
    # Update one replica at a time
    docker compose -f docker/docker-compose.prod.yml up -d backend-api-1
    sleep 10
    
    local health1
    health1=$(curl -sf -o /dev/null -w "%{http_code}" http://localhost:3001/api/v1/health || echo "000")
    if [ "$health1" != "200" ]; then
        error "Backend API 1 failed health check"
        rollback
        exit 1
    fi
    
    docker compose -f docker/docker-compose.prod.yml up -d backend-api-2
    sleep 5
    docker compose -f docker/docker-compose.prod.yml up -d backend-api-3
    
    # Update nginx
    docker compose -f docker/docker-compose.prod.yml up -d nginx
    
    success "Deployment completed"
}

# =============================================================================
# Post-deployment verification
# =============================================================================
post_deploy_verify() {
    log "Running post-deployment verification..."
    
    sleep 15
    
    # Health checks
    local health_status
    health_status=$(curl -sf -o /dev/null -w "%{http_code}" https://gff-erp.com/api/v1/health || echo "000")
    
    local ready_status
    ready_status=$(curl -sf -o /dev/null -w "%{http_code}" https://gff-erp.com/api/v1/health/ready || echo "000")
    
    log "Health: HTTP ${health_status}, Ready: HTTP ${ready_status}"
    
    if [ "$health_status" = "200" ] && [ "$ready_status" = "200" ]; then
        success "Post-deployment verification passed!"
        
        # Notify success
        if [ -n "$SLACK_WEBHOOK" ]; then
            curl -s -X POST "$SLACK_WEBHOOK" \
                -H 'Content-type: application/json' \
                -d "{\"text\":\":rocket: Production deployment successful! Version: ${VERSION}\"}" > /dev/null || true
        fi
        
        return 0
    else
        error "Post-deployment verification FAILED!"
        return 1
    fi
}

# =============================================================================
# Rollback
# =============================================================================
rollback() {
    error "Initiating rollback..."
    
    # Get previous version from docker images
    local previous_version
    previous_version=$(docker images ghcr.io/gff-erp/backend --format '{{.Tag}}' | grep -v "${VERSION}" | grep -v "latest" | head -1)
    
    if [ -n "$previous_version" ]; then
        log "Rolling back to version: ${previous_version}"
        export VERSION="${previous_version}"
        docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" up -d
        success "Rolled back to ${previous_version}"
    else
        # Last resort: restart current containers
        warn "No previous version found, restarting current containers..."
        docker compose -f "${PROJECT_DIR}/docker/docker-compose.prod.yml" restart
    fi
    
    # Notify failure
    if [ -n "$SLACK_WEBHOOK" ]; then
        curl -s -X POST "$SLACK_WEBHOOK" \
            -H 'Content-type: application/json' \
            -d "{\"text\":\":warning: Production deployment FAILED and was rolled back! Version: ${VERSION}\"}" > /dev/null || true
    fi
}

# =============================================================================
# Main
# =============================================================================
main() {
    echo -e "${BOLD}GFF ERP - Production Deployment${NC}"
    echo "================================="
    echo "Version: ${VERSION}"
    echo "Force: ${FORCE}"
    echo ""
    
    pre_deployment_checks
    approval_gate
    pre_deploy_backup
    deploy
    
    if ! post_deploy_verify; then
        rollback
        exit 1
    fi
    
    echo ""
    success "Production deployment completed successfully!"
    echo ""
    echo -e "${BOLD}Production Environment:${NC}"
    echo "  URL: https://gff-erp.com"
    echo "  API: https://gff-erp.com/api/v1"
    echo "  Health: https://gff-erp.com/api/v1/health"
    echo ""
}

main "$@"