#!/usr/bin/env bash
# =============================================================================
# GFF Backend — Coverage Check Script
# =============================================================================
# Runs Jest with coverage collection and validates against 80% threshold.
# Generates badge data for README.md integration.
#
# Usage:   bash test/coverage-check.sh
# Output:  Console summary, coverage badge JSON, exit code 0/1
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
COVERAGE_DIR="${PROJECT_ROOT}/coverage"
SUMMARY_FILE="${COVERAGE_DIR}/coverage-summary.json"
BADGE_FILE="${PROJECT_ROOT}/test/coverage-badge.json"
REPORT_FILE="${PROJECT_ROOT}/test/coverage-report.html"
THRESHOLD="${COVERAGE_THRESHOLD:-80}"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
RESET='\033[0m'

echo "================================================================="
echo "  GFF Backend — Test Coverage Check"
echo "  Threshold: ${THRESHOLD}%"
echo "  Time:      ${TIMESTAMP}"
echo "================================================================="
echo ""

# Step 1: Run Jest with coverage
echo -e "${BLUE}[1/4] Running Jest with coverage...${RESET}"
rm -rf "${COVERAGE_DIR}"

if ! command -v npx &>/dev/null; then
  echo -e "${RED}ERROR: npx not found. Install Node.js and npm.${RESET}"
  exit 1
fi

# Run jest with coverage and json-summary reporter
if ! npx jest \
  --coverage \
  --coverageReporters=json-summary \
  --coverageReporters=text \
  --coverageReporters=html \
  --coverageDirectory="${COVERAGE_DIR}" \
  --no-coverageReporters=json; then
  echo -e "${RED}Tests failed! Fix failing tests before checking coverage.${RESET}"
  exit 1
fi

echo ""

# Step 2: Parse coverage summary
echo -e "${BLUE}[2/4] Parsing coverage summary...${RESET}"

if [[ ! -f "${SUMMARY_FILE}" ]]; then
  echo -e "${RED}ERROR: Coverage summary not found at ${SUMMARY_FILE}${RESET}"
  exit 1
fi

# Extract metrics using Node.js (more reliable than jq)
read -r STATEMENTS_PCT BRANCHES_PCT FUNCTIONS_PCT LINES_PCT OVERALL_PCT << EOF
$(node -e "
const data = require('${SUMMARY_FILE}');
const t = data.total;
const pct = (m) => m.total === 0 ? 100 : Math.round((m.covered / m.total) * 10000) / 100;
const s = pct(t.statements);
const b = pct(t.branches);
const f = pct(t.functions);
const l = pct(t.lines);
const o = Math.round((s + b + f + l) / 4 * 100) / 100;
console.log(s + ' ' + b + ' ' + f + ' ' + l + ' ' + o);
")
EOF

echo "  Statements: ${STATEMENTS_PCT}%"
echo "  Branches:   ${BRANCHES_PCT}%"
echo "  Functions:  ${FUNCTIONS_PCT}%"
echo "  Lines:      ${LINES_PCT}%"
echo "  Overall:    ${OVERALL_PCT}%"
echo ""

# Step 3: Validate against threshold
echo -e "${BLUE}[3/4] Validating against ${THRESHOLD}% threshold...${RESET}"

FAILED_METRICS=()

if (( $(echo "${STATEMENTS_PCT} < ${THRESHOLD}" | bc -l) )); then
  FAILED_METRICS+=("statements (${STATEMENTS_PCT}%)")
fi
if (( $(echo "${BRANCHES_PCT} < ${THRESHOLD}" | bc -l) )); then
  FAILED_METRICS+=("branches (${BRANCHES_PCT}%)")
fi
if (( $(echo "${FUNCTIONS_PCT} < ${THRESHOLD}" | bc -l) )); then
  FAILED_METRICS+=("functions (${FUNCTIONS_PCT}%)")
fi
if (( $(echo "${LINES_PCT} < ${THRESHOLD}" | bc -l) )); then
  FAILED_METRICS+=("lines (${LINES_PCT}%)")
fi

if [[ ${#FAILED_METRICS[@]} -gt 0 ]]; then
  echo ""
  echo -e "${RED}${BOLD}FAILED — Coverage below ${THRESHOLD}% threshold:${RESET}"
  for metric in "${FAILED_METRICS[@]}"; do
    echo -e "  ${RED}✗ ${metric}${RESET}"
  done
  echo ""
  PASSED=false
else
  echo -e "  ${GREEN}${BOLD}✓ All metrics above ${THRESHOLD}% threshold${RESET}"
  echo ""
  PASSED=true
fi

# Step 4: Generate badge data
echo -e "${BLUE}[4/4] Generating badge data...${RESET}"

# Determine badge color
if (( $(echo "${OVERALL_PCT} >= 90" | bc -l) )); then
  BADGE_COLOR="brightgreen"
elif (( $(echo "${OVERALL_PCT} >= ${THRESHOLD}" | bc -l) )); then
  BADGE_COLOR="green"
elif (( $(echo "${OVERALL_PCT} >= 60" | bc -l) )); then
  BADGE_COLOR="yellow"
else
  BADGE_COLOR="red"
fi

cat > "${BADGE_FILE}" << EOF
{
  "schemaVersion": 1,
  "label": "coverage",
  "message": "${OVERALL_PCT}%",
  "color": "${BADGE_COLOR}",
  "namedLogo": "jest",
  "timestamp": "${TIMESTAMP}",
  "details": {
    "statements": ${STATEMENTS_PCT},
    "branches": ${BRANCHES_PCT},
    "functions": ${FUNCTIONS_PCT},
    "lines": ${LINES_PCT},
    "overall": ${OVERALL_PCT},
    "threshold": ${THRESHOLD},
    "passed": ${PASSED}
  }
}
EOF

echo "  Badge data: ${BADGE_FILE}"

# Generate shields.io URL
echo "  Shields URL: https://img.shields.io/badge/coverage-${OVERALL_PCT}%25-${BADGE_COLOR}"

# Generate markdown badge
echo "  Markdown:    ![Coverage](https://img.shields.io/badge/coverage-${OVERALL_PCT}%25-${BADGE_COLOR})"
echo ""

# Generate HTML report using the custom reporter
echo -e "${BLUE}[Bonus] Generating HTML coverage report...${RESET}"
node "${PROJECT_ROOT}/test/coverage-reporter.js" "${SUMMARY_FILE}" "${REPORT_FILE}" || true
echo ""

# Final summary
echo "================================================================="
echo "  Coverage Check Summary"
echo "================================================================="
if [[ "${PASSED}" == "true" ]]; then
  echo -e "  Status:   ${GREEN}${BOLD}PASSED${RESET}"
else
  echo -e "  Status:   ${RED}${BOLD}FAILED${RESET}"
fi
echo "  Overall:  ${OVERALL_PCT}%"
echo "  Grade:    $(${PASSED} && echo -e "${GREEN}" || echo -e "${YELLOW}")$(${PASSED} && echo "B+" || echo "C")${RESET}"
echo "================================================================="
echo ""

# Exit code
if [[ "${PASSED}" == "true" ]]; then
  exit 0
else
  exit 1
fi
