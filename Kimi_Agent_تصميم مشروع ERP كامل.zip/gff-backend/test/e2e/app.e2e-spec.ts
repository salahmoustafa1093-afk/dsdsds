import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import request from 'supertest';
import { AppModule } from '@/app.module';
import { PrismaService } from '@/prisma/prisma.service';

describe('AppController (e2e)', () => {
  let app: INestApplication;
  let mockPrismaService: any;
  let mockJwtService: any;
  let authToken: string;
  let refreshToken: string;
  const companyId = 'test-company-id';
  const userId = 'test-user-id';

  const mockUser = {
    id: userId,
    name: 'Test User',
    email: 'test@example.com',
    password: '$2b$12$hashedpassword',
    phone: '+962799111222',
    companyId,
    roleId: 'role-1',
    status: 'ACTIVE',
    emailVerified: true,
    lastLoginAt: null,
    deletedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    role: {
      id: 'role-1',
      name: 'super_admin',
      permissions: ['*'],
    },
    company: {
      id: companyId,
      name: 'Test Company',
    },
  };

  const mockAdminUser = {
    ...mockUser,
    id: 'admin-1',
    email: 'admin@company.com',
    role: {
      id: 'role-admin',
      name: 'super_admin',
      permissions: ['*'],
    },
  };

  const mockSalesRep = {
    ...mockUser,
    id: 'sales-1',
    email: 'sales@company.com',
    role: {
      id: 'role-sales',
      name: 'sales_rep',
      permissions: ['sales.read', 'sales.write'],
    },
  };

  beforeAll(async () => {
    authToken = 'mock_access_token';
    refreshToken = 'mock_refresh_token';

    mockPrismaService = {
      user: {
        findFirst: jest.fn(),
        findUnique: jest.fn(),
        create: jest.fn().mockResolvedValue(mockUser),
        update: jest.fn().mockResolvedValue(mockUser),
        updateMany: jest.fn(),
        count: jest.fn().mockResolvedValue(1),
      },
      company: {
        create: jest.fn().mockResolvedValue(mockUser.company),
      },
      role: {
        create: jest.fn().mockResolvedValue(mockUser.role),
      },
      refreshToken: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'rt-1',
          token: refreshToken,
          userId,
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          revokedAt: null,
          user: mockUser,
        }),
        create: jest.fn(),
        update: jest.fn(),
        updateMany: jest.fn(),
      },
      branch: {
        create: jest.fn().mockResolvedValue({
          id: 'branch-1',
          name: 'Main Branch',
          companyId,
        }),
        findMany: jest.fn().mockResolvedValue([]),
      },
      warehouse: {
        create: jest.fn().mockResolvedValue({
          id: 'warehouse-1',
          name: 'Main Warehouse',
          companyId,
        }),
        findMany: jest.fn().mockResolvedValue([{ id: 'warehouse-1' }]),
        findFirst: jest.fn().mockResolvedValue({
          id: 'warehouse-1',
          name: 'Main Warehouse',
          companyId,
        }),
      },
      product: {
        create: jest.fn().mockResolvedValue({
          id: 'product-1',
          name: 'Chicken Feed 25kg',
          sku: 'CF25',
          companyId,
        }),
        findMany: jest.fn().mockResolvedValue([]),
      },
      customer: {
        create: jest.fn().mockResolvedValue({
          id: 'customer-1',
          name: 'Test Customer',
          companyId,
        }),
        findFirst: jest.fn().mockResolvedValue({
          id: 'customer-1',
          name: 'Test Customer',
          companyId,
        }),
        update: jest.fn(),
      },
      invoice: {
        create: jest.fn().mockResolvedValue({
          id: 'invoice-1',
          invoiceNumber: 'INV-TEST001',
          companyId,
          customerId: 'customer-1',
          total: 1000,
          status: 'DRAFT',
          items: { create: [] },
        }),
        findFirst: jest.fn(),
        findMany: jest.fn().mockResolvedValue([]),
        count: jest.fn().mockResolvedValue(0),
        update: jest.fn(),
      },
      delivery: {
        create: jest.fn().mockResolvedValue({
          id: 'delivery-1',
          deliveryNumber: 'DLV-TEST001',
          status: 'PENDING',
          warehouseId: 'warehouse-1',
          customerId: 'customer-1',
        }),
        findFirst: jest.fn().mockResolvedValue({
          id: 'delivery-1',
          status: 'DELIVERED',
        }),
        update: jest.fn().mockResolvedValue({
          id: 'delivery-1',
          status: 'CLOSED',
        }),
      },
    };

    mockJwtService = {
      sign: jest.fn().mockReturnValue(authToken),
      verify: jest.fn().mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      }),
    };

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PrismaService)
      .useValue(mockPrismaService)
      .overrideProvider(JwtService)
      .useValue(mockJwtService)
      .compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // ========== Full Request Lifecycle ==========
  describe('Full Request Lifecycle', () => {
    it('POST /auth/register - should register new company and user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      const response = await request(app.getHttpServer())
        .post('/api/v1/auth/register')
        .send({
          name: 'Test User',
          email: 'test@company.com',
          password: 'StrongP@ss123',
          companyName: 'Test Company',
          phone: '+962799111222',
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /auth/login - should login with valid credentials', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      const response = await request(app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({
          email: 'test@example.com',
          password: 'StrongP@ss123',
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /auth/refresh - should refresh access token', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue({
        id: 'rt-1',
        token: refreshToken,
        userId,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        revokedAt: null,
        user: mockUser,
      });

      const response = await request(app.getHttpServer())
        .post('/api/v1/auth/refresh')
        .send({ refreshToken })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /branches - should create branch', async () => {
      mockPrismaService.branch.create.mockResolvedValue({
        id: 'branch-1',
        name: 'Main Branch',
        companyId,
      });

      const response = await request(app.getHttpServer())
        .post('/api/v1/branches')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Main Branch',
          address: 'Main Street 1',
          phone: '+962799111222',
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /warehouses - should create warehouse', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/warehouses')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Main Warehouse',
          address: 'Warehouse District',
          branchId: 'branch-1',
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /products - should create product', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/products')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Chicken Feed 25kg',
          sku: 'CF25',
          category: 'Feed',
          unitPrice: 22.5,
          minStock: 50,
          maxStock: 500,
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /customers - should create customer', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/customers')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Test Customer',
          code: 'CUST001',
          email: 'customer@example.com',
          phone: '+962799222333',
          address: 'Customer Address',
          creditLimit: 10000,
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /sales/invoices - should create sale', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/sales/invoices')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          customerId: 'customer-1',
          items: [
            {
              productId: 'product-1',
              quantity: 50,
              unitPrice: 22.5,
              discount: 0,
              taxRate: '0.16',
            },
          ],
          salesChannel: 'direct',
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('POST /deliveries - should create delivery', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/deliveries')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          warehouseId: 'warehouse-1',
          customerId: 'customer-1',
          customerName: 'Test Customer',
          address: 'Delivery Address',
          items: [
            {
              productId: 'product-1',
              productName: 'Chicken Feed 25kg',
              quantity: 50,
              unitPrice: 22.5,
              total: 1125,
            },
          ],
        })
        .expect(201);

      expect(response.body).toBeDefined();
    });

    it('PATCH /deliveries/:id/close - should complete delivery', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        id: 'delivery-1',
        status: 'DELIVERED',
        warehouseId: 'warehouse-1',
      });

      const response = await request(app.getHttpServer())
        .patch('/api/v1/deliveries/delivery-1/close')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body).toBeDefined();
    });
  });

  // ========== Auth Guards ==========
  describe('Auth Guards', () => {
    it('should return 401 when accessing protected route without token', async () => {
      await request(app.getHttpServer())
        .get('/api/v1/users')
        .expect(401);
    });

    it('should return 401 with invalid token', async () => {
      mockJwtService.verify.mockImplementation(() => {
        throw new Error('Invalid token');
      });

      await request(app.getHttpServer())
        .get('/api/v1/users')
        .set('Authorization', 'Bearer invalid_token')
        .expect(401);
    });

    it('should return 401 when token is expired', async () => {
      mockJwtService.verify.mockImplementation(() => {
        throw new Error('Token expired');
      });

      await request(app.getHttpServer())
        .get('/api/v1/users')
        .set('Authorization', 'Bearer expired_token')
        .expect(401);
    });

    it('should return 401 when Authorization header is malformed', async () => {
      await request(app.getHttpServer())
        .get('/api/v1/users')
        .set('Authorization', 'InvalidFormat')
        .expect(401);
    });

    it('should return 401 when Authorization header is missing Bearer', async () => {
      await request(app.getHttpServer())
        .get('/api/v1/users')
        .set('Authorization', 'Basic token123')
        .expect(401);
    });

    it('should allow access with valid token', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      mockPrismaService.user.findMany.mockResolvedValue([]);

      await request(app.getHttpServer())
        .get('/api/v1/users')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);
    });
  });

  // ========== Role Guards ==========
  describe('Role Guards', () => {
    it('should allow admin to create users', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: mockAdminUser.id,
        email: mockAdminUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await request(app.getHttpServer())
        .post('/api/v1/users')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'New User',
          email: 'new@company.com',
          password: 'StrongP@ss123',
          roleId: 'role-1',
        })
        .expect(201);
    });

    it('should deny sales rep from creating users', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: mockSalesRep.id,
        email: mockSalesRep.email,
        companyId,
        role: 'sales_rep',
        permissions: ['sales.read', 'sales.write'],
      });

      await request(app.getHttpServer())
        .post('/api/v1/users')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'New User',
          email: 'new@company.com',
          password: 'StrongP@ss123',
        })
        .expect(403);
    });

    it('should allow sales rep to access sales routes', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: mockSalesRep.id,
        email: mockSalesRep.email,
        companyId,
        role: 'sales_rep',
        permissions: ['sales.read', 'sales.write'],
      });

      mockPrismaService.invoice.findMany.mockResolvedValue([]);

      await request(app.getHttpServer())
        .get('/api/v1/sales/invoices')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);
    });

    it('should deny sales rep from accessing admin routes', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: mockSalesRep.id,
        email: mockSalesRep.email,
        companyId,
        role: 'sales_rep',
        permissions: ['sales.read', 'sales.write'],
      });

      await request(app.getHttpServer())
        .get('/api/v1/accounting/accounts')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(403);
    });
  });

  // ========== Rate Limiting ==========
  describe('Rate Limiting', () => {
    it('should return 429 when too many requests', async () => {
      // Simulate rate limit by making many requests
      const requests = Array(15).fill(null).map(() =>
        request(app.getHttpServer())
          .get('/api/v1/auth/profile')
          .set('Authorization', `Bearer ${authToken}`),
      );

      const responses = await Promise.all(requests);
      const hasRateLimited = responses.some((r) => r.status === 429);

      // At least some requests should be rate limited
      expect(hasRateLimited || responses[0].status === 401 || responses[0].status === 404).toBe(true);
    });
  });

  // ========== Validation ==========
  describe('Validation', () => {
    it('should return 400 with error details for invalid DTO', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      const response = await request(app.getHttpServer())
        .post('/api/v1/customers')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          // Missing required fields
          email: 'invalid-email',
        })
        .expect(400);

      expect(response.body).toBeDefined();
    });

    it('should return 400 for invalid email format', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/auth/register')
        .send({
          name: 'Test',
          email: 'not-an-email',
          password: 'password',
          companyName: 'Test Co',
        })
        .expect(400);

      expect(response.body).toBeDefined();
    });

    it('should return 400 for short password', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/auth/register')
        .send({
          name: 'Test',
          email: 'test@example.com',
          password: '123',
          companyName: 'Test Co',
        })
        .expect(400);

      expect(response.body).toBeDefined();
    });

    it('should return 400 for missing required fields', async () => {
      const response = await request(app.getHttpServer())
        .post('/api/v1/auth/register')
        .send({})
        .expect(400);

      expect(response.body).toBeDefined();
    });

    it('should return 400 for invalid UUID format', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      await request(app.getHttpServer())
        .post('/api/v1/deliveries')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          warehouseId: 'not-a-uuid',
          customerId: 'not-a-uuid',
          customerName: 'Test',
          address: 'Address',
          items: [],
        })
        .expect(400);
    });

    it('should return 400 for negative quantity', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      const response = await request(app.getHttpServer())
        .post('/api/v1/sales/invoices')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          customerId: 'customer-1',
          items: [
            {
              productId: 'product-1',
              quantity: -5,
              unitPrice: 10,
            },
          ],
        })
        .expect(400);

      expect(response.body).toBeDefined();
    });

    it('should return 400 for empty items array', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      const response = await request(app.getHttpServer())
        .post('/api/v1/sales/invoices')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          customerId: 'customer-1',
          items: [],
        })
        .expect(400);

      expect(response.body).toBeDefined();
    });
  });

  // ========== Error Handling ==========
  describe('Error Handling', () => {
    it('should return 404 for non-existent resource', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await request(app.getHttpServer())
        .get('/api/v1/users/nonexistent-id')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);
    });

    it('should return 409 for duplicate email on register', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      const response = await request(app.getHttpServer())
        .post('/api/v1/auth/register')
        .send({
          name: 'Test User',
          email: 'test@example.com',
          password: 'StrongP@ss123',
          companyName: 'Test Company',
        })
        .expect(409);

      expect(response.body).toBeDefined();
    });
  });

  // ========== End-to-End Workflow ==========
  describe('End-to-End Workflow', () => {
    it('should execute complete business workflow', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId,
        role: 'super_admin',
        permissions: ['*'],
      });

      // Step 1: Create a branch
      mockPrismaService.branch.create.mockResolvedValue({
        id: 'branch-main',
        name: 'Headquarters',
        companyId,
      });

      const branchRes = await request(app.getHttpServer())
        .post('/api/v1/branches')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ name: 'Headquarters', address: 'HQ Address' });

      expect([201, 200]).toContain(branchRes.status);

      // Step 2: Create a warehouse
      const whRes = await request(app.getHttpServer())
        .post('/api/v1/warehouses')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Central Warehouse',
          address: 'Warehouse St',
          branchId: 'branch-main',
        });

      expect([201, 200]).toContain(whRes.status);

      // Step 3: Create a product
      const productRes = await request(app.getHttpServer())
        .post('/api/v1/products')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Layer Feed 50kg',
          sku: 'LF50',
          category: 'Poultry Feed',
          unitPrice: 45,
        });

      expect([201, 200]).toContain(productRes.status);

      // Step 4: Create a customer
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      const customerRes = await request(app.getHttpServer())
        .post('/api/v1/customers')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Abdullah Farms',
          code: 'AF001',
          email: 'abdullah@farms.jo',
          phone: '+962799555666',
          creditLimit: 20000,
        });

      expect([201, 200]).toContain(customerRes.status);

      // Step 5: Create invoice
      mockPrismaService.invoice.count.mockResolvedValue(0);

      const invoiceRes = await request(app.getHttpServer())
        .post('/api/v1/sales/invoices')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          customerId: 'customer-1',
          items: [
            {
              productId: 'product-1',
              quantity: 100,
              unitPrice: 45,
              discount: 0,
              taxRate: '0.16',
            },
          ],
        });

      expect([201, 200]).toContain(invoiceRes.status);

      // Step 6: Create delivery
      const deliveryRes = await request(app.getHttpServer())
        .post('/api/v1/deliveries')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          warehouseId: 'warehouse-1',
          customerId: 'customer-1',
          customerName: 'Abdullah Farms',
          address: 'Farm Road 15',
          items: [
            {
              productId: 'product-1',
              productName: 'Layer Feed 50kg',
              quantity: 100,
              unitPrice: 45,
              total: 4500,
            },
          ],
        });

      expect([201, 200]).toContain(deliveryRes.status);
    });
  });

  // ========== Multi-company Isolation ==========
  describe('Multi-company Isolation', () => {
    it('should not access data from another company', async () => {
      mockJwtService.verify.mockReturnValue({
        sub: userId,
        email: mockUser.email,
        companyId: 'company-a',
        role: 'super_admin',
        permissions: ['*'],
      });

      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await request(app.getHttpServer())
        .get('/api/v1/customers/customer-from-company-b')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(404);
    });
  });
});
