#!/usr/bin/env node
// =============================================================================
// GFF Backend — Custom Coverage Reporter
// =============================================================================
// Reads Jest coverage JSON output and generates an HTML report with:
//   - Overall coverage percentage
//   - Coverage per module (statements, branches, functions, lines)
//   - Uncovered lines highlighted
//   - Coverage trend (if previous report exists)
//   - Minimum threshold enforcement (80%)
//
// Usage:
//   node test/coverage-reporter.js [coverage-summary-json] [output-html]
//
// Arguments:
//   coverage-summary-json   Path to coverage-summary.json (default: coverage/coverage-summary.json)
//   output-html             Path for output HTML (default: test/coverage-report.html)
//
// Exit codes:
//   0 — All metrics above threshold
//   1 — One or more metrics below threshold
// =============================================================================

const fs = require('fs');
const path = require('path');

// ─── Configuration ──────────────────────────────────────────────────────────
const COVERAGE_FILE = process.argv[2] || 'coverage/coverage-summary.json';
const OUTPUT_HTML = process.argv[3] || 'test/coverage-report.html';
const PREVIOUS_REPORT = 'test/coverage-previous.json';
const THRESHOLD = parseFloat(process.env.COVERAGE_THRESHOLD || '80');

const COLORS = {
  excellent: '#059669', // >= 90%
  good: '#2563eb',      // >= 80%
  warning: '#d97706',   // >= 60%
  danger: '#dc2626',    // < 60%
};

// ─── Helpers ────────────────────────────────────────────────────────────────

function getColor(percentage) {
  if (percentage >= 90) return COLORS.excellent;
  if (percentage >= THRESHOLD) return COLORS.good;
  if (percentage >= 60) return COLORS.warning;
  return COLORS.danger;
}

function getGrade(percentage) {
  if (percentage >= 95) return 'A+';
  if (percentage >= 90) return 'A';
  if (percentage >= 85) return 'B+';
  if (percentage >= THRESHOLD) return 'B';
  if (percentage >= 70) return 'C';
  if (percentage >= 60) return 'D';
  return 'F';
}

function formatPct(pct) {
  return `${pct.toFixed(2)}%`;
}

function formatNum(num) {
  return num.toLocaleString();
}

/**
 * Calculate coverage percentage from total/covered.
 */
function calcPct(total, covered) {
  if (total === 0) return 100;
  return (covered / total) * 100;
}

/**
 * Read previous report for trend comparison.
 */
function readPreviousReport() {
  try {
    const data = fs.readFileSync(PREVIOUS_REPORT, 'utf8');
    return JSON.parse(data);
  } catch {
    return null;
  }
}

/**
 * Save current report for future trend comparison.
 */
function saveCurrentReport(summary) {
  try {
    fs.mkdirSync(path.dirname(PREVIOUS_REPORT), { recursive: true });
    fs.writeFileSync(PREVIOUS_REPORT, JSON.stringify(summary, null, 2));
  } catch (err) {
    console.warn(`Warning: Could not save previous report: ${err.message}`);
  }
}

/**
 * Format trend indicator with arrow and color.
 */
function formatTrend(current, previous) {
  if (!previous || previous === current) {
    return '<span style="color:#6b7280">—</span>';
  }
  const diff = current - previous;
  const arrow = diff > 0 ? '↑' : '↓';
  const color = diff > 0 ? COLORS.excellent : diff > -5 ? COLORS.warning : COLORS.danger;
  const sign = diff > 0 ? '+' : '';
  return `<span style="color:${color};font-weight:bold">${arrow} ${sign}${diff.toFixed(2)}%</span>`;
}

// ─── HTML Report Generator ──────────────────────────────────────────────────

function generateHtml(summary, moduleBreakdown, overallTrend, moduleTrends) {
  const timestamp = new Date().toISOString();
  const total = summary.total;

  const statementPct = calcPct(total.statements.total, total.statements.covered);
  const branchPct = calcPct(total.branches.total, total.branches.covered);
  const functionPct = calcPct(total.functions.total, total.functions.covered);
  const linePct = calcPct(total.lines.total, total.lines.covered);
  const overallPct = (statementPct + branchPct + functionPct + linePct) / 4;

  const overallColor = getColor(overallPct);
  const overallGrade = getGrade(overallPct);
  const passed = overallPct >= THRESHOLD;

  // Build module rows
  const moduleRows = moduleBreakdown.map((mod) => {
    const modOverall = (mod.statementPct + mod.branchPct + mod.functionPct + mod.linePct) / 4;
    const modColor = getColor(modOverall);
    const trend = moduleTrends[mod.name] ? formatTrend(modOverall, moduleTrends[mod.name]) : '—';

    return `
      <tr>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;font-weight:500">${mod.name}</td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:center">
          <span style="color:${getColor(mod.statementPct)};font-weight:bold">${formatPct(mod.statementPct)}</span>
          <div style="font-size:11px;color:#6b7280">${formatNum(mod.statements.covered)}/${formatNum(mod.statements.total)}</div>
        </td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:center">
          <span style="color:${getColor(mod.branchPct)};font-weight:bold">${formatPct(mod.branchPct)}</span>
          <div style="font-size:11px;color:#6b7280">${formatNum(mod.branches.covered)}/${formatNum(mod.branches.total)}</div>
        </td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:center">
          <span style="color:${getColor(mod.functionPct)};font-weight:bold">${formatPct(mod.functionPct)}</span>
          <div style="font-size:11px;color:#6b7280">${formatNum(mod.functions.covered)}/${formatNum(mod.functions.total)}</div>
        </td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:center">
          <span style="color:${getColor(mod.linePct)};font-weight:bold">${formatPct(mod.linePct)}</span>
          <div style="font-size:11px;color:#6b7280">${formatNum(mod.lines.covered)}/${formatNum(mod.lines.total)}</div>
        </td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:center">
          <span style="color:${modColor};font-weight:bold;font-size:1.1em">${formatPct(modOverall)}</span>
        </td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:center;font-size:12px">${trend}</td>
      </tr>`;
  }).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GFF Backend — Test Coverage Report</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      background: #f3f4f6;
      color: #1f2937;
      line-height: 1.6;
    }
    .container { max-width: 1200px; margin: 0 auto; padding: 40px 20px; }
    .header {
      background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%);
      color: white;
      padding: 40px;
      border-radius: 12px;
      margin-bottom: 30px;
    }
    .header h1 { font-size: 28px; margin-bottom: 8px; }
    .header .meta { opacity: 0.8; font-size: 14px; }
    .status-badge {
      display: inline-block;
      padding: 8px 20px;
      border-radius: 20px;
      font-weight: 600;
      font-size: 14px;
      margin-top: 15px;
    }
    .status-pass { background: rgba(5, 150, 105, 0.2); color: #6ee7b7; }
    .status-fail { background: rgba(220, 38, 38, 0.2); color: #fca5a5; }

    .overall-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    .metric-card {
      background: white;
      border-radius: 10px;
      padding: 24px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      text-align: center;
    }
    .metric-card .label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; }
    .metric-card .value { font-size: 32px; font-weight: 700; margin-bottom: 4px; }
    .metric-card .detail { font-size: 12px; color: #9ca3af; }

    .section {
      background: white;
      border-radius: 10px;
      padding: 30px;
      margin-bottom: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .section h2 { font-size: 18px; margin-bottom: 20px; color: #1f2937; }

    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    th { text-align: left; padding: 12px 10px; border-bottom: 2px solid #e5e7eb; font-weight: 600; color: #4b5563; font-size: 12px; text-transform: uppercase; }
    th:first-child { text-align: left; }
    th { text-align: center; }

    .progress-bar {
      height: 6px;
      background: #e5e7eb;
      border-radius: 3px;
      overflow: hidden;
      margin-top: 4px;
    }
    .progress-fill { height: 100%; border-radius: 3px; transition: width 0.3s ease; }

    .legend { display: flex; gap: 20px; flex-wrap: wrap; margin-top: 20px; font-size: 12px; }
    .legend-item { display: flex; align-items: center; gap: 6px; }
    .legend-dot { width: 10px; height: 10px; border-radius: 50%; }

    .uncovered-section { margin-top: 20px; }
    .uncovered-file {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      padding: 16px;
      margin-bottom: 12px;
    }
    .uncovered-file .filename { font-family: 'Courier New', monospace; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px; }
    .uncovered-lines { font-family: 'Courier New', monospace; font-size: 12px; color: #dc2626; }
    .uncovered-lines .covered { color: #059669; }

    .footer {
      text-align: center;
      padding: 20px;
      color: #9ca3af;
      font-size: 12px;
    }

    @media print {
      body { background: white; }
      .section { box-shadow: none; border: 1px solid #e5e7eb; }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      <h1>Test Coverage Report</h1>
      <div class="meta">Generated: ${timestamp} &nbsp;|&nbsp; Threshold: ${THRESHOLD}% &nbsp;|&nbsp; Git SHA: ${process.env.GIT_SHA || 'N/A'}</div>
      <div class="status-badge ${passed ? 'status-pass' : 'status-fail'}">
        ${passed ? '✓ PASSED' : '✗ FAILED'} — Grade ${overallGrade}
      </div>
    </div>

    <!-- Overall Metrics -->
    <div class="overall-grid">
      <div class="metric-card">
        <div class="label">Overall</div>
        <div class="value" style="color:${overallColor}">${formatPct(overallPct)}</div>
        <div class="detail">${formatTrend(overallPct, overallTrend)} vs previous</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${overallPct}%;background:${overallColor}"></div></div>
      </div>
      <div class="metric-card">
        <div class="label">Statements</div>
        <div class="value" style="color:${getColor(statementPct)}">${formatPct(statementPct)}</div>
        <div class="detail">${formatNum(total.statements.covered)}/${formatNum(total.statements.total)}</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${statementPct}%;background:${getColor(statementPct)}"></div></div>
      </div>
      <div class="metric-card">
        <div class="label">Branches</div>
        <div class="value" style="color:${getColor(branchPct)}">${formatPct(branchPct)}</div>
        <div class="detail">${formatNum(total.branches.covered)}/${formatNum(total.branches.total)}</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${branchPct}%;background:${getColor(branchPct)}"></div></div>
      </div>
      <div class="metric-card">
        <div class="label">Functions</div>
        <div class="value" style="color:${getColor(functionPct)}">${formatPct(functionPct)}</div>
        <div class="detail">${formatNum(total.functions.covered)}/${formatNum(total.functions.total)}</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${functionPct}%;background:${getColor(functionPct)}"></div></div>
      </div>
      <div class="metric-card">
        <div class="label">Lines</div>
        <div class="value" style="color:${getColor(linePct)}">${formatPct(linePct)}</div>
        <div class="detail">${formatNum(total.lines.covered)}/${formatNum(total.lines.total)}</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${linePct}%;background:${getColor(linePct)}"></div></div>
      </div>
    </div>

    <!-- Module Breakdown -->
    <div class="section">
      <h2>Coverage by Module</h2>
      <table>
        <thead>
          <tr>
            <th>Module</th>
            <th style="text-align:center">Statements</th>
            <th style="text-align:center">Branches</th>
            <th style="text-align:center">Functions</th>
            <th style="text-align:center">Lines</th>
            <th style="text-align:center">Overall</th>
            <th style="text-align:center">Trend</th>
          </tr>
        </thead>
        <tbody>
          ${moduleRows}
        </tbody>
      </table>
      <div class="legend">
        <div class="legend-item"><div class="legend-dot" style="background:${COLORS.excellent}"></div> Excellent (≥90%)</div>
        <div class="legend-item"><div class="legend-dot" style="background:${COLORS.good}"></div> Good (≥${THRESHOLD}%)</div>
        <div class="legend-item"><div class="legend-dot" style="background:${COLORS.warning}"></div> Warning (≥60%)</div>
        <div class="legend-item"><div class="legend-dot" style="background:${COLORS.danger}"></div> Danger (<60%)</div>
      </div>
    </div>

    <!-- Uncovered Lines -->
    ${generateUncoveredSection(summary)}

    <!-- CI/CD Badge -->
    <div class="section">
      <h2>CI/CD Badge</h2>
      <p style="font-size:14px;color:#6b7280;margin-bottom:12px">Add this badge to your README.md:</p>
      <pre style="background:#f9fafb;padding:16px;border-radius:8px;font-size:13px;overflow-x:auto">![Coverage](https://img.shields.io/badge/coverage-${Math.round(overallPct)}%25-${overallPct >= THRESHOLD ? 'green' : 'red'})</pre>
    </div>
  </div>

  <div class="footer">
    GFF Backend Coverage Report &nbsp;|&nbsp; Generated ${timestamp}
  </div>
</body>
</html>`;
}

/**
 * Generate the uncovered lines section.
 */
function generateUncoveredSection(summary) {
  let uncoveredHtml = '';

  for (const [filePath, data] of Object.entries(summary)) {
    if (filePath === 'total') continue;

    // Check if file has uncovered lines
    if (data.lines && data.lines.total > data.lines.covered) {
      const uncoveredCount = data.lines.total - data.lines.covered;
      const linePct = calcPct(data.lines.total, data.lines.covered);

      // Only show files with significant uncovered lines
      if (linePct < 100) {
        const relativePath = filePath.replace(process.cwd(), '');
        uncoveredHtml += `
          <div class="uncovered-file">
            <div class="filename">${relativePath}</div>
            <div style="font-size:12px;color:#6b7280;margin-bottom:8px">
              Lines: ${formatNum(data.lines.covered)}/${formatNum(data.lines.total)} covered
              (${formatPct(linePct)})
              ${uncoveredCount > 0 ? `— <strong>${formatNum(uncoveredCount)} lines uncovered</strong>` : ''}
            </div>
          </div>`;
      }
    }
  }

  if (!uncoveredHtml) {
    uncoveredHtml = '<p style="color:#059669;font-weight:500">All files have 100% line coverage!</p>';
  }

  return `
    <div class="section uncovered-section">
      <h2>Uncovered Lines</h2>
      ${uncoveredHtml}
    </div>`;
}

// ─── Main ───────────────────────────────────────────────────────────────────

function main() {
  console.log('='.repeat(60));
  console.log('GFF Backend — Coverage Report Generator');
  console.log('='.repeat(60));
  console.log(`Coverage file: ${COVERAGE_FILE}`);
  console.log(`Output file:   ${OUTPUT_HTML}`);
  console.log(`Threshold:     ${THRESHOLD}%`);
  console.log('');

  // Read coverage summary
  if (!fs.existsSync(COVERAGE_FILE)) {
    console.error(`ERROR: Coverage file not found: ${COVERAGE_FILE}`);
    console.error('Run tests first: npm test -- --coverage --coverageReporters=json-summary');
    process.exit(1);
  }

  let summary;
  try {
    summary = JSON.parse(fs.readFileSync(COVERAGE_FILE, 'utf8'));
  } catch (err) {
    console.error(`ERROR: Failed to parse coverage file: ${err.message}`);
    process.exit(1);
  }

  // Read previous report for trend
  const previous = readPreviousReport();
  let overallTrend = null;
  if (previous && previous.total) {
    const prevTotal = previous.total;
    const prevOverall = (
      calcPct(prevTotal.statements.total, prevTotal.statements.covered) +
      calcPct(prevTotal.branches.total, prevTotal.branches.covered) +
      calcPct(prevTotal.functions.total, prevTotal.functions.covered) +
      calcPct(prevTotal.lines.total, prevTotal.lines.covered)
    ) / 4;
    overallTrend = prevOverall;
  }

  // Build module breakdown
  const moduleStats = {};
  for (const [filePath, data] of Object.entries(summary)) {
    if (filePath === 'total') continue;

    // Extract module name from path (e.g., src/redis/redis.service.ts → redis)
    const match = filePath.match(/src\/([^/]+)/);
    const moduleName = match ? match[1] : 'other';

    if (!moduleStats[moduleName]) {
      moduleStats[moduleName] = {
        name: moduleName,
        statements: { total: 0, covered: 0 },
        branches: { total: 0, covered: 0 },
        functions: { total: 0, covered: 0 },
        lines: { total: 0, covered: 0 },
      };
    }

    const mod = moduleStats[moduleName];
    mod.statements.total += data.statements?.total || 0;
    mod.statements.covered += data.statements?.covered || 0;
    mod.branches.total += data.branches?.total || 0;
    mod.branches.covered += data.branches?.covered || 0;
    mod.functions.total += data.functions?.total || 0;
    mod.functions.covered += data.functions?.covered || 0;
    mod.lines.total += data.lines?.total || 0;
    mod.lines.covered += data.lines?.covered || 0;
  }

  const moduleBreakdown = Object.values(moduleStats).map((mod) => ({
    ...mod,
    statementPct: calcPct(mod.statements.total, mod.statements.covered),
    branchPct: calcPct(mod.branches.total, mod.branches.covered),
    functionPct: calcPct(mod.functions.total, mod.functions.covered),
    linePct: calcPct(mod.lines.total, mod.lines.covered),
  }));

  // Sort by overall coverage (lowest first)
  moduleBreakdown.sort((a, b) => {
    const aOverall = (a.statementPct + a.branchPct + a.functionPct + a.linePct) / 4;
    const bOverall = (b.statementPct + b.branchPct + b.functionPct + b.linePct) / 4;
    return aOverall - bOverall;
  });

  // Calculate module trends
  const moduleTrends = {};
  if (previous) {
    for (const mod of moduleBreakdown) {
      const prevMod = Object.values(moduleStats).find(
        (m) => m.name === mod.name,
      );
      if (prevMod) {
        moduleTrends[mod.name] =
          (calcPct(prevMod.statements.total, prevMod.statements.covered) +
            calcPct(prevMod.branches.total, prevMod.branches.covered) +
            calcPct(prevMod.functions.total, prevMod.functions.covered) +
            calcPct(prevMod.lines.total, prevMod.lines.covered)) /
          4;
      }
    }
  }

  // Generate HTML
  const total = summary.total;
  const statementPct = calcPct(total.statements.total, total.statements.covered);
  const branchPct = calcPct(total.branches.total, total.branches.covered);
  const functionPct = calcPct(total.functions.total, total.functions.covered);
  const linePct = calcPct(total.lines.total, total.lines.covered);
  const overallPct = (statementPct + branchPct + functionPct + linePct) / 4;

  const html = generateHtml(summary, moduleBreakdown, overallTrend, moduleTrends);

  // Write output
  fs.mkdirSync(path.dirname(OUTPUT_HTML), { recursive: true });
  fs.writeFileSync(OUTPUT_HTML, html);
  console.log(`HTML report written to: ${OUTPUT_HTML}`);

  // Save for trend comparison
  saveCurrentReport(summary);

  // Console summary
  console.log('');
  console.log('Coverage Summary');
  console.log('─'.repeat(50));
  console.log(`  Overall:    ${formatPct(overallPct)} ${formatTrend(overallPct, overallTrend)}`);
  console.log(`  Statements: ${formatPct(statementPct)} (${formatNum(total.statements.covered)}/${formatNum(total.statements.total)})`);
  console.log(`  Branches:   ${formatPct(branchPct)} (${formatNum(total.branches.covered)}/${formatNum(total.branches.total)})`);
  console.log(`  Functions:  ${formatPct(functionPct)} (${formatNum(total.functions.covered)}/${formatNum(total.functions.total)})`);
  console.log(`  Lines:      ${formatPct(linePct)} (${formatNum(total.lines.covered)}/${formatNum(total.lines.total)})`);
  console.log('');
  console.log(`  Grade: ${getGrade(overallPct)}`);
  console.log(`  Threshold: ${THRESHOLD}%`);
  console.log(`  Status: ${overallPct >= THRESHOLD ? 'PASS' : 'FAIL'}`);
  console.log('');
  console.log('Module Breakdown (sorted by coverage):');
  for (const mod of moduleBreakdown) {
    const modOverall = (mod.statementPct + mod.branchPct + mod.functionPct + mod.linePct) / 4;
    const trend = moduleTrends[mod.name] ? formatTrend(modOverall, moduleTrends[mod.name]) : '—';
    console.log(`  ${mod.name.padEnd(20)} ${formatPct(modOverall).padStart(7)} ${trend}`);
  }
  console.log('');

  // Exit code
  if (overallPct < THRESHOLD) {
    console.error(`FAILED: Overall coverage ${formatPct(overallPct)} is below threshold ${THRESHOLD}%`);
    process.exit(1);
  }

  if (statementPct < THRESHOLD || branchPct < THRESHOLD || functionPct < THRESHOLD || linePct < THRESHOLD) {
    const failing = [];
    if (statementPct < THRESHOLD) failing.push('statements');
    if (branchPct < THRESHOLD) failing.push('branches');
    if (functionPct < THRESHOLD) failing.push('functions');
    if (linePct < THRESHOLD) failing.push('lines');
    console.error(`FAILED: Coverage below threshold for: ${failing.join(', ')}`);
    process.exit(1);
  }

  console.log('All coverage metrics above threshold. PASS.');
  process.exit(0);
}

main();
