import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, BadRequestException } from '@nestjs/common';
import { DeliveryService } from '@/delivery/delivery.service';
import { PrismaService } from '@/prisma/prisma.service';
import { DeliveryStatus } from '@prisma/client';

describe('DeliveryService', () => {
  let service: DeliveryService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const warehouseId = 'warehouse-1';
  const customerId = 'customer-1';
  const driverId = 'driver-1';
  const vehicleId = 'vehicle-1';
  const deliveryId = 'delivery-1';

  const mockWarehouse = {
    id: warehouseId,
    name: 'Main Warehouse',
    companyId,
  };

  const mockCustomer = {
    id: customerId,
    name: 'Test Customer',
    phone: '+962799111222',
    companyId,
  };

  const mockDelivery = {
    id: deliveryId,
    deliveryNumber: 'DLV-ABC123',
    status: 'PENDING',
    warehouseId,
    customerId,
    driverId: null,
    vehicleId: null,
    customerName: 'Test Customer',
    customerPhone: '+962799111222',
    address: 'Airport Road, Building 15',
    latitude: null,
    longitude: null,
    gpsHistory: null,
    signatureUrl: null,
    photoUrl: null,
    actualDate: null,
    collectedAmount: null,
    paymentMethod: null,
    failureReason: null,
    scheduledDate: null,
    notes: null,
    customerNotes: null,
    invoiceId: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    items: [
      {
        id: 'item-1',
        productId: 'product-1',
        productName: 'Organic Chicken Feed 25kg',
        quantity: 50,
        unitPrice: 22.5,
        total: 1125,
        pickedQty: null,
        loadedQty: null,
        deliveredQty: null,
        deliveryId,
      },
    ],
  };

  beforeEach(async () => {
    mockPrismaService = {
      warehouse: {
        findMany: jest.fn().mockResolvedValue([{ id: warehouseId }]),
        findFirst: jest.fn().mockResolvedValue(mockWarehouse),
      },
      customer: {
        findFirst: jest.fn().mockResolvedValue(mockCustomer),
        update: jest.fn().mockResolvedValue({ ...mockCustomer, currentDebt: 0 }),
      },
      delivery: {
        findFirst: jest.fn().mockResolvedValue(mockDelivery),
        findMany: jest.fn().mockResolvedValue([mockDelivery]),
        create: jest.fn().mockResolvedValue(mockDelivery),
        update: jest.fn().mockResolvedValue(mockDelivery),
        count: jest.fn().mockResolvedValue(1),
      },
      deliveryItem: {
        updateMany: jest.fn().mockResolvedValue({ count: 1 }),
      },
      customerTransaction: {
        create: jest.fn().mockResolvedValue({ id: 'txn-1' }),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DeliveryService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<DeliveryService>(DeliveryService);
    jest.clearAllMocks();
  });

  // ========== findAll ==========
  describe('findAll()', () => {
    it('should return paginated deliveries for company', async () => {
      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data).toEqual([mockDelivery]);
      expect(result.meta.page).toBe(1);
      expect(result.meta.limit).toBe(10);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by status', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, filters: { status: 'PENDING' } });

      expect(mockPrismaService.delivery.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ status: 'PENDING' }),
        }),
      );
    });

    it('should filter by driverId', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, filters: { driverId } });

      expect(mockPrismaService.delivery.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ driverId }),
        }),
      );
    });

    it('should filter by date range', async () => {
      await service.findAll(companyId, {
        page: 1,
        limit: 10,
        filters: { startDate: '2024-01-01', endDate: '2024-01-31' },
      });

      expect(mockPrismaService.delivery.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            createdAt: expect.objectContaining({
              gte: expect.any(Date),
              lte: expect.any(Date),
            }),
          }),
        }),
      );
    });
  });

  // ========== findOne ==========
  describe('findOne()', () => {
    it('should return a single delivery', async () => {
      const result = await service.findOne(deliveryId, companyId);

      expect(result.data).toEqual(mockDelivery);
    });

    it('should throw NotFoundException for delivery in another company', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(null);

      await expect(service.findOne('other-delivery', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== create ==========
  describe('create()', () => {
    const createDto = {
      warehouseId,
      customerId,
      customerName: 'Test Customer',
      address: 'Airport Road, Building 15',
      customerPhone: '+962799111222',
      items: [
        {
          productId: 'product-1',
          productName: 'Organic Chicken Feed 25kg',
          quantity: 50,
          unitPrice: 22.5,
          total: 1125,
        },
      ],
    };

    it('should create a delivery order', async () => {
      const result = await service.create(companyId, createDto);

      expect(result.data).toBeDefined();
      expect(mockPrismaService.delivery.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: 'PENDING',
            warehouseId,
            customerId,
            items: { create: expect.any(Array) },
          }),
        }),
      );
    });

    it('should throw NotFoundException for invalid warehouse', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValue(null);

      await expect(service.create(companyId, createDto)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for invalid customer', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValue(mockWarehouse);
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(service.create(companyId, createDto)).rejects.toThrow(NotFoundException);
    });

    it('should generate unique delivery number', async () => {
      await service.create(companyId, createDto);

      const createCall = mockPrismaService.delivery.create.mock.calls[0][0];
      expect(createCall.data.deliveryNumber).toMatch(/^DLV-/);
    });

    it('should handle optional scheduledDate', async () => {
      const dtoWithDate = { ...createDto, scheduledDate: '2024-01-20' };
      await service.create(companyId, dtoWithDate);

      const createCall = mockPrismaService.delivery.create.mock.calls[0][0];
      expect(createCall.data.scheduledDate).toBeInstanceOf(Date);
    });
  });

  // ========== assignDriver ==========
  describe('assignDriver()', () => {
    it('should assign driver from PENDING status', async () => {
      const result = await service.assignDriver(deliveryId, companyId, { driverId, vehicleId });

      expect(result.data.status).toBe('ASSIGNED');
      expect(mockPrismaService.delivery.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ status: 'ASSIGNED', driverId, vehicleId }),
        }),
      );
    });

    it('should throw BadRequestException for invalid transition', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'CLOSED' });

      await expect(service.assignDriver(deliveryId, companyId, { driverId, vehicleId })).rejects.toThrow(
        BadRequestException,
      );
    });

    it('should throw BadRequestException assigning from DELIVERED', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'DELIVERED' });

      await expect(service.assignDriver(deliveryId, companyId, { driverId, vehicleId })).rejects.toThrow(
        BadRequestException,
      );
    });
  });

  // ========== confirmPicking ==========
  describe('confirmPicking()', () => {
    const pickingDto = {
      pickedItems: [{ itemId: 'item-1', pickedQty: 50 }],
    };

    it('should confirm picking from ASSIGNED status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'ASSIGNED' });

      const result = await service.confirmPicking(deliveryId, companyId, pickingDto);

      expect(result.data.status).toBe('PICKED');
      expect(mockPrismaService.deliveryItem.updateMany).toHaveBeenCalled();
    });

    it('should throw BadRequestException for invalid transition', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(mockDelivery); // PENDING

      await expect(service.confirmPicking(deliveryId, companyId, pickingDto)).rejects.toThrow(
        BadRequestException,
      );
    });

    it('should update picked quantities for each item', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'ASSIGNED' });

      await service.confirmPicking(deliveryId, companyId, {
        pickedItems: [
          { itemId: 'item-1', pickedQty: 45 },
          { itemId: 'item-2', pickedQty: 30 },
        ],
      });

      expect(mockPrismaService.deliveryItem.updateMany).toHaveBeenCalledTimes(2);
    });
  });

  // ========== confirmLoading ==========
  describe('confirmLoading()', () => {
    const loadingDto = {
      loadedItems: [{ itemId: 'item-1', loadedQty: 50 }],
    };

    it('should confirm loading from PICKED status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'PICKED' });

      const result = await service.confirmLoading(deliveryId, companyId, loadingDto);

      expect(result.data.status).toBe('LOADED');
    });

    it('should throw BadRequestException for invalid transition', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(mockDelivery); // PENDING

      await expect(service.confirmLoading(deliveryId, companyId, loadingDto)).rejects.toThrow(
        BadRequestException,
      );
    });
  });

  // ========== acceptDelivery ==========
  describe('acceptDelivery()', () => {
    it('should accept delivery from LOADED status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'LOADED' });

      const result = await service.acceptDelivery(deliveryId, companyId);

      expect(result.data.status).toBe('ACCEPTED');
    });

    it('should throw BadRequestException for invalid transition', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(mockDelivery); // PENDING

      await expect(service.acceptDelivery(deliveryId, companyId)).rejects.toThrow(BadRequestException);
    });
  });

  // ========== updateGpsTracking ==========
  describe('updateGpsTracking()', () => {
    const gpsDto = { latitude: 31.9454, longitude: 35.9284 };

    it('should update GPS from ACCEPTED status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'ACCEPTED' });

      const result = await service.updateGpsTracking(deliveryId, companyId, gpsDto);

      expect(result.data.status).toBe('IN_TRANSIT');
      expect(result.data.latitude).toBe(31.9454);
      expect(result.data.longitude).toBe(35.9284);
    });

    it('should update GPS from IN_TRANSIT status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'IN_TRANSIT',
        gpsHistory: [{ lat: 31.9, lng: 35.9, timestamp: '2024-01-01T00:00:00Z' }],
      });

      const result = await service.updateGpsTracking(deliveryId, companyId, gpsDto);

      expect(result.data.gpsHistory).toHaveLength(2);
    });

    it('should throw BadRequestException for non-transit delivery', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(mockDelivery); // PENDING

      await expect(service.updateGpsTracking(deliveryId, companyId, gpsDto)).rejects.toThrow(
        BadRequestException,
      );
    });

    it('should append GPS entry to history', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'IN_TRANSIT',
        gpsHistory: [{ lat: 31.9, lng: 35.9, timestamp: '2024-01-01T00:00:00Z' }],
      });

      await service.updateGpsTracking(deliveryId, companyId, gpsDto);

      const updateCall = mockPrismaService.delivery.update.mock.calls[0][0];
      expect(updateCall.data.gpsHistory).toHaveLength(2);
      expect(updateCall.data.gpsHistory[1].lat).toBe(31.9454);
    });
  });

  // ========== confirmDelivery ==========
  describe('confirmDelivery()', () => {
    const confirmDto = {
      deliveredItems: [{ itemId: 'item-1', deliveredQty: 48 }],
      signatureUrl: 'https://cdn.example.com/sig.png',
      photoUrl: 'https://cdn.example.com/photo.jpg',
    };

    it('should confirm delivery from IN_TRANSIT status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'IN_TRANSIT' });

      const result = await service.confirmDelivery(deliveryId, companyId, confirmDto);

      expect(result.data.status).toBe('DELIVERED');
      expect(result.data.signatureUrl).toBe(confirmDto.signatureUrl);
      expect(result.data.photoUrl).toBe(confirmDto.photoUrl);
    });

    it('should confirm delivery from ARRIVED status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'ARRIVED' });

      const result = await service.confirmDelivery(deliveryId, companyId, confirmDto);

      expect(result.data.status).toBe('DELIVERED');
    });

    it('should throw BadRequestException for invalid status', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(mockDelivery); // PENDING

      await expect(service.confirmDelivery(deliveryId, companyId, confirmDto)).rejects.toThrow(
        BadRequestException,
      );
    });

    it('should update delivered quantities', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'IN_TRANSIT' });

      await service.confirmDelivery(deliveryId, companyId, confirmDto);

      expect(mockPrismaService.deliveryItem.updateMany).toHaveBeenCalledWith({
        where: { id: 'item-1', deliveryId },
        data: { deliveredQty: 48 },
      });
    });
  });

  // ========== collectPayment ==========
  describe('collectPayment()', () => {
    const paymentDto = {
      amount: 1125,
      paymentMethod: 'CASH' as const,
      notes: 'Full payment collected',
    };

    it('should collect payment for delivered order', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'DELIVERED',
        customerId,
      });

      const result = await service.collectPayment(deliveryId, companyId, paymentDto);

      expect(result.data.collectedAmount).toBe(1125);
      expect(result.data.paymentMethod).toBe('CASH');
    });

    it('should create customer transaction and reduce debt', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'DELIVERED',
        customerId,
      });

      await service.collectPayment(deliveryId, companyId, paymentDto);

      expect(mockPrismaService.customerTransaction.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            customerId,
            type: 'payment',
            amount: 1125,
            reference: mockDelivery.deliveryNumber,
          }),
        }),
      );
      expect(mockPrismaService.customer.update).toHaveBeenCalledWith({
        where: { id: customerId },
        data: { currentDebt: { decrement: 1125 } },
      });
    });

    it('should throw BadRequestException for non-delivered order', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'IN_TRANSIT',
      });

      await expect(service.collectPayment(deliveryId, companyId, paymentDto)).rejects.toThrow(
        BadRequestException,
      );
    });

    it('should not create transaction if no customer linked', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'DELIVERED',
        customerId: null,
      });

      await service.collectPayment(deliveryId, companyId, paymentDto);

      expect(mockPrismaService.customerTransaction.create).not.toHaveBeenCalled();
      expect(mockPrismaService.customer.update).not.toHaveBeenCalled();
    });
  });

  // ========== closeDelivery ==========
  describe('closeDelivery()', () => {
    it('should close a delivered delivery', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'DELIVERED',
      });

      const result = await service.closeDelivery(deliveryId, companyId);

      expect(result.data.status).toBe('CLOSED');
    });

    it('should throw BadRequestException closing from PENDING', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(mockDelivery); // PENDING

      await expect(service.closeDelivery(deliveryId, companyId)).rejects.toThrow(BadRequestException);
    });

    it('should throw BadRequestException closing from IN_TRANSIT', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'IN_TRANSIT',
      });

      await expect(service.closeDelivery(deliveryId, companyId)).rejects.toThrow(BadRequestException);
    });
  });

  // ========== failDelivery ==========
  describe('failDelivery()', () => {
    const failDto = { reason: 'Customer not available' };

    it('should mark delivery as failed from IN_TRANSIT', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'IN_TRANSIT',
      });

      const result = await service.failDelivery(deliveryId, companyId, failDto);

      expect(result.data.status).toBe('FAILED');
      expect(result.data.failureReason).toBe('Customer not available');
    });

    it('should mark delivery as failed from ARRIVED', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'ARRIVED',
      });

      const result = await service.failDelivery(deliveryId, companyId, failDto);

      expect(result.data.status).toBe('FAILED');
    });

    it('should throw BadRequestException for invalid fail transition', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue(mockDelivery); // PENDING

      await expect(service.failDelivery(deliveryId, companyId, failDto)).rejects.toThrow(
        BadRequestException,
      );
    });
  });

  // ========== Status Transition Validation ==========
  describe('Status Transition Validation', () => {
    const validTransitions: [string, string, () => Promise<any>][] = [
      ['PENDING', 'ASSIGNED', () => service.assignDriver(deliveryId, companyId, { driverId, vehicleId })],
      ['ASSIGNED', 'PICKING', () => service.confirmPicking(deliveryId, companyId, { pickedItems: [] })],
      ['PICKING', 'PICKED', () => service.confirmPicking(deliveryId, companyId, { pickedItems: [] })],
      ['PICKED', 'LOADED', () => service.confirmLoading(deliveryId, companyId, { loadedItems: [] })],
      ['LOADED', 'ACCEPTED', () => service.acceptDelivery(deliveryId, companyId)],
      ['ACCEPTED', 'IN_TRANSIT', () => service.updateGpsTracking(deliveryId, companyId, { latitude: 0, longitude: 0 })],
      ['IN_TRANSIT', 'ARRIVED', () => service.confirmDelivery(deliveryId, companyId, { deliveredItems: [] })],
      ['IN_TRANSIT', 'FAILED', () => service.failDelivery(deliveryId, companyId, { reason: 'Test' })],
      ['ARRIVED', 'DELIVERED', () => service.confirmDelivery(deliveryId, companyId, { deliveredItems: [] })],
      ['ARRIVED', 'FAILED', () => service.failDelivery(deliveryId, companyId, { reason: 'Test' })],
      ['DELIVERED', 'CLOSED', () => service.closeDelivery(deliveryId, companyId)],
      ['FAILED', 'ASSIGNED', () => service.assignDriver(deliveryId, companyId, { driverId, vehicleId })],
    ];

    const invalidTransitions: [string, () => Promise<any>][] = [
      ['CLOSED', () => service.assignDriver(deliveryId, companyId, { driverId, vehicleId })],
      ['CANCELLED', () => service.confirmPicking(deliveryId, companyId, { pickedItems: [] })],
      ['PENDING', () => service.confirmPicking(deliveryId, companyId, { pickedItems: [] })],
      ['PENDING', () => service.confirmLoading(deliveryId, companyId, { loadedItems: [] })],
      ['PENDING', () => service.acceptDelivery(deliveryId, companyId)],
      ['PENDING', () => service.closeDelivery(deliveryId, companyId)],
      ['ASSIGNED', () => service.confirmLoading(deliveryId, companyId, { loadedItems: [] })],
      ['ASSIGNED', () => service.acceptDelivery(deliveryId, companyId)],
      ['PICKED', () => service.acceptDelivery(deliveryId, companyId)],
      ['LOADED', () => service.closeDelivery(deliveryId, companyId)],
      ['DELIVERED', () => service.failDelivery(deliveryId, companyId, { reason: 'Test' })],
      ['DELIVERED', () => service.assignDriver(deliveryId, companyId, { driverId, vehicleId })],
    ];

    it.each(validTransitions)('should allow %s -> %s transition', async (from, to, action) => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: from });
      mockPrismaService.delivery.update.mockResolvedValue({ ...mockDelivery, status: to });

      await expect(action()).resolves.not.toThrow(BadRequestException);
    });

    it.each(invalidTransitions)('should throw for invalid transition from %s', async (from, action) => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: from });

      await expect(action()).rejects.toThrow(BadRequestException);
    });
  });

  // ========== Multi-company Isolation ==========
  describe('Multi-company Isolation', () => {
    it('should not find delivery from another company', async () => {
      mockPrismaService.warehouse.findMany.mockResolvedValue([{ id: 'other-warehouse' }]);
      mockPrismaService.delivery.findFirst.mockResolvedValue(null);

      await expect(service.findOne(deliveryId, 'other-company')).rejects.toThrow(NotFoundException);
    });

    it('should scope findAll to company warehouses', async () => {
      await service.findAll(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.warehouse.findMany).toHaveBeenCalledWith({
        where: { companyId },
        select: { id: true },
      });
    });

    it('should reject warehouse not belonging to company on create', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValue(null);

      await expect(
        service.create(companyId, {
          warehouseId: 'other-warehouse',
          customerId,
          customerName: 'Test',
          address: 'Test Address',
          items: [],
        }),
      ).rejects.toThrow(NotFoundException);
    });

    it('should reject customer not belonging to company on create', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValue(mockWarehouse);
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(
        service.create(companyId, {
          warehouseId,
          customerId: 'other-customer',
          customerName: 'Test',
          address: 'Test Address',
          items: [],
        }),
      ).rejects.toThrow(NotFoundException);
    });

    it('should use warehouse IDs for company-scoped findDeliveryForCompany', async () => {
      mockPrismaService.warehouse.findMany.mockResolvedValue([
        { id: 'wh-1' },
        { id: 'wh-2' },
      ]);

      await service.findOne(deliveryId, companyId);

      expect(mockPrismaService.delivery.findFirst).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            id: deliveryId,
            warehouseId: { in: ['wh-1', 'wh-2'] },
          }),
        }),
      );
    });
  });

  // ========== Edge Cases ==========
  describe('Edge Cases', () => {
    it('should handle empty picked items array', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'ASSIGNED' });

      const result = await service.confirmPicking(deliveryId, companyId, { pickedItems: [] });

      expect(result.data.status).toBe('PICKED');
    });

    it('should handle empty delivered items array', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({ ...mockDelivery, status: 'IN_TRANSIT' });

      const result = await service.confirmDelivery(deliveryId, companyId, { deliveredItems: [] });

      expect(result.data.status).toBe('DELIVERED');
    });

    it('should handle delivery with null gpsHistory', async () => {
      mockPrismaService.delivery.findFirst.mockResolvedValue({
        ...mockDelivery,
        status: 'IN_TRANSIT',
        gpsHistory: null,
      });

      const result = await service.updateGpsTracking(deliveryId, companyId, {
        latitude: 31.9454,
        longitude: 35.9284,
      });

      expect(result.data.gpsHistory).toHaveLength(1);
    });
  });
});
