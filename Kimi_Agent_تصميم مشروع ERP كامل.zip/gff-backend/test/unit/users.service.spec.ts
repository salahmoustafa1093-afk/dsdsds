import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException } from '@nestjs/common';
import { UsersService } from '@/users/users.service';
import { PrismaService } from '@/prisma/prisma.service';

jest.mock('@/common/utils/password.util', () => ({
  hashPassword: jest.fn().mockResolvedValue('hashed_password_123'),
}));

describe('UsersService', () => {
  let service: UsersService;
  let mockPrismaService: any;

  const companyId = 'company-1';

  const mockRole = {
    id: 'role-1',
    name: 'admin',
    permissions: ['users.read', 'users.write'],
    companyId,
  };

  const mockUser = {
    id: 'user-1',
    name: 'John Doe',
    email: 'john@company.com',
    password: 'hashed_password_123',
    phone: '+962799111222',
    companyId,
    roleId: 'role-1',
    branchId: 'branch-1',
    department: 'Sales',
    status: 'ACTIVE',
    deletedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    role: mockRole,
    branch: { id: 'branch-1', name: 'Main Branch' },
  };

  beforeEach(async () => {
    mockPrismaService = {
      user: {
        findFirst: jest.fn().mockResolvedValue(mockUser),
        findUnique: jest.fn(),
        findMany: jest.fn().mockResolvedValue([mockUser]),
        create: jest.fn().mockResolvedValue(mockUser),
        update: jest.fn().mockResolvedValue(mockUser),
        updateMany: jest.fn(),
        count: jest.fn().mockResolvedValue(1),
      },
      role: {
        findFirst: jest.fn().mockResolvedValue(mockRole),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UsersService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<UsersService>(UsersService);
    jest.clearAllMocks();
  });

  // ========== findAll ==========
  describe('findAll()', () => {
    it('should return paginated users for company', async () => {
      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.page).toBe(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by status', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, status: 'ACTIVE' });

      expect(mockPrismaService.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ status: 'ACTIVE' }),
        }),
      );
    });

    it('should search by name or email', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, search: 'john' });

      expect(mockPrismaService.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: [
              { name: { contains: 'john', mode: 'insensitive' } },
              { email: { contains: 'john', mode: 'insensitive' } },
            ],
          }),
        }),
      );
    });

    it('should exclude soft-deleted users', async () => {
      await service.findAll(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.user.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ deletedAt: null }),
        }),
      );
    });

    it('should return empty array when no users exist', async () => {
      mockPrismaService.user.findMany.mockResolvedValue([]);
      mockPrismaService.user.count.mockResolvedValue(0);

      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(0);
      expect(result.meta.total).toBe(0);
      expect(result.meta.totalPages).toBe(0);
    });
  });

  // ========== findOne ==========
  describe('findOne()', () => {
    it('should return a user by ID', async () => {
      const result = await service.findOne('user-1', companyId);

      expect(result.data.id).toBe('user-1');
      expect(result.data.password).toBeUndefined();
    });

    it('should throw NotFoundException for non-existent user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.findOne('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for deleted user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.findOne('deleted-user', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should include role and branch in response', async () => {
      const result = await service.findOne('user-1', companyId);

      expect(result.data.role).toBeDefined();
      expect(result.data.branch).toBeDefined();
    });
  });

  // ========== findByEmail ==========
  describe('findByEmail()', () => {
    it('should find user by email', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      const result = await service.findByEmail('john@company.com');

      expect(result).toBeDefined();
      expect(result?.email).toBe('john@company.com');
    });

    it('should return null for non-existent email', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      const result = await service.findByEmail('nonexistent@test.com');

      expect(result).toBeNull();
    });

    it('should exclude soft-deleted users', async () => {
      await service.findByEmail('john@company.com');

      expect(mockPrismaService.user.findFirst).toHaveBeenCalledWith({
        where: { email: 'john@company.com', deletedAt: null },
        include: { role: true, company: true },
      });
    });
  });

  // ========== create ==========
  describe('create()', () => {
    const createDto = {
      name: 'Jane Smith',
      email: 'jane@company.com',
      password: 'StrongP@ss123',
      phone: '+962799222333',
      roleId: 'role-1',
      branchId: 'branch-1',
      department: 'Marketing',
    };

    it('should create a new user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      const result = await service.create(companyId, createDto);

      expect(result.data).toBeDefined();
      expect(result.data.email).toBe(createDto.email);
    });

    it('should throw ConflictException for duplicate email in company', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      await expect(service.create(companyId, createDto)).rejects.toThrow(ConflictException);
    });

    it('should hash password before storing', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await service.create(companyId, createDto);

      const createCall = mockPrismaService.user.create.mock.calls[0][0];
      expect(createCall.data.password).toBe('hashed_password_123');
    });

    it('should sanitize user (no password) in response', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      const result = await service.create(companyId, createDto);

      expect(result.data.password).toBeUndefined();
    });
  });

  // ========== update ==========
  describe('update()', () => {
    const updateDto = {
      name: 'John Updated',
      phone: '+962799333444',
    };

    it('should update user fields', async () => {
      mockPrismaService.user.update.mockResolvedValue({ ...mockUser, ...updateDto });

      const result = await service.update('user-1', companyId, updateDto);

      expect(result.data.name).toBe('John Updated');
      expect(result.data.phone).toBe('+962799333444');
    });

    it('should throw NotFoundException for non-existent user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.update('nonexistent', companyId, updateDto)).rejects.toThrow(NotFoundException);
    });

    it('should throw ConflictException when changing to existing email', async () => {
      mockPrismaService.user.findFirst
        .mockResolvedValueOnce(mockUser) // First call for find user
        .mockResolvedValueOnce({ ...mockUser, id: 'user-2', email: 'existing@company.com' }); // Second call for email check

      await expect(
        service.update('user-1', companyId, { email: 'existing@company.com' }),
      ).rejects.toThrow(ConflictException);
    });

    it('should allow changing to same email', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      const result = await service.update('user-1', companyId, { email: 'john@company.com' });

      expect(result.data).toBeDefined();
    });

    it('should update role assignment', async () => {
      const result = await service.update('user-1', companyId, { roleId: 'role-2' });

      expect(mockPrismaService.user.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ roleId: 'role-2' }),
        }),
      );
    });
  });

  // ========== remove (Soft Delete) ==========
  describe('remove()', () => {
    it('should soft delete a user', async () => {
      const result = await service.remove('user-1', companyId);

      expect(result.data.message).toBe('User deleted successfully');
      expect(mockPrismaService.user.update).toHaveBeenCalledWith({
        where: { id: 'user-1' },
        data: { deletedAt: expect.any(Date), status: 'INACTIVE' },
      });
    });

    it('should throw NotFoundException for non-existent user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.remove('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for already deleted user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.remove('deleted-user', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== updateStatus ==========
  describe('updateStatus()', () => {
    it('should update user status to INACTIVE', async () => {
      mockPrismaService.user.update.mockResolvedValue({ ...mockUser, status: 'INACTIVE' });

      const result = await service.updateStatus('user-1', companyId, 'INACTIVE');

      expect(result.data.status).toBe('INACTIVE');
    });

    it('should update user status to SUSPENDED', async () => {
      mockPrismaService.user.update.mockResolvedValue({ ...mockUser, status: 'SUSPENDED' });

      const result = await service.updateStatus('user-1', companyId, 'SUSPENDED');

      expect(result.data.status).toBe('SUSPENDED');
    });

    it('should throw NotFoundException for non-existent user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.updateStatus('nonexistent', companyId, 'ACTIVE')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== assignRole ==========
  describe('assignRole()', () => {
    it('should assign role to user', async () => {
      mockPrismaService.user.update.mockResolvedValue({
        ...mockUser,
        roleId: 'role-2',
        role: { id: 'role-2', name: 'manager', permissions: ['read'] },
      });

      const result = await service.assignRole('user-1', companyId, 'role-2');

      expect(result.data.role.id).toBe('role-2');
      expect(result.data.role.name).toBe('manager');
    });

    it('should throw NotFoundException for non-existent user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.assignRole('nonexistent', companyId, 'role-1')).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for role in another company', async () => {
      mockPrismaService.role.findFirst.mockResolvedValue(null);

      await expect(service.assignRole('user-1', companyId, 'other-role')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== getPermissions ==========
  describe('getPermissions()', () => {
    it('should return aggregated permissions', async () => {
      const result = await service.getPermissions('user-1', companyId);

      expect(result.data.userId).toBe('user-1');
      expect(result.data.role).toBe('admin');
      expect(result.data.permissions).toEqual(['users.read', 'users.write']);
    });

    it('should return empty permissions for user without role', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue({
        ...mockUser,
        role: null,
        roleId: null,
      });

      const result = await service.getPermissions('user-1', companyId);

      expect(result.data.permissions).toEqual([]);
      expect(result.data.role).toBeNull();
    });

    it('should throw NotFoundException for non-existent user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.getPermissions('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });
});
