import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException } from '@nestjs/common';
import { ProductionService } from '@/production/production.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('ProductionService', () => {
  let service: ProductionService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const orderId = 'order-1';
  const productId = 'product-1';

  const mockProductionOrder = {
    id: orderId,
    orderNumber: 'PROD-ABC123-0001',
    companyId,
    productId,
    quantity: 1000,
    actualQty: null,
    plannedDate: new Date('2024-02-01'),
    startDate: null,
    endDate: null,
    batchNumber: 'BATCH001',
    status: 'PLANNED',
    notes: 'Weekly production run',
    createdAt: new Date(),
    updatedAt: new Date(),
    items: [
      {
        id: 'item-1',
        type: 'RAW_MATERIAL',
        quantity: 500,
        unitCost: 2.5,
        totalCost: 1250,
        productId: 'raw-1',
      },
      {
        id: 'item-2',
        type: 'LABOR',
        quantity: 40,
        unitCost: 15,
        totalCost: 600,
        productId: null,
      },
      {
        id: 'item-3',
        type: 'OVERHEAD',
        quantity: 1,
        unitCost: 300,
        totalCost: 300,
        productId: null,
      },
    ],
  };

  beforeEach(async () => {
    mockPrismaService = {
      productionOrder: {
        findFirst: jest.fn().mockResolvedValue(mockProductionOrder),
        findMany: jest.fn().mockResolvedValue([mockProductionOrder]),
        create: jest.fn().mockResolvedValue(mockProductionOrder),
        update: jest.fn().mockResolvedValue(mockProductionOrder),
        count: jest.fn().mockResolvedValue(1),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ProductionService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<ProductionService>(ProductionService);
    jest.clearAllMocks();
  });

  // ========== findAll ==========
  describe('findAll()', () => {
    it('should return paginated production orders for company', async () => {
      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.page).toBe(1);
      expect(result.meta.total).toBe(1);
      expect(result.meta.totalPages).toBe(1);
    });

    it('should filter by status', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, status: 'PLANNED' });

      expect(mockPrismaService.productionOrder.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ status: 'PLANNED' }),
        }),
      );
    });

    it('should scope to company', async () => {
      await service.findAll(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.productionOrder.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });

    it('should include items in response', async () => {
      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data[0].items).toBeDefined();
      expect(result.data[0].items.length).toBe(3);
    });

    it('should return empty array when no orders exist', async () => {
      mockPrismaService.productionOrder.findMany.mockResolvedValue([]);
      mockPrismaService.productionOrder.count.mockResolvedValue(0);

      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(0);
      expect(result.meta.total).toBe(0);
      expect(result.meta.totalPages).toBe(0);
    });
  });

  // ========== findOne ==========
  describe('findOne()', () => {
    it('should return production order with items', async () => {
      const result = await service.findOne(orderId, companyId);

      expect(result.data.id).toBe(orderId);
      expect(result.data.items).toBeDefined();
      expect(result.data.items).toHaveLength(3);
    });

    it('should throw NotFoundException for non-existent order', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(null);

      await expect(service.findOne('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for order in another company', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(null);

      await expect(service.findOne(orderId, 'other-company')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== create ==========
  describe('create()', () => {
    const createDto = {
      productId,
      quantity: 2000,
      plannedDate: '2024-03-01',
      batchNumber: 'BATCH002',
      notes: 'March production run',
      items: [
        {
          type: 'RAW_MATERIAL',
          quantity: 1000,
          unitCost: 2.5,
          totalCost: 2500,
          productId: 'raw-1',
        },
        {
          type: 'LABOR',
          quantity: 80,
          unitCost: 15,
          totalCost: 1200,
          productId: null,
        },
      ],
    };

    it('should create production order', async () => {
      const result = await service.create(companyId, createDto);

      expect(result.data).toBeDefined();
      expect(result.data.orderNumber).toMatch(/^PROD-/);
    });

    it('should generate unique order number', async () => {
      await service.create(companyId, createDto);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.orderNumber).toMatch(/^PROD-[A-Z0-9]+-\d{4}$/);
    });

    it('should parse plannedDate to Date', async () => {
      await service.create(companyId, createDto);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.plannedDate).toBeInstanceOf(Date);
    });

    it('should scope to company', async () => {
      await service.create(companyId, createDto);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.companyId).toBe(companyId);
    });

    it('should create items with production order', async () => {
      await service.create(companyId, createDto);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.items).toBeDefined();
      expect(createCall.data.items.create).toHaveLength(2);
    });

    it('should handle order without items', async () => {
      const dtoNoItems = { ...createDto, items: undefined };

      await service.create(companyId, dtoNoItems);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.items).toBeDefined();
    });

    it('should handle null plannedDate', async () => {
      const dtoNoDate = { ...createDto, plannedDate: undefined };

      await service.create(companyId, dtoNoDate);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.plannedDate).toBeUndefined();
    });
  });

  // ========== updateStatus - Workflow ==========
  describe('updateStatus()', () => {
    it('should update from PLANNED to IN_PROGRESS', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(mockProductionOrder);
      mockPrismaService.productionOrder.update.mockResolvedValue({
        ...mockProductionOrder,
        status: 'IN_PROGRESS',
        startDate: new Date(),
      });

      const result = await service.updateStatus(orderId, companyId, 'IN_PROGRESS');

      expect(result.data.status).toBe('IN_PROGRESS');
      expect(mockPrismaService.productionOrder.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: 'IN_PROGRESS',
            startDate: expect.any(Date),
          }),
        }),
      );
    });

    it('should update from IN_PROGRESS to COMPLETED', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue({
        ...mockProductionOrder,
        status: 'IN_PROGRESS',
      });
      mockPrismaService.productionOrder.update.mockResolvedValue({
        ...mockProductionOrder,
        status: 'COMPLETED',
        endDate: new Date(),
        actualQty: 1000,
      });

      const result = await service.updateStatus(orderId, companyId, 'COMPLETED');

      expect(result.data.status).toBe('COMPLETED');
      expect(result.data.endDate).toBeDefined();
      expect(result.data.actualQty).toBe(1000);
    });

    it('should set actualQty equal to planned quantity on complete', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue({
        ...mockProductionOrder,
        status: 'IN_PROGRESS',
        quantity: 1500,
      });

      await service.updateStatus(orderId, companyId, 'COMPLETED');

      const updateCall = mockPrismaService.productionOrder.update.mock.calls[0][0];
      expect(updateCall.data.actualQty).toBe(1500);
    });

    it('should update to CANCELLED', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(mockProductionOrder);
      mockPrismaService.productionOrder.update.mockResolvedValue({
        ...mockProductionOrder,
        status: 'CANCELLED',
      });

      const result = await service.updateStatus(orderId, companyId, 'CANCELLED');

      expect(result.data.status).toBe('CANCELLED');
    });

    it('should throw NotFoundException for non-existent order', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(null);

      await expect(service.updateStatus('nonexistent', companyId, 'IN_PROGRESS')).rejects.toThrow(NotFoundException);
    });

    it('should scope to company', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(mockProductionOrder);

      await service.updateStatus(orderId, companyId, 'IN_PROGRESS');

      expect(mockPrismaService.productionOrder.findFirst).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  // ========== Production Order Workflow ==========
  describe('Production Order Workflow', () => {
    it('should track complete workflow: PLANNED -> IN_PROGRESS -> COMPLETED', async () => {
      // Step 1: PLANNED
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(mockProductionOrder);
      let result = await service.findOne(orderId, companyId);
      expect(result.data.status).toBe('PLANNED');

      // Step 2: IN_PROGRESS
      mockPrismaService.productionOrder.update.mockResolvedValue({
        ...mockProductionOrder,
        status: 'IN_PROGRESS',
        startDate: new Date(),
      });
      result = await service.updateStatus(orderId, companyId, 'IN_PROGRESS');
      expect(result.data.status).toBe('IN_PROGRESS');
      expect(result.data.startDate).toBeDefined();

      // Step 3: COMPLETED
      mockPrismaService.productionOrder.findFirst.mockResolvedValue({
        ...mockProductionOrder,
        status: 'IN_PROGRESS',
      });
      mockPrismaService.productionOrder.update.mockResolvedValue({
        ...mockProductionOrder,
        status: 'COMPLETED',
        endDate: new Date(),
        actualQty: 1000,
      });
      result = await service.updateStatus(orderId, companyId, 'COMPLETED');
      expect(result.data.status).toBe('COMPLETED');
      expect(result.data.endDate).toBeDefined();
      expect(result.data.actualQty).toBe(1000);
    });

    it('should allow cancellation from PLANNED', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(mockProductionOrder);
      mockPrismaService.productionOrder.update.mockResolvedValue({
        ...mockProductionOrder,
        status: 'CANCELLED',
      });

      const result = await service.updateStatus(orderId, companyId, 'CANCELLED');

      expect(result.data.status).toBe('CANCELLED');
    });
  });

  // ========== Batch Tracking ==========
  describe('Batch Tracking', () => {
    it('should include batch number in production order', async () => {
      const result = await service.findOne(orderId, companyId);

      expect(result.data.batchNumber).toBe('BATCH001');
    });

    it('should create production order with batch number', async () => {
      const dto = {
        productId,
        quantity: 500,
        batchNumber: 'BATCH003',
      };

      await service.create(companyId, dto);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.batchNumber).toBe('BATCH003');
    });
  });

  // ========== Yield Calculation ==========
  describe('Yield Calculation', () => {
    it('should track actual vs planned quantity', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue({
        ...mockProductionOrder,
        status: 'IN_PROGRESS',
        quantity: 1000,
        actualQty: null,
      });
      mockPrismaService.productionOrder.update.mockResolvedValue({
        ...mockProductionOrder,
        status: 'COMPLETED',
        actualQty: 1000,
      });

      const result = await service.updateStatus(orderId, companyId, 'COMPLETED');

      // If actualQty equals quantity, yield is 100%
      expect(result.data.actualQty).toBe(1000);
    });

    it('should calculate 100% yield when actual equals planned', async () => {
      const plannedQty = 1000;
      const actualQty = 1000;
      const yieldPercent = (actualQty / plannedQty) * 100;

      expect(yieldPercent).toBe(100);
    });

    it('should calculate partial yield', async () => {
      const plannedQty = 1000;
      const actualQty = 950;
      const yieldPercent = (actualQty / plannedQty) * 100;

      expect(yieldPercent).toBe(95);
    });
  });

  // ========== Cost Allocation ==========
  describe('Cost Allocation', () => {
    it('should track raw material costs', async () => {
      const result = await service.findOne(orderId, companyId);

      const rawMaterial = result.data.items.find((i: any) => i.type === 'RAW_MATERIAL');
      expect(rawMaterial).toBeDefined();
      expect(rawMaterial.totalCost).toBe(1250);
    });

    it('should track labor costs', async () => {
      const result = await service.findOne(orderId, companyId);

      const labor = result.data.items.find((i: any) => i.type === 'LABOR');
      expect(labor).toBeDefined();
      expect(labor.totalCost).toBe(600);
    });

    it('should track overhead costs', async () => {
      const result = await service.findOne(orderId, companyId);

      const overhead = result.data.items.find((i: any) => i.type === 'OVERHEAD');
      expect(overhead).toBeDefined();
      expect(overhead.totalCost).toBe(300);
    });

    it('should calculate total production cost', async () => {
      const result = await service.findOne(orderId, companyId);

      const totalCost = result.data.items.reduce((sum: number, item: any) => sum + item.totalCost, 0);
      expect(totalCost).toBe(2150); // 1250 + 600 + 300
    });

    it('should calculate cost per unit', async () => {
      const result = await service.findOne(orderId, companyId);

      const totalCost = result.data.items.reduce((sum: number, item: any) => sum + item.totalCost, 0);
      const costPerUnit = totalCost / result.data.quantity;

      expect(costPerUnit).toBe(2.15); // 2150 / 1000
    });

    it('should create items with correct cost calculations', async () => {
      const dto = {
        productId,
        quantity: 500,
        items: [
          { type: 'RAW_MATERIAL', quantity: 250, unitCost: 3, totalCost: 750, productId: 'raw-2' },
          { type: 'LABOR', quantity: 20, unitCost: 20, totalCost: 400, productId: null },
        ],
      };

      await service.create(companyId, dto);

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.items.create).toHaveLength(2);
      expect(createCall.data.items.create[0].totalCost).toBe(750);
      expect(createCall.data.items.create[1].totalCost).toBe(400);
    });
  });

  // ========== Multi-company Isolation ==========
  describe('Multi-company Isolation', () => {
    it('should scope findAll to company', async () => {
      await service.findAll(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.productionOrder.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });

    it('should scope findOne to company', async () => {
      await service.findOne(orderId, companyId);

      expect(mockPrismaService.productionOrder.findFirst).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ id: orderId, companyId }),
        }),
      );
    });

    it('should scope create to company', async () => {
      await service.create(companyId, {
        productId,
        quantity: 100,
      });

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.companyId).toBe(companyId);
    });

    it('should not find order from another company', async () => {
      mockPrismaService.productionOrder.findFirst.mockResolvedValue(null);

      await expect(service.findOne(orderId, 'other-company')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Edge Cases ==========
  describe('Edge Cases', () => {
    it('should handle production order with zero quantity', async () => {
      await service.create(companyId, {
        productId,
        quantity: 0,
      });

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.quantity).toBe(0);
    });

    it('should handle production order with empty notes', async () => {
      await service.create(companyId, {
        productId,
        quantity: 100,
        notes: '',
      });

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.notes).toBe('');
    });

    it('should handle production order with null notes', async () => {
      await service.create(companyId, {
        productId,
        quantity: 100,
      });

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.notes).toBeUndefined();
    });

    it('should handle items with null productId', async () => {
      await service.create(companyId, {
        productId,
        quantity: 100,
        items: [
          { type: 'LABOR', quantity: 10, unitCost: 15, totalCost: 150, productId: null },
        ],
      });

      const createCall = mockPrismaService.productionOrder.create.mock.calls[0][0];
      expect(createCall.data.items.create[0].productId).toBeNull();
    });
  });
});
