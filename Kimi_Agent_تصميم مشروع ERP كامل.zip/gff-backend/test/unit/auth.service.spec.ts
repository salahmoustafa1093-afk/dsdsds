import { Test, TestingModule } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { AuthService } from '@/auth/auth.service';
import { PrismaService } from '@/prisma/prisma.service';
import { ConflictException, UnauthorizedException, NotFoundException, BadRequestException } from '@nestjs/common';

// Mock password utils
jest.mock('@/common/utils/password.util', () => ({
  hashPassword: jest.fn().mockResolvedValue('hashed_password_123'),
  comparePassword: jest.fn(),
}));

// Mock token util
jest.mock('@/common/utils/token.util', () => ({
  generateSecureToken: jest.fn().mockReturnValue('mock_refresh_token_123'),
}));

import { hashPassword, comparePassword } from '@/common/utils/password.util';
import { generateSecureToken } from '@/common/utils/token.util';

describe('AuthService', () => {
  let service: AuthService;
  let mockPrismaService: any;
  let mockJwtService: any;

  const mockCompany = {
    id: 'company-1',
    name: 'Test Company',
    email: 'test@company.com',
    phone: '+962799111222',
  };

  const mockRole = {
    id: 'role-1',
    name: 'super_admin',
    description: 'Super Administrator with full access',
    permissions: ['*'],
    isSystem: true,
    companyId: 'company-1',
  };

  const mockUser = {
    id: 'user-1',
    name: 'John Doe',
    email: 'john@company.com',
    password: 'hashed_password_123',
    phone: '+962799111222',
    companyId: 'company-1',
    roleId: 'role-1',
    emailVerified: true,
    status: 'ACTIVE',
    lastLoginAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    role: mockRole,
    company: mockCompany,
  };

  const mockRefreshTokenRecord = {
    id: 'rt-1',
    token: 'valid_refresh_token',
    userId: 'user-1',
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    revokedAt: null,
    createdAt: new Date(),
    user: mockUser,
  };

  beforeEach(async () => {
    mockPrismaService = {
      user: {
        findFirst: jest.fn(),
        findUnique: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        updateMany: jest.fn(),
      },
      company: {
        create: jest.fn(),
      },
      role: {
        create: jest.fn(),
      },
      refreshToken: {
        findUnique: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        updateMany: jest.fn(),
      },
    };

    mockJwtService = {
      sign: jest.fn().mockReturnValue('mock_access_token_123'),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: PrismaService, useValue: mockPrismaService },
        { provide: JwtService, useValue: mockJwtService },
        {
          provide: ConfigService,
          useValue: {
            get: jest.fn((key: string, defaultValue?: any) => {
              const config: Record<string, any> = {
                JWT_SECRET: 'test_jwt_secret',
                JWT_ACCESS_EXPIRATION: '15m',
                JWT_REFRESH_EXPIRATION: '7d',
              };
              return config[key] ?? defaultValue;
            }),
          },
        },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    jest.clearAllMocks();
  });

  describe('register()', () => {
    const registerDto = {
      name: 'John Doe',
      email: 'john@company.com',
      password: 'StrongP@ss123',
      companyName: 'Test Company',
      phone: '+962799111222',
    };

    it('should register a new user with company successfully', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);
      mockPrismaService.company.create.mockResolvedValue(mockCompany);
      mockPrismaService.role.create.mockResolvedValue(mockRole);
      mockPrismaService.user.create.mockResolvedValue(mockUser);
      mockPrismaService.refreshToken.create.mockResolvedValue({ id: 'rt-1' });

      const result = await service.register(registerDto);

      expect(mockPrismaService.user.findFirst).toHaveBeenCalledWith({
        where: { email: registerDto.email },
      });
      expect(hashPassword).toHaveBeenCalledWith(registerDto.password);
      expect(mockPrismaService.company.create).toHaveBeenCalled();
      expect(mockPrismaService.role.create).toHaveBeenCalled();
      expect(mockPrismaService.user.create).toHaveBeenCalled();
      expect(result.user).toBeDefined();
      expect(result.company).toEqual({ id: mockCompany.id, name: mockCompany.name });
      expect(result.accessToken).toBe('mock_access_token_123');
      expect(result.refreshToken).toBe('mock_refresh_token_123');
    });

    it('should throw ConflictException when email already exists', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      await expect(service.register(registerDto)).rejects.toThrow(ConflictException);
      await expect(service.register(registerDto)).rejects.toThrow('Email already registered');
      expect(mockPrismaService.company.create).not.toHaveBeenCalled();
    });

    it('should hash the password before storing', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);
      mockPrismaService.company.create.mockResolvedValue(mockCompany);
      mockPrismaService.role.create.mockResolvedValue(mockRole);
      mockPrismaService.user.create.mockResolvedValue(mockUser);
      mockPrismaService.refreshToken.create.mockResolvedValue({ id: 'rt-1' });

      await service.register(registerDto);

      expect(hashPassword).toHaveBeenCalledTimes(1);
      expect(hashPassword).toHaveBeenCalledWith(registerDto.password);
      const createCall = mockPrismaService.user.create.mock.calls[0][0];
      expect(createCall.data.password).toBe('hashed_password_123');
    });
  });

  describe('login()', () => {
    const loginDto = {
      email: 'john@company.com',
      password: 'StrongP@ss123',
    };

    it('should login with valid credentials', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(true);
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);
      mockPrismaService.user.update.mockResolvedValue({ ...mockUser, lastLoginAt: new Date() });
      mockPrismaService.refreshToken.create.mockResolvedValue({ id: 'rt-1' });

      const result = await service.login(loginDto);

      expect(result.user).toBeDefined();
      expect(result.accessToken).toBe('mock_access_token_123');
      expect(result.refreshToken).toBe('mock_refresh_token_123');
      expect(mockPrismaService.user.update).toHaveBeenCalledWith({
        where: { id: mockUser.id },
        data: { lastLoginAt: expect.any(Date) },
      });
    });

    it('should throw UnauthorizedException for wrong password', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(false);
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      await expect(service.login(loginDto)).rejects.toThrow(UnauthorizedException);
      await expect(service.login(loginDto)).rejects.toThrow('Invalid email or password');
    });

    it('should throw UnauthorizedException for inactive user', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(true);
      mockPrismaService.user.findFirst.mockResolvedValue({
        ...mockUser,
        status: 'INACTIVE',
      });

      await expect(service.login(loginDto)).rejects.toThrow(UnauthorizedException);
    });

    it('should throw UnauthorizedException for non-existent email', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      await expect(service.login(loginDto)).rejects.toThrow(UnauthorizedException);
    });

    it('should throw UnauthorizedException for suspended user', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(true);
      mockPrismaService.user.findFirst.mockResolvedValue({
        ...mockUser,
        status: 'SUSPENDED',
      });

      await expect(service.login(loginDto)).rejects.toThrow(UnauthorizedException);
    });
  });

  describe('refresh()', () => {
    const refreshDto = {
      refreshToken: 'valid_refresh_token',
    };

    it('should refresh tokens with valid refresh token', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue(mockRefreshTokenRecord);
      mockPrismaService.refreshToken.update.mockResolvedValue({
        ...mockRefreshTokenRecord,
        revokedAt: new Date(),
      });
      mockPrismaService.refreshToken.create.mockResolvedValue({ id: 'rt-2' });

      const result = await service.refresh(refreshDto);

      expect(result.accessToken).toBe('mock_access_token_123');
      expect(result.refreshToken).toBe('mock_refresh_token_123');
      expect(mockPrismaService.refreshToken.update).toHaveBeenCalled();
    });

    it('should throw UnauthorizedException for expired refresh token', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue({
        ...mockRefreshTokenRecord,
        expiresAt: new Date(Date.now() - 1000),
      });

      await expect(service.refresh(refreshDto)).rejects.toThrow(UnauthorizedException);
      await expect(service.refresh(refreshDto)).rejects.toThrow('Refresh token has expired');
    });

    it('should throw UnauthorizedException for revoked token', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue({
        ...mockRefreshTokenRecord,
        revokedAt: new Date(),
      });

      await expect(service.refresh(refreshDto)).rejects.toThrow(UnauthorizedException);
      await expect(service.refresh(refreshDto)).rejects.toThrow('Invalid refresh token');
    });

    it('should throw UnauthorizedException for non-existent token', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue(null);

      await expect(service.refresh(refreshDto)).rejects.toThrow(UnauthorizedException);
    });

    it('should revoke old refresh token and generate new one', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue(mockRefreshTokenRecord);
      mockPrismaService.refreshToken.update.mockResolvedValue({
        ...mockRefreshTokenRecord,
        revokedAt: new Date(),
      });
      mockPrismaService.refreshToken.create.mockResolvedValue({ id: 'rt-2' });

      await service.refresh(refreshDto);

      expect(mockPrismaService.refreshToken.update).toHaveBeenCalledWith({
        where: { id: 'rt-1' },
        data: { revokedAt: expect.any(Date) },
      });
      expect(generateSecureToken).toHaveBeenCalled();
      expect(mockJwtService.sign).toHaveBeenCalled();
    });
  });

  describe('logout()', () => {
    it('should revoke the refresh token on logout', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue(mockRefreshTokenRecord);
      mockPrismaService.refreshToken.update.mockResolvedValue({
        ...mockRefreshTokenRecord,
        revokedAt: new Date(),
      });

      const result = await service.logout('valid_refresh_token');

      expect(result.message).toBe('Logged out successfully');
      expect(mockPrismaService.refreshToken.update).toHaveBeenCalledWith({
        where: { id: 'rt-1' },
        data: { revokedAt: expect.any(Date) },
      });
    });

    it('should succeed silently if token does not exist', async () => {
      mockPrismaService.refreshToken.findUnique.mockResolvedValue(null);

      const result = await service.logout('nonexistent_token');

      expect(result.message).toBe('Logged out successfully');
      expect(mockPrismaService.refreshToken.update).not.toHaveBeenCalled();
    });
  });

  describe('forgotPassword()', () => {
    const forgotDto = {
      email: 'john@company.com',
    };

    it('should return success message for existing email', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      const result = await service.forgotPassword(forgotDto);

      expect(result.message).toBe('If the email exists, a reset link will be sent.');
      expect(mockPrismaService.user.findFirst).toHaveBeenCalledWith({
        where: { email: forgotDto.email },
      });
    });

    it('should return same message for non-existent email (no info leak)', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      const result = await service.forgotPassword(forgotDto);

      expect(result.message).toBe('If the email exists, a reset link will be sent.');
      expect(generateSecureToken).not.toHaveBeenCalled();
    });
  });

  describe('resetPassword()', () => {
    const resetDto = {
      token: 'some_reset_token',
      password: 'NewP@ss123',
    };

    it('should throw BadRequestException since not implemented', async () => {
      await expect(service.resetPassword(resetDto)).rejects.toThrow(BadRequestException);
      await expect(service.resetPassword(resetDto)).rejects.toThrow('Token validation not implemented');
    });
  });

  describe('changePassword()', () => {
    const changeDto = {
      oldPassword: 'OldP@ss123',
      newPassword: 'NewP@ss456',
    };

    it('should change password with correct old password', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(true);
      mockPrismaService.user.findUnique.mockResolvedValue(mockUser);
      mockPrismaService.user.update.mockResolvedValue({
        ...mockUser,
        password: 'new_hashed_password',
      });
      mockPrismaService.refreshToken.updateMany.mockResolvedValue({ count: 3 });

      const result = await service.changePassword('user-1', changeDto);

      expect(comparePassword).toHaveBeenCalledWith(changeDto.oldPassword, mockUser.password);
      expect(hashPassword).toHaveBeenCalledWith(changeDto.newPassword);
      expect(mockPrismaService.refreshToken.updateMany).toHaveBeenCalledWith({
        where: { userId: 'user-1' },
        data: { revokedAt: expect.any(Date) },
      });
      expect(result.message).toBe('Password changed successfully');
    });

    it('should throw NotFoundException if user not found', async () => {
      mockPrismaService.user.findUnique.mockResolvedValue(null);

      await expect(service.changePassword('nonexistent', changeDto)).rejects.toThrow(NotFoundException);
    });

    it('should throw BadRequestException for wrong old password', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(false);
      mockPrismaService.user.findUnique.mockResolvedValue(mockUser);

      await expect(service.changePassword('user-1', changeDto)).rejects.toThrow(BadRequestException);
      await expect(service.changePassword('user-1', changeDto)).rejects.toThrow('Current password is incorrect');
    });
  });

  describe('getProfile()', () => {
    it('should return user profile without password', async () => {
      mockPrismaService.user.findUnique.mockResolvedValue(mockUser);

      const result = await service.getProfile('user-1');

      expect(result.user).toBeDefined();
      expect(result.user.password).toBeUndefined();
      expect(result.user.email).toBe(mockUser.email);
    });

    it('should throw NotFoundException if user not found', async () => {
      mockPrismaService.user.findUnique.mockResolvedValue(null);

      await expect(service.getProfile('nonexistent')).rejects.toThrow(NotFoundException);
    });
  });

  describe('updateProfile()', () => {
    it('should update user profile', async () => {
      const updateData = { name: 'John Updated', phone: '+962799333444' };
      mockPrismaService.user.update.mockResolvedValue({
        ...mockUser,
        ...updateData,
      });

      const result = await service.updateProfile('user-1', updateData);

      expect(result.user.name).toBe('John Updated');
      expect(result.user.phone).toBe('+962799333444');
    });
  });

  describe('validateUser()', () => {
    it('should return user for valid credentials', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(true);
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      const result = await service.validateUser('john@company.com', 'StrongP@ss123');

      expect(result).toBeDefined();
      expect(result?.email).toBe('john@company.com');
    });

    it('should return null for non-existent user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(null);

      const result = await service.validateUser('nonexistent@test.com', 'password');

      expect(result).toBeNull();
    });

    it('should return null for wrong password', async () => {
      (comparePassword as jest.Mock).mockResolvedValue(false);
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);

      const result = await service.validateUser('john@company.com', 'wrongpassword');

      expect(result).toBeNull();
    });

    it('should return null for inactive user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue({
        ...mockUser,
        status: 'INACTIVE',
      });

      const result = await service.validateUser('john@company.com', 'StrongP@ss123');

      expect(result).toBeNull();
    });

    it('should return null for suspended user', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue({
        ...mockUser,
        status: 'SUSPENDED',
      });

      const result = await service.validateUser('john@company.com', 'StrongP@ss123');

      expect(result).toBeNull();
    });
  });

  describe('generateTokens()', () => {
    it('should include correct payload in JWT', async () => {
      mockPrismaService.user.findFirst.mockResolvedValue(mockUser);
      mockPrismaService.user.update.mockResolvedValue(mockUser);
      mockPrismaService.refreshToken.create.mockResolvedValue({ id: 'rt-1' });
      (comparePassword as jest.Mock).mockResolvedValue(true);

      await service.login({ email: 'john@company.com', password: 'StrongP@ss123' });

      expect(mockJwtService.sign).toHaveBeenCalledWith(
        expect.objectContaining({
          sub: mockUser.id,
          email: mockUser.email,
          companyId: mockUser.companyId,
          role: mockRole.name,
          permissions: mockRole.permissions,
        }),
        expect.any(Object),
      );
    });
  });
});
