import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException } from '@nestjs/common';
import { FleetService } from '@/fleet/fleet.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('FleetService', () => {
  let service: FleetService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const vehicleId = 'vehicle-1';

  const mockVehicle = {
    id: vehicleId,
    plateNumber: 'ABC-123',
    make: 'Toyota',
    model: 'Hilux',
    year: 2022,
    color: 'White',
    vin: 'JT3HP10VXN7119563',
    engineNumber: 'ENGINE001',
    fuelType: 'DIESEL',
    tankCapacity: 80,
    currentMileage: 25000,
    status: 'ACTIVE',
    companyId,
    purchaseDate: new Date('2022-01-15'),
    insuranceExpiry: new Date('2025-01-15'),
    licenseExpiry: new Date('2024-12-31'),
    deletedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockDriver = {
    id: 'driver-1',
    firstName: 'Ahmed',
    lastName: 'Hassan',
    licenseNumber: 'DL-123456',
    licenseType: 'Heavy Vehicle',
    licenseExpiry: new Date('2025-06-30'),
    phone: '+962799111222',
    email: 'ahmed@company.com',
    dateOfBirth: new Date('1985-03-15'),
    hireDate: new Date('2020-01-10'),
    status: 'ACTIVE',
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockFuelLog = {
    id: 'fuel-1',
    vehicleId,
    fuelType: 'DIESEL',
    liters: 60,
    pricePerLiter: 0.85,
    totalCost: 51.0,
    mileage: 25000,
    station: 'Petro Station 1',
    notes: 'Regular fill',
    date: new Date(),
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockMaintenanceRecord = {
    id: 'maint-1',
    vehicleId,
    type: 'PREVENTIVE',
    description: 'Oil change and filter replacement',
    cost: 150,
    mileage: 25000,
    scheduledDate: new Date('2024-02-01'),
    nextDueDate: new Date('2024-05-01'),
    nextDueMileage: 30000,
    performedBy: 'Auto Shop Co.',
    notes: 'Used synthetic oil',
    status: 'SCHEDULED',
    completedDate: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    mockPrismaService = {
      vehicle: {
        findFirst: jest.fn().mockResolvedValue(mockVehicle),
        findUnique: jest.fn().mockResolvedValue(null),
        findMany: jest.fn().mockResolvedValue([mockVehicle]),
        create: jest.fn().mockResolvedValue(mockVehicle),
        update: jest.fn().mockResolvedValue(mockVehicle),
        count: jest.fn().mockResolvedValue(1),
      },
      driver: {
        findUnique: jest.fn().mockResolvedValue(mockDriver),
        findMany: jest.fn().mockResolvedValue([mockDriver]),
        create: jest.fn().mockResolvedValue(mockDriver),
        update: jest.fn().mockResolvedValue(mockDriver),
        count: jest.fn().mockResolvedValue(1),
      },
      fuelLog: {
        findMany: jest.fn().mockResolvedValue([mockFuelLog]),
        create: jest.fn().mockResolvedValue(mockFuelLog),
      },
      maintenanceRecord: {
        findFirst: jest.fn().mockResolvedValue(mockMaintenanceRecord),
        findMany: jest.fn().mockResolvedValue([mockMaintenanceRecord]),
        create: jest.fn().mockResolvedValue(mockMaintenanceRecord),
        update: jest.fn().mockResolvedValue(mockMaintenanceRecord),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        FleetService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<FleetService>(FleetService);
    jest.clearAllMocks();
  });

  // ========== Vehicle CRUD ==========
  describe('findAllVehicles()', () => {
    it('should return paginated vehicles for company', async () => {
      const result = await service.findAllVehicles(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.page).toBe(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by status', async () => {
      await service.findAllVehicles(companyId, { page: 1, limit: 10, status: 'ACTIVE' });

      expect(mockPrismaService.vehicle.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ status: 'ACTIVE' }),
        }),
      );
    });

    it('should search by plate number', async () => {
      await service.findAllVehicles(companyId, { page: 1, limit: 10, search: 'ABC' });

      expect(mockPrismaService.vehicle.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: expect.arrayContaining([
              { plateNumber: { contains: 'ABC', mode: 'insensitive' } },
            ]),
          }),
        }),
      );
    });

    it('should search by make or model', async () => {
      await service.findAllVehicles(companyId, { page: 1, limit: 10, search: 'Toyota' });

      expect(mockPrismaService.vehicle.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: expect.arrayContaining([
              { make: { contains: 'Toyota', mode: 'insensitive' } },
              { model: { contains: 'Toyota', mode: 'insensitive' } },
            ]),
          }),
        }),
      );
    });

    it('should exclude deleted vehicles', async () => {
      await service.findAllVehicles(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.vehicle.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ deletedAt: null }),
        }),
      );
    });
  });

  describe('findOneVehicle()', () => {
    it('should return vehicle with fuel logs and maintenance', async () => {
      const result = await service.findOneVehicle(vehicleId, companyId);

      expect(result.data.id).toBe(vehicleId);
      expect(result.data.fuelLogs).toBeDefined();
      expect(result.data.maintenanceRecords).toBeDefined();
    });

    it('should throw NotFoundException for non-existent vehicle', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.findOneVehicle('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for vehicle in another company', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.findOneVehicle(vehicleId, 'other-company')).rejects.toThrow(NotFoundException);
    });
  });

  describe('createVehicle()', () => {
    const createVehicleDto = {
      plateNumber: 'XYZ-789',
      make: 'Ford',
      model: 'Ranger',
      year: 2023,
      color: 'Black',
      vin: '1FTFW1ET5DFC10312',
      engineNumber: 'ENGINE002',
      fuelType: 'DIESEL',
      tankCapacity: 75,
      currentMileage: 0,
      purchaseDate: '2023-06-01',
      insuranceExpiry: '2024-06-01',
      licenseExpiry: '2024-12-31',
    };

    it('should create a new vehicle', async () => {
      const result = await service.createVehicle(companyId, createVehicleDto);

      expect(result.data).toBeDefined();
      expect(result.data.plateNumber).toBe('ABC-123');
    });

    it('should throw ConflictException for duplicate plate number', async () => {
      mockPrismaService.vehicle.findUnique.mockResolvedValue(mockVehicle);

      await expect(service.createVehicle(companyId, createVehicleDto)).rejects.toThrow(ConflictException);
    });

    it('should parse purchaseDate to Date', async () => {
      await service.createVehicle(companyId, createVehicleDto);

      const createCall = mockPrismaService.vehicle.create.mock.calls[0][0];
      expect(createCall.data.purchaseDate).toBeInstanceOf(Date);
    });

    it('should parse insuranceExpiry to Date', async () => {
      await service.createVehicle(companyId, createVehicleDto);

      const createCall = mockPrismaService.vehicle.create.mock.calls[0][0];
      expect(createCall.data.insuranceExpiry).toBeInstanceOf(Date);
    });

    it('should parse licenseExpiry to Date', async () => {
      await service.createVehicle(companyId, createVehicleDto);

      const createCall = mockPrismaService.vehicle.create.mock.calls[0][0];
      expect(createCall.data.licenseExpiry).toBeInstanceOf(Date);
    });

    it('should scope vehicle to company', async () => {
      await service.createVehicle(companyId, createVehicleDto);

      expect(mockPrismaService.vehicle.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  describe('updateVehicle()', () => {
    it('should update vehicle fields', async () => {
      mockPrismaService.vehicle.update.mockResolvedValue({
        ...mockVehicle,
        color: 'Red',
        currentMileage: 26000,
      });

      const result = await service.updateVehicle(vehicleId, companyId, {
        color: 'Red',
        currentMileage: 26000,
      });

      expect(result.data.color).toBe('Red');
      expect(result.data.currentMileage).toBe(26000);
    });

    it('should throw NotFoundException for non-existent vehicle', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.updateVehicle('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  describe('removeVehicle()', () => {
    it('should soft delete vehicle with RETIRED status', async () => {
      const result = await service.removeVehicle(vehicleId, companyId);

      expect(result.data.message).toBe('Vehicle deleted successfully');
      expect(mockPrismaService.vehicle.update).toHaveBeenCalledWith({
        where: { id: vehicleId },
        data: { deletedAt: expect.any(Date), status: 'RETIRED' },
      });
    });

    it('should throw NotFoundException for non-existent vehicle', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.removeVehicle('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Drivers ==========
  describe('findAllDrivers()', () => {
    it('should return paginated drivers', async () => {
      const result = await service.findAllDrivers({ page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should search by license number', async () => {
      await service.findAllDrivers({ page: 1, limit: 10, search: 'DL-123' });

      expect(mockPrismaService.driver.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: expect.arrayContaining([
              { licenseNumber: { contains: 'DL-123', mode: 'insensitive' } },
            ]),
          }),
        }),
      );
    });
  });

  describe('createDriver()', () => {
    const createDriverDto = {
      firstName: 'Mohammed',
      lastName: 'Ali',
      licenseNumber: 'DL-789012',
      licenseType: 'Light Vehicle',
      licenseExpiry: '2025-12-31',
      phone: '+962799333444',
      email: 'mohammed@company.com',
      dateOfBirth: '1990-01-01',
      hireDate: '2023-01-01',
    };

    it('should create a driver', async () => {
      const result = await service.createDriver(createDriverDto);

      expect(result.data).toBeDefined();
    });

    it('should parse licenseExpiry to Date', async () => {
      await service.createDriver(createDriverDto);

      const createCall = mockPrismaService.driver.create.mock.calls[0][0];
      expect(createCall.data.licenseExpiry).toBeInstanceOf(Date);
    });
  });

  describe('updateDriver()', () => {
    it('should update driver', async () => {
      const result = await service.updateDriver('driver-1', { firstName: 'Updated' });

      expect(result.data).toBeDefined();
    });

    it('should throw NotFoundException for non-existent driver', async () => {
      mockPrismaService.driver.findUnique.mockResolvedValue(null);

      await expect(service.updateDriver('nonexistent', {})).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Fuel Logs ==========
  describe('addFuelLog()', () => {
    const fuelLogDto = {
      fuelType: 'DIESEL' as const,
      liters: 60,
      pricePerLiter: 0.85,
      mileage: 26000,
      station: 'Petro Station 2',
      notes: 'Highway trip',
    };

    it('should create fuel log with calculated total cost', async () => {
      const result = await service.addFuelLog(vehicleId, companyId, fuelLogDto);

      expect(result.data).toBeDefined();
      expect(result.data.totalCost).toBe(51.0); // 60 * 0.85
    });

    it('should update vehicle mileage', async () => {
      await service.addFuelLog(vehicleId, companyId, fuelLogDto);

      expect(mockPrismaService.vehicle.update).toHaveBeenCalledWith({
        where: { id: vehicleId },
        data: { currentMileage: 26000 },
      });
    });

    it('should calculate total cost correctly', async () => {
      const result = await service.addFuelLog(vehicleId, companyId, {
        ...fuelLogDto,
        liters: 40,
        pricePerLiter: 0.9,
      });

      expect(result.data.totalCost).toBe(36.0); // 40 * 0.9
    });

    it('should throw NotFoundException for non-existent vehicle', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.addFuelLog('nonexistent', companyId, fuelLogDto)).rejects.toThrow(NotFoundException);
    });
  });

  describe('getFuelLogs()', () => {
    it('should return fuel logs with totals', async () => {
      const result = await service.getFuelLogs(vehicleId, companyId);

      expect(result.data.logs).toHaveLength(1);
      expect(result.data.totalCost).toBe(51.0);
      expect(result.data.totalLiters).toBe(60);
    });

    it('should calculate totals from multiple logs', async () => {
      mockPrismaService.fuelLog.findMany.mockResolvedValue([
        { ...mockFuelLog, totalCost: 51.0, liters: 60 },
        { ...mockFuelLog, id: 'fuel-2', totalCost: 34.0, liters: 40 },
        { ...mockFuelLog, id: 'fuel-3', totalCost: 42.5, liters: 50 },
      ]);

      const result = await service.getFuelLogs(vehicleId, companyId);

      expect(result.data.totalCost).toBe(127.5); // 51 + 34 + 42.5
      expect(result.data.totalLiters).toBe(150); // 60 + 40 + 50
    });

    it('should throw NotFoundException for non-existent vehicle', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.getFuelLogs('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Maintenance ==========
  describe('addMaintenance()', () => {
    const maintenanceDto = {
      type: 'PREVENTIVE' as const,
      description: 'Regular oil change',
      cost: 150,
      mileage: 25000,
      scheduledDate: '2024-03-01',
      nextDueDate: '2024-06-01',
      nextDueMileage: 30000,
      performedBy: 'Auto Shop Co.',
      notes: 'Used 5W-30 synthetic',
    };

    it('should create maintenance record', async () => {
      const result = await service.addMaintenance(vehicleId, companyId, maintenanceDto);

      expect(result.data).toBeDefined();
      expect(result.data.type).toBe('PREVENTIVE');
    });

    it('should set vehicle status to MAINTENANCE for PREVENTIVE', async () => {
      await service.addMaintenance(vehicleId, companyId, maintenanceDto);

      expect(mockPrismaService.vehicle.update).toHaveBeenCalledWith({
        where: { id: vehicleId },
        data: { status: 'MAINTENANCE' },
      });
    });

    it('should set vehicle status to MAINTENANCE for CORRECTIVE', async () => {
      await service.addMaintenance(vehicleId, companyId, {
        ...maintenanceDto,
        type: 'CORRECTIVE' as const,
        description: 'Brake repair',
      });

      expect(mockPrismaService.vehicle.update).toHaveBeenCalledWith({
        where: { id: vehicleId },
        data: { status: 'MAINTENANCE' },
      });
    });

    it('should not change status for INSPECTION', async () => {
      await service.addMaintenance(vehicleId, companyId, {
        ...maintenanceDto,
        type: 'INSPECTION' as const,
      });

      expect(mockPrismaService.vehicle.update).not.toHaveBeenCalled();
    });

    it('should parse scheduledDate to Date', async () => {
      await service.addMaintenance(vehicleId, companyId, maintenanceDto);

      const createCall = mockPrismaService.maintenanceRecord.create.mock.calls[0][0];
      expect(createCall.data.scheduledDate).toBeInstanceOf(Date);
    });

    it('should parse nextDueDate to Date', async () => {
      await service.addMaintenance(vehicleId, companyId, maintenanceDto);

      const createCall = mockPrismaService.maintenanceRecord.create.mock.calls[0][0];
      expect(createCall.data.nextDueDate).toBeInstanceOf(Date);
    });

    it('should throw NotFoundException for non-existent vehicle', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.addMaintenance('nonexistent', companyId, maintenanceDto)).rejects.toThrow(NotFoundException);
    });
  });

  describe('getMaintenanceRecords()', () => {
    it('should return maintenance records for vehicle', async () => {
      const result = await service.getMaintenanceRecords(vehicleId, companyId);

      expect(result.data).toHaveLength(1);
    });

    it('should throw NotFoundException for non-existent vehicle', async () => {
      mockPrismaService.vehicle.findFirst.mockResolvedValue(null);

      await expect(service.getMaintenanceRecords('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  describe('updateMaintenanceStatus()', () => {
    it('should update to COMPLETED and set vehicle ACTIVE', async () => {
      mockPrismaService.maintenanceRecord.findFirst.mockResolvedValue(mockMaintenanceRecord);
      mockPrismaService.maintenanceRecord.update.mockResolvedValue({
        ...mockMaintenanceRecord,
        status: 'COMPLETED',
        completedDate: new Date(),
      });

      const result = await service.updateMaintenanceStatus('maint-1', companyId, 'COMPLETED');

      expect(result.data.status).toBe('COMPLETED');
      expect(mockPrismaService.vehicle.update).toHaveBeenCalledWith({
        where: { id: vehicleId },
        data: { status: 'ACTIVE' },
      });
    });

    it('should set completedDate when status is COMPLETED', async () => {
      mockPrismaService.maintenanceRecord.findFirst.mockResolvedValue(mockMaintenanceRecord);

      await service.updateMaintenanceStatus('maint-1', companyId, 'COMPLETED');

      expect(mockPrismaService.maintenanceRecord.update).toHaveBeenCalledWith({
        where: { id: 'maint-1' },
        data: expect.objectContaining({
          status: 'COMPLETED',
          completedDate: expect.any(Date),
        }),
      });
    });

    it('should not set completedDate for non-COMPLETED status', async () => {
      mockPrismaService.maintenanceRecord.findFirst.mockResolvedValue(mockMaintenanceRecord);

      await service.updateMaintenanceStatus('maint-1', companyId, 'IN_PROGRESS');

      expect(mockPrismaService.maintenanceRecord.update).toHaveBeenCalledWith({
        where: { id: 'maint-1' },
        data: expect.objectContaining({
          status: 'IN_PROGRESS',
        }),
      );
      const updateCall = mockPrismaService.maintenanceRecord.update.mock.calls[0][0];
      expect(updateCall.data.completedDate).toBeUndefined();
    });

    it('should throw NotFoundException for record in another company', async () => {
      mockPrismaService.maintenanceRecord.findFirst.mockResolvedValue(null);

      await expect(service.updateMaintenanceStatus('nonexistent', companyId, 'COMPLETED')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Fleet Dashboard ==========
  describe('getFleetStats()', () => {
    it('should return fleet statistics', async () => {
      const result = await service.getFleetStats(companyId);

      expect(result.data.total).toBe(1);
      expect(result.data.active).toBe(1);
      expect(result.data.inMaintenance).toBe(1);
      expect(result.data.retired).toBe(1);
    });

    it('should scope to company', async () => {
      await service.getFleetStats(companyId);

      expect(mockPrismaService.vehicle.count).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  describe('getUpcomingMaintenance()', () => {
    it('should return upcoming maintenance within 30 days', async () => {
      const result = await service.getUpcomingMaintenance(companyId);

      expect(result.data).toBeDefined();
      expect(Array.isArray(result.data)).toBe(true);
    });

    it('should scope to company', async () => {
      await service.getUpcomingMaintenance(companyId);

      expect(mockPrismaService.maintenanceRecord.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            vehicle: { companyId },
          }),
        }),
      );
    });

    it('should filter by SCHEDULED and OVERDUE status', async () => {
      await service.getUpcomingMaintenance(companyId);

      expect(mockPrismaService.maintenanceRecord.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            status: { in: ['SCHEDULED', 'OVERDUE'] },
          }),
        }),
      );
    });
  });
});
