import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, BadRequestException } from '@nestjs/common';
import { InventoryService } from '@/inventory/inventory.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('InventoryService', () => {
  let service: InventoryService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const warehouseId = 'warehouse-1';
  const stockId = 'stock-1';
  const productId = 'product-1';

  const mockWarehouse = {
    id: warehouseId,
    name: 'Main Warehouse',
    companyId,
  };

  const mockStock = {
    id: stockId,
    productId,
    warehouseId,
    locationId: 'location-1',
    quantity: 100,
    reservedQty: 10,
    product: {
      id: productId,
      name: 'Chicken Feed 25kg',
      sku: 'CF25',
      minStock: 20,
      maxStock: 200,
      unit: 'bag',
    },
    warehouse: { id: warehouseId, name: 'Main Warehouse' },
    location: { id: 'location-1', zone: 'A', aisle: '1', rack: '2', bin: '3' },
  };

  const mockStockMovement = {
    id: 'movement-1',
    stockId,
    type: 'INBOUND',
    quantity: 50,
    beforeQty: 50,
    afterQty: 100,
    reference: 'PO-001',
    referenceId: null,
    notes: 'Stock receipt',
    createdBy: 'user-1',
    createdAt: new Date(),
  };

  const mockTransfer = {
    id: 'transfer-1',
    transferNumber: 'TRF-ABC123',
    fromWarehouseId: warehouseId,
    toWarehouseId: 'warehouse-2',
    status: 'PENDING',
    notes: 'Restock',
    items: [
      {
        id: 'ti-1',
        productId,
        quantity: 20,
        batchNumber: 'BATCH001',
        product: { id: productId, name: 'Chicken Feed 25kg', sku: 'CF25' },
      },
    ],
  };

  beforeEach(async () => {
    mockPrismaService = {
      stock: {
        findMany: jest.fn().mockResolvedValue([mockStock]),
        findFirst: jest.fn().mockResolvedValue(mockStock),
        findUnique: jest.fn().mockResolvedValue(mockStock),
        create: jest.fn().mockResolvedValue(mockStock),
        update: jest.fn().mockResolvedValue(mockStock),
        fields: { reservedQty: 'reservedQty' },
      },
      stockMovement: {
        findMany: jest.fn().mockResolvedValue([mockStockMovement]),
        create: jest.fn().mockResolvedValue(mockStockMovement),
        count: jest.fn().mockResolvedValue(1),
      },
      warehouse: {
        findFirst: jest.fn().mockResolvedValue(mockWarehouse),
        findMany: jest.fn().mockResolvedValue([mockWarehouse]),
      },
      stockTransfer: {
        findFirst: jest.fn().mockResolvedValue(mockTransfer),
        findMany: jest.fn().mockResolvedValue([mockTransfer]),
        create: jest.fn().mockResolvedValue(mockTransfer),
        update: jest.fn().mockResolvedValue(mockTransfer),
        count: jest.fn().mockResolvedValue(1),
      },
    };

    // Mock $transaction
    mockPrismaService.$transaction = jest.fn((cb) => {
      if (typeof cb === 'function') {
        return cb(mockPrismaService);
      }
      return Promise.resolve(cb);
    });

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        InventoryService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<InventoryService>(InventoryService);
    jest.clearAllMocks();
  });

  // ========== getStock ==========
  describe('getStock()', () => {
    it('should return stock items for warehouse', async () => {
      const result = await service.getStock(companyId, { warehouseId });

      expect(result.data.stocks).toHaveLength(1);
      expect(result.data.lowStockItems).toBe(0);
    });

    it('should return low stock count', async () => {
      const lowStock = { ...mockStock, quantity: 15 }; // below minStock of 20
      mockPrismaService.stock.findMany.mockResolvedValue([lowStock]);

      const result = await service.getStock(companyId, { warehouseId });

      expect(result.data.lowStockItems).toBe(1);
    });

    it('should throw NotFoundException for invalid warehouse', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValue(null);

      await expect(service.getStock(companyId, { warehouseId: 'invalid' })).rejects.toThrow(NotFoundException);
    });

    it('should filter by productId', async () => {
      await service.getStock(companyId, { warehouseId, productId });

      expect(mockPrismaService.stock.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ productId }),
        }),
      );
    });

    it('should return empty array when no stock exists', async () => {
      mockPrismaService.stock.findMany.mockResolvedValue([]);

      const result = await service.getStock(companyId, { warehouseId });

      expect(result.data.stocks).toHaveLength(0);
      expect(result.data.lowStockItems).toBe(0);
    });
  });

  // ========== getStockById ==========
  describe('getStockById()', () => {
    it('should return stock with movements', async () => {
      const result = await service.getStockById(stockId);

      expect(result.data).toBeDefined();
      expect(result.data.product).toBeDefined();
      expect(result.data.movements).toBeDefined();
    });

    it('should throw NotFoundException for invalid stock ID', async () => {
      mockPrismaService.stock.findUnique.mockResolvedValue(null);

      await expect(service.getStockById('nonexistent')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== createMovement - INBOUND ==========
  describe('createMovement() - INBOUND', () => {
    const inboundDto = {
      productId,
      warehouseId,
      locationId: 'location-1',
      type: 'INBOUND' as const,
      quantity: 50,
      reference: 'PO-001',
      referenceId: null,
      notes: 'Stock receipt',
    };

    it('should create inbound movement and increase stock', async () => {
      const result = await service.createMovement(companyId, inboundDto, 'user-1');

      expect(result.data).toBeDefined();
      expect(result.data.type).toBe('INBOUND');
      expect(result.data.afterQty).toBe(150); // 100 + 50
    });

    it('should create stock record if not exists for INBOUND', async () => {
      mockPrismaService.stock.findFirst.mockResolvedValue(null);

      await service.createMovement(companyId, inboundDto, 'user-1');

      expect(mockPrismaService.stock.create).toHaveBeenCalledWith({
        data: {
          productId,
          warehouseId,
          locationId: 'location-1',
          quantity: 0,
        },
      });
    });

    it('should throw NotFoundException for invalid warehouse', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValue(null);

      await expect(service.createMovement(companyId, inboundDto)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== createMovement - OUTBOUND ==========
  describe('createMovement() - OUTBOUND', () => {
    const outboundDto = {
      productId,
      warehouseId,
      locationId: 'location-1',
      type: 'OUTBOUND' as const,
      quantity: 30,
      reference: 'SO-001',
      notes: 'Sales order',
    };

    it('should create outbound movement and decrease stock', async () => {
      const result = await service.createMovement(companyId, outboundDto);

      expect(result.data.type).toBe('OUTBOUND');
      expect(result.data.afterQty).toBe(70); // 100 - 30
    });

    it('should throw BadRequestException for insufficient stock', async () => {
      const dtoTooMuch = { ...outboundDto, quantity: 200 };

      await expect(service.createMovement(companyId, dtoTooMuch)).rejects.toThrow(BadRequestException);
      await expect(service.createMovement(companyId, dtoTooMuch)).rejects.toThrow('Insufficient stock quantity');
    });

    it('should throw BadRequestException when stock equals zero', async () => {
      mockPrismaService.stock.findFirst.mockResolvedValue({ ...mockStock, quantity: 0 });

      await expect(service.createMovement(companyId, outboundDto)).rejects.toThrow(BadRequestException);
    });
  });

  // ========== createMovement - TRANSFER ==========
  describe('createMovement() - Transfer types', () => {
    it('should handle TRANSFER_IN', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'TRANSFER_IN' as const,
        quantity: 25,
        reference: 'TRF-001',
      };

      const result = await service.createMovement(companyId, dto);

      expect(result.data.type).toBe('TRANSFER_IN');
      expect(result.data.afterQty).toBe(125); // 100 + 25
    });

    it('should handle TRANSFER_OUT with sufficient stock', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'TRANSFER_OUT' as const,
        quantity: 20,
        reference: 'TRF-001',
      };

      const result = await service.createMovement(companyId, dto);

      expect(result.data.type).toBe('TRANSFER_OUT');
      expect(result.data.afterQty).toBe(80); // 100 - 20
    });

    it('should throw for TRANSFER_OUT with insufficient stock', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'TRANSFER_OUT' as const,
        quantity: 200,
        reference: 'TRF-001',
      };

      await expect(service.createMovement(companyId, dto)).rejects.toThrow(BadRequestException);
    });
  });

  // ========== createMovement - ADJUSTMENT ==========
  describe('createMovement() - ADJUSTMENT', () => {
    it('should set stock to exact quantity', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'ADJUSTMENT' as const,
        quantity: 75, // target quantity
        reference: 'ADJ-001',
        notes: 'Cycle count',
      };

      const result = await service.createMovement(companyId, dto);

      expect(result.data.type).toBe('ADJUSTMENT');
      expect(result.data.afterQty).toBe(75);
    });

    it('should allow adjustment to zero', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'ADJUSTMENT' as const,
        quantity: 0,
        reference: 'ADJ-002',
      };

      const result = await service.createMovement(companyId, dto);

      expect(result.data.afterQty).toBe(0);
    });
  });

  // ========== createMovement - PRODUCTION ==========
  describe('createMovement() - PRODUCTION', () => {
    it('should decrease stock for production usage', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'PRODUCTION' as const,
        quantity: 40,
        reference: 'PROD-001',
      };

      const result = await service.createMovement(companyId, dto);

      expect(result.data.type).toBe('PRODUCTION');
      expect(result.data.afterQty).toBe(60); // 100 - 40
    });

    it('should throw for production exceeding stock', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'PRODUCTION' as const,
        quantity: 150,
        reference: 'PROD-002',
      };

      await expect(service.createMovement(companyId, dto)).rejects.toThrow(BadRequestException);
    });
  });

  // ========== createMovement - RETURN ==========
  describe('createMovement() - RETURN', () => {
    it('should increase stock for returns', async () => {
      const dto = {
        productId,
        warehouseId,
        type: 'RETURN' as const,
        quantity: 10,
        reference: 'RET-001',
      };

      const result = await service.createMovement(companyId, dto);

      expect(result.data.type).toBe('RETURN');
      expect(result.data.afterQty).toBe(110); // 100 + 10
    });
  });

  // ========== getMovements ==========
  describe('getMovements()', () => {
    it('should return paginated movements', async () => {
      const result = await service.getMovements(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by warehouse', async () => {
      await service.getMovements(companyId, { page: 1, limit: 10, warehouseId });

      expect(mockPrismaService.stockMovement.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            stock: { warehouseId },
          }),
        }),
      );
    });

    it('should filter by product', async () => {
      await service.getMovements(companyId, { page: 1, limit: 10, productId });

      expect(mockPrismaService.stockMovement.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            stock: { productId },
          }),
        }),
      );
    });
  });

  // ========== adjustStock ==========
  describe('adjustStock()', () => {
    const adjustmentDto = {
      stockId,
      newQuantity: 80,
      reason: 'Cycle count adjustment',
    };

    it('should create adjustment movement', async () => {
      const result = await service.adjustStock(companyId, adjustmentDto, 'user-1');

      expect(result.data).toBeDefined();
      expect(result.data.type).toBe('ADJUSTMENT');
      expect(result.data.beforeQty).toBe(100);
      expect(result.data.afterQty).toBe(80);
    });

    it('should throw NotFoundException for stock in another company', async () => {
      mockPrismaService.stock.findFirst.mockResolvedValue({
        ...mockStock,
        warehouse: { companyId: 'other-company' },
      });

      await expect(service.adjustStock(companyId, adjustmentDto)).rejects.toThrow(NotFoundException);
    });

    it('should calculate correct quantity for increase', async () => {
      const increaseDto = { ...adjustmentDto, newQuantity: 120 };

      await service.adjustStock(companyId, increaseDto);

      const txCalls = mockPrismaService.$transaction.mock.calls[0][0];
      expect(txCalls[0].data.quantity).toBe(20); // |120 - 100| = 20
    });

    it('should calculate correct quantity for decrease', async () => {
      const decreaseDto = { ...adjustmentDto, newQuantity: 60 };

      await service.adjustStock(companyId, decreaseDto);

      const txCalls = mockPrismaService.$transaction.mock.calls[0][0];
      expect(txCalls[0].data.quantity).toBe(40); // |60 - 100| = 40
    });
  });

  // ========== createTransfer ==========
  describe('createTransfer()', () => {
    const transferDto = {
      fromWarehouseId: warehouseId,
      toWarehouseId: 'warehouse-2',
      notes: 'Restock branch warehouse',
      items: [
        { productId, quantity: 20, batchNumber: 'BATCH001' },
      ],
    };

    it('should create stock transfer', async () => {
      const result = await service.createTransfer(companyId, transferDto);

      expect(result.data).toBeDefined();
      expect(result.data.transferNumber).toMatch(/^TRF-/);
      expect(result.data.items).toHaveLength(1);
    });

    it('should verify both warehouses belong to company', async () => {
      await service.createTransfer(companyId, transferDto);

      expect(mockPrismaService.warehouse.findFirst).toHaveBeenCalledTimes(2);
    });

    it('should throw NotFoundException for missing source warehouse', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValueOnce(null);

      await expect(service.createTransfer(companyId, transferDto)).rejects.toThrow(NotFoundException);
      await expect(service.createTransfer(companyId, transferDto)).rejects.toThrow('Source warehouse not found');
    });

    it('should throw NotFoundException for missing destination warehouse', async () => {
      mockPrismaService.warehouse.findFirst
        .mockResolvedValueOnce(mockWarehouse)
        .mockResolvedValueOnce(null);

      await expect(service.createTransfer(companyId, transferDto)).rejects.toThrow(NotFoundException);
      await expect(service.createTransfer(companyId, transferDto)).rejects.toThrow('Destination warehouse not found');
    });

    it('should throw BadRequestException for insufficient stock', async () => {
      mockPrismaService.stock.findFirst.mockResolvedValue({ ...mockStock, quantity: 5 }); // less than 20

      await expect(service.createTransfer(companyId, transferDto)).rejects.toThrow(BadRequestException);
    });

    it('should throw for non-existent stock', async () => {
      mockPrismaService.stock.findFirst.mockResolvedValue(null);

      await expect(service.createTransfer(companyId, transferDto)).rejects.toThrow(BadRequestException);
    });

    it('should handle multiple items in transfer', async () => {
      const multiItemDto = {
        ...transferDto,
        items: [
          { productId: 'product-1', quantity: 10, batchNumber: 'B001' },
          { productId: 'product-2', quantity: 15, batchNumber: 'B002' },
        ],
      };

      const result = await service.createTransfer(companyId, multiItemDto);

      expect(result.data.items).toHaveLength(2);
    });
  });

  // ========== findAllTransfers ==========
  describe('findAllTransfers()', () => {
    it('should return transfers scoped to company', async () => {
      const result = await service.findAllTransfers(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });
  });

  // ========== updateTransferStatus ==========
  describe('updateTransferStatus()', () => {
    it('should update status to SHIPPED and deduct from source', async () => {
      mockPrismaService.stockTransfer.findFirst.mockResolvedValue({
        ...mockTransfer,
        status: 'APPROVED',
      });

      const result = await service.updateTransferStatus('transfer-1', companyId, 'SHIPPED');

      expect(result.data.status).toBe('SHIPPED');
      expect(mockPrismaService.stock.update).toHaveBeenCalled();
    });

    it('should update status to RECEIVED and add to destination', async () => {
      mockPrismaService.stockTransfer.findFirst.mockResolvedValue({
        ...mockTransfer,
        status: 'SHIPPED',
      });

      const result = await service.updateTransferStatus('transfer-1', companyId, 'RECEIVED');

      expect(result.data.status).toBe('RECEIVED');
      expect(mockPrismaService.stock.update).toHaveBeenCalled();
    });

    it('should create new stock if not exists at destination', async () => {
      mockPrismaService.stockTransfer.findFirst.mockResolvedValue({
        ...mockTransfer,
        status: 'SHIPPED',
      });
      mockPrismaService.stock.findFirst.mockResolvedValue(null);

      await service.updateTransferStatus('transfer-1', companyId, 'RECEIVED');

      expect(mockPrismaService.stock.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          productId,
          warehouseId: 'warehouse-2',
          quantity: 20,
        }),
      });
    });

    it('should throw NotFoundException for transfer not in company', async () => {
      mockPrismaService.stockTransfer.findFirst.mockResolvedValue(null);

      await expect(service.updateTransferStatus('nonexistent', companyId, 'SHIPPED')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== getLowStock ==========
  describe('getLowStock()', () => {
    it('should return low stock items', async () => {
      const result = await service.getLowStock(companyId);

      expect(result.data).toBeDefined();
      expect(Array.isArray(result.data)).toBe(true);
    });

    it('should scope to company warehouses', async () => {
      await service.getLowStock(companyId);

      expect(mockPrismaService.stock.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            warehouse: { companyId },
          }),
        }),
      );
    });
  });

  // ========== createAudit ==========
  describe('createAudit()', () => {
    it('should create stock audit for warehouse', async () => {
      const result = await service.createAudit(companyId, warehouseId, 'Monthly audit');

      expect(result.data).toBeDefined();
      expect(result.data.warehouseId).toBe(warehouseId);
      expect(result.data.totalItems).toBe(1);
      expect(result.data.totalQuantity).toBe(100);
      expect(result.data.items).toHaveLength(1);
      expect(result.data.notes).toBe('Monthly audit');
      expect(result.data.auditDate).toBeInstanceOf(Date);
    });

    it('should throw NotFoundException for invalid warehouse', async () => {
      mockPrismaService.warehouse.findFirst.mockResolvedValue(null);

      await expect(service.createAudit(companyId, 'invalid-warehouse')).rejects.toThrow(NotFoundException);
    });

    it('should calculate total quantity correctly', async () => {
      mockPrismaService.stock.findMany.mockResolvedValue([
        { ...mockStock, quantity: 50 },
        { ...mockStock, id: 'stock-2', quantity: 75 },
        { ...mockStock, id: 'stock-3', quantity: 25 },
      ]);

      const result = await service.createAudit(companyId, warehouseId);

      expect(result.data.totalItems).toBe(3);
      expect(result.data.totalQuantity).toBe(150);
    });

    it('should handle empty warehouse', async () => {
      mockPrismaService.stock.findMany.mockResolvedValue([]);

      const result = await service.createAudit(companyId, warehouseId);

      expect(result.data.totalItems).toBe(0);
      expect(result.data.totalQuantity).toBe(0);
    });
  });
});
