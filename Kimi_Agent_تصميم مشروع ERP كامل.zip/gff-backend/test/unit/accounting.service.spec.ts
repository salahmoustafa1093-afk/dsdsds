import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException, BadRequestException } from '@nestjs/common';
import { AccountingService } from '@/accounting/accounting.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('AccountingService', () => {
  let service: AccountingService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const accountId = 'account-1';
  const journalEntryId = 'je-1';

  const mockAccount = {
    id: accountId,
    code: '1000',
    name: 'Cash',
    type: 'ASSET',
    parentId: null,
    companyId,
    balance: 10000,
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    parent: null,
    children: [
      { id: 'account-2', name: 'Cash on Hand', code: '1010' },
      { id: 'account-3', name: 'Bank Account', code: '1020' },
    ],
    _count: { journalEntries: 5 },
    journalEntries: [
      { debit: 5000, credit: 0 },
      { debit: 3000, credit: 1000 },
    ],
  };

  const mockJournalEntry = {
    id: journalEntryId,
    entryNumber: 'JE-ABC123-0001',
    companyId,
    description: 'Monthly expense allocation',
    reference: 'REF-001',
    totalDebit: 5000,
    totalCredit: 5000,
    isPosted: false,
    postedAt: null,
    date: new Date(),
    createdAt: new Date(),
    updatedAt: new Date(),
    lines: [
      {
        id: 'line-1',
        accountId: 'acc-1',
        debit: 5000,
        credit: 0,
        description: 'Rent expense',
        account: { id: 'acc-1', name: 'Rent Expense', code: '5000' },
      },
      {
        id: 'line-2',
        accountId: 'acc-2',
        debit: 0,
        credit: 5000,
        description: 'Cash payment',
        account: { id: 'acc-2', name: 'Cash', code: '1000' },
      },
    ],
  };

  const mockBankAccount = {
    id: 'bank-1',
    name: 'Main Checking',
    bankName: 'National Bank',
    accountNumber: '1234567890',
    currency: 'USD',
    currentBalance: 50000,
    companyId,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockTreasuryTransaction = {
    id: 'tt-1',
    type: 'RECEIPT',
    amount: 10000,
    description: 'Customer payment',
    reference: 'INV-001',
    date: new Date(),
    companyId,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    mockPrismaService = {
      account: {
        findFirst: jest.fn().mockResolvedValue(mockAccount),
        findMany: jest.fn().mockResolvedValue([mockAccount]),
        create: jest.fn().mockResolvedValue(mockAccount),
        update: jest.fn().mockResolvedValue(mockAccount),
        count: jest.fn().mockResolvedValue(1),
      },
      journalEntry: {
        findFirst: jest.fn().mockResolvedValue(mockJournalEntry),
        findMany: jest.fn().mockResolvedValue([mockJournalEntry]),
        create: jest.fn().mockResolvedValue(mockJournalEntry),
        update: jest.fn().mockResolvedValue(mockJournalEntry),
        count: jest.fn().mockResolvedValue(1),
      },
      journalEntryLine: {
        findMany: jest.fn().mockResolvedValue(mockJournalEntry.lines),
      },
      bankAccount: {
        findFirst: jest.fn().mockResolvedValue(mockBankAccount),
        findMany: jest.fn().mockResolvedValue([mockBankAccount]),
        create: jest.fn().mockResolvedValue(mockBankAccount),
        update: jest.fn().mockResolvedValue(mockBankAccount),
      },
      treasuryTransaction: {
        findFirst: jest.fn().mockResolvedValue(mockTreasuryTransaction),
        findMany: jest.fn().mockResolvedValue([mockTreasuryTransaction]),
        create: jest.fn().mockResolvedValue(mockTreasuryTransaction),
        count: jest.fn().mockResolvedValue(1),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AccountingService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<AccountingService>(AccountingService);
    jest.clearAllMocks();
  });

  // ========== Chart of Accounts ==========
  describe('findAllAccounts()', () => {
    it('should return paginated accounts for company', async () => {
      const result = await service.findAllAccounts(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.page).toBe(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by account type', async () => {
      await service.findAllAccounts(companyId, { page: 1, limit: 10, type: 'ASSET' });

      expect(mockPrismaService.account.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ type: 'ASSET' }),
        }),
      );
    });

    it('should scope to company', async () => {
      await service.findAllAccounts(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.account.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });

    it('should include parent and children', async () => {
      const result = await service.findAllAccounts(companyId, { page: 1, limit: 10 });

      expect(result.data[0].children).toBeDefined();
      expect(result.data[0].children.length).toBe(2);
    });
  });

  describe('findOneAccount()', () => {
    it('should return account with journal entries', async () => {
      const result = await service.findOneAccount(accountId, companyId);

      expect(result.data).toBeDefined();
      expect(result.data.journalEntries).toBeDefined();
    });

    it('should include parent and children', async () => {
      const result = await service.findOneAccount(accountId, companyId);

      expect(result.data.parent).toBeDefined();
      expect(result.data.children).toBeDefined();
    });

    it('should throw NotFoundException for account in another company', async () => {
      mockPrismaService.account.findFirst.mockResolvedValue(null);

      await expect(service.findOneAccount('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  describe('createAccount()', () => {
    const createAccountDto = {
      code: '2000',
      name: 'Accounts Payable',
      type: 'LIABILITY' as const,
      parentId: null,
    };

    it('should create a new account', async () => {
      const result = await service.createAccount(companyId, createAccountDto);

      expect(result.data).toBeDefined();
      expect(result.data.code).toBe('1000');
    });

    it('should throw ConflictException for duplicate code', async () => {
      mockPrismaService.account.findFirst.mockResolvedValueOnce(mockAccount);

      await expect(service.createAccount(companyId, createAccountDto)).rejects.toThrow(ConflictException);
    });

    it('should scope account to company', async () => {
      await service.createAccount(companyId, createAccountDto);

      expect(mockPrismaService.account.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  describe('updateAccount()', () => {
    it('should update account fields', async () => {
      mockPrismaService.account.update.mockResolvedValue({ ...mockAccount, name: 'Updated Name' });

      const result = await service.updateAccount(accountId, companyId, { name: 'Updated Name' });

      expect(result.data.name).toBe('Updated Name');
    });

    it('should throw NotFoundException for non-existent account', async () => {
      mockPrismaService.account.findFirst.mockResolvedValue(null);

      await expect(service.updateAccount('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Account Balance ==========
  describe('getAccountBalance()', () => {
    it('should calculate ASSET account balance (debit - credit)', async () => {
      const result = await service.getAccountBalance(accountId, companyId);

      // totalDebit = 5000 + 3000 = 8000, totalCredit = 0 + 1000 = 1000
      // ASSET balance = 8000 - 1000 = 7000
      expect(result.data.balance).toBe(7000);
      expect(result.data.totalDebit).toBe(8000);
      expect(result.data.totalCredit).toBe(1000);
    });

    it('should calculate LIABILITY account balance (credit - debit)', async () => {
      mockPrismaService.account.findFirst.mockResolvedValue({
        ...mockAccount,
        type: 'LIABILITY',
        journalEntries: [
          { debit: 1000, credit: 5000 },
          { debit: 2000, credit: 3000 },
        ],
      });

      const result = await service.getAccountBalance(accountId, companyId);

      // totalDebit = 3000, totalCredit = 8000
      // LIABILITY balance = 8000 - 3000 = 5000
      expect(result.data.balance).toBe(5000);
    });

    it('should calculate EQUITY account balance (credit - debit)', async () => {
      mockPrismaService.account.findFirst.mockResolvedValue({
        ...mockAccount,
        type: 'EQUITY',
        journalEntries: [
          { debit: 0, credit: 10000 },
        ],
      });

      const result = await service.getAccountBalance(accountId, companyId);

      expect(result.data.balance).toBe(10000);
    });

    it('should calculate REVENUE account balance (credit - debit)', async () => {
      mockPrismaService.account.findFirst.mockResolvedValue({
        ...mockAccount,
        type: 'REVENUE',
        journalEntries: [
          { debit: 0, credit: 5000 },
          { debit: 1000, credit: 0 },
        ],
      });

      const result = await service.getAccountBalance(accountId, companyId);

      expect(result.data.balance).toBe(4000); // 5000 - 1000
    });

    it('should calculate EXPENSE account balance (debit - credit)', async () => {
      mockPrismaService.account.findFirst.mockResolvedValue({
        ...mockAccount,
        type: 'EXPENSE',
        journalEntries: [
          { debit: 3000, credit: 0 },
          { debit: 2000, credit: 500 },
        ],
      });

      const result = await service.getAccountBalance(accountId, companyId);

      expect(result.data.balance).toBe(4500); // 5000 - 500
    });

    it('should throw NotFoundException for non-existent account', async () => {
      mockPrismaService.account.findFirst.mockResolvedValue(null);

      await expect(service.getAccountBalance('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Journal Entries ==========
  describe('findAllJournalEntries()', () => {
    it('should return paginated journal entries', async () => {
      const result = await service.findAllJournalEntries(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by date range', async () => {
      await service.findAllJournalEntries(companyId, {
        page: 1,
        limit: 10,
        startDate: '2024-01-01',
        endDate: '2024-01-31',
      });

      expect(mockPrismaService.journalEntry.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            date: expect.objectContaining({
              gte: expect.any(Date),
              lte: expect.any(Date),
            }),
          }),
        }),
      );
    });

    it('should scope to company', async () => {
      await service.findAllJournalEntries(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.journalEntry.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });

    it('should include lines with account details', async () => {
      const result = await service.findAllJournalEntries(companyId, { page: 1, limit: 10 });

      expect(result.data[0].lines).toBeDefined();
      expect(result.data[0].lines[0].account).toBeDefined();
    });
  });

  describe('createJournalEntry()', () => {
    const createJEDto = {
      description: 'Purchase inventory',
      reference: 'PO-001',
      lines: [
        { accountId: 'acc-1', debit: 5000, credit: 0, description: 'Inventory' },
        { accountId: 'acc-2', debit: 0, credit: 5000, description: 'Cash' },
      ],
    };

    it('should create balanced journal entry', async () => {
      const result = await service.createJournalEntry(companyId, createJEDto);

      expect(result.data).toBeDefined();
      expect(result.data.entryNumber).toMatch(/^JE-/);
      expect(Number(result.data.totalDebit)).toBe(5000);
      expect(Number(result.data.totalCredit)).toBe(5000);
    });

    it('should throw BadRequestException when debits != credits', async () => {
      const unbalancedDto = {
        ...createJEDto,
        lines: [
          { accountId: 'acc-1', debit: 5000, credit: 0, description: 'Inventory' },
          { accountId: 'acc-2', debit: 0, credit: 3000, description: 'Cash' },
        ],
      };

      await expect(service.createJournalEntry(companyId, unbalancedDto)).rejects.toThrow(BadRequestException);
      await expect(service.createJournalEntry(companyId, unbalancedDto)).rejects.toThrow('Total debits must equal total credits');
    });

    it('should throw BadRequestException when difference > 0.001', async () => {
      const unbalancedDto = {
        ...createJEDto,
        lines: [
          { accountId: 'acc-1', debit: 5000, credit: 0, description: 'Inventory' },
          { accountId: 'acc-2', debit: 0, credit: 5000.002, description: 'Cash' },
        ],
      };

      await expect(service.createJournalEntry(companyId, unbalancedDto)).rejects.toThrow(BadRequestException);
    });

    it('should allow balanced entry within 0.001 tolerance', async () => {
      const balancedDto = {
        ...createJEDto,
        lines: [
          { accountId: 'acc-1', debit: 5000, credit: 0, description: 'Inventory' },
          { accountId: 'acc-2', debit: 0, credit: 5000.0005, description: 'Cash' },
        ],
      };

      await expect(service.createJournalEntry(companyId, balancedDto)).resolves.not.toThrow();
    });

    it('should create lines with journal entry', async () => {
      await service.createJournalEntry(companyId, createJEDto);

      expect(mockPrismaService.journalEntry.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            lines: {
              create: expect.arrayContaining([
                expect.objectContaining({
                  accountId: 'acc-1',
                  debit: 5000,
                  credit: 0,
                }),
                expect.objectContaining({
                  accountId: 'acc-2',
                  debit: 0,
                  credit: 5000,
                }),
              ]),
            },
          }),
        }),
      );
    });

    it('should scope journal entry to company', async () => {
      await service.createJournalEntry(companyId, createJEDto);

      const createCall = mockPrismaService.journalEntry.create.mock.calls[0][0];
      expect(createCall.data.companyId).toBe(companyId);
    });

    it('should handle multi-line entries', async () => {
      const multiLineDto = {
        description: 'Complex entry',
        reference: 'REF-002',
        lines: [
          { accountId: 'acc-1', debit: 3000, credit: 0 },
          { accountId: 'acc-2', debit: 2000, credit: 0 },
          { accountId: 'acc-3', debit: 0, credit: 5000 },
        ],
      };

      const result = await service.createJournalEntry(companyId, multiLineDto);

      expect(Number(result.data.totalDebit)).toBe(5000);
      expect(Number(result.data.totalCredit)).toBe(5000);
    });
  });

  describe('postJournalEntry()', () => {
    it('should post unposted journal entry', async () => {
      mockPrismaService.journalEntry.update.mockResolvedValue({
        ...mockJournalEntry,
        isPosted: true,
        postedAt: new Date(),
      });

      const result = await service.postJournalEntry(journalEntryId, companyId);

      expect(result.data.isPosted).toBe(true);
      expect(mockPrismaService.account.update).toHaveBeenCalled();
    });

    it('should update account balances when posting', async () => {
      mockPrismaService.journalEntry.update.mockResolvedValue({
        ...mockJournalEntry,
        isPosted: true,
      });

      await service.postJournalEntry(journalEntryId, companyId);

      // Line 1: debit 5000, credit 0 -> netChange = +5000
      expect(mockPrismaService.account.update).toHaveBeenCalledWith({
        where: { id: 'acc-1' },
        data: { balance: { increment: 5000 } },
      });

      // Line 2: debit 0, credit 5000 -> netChange = -5000
      expect(mockPrismaService.account.update).toHaveBeenCalledWith({
        where: { id: 'acc-2' },
        data: { balance: { increment: -5000 } },
      });
    });

    it('should throw BadRequestException for already posted entry', async () => {
      mockPrismaService.journalEntry.findFirst.mockResolvedValue({
        ...mockJournalEntry,
        isPosted: true,
      });

      await expect(service.postJournalEntry(journalEntryId, companyId)).rejects.toThrow(BadRequestException);
      await expect(service.postJournalEntry(journalEntryId, companyId)).rejects.toThrow('Journal entry already posted');
    });

    it('should throw NotFoundException for non-existent entry', async () => {
      mockPrismaService.journalEntry.findFirst.mockResolvedValue(null);

      await expect(service.postJournalEntry('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should scope to company', async () => {
      mockPrismaService.journalEntry.update.mockResolvedValue({
        ...mockJournalEntry,
        isPosted: true,
      });

      await service.postJournalEntry(journalEntryId, companyId);

      expect(mockPrismaService.journalEntry.findFirst).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  // ========== Bank Accounts ==========
  describe('findAllBankAccounts()', () => {
    it('should return bank accounts for company', async () => {
      const result = await service.findAllBankAccounts(companyId);

      expect(result.data).toHaveLength(1);
      expect(result.data[0].name).toBe('Main Checking');
    });

    it('should scope to company', async () => {
      await service.findAllBankAccounts(companyId);

      expect(mockPrismaService.bankAccount.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { companyId },
        }),
      );
    });
  });

  describe('createBankAccount()', () => {
    const createBankDto = {
      name: 'Savings Account',
      bankName: 'International Bank',
      accountNumber: '9876543210',
      currency: 'USD',
      currentBalance: 0,
    };

    it('should create bank account', async () => {
      const result = await service.createBankAccount(companyId, createBankDto);

      expect(result.data).toBeDefined();
    });

    it('should scope to company', async () => {
      await service.createBankAccount(companyId, createBankDto);

      expect(mockPrismaService.bankAccount.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  describe('updateBankAccount()', () => {
    it('should update bank account', async () => {
      const result = await service.updateBankAccount('bank-1', companyId, { name: 'Updated Name' });

      expect(result.data).toBeDefined();
    });

    it('should throw NotFoundException for bank account in another company', async () => {
      mockPrismaService.bankAccount.findFirst.mockResolvedValue(null);

      await expect(service.updateBankAccount('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Treasury ==========
  describe('findAllTreasuryTransactions()', () => {
    it('should return paginated treasury transactions', async () => {
      const result = await service.findAllTreasuryTransactions(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by type', async () => {
      await service.findAllTreasuryTransactions(companyId, { page: 1, limit: 10, type: 'RECEIPT' });

      expect(mockPrismaService.treasuryTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ type: 'RECEIPT' }),
        }),
      );
    });

    it('should scope to company', async () => {
      await service.findAllTreasuryTransactions(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.treasuryTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  describe('createTreasuryTransaction()', () => {
    const createTreasuryDto = {
      type: 'RECEIPT' as const,
      amount: 5000,
      description: 'Customer payment',
      reference: 'INV-001',
      date: new Date(),
    };

    it('should create treasury transaction', async () => {
      const result = await service.createTreasuryTransaction(companyId, createTreasuryDto);

      expect(result.data).toBeDefined();
      expect(result.data.type).toBe('RECEIPT');
    });

    it('should scope to company', async () => {
      await service.createTreasuryTransaction(companyId, createTreasuryDto);

      expect(mockPrismaService.treasuryTransaction.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  describe('getTreasuryBalance()', () => {
    it('should calculate correct balance', async () => {
      mockPrismaService.treasuryTransaction.findMany.mockResolvedValue([
        { type: 'RECEIPT', amount: 10000 },
        { type: 'DEPOSIT', amount: 5000 },
        { type: 'PAYMENT', amount: 3000 },
        { type: 'WITHDRAWAL', amount: 2000 },
      ]);

      const result = await service.getTreasuryBalance(companyId);

      // totalReceipts = 10000 + 5000 = 15000
      // totalPayments = 3000 + 2000 = 5000
      // balance = 15000 - 5000 = 10000
      expect(result.data.totalReceipts).toBe(15000);
      expect(result.data.totalPayments).toBe(5000);
      expect(result.data.balance).toBe(10000);
    });

    it('should handle zero transactions', async () => {
      mockPrismaService.treasuryTransaction.findMany.mockResolvedValue([]);

      const result = await service.getTreasuryBalance(companyId);

      expect(result.data.totalReceipts).toBe(0);
      expect(result.data.totalPayments).toBe(0);
      expect(result.data.balance).toBe(0);
    });

    it('should handle only receipts', async () => {
      mockPrismaService.treasuryTransaction.findMany.mockResolvedValue([
        { type: 'RECEIPT', amount: 5000 },
        { type: 'RECEIPT', amount: 3000 },
      ]);

      const result = await service.getTreasuryBalance(companyId);

      expect(result.data.totalReceipts).toBe(8000);
      expect(result.data.totalPayments).toBe(0);
      expect(result.data.balance).toBe(8000);
    });

    it('should scope to company', async () => {
      await service.getTreasuryBalance(companyId);

      expect(mockPrismaService.treasuryTransaction.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { companyId },
        }),
      );
    });
  });

  // ========== Trial Balance ==========
  describe('getTrialBalance()', () => {
    it('should return trial balance with totals', async () => {
      mockPrismaService.account.findMany.mockResolvedValue([
        {
          ...mockAccount,
          journalEntries: [
            { debit: 10000, credit: 2000 },
          ],
        },
        {
          ...mockAccount,
          id: 'acc-liab',
          code: '2000',
          name: 'Accounts Payable',
          type: 'LIABILITY',
          journalEntries: [
            { debit: 1000, credit: 8000 },
          ],
        },
      ]);

      const result = await service.getTrialBalance(companyId);

      expect(result.data.accounts).toHaveLength(2);
      // Account 1: debit=10000, credit=2000
      // Account 2: debit=1000, credit=8000
      // Grand totals: debit=11000, credit=10000
      expect(result.data.grandTotalDebit).toBe(11000);
      expect(result.data.grandTotalCredit).toBe(10000);
    });

    it('should scope to company', async () => {
      await service.getTrialBalance(companyId);

      expect(mockPrismaService.account.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { companyId },
        }),
      );
    });

    it('should return zero for empty chart of accounts', async () => {
      mockPrismaService.account.findMany.mockResolvedValue([]);

      const result = await service.getTrialBalance(companyId);

      expect(result.data.accounts).toHaveLength(0);
      expect(result.data.grandTotalDebit).toBe(0);
      expect(result.data.grandTotalCredit).toBe(0);
    });
  });
});
