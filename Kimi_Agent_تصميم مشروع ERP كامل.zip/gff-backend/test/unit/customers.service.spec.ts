import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException } from '@nestjs/common';
import { CustomersService } from '@/customers/customers.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('CustomersService', () => {
  let service: CustomersService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const customerId = 'customer-1';
  const categoryId = 'category-1';

  const mockCustomer = {
    id: customerId,
    name: 'Al-Shamal Poultry Farm',
    code: 'CUST001',
    email: 'contact@shamal.com',
    phone: '+962799111222',
    address: 'Airport Road, Amman',
    taxNumber: '123456789',
    creditLimit: 5000,
    currentDebt: 2000,
    paymentTerms: 30,
    isActive: true,
    companyId,
    categoryId,
    deletedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    category: {
      id: categoryId,
      name: 'Premium',
      description: 'Premium customers',
      companyId,
    },
  };

  const mockCategory = {
    id: categoryId,
    name: 'Premium',
    description: 'Premium tier customers',
    companyId,
    _count: { customers: 5 },
  };

  beforeEach(async () => {
    mockPrismaService = {
      customer: {
        findFirst: jest.fn().mockResolvedValue(mockCustomer),
        findMany: jest.fn().mockResolvedValue([mockCustomer]),
        create: jest.fn().mockResolvedValue(mockCustomer),
        update: jest.fn().mockResolvedValue(mockCustomer),
        count: jest.fn().mockResolvedValue(1),
      },
      customerCategory: {
        findFirst: jest.fn().mockResolvedValue(mockCategory),
        findMany: jest.fn().mockResolvedValue([mockCategory]),
        create: jest.fn().mockResolvedValue(mockCategory),
        update: jest.fn().mockResolvedValue(mockCategory),
        delete: jest.fn(),
      },
      customerTransaction: {
        create: jest.fn().mockResolvedValue({
          id: 'txn-1',
          customerId,
          type: 'payment',
          amount: 500,
          balance: 1500,
          reference: 'PAY-001',
          notes: 'Monthly payment',
          createdAt: new Date(),
        }),
        findMany: jest.fn().mockResolvedValue([
          {
            id: 'txn-1',
            customerId,
            type: 'payment',
            amount: 500,
            balance: 1500,
            reference: 'PAY-001',
            createdAt: new Date(),
          },
        ]),
      },
    };

    mockPrismaService.$transaction = jest.fn((cb) => {
      if (typeof cb === 'function') return cb(mockPrismaService);
      return Promise.resolve(cb);
    });

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CustomersService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<CustomersService>(CustomersService);
    jest.clearAllMocks();
  });

  // ========== findAll ==========
  describe('findAll()', () => {
    it('should return paginated customers for company', async () => {
      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.page).toBe(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by category', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, categoryId });

      expect(mockPrismaService.customer.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ categoryId }),
        }),
      );
    });

    it('should search by name', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, search: 'shamal' });

      expect(mockPrismaService.customer.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: expect.arrayContaining([
              { name: { contains: 'shamal', mode: 'insensitive' } },
            ]),
          }),
        }),
      );
    });

    it('should search by code', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, search: 'CUST001' });

      expect(mockPrismaService.customer.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: expect.arrayContaining([
              { code: { contains: 'CUST001', mode: 'insensitive' } },
            ]),
          }),
        }),
      );
    });

    it('should search by email', async () => {
      await service.findAll(companyId, { page: 1, limit: 10, search: 'shamal.com' });

      expect(mockPrismaService.customer.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: expect.arrayContaining([
              { email: { contains: 'shamal.com', mode: 'insensitive' } },
            ]),
          }),
        }),
      );
    });

    it('should exclude soft-deleted customers', async () => {
      await service.findAll(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.customer.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ deletedAt: null }),
        }),
      );
    });

    it('should include category in response', async () => {
      const result = await service.findAll(companyId, { page: 1, limit: 10 });

      expect(result.data[0].category).toBeDefined();
    });
  });

  // ========== findOne ==========
  describe('findOne()', () => {
    it('should return customer with invoices and transactions', async () => {
      const result = await service.findOne(customerId, companyId);

      expect(result.data.id).toBe(customerId);
      expect(result.data.invoices).toBeDefined();
      expect(result.data.transactions).toBeDefined();
      expect(result.data.category).toBeDefined();
    });

    it('should throw NotFoundException for non-existent customer', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(service.findOne('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for deleted customer', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(service.findOne('deleted', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should scope to company', async () => {
      await service.findOne(customerId, companyId);

      expect(mockPrismaService.customer.findFirst).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  // ========== create ==========
  describe('create()', () => {
    const createDto = {
      name: 'New Customer',
      code: 'CUST002',
      email: 'new@customer.com',
      phone: '+962799333444',
      address: 'New Address',
      taxNumber: '987654321',
      creditLimit: 3000,
      paymentTerms: 15,
      categoryId,
    };

    it('should create a new customer', async () => {
      const result = await service.create(companyId, createDto);

      expect(result.data).toBeDefined();
      expect(result.data.name).toBe('Al-Shamal Poultry Farm');
    });

    it('should throw ConflictException for duplicate email', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValueOnce(mockCustomer);

      await expect(service.create(companyId, createDto)).rejects.toThrow(ConflictException);
    });

    it('should allow customer without email', async () => {
      const dtoNoEmail = { ...createDto, email: undefined };

      const result = await service.create(companyId, dtoNoEmail);

      expect(result.data).toBeDefined();
      expect(mockPrismaService.customer.findFirst).toHaveBeenCalledTimes(0);
    });

    it('should scope customer to company', async () => {
      await service.create(companyId, createDto);

      expect(mockPrismaService.customer.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  // ========== update ==========
  describe('update()', () => {
    const updateDto = {
      name: 'Updated Customer Name',
      phone: '+962799555666',
    };

    it('should update customer fields', async () => {
      mockPrismaService.customer.update.mockResolvedValue({ ...mockCustomer, ...updateDto });

      const result = await service.update(customerId, companyId, updateDto);

      expect(result.data.name).toBe('Updated Customer Name');
      expect(result.data.phone).toBe('+962799555666');
    });

    it('should throw NotFoundException for non-existent customer', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(service.update('nonexistent', companyId, updateDto)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== remove (Soft Delete) ==========
  describe('remove()', () => {
    it('should soft delete customer', async () => {
      const result = await service.remove(customerId, companyId);

      expect(result.data.message).toBe('Customer deleted successfully');
      expect(mockPrismaService.customer.update).toHaveBeenCalledWith({
        where: { id: customerId },
        data: { deletedAt: expect.any(Date), isActive: false },
      });
    });

    it('should throw NotFoundException for non-existent customer', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(service.remove('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== getDebts ==========
  describe('getDebts()', () => {
    it('should return customers with debts', async () => {
      mockPrismaService.customer.findMany.mockResolvedValue([
        { ...mockCustomer, currentDebt: 3000 },
        { ...mockCustomer, id: 'customer-2', name: 'Customer B', currentDebt: 1500, creditLimit: 5000 },
      ]);

      const result = await service.getDebts(companyId);

      expect(result.data.customers).toHaveLength(2);
      expect(result.data.totalDebt).toBe(4500);
    });

    it('should identify overdue customers exceeding credit limit', async () => {
      mockPrismaService.customer.findMany.mockResolvedValue([
        { ...mockCustomer, currentDebt: 6000, creditLimit: 5000 }, // Overdue
        { ...mockCustomer, id: 'customer-2', currentDebt: 2000, creditLimit: 5000 }, // Normal
      ]);

      const result = await service.getDebts(companyId);

      expect(result.data.overdueCount).toBe(1);
    });

    it('should scope to company', async () => {
      await service.getDebts(companyId);

      expect(mockPrismaService.customer.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });

    it('should return zero debt when no customers have debt', async () => {
      mockPrismaService.customer.findMany.mockResolvedValue([]);

      const result = await service.getDebts(companyId);

      expect(result.data.customers).toHaveLength(0);
      expect(result.data.totalDebt).toBe(0);
      expect(result.data.overdueCount).toBe(0);
    });
  });

  // ========== Credit Limit ==========
  describe('updateCreditLimit()', () => {
    const creditLimitDto = {
      creditLimit: 10000,
    };

    it('should update customer credit limit', async () => {
      mockPrismaService.customer.update.mockResolvedValue({
        ...mockCustomer,
        creditLimit: 10000,
      });

      const result = await service.updateCreditLimit(customerId, companyId, creditLimitDto);

      expect(result.data.creditLimit).toBe(10000);
    });

    it('should throw NotFoundException for non-existent customer', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(service.updateCreditLimit('nonexistent', companyId, creditLimitDto)).rejects.toThrow(NotFoundException);
    });

    it('should enforce credit limit on new transactions', async () => {
      // credit limit = 10000, current debt = 2000, trying to add 9000
      mockPrismaService.customer.findFirst.mockResolvedValue({
        ...mockCustomer,
        creditLimit: 10000,
        currentDebt: 2000,
      });

      const result = await service.updateCreditLimit(customerId, companyId, { creditLimit: 10000 });

      expect(result.data).toBeDefined();
    });
  });

  // ========== Categories ==========
  describe('findAllCategories()', () => {
    it('should return categories for company', async () => {
      const result = await service.findAllCategories(companyId);

      expect(result.data).toHaveLength(1);
      expect(result.data[0].name).toBe('Premium');
    });

    it('should scope categories to company', async () => {
      await service.findAllCategories(companyId);

      expect(mockPrismaService.customerCategory.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { companyId },
        }),
      );
    });

    it('should include customer count', async () => {
      const result = await service.findAllCategories(companyId);

      expect(result.data[0]._count).toBeDefined();
    });
  });

  describe('createCategory()', () => {
    const createCategoryDto = {
      name: 'Standard',
      description: 'Standard tier customers',
    };

    it('should create customer category', async () => {
      const result = await service.createCategory(companyId, createCategoryDto);

      expect(result.data).toBeDefined();
      expect(result.data.name).toBe('Premium');
    });

    it('should scope category to company', async () => {
      await service.createCategory(companyId, createCategoryDto);

      expect(mockPrismaService.customerCategory.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ companyId }),
        }),
      );
    });
  });

  describe('updateCategory()', () => {
    it('should update category', async () => {
      const result = await service.updateCategory(categoryId, companyId, { name: 'VIP' });

      expect(result.data).toBeDefined();
    });

    it('should throw NotFoundException for category in another company', async () => {
      mockPrismaService.customerCategory.findFirst.mockResolvedValue(null);

      await expect(service.updateCategory('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  describe('removeCategory()', () => {
    it('should delete empty category', async () => {
      mockPrismaService.customerCategory.findFirst.mockResolvedValue({
        ...mockCategory,
        _count: { customers: 0 },
      });

      const result = await service.removeCategory(categoryId, companyId);

      expect(result.data.message).toBe('Category deleted');
      expect(mockPrismaService.customerCategory.delete).toHaveBeenCalled();
    });

    it('should throw ConflictException for category with customers', async () => {
      mockPrismaService.customerCategory.findFirst.mockResolvedValue({
        ...mockCategory,
        _count: { customers: 5 },
      });

      await expect(service.removeCategory(categoryId, companyId)).rejects.toThrow(ConflictException);
    });

    it('should throw NotFoundException for non-existent category', async () => {
      mockPrismaService.customerCategory.findFirst.mockResolvedValue(null);

      await expect(service.removeCategory('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Transactions ==========
  describe('createTransaction()', () => {
    it('should create payment transaction and reduce debt', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue({
        ...mockCustomer,
        currentDebt: 2000,
      });

      const result = await service.createTransaction(customerId, companyId, {
        type: 'payment',
        amount: 500,
        reference: 'PAY-001',
        notes: 'Monthly payment',
      });

      expect(result.data.type).toBe('payment');
      expect(result.data.amount).toBe(500);
      expect(result.data.balance).toBe(1500); // 2000 - 500
    });

    it('should create charge transaction and increase debt', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue({
        ...mockCustomer,
        currentDebt: 2000,
      });

      const result = await service.createTransaction(customerId, companyId, {
        type: 'charge',
        amount: 1000,
        reference: 'INV-002',
        notes: 'New invoice',
      });

      expect(result.data.type).toBe('charge');
      expect(result.data.amount).toBe(1000);
      expect(result.data.balance).toBe(3000); // 2000 + 1000
    });

    it('should throw NotFoundException for non-existent customer', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(
        service.createTransaction('nonexistent', companyId, {
          type: 'payment',
          amount: 500,
        }),
      ).rejects.toThrow(NotFoundException);
    });

    it('should handle zero balance payment', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue({
        ...mockCustomer,
        currentDebt: 500,
      });

      const result = await service.createTransaction(customerId, companyId, {
        type: 'payment',
        amount: 500,
        reference: 'PAY-002',
      });

      expect(result.data.balance).toBe(0);
    });

    it('should handle overpayment (negative balance)', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue({
        ...mockCustomer,
        currentDebt: 500,
      });

      const result = await service.createTransaction(customerId, companyId, {
        type: 'payment',
        amount: 1000,
        reference: 'PAY-003',
      });

      expect(result.data.balance).toBe(-500); // 500 - 1000
    });
  });

  // ========== getTransactions ==========
  describe('getTransactions()', () => {
    it('should return transaction history', async () => {
      const result = await service.getTransactions(customerId, companyId);

      expect(result.data).toHaveLength(1);
      expect(result.data[0].type).toBe('payment');
    });

    it('should throw NotFoundException for non-existent customer', async () => {
      mockPrismaService.customer.findFirst.mockResolvedValue(null);

      await expect(service.getTransactions('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should scope to company', async () => {
      await service.getTransactions(customerId, companyId);

      expect(mockPrismaService.customer.findFirst).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });
  });
});
