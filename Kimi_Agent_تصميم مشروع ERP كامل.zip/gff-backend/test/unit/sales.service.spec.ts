import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException } from '@nestjs/common';
import { SalesService } from '@/sales/sales.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('SalesService', () => {
  let service: SalesService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const customerId = 'customer-1';
  const invoiceId = 'invoice-1';
  const userId = 'user-1';

  const mockCustomer = {
    id: customerId,
    name: 'Test Customer',
    code: 'CUST001',
    currentDebt: 1000,
  };

  const mockInvoice = {
    id: invoiceId,
    invoiceNumber: 'INV-ABC123-0001',
    companyId,
    customerId,
    issueDate: new Date(),
    dueDate: new Date(),
    salesChannel: 'direct',
    subtotal: 2000,
    discount: 100,
    taxAmount: 304,
    total: 2204,
    paidAmount: 0,
    notes: 'Test invoice',
    terms: null,
    status: 'DRAFT',
    deletedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    userId,
    items: [
      {
        id: 'item-1',
        productId: 'product-1',
        quantity: 10,
        unitPrice: 200,
        discount: 100,
        taxRate: 0.16,
        taxAmount: 304,
        total: 2204,
        batchNumber: null,
        product: { id: 'product-1', name: 'Product A', sku: 'SKU001' },
      },
    ],
    customer: { id: customerId, name: 'Test Customer', code: 'CUST001' },
    returns: [],
  };

  const mockQuote = {
    id: 'quote-1',
    quoteNumber: 'QT-ABC123',
    companyId,
    customerId,
    expiryDate: new Date(),
    subtotal: 1000,
    discount: 0,
    taxAmount: 160,
    total: 1160,
    status: 'DRAFT',
    notes: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    items: [
      {
        id: 'qi-1',
        productId: 'product-1',
        quantity: 5,
        unitPrice: 200,
        discount: 0,
        total: 1160,
        product: { id: 'product-1', name: 'Product A' },
      },
    ],
    customer: { id: customerId, name: 'Test Customer' },
  };

  const mockSalesReturn = {
    id: 'return-1',
    returnNumber: 'RET-ABC123',
    invoiceId,
    reason: 'Defective product',
    total: 400,
    status: 'PENDING',
    notes: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    items: [
      {
        id: 'ri-1',
        productId: 'product-1',
        quantity: 2,
        unitPrice: 200,
        total: 400,
        reason: 'Defective',
      },
    ],
    invoice: { id: invoiceId, invoiceNumber: 'INV-ABC123-0001' },
  };

  beforeEach(async () => {
    mockPrismaService = {
      invoice: {
        findFirst: jest.fn().mockResolvedValue(mockInvoice),
        findMany: jest.fn().mockResolvedValue([mockInvoice]),
        create: jest.fn().mockResolvedValue(mockInvoice),
        update: jest.fn().mockResolvedValue(mockInvoice),
        count: jest.fn().mockResolvedValue(1),
        groupBy: jest.fn().mockResolvedValue([
          { salesChannel: 'direct', _sum: { total: 2204 }, _count: { id: 1 } },
          { salesChannel: 'online', _sum: { total: 1500 }, _count: { id: 2 } },
        ]),
      },
      customer: {
        update: jest.fn().mockResolvedValue(mockCustomer),
      },
      salesReturn: {
        findFirst: jest.fn().mockResolvedValue(mockSalesReturn),
        findMany: jest.fn().mockResolvedValue([mockSalesReturn]),
        create: jest.fn().mockResolvedValue(mockSalesReturn),
        update: jest.fn().mockResolvedValue(mockSalesReturn),
        count: jest.fn().mockResolvedValue(1),
      },
      quote: {
        findFirst: jest.fn().mockResolvedValue(mockQuote),
        findMany: jest.fn().mockResolvedValue([mockQuote]),
        create: jest.fn().mockResolvedValue(mockQuote),
        update: jest.fn().mockResolvedValue(mockQuote),
        count: jest.fn().mockResolvedValue(1),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SalesService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<SalesService>(SalesService);
    jest.clearAllMocks();
  });

  // ========== findAllInvoices ==========
  describe('findAllInvoices()', () => {
    it('should return paginated invoices for company', async () => {
      const result = await service.findAllInvoices(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
      expect(result.meta.totalPages).toBe(1);
    });

    it('should filter by date range', async () => {
      await service.findAllInvoices(companyId, {
        page: 1,
        limit: 10,
        filters: { startDate: '2024-01-01', endDate: '2024-01-31' },
      });

      expect(mockPrismaService.invoice.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            issueDate: expect.any(Object),
          }),
        }),
      );
    });

    it('should filter by customer', async () => {
      await service.findAllInvoices(companyId, {
        page: 1,
        limit: 10,
        filters: { customerId },
      });

      expect(mockPrismaService.invoice.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ customerId }),
        }),
      );
    });

    it('should filter by status', async () => {
      await service.findAllInvoices(companyId, {
        page: 1,
        limit: 10,
        filters: { status: 'CONFIRMED' },
      });

      expect(mockPrismaService.invoice.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ status: 'CONFIRMED' }),
        }),
      );
    });

    it('should filter by sales channel', async () => {
      await service.findAllInvoices(companyId, {
        page: 1,
        limit: 10,
        filters: { channel: 'online' },
      });

      expect(mockPrismaService.invoice.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ salesChannel: 'online' }),
        }),
      );
    });

    it('should exclude deleted invoices', async () => {
      await service.findAllInvoices(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.invoice.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ deletedAt: null }),
        }),
      );
    });
  });

  // ========== findOneInvoice ==========
  describe('findOneInvoice()', () => {
    it('should return a single invoice', async () => {
      const result = await service.findOneInvoice(invoiceId, companyId);

      expect(result.data.id).toBe(invoiceId);
      expect(result.data.items).toBeDefined();
      expect(result.data.customer).toBeDefined();
    });

    it('should throw NotFoundException for non-existent invoice', async () => {
      mockPrismaService.invoice.findFirst.mockResolvedValue(null);

      await expect(service.findOneInvoice('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for invoice in another company', async () => {
      mockPrismaService.invoice.findFirst.mockResolvedValue(null);

      await expect(service.findOneInvoice(invoiceId, 'other-company')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== createInvoice ==========
  describe('createInvoice()', () => {
    const createInvoiceDto = {
      customerId,
      issueDate: '2024-01-15',
      dueDate: '2024-02-15',
      salesChannel: 'direct',
      notes: 'Please pay on time',
      terms: 'Net 30',
      items: [
        {
          productId: 'product-1',
          quantity: 10,
          unitPrice: 200,
          discount: 100,
          taxRate: '0.16',
          batchNumber: null,
        },
      ],
    };

    it('should create invoice with correct calculations', async () => {
      const result = await service.createInvoice(companyId, userId, createInvoiceDto);

      expect(result.data).toBeDefined();
      expect(result.data.invoiceNumber).toMatch(/^INV-/);
    });

    it('should calculate subtotal correctly', async () => {
      await service.createInvoice(companyId, userId, createInvoiceDto);

      const createCall = mockPrismaService.invoice.create.mock.calls[0][0];
      expect(createCall.data.subtotal).toBe(2000); // 10 * 200
    });

    it('should calculate tax correctly', async () => {
      await service.createInvoice(companyId, userId, createInvoiceDto);

      const createCall = mockPrismaService.invoice.create.mock.calls[0][0];
      // taxable amount = 2000 - 100 = 1900, tax = 1900 * 0.16 = 304
      expect(createCall.data.taxAmount).toBeCloseTo(304, 1);
    });

    it('should calculate total correctly', async () => {
      await service.createInvoice(companyId, userId, createInvoiceDto);

      const createCall = mockPrismaService.invoice.create.mock.calls[0][0];
      // total = 2000 - 100 + 304 = 2204
      expect(createCall.data.total).toBeCloseTo(2204, 1);
    });

    it('should use default tax rate when not provided', async () => {
      const dtoWithoutTax = {
        ...createInvoiceDto,
        items: [{ ...createInvoiceDto.items[0], taxRate: undefined }],
      };

      await service.createInvoice(companyId, userId, dtoWithoutTax);

      const createCall = mockPrismaService.invoice.create.mock.calls[0][0];
      expect(createCall.data.taxAmount).toBeGreaterThan(0);
    });

    it('should use current date when issueDate not provided', async () => {
      const dtoWithoutDate = { ...createInvoiceDto, issueDate: undefined };

      await service.createInvoice(companyId, userId, dtoWithoutDate);

      const createCall = mockPrismaService.invoice.create.mock.calls[0][0];
      expect(createCall.data.issueDate).toBeInstanceOf(Date);
    });

    it('should use default sales channel "direct"', async () => {
      const dtoWithoutChannel = { ...createInvoiceDto, salesChannel: undefined };

      await service.createInvoice(companyId, userId, dtoWithoutChannel);

      const createCall = mockPrismaService.invoice.create.mock.calls[0][0];
      expect(createCall.data.salesChannel).toBe('direct');
    });

    it('should increment customer debt', async () => {
      await service.createInvoice(companyId, userId, createInvoiceDto);

      expect(mockPrismaService.customer.update).toHaveBeenCalledWith({
        where: { id: customerId },
        data: { currentDebt: { increment: expect.any(Number) } },
      });
    });

    it('should work with userId undefined', async () => {
      const result = await service.createInvoice(companyId, undefined, createInvoiceDto);

      expect(result.data).toBeDefined();
    });
  });

  // ========== updateInvoice ==========
  describe('updateInvoice()', () => {
    const updateDto = {
      notes: 'Updated notes',
      terms: 'Updated terms',
    };

    it('should update invoice fields', async () => {
      mockPrismaService.invoice.update.mockResolvedValue({ ...mockInvoice, ...updateDto });

      const result = await service.updateInvoice(invoiceId, companyId, updateDto);

      expect(result.data.notes).toBe('Updated notes');
    });

    it('should throw NotFoundException for non-existent invoice', async () => {
      mockPrismaService.invoice.findFirst.mockResolvedValue(null);

      await expect(service.updateInvoice('nonexistent', companyId, updateDto)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== deleteInvoice ==========
  describe('deleteInvoice()', () => {
    it('should soft delete and reverse customer debt', async () => {
      const result = await service.deleteInvoice(invoiceId, companyId);

      expect(result.data.message).toBe('Invoice cancelled');
      expect(mockPrismaService.invoice.update).toHaveBeenCalledWith({
        where: { id: invoiceId },
        data: { deletedAt: expect.any(Date), status: 'CANCELLED' },
      });
      expect(mockPrismaService.customer.update).toHaveBeenCalledWith({
        where: { id: customerId },
        data: { currentDebt: { decrement: 2204 } },
      });
    });

    it('should throw NotFoundException for non-existent invoice', async () => {
      mockPrismaService.invoice.findFirst.mockResolvedValue(null);

      await expect(service.deleteInvoice('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Returns ==========
  describe('findAllReturns()', () => {
    it('should return paginated returns scoped to company', async () => {
      const result = await service.findAllReturns(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });
  });

  describe('createReturn()', () => {
    const createReturnDto = {
      invoiceId,
      reason: 'Defective product',
      notes: 'Customer request',
      items: [
        {
          productId: 'product-1',
          quantity: 2,
          unitPrice: 200,
        },
      ],
    };

    it('should create sales return for valid invoice', async () => {
      const result = await service.createReturn(companyId, createReturnDto);

      expect(result.data).toBeDefined();
      expect(result.data.returnNumber).toMatch(/^RET-/);
      expect(result.data.reason).toBe('Defective product');
    });

    it('should calculate return total correctly', async () => {
      await service.createReturn(companyId, createReturnDto);

      const createCall = mockPrismaService.salesReturn.create.mock.calls[0][0];
      expect(createCall.data.total).toBe(400); // 2 * 200
    });

    it('should throw NotFoundException for invoice in another company', async () => {
      mockPrismaService.invoice.findFirst.mockResolvedValue(null);

      await expect(service.createReturn(companyId, createReturnDto)).rejects.toThrow(NotFoundException);
    });

    it('should handle multiple return items', async () => {
      const dtoWithMultipleItems = {
        ...createReturnDto,
        items: [
          { productId: 'product-1', quantity: 2, unitPrice: 200 },
          { productId: 'product-2', quantity: 1, unitPrice: 150 },
        ],
      };

      await service.createReturn(companyId, dtoWithMultipleItems);

      const createCall = mockPrismaService.salesReturn.create.mock.calls[0][0];
      expect(createCall.data.total).toBe(550); // (2 * 200) + (1 * 150)
    });
  });

  describe('updateReturnStatus()', () => {
    it('should update return status', async () => {
      mockPrismaService.salesReturn.update.mockResolvedValue({ ...mockSalesReturn, status: 'APPROVED' });

      const result = await service.updateReturnStatus('return-1', companyId, 'APPROVED');

      expect(result.data.status).toBe('APPROVED');
    });

    it('should throw NotFoundException for return in another company', async () => {
      mockPrismaService.salesReturn.findFirst.mockResolvedValue(null);

      await expect(service.updateReturnStatus('nonexistent', companyId, 'APPROVED')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Quotes ==========
  describe('findAllQuotes()', () => {
    it('should return paginated quotes for company', async () => {
      const result = await service.findAllQuotes(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });
  });

  describe('createQuote()', () => {
    const createQuoteDto = {
      customerId,
      expiryDate: '2024-02-01',
      notes: 'Valid for 30 days',
      items: [
        {
          productId: 'product-1',
          quantity: 5,
          unitPrice: 200,
          discount: 0,
          taxRate: '0.16',
        },
      ],
    };

    it('should create a quote with calculations', async () => {
      const result = await service.createQuote(companyId, createQuoteDto);

      expect(result.data).toBeDefined();
      expect(result.data.quoteNumber).toMatch(/^QT-/);
    });

    it('should calculate quote total correctly', async () => {
      await service.createQuote(companyId, createQuoteDto);

      const createCall = mockPrismaService.quote.create.mock.calls[0][0];
      // subtotal = 5 * 200 = 1000, tax = 1000 * 0.16 = 160, total = 1000 + 160 = 1160
      expect(createCall.data.subtotal).toBe(1000);
      expect(createCall.data.total).toBeCloseTo(1160, 1);
    });

    it('should handle empty discount', async () => {
      const dtoNoDiscount = {
        ...createQuoteDto,
        items: [{ ...createQuoteDto.items[0], discount: undefined }],
      };

      await service.createQuote(companyId, dtoNoDiscount);

      const createCall = mockPrismaService.quote.create.mock.calls[0][0];
      expect(createCall.data.discount).toBe(0);
    });
  });

  describe('updateQuoteStatus()', () => {
    it('should update quote status', async () => {
      mockPrismaService.quote.update.mockResolvedValue({ ...mockQuote, status: 'ACCEPTED' });

      const result = await service.updateQuoteStatus('quote-1', companyId, 'ACCEPTED');

      expect(result.data.status).toBe('ACCEPTED');
    });

    it('should throw NotFoundException for quote in another company', async () => {
      mockPrismaService.quote.findFirst.mockResolvedValue(null);

      await expect(service.updateQuoteStatus('nonexistent', companyId, 'ACCEPTED')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Status Workflow ==========
  describe('Status Workflow: DRAFT -> CONFIRMED -> DELIVERED -> PAID', () => {
    it('should track draft invoice', async () => {
      mockPrismaService.invoice.findFirst.mockResolvedValue({ ...mockInvoice, status: 'DRAFT' });

      const result = await service.findOneInvoice(invoiceId, companyId);

      expect(result.data.status).toBe('DRAFT');
    });

    it('should allow status change to CONFIRMED', async () => {
      mockPrismaService.invoice.update.mockResolvedValue({ ...mockInvoice, status: 'CONFIRMED' });

      const result = await service.updateInvoice(invoiceId, companyId, { status: 'CONFIRMED' as any });

      expect(result.data.status).toBe('CONFIRMED');
    });

    it('should allow status change to DELIVERED', async () => {
      mockPrismaService.invoice.update.mockResolvedValue({ ...mockInvoice, status: 'DELIVERED' });

      const result = await service.updateInvoice(invoiceId, companyId, { status: 'DELIVERED' as any });

      expect(result.data.status).toBe('DELIVERED');
    });

    it('should allow status change to PAID', async () => {
      mockPrismaService.invoice.update.mockResolvedValue({ ...mockInvoice, status: 'PAID', paidAmount: 2204 });

      const result = await service.updateInvoice(invoiceId, companyId, { status: 'PAID' as any });

      expect(result.data.status).toBe('PAID');
    });
  });

  // ========== Sales Reports ==========
  describe('getSalesReport()', () => {
    it('should return aggregated sales data', async () => {
      mockPrismaService.invoice.findMany.mockResolvedValue([
        { ...mockInvoice, total: 1000, paidAmount: 600, status: 'PAID' },
        { ...mockInvoice, total: 1500, paidAmount: 0, status: 'PENDING' },
      ]);

      const result = await service.getSalesReport(companyId, {});

      expect(result.data.totalInvoices).toBe(2);
      expect(result.data.totalSales).toBe(2500);
      expect(result.data.totalPaid).toBe(600);
      expect(result.data.totalPending).toBe(1900);
    });

    it('should aggregate by status', async () => {
      mockPrismaService.invoice.findMany.mockResolvedValue([
        { ...mockInvoice, total: 1000, status: 'PAID' },
        { ...mockInvoice, total: 2000, status: 'PAID' },
        { ...mockInvoice, total: 1500, status: 'PENDING' },
      ]);

      const result = await service.getSalesReport(companyId, {});

      expect(result.data.byStatus.PAID).toBe(3000);
      expect(result.data.byStatus.PENDING).toBe(1500);
    });

    it('should aggregate by channel', async () => {
      mockPrismaService.invoice.findMany.mockResolvedValue([
        { ...mockInvoice, total: 1000, salesChannel: 'direct' },
        { ...mockInvoice, total: 2000, salesChannel: 'online' },
        { ...mockInvoice, total: 1500, salesChannel: null },
      ]);

      const result = await service.getSalesReport(companyId, {});

      expect(result.data.byChannel.direct).toBe(1000);
      expect(result.data.byChannel.online).toBe(2000);
      expect(result.data.byChannel.unknown).toBe(1500);
    });

    it('should filter by date range', async () => {
      mockPrismaService.invoice.findMany.mockResolvedValue([mockInvoice]);

      await service.getSalesReport(companyId, { startDate: '2024-01-01', endDate: '2024-01-31' });

      expect(mockPrismaService.invoice.findMany).toHaveBeenCalledWith({
        where: expect.objectContaining({
          companyId,
          deletedAt: null,
          issueDate: expect.objectContaining({
            gte: expect.any(Date),
            lte: expect.any(Date),
          }),
        }),
      });
    });
  });

  // ========== getSalesChannels ==========
  describe('getSalesChannels()', () => {
    it('should return sales grouped by channel', async () => {
      const result = await service.getSalesChannels(companyId);

      expect(result.data).toHaveLength(2);
      expect(result.data[0]).toHaveProperty('salesChannel');
      expect(result.data[0]).toHaveProperty('_sum');
      expect(result.data[0]).toHaveProperty('_count');
    });

    it('should exclude deleted invoices', async () => {
      await service.getSalesChannels(companyId);

      expect(mockPrismaService.invoice.groupBy).toHaveBeenCalledWith({
        by: ['salesChannel'],
        where: { companyId, deletedAt: null },
        _sum: { total: true },
        _count: { id: true },
      });
    });
  });

  // ========== Multi-company Isolation ==========
  describe('Multi-company Isolation', () => {
    it('should scope invoices to company', async () => {
      await service.findAllInvoices(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.invoice.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });

    it('should scope returns to company via invoice', async () => {
      await service.findAllReturns(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.salesReturn.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            invoice: { companyId },
          }),
        }),
      );
    });

    it('should scope quotes to company', async () => {
      await service.findAllQuotes(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.quote.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });
  });
});
