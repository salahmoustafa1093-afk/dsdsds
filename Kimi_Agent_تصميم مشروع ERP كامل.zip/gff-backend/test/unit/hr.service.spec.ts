import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException } from '@nestjs/common';
import { HrService } from '@/hr/hr.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('HrService', () => {
  let service: HrService;
  let mockPrismaService: any;

  const companyId = 'company-1';
  const employeeId = 'employee-1';

  const mockEmployee = {
    id: employeeId,
    employeeCode: 'EMP001',
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@company.com',
    phone: '+962799111222',
    salary: 5000,
    department: 'Sales',
    position: 'Sales Manager',
    branchId: 'branch-1',
    companyId,
    hireDate: new Date('2023-01-15'),
    birthDate: new Date('1990-05-20'),
    status: 'ACTIVE',
    deletedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    branch: { id: 'branch-1', name: 'Main Branch' },
  };

  const mockAttendance = {
    id: 'att-1',
    employeeId,
    date: new Date('2024-01-15'),
    checkIn: new Date('2024-01-15T08:00:00'),
    checkOut: new Date('2024-01-15T17:00:00'),
    status: 'PRESENT',
    workHours: 9,
    overtimeHours: 1,
    notes: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockPayroll = {
    id: 'payroll-1',
    employeeId,
    periodStart: new Date('2024-01-01'),
    periodEnd: new Date('2024-01-31'),
    baseSalary: 5000,
    overtimePay: 562.5,
    bonuses: 200,
    deductions: 100,
    taxAmount: 288.13,
    socialSecurity: 375,
    netSalary: 4899.37,
    status: 'DRAFT',
    paidAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockCommission = {
    id: 'comm-1',
    employeeId,
    type: 'SALES',
    amount: 1500,
    rate: 0.05,
    baseAmount: 30000,
    description: 'January sales commission',
    status: 'PENDING',
    paidAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockLeave = {
    id: 'leave-1',
    employeeId,
    type: 'ANNUAL',
    startDate: new Date('2024-03-01'),
    endDate: new Date('2024-03-05'),
    days: 5,
    reason: 'Family vacation',
    status: 'PENDING',
    approvedBy: null,
    approvedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(async () => {
    mockPrismaService = {
      employee: {
        findFirst: jest.fn().mockResolvedValue(mockEmployee),
        findUnique: jest.fn().mockResolvedValue(null),
        findMany: jest.fn().mockResolvedValue([mockEmployee]),
        create: jest.fn().mockResolvedValue(mockEmployee),
        update: jest.fn().mockResolvedValue(mockEmployee),
        count: jest.fn().mockResolvedValue(1),
        groupBy: jest.fn().mockResolvedValue([
          { department: 'Sales', _count: { id: 5 } },
          { department: 'IT', _count: { id: 3 } },
        ]),
      },
      attendanceRecord: {
        findMany: jest.fn().mockResolvedValue([mockAttendance]),
        upsert: jest.fn().mockResolvedValue(mockAttendance),
        count: jest.fn().mockResolvedValue(22),
      },
      payroll: {
        findFirst: jest.fn().mockResolvedValue(mockPayroll),
        findMany: jest.fn().mockResolvedValue([mockPayroll]),
        create: jest.fn().mockResolvedValue(mockPayroll),
        update: jest.fn().mockResolvedValue(mockPayroll),
        count: jest.fn().mockResolvedValue(1),
      },
      commission: {
        findFirst: jest.fn().mockResolvedValue(mockCommission),
        findMany: jest.fn().mockResolvedValue([mockCommission]),
        create: jest.fn().mockResolvedValue(mockCommission),
        update: jest.fn().mockResolvedValue(mockCommission),
        count: jest.fn().mockResolvedValue(1),
      },
      leave: {
        findFirst: jest.fn().mockResolvedValue(mockLeave),
        findMany: jest.fn().mockResolvedValue([mockLeave]),
        create: jest.fn().mockResolvedValue(mockLeave),
        update: jest.fn().mockResolvedValue(mockLeave),
        count: jest.fn().mockResolvedValue(1),
      },
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        HrService,
        { provide: PrismaService, useValue: mockPrismaService },
      ],
    }).compile();

    service = module.get<HrService>(HrService);
    jest.clearAllMocks();
  });

  // ========== Employee CRUD ==========
  describe('findAllEmployees()', () => {
    it('should return paginated employees for company', async () => {
      const result = await service.findAllEmployees(companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.page).toBe(1);
      expect(result.meta.total).toBe(1);
    });

    it('should filter by department', async () => {
      await service.findAllEmployees(companyId, { page: 1, limit: 10, department: 'Sales' });

      expect(mockPrismaService.employee.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ department: 'Sales' }),
        }),
      );
    });

    it('should filter by status', async () => {
      await service.findAllEmployees(companyId, { page: 1, limit: 10, status: 'ACTIVE' });

      expect(mockPrismaService.employee.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ status: 'ACTIVE' }),
        }),
      );
    });

    it('should search by name or code', async () => {
      await service.findAllEmployees(companyId, { page: 1, limit: 10, search: 'john' });

      expect(mockPrismaService.employee.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            OR: expect.arrayContaining([
              { firstName: { contains: 'john', mode: 'insensitive' } },
              { lastName: { contains: 'john', mode: 'insensitive' } },
              { employeeCode: { contains: 'john', mode: 'insensitive' } },
              { email: { contains: 'john', mode: 'insensitive' } },
            ]),
          }),
        }),
      );
    });

    it('should exclude deleted employees', async () => {
      await service.findAllEmployees(companyId, { page: 1, limit: 10 });

      expect(mockPrismaService.employee.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ deletedAt: null }),
        }),
      );
    });

    it('should include branch and counts', async () => {
      const result = await service.findAllEmployees(companyId, { page: 1, limit: 10 });

      expect(result.data[0].branch).toBeDefined();
    });
  });

  describe('findOneEmployee()', () => {
    it('should return employee with all relations', async () => {
      const result = await service.findOneEmployee(employeeId, companyId);

      expect(result.data.id).toBe(employeeId);
      expect(result.data.branch).toBeDefined();
      expect(result.data.attendance).toBeDefined();
      expect(result.data.payrolls).toBeDefined();
      expect(result.data.commissions).toBeDefined();
      expect(result.data.leaves).toBeDefined();
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.findOneEmployee('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });

    it('should throw NotFoundException for deleted employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.findOneEmployee('deleted', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  describe('createEmployee()', () => {
    const createEmployeeDto = {
      employeeCode: 'EMP002',
      firstName: 'Jane',
      lastName: 'Smith',
      email: 'jane@company.com',
      phone: '+962799222333',
      salary: 6000,
      department: 'IT',
      position: 'Developer',
      branchId: 'branch-1',
      hireDate: '2024-01-15',
      birthDate: '1995-03-10',
      status: 'ACTIVE',
    };

    it('should create employee', async () => {
      const result = await service.createEmployee(companyId, createEmployeeDto);

      expect(result.data).toBeDefined();
      expect(result.data.employeeCode).toBe('EMP001');
    });

    it('should throw ConflictException for duplicate employee code', async () => {
      mockPrismaService.employee.findUnique.mockResolvedValue(mockEmployee);

      await expect(service.createEmployee(companyId, createEmployeeDto)).rejects.toThrow(ConflictException);
    });

    it('should use default status ACTIVE', async () => {
      const dtoNoStatus = { ...createEmployeeDto, status: undefined };
      mockPrismaService.employee.findUnique.mockResolvedValue(null);

      await service.createEmployee(companyId, dtoNoStatus);

      const createCall = mockPrismaService.employee.create.mock.calls[0][0];
      expect(createCall.data.status).toBe('ACTIVE');
    });

    it('should parse hireDate to Date', async () => {
      mockPrismaService.employee.findUnique.mockResolvedValue(null);

      await service.createEmployee(companyId, createEmployeeDto);

      const createCall = mockPrismaService.employee.create.mock.calls[0][0];
      expect(createCall.data.hireDate).toBeInstanceOf(Date);
    });

    it('should parse birthDate to Date when provided', async () => {
      mockPrismaService.employee.findUnique.mockResolvedValue(null);

      await service.createEmployee(companyId, createEmployeeDto);

      const createCall = mockPrismaService.employee.create.mock.calls[0][0];
      expect(createCall.data.birthDate).toBeInstanceOf(Date);
    });

    it('should handle optional birthDate', async () => {
      const dtoNoBirth = { ...createEmployeeDto, birthDate: undefined };
      mockPrismaService.employee.findUnique.mockResolvedValue(null);

      await service.createEmployee(companyId, dtoNoBirth);

      const createCall = mockPrismaService.employee.create.mock.calls[0][0];
      expect(createCall.data.birthDate).toBeUndefined();
    });
  });

  describe('updateEmployee()', () => {
    it('should update employee fields', async () => {
      mockPrismaService.employee.update.mockResolvedValue({
        ...mockEmployee,
        firstName: 'Johnny',
        salary: 5500,
      });

      const result = await service.updateEmployee(employeeId, companyId, {
        firstName: 'Johnny',
        salary: 5500,
      });

      expect(result.data.firstName).toBe('Johnny');
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.updateEmployee('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  describe('removeEmployee()', () => {
    it('should soft delete employee with TERMINATED status', async () => {
      const result = await service.removeEmployee(employeeId, companyId);

      expect(result.data.message).toBe('Employee deleted successfully');
      expect(mockPrismaService.employee.update).toHaveBeenCalledWith({
        where: { id: employeeId },
        data: { deletedAt: expect.any(Date), status: 'TERMINATED' },
      });
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.removeEmployee('nonexistent', companyId)).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Attendance ==========
  describe('getAttendance()', () => {
    it('should return paginated attendance records', async () => {
      const result = await service.getAttendance(employeeId, companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.getAttendance('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  describe('recordAttendance()', () => {
    const attendanceDto = {
      date: '2024-01-15',
      checkIn: '08:00',
      checkOut: '17:00',
      status: 'PRESENT' as const,
      overtimeHours: 1,
      notes: 'Regular work day',
    };

    it('should record attendance with work hours calculation', async () => {
      const result = await service.recordAttendance(employeeId, companyId, attendanceDto);

      expect(result.data).toBeDefined();
      expect(result.data.workHours).toBe(9); // 17 - 8 = 9 hours
      expect(result.data.overtimeHours).toBe(1);
    });

    it('should calculate work hours correctly', async () => {
      await service.recordAttendance(employeeId, companyId, {
        ...attendanceDto,
        checkIn: '09:00',
        checkOut: '18:00',
      });

      const upsertCall = mockPrismaService.attendanceRecord.upsert.mock.calls[0][0];
      expect(upsertCall.update.workHours).toBe(9);
    });

    it('should handle present status', async () => {
      await service.recordAttendance(employeeId, companyId, { ...attendanceDto, status: 'PRESENT' });

      const upsertCall = mockPrismaService.attendanceRecord.upsert.mock.calls[0][0];
      expect(upsertCall.update.status).toBe('PRESENT');
    });

    it('should handle absent status', async () => {
      await service.recordAttendance(employeeId, companyId, {
        ...attendanceDto,
        checkIn: undefined,
        checkOut: undefined,
        status: 'ABSENT',
      });

      const upsertCall = mockPrismaService.attendanceRecord.upsert.mock.calls[0][0];
      expect(upsertCall.update.status).toBe('ABSENT');
    });

    it('should handle late status', async () => {
      await service.recordAttendance(employeeId, companyId, {
        ...attendanceDto,
        checkIn: '10:00',
        status: 'LATE',
      });

      const upsertCall = mockPrismaService.attendanceRecord.upsert.mock.calls[0][0];
      expect(upsertCall.update.status).toBe('LATE');
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.recordAttendance('nonexistent', companyId, attendanceDto)).rejects.toThrow(NotFoundException);
    });

    it('should use default status PRESENT', async () => {
      await service.recordAttendance(employeeId, companyId, {
        date: '2024-01-15',
      } as any);

      const upsertCall = mockPrismaService.attendanceRecord.upsert.mock.calls[0][0];
      expect(upsertCall.create.status).toBe('PRESENT');
    });

    it('should set workHours to 0 when no check-in/check-out', async () => {
      await service.recordAttendance(employeeId, companyId, {
        date: '2024-01-15',
        status: 'ABSENT',
      } as any);

      const upsertCall = mockPrismaService.attendanceRecord.upsert.mock.calls[0][0];
      expect(upsertCall.update.workHours).toBe(0);
    });
  });

  // ========== Payroll ==========
  describe('getPayrolls()', () => {
    it('should return paginated payrolls', async () => {
      const result = await service.getPayrolls(employeeId, companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.getPayrolls('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  describe('generatePayroll()', () => {
    const payrollDto = {
      periodStart: '2024-01-01',
      periodEnd: '2024-01-31',
      bonuses: 200,
      deductions: 100,
      overtimePay: undefined,
    };

    it('should generate payroll with correct calculation', async () => {
      mockPrismaService.attendanceRecord.findMany.mockResolvedValue([
        { ...mockAttendance, workHours: 8, overtimeHours: 0 },
        { ...mockAttendance, workHours: 9, overtimeHours: 1 },
      ]);

      const result = await service.generatePayroll(employeeId, companyId, payrollDto);

      // baseSalary = 5000
      // overtimePay = 1 * (5000/30/8*1.5) = 1 * 31.25 = 31.25
      // bonuses = 200
      // deductions = 100
      // taxAmount = (5000 + 31.25 + 200) * 0.05 = 261.56
      // socialSecurity = 5000 * 0.075 = 375
      // netSalary = 5000 + 31.25 + 200 - 100 - 261.56 - 375 = 4494.69
      expect(result.data.baseSalary).toBe(5000);
      expect(result.data.bonuses).toBe(200);
      expect(result.data.deductions).toBe(100);
      expect(result.data.taxAmount).toBeGreaterThan(0);
      expect(result.data.socialSecurity).toBe(375);
      expect(result.data.netSalary).toBeGreaterThan(0);
      expect(result.data.status).toBe('DRAFT');
    });

    it('should use provided overtimePay', async () => {
      const dtoWithOvertime = { ...payrollDto, overtimePay: 500 };

      const result = await service.generatePayroll(employeeId, companyId, dtoWithOvertime);

      expect(result.data.overtimePay).toBe(500);
    });

    it('should use zero bonuses and deductions when not provided', async () => {
      const dtoMinimal = {
        periodStart: '2024-01-01',
        periodEnd: '2024-01-31',
      };

      const result = await service.generatePayroll(employeeId, companyId, dtoMinimal);

      expect(result.data.bonuses).toBe(0);
      expect(result.data.deductions).toBe(0);
    });

    it('should calculate 5% flat tax', async () => {
      mockPrismaService.attendanceRecord.findMany.mockResolvedValue([]);

      const result = await service.generatePayroll(employeeId, companyId, {
        ...payrollDto,
        bonuses: 0,
        overtimePay: 0,
      });

      // tax = (5000 + 0 + 0) * 0.05 = 250
      expect(result.data.taxAmount).toBe(250);
    });

    it('should calculate 7.5% social security', async () => {
      mockPrismaService.attendanceRecord.findMany.mockResolvedValue([]);

      const result = await service.generatePayroll(employeeId, companyId, payrollDto);

      // social security = 5000 * 0.075 = 375
      expect(result.data.socialSecurity).toBe(375);
    });

    it('should verify formula: salary + allowances - deductions = net', async () => {
      mockPrismaService.attendanceRecord.findMany.mockResolvedValue([]);

      const result = await service.generatePayroll(employeeId, companyId, payrollDto);

      const { baseSalary, overtimePay, bonuses, deductions, taxAmount, socialSecurity, netSalary } = result.data;
      const expectedNet = baseSalary + overtimePay + bonuses - deductions - taxAmount - socialSecurity;
      expect(netSalary).toBeCloseTo(expectedNet, 1);
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.generatePayroll('nonexistent', companyId, payrollDto)).rejects.toThrow(NotFoundException);
    });
  });

  describe('updatePayrollStatus()', () => {
    it('should update status to PAID with paidAt', async () => {
      mockPrismaService.payroll.update.mockResolvedValue({ ...mockPayroll, status: 'PAID', paidAt: new Date() });

      const result = await service.updatePayrollStatus('payroll-1', companyId, 'PAID');

      expect(result.data.status).toBe('PAID');
    });

    it('should throw NotFoundException for payroll in another company', async () => {
      mockPrismaService.payroll.findFirst.mockResolvedValue(null);

      await expect(service.updatePayrollStatus('nonexistent', companyId, 'PAID')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Commissions ==========
  describe('getCommissions()', () => {
    it('should return paginated commissions', async () => {
      const result = await service.getCommissions(employeeId, companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.getCommissions('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  describe('createCommission()', () => {
    const commissionDto = {
      type: 'SALES' as const,
      amount: 2000,
      rate: 0.05,
      baseAmount: 40000,
      description: 'February sales commission',
    };

    it('should create commission', async () => {
      const result = await service.createCommission(employeeId, companyId, commissionDto);

      expect(result.data).toBeDefined();
      expect(result.data.status).toBe('PENDING');
      expect(result.data.amount).toBe(2000);
    });

    it('should calculate commission based on targets', async () => {
      // 5% of 40000 = 2000
      await service.createCommission(employeeId, companyId, commissionDto);

      const createCall = mockPrismaService.commission.create.mock.calls[0][0];
      expect(createCall.data.amount).toBe(2000);
      expect(createCall.data.rate).toBe(0.05);
      expect(createCall.data.baseAmount).toBe(40000);
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.createCommission('nonexistent', companyId, commissionDto)).rejects.toThrow(NotFoundException);
    });
  });

  describe('updateCommissionStatus()', () => {
    it('should update to PAID with paidAt', async () => {
      mockPrismaService.commission.update.mockResolvedValue({ ...mockCommission, status: 'PAID', paidAt: new Date() });

      const result = await service.updateCommissionStatus('comm-1', companyId, 'PAID');

      expect(result.data.status).toBe('PAID');
    });

    it('should throw NotFoundException for commission in another company', async () => {
      mockPrismaService.commission.findFirst.mockResolvedValue(null);

      await expect(service.updateCommissionStatus('nonexistent', companyId, 'PAID')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== Leave Management ==========
  describe('getLeaves()', () => {
    it('should return paginated leave records', async () => {
      const result = await service.getLeaves(employeeId, companyId, { page: 1, limit: 10 });

      expect(result.data).toHaveLength(1);
      expect(result.meta.total).toBe(1);
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.getLeaves('nonexistent', companyId, {})).rejects.toThrow(NotFoundException);
    });
  });

  describe('createLeave()', () => {
    const leaveDto = {
      type: 'ANNUAL' as const,
      startDate: '2024-03-01',
      endDate: '2024-03-05',
      days: 5,
      reason: 'Family vacation',
    };

    it('should create leave request with PENDING status', async () => {
      const result = await service.createLeave(employeeId, companyId, leaveDto);

      expect(result.data).toBeDefined();
      expect(result.data.status).toBe('PENDING');
      expect(result.data.days).toBe(5);
    });

    it('should create sick leave', async () => {
      const result = await service.createLeave(employeeId, companyId, {
        ...leaveDto,
        type: 'SICK',
        reason: 'Flu',
      });

      expect(result.data).toBeDefined();
    });

    it('should create unpaid leave', async () => {
      const result = await service.createLeave(employeeId, companyId, {
        ...leaveDto,
        type: 'UNPAID',
        reason: 'Personal',
      });

      expect(result.data).toBeDefined();
    });

    it('should throw NotFoundException for non-existent employee', async () => {
      mockPrismaService.employee.findFirst.mockResolvedValue(null);

      await expect(service.createLeave('nonexistent', companyId, leaveDto)).rejects.toThrow(NotFoundException);
    });
  });

  describe('updateLeaveStatus()', () => {
    it('should approve leave with approver info', async () => {
      mockPrismaService.leave.update.mockResolvedValue({
        ...mockLeave,
        status: 'APPROVED',
        approvedBy: 'manager-1',
        approvedAt: new Date(),
      });

      const result = await service.updateLeaveStatus('leave-1', companyId, 'APPROVED', 'manager-1');

      expect(result.data.status).toBe('APPROVED');
      expect(mockPrismaService.leave.update).toHaveBeenCalledWith({
        where: { id: 'leave-1' },
        data: expect.objectContaining({
          status: 'APPROVED',
          approvedBy: 'manager-1',
          approvedAt: expect.any(Date),
        }),
      });
    });

    it('should reject leave', async () => {
      mockPrismaService.leave.update.mockResolvedValue({ ...mockLeave, status: 'REJECTED' });

      const result = await service.updateLeaveStatus('leave-1', companyId, 'REJECTED');

      expect(result.data.status).toBe('REJECTED');
    });

    it('should throw NotFoundException for leave in another company', async () => {
      mockPrismaService.leave.findFirst.mockResolvedValue(null);

      await expect(service.updateLeaveStatus('nonexistent', companyId, 'APPROVED')).rejects.toThrow(NotFoundException);
    });
  });

  // ========== HR Dashboard ==========
  describe('getHrStats()', () => {
    it('should return HR statistics', async () => {
      const result = await service.getHrStats(companyId);

      expect(result.data.total).toBe(1);
      expect(result.data.active).toBe(1);
      expect(result.data.onLeave).toBe(1);
      expect(result.data.departments).toBeDefined();
      expect(result.data.monthlyAttendance).toBe(22);
    });

    it('should scope to company', async () => {
      await service.getHrStats(companyId);

      expect(mockPrismaService.employee.count).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ companyId }),
        }),
      );
    });

    it('should count monthly attendance', async () => {
      await service.getHrStats(companyId);

      expect(mockPrismaService.attendanceRecord.count).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            employee: { companyId },
            date: expect.any(Object),
          }),
        }),
      );
    });
  });
});
