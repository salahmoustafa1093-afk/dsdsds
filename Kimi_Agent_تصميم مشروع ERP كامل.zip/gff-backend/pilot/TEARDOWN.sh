#!/bin/bash
# =============================================================================
# GFF ERP - Pilot Environment Teardown Script
# =============================================================================
# Clean removal of all pilot environment resources
# Usage: ./TEARDOWN.sh [--full] [--keep-data]
#
# Options:
#   --full      Remove Docker volumes and images too (complete cleanup)
#   --keep-data Keep data volumes (postgres-data, redis-data)
#   --yes       Skip confirmation prompt
# =============================================================================

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Flags
FULL_TEARDOWN=false
KEEP_DATA=false
SKIP_CONFIRM=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --full) FULL_TEARDOWN=true; shift ;;
        --keep-data) KEEP_DATA=true; shift ;;
        --yes) SKIP_CONFIRM=true; shift ;;
        --help)
            echo "GFF ERP Pilot Teardown Script"
            echo ""
            echo "Usage: ./TEARDOWN.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --full      Remove Docker volumes and images"
            echo "  --keep-data Keep data volumes (safe for data)"
            echo "  --yes       Skip confirmation prompt"
            echo "  --help      Show this help"
            echo ""
            echo "WARNING: This will remove all GFF ERP containers and resources!"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

# =============================================================================
# Helper Functions
# =============================================================================
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[OK]${NC}   $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERR]${NC}  $1"
}

# =============================================================================
# Confirmation
# =============================================================================
if [ "$SKIP_CONFIRM" = false ]; then
    echo ""
    echo -e "${RED}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${RED}${BOLD}  WARNING: GFF ERP Pilot Environment Teardown${NC}"
    echo -e "${RED}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "This will:"
    echo "  - Stop and remove all GFF ERP Docker containers"
    echo "  - Remove Docker networks created by the stack"
    
    if [ "$FULL_TEARDOWN" = true ]; then
        echo -e "  - ${RED}Remove all Docker volumes (including data!)${NC}"
        echo -e "  - ${RED}Remove Docker images${NC}"
    elif [ "$KEEP_DATA" = true ]; then
        echo "  - Keep data volumes (postgres-data, redis-data)"
    else
        echo "  - Remove Docker volumes (except named data volumes)"
    fi
    
    echo ""
    read -p "Are you sure you want to continue? [y/N]: " confirm
    
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
        log_info "Teardown cancelled."
        exit 0
    fi
fi

# =============================================================================
# Teardown
# =============================================================================
echo ""
echo -e "${BOLD}Starting teardown...${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
COMPOSE_FILE="${PROJECT_DIR}/docker/docker-compose.prod.yml"

# Check if compose file exists
if [ ! -f "$COMPOSE_FILE" ]; then
    log_warn "Compose file not found at ${COMPOSE_FILE}"
    log_info "Will attempt to remove containers by name pattern..."
    COMPOSE_FILE=""
fi

# Step 1: Stop and remove containers
log_info "Stopping and removing containers..."

if [ -n "$COMPOSE_FILE" ]; then
    # Stop services
    docker compose -f "$COMPOSE_FILE" down --remove-orphans 2>/dev/null || true
    log_success "Compose services stopped"
else
    # Fallback: stop by container names
    containers=("gff-postgres" "gff-redis" "gff-backend-api-1" "gff-backend-api-2" "gff-backend-api-3" "gff-nginx" "gff-prometheus" "gff-grafana" "gff-loki" "gff-promtail" "gff-node-exporter" "gff-postgres-exporter" "gff-redis-exporter" "gff-backup")
    
    for container in "${containers[@]}"; do
        if docker ps -a -q -f "name=$container" | grep -q .; then
            docker stop "$container" 2>/dev/null || true
            docker rm "$container" 2>/dev/null || true
            log_info "Removed container: $container"
        fi
    done
fi

# Step 2: Remove volumes
if [ "$FULL_TEARDOWN" = true ]; then
    log_info "Removing all volumes..."
    
    if [ -n "$COMPOSE_FILE" ]; then
        docker compose -f "$COMPOSE_FILE" down -v 2>/dev/null || true
    fi
    
    # Remove named volumes
    volumes=("gff-backend_postgres-data" "gff-backend_redis-data" "gff-backend_grafana-data" "gff-backend_prometheus-data" "gff-backend_nginx-certs" "gff-backend_app-logs" "gff-backend_loki-data")
    for vol in "${volumes[@]}"; do
        if docker volume ls -q | grep -q "^${vol}$"; then
            docker volume rm "$vol" 2>/dev/null || true
            log_info "Removed volume: $vol"
        fi
    done
    
    # Remove host bind directories
    if [ -d "/data" ]; then
        read -p "Remove /data directory? This will DELETE all database data! [y/N]: " remove_data
        if [[ "$remove_data" =~ ^[Yy]$ ]]; then
            rm -rf /data
            log_success "Removed /data directory"
        else
            log_info "Kept /data directory"
        fi
    fi
    
    log_success "All volumes removed"
elif [ "$KEEP_DATA" = true ]; then
    log_info "Keeping data volumes as requested (--keep-data)"
    
    # Only remove non-data volumes
    volumes_to_remove=("gff-backend_grafana-data" "gff-backend_prometheus-data" "gff-backend_nginx-certs" "gff-backend_app-logs" "gff-backend_loki-data")
    for vol in "${volumes_to_remove[@]}"; do
        if docker volume ls -q | grep -q "^${vol}$"; then
            docker volume rm "$vol" 2>/dev/null || true
            log_info "Removed volume: $vol"
        fi
    done
else
    log_info "Removing Docker volumes (compose default)..."
    if [ -n "$COMPOSE_FILE" ]; then
        docker compose -f "$COMPOSE_FILE" down -v 2>/dev/null || true
    fi
fi

# Step 3: Remove networks
log_info "Removing networks..."
networks=("gff-backend_frontend" "gff-backend_backend" "gff-backend_database" "gff-backend_monitoring")
for net in "${networks[@]}"; do
    if docker network ls -q -f "name=$net" | grep -q .; then
        docker network rm "$net" 2>/dev/null || true
        log_info "Removed network: $net"
    fi
done
log_success "Networks removed"

# Step 4: Remove images (only in full mode)
if [ "$FULL_TEARDOWN" = true ]; then
    log_info "Removing Docker images..."
    
    images=(
        "postgres:16-alpine"
        "redis:7-alpine"
        "nginx:1.25-alpine"
        "prom/prometheus:v2.48.0"
        "grafana/grafana:10.2.0"
        "grafana/loki:2.9.0"
        "grafana/promtail:2.9.0"
        "prom/node-exporter:v1.7.0"
        "prometheuscommunity/postgres-exporter:v0.15.0"
        "oliver006/redis_exporter:v1.55.0"
    )
    
    for img in "${images[@]}"; do
        if docker images -q "$img" 2>/dev/null | grep -q .; then
            docker rmi "$img" 2>/dev/null || true
            log_info "Removed image: $img"
        fi
    done
    
    # Remove project-specific images
    if docker images -q "ghcr.io/gff-erp/backend" 2>/dev/null | grep -q .; then
        docker rmi $(docker images -q "ghcr.io/gff-erp/backend") 2>/dev/null || true
    fi
    if docker images -q "ghcr.io/gff-erp/frontend" 2>/dev/null | grep -q .; then
        docker rmi $(docker images -q "ghcr.io/gff-erp/frontend") 2>/dev/null || true
    fi
    
    # Prune dangling
    docker image prune -f 2>/dev/null || true
    docker builder prune -f 2>/dev/null || true
    
    log_success "Images removed"
fi

# Step 5: Clean up credentials file
if [ -f "${PROJECT_DIR}/pilot/credentials.txt" ]; then
    rm -f "${PROJECT_DIR}/pilot/credentials.txt"
    log_info "Removed credentials file"
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}${BOLD}  Teardown Complete!${NC}"
echo -e "${GREEN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "Remaining resources:"

# Show remaining containers
echo ""
echo "Containers (GFF-related):"
remaining_containers=$(docker ps -a --format "table {{.Names}}\t{{.Status}}" | grep -E "gff-|gff_" || true)
if [ -n "$remaining_containers" ]; then
    echo "$remaining_containers"
else
    echo "  (none)"
fi

# Show remaining volumes
echo ""
echo "Volumes (GFF-related):"
remaining_volumes=$(docker volume ls | grep -E "gff-" || true)
if [ -n "$remaining_volumes" ]; then
    echo "$remaining_volumes"
else
    echo "  (none)"
fi

# Show remaining networks
echo ""
echo "Networks (GFF-related):"
remaining_networks=$(docker network ls | grep -E "gff-" || true)
if [ -n "$remaining_networks" ]; then
    echo "$remaining_networks"
else
    echo "  (none)"
fi

echo ""
log_success "GFF ERP pilot environment has been removed!"
echo ""
echo "To set up again, run:"
echo "  ./pilot/setup-pilot.sh"
echo ""