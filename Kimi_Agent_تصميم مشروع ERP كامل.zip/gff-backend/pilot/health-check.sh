#!/bin/bash
# =============================================================================
# GFF ERP - Post-Deployment Health Check Script
# =============================================================================
# Checks all services and reports status with colors
# Usage: ./health-check.sh [--watch] [--json]
#
# Options:
#   --watch   Continuous monitoring mode (refreshes every 10s)
#   --json    Output results as JSON
# =============================================================================

set -uo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

WATCH_MODE=false
JSON_MODE=false
COMPOSE_FILE=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --watch) WATCH_MODE=true; shift ;;
        --json) JSON_MODE=true; shift ;;
        *) shift ;;
    esac
done

# Find docker-compose file
find_compose_file() {
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    local project_dir="$(cd "${script_dir}/.." && pwd)"
    
    if [ -f "${project_dir}/docker/docker-compose.prod.yml" ]; then
        echo "${project_dir}/docker/docker-compose.prod.yml"
    elif [ -f "${project_dir}/docker-compose.yml" ]; then
        echo "${project_dir}/docker-compose.yml"
    else
        echo ""
    fi
}

COMPOSE_FILE=$(find_compose_file)

# =============================================================================
# Health Check Functions
# =============================================================================
check_container() {
    local name=$1
    local status
    
    if [ -n "$COMPOSE_FILE" ]; then
        status=$(docker compose -f "$COMPOSE_FILE" ps -q "$name" 2>/dev/null | xargs -I {} docker inspect -f '{{.State.Status}}' {} 2>/dev/null)
    else
        status=$(docker ps -q -f "name=$name" | head -1 | xargs -I {} docker inspect -f '{{.State.Status}}' {} 2>/dev/null)
    fi
    
    if [ "$status" = "running" ]; then
        echo "PASS"
    else
        echo "FAIL"
    fi
}

check_database() {
    local result
    if [ -n "$COMPOSE_FILE" ]; then
        result=$(docker compose -f "$COMPOSE_FILE" exec -T postgres pg_isready -U gff_pilot -d gff_erp_pilot 2>/dev/null)
    else
        result=$(docker exec gff-postgres pg_isready -U gff_pilot -d gff_erp_pilot 2>/dev/null)
    fi
    
    if echo "$result" | grep -q "accepting connections"; then
        echo "PASS"
    else
        echo "FAIL"
    fi
}

check_api() {
    local status
    status=$(curl -sf -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:3001/api/v1/health 2>/dev/null || echo "000")
    
    if [ "$status" = "200" ]; then
        echo "PASS"
    else
        echo "FAIL"
    fi
}

check_api_ready() {
    local status
    status=$(curl -sf -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:3001/api/v1/health/ready 2>/dev/null || echo "000")
    
    if [ "$status" = "200" ]; then
        echo "PASS"
    else
        echo "FAIL"
    fi
}

check_redis() {
    local result
    local redis_pass="${REDIS_PASSWORD:-GffRedis2024!}"
    
    if [ -n "$COMPOSE_FILE" ]; then
        result=$(docker compose -f "$COMPOSE_FILE" exec -T redis redis-cli -a "$redis_pass" ping 2>/dev/null)
    else
        result=$(docker exec gff-redis redis-cli -a "$redis_pass" ping 2>/dev/null)
    fi
    
    if echo "$result" | grep -q "PONG"; then
        echo "PASS"
    else
        echo "FAIL"
    fi
}

check_nginx() {
    local status
    status=$(curl -sf -o /dev/null -w "%{http_code}" --max-time 5 http://localhost/health 2>/dev/null || echo "000")
    
    if [ "$status" = "200" ]; then
        echo "PASS"
    else
        echo "FAIL"
    fi
}

check_frontend() {
    local status
    status=$(curl -sf -o /dev/null -w "%{http_code}" --max-time 5 http://localhost/ 2>/dev/null || echo "000")
    
    if [ "$status" = "200" ] || [ "$status" = "304" ]; then
        echo "PASS"
    else
        echo "FAIL"
    fi
}

check_disk_space() {
    local usage
    usage=$(df / | awk 'NR==2 {print $5}' | tr -d '%')
    
    if [ "$usage" -lt 80 ]; then
        echo "PASS"
    elif [ "$usage" -lt 90 ]; then
        echo "WARN"
    else
        echo "FAIL"
    fi
}

check_memory() {
    local usage
    usage=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
    
    if [ "$usage" -lt 80 ]; then
        echo "PASS"
    elif [ "$usage" -lt 90 ]; then
        echo "WARN"
    else
        echo "FAIL"
    fi
}

# =============================================================================
# Print Results
# =============================================================================
print_status() {
    local check=$1
    local status=$2
    local detail=${3:-""}
    
    if [ "$JSON_MODE" = true ]; then
        return
    fi
    
    local color
    case "$status" in
        PASS) color="$GREEN" ;;
        WARN) color="$YELLOW" ;;
        FAIL) color="$RED" ;;
        *) color="$NC" ;;
    esac
    
    printf "  %-40s ${color}%-6s${NC} %s\n" "$check" "$status" "$detail"
}

print_header() {
    if [ "$JSON_MODE" = true ]; then
        return
    fi
    echo ""
    echo -e "${CYAN}${BOLD}GFF ERP - Health Check${NC}"
    echo -e "${CYAN}$(date '+%Y-%m-%d %H:%M:%S')${NC}"
    echo "=========================================="
}

print_summary() {
    local passed=$1
    local failed=$2
    local warnings=$3
    
    if [ "$JSON_MODE" = true ]; then
        return
    fi
    
    echo ""
    echo "=========================================="
    echo -e "${GREEN}Passed:${NC}  $passed"
    if [ "$warnings" -gt 0 ]; then
        echo -e "${YELLOW}Warnings:${NC} $warnings"
    fi
    if [ "$failed" -gt 0 ]; then
        echo -e "${RED}Failed:${NC}  $failed"
    fi
    
    if [ "$failed" -eq 0 ]; then
        echo -e "\n${GREEN}${BOLD}All checks passed! System is healthy.${NC}"
    else
        echo -e "\n${RED}${BOLD}Some checks failed! Please investigate.${NC}"
    fi
}

# =============================================================================
# Run All Checks
# =============================================================================
run_checks() {
    local passed=0
    local failed=0
    local warnings=0
    local results=()
    
    print_header
    
    # Container checks
    echo ""
    echo -e "${BOLD}Containers:${NC}"
    
    local containers=("gff-postgres" "gff-redis" "gff-backend-api-1" "gff-backend-api-2" "gff-backend-api-3" "gff-nginx")
    local container_names=("PostgreSQL" "Redis" "Backend API 1" "Backend API 2" "Backend API 3" "Nginx")
    
    for i in "${!containers[@]}"; do
        local status
        status=$(check_container "${containers[$i]}")
        print_status "${container_names[$i]}" "$status"
        
        if [ "$status" = "PASS" ]; then
            ((passed++))
        else
            ((failed++))
        fi
        
        results+=("{\"check\":\"${container_names[$i]}\",\"status\":\"$status\",\"category\":\"container\"}")
    done
    
    # Service checks
    echo ""
    echo -e "${BOLD}Services:${NC}"
    
    local db_status
    db_status=$(check_database)
    print_status "Database Connectivity" "$db_status"
    if [ "$db_status" = "PASS" ]; then ((passed++)); else ((failed++)); fi
    results+=("{\"check\":\"Database Connectivity\",\"status\":\"$db_status\",\"category\":\"service\"}")
    
    local redis_status
    redis_status=$(check_redis)
    print_status "Redis Connectivity" "$redis_status"
    if [ "$redis_status" = "PASS" ]; then ((passed++)); else ((failed++)); fi
    results+=("{\"check\":\"Redis Connectivity\",\"status\":\"$redis_status\",\"category\":\"service\"}")
    
    local api_status
    api_status=$(check_api)
    print_status "API Health (/health)" "$api_status"
    if [ "$api_status" = "PASS" ]; then ((passed++)); else ((failed++)); fi
    results+=("{\"check\":\"API Health\",\"status\":\"$api_status\",\"category\":\"service\"}")
    
    local api_ready_status
    api_ready_status=$(check_api_ready)
    print_status "API Ready (/health/ready)" "$api_ready_status"
    if [ "$api_ready_status" = "PASS" ]; then ((passed++)); else ((failed++)); fi
    results+=("{\"check\":\"API Ready\",\"status\":\"$api_ready_status\",\"category\":\"service\"}")
    
    local nginx_status
    nginx_status=$(check_nginx)
    print_status "Nginx Health" "$nginx_status"
    if [ "$nginx_status" = "PASS" ]; then ((passed++)); else ((failed++)); fi
    results+=("{\"check\":\"Nginx Health\",\"status\":\"$nginx_status\",\"category\":\"service\"}")
    
    local frontend_status
    frontend_status=$(check_frontend)
    print_status "Frontend Load" "$frontend_status"
    if [ "$frontend_status" = "PASS" ]; then ((passed++)); else ((failed++)); fi
    results+=("{\"check\":\"Frontend Load\",\"status\":\"$frontend_status\",\"category\":\"service\"}")
    
    # System checks
    echo ""
    echo -e "${BOLD}System Resources:${NC}"
    
    local disk_status
    disk_status=$(check_disk_space)
    local disk_usage
    disk_usage=$(df -h / | awk 'NR==2 {print $5}')
    print_status "Disk Space" "$disk_status" "($disk_usage used)"
    if [ "$disk_status" = "PASS" ]; then ((passed++)); elif [ "$disk_status" = "WARN" ]; then ((warnings++)); else ((failed++)); fi
    results+=("{\"check\":\"Disk Space\",\"status\":\"$disk_status\",\"detail\":\"$disk_usage\",\"category\":\"system\"}")
    
    local mem_status
    mem_status=$(check_memory)
    local mem_usage
    mem_usage=$(free -m | awk 'NR==2{printf "%s/%sMB (%.1f%%)", $3, $2, $3*100/$2}')
    print_status "Memory" "$mem_status" "($mem_usage used)"
    if [ "$mem_status" = "PASS" ]; then ((passed++)); elif [ "$mem_status" = "WARN" ]; then ((warnings++)); else ((failed++)); fi
    results+=("{\"check\":\"Memory\",\"status\":\"$mem_status\",\"detail\":\"$mem_usage\",\"category\":\"system\"}")
    
    # Summary
    print_summary "$passed" "$failed" "$warnings"
    
    # JSON output
    if [ "$JSON_MODE" = true ]; then
        local json_results
        json_results=$(printf "%s," "${results[@]}" | sed 's/,$//')
        local overall
        if [ "$failed" -eq 0 ]; then
            overall="healthy"
        else
            overall="unhealthy"
        fi
        
        echo "{"
        echo "  \"timestamp\": \"$(date -u '+%Y-%m-%dT%H:%M:%SZ')\","
        echo "  \"overall\": \"$overall\","
        echo "  \"summary\": {"
        echo "    \"passed\": $passed,"
        echo "    \"failed\": $failed,"
        echo "    \"warnings\": $warnings"
        echo "  },"
        echo "  \"checks\": [$json_results]"
        echo "}"
    fi
    
    return "$failed"
}

# =============================================================================
# Main
# =============================================================================
main() {
    if [ "$JSON_MODE" = true ]; then
        WATCH_MODE=false
    fi
    
    if [ "$WATCH_MODE" = true ]; then
        while true; do
            clear
            run_checks
            echo ""
            echo -e "${CYAN}Refreshing in 10 seconds... (Ctrl+C to exit)${NC}"
            sleep 10
        done
    else
        run_checks
        exit $?
    fi
}

main "$@"