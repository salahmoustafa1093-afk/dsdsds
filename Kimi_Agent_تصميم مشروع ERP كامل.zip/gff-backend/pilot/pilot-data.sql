-- =============================================================================
-- GFF ERP - Pilot Seed Data
-- =============================================================================
-- Realistic Egyptian data for pilot testing
-- Run: docker compose exec postgres psql -U gff_pilot -d gff_erp_pilot -f /pilot-data.sql
-- =============================================================================

BEGIN;

-- =============================================================================
-- 1. Branch: القاهرة الرئيسي
-- =============================================================================
INSERT INTO branches (id, name, name_en, address, phone, email, manager_name, is_active, created_at, updated_at)
VALUES (
    gen_random_uuid(),
    'القاهرة الرئيسي',
    'Cairo Main',
    '15 شارع رمسيس، وسط البلد، القاهرة',
    '+20 2 2390 1234',
    'cairo@gff-erp.com',
    'محمد أحمد حسن',
    true,
    NOW(),
    NOW()
)
RETURNING id INTO VARIABLE;

-- Get the branch ID for references
DO $$
DECLARE
    cairo_branch_id UUID;
    warehouse_id UUID;
    product1_id UUID;
    product2_id UUID;
    product3_id UUID;
    product4_id UUID;
    product5_id UUID;
    customer1_id UUID;
    customer2_id UUID;
    customer3_id UUID;
    supplier1_id UUID;
    supplier2_id UUID;
    driver1_id UUID;
    driver2_id UUID;
    employee1_id UUID;
    employee2_id UUID;
    employee3_id UUID;
    vehicle_id UUID;
BEGIN
    SELECT id INTO cairo_branch_id FROM branches WHERE name = 'القاهرة الرئيسي' LIMIT 1;

-- =============================================================================
-- 2. Warehouse: مخزن القاهرة
-- =============================================================================
    INSERT INTO warehouses (id, branch_id, name, name_en, area_sqm, address, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(),
        cairo_branch_id,
        'مخزن القاهرة',
        'Cairo Warehouse',
        1000,
        'شارع الجمهورية، مدينة نصر، القاهرة',
        true,
        NOW(),
        NOW()
    )
    RETURNING id INTO warehouse_id;

-- =============================================================================
-- 3. Five Products
-- =============================================================================
    -- Product 1: علف دواجن بادئ 25كجم
    INSERT INTO products (id, sku, name, name_en, category, unit, weight_kg, purchase_price, sale_price, wholesale_price, min_stock, current_stock, warehouse_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'SKU-001', 'علف دواجن بادئ 25كجم', 'Poultry Starter Feed 25kg', 'feed', 'bag', 25, 280.00, 350.00, 320.00, 100, 500,
        warehouse_id, true, NOW(), NOW()
    )
    RETURNING id INTO product1_id;

    -- Product 2: علف دواجن ناهي 25كجم
    INSERT INTO products (id, sku, name, name_en, category, unit, weight_kg, purchase_price, sale_price, wholesale_price, min_stock, current_stock, warehouse_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'SKU-002', 'علف دواجن ناهي 25كجم', 'Poultry Finisher Feed 25kg', 'feed', 'bag', 25, 270.00, 340.00, 310.00, 100, 450,
        warehouse_id, true, NOW(), NOW()
    )
    RETURNING id INTO product2_id;

    -- Product 3: ذرة صفراء
    INSERT INTO products (id, sku, name, name_en, category, unit, weight_kg, purchase_price, sale_price, wholesale_price, min_stock, current_stock, warehouse_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'SKU-003', 'ذرة صفراء', 'Yellow Corn', 'grain', 'ton', 1000, 8500.00, 9500.00, 9000.00, 10, 50,
        warehouse_id, true, NOW(), NOW()
    )
    RETURNING id INTO product3_id;

    -- Product 4: كسب فول صويا
    INSERT INTO products (id, sku, name, name_en, category, unit, weight_kg, purchase_price, sale_price, wholesale_price, min_stock, current_stock, warehouse_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'SKU-004', 'كسب فول صويا', 'Soybean Meal', 'protein', 'ton', 1000, 12000.00, 13500.00, 12800.00, 5, 25,
        warehouse_id, true, NOW(), NOW()
    )
    RETURNING id INTO product4_id;

    -- Product 5: ردة قمح
    INSERT INTO products (id, sku, name, name_en, category, unit, weight_kg, purchase_price, sale_price, wholesale_price, min_stock, current_stock, warehouse_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'SKU-005', 'ردة قمح', 'Wheat Bran', 'grain', 'ton', 1000, 4500.00, 5200.00, 4900.00, 15, 75,
        warehouse_id, true, NOW(), NOW()
    )
    RETURNING id INTO product5_id;

-- =============================================================================
-- 4. Three Customers
-- =============================================================================
    -- Customer 1: مزرعة النيل للدواجن
    INSERT INTO customers (id, name, name_en, type, phone, email, address, tax_number, credit_limit, balance, branch_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'مزرعة النيل للدواجن', 'Nile Poultry Farm', 'wholesale', '+20 100 123 4567', 'nile.poultry@email.com',
        'طريق مصر إسماعيلية الصحراوي، الكيلو 45', '123456789', 500000.00, 125000.00, cairo_branch_id, true, NOW(), NOW()
    )
    RETURNING id INTO customer1_id;

    -- Customer 2: شركة مصر للأعلاف
    INSERT INTO customers (id, name, name_en, type, phone, email, address, tax_number, credit_limit, balance, branch_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'شركة مصر للأعلاف', 'Misr Feed Company', 'corporate', '+20 2 2400 5678', 'info@misrfeed.com.eg',
        'المنطقة الصناعية الثالثة، العاشر من رمضان', '987654321', 1000000.00, 350000.00, cairo_branch_id, true, NOW(), NOW()
    )
    RETURNING id INTO customer2_id;

    -- Customer 3: مزارع الأمل
    INSERT INTO customers (id, name, name_en, type, phone, email, address, tax_number, credit_limit, balance, branch_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'مزارع الأمل', 'Amal Farms', 'retail', '+20 112 987 6543', 'amal.farms@email.com',
        'قرية النخيلة، مركز طامية، الفيوم', '456789123', 100000.00, 15000.00, cairo_branch_id, true, NOW(), NOW()
    )
    RETURNING id INTO customer3_id;

-- =============================================================================
-- 5. Two Suppliers
-- =============================================================================
    -- Supplier 1: شركة الدلتا للحبوب
    INSERT INTO suppliers (id, name, name_en, type, phone, email, address, tax_number, balance, branch_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'شركة الدلتا للحبوب', 'Delta Grains Company', 'supplier', '+20 40 234 5678', 'sales@deltagrains.com',
        'المنطقة الصناعية، دسوق، كفر الشيخ', '111222333', -200000.00, cairo_branch_id, true, NOW(), NOW()
    )
    RETURNING id INTO supplier1_id;

    -- Supplier 2: مصنع الشرق لصناعة الأعلاف
    INSERT INTO suppliers (id, name, name_en, type, phone, email, address, tax_number, balance, branch_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'مصنع الشرق لصناعة الأعلاف', 'Al Sharq Feed Factory', 'manufacturer', '+20 55 345 6789', 'export@sharqfeed.com',
        'المنطقة الصناعية الثانية، الدلنجات، البحيرة', '444555666', -450000.00, cairo_branch_id, true, NOW(), NOW()
    )
    RETURNING id INTO supplier2_id;

-- =============================================================================
-- 6. Two Drivers
-- =============================================================================
    -- Driver 1: أحمد سعيد
    INSERT INTO drivers (id, name, phone, license_number, license_expiry, national_id, address, is_active, branch_id, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'أحمد سعيد', '+20 100 234 5678', '12345678', '2026-06-15', '28512345678901',
        '15 شارع الجيش، مدينة نصر، القاهرة', true, cairo_branch_id, NOW(), NOW()
    )
    RETURNING id INTO driver1_id;

    -- Driver 2: محمد علي
    INSERT INTO drivers (id, name, phone, license_number, license_expiry, national_id, address, is_active, branch_id, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'محمد علي', '+20 112 345 6789', '87654321', '2027-03-20', '28898765432109',
        '8 شارع التحرير، الدقي، الجيزة', true, cairo_branch_id, NOW(), NOW()
    )
    RETURNING id INTO driver2_id;

-- =============================================================================
-- 7. Three Employees
-- =============================================================================
    -- Employee 1: مدير الفرع
    INSERT INTO employees (id, employee_code, name, email, phone, job_title, department, salary, hire_date, is_active, branch_id, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'EMP-001', 'خالد محمود إبراهيم', 'k.mahmoud@gff-erp.com', '+20 100 345 6789',
        'مدير الفرع', 'management', 15000.00, '2023-01-15', true, cairo_branch_id, NOW(), NOW()
    )
    RETURNING id INTO employee1_id;

    -- Employee 2: أمين المخزن
    INSERT INTO employees (id, employee_code, name, email, phone, job_title, department, salary, hire_date, is_active, branch_id, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'EMP-002', 'سيد عادل فؤاد', 's.adel@gff-erp.com', '+20 112 456 7890',
        'أمين المخزن', 'warehouse', 8000.00, '2023-03-01', true, cairo_branch_id, NOW(), NOW()
    )
    RETURNING id INTO employee2_id;

    -- Employee 3: مندوب مبيعات
    INSERT INTO employees (id, employee_code, name, email, phone, job_title, department, salary, hire_date, is_active, branch_id, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'EMP-003', 'عمر خالد سامي', 'o.khaled@gff-erp.com', '+20 100 567 8901',
        'مندوب مبيعات', 'sales', 6000.00, '2023-06-15', true, cairo_branch_id, NOW(), NOW()
    )
    RETURNING id INTO employee3_id;

-- =============================================================================
-- 8. One Vehicle
-- =============================================================================
    INSERT INTO vehicles (id, plate_number, type, brand, model, year, capacity_kg, driver_id, branch_id, is_active, created_at, updated_at)
    VALUES (
        gen_random_uuid(), 'ط أ ب 1234', 'van', ' Hyundai', 'H350', 2022, 3500,
        driver1_id, cairo_branch_id, true, NOW(), NOW()
    )
    RETURNING id INTO vehicle_id;

    -- Assign vehicle to driver
    UPDATE drivers SET vehicle_id = vehicle_id WHERE id = driver1_id;

-- =============================================================================
-- 9. Chart of Accounts
-- =============================================================================
    -- Assets
    INSERT INTO chart_of_accounts (id, code, name, name_en, type, parent_id, is_active, created_at, updated_at) VALUES
    (gen_random_uuid(), '1', 'الأصول', 'Assets', 'asset', NULL, true, NOW(), NOW());

    INSERT INTO chart_of_accounts (id, code, name, name_en, type, parent_code, is_active, created_at, updated_at) VALUES
    (gen_random_uuid(), '11', 'الأصول المتداولة', 'Current Assets', 'asset', '1', true, NOW(), NOW()),
    (gen_random_uuid(), '1101', 'النقدية', 'Cash', 'asset', '11', true, NOW(), NOW()),
    (gen_random_uuid(), '1102', 'البنك', 'Bank', 'asset', '11', true, NOW(), NOW()),
    (gen_random_uuid(), '1103', 'العملاء', 'Accounts Receivable', 'asset', '11', true, NOW(), NOW()),
    (gen_random_uuid(), '1104', 'مخزون السلع', 'Inventory', 'asset', '11', true, NOW(), NOW()),
    (gen_random_uuid(), '1105', 'مصروفات مدفوعة مقدماً', 'Prepaid Expenses', 'asset', '11', true, NOW(), NOW()),
    (gen_random_uuid(), '12', 'الأصول الثابتة', 'Fixed Assets', 'asset', '1', true, NOW(), NOW()),
    (gen_random_uuid(), '1201', 'الأراضي', 'Land', 'asset', '12', true, NOW(), NOW()),
    (gen_random_uuid(), '1202', 'المباني', 'Buildings', 'asset', '12', true, NOW(), NOW()),
    (gen_random_uuid(), '1203', 'السيارات', 'Vehicles', 'asset', '12', true, NOW(), NOW()),
    (gen_random_uuid(), '1204', 'الأجهزة والمعدات', 'Equipment', 'asset', '12', true, NOW(), NOW()),
    (gen_random_uuid(), '1205', 'مجمع الإهلاك', 'Accumulated Depreciation', 'asset', '12', true, NOW(), NOW());

    -- Liabilities
    INSERT INTO chart_of_accounts (id, code, name, name_en, type, parent_code, is_active, created_at, updated_at) VALUES
    (gen_random_uuid(), '2', 'الخصوم', 'Liabilities', 'liability', NULL, true, NOW(), NOW()),
    (gen_random_uuid(), '21', 'الخصوم المتداولة', 'Current Liabilities', 'liability', '2', true, NOW(), NOW()),
    (gen_random_uuid(), '2101', 'الموردون', 'Accounts Payable', 'liability', '21', true, NOW(), NOW()),
    (gen_random_uuid(), '2102', 'قروض قصيرة الأجل', 'Short-term Loans', 'liability', '21', true, NOW(), NOW()),
    (gen_random_uuid(), '2103', 'ضريبة القيمة المضافة', 'VAT Payable', 'liability', '21', true, NOW(), NOW()),
    (gen_random_uuid(), '2104', 'أجور مستحقة', 'Accrued Wages', 'liability', '21', true, NOW(), NOW()),
    (gen_random_uuid(), '22', 'الخصوم طويلة الأجل', 'Long-term Liabilities', 'liability', '2', true, NOW(), NOW()),
    (gen_random_uuid(), '2201', 'قروض طويلة الأجل', 'Long-term Loans', 'liability', '22', true, NOW(), NOW());

    -- Equity
    INSERT INTO chart_of_accounts (id, code, name, name_en, type, parent_code, is_active, created_at, updated_at) VALUES
    (gen_random_uuid(), '3', 'حقوق الملكية', 'Equity', 'equity', NULL, true, NOW(), NOW()),
    (gen_random_uuid(), '31', 'رأس المال', 'Capital', 'equity', '3', true, NOW(), NOW()),
    (gen_random_uuid(), '3101', 'رأس المال المدفوع', 'Paid-in Capital', 'equity', '31', true, NOW(), NOW()),
    (gen_random_uuid(), '32', 'الأرباح المحتجزة', 'Retained Earnings', 'equity', '3', true, NOW(), NOW()),
    (gen_random_uuid(), '3201', 'أرباح السنوات السابقة', 'Previous Years Profits', 'equity', '32', true, NOW(), NOW()),
    (gen_random_uuid(), '3202', 'أرباح السنة الحالية', 'Current Year Profits', 'equity', '32', true, NOW(), NOW());

    -- Revenue
    INSERT INTO chart_of_accounts (id, code, name, name_en, type, parent_code, is_active, created_at, updated_at) VALUES
    (gen_random_uuid(), '4', 'الإيرادات', 'Revenue', 'revenue', NULL, true, NOW(), NOW()),
    (gen_random_uuid(), '41', 'إيرادات المبيعات', 'Sales Revenue', 'revenue', '4', true, NOW(), NOW()),
    (gen_random_uuid(), '4101', 'مبيعات الأعلاف', 'Feed Sales', 'revenue', '41', true, NOW(), NOW()),
    (gen_random_uuid(), '4102', 'مبيعات الحبوب', 'Grain Sales', 'revenue', '41', true, NOW(), NOW()),
    (gen_random_uuid(), '42', 'إيرادات أخرى', 'Other Revenue', 'revenue', '4', true, NOW(), NOW()),
    (gen_random_uuid(), '4201', 'إيرادات النقل', 'Transport Revenue', 'revenue', '42', true, NOW(), NOW()),
    (gen_random_uuid(), '4202', 'إيرادات الخدمات', 'Service Revenue', 'revenue', '42', true, NOW(), NOW());

    -- Expenses
    INSERT INTO chart_of_accounts (id, code, name, name_en, type, parent_code, is_active, created_at, updated_at) VALUES
    (gen_random_uuid(), '5', 'المصروفات', 'Expenses', 'expense', NULL, true, NOW(), NOW()),
    (gen_random_uuid(), '51', 'تكلفة البضاعة المباعة', 'Cost of Goods Sold', 'expense', '5', true, NOW(), NOW()),
    (gen_random_uuid(), '5101', 'تكلفة الأعلاف المباعة', 'Cost of Feed Sold', 'expense', '51', true, NOW(), NOW()),
    (gen_random_uuid(), '5102', 'تكلفة الحبوب المباعة', 'Cost of Grain Sold', 'expense', '51', true, NOW(), NOW()),
    (gen_random_uuid(), '52', 'المصروفات التشغيلية', 'Operating Expenses', 'expense', '5', true, NOW(), NOW()),
    (gen_random_uuid(), '5201', 'مرتبات و wages', 'Salaries and Wages', 'expense', '52', true, NOW(), NOW()),
    (gen_random_uuid(), '5202', 'إيجارات', 'Rent', 'expense', '52', true, NOW(), NOW()),
    (gen_random_uuid(), '5203', 'كهرباء ومياه', 'Utilities', 'expense', '52', true, NOW(), NOW()),
    (gen_random_uuid(), '5204', 'صيانة', 'Maintenance', 'expense', '52', true, NOW(), NOW()),
    (gen_random_uuid(), '5205', 'وقود', 'Fuel', 'expense', '52', true, NOW(), NOW()),
    (gen_random_uuid(), '5206', 'إهلاك', 'Depreciation', 'expense', '52', true, NOW(), NOW()),
    (gen_random_uuid(), '53', 'المصروفات الإدارية', 'Administrative Expenses', 'expense', '5', true, NOW(), NOW()),
    (gen_random_uuid(), '5301', 'مصروفات مكتبية', 'Office Expenses', 'expense', '53', true, NOW(), NOW()),
    (gen_random_uuid(), '5302', 'مصروفات سفر', 'Travel Expenses', 'expense', '53', true, NOW(), NOW()),
    (gen_random_uuid(), '5303', 'اشتراكات', 'Subscriptions', 'expense', '53', true, NOW(), NOW()),
    (gen_random_uuid(), '54', 'المصروفات البيعية', 'Selling Expenses', 'expense', '5', true, NOW(), NOW()),
    (gen_random_uuid(), '5401', 'عمولات مبيعات', 'Sales Commissions', 'expense', '54', true, NOW(), NOW()),
    (gen_random_uuid(), '5402', 'دعاية وإعلان', 'Advertising', 'expense', '54', true, NOW(), NOW());

-- =============================================================================
-- 10. Initial Balances
-- =============================================================================
    -- Cash
    INSERT INTO account_balances (id, account_code, fiscal_year, opening_balance, current_balance, branch_id, created_at, updated_at)
    VALUES (gen_random_uuid(), '1101', 2024, 250000.00, 250000.00, cairo_branch_id, NOW(), NOW());

    -- Bank
    INSERT INTO account_balances (id, account_code, fiscal_year, opening_balance, current_balance, branch_id, created_at, updated_at)
    VALUES (gen_random_uuid(), '1102', 2024, 500000.00, 500000.00, cairo_branch_id, NOW(), NOW());

    -- Inventory
    INSERT INTO account_balances (id, account_code, fiscal_year, opening_balance, current_balance, branch_id, created_at, updated_at)
    VALUES (gen_random_uuid(), '1104', 2024, 875000.00, 875000.00, cairo_branch_id, NOW(), NOW());

    -- Paid-in Capital
    INSERT INTO account_balances (id, account_code, fiscal_year, opening_balance, current_balance, branch_id, created_at, updated_at)
    VALUES (gen_random_uuid(), '3101', 2024, 2000000.00, 2000000.00, cairo_branch_id, NOW(), NOW());

    -- Vehicles
    INSERT INTO account_balances (id, account_code, fiscal_year, opening_balance, current_balance, branch_id, created_at, updated_at)
    VALUES (gen_random_uuid(), '1203', 2024, 450000.00, 450000.00, cairo_branch_id, NOW(), NOW());

    -- Accounts Receivable (Customers)
    INSERT INTO account_balances (id, account_code, fiscal_year, opening_balance, current_balance, branch_id, created_at, updated_at)
    VALUES (gen_random_uuid(), '1103', 2024, 490000.00, 490000.00, cairo_branch_id, NOW(), NOW());

    -- Accounts Payable (Suppliers)
    INSERT INTO account_balances (id, account_code, fiscal_year, opening_balance, current_balance, branch_id, created_at, updated_at)
    VALUES (gen_random_uuid(), '2101', 2024, 650000.00, 650000.00, cairo_branch_id, NOW(), NOW());

-- =============================================================================
-- 11. Create Admin User
-- =============================================================================
    INSERT INTO users (id, email, password_hash, name, role, is_active, email_verified, branch_id, created_at, updated_at)
    VALUES (
        gen_random_uuid(),
        'admin@gff-erp.com',
        '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewKyNiAYMyzJ/I5K', -- admin123 (bcrypt)
        'مدير النظام',
        'admin',
        true,
        true,
        cairo_branch_id,
        NOW(),
        NOW()
    );

END $$;

COMMIT;

-- =============================================================================
-- Verification
-- =============================================================================
SELECT 'Pilot data seeded successfully!' AS status;
SELECT COUNT(*) AS branches FROM branches;
SELECT COUNT(*) AS warehouses FROM warehouses;
SELECT COUNT(*) AS products FROM products;
SELECT COUNT(*) AS customers FROM customers;
SELECT COUNT(*) AS suppliers FROM suppliers;
SELECT COUNT(*) AS drivers FROM drivers;
SELECT COUNT(*) AS employees FROM employees;
SELECT COUNT(*) AS vehicles FROM vehicles;
SELECT COUNT(*) AS accounts FROM chart_of_accounts;
SELECT COUNT(*) AS balances FROM account_balances;
SELECT COUNT(*) AS users FROM users;