# GFF ERP - Pilot Environment

One-command pilot deployment for the GFF ERP system.

## Requirements

- Ubuntu 22.04 LTS (or compatible)
- 4 CPU cores
- 16GB RAM
- 100GB SSD
- Internet access

## Quick Start

```bash
# 1. Clone the repository
git clone https://github.com/gff-erp/backend.git
cd backend

# 2. Run the setup script (as root)
sudo ./pilot/setup-pilot.sh
```

The setup script will:
1. Update system packages
2. Install Docker and Docker Compose
3. Configure the environment
4. Start all services
5. Seed pilot data
6. Run health checks

## Options

```bash
# Skip Docker installation (if already installed)
sudo ./pilot/setup-pilot.sh --skip-docker

# Include monitoring stack (Prometheus + Grafana)
sudo ./pilot/setup-pilot.sh --with-monitoring

# Only seed data (skip infrastructure setup)
sudo ./pilot/setup-pilot.sh --seed-only
```

## Access

After setup completes, access the application at:

| Service | URL |
|---------|-----|
| Frontend | http://YOUR-SERVER-IP |
| API | http://YOUR-SERVER-IP/api/v1 |
| Health | http://YOUR-SERVER-IP/api/v1/health |

Default admin credentials:
- Email: `admin@gff-erp.com`
- Password: `admin123`

## Management

```bash
# View logs
docker compose -f docker/docker-compose.prod.yml logs -f

# Check health
./pilot/health-check.sh

# Monitor continuously
./pilot/health-check.sh --watch

# Database shell
docker compose -f docker/docker-compose.prod.yml exec postgres psql -U gff_pilot -d gff_erp_pilot

# Restart services
docker compose -f docker/docker-compose.prod.yml restart

# Stop services
docker compose -f docker/docker-compose.prod.yml down

# Complete removal
./pilot/TEARDOWN.sh
```

## Pilot Data

The pilot environment includes:

- **1 Branch**: القاهرة الرئيسي
- **1 Warehouse**: مخزن القاهرة (1000 sqm)
- **5 Products**: Various poultry feeds and grains
- **3 Customers**: Mix of wholesale, corporate, and retail
- **2 Suppliers**: Grain company and feed factory
- **2 Drivers**: With license details
- **3 Employees**: Branch manager, warehouse keeper, sales rep
- **1 Vehicle**: Delivery van
- **Full Chart of Accounts**: Standard Egyptian accounting tree
- **Initial Balances**: Realistic opening balances

## Troubleshooting

**Services won't start**: Check `docker compose -f docker/docker-compose.prod.yml logs`

**Database connection failed**: Ensure postgres container is healthy: `docker compose -f docker/docker-compose.prod.yml ps`

**Port conflicts**: Ensure ports 80, 443, 3001-3003 are not in use

**Permission denied**: Run setup script with `sudo`

## Security Notes

- Change default passwords immediately after setup
- The `.env` file contains sensitive data - protect it
- Credentials are saved to `pilot/credentials.txt` (chmod 600)
- Firewall is configured to allow SSH, HTTP, and HTTPS only