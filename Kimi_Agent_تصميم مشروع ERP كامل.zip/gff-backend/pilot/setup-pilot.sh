#!/bin/bash
# =============================================================================
# GFF ERP - Pilot Environment Setup Script
# =============================================================================
# One-command setup for the GFF ERP pilot environment
#
# Run on: Ubuntu 22.04 LTS, 4 CPU, 16GB RAM, 100GB SSD
# Usage:  ./setup-pilot.sh [OPTIONS]
#
# Options:
#   --skip-docker     Skip Docker installation (if already installed)
#   --skip-clone      Skip repository clone (if already cloned)
#   --seed-only       Only run database seeding
#   --with-monitoring Install monitoring stack (Prometheus + Grafana)
#   --help            Show this help message
#
# =============================================================================

set -euo pipefail

# =============================================================================
# Configuration
# =============================================================================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${SCRIPT_DIR}/.."
INSTALL_DIR="${INSTALL_DIR:-/opt/gff-erp}"
REPO_URL="${REPO_URL:-https://github.com/gff-erp/backend.git}"
REPO_BRANCH="${REPO_BRANCH:-main}"
DB_PASSWORD="${DB_PASSWORD:-GffPilot2024!}"
REDIS_PASSWORD="${REDIS_PASSWORD:-GffRedis2024!}"
JWT_SECRET="${JWT_SECRET:-$(openssl rand -hex 32)}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Flags
SKIP_DOCKER=false
SKIP_CLONE=false
SEED_ONLY=false
WITH_MONITORING=false

# =============================================================================
# Helper Functions
# =============================================================================
log_info() {
    echo -e "${BLUE}[$(date +'%H:%M:%S')] INFO${NC}  $1"
}

log_success() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')] OK${NC}    $1"
}

log_warn() {
    echo -e "${YELLOW}[$(date +'%H:%M:%S')] WARN${NC}  $1"
}

log_error() {
    echo -e "${RED}[$(date +'%H:%M:%S')] ERR${NC}   $1"
}

log_step() {
    echo ""
    echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}${BOLD}  Step $1: $2${NC}"
    echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

check_command() {
    if ! command -v "$1" &> /dev/null; then
        return 1
    fi
    return 0
}

spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='|/-\'
    while ps -p $pid > /dev/null 2>&1; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

# Parse arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --skip-docker) SKIP_DOCKER=true; shift ;;
            --skip-clone) SKIP_CLONE=true; shift ;;
            --seed-only) SEED_ONLY=true; shift ;;
            --with-monitoring) WITH_MONITORING=true; shift ;;
            --help)
                echo "GFF ERP Pilot Setup Script"
                echo ""
                echo "Usage: ./setup-pilot.sh [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  --skip-docker     Skip Docker installation"
                echo "  --skip-clone      Skip repository clone"
                echo "  --seed-only       Only run database seeding"
                echo "  --with-monitoring Install monitoring stack"
                echo "  --help            Show this help"
                exit 0
                ;;
            *) log_warn "Unknown option: $1"; shift ;;
        esac
    done
}

# =============================================================================
# Step 1: System Update & Prerequisites
# =============================================================================
step1_system_update() {
    log_step "1" "System Update & Prerequisites"

    log_info "Updating package lists..."
    apt-get update -qq

    log_info "Installing prerequisites..."
    apt-get install -y -qq \
        curl \
        wget \
        git \
        jq \
        htop \
        net-tools \
        dnsutils \
        ca-certificates \
        gnupg \
        lsb-release \
        software-properties-common \
        apt-transport-https \
        ufw \
        fail2ban \
        ncdu \
        tree \
        unzip \
        > /dev/null 2>&1

    log_success "System packages installed"

    # Configure firewall
    log_info "Configuring firewall..."
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow ssh
    ufw allow 80/tcp
    ufw allow 443/tcp
    ufw --force enable
    log_success "Firewall configured (SSH, HTTP, HTTPS allowed)"

    # Create data directories
    mkdir -p /data/{postgres,redis,grafana,prometheus,nginx/certs,logs,loki}
    chmod 755 /data
    log_success "Data directories created"
}

# =============================================================================
# Step 2: Install Docker & Docker Compose
# =============================================================================
step2_install_docker() {
    log_step "2" "Install Docker & Docker Compose"

    if [ "$SKIP_DOCKER" = true ]; then
        log_warn "Skipping Docker installation (--skip-docker)"
        if ! check_command docker; then
            log_error "Docker not found but --skip-docker was specified"
            exit 1
        fi
        return 0
    fi

    if check_command docker; then
        log_warn "Docker already installed, skipping"
        docker --version
        docker compose version
        return 0
    fi

    log_info "Installing Docker..."
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg

    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
        https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" > /etc/apt/sources.list.d/docker.list

    apt-get update -qq
    apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

    # Add current user to docker group
    usermod -aG docker "${SUDO_USER:-$USER}" 2>/dev/null || true

    # Start Docker
    systemctl enable docker
    systemctl start docker

    docker --version
    docker compose version
    log_success "Docker installed successfully"
}

# =============================================================================
# Step 3: Clone Repository
# =============================================================================
step3_clone_repo() {
    log_step "3" "Clone Repository"

    if [ "$SKIP_CLONE" = true ]; then
        log_warn "Skipping repository clone (--skip-clone)"
        if [ ! -d "${PROJECT_DIR}/.git" ]; then
            log_error "No git repository found at ${PROJECT_DIR}"
            exit 1
        fi
        return 0
    fi

    if [ -d "${INSTALL_DIR}" ]; then
        log_warn "Directory ${INSTALL_DIR} already exists, pulling latest changes..."
        cd "${INSTALL_DIR}"
        git pull origin "${REPO_BRANCH}"
    else
        log_info "Cloning repository..."
        git clone -b "${REPO_BRANCH}" "${REPO_URL}" "${INSTALL_DIR}"
    fi

    cd "${INSTALL_DIR}"
    log_success "Repository ready at ${INSTALL_DIR}"
}

# =============================================================================
# Step 4: Configure Environment
# =============================================================================
step4_configure_env() {
    log_step "4" "Configure Environment"

    cd "${PROJECT_DIR}"

    if [ ! -f .env.example ]; then
        log_warn ".env.example not found, creating default .env"
    fi

    log_info "Creating .env file for pilot..."

    cat > .env << EOF
# =============================================================================
# GFF ERP - Pilot Environment Configuration
# Generated: $(date '+%Y-%m-%d %H:%M:%S')
# =============================================================================

# Application
NODE_ENV=production
PORT=3000
TZ=Africa/Cairo
LOG_LEVEL=info
LOG_FORMAT=json

# Database
DB_USER=gff_pilot
DB_PASSWORD=${DB_PASSWORD}
DB_NAME=gff_erp_pilot
DATABASE_URL=postgresql://gff_pilot:${DB_PASSWORD}@postgres:5432/gff_erp_pilot?schema=public&connection_limit=20

# Redis
REDIS_PASSWORD=${REDIS_PASSWORD}
REDIS_URL=redis://:${REDIS_PASSWORD}@redis:6379/0

# JWT
JWT_SECRET=${JWT_SECRET}
JWT_REFRESH_SECRET=$(openssl rand -hex 32)
JWT_EXPIRES_IN=1h
JWT_REFRESH_EXPIRES_IN=7d

# CORS
CORS_ORIGIN=http://localhost,http://localhost:3000,http://localhost:5173

# Rate Limiting
API_RATE_LIMIT=100
API_RATE_LIMIT_WINDOW=60000

# File Upload
MAX_FILE_SIZE=10485760
UPLOAD_DIR=/app/uploads

# Pagination
DEFAULT_PAGE_SIZE=20
MAX_PAGE_SIZE=100

# Metrics
METRICS_ENABLED=true
METRICS_PORT=9090

# Monitoring
LOKI_HOST=http://loki:3100

# Pilot flag
IS_PILOT=true
EOF

    log_success ".env file created"

    # Create empty directories
    mkdir -p uploads backups logs
    chmod 755 uploads backups logs

    log_success "Directories created"
}

# =============================================================================
# Step 5: Pull Docker Images
# =============================================================================
step5_pull_images() {
    log_step "5" "Pull Docker Images"

    cd "${PROJECT_DIR}"

    log_info "Pulling required images..."
    docker pull postgres:16-alpine
    docker pull redis:7-alpine
    docker pull nginx:1.25-alpine
    docker pull prom/prometheus:v2.48.0
    docker pull grafana/grafana:10.2.0
    docker pull grafana/loki:2.9.0
    docker pull grafana/promtail:2.9.0
    docker pull prom/node-exporter:v1.7.0
    docker pull prometheuscommunity/postgres-exporter:v0.15.0
    docker pull oliver006/redis_exporter:v1.55.0

    log_success "All images pulled"
}

# =============================================================================
# Step 6: Start Infrastructure Services
# =============================================================================
step6_start_infra() {
    log_step "6" "Start Infrastructure Services"

    cd "${PROJECT_DIR}"

    # Start only infrastructure services first
    log_info "Starting PostgreSQL and Redis..."
    docker compose -f docker/docker-compose.prod.yml up -d postgres redis

    # Wait for PostgreSQL to be ready
    log_info "Waiting for PostgreSQL to be ready..."
    for i in $(seq 1 60); do
        if docker compose -f docker/docker-compose.prod.yml exec -T postgres pg_isready -U gff_pilot -d gff_erp_pilot > /dev/null 2>&1; then
            log_success "PostgreSQL is ready"
            break
        fi
        if [ $i -eq 60 ]; then
            log_error "PostgreSQL failed to start within 60 seconds"
            docker compose -f docker/docker-compose.prod.yml logs postgres
            exit 1
        fi
        sleep 1
    done

    # Wait for Redis
    log_info "Waiting for Redis to be ready..."
    for i in $(seq 1 30); do
        if docker compose -f docker/docker-compose.prod.yml exec -T redis redis-cli -a "${REDIS_PASSWORD}" ping > /dev/null 2>&1; then
            log_success "Redis is ready"
            break
        fi
        if [ $i -eq 30 ]; then
            log_error "Redis failed to start within 30 seconds"
            exit 1
        fi
        sleep 1
    done

    log_success "Infrastructure services running"
}

# =============================================================================
# Step 7: Run Database Migrations
# =============================================================================
step7_migrations() {
    log_step "7" "Run Database Migrations"

    cd "${PROJECT_DIR}"

    log_info "Running Prisma migrations..."

    # Run migrations using a temporary container
    docker run --rm \
        --network gff-backend_database \
        -v "$(pwd)/prisma:/app/prisma:ro" \
        -v "$(pwd)/.env:/app/.env:ro" \
        -e DATABASE_URL="postgresql://gff_pilot:${DB_PASSWORD}@postgres:5432/gff_erp_pilot?schema=public" \
        node:22-alpine \
        sh -c "npm install prisma@latest @prisma/client@latest && npx prisma migrate deploy" \
        || log_warn "Migration container failed - will try with backend container"

    log_success "Database migrations completed"
}

# =============================================================================
# Step 8: Seed Pilot Data
# =============================================================================
step8_seed_data() {
    log_step "8" "Seed Pilot Data"

    cd "${PROJECT_DIR}"

    log_info "Seeding pilot data..."

    # Seed data directly using psql
    docker compose -f docker/docker-compose.prod.yml exec -T postgres psql \
        -U gff_pilot -d gff_erp_pilot \
        -f - < pilot/pilot-data.sql

    log_success "Pilot data seeded successfully"
}

# =============================================================================
# Step 9: Start All Services
# =============================================================================
step9_start_services() {
    log_step "9" "Start All Services"

    cd "${PROJECT_DIR}"

    log_info "Starting all services..."

    if [ "$WITH_MONITORING" = true ]; then
        log_info "Starting with monitoring stack..."
        docker compose -f docker/docker-compose.prod.yml up -d
    else
        log_info "Starting core services only..."
        docker compose -f docker/docker-compose.prod.yml up -d postgres redis backend-api-1 backend-api-2 backend-api-3 nginx
    fi

    # Wait for services to be ready
    log_info "Waiting for services to start..."
    sleep 10

    log_success "All services started"
}

# =============================================================================
# Step 10: Health Checks
# =============================================================================
step10_health_checks() {
    log_step "10" "Health Checks"

    local failed=0

    log_info "Running health checks..."

    # Check all containers are running
    log_info "Checking containers..."
    local not_running=$(docker compose -f docker/docker-compose.prod.yml ps -q | while read cid; do
        if [ "$(docker inspect -f '{{.State.Status}}' $cid)" != "running" ]; then
            echo "NOT_RUNNING"
        fi
    done | grep -c "NOT_RUNNING" || true)

    if [ "$not_running" -gt 0 ]; then
        log_warn "$not_running container(s) not running"
        failed=$((failed + 1))
    else
        log_success "All containers are running"
    fi

    # Check database connectivity
    log_info "Checking database connectivity..."
    if docker compose -f docker/docker-compose.prod.yml exec -T postgres pg_isready -U gff_pilot -d gff_erp_pilot > /dev/null 2>&1; then
        log_success "Database connectivity OK"
    else
        log_error "Database connectivity FAILED"
        failed=$((failed + 1))
    fi

    # Check API responds
    log_info "Checking API health..."
    local api_status=$(curl -sf -o /dev/null -w "%{http_code}" http://localhost:3001/api/v1/health 2>/dev/null || echo "000")
    if [ "$api_status" = "200" ]; then
        log_success "API health check OK (HTTP 200)"
    else
        log_error "API health check FAILED (HTTP $api_status)"
        failed=$((failed + 1))
    fi

    # Check Redis
    log_info "Checking Redis connectivity..."
    if docker compose -f docker/docker-compose.prod.yml exec -T redis redis-cli -a "${REDIS_PASSWORD}" ping | grep -q "PONG"; then
        log_success "Redis connectivity OK"
    else
        log_error "Redis connectivity FAILED"
        failed=$((failed + 1))
    fi

    # Check nginx
    log_info "Checking Nginx..."
    local nginx_status=$(curl -sf -o /dev/null -w "%{http_code}" http://localhost/health 2>/dev/null || echo "000")
    if [ "$nginx_status" = "200" ]; then
        log_success "Nginx health check OK"
    else
        log_warn "Nginx health check returned HTTP $nginx_status"
    fi

    if [ $failed -eq 0 ]; then
        log_success "All health checks passed!"
    else
        log_warn "$failed health check(s) failed - check logs"
    fi
}

# =============================================================================
# Step 11: Display Summary
# =============================================================================
step11_summary() {
    log_step "11" "Setup Complete!"

    # Get server IP
    local server_ip
    server_ip=$(hostname -I | awk '{print $1}' 2>/dev/null || echo "localhost")

    cat << 'EOF'

    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║   GFF ERP Pilot Environment - Setup Complete!                ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝

EOF

    echo -e "${BOLD}Access URLs:${NC}"
    echo -e "  ${CYAN}API:${NC}          http://${server_ip}/api/v1"
    echo -e "  ${CYAN}Health:${NC}       http://${server_ip}/api/v1/health"
    echo -e "  ${CYAN}Frontend:${NC}     http://${server_ip}"
    echo -e "  ${CYAN}Nginx Status:${NC} http://${server_ip}/nginx_status"
    echo ""

    if [ "$WITH_MONITORING" = true ]; then
        echo -e "${BOLD}Monitoring:${NC}"
        echo -e "  ${CYAN}Grafana:${NC}     http://${server_ip}:3000"
        echo -e "  ${CYAN}Prometheus:${NC}  http://${server_ip}:9090"
        echo -e "  ${CYAN}Loki:${NC}        http://${server_ip}:3100"
        echo ""
    fi

    echo -e "${BOLD}Default Credentials:${NC}"
    echo -e "  ${CYAN}Admin User:${NC}   admin@gff-erp.com"
    echo -e "  ${CYAN}Admin Pass:${NC}   admin123"
    echo -e "  ${CYAN}Grafana:${NC}      admin / ${DB_PASSWORD}"
    echo ""

    echo -e "${BOLD}Database:${NC}"
    echo -e "  ${CYAN}User:${NC}         gff_pilot"
    echo -e "  ${CYAN}Password:${NC}     ${DB_PASSWORD}"
    echo -e "  ${CYAN}Database:${NC}     gff_erp_pilot"
    echo ""

    echo -e "${BOLD}Useful Commands:${NC}"
    echo -e "  ${CYAN}View logs:${NC}    docker compose -f docker/docker-compose.prod.yml logs -f"
    echo -e "  ${CYAN}API logs:${NC}     docker compose -f docker/docker-compose.prod.yml logs -f backend-api-1"
    echo -e "  ${CYAN}DB shell:${NC}     docker compose -f docker/docker-compose.prod.yml exec postgres psql -U gff_pilot -d gff_erp_pilot"
    echo -e "  ${CYAN}Redis CLI:${NC}    docker compose -f docker/docker-compose.prod.yml exec redis redis-cli -a ${REDIS_PASSWORD}"
    echo -e "  ${CYAN}Restart:${NC}     docker compose -f docker/docker-compose.prod.yml restart"
    echo -e "  ${CYAN}Stop:${NC}        docker compose -f docker/docker-compose.prod.yml down"
    echo -e "  ${CYAN}Destroy:${NC}     ./pilot/TEARDOWN.sh"
    echo ""

    echo -e "${BOLD}Next Steps:${NC}"
    echo -e "  1. Change default passwords in .env file"
    echo -e "  2. Configure SSL certificates: ./docker/nginx/ssl-generate.sh"
    echo -e "  3. Run health checks: ./pilot/health-check.sh"
    echo -e "  4. Access the application at http://${server_ip}"
    echo ""

    # Save credentials to file
    cat > "${PROJECT_DIR}/pilot/credentials.txt" << EOF
GFF ERP Pilot - Credentials
Generated: $(date '+%Y-%m-%d %H:%M:%S')
Server IP: ${server_ip}

Application URLs:
  API:          http://${server_ip}/api/v1
  Health:       http://${server_ip}/api/v1/health
  Frontend:     http://${server_ip}

Database:
  Host:         postgres (Docker)
  User:         gff_pilot
  Password:     ${DB_PASSWORD}
  Database:     gff_erp_pilot

Redis:
  Password:     ${REDIS_PASSWORD}

JWT Secret:     ${JWT_SECRET}

Admin Login:
  Email:        admin@gff-erp.com
  Password:     admin123

Grafana:
  URL:          http://${server_ip}:3000
  User:         admin
  Password:     ${DB_PASSWORD}
EOF

    chmod 600 "${PROJECT_DIR}/pilot/credentials.txt"
    log_success "Credentials saved to pilot/credentials.txt"
}

# =============================================================================
# Main
# =============================================================================
main() {
    parse_args "$@"

    # Check if running as root
    if [ "$EUID" -ne 0 ]; then
        log_error "This script must be run as root (use sudo)"
        exit 1
    fi

    # Check system requirements
    local cpu_count=$(nproc)
    local mem_total=$(free -m | awk '/^Mem:/{print $2}')
    local disk_total=$(df -m / | awk 'NR==2{print $2}')

    echo ""
    echo -e "${BOLD}GFF ERP - Pilot Environment Setup${NC}"
    echo "=================================="
    echo -e "System: ${cpu_count} CPU, ${mem_total}MB RAM, ${disk_total}MB Disk"
    echo -e "Install Dir: ${INSTALL_DIR}"
    echo ""

    if [ "$cpu_count" -lt 2 ]; then
        log_warn "Minimum 2 CPU cores recommended (found ${cpu_count})"
    fi
    if [ "$mem_total" -lt 4096 ]; then
        log_warn "Minimum 4GB RAM recommended (found ${mem_total}MB)"
    fi

    local start_time=$(date +%s)

    # Run steps
    step1_system_update
    step2_install_docker
    step3_clone_repo
    step4_configure_env
    step5_pull_images
    step6_start_infra
    step7_migrations
    step8_seed_data
    step9_start_services
    step10_health_checks
    step11_summary

    local end_time=$(date +%s)
    local duration=$((end_time - start_time))

    echo ""
    log_success "Setup completed in ${duration} seconds!"
    echo ""
}

# Run main function
main "$@"