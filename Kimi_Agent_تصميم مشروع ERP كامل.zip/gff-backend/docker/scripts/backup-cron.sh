#!/bin/bash
# =============================================================================
# GFF ERP - Automated PostgreSQL Backup Script
# =============================================================================
# Run by cron daily at 2:00 AM
# Retention: 30 days
# Uploads to S3 if configured
# =============================================================================

set -euo pipefail

# Configuration
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
DATE=$(date +"%Y-%m-%d")
BACKUP_DIR="${BACKUP_DIR:-/backups}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
S3_BUCKET="${S3_BUCKET:-}"
AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-}"
AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-}"

# Database credentials from environment
PGHOST="${PGHOST:-postgres}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-gff_user}"
PGPASSWORD="${PGPASSWORD:-changeme}"
PGDATABASE="${PGDATABASE:-gff_erp}"

# Colors (if terminal)
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] [INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] [SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] [WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] [ERROR]${NC} $1"
}

# Create backup directory
mkdir -p "${BACKUP_DIR}"

# =============================================================================
# Full Database Backup
# =============================================================================
log_info "Starting PostgreSQL backup for database: ${PGDATABASE}"

BACKUP_FILE="${BACKUP_DIR}/gff_erp_${TIMESTAMP}.sql.gz"

# Run pg_dump with compression
PGPASSWORD="${PGPASSWORD}" pg_dump \
    -h "${PGHOST}" \
    -p "${PGPORT}" \
    -U "${PGUSER}" \
    -d "${PGDATABASE}" \
    --verbose \
    --no-owner \
    --no-privileges \
    --encoding=UTF8 \
    --format=plain \
    2>>"${BACKUP_DIR}/backup_${TIMESTAMP}.log" | \
    gzip -9 > "${BACKUP_FILE}"

if [ ${PIPESTATUS[0]} -eq 0 ]; then
    BACKUP_SIZE=$(du -h "${BACKUP_FILE}" | cut -f1)
    log_success "Backup completed: ${BACKUP_FILE} (${BACKUP_SIZE})"
else
    log_error "Backup failed! Check ${BACKUP_DIR}/backup_${TIMESTAMP}.log"
    exit 1
fi

# =============================================================================
# Calculate checksum
# =============================================================================
CHECKSUM_FILE="${BACKUP_FILE}.sha256"
sha256sum "${BACKUP_FILE}" > "${CHECKSUM_FILE}"
log_success "Checksum: $(cat ${CHECKSUM_FILE} | cut -d' ' -f1)"

# =============================================================================
# Upload to S3 (if configured)
# =============================================================================
if [ -n "${S3_BUCKET}" ] && [ -n "${AWS_ACCESS_KEY_ID}" ] && [ -n "${AWS_SECRET_ACCESS_KEY}" ]; then
    log_info "Uploading backup to S3: ${S3_BUCKET}"
    
    # Check if AWS CLI is available
    if command -v aws &> /dev/null; then
        aws s3 cp "${BACKUP_FILE}" "s3://${S3_BUCKET}/backups/$(basename ${BACKUP_FILE})" \
            --storage-class STANDARD_IA
        aws s3 cp "${CHECKSUM_FILE}" "s3://${S3_BUCKET}/backups/$(basename ${CHECKSUM_FILE})"
        log_success "Backup uploaded to S3"
    else
        log_warn "AWS CLI not available, skipping S3 upload"
    fi
else
    log_info "S3 not configured, skipping upload"
fi

# =============================================================================
# Clean up old backups
# =============================================================================
log_info "Cleaning up backups older than ${RETENTION_DAYS} days..."

# Local cleanup
DELETED_COUNT=$(find "${BACKUP_DIR}" -name "gff_erp_*.sql.gz" -type f -mtime +${RETENTION_DAYS} | wc -l)
find "${BACKUP_DIR}" -name "gff_erp_*.sql.gz" -type f -mtime +${RETENTION_DAYS} -delete
find "${BACKUP_DIR}" -name "gff_erp_*.sql.gz.sha256" -type f -mtime +${RETENTION_DAYS} -delete
find "${BACKUP_DIR}" -name "backup_*.log" -type f -mtime +${RETENTION_DAYS} -delete

log_success "Deleted ${DELETED_COUNT} old local backup(s)"

# S3 cleanup
if [ -n "${S3_BUCKET}" ] && command -v aws &> /dev/null; then
    log_info "Cleaning up old S3 backups..."
    CUTOFF_DATE=$(date -d "-${RETENTION_DAYS} days" +%Y-%m-%d 2>/dev/null || date -v-${RETENTION_DAYS}d +%Y-%m-%d)
    
    aws s3 ls "s3://${S3_BUCKET}/backups/" | while read -r line; do
        FILE_DATE=$(echo "$line" | awk '{print $1}')
        FILE_NAME=$(echo "$line" | awk '{print $4}')
        if [[ "$FILE_DATE" < "$CUTOFF_DATE" ]]; then
            aws s3 rm "s3://${S3_BUCKET}/backups/${FILE_NAME}" --quiet
            log_info "Deleted from S3: ${FILE_NAME}"
        fi
    done
    log_success "S3 cleanup completed"
fi

# =============================================================================
# Summary
# =============================================================================
log_success "Backup process completed successfully!"
echo "========================================"
echo "Backup Summary:"
echo "  Database: ${PGDATABASE}"
echo "  File: ${BACKUP_FILE}"
echo "  Size: ${BACKUP_SIZE}"
echo "  Checksum: $(cat ${CHECKSUM_FILE} | cut -d' ' -f1)"
echo "  Retention: ${RETENTION_DAYS} days"
if [ -n "${S3_BUCKET}" ]; then
    echo "  S3 Bucket: ${S3_BUCKET}"
fi
echo "========================================"