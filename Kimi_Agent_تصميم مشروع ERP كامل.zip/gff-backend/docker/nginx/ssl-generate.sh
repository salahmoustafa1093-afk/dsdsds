#!/bin/bash
# =============================================================================
# GFF ERP - Let's Encrypt SSL Certificate Generation Script
# =============================================================================
# Usage:
#   ./ssl-generate.sh [staging|production]
#
#   staging    - Use Let's Encrypt staging server (for testing)
#   production - Use Let's Encrypt production server (default)
#
# Requirements:
#   - Docker installed and running
#   - Domain DNS records pointing to this server
#   - Ports 80 and 443 accessible from the internet
#
# Domains:
#   - gff-erp.com
#   - www.gff-erp.com
#   - monitoring.gff-erp.com
# =============================================================================

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOMAIN="gff-erp.com"
DOMAINS=("gff-erp.com" "www.gff-erp.com" "monitoring.gff-erp.com")
EMAIL="admin@gff-erp.com"
ENVIRONMENT="${1:-production}"
CERT_DIR="/data/nginx/certs"
WEBROOT="/var/www/certbot"

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   log_error "This script must be run as root (use sudo)"
   exit 1
fi

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    log_error "Docker is not installed. Please install Docker first."
    exit 1
fi

log_info "Starting SSL certificate generation for GFF ERP"
log_info "Environment: ${ENVIRONMENT}"
log_info "Domains: ${DOMAINS[*]}"

# Create necessary directories
mkdir -p "${CERT_DIR}/live/${DOMAIN}"
mkdir -p "${WEBROOT}"
mkdir -p "${CERT_DIR}/renewal-hooks/deploy"

# Determine ACME server URL
if [[ "${ENVIRONMENT}" == "staging" ]]; then
    ACME_URL="https://acme-staging-v02.api.letsencrypt.org/directory"
    log_warn "Using Let's Encrypt STAGING server"
    log_warn "Certificates from staging will NOT be trusted by browsers"
else
    ACME_URL="https://acme-v02.api.letsencrypt.org/directory"
    log_info "Using Let's Encrypt PRODUCTION server"
fi

# Generate strong DH parameters if not exists
if [[ ! -f "${CERT_DIR}/ssl-dhparams.pem" ]]; then
    log_info "Generating DH parameters (this may take a while)..."
    openssl dhparam -out "${CERT_DIR}/ssl-dhparams.pem" 2048
    log_success "DH parameters generated"
fi

# Create a temporary Nginx config for ACME challenge
log_info "Setting up temporary Nginx for ACME challenge..."

cat > "${SCRIPT_DIR}/conf.d/acme-challenge.conf" << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name _;
    
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
        try_files $uri =404;
    }
    
    location / {
        return 301 https://$host$request_uri;
    }
}
EOF

# Check if Nginx container is running, if not start a temporary one
if docker ps -q -f name=gff-nginx | grep -q .; then
    log_info "Reloading Nginx configuration..."
    docker exec gff-nginx nginx -s reload
else
    log_info "Starting temporary Nginx for ACME challenge..."
    docker run -d --name nginx-acme-temp \
        -p 80:80 \
        -v "${WEBROOT}:${WEBROOT}" \
        -v "${SCRIPT_DIR}/conf.d:/etc/nginx/conf.d:ro" \
        nginx:1.25-alpine &> /dev/null || true
fi

# Build domain arguments for certbot
DOMAIN_ARGS=""
for d in "${DOMAINS[@]}"; do
    DOMAIN_ARGS="${DOMAIN_ARGS} -d ${d}"
done

# Run certbot
log_info "Requesting certificates from Let's Encrypt..."
docker run --rm \
    -v "${CERT_DIR}/etc/letsencrypt:/etc/letsencrypt" \
    -v "${CERT_DIR}/var/lib/letsencrypt:/var/lib/letsencrypt" \
    -v "${WEBROOT}:${WEBROOT}" \
    certbot/certbot:latest certonly \
    --webroot \
    --webroot-path "${WEBROOT}" \
    --agree-tos \
    --no-eff-email \
    --email "${EMAIL}" \
    --server "${ACME_URL}" \
    --non-interactive \
    --expand \
    ${DOMAIN_ARGS}

# Create a deployment hook for certificate renewal
cat > "${CERT_DIR}/renewal-hooks/deploy/01-reload-nginx.sh" << 'EOF'
#!/bin/bash
# Reload Nginx after certificate renewal
if docker ps -q -f name=gff-nginx | grep -q .; then
    echo "Reloading Nginx after certificate renewal..."
    docker exec gff-nginx nginx -s reload
    echo "Nginx reloaded successfully"
else
    echo "Nginx container not running, skipping reload"
fi
EOF
chmod +x "${CERT_DIR}/renewal-hooks/deploy/01-reload-nginx.sh"

# Create cron job for auto-renewal
log_info "Setting up automatic certificate renewal..."
CRON_JOB="0 3 * * * root docker run --rm -v ${CERT_DIR}/etc/letsencrypt:/etc/letsencrypt -v ${CERT_DIR}/var/lib/letsencrypt:/var/lib/letsencrypt -v ${WEBROOT}:${WEBROOT} certbot/certbot:latest renew --quiet --deploy-hook '${CERT_DIR}/renewal-hooks/deploy/01-reload-nginx.sh' >> /var/log/letsencrypt-renewal.log 2>&1"

if ! grep -q "certbot/certbot" /etc/crontab 2>/dev/null; then
    echo "${CRON_JOB}" >> /etc/crontab
    log_success "Certificate renewal cron job added to /etc/crontab"
else
    log_warn "Certificate renewal cron job already exists"
fi

# Clean up temporary Nginx
docker rm -f nginx-acme-temp &> /dev/null || true
rm -f "${SCRIPT_DIR}/conf.d/acme-challenge.conf"

# Verify certificates
log_info "Verifying certificates..."
for d in "${DOMAINS[@]}"; do
    CERT_PATH="${CERT_DIR}/etc/letsencrypt/live/${d}/fullchain.pem"
    if [[ -f "${CERT_PATH}" ]]; then
        CERT_INFO=$(openssl x509 -in "${CERT_PATH}" -noout -subject -dates -issuer 2>/dev/null)
        log_success "Certificate for ${d}:"
        echo "  ${CERT_INFO}" | while read -r line; do echo "  ${line}"; done
    else
        # Check if the certificate is under the primary domain
        CERT_PATH="${CERT_DIR}/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
        if [[ -f "${CERT_PATH}" ]]; then
            CERT_DOMAINS=$(openssl x509 -in "${CERT_PATH}" -noout -text 2>/dev/null | grep -A1 "Subject Alternative Name" | tail -1)
            if echo "${CERT_DOMAINS}" | grep -q "${d}"; then
                log_success "Certificate for ${d} (SAN in ${DOMAIN} certificate)"
            fi
        fi
    fi
done

# Create symlinks for Nginx
log_info "Setting up certificate symlinks..."
mkdir -p "/etc/letsencrypt/live/${DOMAIN}" 2>/dev/null || true

log_success "SSL certificate generation completed!"
echo ""
echo "========================================"
echo "Certificate Details:"
echo "  Primary Domain: ${DOMAIN}"
echo "  SAN Domains: ${DOMAINS[*]}"
echo "  Certificate Path: ${CERT_DIR}/etc/letsencrypt/live/${DOMAIN}/"
echo "  Email: ${EMAIL}"
echo "  Environment: ${ENVIRONMENT}"
echo "  Auto-renewal: Daily at 3:00 AM"
echo "========================================"
echo ""

if [[ "${ENVIRONMENT}" == "staging" ]]; then
    log_warn "IMPORTANT: You are using STAGING certificates"
    log_warn "Run './ssl-generate.sh production' for production certificates"
    echo ""
    log_info "To get production certificates:"
    echo "  1. Test that everything works with staging certificates"
    echo "  2. Remove staging certificates: rm -rf ${CERT_DIR}/etc/letsencrypt/live/${DOMAIN}"
    echo "  3. Run: ./ssl-generate.sh production"
fi

# Verify certificate with OpenSSL
log_info "Testing certificate..."
if command -v openssl &> /dev/null; then
    CERT_PATH="${CERT_DIR}/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
    if [[ -f "${CERT_PATH}" ]]; then
        openssl x509 -in "${CERT_PATH}" -noout -text 2>/dev/null | grep -E "Subject:|Issuer:|Not Before|Not After|DNS:" | while read -r line; do
            echo "  ${line}"
        done
    fi
fi

log_success "SSL setup complete! You can now start the full stack with:"
echo "  docker compose -f docker/docker-compose.prod.yml up -d"
