# GFF Backend Refactor Plan

## Source of Truth
`prisma/schema.prisma` — 56 models, 32 enums, 1608 lines. The ONLY reference.

## Error Distribution (Original ~796 errors)
| Module | Errors | File |
|--------|--------|------|
| accounting | 100 | src/accounting/accounting.service.ts |
| purchases | 77 | src/purchases/purchases.service.ts |
| inventory | 48 | src/inventory/inventory.service.ts |
| production | 44 | src/production/production.service.ts |
| feed | 36 | src/feed/feed.service.ts |
| reports | 34 | src/reports/reports.service.ts |
| sales | 30 | src/sales/sales.service.ts |
| hr | 27 | src/hr/hr.service.ts |
| products | 25 | src/products/products.service.ts |
| delivery | 23 | src/delivery/delivery.service.ts |

## Approach
Module-by-module rewrite. Each agent:
1. Reads schema.prisma relevant models
2. Reads current service file
3. Rewrites service + DTOs against schema
4. Commits changes
5. Returns error count

## Batch 1: Accounting (100 errors) — CRITICAL PATH
Rewrite accounting.service.ts + DTOs
- `prisma.account` → `prisma.chartOfAccount`
- `name` → `nameAr` / `nameEn`
- `isPosted` → `status` (JournalStatus enum)
- Remove `sourceType`, `sourceId` from JournalEntry
- `journalEntries` relation → `journalLines`
- `journalEntry` relation → `entry`
- `journalEntryId` → `entryId`
- `prisma.treasuryTransaction` → `prisma.cashTransaction`
- `prisma.invoice` → `prisma.salesInvoice`
- `prisma.inventoryMovement` → `prisma.stockMovement`
- Remove `isSystem`, `reference` (not in schema)

## Batch 2: Purchases (77 errors)
## Batch 3: Inventory + Products (48+25 errors)
## Batch 4: Production + Feed (44+36 errors)
## Batch 5: Sales (30 errors)
## Batch 6: Reports (34 errors)
## Batch 7: HR (27 errors)
## Batch 8: Delivery (23 errors)

## Deliverables
- `npm run build` returns 0 TypeScript errors
- No `any` types introduced
- No fields introduced that don't exist in schema.prisma
